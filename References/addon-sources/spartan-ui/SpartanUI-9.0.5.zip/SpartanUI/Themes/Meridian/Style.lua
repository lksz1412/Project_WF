local SUI = SUI

-- Art and layout come from the shared painted-look builder (Themes/Painted.lua)
SUI.ThemePainted.Register({
	name = 'Meridian',
	displayName = 'Observatory',
	description = 'A worn brass survey instrument with dark enamel and sea-glass accents',
	accent = { 0.537, 0.710, 0.675 },
	narrowCentre = true,
	-- The name strip ends in sea-glass beads
	nameInset = 16,
	-- The top right map reaches past the round mask's soft edge
	cornerMinimapPad = 4,
	-- The map in the bar covers the dark rim inside the ring
	dockedMinimapSize = 188,
	kit = 'meridian',
	colors = {
		frameBg = { 0.047, 0.078, 0.075, 0.93 },
		frameBorder = { 0.553, 0.482, 0.345, 1.00 },
	},
})
