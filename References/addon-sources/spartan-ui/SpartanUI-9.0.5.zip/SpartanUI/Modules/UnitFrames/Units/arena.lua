if SUI.IsClassic then
	return
end

local UF = SUI.UF
local elementList = {
	---Basic
	'FrameBackground',
	'Name',
	'Health',
	'Castbar',
	'Power',
	'Portrait',
	'Dispel',
	'SpartanArt',
	not UF.IsModernOUF and 'Buffs',
	not UF.IsModernOUF and 'Debuffs',
	UF.IsModernOUF and 'BuffContainer',
	UF.IsModernOUF and 'DebuffContainer',
	UF.IsModernOUF and 'CustomAuras',
	'ClassIcon',
	'RaidTargetIndicator',
	'TargetHighlight',
	'Range',
	'Fader',
	'PVPSpecIcon',
	'GroupRoleIndicator',
	'RaidRoleIndicator',
	UF.IsModernOUF and 'AuraTracker',
}

local function GroupBuilder(holder)
	for i = 1, 5 do
		local frame = SUIUF:Spawn('arena' .. i, 'SUI_UF_arena' .. i)
		frame:SetAttribute('oUF-enableArenaPrep', true)

		holder.frames[i] = frame
	end
	UF.Unit:LayoutGroupFrames('arena')
end

local function Builder(frame)
	local elementDB = frame.elementDB

	for _, elementName in pairs(elementList) do
		UF.Elements:Build(frame, elementName, elementDB[elementName])
	end
end

local function Options(OptionSet)
	UF.Options:AddGroupLayout('arena', OptionSet)
end

---@type SUI.UF.Unit.Settings
local Settings = {
	maxColumns = 1,
	unitsPerColumn = 5,
	columnSpacing = 1,
	yOffset = -10,
	elements = {
		Name = { text = '[SUI_ColorClass][name] [arenaspec]' },
		Power = {
			height = 5,
		},
		Portrait = {
			enabled = false,
		},
		Castbar = {
			enabled = true,
			height = 15,
		},
		Health = {
			position = {
				anchor = 'TOP',
				relativeTo = 'Castbar',
				relativePoint = 'BOTTOM',
			},
		},
		ThreatIndicator = {
			enabled = true,
			points = 'Name',
		},
		ClassIcon = {
			enabled = true,
		},
	},
	config = {
		IsGroup = true,
		useUnitWatch = true,
	},
}

UF.Unit:Add('arena', Builder, Settings, Options, GroupBuilder)
