local UF = SUI.UF

---@param element any
---@param unit? UnitId
---@param isFullUpdate? boolean
local function updateSettings(element, unit, isFullUpdate)
	local DB = element.DB
	element.size = DB.size or 20
	element.initialAnchor = DB.position.anchor
	element.growthX = DB.growthx
	element.growthY = DB.growthy
	-- Disable showType in Retail to avoid secret aura API errors
	element.showType = not SUI.IsRetail and DB.showType
	element.num = DB.number or 10
	element.onlyShowPlayer = DB.onlyShowPlayer
	-- Set maxCols to avoid secret value errors from GetWidth() in Retail
	element.maxCols = DB.number / DB.rows
	element.disableMouse = DB.clickThrough
end

---@param element any
local function SizeChange(element)
	local DB = element.DB
	local w = (DB.number / DB.rows)
	if w < 1.5 then
		w = 1.5
	end
	element:SetSize((DB.size + DB.spacing) * w, (DB.spacing + DB.size) * DB.rows)
end

---@param frame table
---@param DB table
local function Build(frame, DB)
	--Debuff Icons
	local element = CreateFrame('Frame', frame.unitOnCreate .. 'Debuffs', frame.raised)
	element.PostUpdateButton = function(self, button, unit, data, position)
		button.data = data
		button.unit = unit
		button.showDuration = self.DB and self.DB.showDuration
		-- Apply text customization settings
		if self.DB and button._lastTextSettingsApplied ~= self.DB then
			UF.Auras:ApplyTextSettings(button, self.DB)
			button._lastTextSettingsApplied = self.DB
		end
	end
	element.PostCreateButton = function(self, button)
		UF.Auras:PostCreateButton('Debuffs', button)
	end

	---@param unit UnitId
	---@param data UnitAuraInfo
	local FilterAura = function(element, unit, data)
		return UF.Auras:Filter(element, unit, data)
	end
	local PreUpdate = function(self)
		updateSettings(element)
		-- Update sort function based on settings
		local sortMode = element.DB and element.DB.sortMode
		element.SortDebuffs = UF.Auras:CreateSortFunction(sortMode)
	end

	-- Set FilterAura for both Retail and Classic
	element.FilterAura = FilterAura
	if not SUI.IsRetail then
		element.displayReasons = {}
	end
	element.PreUpdate = PreUpdate
	element.SizeChange = SizeChange

	frame.Debuffs = element
end

---@param frame table
---@param settings? table
local function Update(frame, settings)
	local element = frame.Debuffs
	local DB = settings or element.DB

	if DB.enabled then
		element:Show()
	else
		element:Hide()
	end

	updateSettings(element)

	for i = 1, element.createdButtons or 0 do
		local button = element[i]
		if button then
			button.showDuration = DB.showDuration
			UF.Auras:ApplyTextSettings(button, DB)
		end
	end
end

---@param unitName string
---@param OptionSet AceConfig.OptionsTable
local function Options(unitName, OptionSet)
	-- Retail renders auras through its own containers. This element cannot draw there,
	-- so showing its settings would be a panel that does nothing.
	if SUI.IsRetail then
		return
	end

	local L = SUI.L
	local ElementSettings = UF.CurrentSettings[unitName].elements.Debuffs

	local function OptUpdate(option, val)
		--Update memory
		UF.CurrentSettings[unitName].elements.Debuffs[option] = val
		--Update the DB
		UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs[option] = val
		--Update the screen
		UF.Unit[unitName]:ElementUpdate('Debuffs')
	end

	OptionSet.args.Display = OptionSet.args.Display or {
		name = L['Display'],
		type = 'group',
		order = 10,
		inline = true,
		args = {},
	}

	-- Visual settings (size, count, layout)
	OptionSet.args.Display.args.size = {
		name = L['Icon Size'],
		desc = L['Size of each debuff icon'],
		type = 'range',
		order = 1,
		min = 10,
		max = 60,
		step = 1,
		get = function()
			return ElementSettings.size or 20
		end,
		set = function(_, val)
			OptUpdate('size', val)
		end,
	}

	OptionSet.args.Display.args.number = {
		name = L['Icon Count'],
		desc = L['Maximum number of debuffs to display'],
		type = 'range',
		order = 2,
		min = 1,
		max = 40,
		step = 1,
		get = function()
			return ElementSettings.number or 10
		end,
		set = function(_, val)
			OptUpdate('number', val)
		end,
	}

	OptionSet.args.Display.args.rows = {
		name = L['Rows'],
		desc = L['Number of rows for debuff icons'],
		type = 'range',
		order = 3,
		min = 1,
		max = 10,
		step = 1,
		get = function()
			return ElementSettings.rows or 2
		end,
		set = function(_, val)
			OptUpdate('rows', val)
		end,
	}

	OptionSet.args.Display.args.spacing = {
		name = L['Spacing'],
		desc = L['Space between debuff icons'],
		type = 'range',
		order = 4,
		min = 0,
		max = 10,
		step = 1,
		get = function()
			return ElementSettings.spacing or 1
		end,
		set = function(_, val)
			OptUpdate('spacing', val)
		end,
	}

	OptionSet.args.Display.args.growthx = {
		name = L['Horizontal Growth'],
		desc = L['Direction debuffs grow horizontally'],
		type = 'select',
		order = 5,
		values = {
			LEFT = L['Left'],
			RIGHT = L['Right'],
		},
		get = function()
			return ElementSettings.growthx or 'LEFT'
		end,
		set = function(_, val)
			OptUpdate('growthx', val)
		end,
	}

	OptionSet.args.Display.args.growthy = {
		name = L['Vertical Growth'],
		desc = L['Direction debuffs grow vertically'],
		type = 'select',
		order = 6,
		values = {
			UP = L['Up'],
			DOWN = L['Down'],
		},
		get = function()
			return ElementSettings.growthy or 'UP'
		end,
		set = function(_, val)
			OptUpdate('growthy', val)
		end,
	}

	OptionSet.args.Display.args.clickThrough = {
		name = L['Click-through'],
		desc = L['Clicks pass through debuff icons to the unit frame underneath. Useful for healers using click-casting.'],
		type = 'toggle',
		order = 6.5,
		get = function()
			return ElementSettings.clickThrough
		end,
		set = function(_, val)
			OptUpdate('clickThrough', val)
		end,
	}

	OptionSet.args.Expiring = {
		name = L['Expiring effects'],
		type = 'group',
		order = 15,
		inline = true,
		args = {
			enabled = {
				name = L['Glow when expiring'],
				desc = L['Show a glowing border on aura icons that are about to expire'],
				type = 'toggle',
				order = 1,
				get = function()
					return ElementSettings.expiring and ElementSettings.expiring.enabled
				end,
				set = function(_, val)
					if not UF.CurrentSettings[unitName].elements.Debuffs.expiring then
						UF.CurrentSettings[unitName].elements.Debuffs.expiring = {}
					end
					UF.CurrentSettings[unitName].elements.Debuffs.expiring.enabled = val
					if not UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring then
						UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring = {}
					end
					UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring.enabled = val
					UF.Unit[unitName]:ElementUpdate('Debuffs')
				end,
			},
			threshold = {
				name = L['Threshold (seconds)'],
				desc = L['Start showing the glow effect when this many seconds remain'],
				type = 'range',
				order = 2,
				min = 1,
				max = 30,
				step = 1,
				get = function()
					return ElementSettings.expiring and ElementSettings.expiring.threshold or 5
				end,
				set = function(_, val)
					if not UF.CurrentSettings[unitName].elements.Debuffs.expiring then
						UF.CurrentSettings[unitName].elements.Debuffs.expiring = {}
					end
					UF.CurrentSettings[unitName].elements.Debuffs.expiring.threshold = val
					if not UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring then
						UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring = {}
					end
					UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring.threshold = val
					UF.Unit[unitName]:ElementUpdate('Debuffs')
				end,
			},
			pulsate = {
				name = L['Pulsate'],
				desc = L['Animate the glow with a pulsating effect instead of a static glow'],
				type = 'toggle',
				order = 3,
				get = function()
					return ElementSettings.expiring and ElementSettings.expiring.pulsate
				end,
				set = function(_, val)
					if not UF.CurrentSettings[unitName].elements.Debuffs.expiring then
						UF.CurrentSettings[unitName].elements.Debuffs.expiring = {}
					end
					UF.CurrentSettings[unitName].elements.Debuffs.expiring.pulsate = val
					if not UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring then
						UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring = {}
					end
					UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring.pulsate = val
					UF.Unit[unitName]:ElementUpdate('Debuffs')
				end,
			},
			color = {
				name = L['Glow color'],
				desc = L['Color of the expiring glow effect'],
				type = 'color',
				order = 4,
				hasAlpha = true,
				get = function()
					local c = ElementSettings.expiring and ElementSettings.expiring.color or { 1, 0.2, 0.2, 0.8 }
					return c[1], c[2], c[3], c[4]
				end,
				set = function(_, r, g, b, a)
					if not UF.CurrentSettings[unitName].elements.Debuffs.expiring then
						UF.CurrentSettings[unitName].elements.Debuffs.expiring = {}
					end
					UF.CurrentSettings[unitName].elements.Debuffs.expiring.color = { r, g, b, a }
					if not UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring then
						UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring = {}
					end
					UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs.expiring.color = { r, g, b, a }
					UF.Unit[unitName]:ElementUpdate('Debuffs')
				end,
			},
		},
	}

	local anchorValues = {
		TOPLEFT = L['Top Left'],
		TOP = L['Top'],
		TOPRIGHT = L['Top Right'],
		LEFT = L['Left'],
		CENTER = L['Center'],
		RIGHT = L['Right'],
		BOTTOMLEFT = L['Bottom Left'],
		BOTTOM = L['Bottom'],
		BOTTOMRIGHT = L['Bottom Right'],
	}

	local outlineValues = {
		NONE = L['None'],
		OUTLINE = L['Outline'],
		THICKOUTLINE = L['Thick outline'],
	}

	local function NestedOptUpdate(path, val)
		local keys = {}
		for key in path:gmatch('[^.]+') do
			keys[#keys + 1] = key
		end
		local t = UF.CurrentSettings[unitName].elements.Debuffs
		for i = 1, #keys - 1 do
			if not t[keys[i]] then
				t[keys[i]] = {}
			end
			t = t[keys[i]]
		end
		t[keys[#keys]] = val
		local d = UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs
		for i = 1, #keys - 1 do
			if not d[keys[i]] then
				d[keys[i]] = {}
			end
			d = d[keys[i]]
		end
		d[keys[#keys]] = val
		UF.Unit[unitName]:ElementUpdate('Debuffs')
	end

	local function TextHidden(showKey)
		return function()
			return ElementSettings[showKey] == false
		end
	end

	OptionSet.args.TextCustomization = {
		name = L['Text on icons'],
		desc = L['The time left and stack count drawn on each icon'],
		type = 'group',
		order = 16,
		inline = true,
		args = {
			durationHeader = {
				name = L['Time left'],
				type = 'header',
				order = 1,
			},
			showDuration = {
				name = L['Show time left'],
				desc = L['Show how long each aura has left, written on the icon'],
				type = 'toggle',
				order = 1.5,
				get = function()
					return ElementSettings.showDuration ~= false
				end,
				set = function(_, val)
					OptUpdate('showDuration', val)
				end,
			},
			durationSize = {
				name = L['Size'],
				type = 'range',
				disabled = TextHidden('showDuration'),
				order = 2,
				min = 6,
				max = 24,
				step = 1,
				get = function()
					return ElementSettings.durationText and ElementSettings.durationText.size or 10
				end,
				set = function(_, val)
					NestedOptUpdate('durationText.size', val)
				end,
			},
			durationOutline = {
				name = L['Outline'],
				type = 'select',
				disabled = TextHidden('showDuration'),
				order = 3,
				values = outlineValues,
				get = function()
					return ElementSettings.durationText and ElementSettings.durationText.outline or 'OUTLINE'
				end,
				set = function(_, val)
					NestedOptUpdate('durationText.outline', val)
				end,
			},
			durationAnchor = {
				name = L['Position'],
				type = 'select',
				disabled = TextHidden('showDuration'),
				order = 4,
				values = anchorValues,
				get = function()
					return ElementSettings.durationText and ElementSettings.durationText.anchor or 'CENTER'
				end,
				set = function(_, val)
					NestedOptUpdate('durationText.anchor', val)
				end,
			},
			durationColorByTime = {
				name = L['Color by remaining time'],
				desc = L['Red when expiring soon, yellow when moderate, white otherwise'],
				type = 'toggle',
				disabled = TextHidden('showDuration'),
				order = 5,
				get = function()
					return ElementSettings.durationText and ElementSettings.durationText.colorByTime ~= false
				end,
				set = function(_, val)
					NestedOptUpdate('durationText.colorByTime', val)
				end,
			},
			stackHeader = {
				name = L['Stack count'],
				type = 'header',
				order = 10,
			},
			showCount = {
				name = L['Show stack count'],
				desc = L['Show how many stacks an aura has, written on the icon'],
				type = 'toggle',
				order = 10.5,
				get = function()
					return ElementSettings.showCount ~= false
				end,
				set = function(_, val)
					OptUpdate('showCount', val)
				end,
			},
			stackSize = {
				name = L['Size'],
				type = 'range',
				disabled = TextHidden('showCount'),
				order = 11,
				min = 6,
				max = 24,
				step = 1,
				get = function()
					return ElementSettings.stackText and ElementSettings.stackText.size or 10
				end,
				set = function(_, val)
					NestedOptUpdate('stackText.size', val)
				end,
			},
			stackOutline = {
				name = L['Outline'],
				type = 'select',
				disabled = TextHidden('showCount'),
				order = 12,
				values = outlineValues,
				get = function()
					return ElementSettings.stackText and ElementSettings.stackText.outline or 'OUTLINE'
				end,
				set = function(_, val)
					NestedOptUpdate('stackText.outline', val)
				end,
			},
			stackAnchor = {
				name = L['Position'],
				type = 'select',
				disabled = TextHidden('showCount'),
				order = 13,
				values = anchorValues,
				get = function()
					return ElementSettings.stackText and ElementSettings.stackText.anchor or 'BOTTOMRIGHT'
				end,
				set = function(_, val)
					NestedOptUpdate('stackText.anchor', val)
				end,
			},
		},
	}

	OptionSet.args.Display.args.sortMode = {
		name = L['Sort Mode'],
		desc = SUI.IsRetail and L['Sort by priority (player auras first). Time/Name sorting unavailable in Retail.']
			or L['How to sort auras. Priority sorts by importance (boss > dispellable > player), Time sorts by remaining duration, Name sorts alphabetically.'],
		type = 'select',
		order = 6,
		values = SUI.IsRetail and {
			priority = L['Priority (Recommended)'],
		} or {
			priority = L['Priority (Recommended)'],
			time = L['Time Remaining'],
			name = L['Alphabetical'],
		},
		get = function()
			return ElementSettings.sortMode or 'priority'
		end,
		set = function(_, val)
			OptUpdate('sortMode', val)
		end,
	}

	-- Retail: Prominent Filter Mode radio selects (inline group on main element page)
	if SUI.IsRetail then
		OptionSet.args.FilterMode = {
			name = L['Filter Mode'],
			type = 'group',
			order = 50,
			inline = true,
			args = {
				desc = {
					type = 'description',
					name = 'WoW 12.0.1 provides 14+ filter modes for precise aura control. Select a preset below or use a custom filter string.',
					order = 0,
					fontSize = 'small',
				},
				filterMode = {
					name = L['Filter Preset'],
					desc = L['Select a predefined filter configuration'],
					type = 'select',
					order = 1,
					width = 'full',
					values = {
						blizzard_default = L['Blizzard Default (Recommended)'],
						all_debuffs = L['All Debuffs'],
						player_debuffs = L['Player Debuffs Only'],
						raid_debuffs = L['Raid Debuffs'],
						dispellable = L['Dispellable Only'],
						crowd_control = L['Crowd Control'],
					},
					get = function()
						local retail = ElementSettings.retail
						return retail and retail.filterMode or 'blizzard_default'
					end,
					set = function(_, val)
						ElementSettings.retail = ElementSettings.retail or {}
						ElementSettings.retail.filterMode = val
						ElementSettings.retail.customFilter = nil -- Clear custom when selecting preset

						local userSettings = UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs
						userSettings.retail = userSettings.retail or {}
						userSettings.retail.filterMode = val
						userSettings.retail.customFilter = nil

						UF.Unit[unitName]:ElementUpdate('Debuffs')
					end,
				},
				disableInPvP = {
					name = L['Hide in PvP'],
					desc = L['Hides raid debuffs in battlegrounds and arenas where the RAID filter flags too many debuffs'],
					type = 'toggle',
					order = 2,
					hidden = function()
						local retail = ElementSettings.retail
						return not retail or retail.filterMode ~= 'raid_debuffs'
					end,
					get = function()
						local retail = ElementSettings.retail
						return not retail or retail.disableInPvP ~= false
					end,
					set = function(_, val)
						ElementSettings.retail = ElementSettings.retail or {}
						ElementSettings.retail.disableInPvP = val

						local userSettings = UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs
						userSettings.retail = userSettings.retail or {}
						userSettings.retail.disableInPvP = val

						UF.Unit[unitName]:ElementUpdate('Debuffs')
					end,
				},
				customFilterHeader = {
					name = L['Advanced: Custom Filter String'],
					type = 'header',
					order = 5,
				},
				customFilter = {
					name = L['Filter String'],
					desc = L['Advanced: Enter raw filter string (e.g., "HARMFUL|RAID|PLAYER"). Overrides preset selection. Clear the field to use the preset above.'],
					type = 'input',
					width = 'full',
					order = 6,
					get = function()
						local retail = ElementSettings.retail
						local custom = retail and retail.customFilter
						local filterStr
						if custom and custom ~= '' then
							filterStr = custom
						else
							local filterMode = retail and retail.filterMode or 'blizzard_default'
							filterStr = UF.Auras.FILTER_PRESETS[filterMode] or 'HARMFUL'
						end
						return filterStr:gsub('|', '||')
					end,
					set = function(_, val)
						val = val and val:gsub('||', '|') or val
						ElementSettings.retail = ElementSettings.retail or {}
						local userSettings = UF.DB.UserSettings[UF:GetPresetForFrame(unitName)][unitName].elements.Debuffs
						userSettings.retail = userSettings.retail or {}

						-- Check if custom string matches any preset
						local matchedPreset = nil
						if val and val ~= '' then
							for presetKey, presetFilter in pairs(UF.Auras.FILTER_PRESETS) do
								if val == presetFilter then
									matchedPreset = presetKey
									break
								end
							end
						end

						if matchedPreset then
							-- User entered a preset string - switch to that preset
							ElementSettings.retail.filterMode = matchedPreset
							ElementSettings.retail.customFilter = nil
							userSettings.retail.filterMode = matchedPreset
							userSettings.retail.customFilter = nil
							SUI:Print('Filter matched preset: |cFF00FF00' .. matchedPreset .. '|r - switched to preset mode')
						else
							-- Actual custom string
							ElementSettings.retail.customFilter = val ~= '' and val or nil
							userSettings.retail.customFilter = val ~= '' and val or nil
						end

						UF.Unit[unitName]:ElementUpdate('Debuffs')
					end,
				},
				filtersReference = {
					type = 'description',
					order = 7,
					fontSize = 'small',
					name = 'Available Filters:\nHELPFUL, HARMFUL, PLAYER, RAID, RAID_IN_COMBAT, RAID_PLAYER_DISPELLABLE, EXTERNAL_DEFENSIVE, BIG_DEFENSIVE, CROWD_CONTROL, CANCELABLE, NOT_CANCELABLE, INCLUDE_NAME_PLATE_ONLY, MAW\n\nCombine with | (pipe) character, e.g., "HARMFUL|RAID|PLAYER"',
				},
			},
		}
	end
end

---@type SUI.UF.Elements.Settings
local Settings = {
	number = 10,
	size = 20,
	spacing = 1,
	width = false,
	ShowBoss = true,
	showType = true,
	showDuration = true,
	showCount = true,
	clickThrough = false,
	sortMode = 'priority',
	growthx = 'LEFT',
	growthy = 'UP',
	rows = 2,
	expiring = {
		enabled = false,
		threshold = 5,
		pulsate = true,
		color = { 1, 0.2, 0.2, 0.8 },
	},
	durationText = {
		size = 10,
		outline = 'OUTLINE',
		anchor = 'CENTER',
		x = 0,
		y = 0,
		colorByTime = true,
	},
	stackText = {
		size = 10,
		outline = 'OUTLINE',
		anchor = 'BOTTOMRIGHT',
		x = 2,
		y = -2,
	},
	position = {
		anchor = 'TOPRIGHT',
		relativePoint = 'BOTTOMRIGHT',
		smartPosition = {
			enabled = false,
			anchorTo = 'Buffs', -- Which element to anchor to when enabled
		},
	},
	config = {
		type = 'Auras',
	},
	-- Retail filter config
	retail = {
		filterMode = 'blizzard_default',
	},
	-- Classic filter config
	classic = {
		rules = {
			duration = {
				enabled = true,
				mode = 'include',
				maxTime = 180,
				minTime = 1,
			},
			isHarmful = true,
			isBossAura = true,
			isFromPlayerOrPlayerPet = false,
			isHelpful = false,
			isStealable = false,
			isRaid = false,
			nameplateShowPersonal = false,
			nameplateShowAll = false,
			isNameplateOnly = false,
			canApplyAura = false,
		},
		whitelist = {},
		blacklist = {},
	},
}
UF.Elements:Register('Debuffs', Build, Update, Options, Settings)
