local _, ns = ...
local P = ns.Plates
local L = P.L

-- Setup steps (3.1), defined by the core and added by the host through host.AddSetupSteps.
-- LibAT.Setup rules apply: a pick is staged and applied when the player moves on; get() returns
-- the pending value; never reload from a step.
--
-- One compact "look" step, preselected on "Match my look" so Next accepts it, with the size as a
-- variant row (Small / Medium / Large) on every card: LibAT reads variants per card and calls
-- getVariant(value) and setVariant(value, variant, ctx), where value is the card's style. Picking
-- a size on a card also picks that card. Cards come from P.Gallery:Cards() (live art through the
-- LibAT art.draw hook when the gallery supplies it; otherwise the name and description).
--
-- Leaving the step (not closing the window) applies, in one Store batch:
--   * the style and size;
--   * the role, when the host knows the player's answer from its own setup
--     (host.GetSetupRole() -> 'tank' | 'damage' | 'healer' | nil); nil keeps 'auto' (the spec);
--   * the game settings setup turns on (open question 6): plates do not overlap, friendly players
--     show names only inside instances, plates keep one size (SetupSteps.BEHAVIOR). A behavior key
--     the player already set is left alone;
--   * profile.enabled = true (picking a style turns these plates on for the profile) and the
--     What's new card is marked answered.
-- Migrated profiles never pass through here, so their game settings stay untouched (7.4).
--
-- The host decides where the step sits (order, chapter), when it is hidden and any banner (for
-- example another nameplate addon that the conflicts step can turn off). The step's summary() is
-- the Done page line: "Style: Clean. Size: Large." and the game settings we changed.
-- SetupSteps:RestoreGame backs the Done page's "Give the game back its settings" link, which the
-- host also adds while another nameplate addon draws the plates (nothing runs then, but the step
-- has saved its choices).

---@class Plates.SetupSteps
local SetupSteps = { pending = {} }
P.SetupSteps = SetupSteps

SetupSteps.STEP_ID = 'nameplates-look'

---Size choices shown on every card.
SetupSteps.SIZES = {
	{ value = 'small', text = L['Small'] },
	{ value = 'medium', text = L['Medium'] },
	{ value = 'large', text = L['Large'] },
}

---Game settings finishing setup turns on (profile.behavior keys; the Driver writes them).
SetupSteps.BEHAVIOR = {
	stacking = { enemy = true },
	friendlyNames = true,
	pinScale = true,
}

---What each behavior changes, for the Done page, and the game settings it covers (so the list
---does not name them twice).
SetupSteps.BEHAVIOR_TEXT = {
	{ key = 'stacking', text = L['Plates do not overlap'], cvars = { 'nameplateStackingTypes' } },
	{
		key = 'friendlyNames',
		text = L['Friendly players show names only in dungeons and raids'],
		cvars = { 'nameplateShowOnlyNameForFriendlyPlayerUnits', 'nameplateUseClassColorForFriendlyPlayerUnitNames' },
	},
	{ key = 'pinScale', text = L['Plates keep one size at any distance'], cvars = { 'nameplateMinScale', 'nameplateMaxScale', 'nameplateSelectedScale' } },
}

---Whether a setup game setting does anything on this client: only clients that hide units in
---instances hand friendly plates there back to the game, so friendlyNames changes nothing elsewhere.
---@param key string
---@return boolean
function SetupSteps.BehaviorApplies(key)
	if key == 'friendlyNames' then
		return P.Caps:Get('secrets') == true
	end
	return true
end

---Roles the host may report from its own setup.
local ROLES = { tank = true, damage = true, healer = true }

---The looks the first-run step offers (the Style page gallery shows every style).
SetupSteps.LOOKS = { host = true, clean = true, slim = true, bold = true, bordered = true, blizzard = true }

---Gallery cards with the size row on each.
---@return table[] cards
function SetupSteps.Cards()
	local cards = {}
	for _, card in ipairs(P.Gallery:Cards()) do
		if SetupSteps.LOOKS[card.value] then
			card.variants = SetupSteps.SIZES
			cards[#cards + 1] = card
		end
	end
	return cards
end

---The step's recommended value for LibAT's quick paths (no card uses it, see P:GetSetupSteps).
SetupSteps.RECOMMENDED = '@recommended'

---The style the step shows as picked: the pending pick, else the profile's.
---@return string
function SetupSteps:Style()
	if self.pending.style ~= nil then
		return self.pending.style
	end
	return P.Store:Get('style') or 'host'
end

---The size the step shows as picked.
---@return string
function SetupSteps:Size()
	return self.pending.size or P.Store:Get('size') or 'medium'
end

---Display name of a style id ('host' is "Match my look").
---@param id string|nil
---@return string
function SetupSteps:StyleName(id)
	local Registry = P.Styles.Registry
	local style = Registry:Get(Registry:ResolveId(id))
	if id == 'host' and not (style and style.matchesHost) then
		return L['Match my look']
	end
	return style and style.name or tostring(id)
end

---@param size string|nil
---@return string
function SetupSteps:SizeName(size)
	for _, item in ipairs(self.SIZES) do
		if item.value == size then
			return item.text
		end
	end
	return tostring(size)
end

---The role the host's own setup asked about, or nil.
---@return string|nil
local function HostRole()
	local host = P.host
	if not (host and host.GetSetupRole) then
		return nil
	end
	local ok, role = pcall(host.GetSetupRole)
	if ok and ROLES[role] then
		return role
	end
	return nil
end

---Apply the step: style, size, role, the setup game settings, plates on. One refresh.
function SetupSteps:Apply()
	local pending = self.pending
	local role = HostRole()
	P.Store:Batch(function()
		if pending.style then
			P.Store:Set('style', pending.style)
		end
		if pending.size then
			P.Store:Set('size', pending.size)
		end
		if role then
			P.Store:Set('role', role)
		end
		for key, value in pairs(self.BEHAVIOR) do
			if P.Store:Get({ 'behavior', key }) == nil and SetupSteps.BehaviorApplies(key) then
				P.Store:Set({ 'behavior', key }, value)
			end
		end
		P.Store:Set('enabled', true)
	end)
	if P.Migrate and P.Migrate.FinishMakeover then
		P.Migrate:FinishMakeover()
	end
	P.util.Wipe(pending)
end

---Game settings these plates changed (or will change in instances), in plain words.
---@return string[]
function SetupSteps:ChangedSettings()
	local list, covered = {}, {}
	for _, item in ipairs(self.BEHAVIOR_TEXT) do
		local value = P.Store:Get({ 'behavior', item.key })
		if value ~= nil and value ~= false and SetupSteps.BehaviorApplies(item.key) then
			list[#list + 1] = item.text
			for _, name in ipairs(item.cvars) do
				covered[name] = true
			end
		end
	end
	local CVars = P.CVars
	for _, name in ipairs(CVars.order or {}) do
		local def = CVars.defs[name]
		if def and not covered[name] and CVars:GetBackup(name) ~= nil then
			list[#list + 1] = def.label
		end
	end
	return list
end

---The Done page line.
---@return string
function SetupSteps:Summary()
	local text = string.format(L['Style: %s. Size: %s.'], self:StyleName(self:Style()), self:SizeName(self:Size()))
	local changed = self:ChangedSettings()
	if #changed > 0 then
		text = text .. ' ' .. string.format(L['Game settings we change: %s.'], table.concat(changed, ', '))
	end
	-- Healer emphasis changes how enemy plates look the most; say so where the player looks
	local setting = P.Store:Get('role')
	local role = (setting and setting ~= 'auto') and setting or (P.Context and P.Context.role)
	if P.Roles.QuietOn(role) then
		text = text .. ' ' .. L['Because you heal, enemy plates stay small and soft until they matter. Change this in Who and where, More settings.']
	end
	return text
end

---"Give the game back its settings" (Done page link): puts back every game setting we changed
---and stops setup's own changes from coming back.
---@return boolean done false when some settings wait for combat to end
function SetupSteps:RestoreGame()
	P.Store:Batch(function()
		for key in pairs(self.BEHAVIOR) do
			P.Store:Set({ 'behavior', key }, nil)
		end
	end)
	if P.Driver and P.Driver.HandBack then
		return P.Driver:HandBack()
	end
	return P.CVars:RestoreAll()
end

---The steps for host.AddSetupSteps.
---@return table[] steps
function P:GetSetupSteps()
	return {
		{
			id = SetupSteps.STEP_ID,
			kind = 'look',
			compact = true,
			scope = 'profile',
			name = L['Nameplates'],
			title = L['Pick how your nameplates look'],
			text = L['The bars over enemy and friendly plates. You can change any part later.'],
			cards = SetupSteps.Cards,
			-- "Use recommended" (LibAT ApplyRecommended) calls set() only when get() differs from
			-- this, and never calls onLeave. No card has this value, so the recommended run always
			-- reaches set(), which keeps the player's style and applies the rest of the step.
			recommended = SetupSteps.RECOMMENDED,
			get = function()
				return SetupSteps:Style()
			end,
			set = function(value, ctx)
				if value ~= SetupSteps.RECOMMENDED then
					SetupSteps.pending.style = value
				end
				if ctx and ctx.recommendedRun then
					SetupSteps:Apply()
				end
			end,
			-- One size for every style, so the card's style does not change the answer
			getVariant = function()
				return SetupSteps:Size()
			end,
			setVariant = function(value, variant)
				SetupSteps.pending.style = value
				SetupSteps.pending.size = variant
			end,
			onLeave = function(ctx)
				if ctx and ctx.closing then
					return
				end
				SetupSteps:Apply()
			end,
			summary = function()
				return SetupSteps:Summary()
			end,
		},
	}
end
