local _, ns = ...
local M = ns.Messenger
local L = M.L

-- AceConfig options. Host-neutral: the host decides where the table is shown.

local MAX_CHANNEL_SLOTS = 12

---Joined numbered channels, in channel-number order. Community channels are left out.
---@return table[] { id = number, name = string }
local function JoinedChannels()
	local list = {}
	local data = { GetChannelList() }
	for i = 1, #data, 3 do
		local id, name = data[i], data[i + 1]
		if type(id) == 'number' and type(name) == 'string' and not name:find('^Community:') then
			list[#list + 1] = { id = id, name = name }
		end
	end
	return list
end

---Two toggles for one chat kind: bring it into Messenger, and whether the main chat keeps it.
---@param order number
---@param label string
---@param getRoute fun(): table|nil
---@param hidden? function
---@return table
local function RouteGroup(order, label, getRoute, hidden)
	return {
		type = 'group',
		inline = true,
		order = order,
		name = label,
		hidden = hidden,
		args = {
			capture = {
				type = 'toggle',
				order = 1,
				width = 'normal',
				name = L['Show in Messenger'],
				get = function()
					local route = getRoute()
					return route and route.capture
				end,
				set = function(_, value)
					local route = getRoute()
					if route then
						route.capture = value
						M:RoutesChanged()
					end
				end,
			},
			hide = {
				type = 'toggle',
				order = 2,
				width = 'double',
				name = L['Hide from the main chat window'],
				desc = L['When off, these messages show in both places.'],
				disabled = function()
					local route = getRoute()
					return not (route and route.capture)
				end,
				get = function()
					local route = getRoute()
					return route and route.hide
				end,
				set = function(_, value)
					local route = getRoute()
					if route then
						route.hide = value
						M:RoutesChanged()
					end
				end,
			},
		},
	}
end

---@return table
function M:BuildOptionsTable()
	local settings = function()
		return M.settings
	end

	local chats = {
		type = 'group',
		order = 2,
		name = L['Chats'],
		args = {
			about = {
				type = 'description',
				order = 0,
				fontSize = 'medium',
				name = L['Pick which chats become conversations in Messenger. Whispers are on to start with. Anything you turn on here gets its own conversation, and you choose whether the main chat window keeps showing it too.']
					.. '\n',
			},
			peopleHeader = { type = 'header', order = 1, name = L['People'] },
			groupHeader = { type = 'header', order = 20, name = L['Groups'] },
			publicHeader = { type = 'header', order = 40, name = L['Nearby'] },
			channelHeader = { type = 'header', order = 60, name = L['Joined channels'] },
			noChannels = {
				type = 'description',
				order = 61,
				name = L['You have not joined any channels.'],
				hidden = function()
					return #JoinedChannels() > 0
				end,
			},
		},
	}

	local orders = { WHISPER = 2, BN_WHISPER = 3, GUILD = 21, OFFICER = 22, PARTY = 23, RAID = 24, INSTANCE = 25, SAY = 41, YELL = 42, EMOTE = 43 }
	for _, kind in ipairs(M.Kinds) do
		if orders[kind.key] then
			chats.args[kind.key] = RouteGroup(orders[kind.key], kind.label, function()
				return M.settings.routes[kind.key]
			end)
		end
	end

	for slot = 1, MAX_CHANNEL_SLOTS do
		local function Channel()
			return JoinedChannels()[slot]
		end
		local group = RouteGroup(61 + slot, '', function()
			local channel = Channel()
			return channel and M.settings.channels[channel.name] or nil
		end, function()
			return Channel() == nil
		end)
		group.name = function()
			local channel = Channel()
			return channel and string.format('%d. %s', channel.id, channel.name) or ''
		end
		chats.args['channel' .. slot] = group
	end

	return {
		type = 'group',
		name = L['Messenger'],
		childGroups = 'tab',
		args = {
			open = {
				type = 'execute',
				order = 0,
				name = L['Open Messenger'],
				func = function()
					M:Open(nil, false)
				end,
			},
			general = {
				type = 'group',
				order = 1,
				name = L['General'],
				args = {
					onWhisper = {
						type = 'select',
						order = 1,
						width = 'double',
						name = L['When someone whispers you'],
						values = {
							alert = L['Show an alert'],
							open = L['Open Messenger right away'],
						},
						get = function()
							return settings().onWhisper
						end,
						set = function(_, value)
							settings().onWhisper = value
						end,
					},
					listMode = {
						type = 'select',
						order = 5,
						width = 'double',
						name = L['Conversation list size'],
						desc = L['How much room the list on the left takes. You can also switch with the list button at the top left of the Messenger window.'],
						values = {
							auto = L['Automatic: full, pictures only when the window is narrow'],
							full = L['Full: name and latest message'],
							slim = L['Compact: one short line per conversation'],
							icons = L['Pictures only'],
						},
						sorting = { 'auto', 'full', 'slim', 'icons' },
						get = function()
							return settings().listMode
						end,
						set = function(_, value)
							M.UI.Deck:SetListMode(value)
						end,
					},
					skin = {
						type = 'select',
						order = 9,
						width = 'double',
						name = L['Window style'],
						desc = L['How the Messenger windows are framed. Messenger keeps its own simple look unless you pick another style.'],
						hidden = function()
							return not M.Theme.Kit()
						end,
						values = function()
							local values = {
								default = L['Messenger (default)'],
								auto = L['Match my other windows'],
							}
							for _, skin in ipairs(M.Theme.SkinList()) do
								values[skin.id] = skin.name
							end
							return values
						end,
						sorting = function()
							local order = { 'default', 'auto' }
							for _, skin in ipairs(M.Theme.SkinList()) do
								order[#order + 1] = skin.id
							end
							return order
						end,
						get = function()
							return M.Theme.SkinId()
						end,
						set = function(_, value)
							settings().window.skin = value
							M.Widgets.ApplySkin()
						end,
					},
					messageStyle = {
						type = 'select',
						order = 9.1,
						width = 'double',
						name = L['Message style'],
						desc = L['Bubbles look like the messages app on a phone: yours on the right, everyone else on the left. You can also switch by right-clicking any message.'],
						values = {
							lines = L['Lines: names over each group of messages'],
							bubbles = L['Bubbles: yours on the right, theirs on the left'],
						},
						sorting = { 'lines', 'bubbles' },
						get = function()
							return settings().messageStyle
						end,
						set = function(_, value)
							M:SetMessageStyle(value)
						end,
					},
					myBubble = {
						type = 'select',
						order = 9.2,
						name = L['Your bubble color'],
						desc = L['The color of the messages you send.'],
						hidden = function()
							return settings().messageStyle ~= 'bubbles'
						end,
						values = function()
							local values = { chat = L['Color of the chat you are in'], custom = L['Your own color'] }
							for _, color in ipairs(M.Colors.Palette) do
								values[color.id] = color.label
							end
							return values
						end,
						sorting = function()
							local order = { 'chat' }
							for _, color in ipairs(M.Colors.Palette) do
								order[#order + 1] = color.id
							end
							order[#order + 1] = 'custom'
							return order
						end,
						get = function()
							local mine = settings().bubbles.mine
							return type(mine) == 'table' and 'custom' or mine
						end,
						set = function(_, value)
							local bubbles = settings().bubbles
							if value == 'custom' then
								if type(bubbles.mine) ~= 'table' then
									local start = M.Colors.ById.blue
									bubbles.mine = { start.r, start.g, start.b }
								end
							else
								bubbles.mine = value
							end
							M:Fire('COLORS_CHANGED')
						end,
					},
					myBubbleCustom = {
						type = 'color',
						order = 9.3,
						name = L['Pick your color'],
						hidden = function()
							return settings().messageStyle ~= 'bubbles' or type(settings().bubbles.mine) ~= 'table'
						end,
						get = function()
							local mine = settings().bubbles.mine
							return mine[1], mine[2], mine[3]
						end,
						set = function(_, r, g, b)
							settings().bubbles.mine = { r, g, b }
							M:Fire('COLORS_CHANGED')
						end,
					},
					otherBubbles = {
						type = 'select',
						order = 9.4,
						width = 'double',
						name = L["Other people's bubbles"],
						desc = L['A color you pick for someone always wins: right-click one of their messages. Colors are kept for your whole account, and Battle.net friends keep theirs on every character they play.'],
						hidden = function()
							return settings().messageStyle ~= 'bubbles'
						end,
						values = {
							auto = L['Grey in private chats, a color for each person in channels'],
							color = L['A color for each person everywhere'],
							grey = L['Grey everywhere'],
						},
						sorting = { 'auto', 'color', 'grey' },
						get = function()
							return settings().bubbles.others
						end,
						set = function(_, value)
							settings().bubbles.others = value
							M:Fire('COLORS_CHANGED')
						end,
					},
					fontSize = {
						type = 'range',
						order = 10,
						name = L['Text size'],
						min = 9,
						max = 20,
						step = 1,
						get = function()
							return settings().fontSize
						end,
						set = function(_, value)
							settings().fontSize = value
							M.Theme.RefreshFonts()
						end,
					},
					alpha = {
						type = 'range',
						order = 11,
						name = L['Window background'],
						desc = L['How solid the window background is.'],
						min = 0.4,
						max = 1,
						step = 0.02,
						isPercent = true,
						get = function()
							return settings().window.alpha
						end,
						set = function(_, value)
							settings().window.alpha = value
							M:Fire('SETTINGS_CHANGED')
						end,
					},
					fadeWhileMoving = {
						type = 'range',
						order = 11.5,
						name = L['Fade while moving'],
						desc = L['How see-through Messenger gets while your character moves, so it covers less of the world. It stays solid while your mouse is over it or you are typing. 100% turns this off.'],
						min = 0.1,
						max = 1,
						step = 0.05,
						isPercent = true,
						get = function()
							return settings().fadeWhileMoving
						end,
						set = function(_, value)
							settings().fadeWhileMoving = value
						end,
					},
					timeFormat = {
						type = 'select',
						order = 12,
						name = L['Clock'],
						values = {
							auto = L['Same as the game clock'],
							['12'] = L['12 hour'],
							['24'] = L['24 hour'],
						},
						get = function()
							return settings().timeFormat
						end,
						set = function(_, value)
							settings().timeFormat = value
							M:Fire('FONTS_CHANGED')
						end,
					},
					emoji = {
						type = 'toggle',
						order = 19,
						width = 'double',
						name = L['Show emoji pictures'],
						desc = L['Turns codes like :) and :fire: into pictures, and adds an emoji button to the message box.'],
						hidden = function()
							return not (M.host and M.host.emojiPath)
						end,
						get = function()
							return settings().emoji
						end,
						set = function(_, value)
							settings().emoji = value
							M:Fire('SETTINGS_CHANGED')
						end,
					},
					minimap = {
						type = 'toggle',
						order = 20,
						width = 'double',
						name = L['Show a minimap button'],
						get = function()
							return not settings().minimap.hide
						end,
						set = function(_, value)
							M.UI.Launcher:SetMinimapShown(value)
						end,
					},
					toggleKey = {
						type = 'keybinding',
						order = 24,
						width = 'double',
						name = L['Key to open or close Messenger'],
						desc = L['Click, then press the key you want. Press Escape instead to clear it. This is the same key binding you can set under Key Bindings > AddOns, and it cannot be changed during combat.'],
						hidden = function()
							return not (M.host and M.host.toggleBinding)
						end,
						disabled = function()
							return InCombatLockdown()
						end,
						get = function()
							return GetBindingKey(M.host.toggleBinding)
						end,
						set = function(_, key)
							M.Integration:SetKey(M.host.toggleBinding, key)
						end,
					},
					replyKey = {
						type = 'toggle',
						order = 25,
						width = 'full',
						name = L['Your Reply key answers in Messenger'],
						desc = L['Hidden whispers do not reach the main chat, so the normal Reply key could answer the wrong person. With this on, your Reply key opens the last person who whispered you in Messenger. Your saved key bindings are not changed. Typing /r in the main chat box still uses the main chat.'],
						get = function()
							return settings().replyKey
						end,
						set = function(_, value)
							settings().replyKey = value
							M:Fire('SETTINGS_CHANGED')
						end,
					},
					takeOverWhispers = {
						type = 'toggle',
						order = 26,
						width = 'full',
						name = L['Whispers you start in the main chat open in Messenger'],
						desc = L['Typing /w Name, clicking a name or choosing Whisper moves you into Messenger. Heads up: while this is on, the main chat box may refuse to send during some boss fights and Mythic+ until you reload. Turn it off if that happens to you.'],
						get = function()
							return settings().takeOverWhispers
						end,
						set = function(_, value)
							settings().takeOverWhispers = value
						end,
					},
					keys = {
						type = 'description',
						order = 30,
						name = '\n'
							.. L['Tip: set keys for "Open Messenger" and "Reply to last whisper" in the game\'s Key Bindings, under AddOns. Shift-click an item while typing to link it. Type /messenger Name to start a conversation.'],
					},
				},
			},
			chats = chats,
			alerts = {
				type = 'group',
				order = 3,
				name = L['Alerts'],
				args = {
					peopleHeader = { type = 'header', order = 1, name = L['Whispers'] },
					peopleSound = {
						type = 'toggle',
						order = 2,
						name = L['Play a sound'],
						get = function()
							return settings().alerts.people.sound
						end,
						set = function(_, value)
							settings().alerts.people.sound = value
						end,
					},
					peopleToast = {
						type = 'toggle',
						order = 3,
						name = L['Show a pop-up'],
						get = function()
							return settings().alerts.people.toast
						end,
						set = function(_, value)
							settings().alerts.people.toast = value
						end,
					},
					peopleFlash = {
						type = 'toggle',
						order = 4,
						name = L['Flash the taskbar'],
						desc = L['Flashes the game icon when the game is in the background.'],
						get = function()
							return settings().alerts.people.flash
						end,
						set = function(_, value)
							settings().alerts.people.flash = value
						end,
					},
					roomsHeader = { type = 'header', order = 10, name = L['Channels'] },
					roomsNote = {
						type = 'description',
						order = 10.5,
						name = L['Busy public chats (General, Trade, Say) pop up at most once every 5 minutes, unless you read them. A line with your name always alerts. Pick a different level for any conversation with the bell at the top of the chat.']
							.. '\n',
					},
					roomsSound = {
						type = 'toggle',
						order = 11,
						name = L['Play a sound'],
						get = function()
							return settings().alerts.rooms.sound
						end,
						set = function(_, value)
							settings().alerts.rooms.sound = value
						end,
					},
					roomsToast = {
						type = 'toggle',
						order = 12,
						name = L['Show a pop-up'],
						get = function()
							return settings().alerts.rooms.toast
						end,
						set = function(_, value)
							settings().alerts.rooms.toast = value
						end,
					},
					roomsFlash = {
						type = 'toggle',
						order = 13,
						name = L['Flash the taskbar'],
						get = function()
							return settings().alerts.rooms.flash
						end,
						set = function(_, value)
							settings().alerts.rooms.flash = value
						end,
					},
					mentions = {
						type = 'toggle',
						order = 14,
						width = 'full',
						name = L['Alert me when someone says my name in a channel'],
						desc = L['The line is highlighted, and you get the same sound and pop-up as a whisper.'],
						get = function()
							return settings().alerts.mentions
						end,
						set = function(_, value)
							settings().alerts.mentions = value
						end,
					},
					mentionWords = {
						type = 'input',
						order = 15,
						width = 'double',
						name = L['Other words to watch for'],
						desc = L['Separate words with commas, for example: tank, heals, your guild name.'],
						disabled = function()
							return not settings().alerts.mentions
						end,
						get = function()
							return settings().alerts.mentionWords
						end,
						set = function(_, value)
							settings().alerts.mentionWords = value
						end,
					},
					combatHeader = { type = 'header', order = 20, name = L['Combat'] },
					holdInCombat = {
						type = 'toggle',
						order = 21,
						width = 'full',
						name = L['Hold alerts until combat ends'],
						desc = L['Messages are still saved. You get one pop-up after the fight.'],
						get = function()
							return settings().alerts.holdInCombat
						end,
						set = function(_, value)
							settings().alerts.holdInCombat = value
						end,
					},
					hideInCombat = {
						type = 'toggle',
						order = 22,
						width = 'full',
						name = L['Hide the Messenger window in combat'],
						desc = L['It comes back when combat ends.'],
						get = function()
							return settings().alerts.hideInCombat
						end,
						set = function(_, value)
							settings().alerts.hideInCombat = value
						end,
					},
					popupHeader = { type = 'header', order = 30, name = L['Pop-ups'] },
					toastDuration = {
						type = 'range',
						order = 31,
						name = L['Seconds on screen'],
						min = 3,
						max = 20,
						step = 1,
						get = function()
							return settings().alerts.toastDuration
						end,
						set = function(_, value)
							settings().alerts.toastDuration = value
						end,
					},
					moveToasts = {
						type = 'execute',
						order = 32,
						name = function()
							return M.UI.Toast:IsUnlocked() and L['Lock pop-up position'] or L['Move pop-ups']
						end,
						func = function()
							M.UI.Toast:SetUnlocked(not M.UI.Toast:IsUnlocked())
						end,
					},
				},
			},
			history = {
				type = 'group',
				order = 4,
				name = L['History'],
				args = {
					maxMessages = {
						type = 'range',
						order = 1,
						width = 'double',
						name = L['Messages to keep per conversation'],
						min = 100,
						max = 2000,
						step = 50,
						get = function()
							return settings().history.maxMessages
						end,
						set = function(_, value)
							settings().history.maxMessages = value
						end,
					},
					keepDays = {
						type = 'range',
						order = 2,
						width = 'double',
						name = L['Delete quiet conversations after (days)'],
						desc = L['Conversations with no new messages for this many days are removed at login. Pinned ones are kept. 0 keeps everything.'],
						min = 0,
						max = 365,
						step = 1,
						get = function()
							return settings().history.keepDays
						end,
						set = function(_, value)
							settings().history.keepDays = value
						end,
					},
					roomDays = {
						type = 'range',
						order = 3,
						width = 'double',
						name = L['Keep channel messages for (days)'],
						min = 1,
						max = 14,
						step = 1,
						get = function()
							return settings().history.roomDays
						end,
						set = function(_, value)
							settings().history.roomDays = value
						end,
					},
					deleteAll = {
						type = 'execute',
						order = 10,
						name = L['Delete all conversations'],
						confirm = true,
						confirmText = L['Delete every conversation and all saved messages? This cannot be undone.'],
						func = function()
							M.Store:DeleteAll()
						end,
					},
				},
			},
		},
	}
end
