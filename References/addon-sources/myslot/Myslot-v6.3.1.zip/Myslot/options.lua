local _, MySlot = ...
local L = MySlot.L
local RegEvent = MySlot.regevent


local f = CreateFrame("Frame", nil, UIParent)
f.name = L["Myslot"]

local category = Settings.RegisterCanvasLayoutCategory(f, L["Myslot"])
MySlot.settingcategory = category
Settings.RegisterAddOnCategory(category)

RegEvent("ADDON_LOADED", function()
    do
        local t = f:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
        t:SetText(L["Myslot"])
        t:SetPoint("TOPLEFT", f, 15, -15)
    end

    do
        local t = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        t:SetText(L["Feedback"] .. "  farmer1992@gmail.com")
        t:SetPoint("TOPLEFT", f, 15, -50)
    end


    do
        local b = CreateFrame("Button", nil, f, "GameMenuButtonTemplate")
        b:SetWidth(240)
        b:SetHeight(25)
        b:SetPoint("TOPLEFT", 15, -80)
        b:SetText(L["Open Myslot"])
        b:SetScript("OnClick", function()
            MySlot.MainFrame:Show()
        end)
    end

    MyslotSettings = MyslotSettings or {}

    do
        MyslotSettings.minimap = MyslotSettings.minimap or { hide = false }
        local config = MyslotSettings.minimap

        local b = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
        b:SetPoint("TOPLEFT", f, 15, -110)

        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        b.text:SetPoint("LEFT", b, "RIGHT", 0, 1)
        b.text:SetText(L["Minimap Icon"])
        b:SetChecked(not config.hide)
        b:SetScript("OnClick", function()
            config.hide = not b:GetChecked()

            local icon = LibStub("LibDBIcon-1.0")
            if b:GetChecked() then
                icon:Show("Myslot")
            else
                icon:Hide("Myslot")
            end
        end)
    end

    do
        local t = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        t:SetText((DEFAULT or "Default") .. " " .. RED_FONT_COLOR:WrapTextInColorCode(L["IGNORE"]))
        t:SetPoint("TOPLEFT", f, 15, -145)
    end

    -- Mirrors the main window: Export on the left, Import on the right.
    local function AddIgnoreDefaultsButton(kind, text, x)
        local b = CreateFrame("Button", nil, f, "GameMenuButtonTemplate")
        b:SetWidth(150)
        b:SetHeight(25)
        b:SetPoint("TOPLEFT", x, -165)
        b:SetText(text)

        local icon = b:CreateTexture(nil, "ARTWORK")
        icon:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
        icon:SetPoint("RIGHT", -6, 0)
        icon:SetSize(16, 16)

        b:SetScript("OnClick", function(self)
            MySlot:ShowIgnoreDefaultsMenu(kind, self)
        end)
    end

    AddIgnoreDefaultsButton("export", L["Export"], 15)
    AddIgnoreDefaultsButton("import", L["Import"], 175)

    local doffset = -210
    do
        local t = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        t:SetText(RED_FONT_COLOR:WrapTextInColorCode(L["DANGEROUS"]))
        t:SetPoint("TOPLEFT", f, 15, doffset)
    end

    -- Running vertical cursor so hidden rows (e.g. Cooldown Manager on Classic)
    -- don't leave a gap; each row advances the offset by 30px.
    local rowy = doffset - 20
    local function AddClearButton(text, what)
        local b = CreateFrame("Button", nil, f, "GameMenuButtonTemplate")
        b:SetWidth(240)
        b:SetHeight(25)
        b:SetPoint("TOPLEFT", 15, rowy)
        b:SetText(text)
        b:SetScript("OnClick", function()
            StaticPopup_Show("MYSLOT_CONFIRM_CLEAR", what, nil, what)
        end)
        rowy = rowy - 30
    end

    AddClearButton(L["Remove everything in ActionBar"], "ACTION")
    AddClearButton(L["Remove all Key Bindings"], "BINDING")
    AddClearButton(L["Remove all Macros"], "MACRO")

    -- Cooldown Manager is retail-only; only offer it where supported.
    if MySlot:IsCooldownManagerSupported() then
        AddClearButton(L["Remove all Cooldown Manager"], "COOLDOWNMANAGER")
    end

    -- Click Cast Bindings are retail-only; only offer it where supported.
    if MySlot:IsClickBindingSupported() then
        AddClearButton(L["Remove all Click Cast Bindings"], "CLICKBINDING")
    end

    -- Talent loadouts are retail-only; this only removes the "Myslot" loadouts
    -- that "Apply talents" created.
    if MySlot:IsTalentStringSupported() then
        AddClearButton(L["Remove 'Myslot' talent loadouts"], "TALENTLOADOUT")
    end

    do
        local b = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
        b:SetPoint("TOPLEFT", f, 15, rowy)

        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        b.text:SetPoint("LEFT", b, "RIGHT", 0, 1)
        b.text:SetText(L["Allow"] .. " " .. "|cffff0000" .. L["CLEAR"] .. "|r" .. " " .. L[" before Import"])
        b:SetChecked(MyslotSettings.allowclearonimport)
        b:SetScript("OnClick", function()
            MyslotSettings.allowclearonimport = b:GetChecked()
        end)
    end
end)

StaticPopupDialogs["MYSLOT_CONFIRM_CLEAR"] = {
    text = L["Please type %s to confirm"],
    button1 = ACCEPT,
    button2 = CANCEL,
    hasEditBox = true,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    multiple = 0,
    OnAccept = function(self, data)
        local editBox = self.GetEditBox and self:GetEditBox() or self.editBox
        local tx = editBox:GetText()

        if tx == data then
            MySlot:Clear(data, {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                [8] = true,
                [9] = true,
                [10] = true,
                [11] = true,
                [12] = true,
                [13] = true,
                [14] = true,
                [15] = true,
                ["ACCOUNT"] = true,
                ["CHARACTOR"] = true,
                ["KEYBOARD"] = true,
                ["GAMEPAD"] = true,
            })
            MySlot:AnnounceCooldownManagerPending()
        else
            MySlot:Print(L["Please type %s to confirm"]:format(data))
        end

    end,
}