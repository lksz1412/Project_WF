--[[
	Portuguese Localization
--]]

local ADDON = ...
local L = LibStub('AceLocale-3.0'):NewLocale(ADDON, 'ptBR')
if not L then return end

--keybindings
L.OpenBags = 'Abrir Mochila'
L.OpenBank = 'Abrir Banco'
L.OpenGuild = 'Abrir Banco da Guilda'
L.OpenVault = 'Abrir Cofre'

--terminal
L.Commands = 'Lista de comandos'
L.CmdShowInventory = 'Mostra ou oculta o inventário'
L.CmdShowBank = 'Mostra ou oculta o banco'
L.CmdShowGuild = 'Mostra ou oculta o banco da guilda'
L.CmdShowVault = 'Mostra ou oculta o cofre do vazio'
L.CmdShowVersion = 'Mostra a versão atual'
L.CmdShowOptions = 'Abre o menu de configuração'
L.CmdReset = 'Apagar definições e dados em cache'
L.ResetConfirm = 'Tem a certeza de que deseja repor %s?|nTodas as definições e dados em cache serão perdidos.'
L.SkinError = 'Erro ao aplicar o tema.'
L.UpgradeError = 'Problema ao atualizar as definições. Se encontrar problemas, tente repor as suas definições.'

--titles
L.TitleBags = 'Mochila de %s'
L.TitleBank = 'Banco de %s'
L.TitleVault = 'Cofre de %s'
L.NormalBags = 'Bolsas Normais'
L.TradeBags = 'Bolsas de Profissão'
L.AmmoBags = 'Bolsas de Munição'

--tooltips
L.Bags = 'Bolsas'
L.Drag = 'Arrastar'
L.BrowseItems = 'Navegar Itens'
L.HideBag = 'Clique para esconder esta bolsa.'
L.ShowBag = 'Clique para mostrar esta bolsa.'
L.GuildFunds = 'Dinheiro da Guilda'
L.NumAllowed = '%s Permitidos'
L.NumWithdraw = '%s Retirar'
L.NumDeposit = '%s Depositar'
L.NumRemaining = '%s Restantes'
L.WarbandMoney = 'Dinheiro do Bando de Guerra'
L.OfflineViewing = 'Visualização Offline'
L.Others = 'Outros'

--menus
L.Characters = 'Personagens'
L.Guilds = 'Guildas'
L.Locations = 'Locais'
L.EnterDescription = 'Inserir Descrição:'
L.ServerSorting = 'Ordenar pelo Servidor'
L.ReverseSorting = 'Ordem Reversa'
L.PartialFirst = 'Pilhas parciais primeiro'
L.CleanupOptions = 'Opções de Limpeza'
L.IncludeReagents = 'Incluir Componentes'
L.LockItems = 'Bloquear Slots de Itens'

--dialogs
L.AskMafia = 'Perguntar à Máfia'
L.ConfirmDelete = 'Tem certeza de que deseja apagar os dados em cache de %s?'
L.ConfirmTransfer = 'Depositar quaisquer itens irá-lhes remover todas as modificações e torná-los-a introcáveis e não reembolsáveis.|n|nDeseja continuar?'
L.CannotPurchaseVault = 'Você não tem dinheiro suficiente para desbloquear a utilização do Cofre|n|n|cffff2020Custo: %s|r'
L.PurchaseVault = 'Gostaria de desbloquear o Cofre?|n|n|cffffd200Custo:|r %s'
L.ConfigurationMode = 'Você está no modo de configuração da ordenação pelo cliente.|n|nClique nos slots de itens para selecionar se devem ser bloqueados durante a ordenação.'
L.OutOfDate = 'A sua versão de |cffffd200%s|r pode estar desatualizada!|n%s reportou ter|n|cff82c5ff%s|r, atualize se for verdade.'
L.InvalidVersion = 'A sua cópia do |cffffd200%s|r está corrompida ou é ilegal.|nPor favor, faça download da versão oficial (gratuitamente).'
