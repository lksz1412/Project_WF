local addonName, ns = ...

local UI = {}
ns.ElvaUI = UI

UI.TEAL = { 0.141, 0.890, 0.827 }
UI.PINK = { 0.973, 0.424, 0.737 }
UI.GOLD = { 1, 0.82, 0 }
UI.TEAL_HEX = "24e3d3"
UI.PINK_HEX = "f86cbc"
UI.WINDOW = { 0.05, 0.05, 0.05, 0.95 }
UI.INNER = { 0.1, 0.1, 0.11, 0.97 }
UI.EDGE = 0.27
UI.EDGE_HOVER = 0.4
UI.BOX_EDGE = 0.42
UI.TINT = 0.045
UI.WIDTH = 900
UI.HEIGHT = 700
UI.MIN_HEIGHT = 540
UI.MAX_HEIGHT = 1000
UI.SCALE = 1.1
UI.GRID = 40
UI.RIGHT_COLUMN = 340
UI.PREVIEW_BG = { 0.314, 0.314, 0.314, 0.05 }
UI.CARD_W = 152
UI.CARD_H = 60
UI.MENU_X = 12
UI.MENU_NUDGE = 4
UI.MOVE_PANEL_Y = 0.25

UI.PAGE_COLORS = {
    ["Player"] = { 0.141, 0.890, 0.827 },
    ["Target & Focus"] = { 0.973, 0.424, 0.737 },
    ["Party"] = { 1, 0.478, 0.239 },
    ["Pet"] = { 0.494, 0.878, 0.541 },
    ["Nameplates"] = { 0.706, 0.549, 1 },
    ["Swing Timer"] = { 1, 0.878, 0.4 },
    ["GCD Bar"] = { 0.353, 0.722, 1 },
}

local TEX = "Interface\\AddOns\\" .. addonName .. "\\Textures\\"

local function NoSnap(t)
    if t.SetSnapToPixelGrid then
        t:SetSnapToPixelGrid(false)
        t:SetTexelSnappingBias(0)
    end
end

function UI.PixelLine(tex, vertical)
    if tex.SetSnapToPixelGrid then
        tex:SetSnapToPixelGrid(true)
        tex:SetTexelSnappingBias(0)
    end
    local scale = tex.GetEffectiveScale and tex:GetEffectiveScale() or 1
    local _, screenHeight = GetPhysicalScreenSize()
    local px = (screenHeight and screenHeight > 0) and (768 / screenHeight) / scale or 1
    if vertical then tex:SetWidth(px) else tex:SetHeight(px) end
end

UI.FONT = "Interface\\AddOns\\" .. addonName .. "\\Fonts\\NotoSansCondensedBlack.ttf"

UI.SIZES = {
    title = 16, info = 10, description = 12, hint = 10,
    menuHeader = 12, menuItem = 10, profile = 10,
    tab = 12, heading = 14, setting = 13, check = 12,
    note = 10, button = 12, preview = 10, value = 10,
}

local fonts = {}
function UI.Font(template, size)
    local key = template .. (size and ("_" .. size) or "")
    local name = addonName .. "ElvaUIFont" .. key
    if fonts[key] then return name end
    local object = CreateFont(name)
    if _G[template] then object:CopyFontObject(_G[template]) end
    local _, baseSize, flags = object:GetFont()
    if not pcall(object.SetFont, object, UI.FONT, size or baseSize or 12, flags or "") and _G[template] then object:CopyFontObject(_G[template]) end
    fonts[key] = object
    return name
end

function UI.HeaderFont()
    local name = addonName .. "ElvaUIHeader"
    if _G[name] then return name end
    local font = CreateFont(name)
    font:CopyFontObject(UI.Font("GameFontNormal"))
    local file, _, flags = font:GetFont()
    if file then pcall(font.SetFont, font, file, UI.SIZES.heading, flags or "") end
    return name
end

function UI.TitleFont()
    local name = addonName .. "ElvaUITitle"
    if _G[name] then return name end
    local font = CreateFont(name)
    font:CopyFontObject(UI.Font("GameFontNormal"))
    local file, _, flags = font:GetFont()
    if file then pcall(font.SetFont, font, file, UI.SIZES.setting, flags or "") end
    font:SetTextColor(1, 1, 1)
    return name
end

function UI.Outline(frame, r, layer, sub)
    local o = { parts = {} }
    local function Tex()
        local t = frame:CreateTexture(nil, layer or "BORDER", nil, sub or 0)
        NoSnap(t)
        o.parts[#o.parts + 1] = t
        return t
    end
    for _, d in ipairs({ { "TOPLEFT", 0, 0.5, 0, 0.5 }, { "TOPRIGHT", 0.5, 1, 0, 0.5 }, { "BOTTOMLEFT", 0, 0.5, 0.5, 1 }, { "BOTTOMRIGHT", 0.5, 1, 0.5, 1 } }) do
        local t = Tex()
        t:SetSize(r, r)
        t:SetPoint(d[1], frame, d[1], 0, 0)
        t:SetTexture(TEX .. "UIRing12.tga")
        t:SetTexCoord(d[2], d[3], d[4], d[5])
    end
    for _, d in ipairs({ { "TOPLEFT", r, 0, "TOPRIGHT", -r, 0 }, { "BOTTOMLEFT", r, 0, "BOTTOMRIGHT", -r, 0 }, { "TOPLEFT", 0, -r, "BOTTOMLEFT", 0, r, true }, { "TOPRIGHT", 0, -r, "BOTTOMRIGHT", 0, r, true } }) do
        local t = Tex()
        t:SetColorTexture(1, 1, 1, 1)
        t:SetPoint(d[1], frame, d[1], d[2], d[3])
        t:SetPoint(d[4], frame, d[4], d[5], d[6])
        UI.PixelLine(t, d[7])
    end
    function o:SetColor(cr, cg, cb, ca)
        for _, t in ipairs(self.parts) do t:SetVertexColor(cr, cg, cb, ca or 1) end
    end
    return o
end

function UI.Shape(frame, r, layer, sub, ins, host)
    ins = ins or 0
    local o = { parts = {} }
    local function Tex()
        local t = (host or frame):CreateTexture(nil, layer or "BACKGROUND", nil, sub or 0)
        NoSnap(t)
        o.parts[#o.parts + 1] = t
        return t
    end
    for _, d in ipairs({ { "TOPLEFT", 0, 0.5, 0, 0.5, 1, -1 }, { "TOPRIGHT", 0.5, 1, 0, 0.5, -1, -1 }, { "BOTTOMLEFT", 0, 0.5, 0.5, 1, 1, 1 }, { "BOTTOMRIGHT", 0.5, 1, 0.5, 1, -1, 1 } }) do
        local t = Tex()
        t:SetSize(r, r)
        t:SetPoint(d[1], frame, d[1], d[6] * ins, d[7] * ins)
        t:SetTexture(TEX .. "UICorner.tga")
        t:SetTexCoord(d[2], d[3], d[4], d[5])
    end
    local mid = Tex()
    mid:SetColorTexture(1, 1, 1, 1)
    mid:SetPoint("TOPLEFT", frame, "TOPLEFT", ins + r, -ins)
    mid:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -ins - r, ins)
    local left = Tex()
    left:SetColorTexture(1, 1, 1, 1)
    left:SetPoint("TOPLEFT", frame, "TOPLEFT", ins, -ins - r)
    left:SetPoint("BOTTOMRIGHT", frame, "BOTTOMLEFT", ins + r, ins + r)
    local right = Tex()
    right:SetColorTexture(1, 1, 1, 1)
    right:SetPoint("TOPLEFT", frame, "TOPRIGHT", -ins - r, -ins - r)
    right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -ins, ins + r)
    function o:SetColor(cr, cg, cb, ca)
        for _, t in ipairs(self.parts) do t:SetVertexColor(cr, cg, cb, ca or 1) end
    end
    function o:SetShown(on)
        for _, t in ipairs(self.parts) do t:SetShown(on) end
    end
    return o
end

function UI.Bordered(frame, r, host, sub)
    local edge = UI.Shape(frame, r, "BACKGROUND", (sub or -4), 0, host)
    local fill = UI.Shape(frame, r - 1, "BACKGROUND", (sub or -4) + 1, 1, host)
    edge:SetColor(UI.EDGE, UI.EDGE, UI.EDGE + 0.02, 1)
    fill:SetColor(UI.INNER[1], UI.INNER[2], UI.INNER[3], UI.INNER[4])
    return edge, fill
end

function UI.Glow(frame, r, layer, sub)
    local g = { parts = {} }
    local function Tex(file)
        local t = frame:CreateTexture(nil, layer or "BACKGROUND", nil, sub or 0)
        t:SetTexture(TEX .. file)
        NoSnap(t)
        g.parts[#g.parts + 1] = t
        return t
    end
    for _, d in ipairs({
        { "BOTTOMRIGHT", "TOPLEFT", r, -r, 0, 1, 0, 1 },
        { "BOTTOMLEFT", "TOPRIGHT", -r, -r, 1, 0, 0, 1 },
        { "TOPRIGHT", "BOTTOMLEFT", r, r, 0, 1, 1, 0 },
        { "TOPLEFT", "BOTTOMRIGHT", -r, r, 1, 0, 1, 0 },
    }) do
        local t = Tex("UIGlowCorner.tga")
        t:SetSize(r * 2, r * 2)
        t:SetPoint(d[1], frame, d[2], d[3], d[4])
        t:SetTexCoord(d[5], d[6], d[7], d[8])
    end
    local top = Tex("UIGlowEdge.tga")
    top:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", r, 0)
    top:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", -r, 0)
    top:SetHeight(r)
    local bottom = Tex("UIGlowEdge.tga")
    bottom:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", r, 0)
    bottom:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", -r, 0)
    bottom:SetHeight(r)
    bottom:SetTexCoord(0, 1, 1, 0)
    local left = Tex("UIGlowEdge.tga")
    left:SetPoint("TOPRIGHT", frame, "TOPLEFT", 0, -r)
    left:SetPoint("BOTTOMRIGHT", frame, "BOTTOMLEFT", 0, r)
    left:SetWidth(r)
    left:SetTexCoord(0, 0, 1, 0, 0, 1, 1, 1)
    local right = Tex("UIGlowEdge.tga")
    right:SetPoint("TOPLEFT", frame, "TOPRIGHT", 0, -r)
    right:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", 0, r)
    right:SetWidth(r)
    right:SetTexCoord(0, 1, 1, 1, 0, 0, 1, 0)
    function g:SetColor(cr, cg, cb, mult)
        for _, t in ipairs(self.parts) do t:SetVertexColor(cr, cg, cb, math.min(1, 0.55 * (mult or 1))) end
    end
    function g:SetShown(on)
        for _, t in ipairs(self.parts) do t:SetShown(on) end
    end
    g:SetColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3], 1)
    return g
end

function UI.Window(frame, savedScale)
    frame:SetScale(math.max(0.8, math.min(1.3, (tonumber(savedScale) or UI.SCALE * 100) / 100)))
    if frame.SetBackdrop then frame:SetBackdrop(nil) end
    UI.Shape(frame, 12, "BACKGROUND", -8, 0):SetColor(UI.WINDOW[1], UI.WINDOW[2], UI.WINDOW[3], UI.WINDOW[4])
    UI.Outline(frame, 12, "BORDER", -8):SetColor(1, 1, 1, 0.12)
end

function UI.SavePos(root, db)
    local scale, left, top = root:GetScale(), root:GetLeft(), root:GetTop()
    if not (left and top and scale) then return end
    db.panelPos = { left * scale, top * scale }
end

function UI.RestorePos(root, db)
    local pos = db.panelPos
    if type(pos) ~= "table" or not pos[1] or not pos[2] then return false end
    local scale = root:GetScale()
    root:ClearAllPoints()
    root:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", pos[1] / scale, pos[2] / scale)
    return true
end

function UI.DefaultPos(root)
    local ratio = UIParent:GetEffectiveScale() / root:GetEffectiveScale()
    local half = UIParent:GetHeight() / 2
    local lines = math.floor(half / UI.GRID)
    local fromTop = half - math.max(0, lines - 1) * UI.GRID
    root:ClearAllPoints()
    root:SetPoint("TOP", UIParent, "TOP", 0, -fromTop * ratio)
end

function UI.Placement(root, db)
    root:SetMovable(true)
    root:SetClampedToScreen(true)
    root:EnableMouse(true)
    root:RegisterForDrag("LeftButton")
    root:SetScript("OnDragStart", root.StartMoving)
    root:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        UI.SavePos(self, db)
    end)
    root:HookScript("OnHide", function(self) UI.SavePos(self, db) end)
    local placed = false
    root:HookScript("OnShow", function(self)
        if placed then return end
        placed = true
        if not UI.RestorePos(self, db) then UI.DefaultPos(self) end
    end)
end

function UI.ResizeGrip(root, db, onDone)
    local grip = CreateFrame("Button", nil, root)
    grip:SetSize(14, 14)
    grip:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", -2, 2)
    grip:SetFrameLevel(root:GetFrameLevel() + 20)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    UI.Tip(grip, "Drag sideways to make the window bigger or smaller, and up or down to make it taller or shorter.")
    local minHeight, maxHeight = UI.MIN_HEIGHT, UI.MAX_HEIGHT
    if type(db.panelHeight) == "number" then root:SetHeight(math.max(minHeight, math.min(maxHeight, db.panelHeight))) end
    grip:SetScript("OnMouseDown", function(self)
        local ui = UIParent:GetEffectiveScale()
        local scale = root:GetScale()
        local left, top = root:GetLeft() * scale, root:GetTop() * scale
        local cx, cy = GetCursorPosition()
        cx, cy = cx / ui, cy / ui
        local startWidth = root:GetWidth() * scale
        local startScreenHeight = root:GetHeight() * scale
        root:ClearAllPoints()
        root:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left / scale, top / scale)
        self:SetScript("OnUpdate", function()
            local x, y = GetCursorPosition()
            x, y = x / ui, y / ui
            local wanted = math.max(0.8, math.min(1.3, (startWidth + (x - cx)) / root:GetWidth()))
            root:SetScale(wanted)
            root:SetHeight(math.max(minHeight, math.min(maxHeight, (startScreenHeight + (cy - y)) / wanted)))
            root:ClearAllPoints()
            root:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left / wanted, top / wanted)
        end)
    end)
    grip:SetScript("OnMouseUp", function(self)
        self:SetScript("OnUpdate", nil)
        local scale = root:GetScale()
        local left, top = root:GetLeft() * scale, root:GetTop() * scale
        db.panelHeight = math.floor(root:GetHeight() + 0.5)
        db.panelScale = math.floor(scale * 100 / 5 + 0.5) * 5
        local final = db.panelScale / 100
        root:SetScale(final)
        root:ClearAllPoints()
        root:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left / final, top / final)
        UI.SavePos(root, db)
        if onDone then onDone() end
    end)
    return grip
end

function UI.Panel(frame, r)
    if frame.SetBackdrop then frame:SetBackdrop(nil) end
    UI.Shape(frame, r or 8, "BACKGROUND", -8, 0):SetColor(0.24, 0.24, 0.27, 0.9)
    UI.Shape(frame, (r or 8) - 1, "BACKGROUND", -7, 1):SetColor(0.05, 0.05, 0.055, 0.95)
end

function UI.GlassBox(frame, r, alpha)
    local s = UI.Shape(frame, r or 8, "BACKGROUND", -6, 0)
    s:SetColor(1, 1, 1, alpha or UI.TINT)
    return s
end

function UI.GlassCard(frame, r)
    local fill = UI.Shape(frame, r or 8, "BACKGROUND", -2, 0)
    fill:SetColor(1, 1, 1, 0.05)
    local edge = UI.Outline(frame, r or 8, "BORDER", -2)
    edge:SetColor(1, 1, 1, 0.08)
    return fill, edge
end

function UI.FadeLine(parent, anchorPoint, x, y, width, alpha)
    local half = width / 2
    local a = parent:CreateTexture(nil, "ARTWORK")
    a:SetColorTexture(1, 1, 1, 1)
    a:SetPoint(anchorPoint, parent, anchorPoint, x, y)
    a:SetWidth(half)
    UI.PixelLine(a)
    local b = parent:CreateTexture(nil, "ARTWORK")
    b:SetColorTexture(1, 1, 1, 1)
    b:SetPoint("LEFT", a, "RIGHT", 0, 0)
    b:SetWidth(half)
    UI.PixelLine(b)
    local peak = alpha or 0.14
    if CreateColor and a.SetGradient then
        pcall(a.SetGradient, a, "HORIZONTAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, peak))
        pcall(b.SetGradient, b, "HORIZONTAL", CreateColor(1, 1, 1, peak), CreateColor(1, 1, 1, 0))
    else
        a:SetVertexColor(1, 1, 1, peak)
        b:SetVertexColor(1, 1, 1, peak)
    end
    return a, b
end

function UI.SoftLine(parent, p1, rel1, x1, y1, p2, rel2, x2, y2)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetColorTexture(1, 1, 1, 0.07)
    t:SetPoint(p1, rel1, p1, x1, y1)
    t:SetPoint(p2, rel2, p2, x2, y2)
    UI.PixelLine(t)
    return t
end

function UI.Heading(parent, text, anchor, yOff, xOff)
    local h = parent:CreateFontString(nil, "ARTWORK", UI.HeaderFont())
    h:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", xOff or 0, yOff or -20)
    h:SetText(text)
    h:SetJustifyV("TOP")
    local th = h.GetStringHeight and h:GetStringHeight()
    h:SetHeight(((type(th) == "number" and th > 0) and th or 16) + 8)
    return h
end

function UI.SectionLine(parent, heading, width)
    local line = parent:CreateTexture(nil, "BORDER", nil, -7)
    NoSnap(line)
    line:SetColorTexture(0.45, 0.45, 0.5, 0.55)
    line:SetPoint("TOPLEFT", heading, "TOPLEFT", 0, 9)
    line:SetWidth((width or 650) - 10)
    line:SetHeight(1)
    return line
end

function UI.RightColumn(parent)
    local top = CreateFrame("Frame", nil, parent)
    top:SetSize(1, 1)
    top:SetPoint("TOPLEFT", parent, "TOPLEFT", UI.RIGHT_COLUMN, 4)
    return top
end

local function Fader(btn, low)
    local function Fade() btn:SetAlpha(btn:IsEnabled() and 1 or low) end
    if hooksecurefunc then
        hooksecurefunc(btn, "Enable", Fade)
        hooksecurefunc(btn, "Disable", Fade)
        hooksecurefunc(btn, "SetEnabled", Fade)
    end
    Fade()
end

function UI.SkinButton(btn)
    if rawget(btn, "elvaSkinned") then return end
    btn.elvaSkinned = true
    for _, k in ipairs({ "Left", "Middle", "Right" }) do
        local t = btn[k]
        if type(t) == "table" and t.SetAlpha then t:SetAlpha(0) end
    end
    for _, get in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture", "GetHighlightTexture" }) do
        local t = btn[get] and btn[get](btn)
        if t then t:SetAlpha(0) end
    end
    local edge = UI.Bordered(btn, 4)
    local function Paint(hover)
        local v = hover and UI.EDGE_HOVER or UI.EDGE
        edge:SetColor(v, v, v + 0.02, 1)
    end
    Paint(false)
    btn:HookScript("OnEnter", function() Paint(true) end)
    btn:HookScript("OnLeave", function() Paint(false) end)
    Fader(btn, 0.45)
end

function UI.IconButton(btn, file, flip)
    for _, get in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture", "GetHighlightTexture" }) do
        local t = btn[get] and btn[get](btn)
        if t then t:SetAlpha(0) end
    end
    for _, region in ipairs({ btn:GetRegions() }) do
        if region.GetObjectType and region:GetObjectType() == "Texture" then region:SetAlpha(0) end
    end
    local edge = UI.Bordered(btn, 4)
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(TEX .. file)
    icon:SetSize(16, 16)
    icon:SetPoint("CENTER", btn, "CENTER", 0, 0)
    if flip then icon:SetTexCoord(0, 1, 1, 0) end
    local function Paint(hover)
        local v = hover and UI.EDGE_HOVER or UI.EDGE
        edge:SetColor(v, v, v + 0.02, 1)
        local c = hover and 1 or 0.7
        icon:SetVertexColor(c, c, c + 0.02, 1)
    end
    Paint(false)
    btn:HookScript("OnEnter", function() Paint(true) end)
    btn:HookScript("OnLeave", function() Paint(false) end)
    Fader(btn, 0.4)
    return icon
end

function UI.CloseButton(parent, onClick)
    local close = CreateFrame("Button", nil, parent)
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -12, -12)
    UI.IconButton(close, "UIClose.tga")
    close:SetScript("OnClick", onClick or function() parent:Hide() end)
    return close
end

function UI.StripIcon(strip, file, slot, title, text, onClick)
    local btn = CreateFrame("Button", nil, strip)
    btn:SetSize(22, 22)
    btn:SetPoint("RIGHT", strip, "RIGHT", -4 - (slot or 0) * 26, 0)
    btn:SetFrameLevel(strip:GetFrameLevel() + 5)
    UI.IconButton(btn, file)
    btn:SetScript("OnClick", onClick)
    btn:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText(title, 1, 1, 1)
        if text then GameTooltip:AddLine(text, nil, nil, nil, true) end
        GameTooltip:Show()
    end)
    btn:HookScript("OnLeave", GameTooltip_Hide)
    return btn
end

function UI.ResetIcon(strip, onClick)
    return UI.StripIcon(strip, "UIReset.tga", 0, "Reset this tab", "Puts only the settings on this tab back to their defaults. Other tabs and bars aren't touched.", onClick)
end

function UI.UndoIcon(strip, onClick, hasReset)
    return UI.StripIcon(strip, "UIUndo.tga", hasReset and 1 or 0, "Undo", "Takes back your last change. Click again to go further back.", onClick)
end

function UI.SkinCheck(cb, boxSide)
    cb:SetSize(26, 26)
    local box = CreateFrame("Frame", nil, cb)
    box:SetSize(20, 20)
    box:SetPoint(boxSide or "LEFT", cb, boxSide or "LEFT", 0, 0)
    box:EnableMouse(false)
    for _, get in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture" }) do
        local t = cb[get] and cb[get](cb)
        if t then t:SetAlpha(0) end
    end
    UI.Shape(box, 4, "BACKGROUND", 0, 0, cb):SetColor(UI.BOX_EDGE, UI.BOX_EDGE, UI.BOX_EDGE + 0.03, 1)
    UI.Shape(box, 3, "BACKGROUND", 1, 1, cb):SetColor(0.1, 0.1, 0.11, 1)
    for _, get in ipairs({ "GetCheckedTexture", "GetDisabledCheckedTexture" }) do
        local t = cb[get] and cb[get](cb)
        if t then
            t:ClearAllPoints()
            t:SetSize(24, 24)
            t:SetPoint("CENTER", box, "CENTER", 1, 1)
        end
    end
    local hl = cb.GetHighlightTexture and cb:GetHighlightTexture()
    if hl then
        hl:ClearAllPoints()
        hl:SetAllPoints(box)
        hl:SetColorTexture(1, 1, 1, 0.08)
    end
    local text = cb.Text or cb.text
    if text and boxSide ~= "RIGHT" then
        text:ClearAllPoints()
        text:SetPoint("LEFT", box, "RIGHT", 8, 0)
    end
    return box
end

function UI.CheckTip(cb, title, text, whyOff)
    cb:SetScript("OnEnter", function(self)
        local reason = whyOff and not self:IsEnabled() and whyOff()
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(title, 1, 1, 1)
        if text then GameTooltip:AddLine(text, nil, nil, nil, true) end
        if reason then GameTooltip:AddLine(reason, 1, 0.82, 0, true) end
        GameTooltip:Show()
    end)
    cb:SetScript("OnLeave", GameTooltip_Hide)
end

function UI.Swatch(btn, size)
    btn:SetSize(size or 18, size or 18)
    btn.edge = UI.Shape(btn, 4, "BACKGROUND", 0, 0)
    btn.edge:SetColor(UI.BOX_EDGE, UI.BOX_EDGE, UI.BOX_EDGE + 0.03, 1)
    btn.fill = UI.Shape(btn, 3, "BACKGROUND", 1, 1)
    function btn:SetColor(r, g, b, a)
        a = a or 1
        self.fill:SetColor(0.12 * (1 - a) + r * a, 0.12 * (1 - a) + g * a, 0.12 * (1 - a) + b * a, 1)
    end
    return btn
end

function UI.SkinSlider(slider, host)
    if slider.SetBackdrop then slider:SetBackdrop(nil) end
    for _, region in ipairs({ slider:GetRegions() }) do
        if region.GetObjectType and region:GetObjectType() == "Texture" and region ~= slider:GetThumbTexture() then region:SetAlpha(0) end
    end
    slider:SetHeight(17)
    slider:SetHitRectInsets(0, 0, -10, -10)
    local track = CreateFrame("Frame", nil, host or slider:GetParent())
    track:SetPoint("LEFT", slider, "LEFT", 0, 0)
    track:SetPoint("RIGHT", slider, "RIGHT", 0, 0)
    track:SetHeight(6)
    UI.Shape(track, 3, "BACKGROUND", 0, 0, slider):SetColor(0.17, 0.17, 0.18, 1)
    slider:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
    local thumb = slider:GetThumbTexture()
    if thumb then
        thumb:SetSize(8, 14)
        thumb:SetVertexColor(0.73, 0.73, 0.75, 1)
        slider:HookScript("OnEnter", function() thumb:SetVertexColor(0.92, 0.92, 0.94, 1) end)
        slider:HookScript("OnLeave", function() thumb:SetVertexColor(0.73, 0.73, 0.75, 1) end)
    end
    return track
end

function UI.DragQueue(slider, commit)
    local d = UI.dragDriver
    if not d then
        d = CreateFrame("Frame")
        d:SetScript("OnUpdate", function(self)
            local sl = self.slider
            if sl and sl.pendingV ~= nil and self.commit then
                local v = sl.pendingV
                sl.pendingV = nil
                self.commit(v)
            end
            if not (sl and sl.dragging) then self:Hide() end
        end)
        UI.dragDriver = d
    end
    d.slider = slider
    d.commit = commit
    d:Show()
end

function UI.SkinScrollBar(scroll)
    local sb = scroll.ScrollBar
    if type(sb) ~= "table" then return end
    local name = sb.GetName and sb:GetName() or ""
    local up = sb.ScrollUpButton or sb.Back or _G[name .. "ScrollUpButton"]
    local down = sb.ScrollDownButton or sb.Forward or _G[name .. "ScrollDownButton"]
    if type(up) == "table" and up.GetRegions then
        up:SetSize(18, 18)
        UI.IconButton(up, "UIArrow.tga")
    end
    if type(down) == "table" and down.GetRegions then
        down:SetSize(18, 18)
        UI.IconButton(down, "UIArrow.tga", true)
    end
    local thumb = sb.GetThumbTexture and sb:GetThumbTexture()
    if thumb then
        thumb:SetColorTexture(0.35, 0.35, 0.37, 1)
        thumb:SetWidth(6)
        thumb:SetHeight(28)
    end
end

function UI.NavMarker(item, color)
    local bar = item:CreateTexture(nil, "ARTWORK")
    bar:SetColorTexture(1, 1, 1, 1)
    bar:SetPoint("TOPLEFT", item, "TOPLEFT", 0, -1)
    bar:SetPoint("BOTTOMLEFT", item, "BOTTOMLEFT", 0, 1)
    bar:SetWidth(4)
    if color then
        bar:SetVertexColor(color[1], color[2], color[3], 1)
    elseif not (CreateColor and pcall(bar.SetGradient, bar, "VERTICAL", CreateColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3], 1), CreateColor(UI.PINK[1], UI.PINK[2], UI.PINK[3], 1))) then
        bar:SetVertexColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3], 1)
    end
    bar:Hide()
    return bar
end

function UI.Card(frame, r)
    r = r or 6
    local c = {}
    c.edge = UI.Shape(frame, r, "BACKGROUND", -2, 0)
    c.fill = UI.Shape(frame, r - 1, "BACKGROUND", -1, 1)
    c.glow = UI.Glow(frame, r, "BACKGROUND", -3)
    function c:SetPicked(on)
        if on then
            self.edge:SetColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3], 1)
            self.fill:SetColor(0.035, 0.12, 0.14, 1)
        else
            self.edge:SetColor(1, 1, 1, 0)
            self.fill:SetColor(1, 1, 1, UI.TINT)
        end
        self.glow:SetShown(on and true or false)
    end
    c:SetPicked(false)
    return c
end

function UI.PreviewBox(frame, r)
    local fill = UI.Shape(frame, r or 8, "BACKGROUND", -2, 0)
    fill:SetColor(UI.PREVIEW_BG[1], UI.PREVIEW_BG[2], UI.PREVIEW_BG[3], UI.PREVIEW_BG[4])
    local sheen = UI.Shape(frame, r or 8, "BACKGROUND", -1, 0)
    for i, part in ipairs(sheen.parts) do
        if i <= 2 then
            part:SetVertexColor(1, 1, 1, 0.05)
        elseif i <= 4 then
            part:SetVertexColor(1, 1, 1, 0)
        else
            part:SetVertexColor(1, 1, 1, 0.025)
            if CreateColor then pcall(part.SetGradient, part, "VERTICAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, 0.05)) end
        end
    end
    return fill
end

function UI.PreviewControls(box, db, onToggle, onPickBg)
    local label = box:CreateFontString(nil, "ARTWORK", UI.Font("GameFontDisableSmall", UI.SIZES.preview))
    label:SetPoint("TOPLEFT", box, "TOPLEFT", 6, -4)
    label:SetText(db.previewHidden and "Preview hidden" or "Preview")
    local eye = CreateFrame("Button", nil, box)
    eye:SetSize(20, 18)
    eye:SetPoint("TOPRIGHT", box, "TOPRIGHT", -4, -2)
    UI.IconButton(eye, "UIEye.tga")
    eye:SetAlpha(db.previewHidden and 0.6 or 1)
    eye:SetScript("OnClick", function()
        db.previewHidden = not db.previewHidden or nil
        label:SetText(db.previewHidden and "Preview hidden" or "Preview")
        eye:SetAlpha(db.previewHidden and 0.6 or 1)
        if onToggle then onToggle(db.previewHidden and true or false) end
    end)
    eye:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(db.previewHidden and "Show preview" or "Hide preview", 1, 1, 1)
        GameTooltip:Show()
    end)
    eye:HookScript("OnLeave", GameTooltip_Hide)
    local swatch = UI.Swatch(CreateFrame("Button", nil, box))
    swatch:SetPoint("RIGHT", eye, "LEFT", -8, 0)
    local c = type(db.previewBg) == "table" and db.previewBg or UI.PREVIEW_BG
    swatch:SetColor(c[1], c[2], c[3], c[4])
    local swatchLabel = box:CreateFontString(nil, "ARTWORK", UI.Font("GameFontDisableSmall", UI.SIZES.preview))
    swatchLabel:SetPoint("RIGHT", swatch, "LEFT", -4, 0)
    swatchLabel:SetText("Background")
    swatch:SetScript("OnClick", function() if onPickBg then onPickBg(swatch) end end)
    UI.Tip(swatch, "Pick a color to see how things look against it.")
    return label, eye, swatch
end

function UI.SkinDropdown(box)
    if box.SetBackdrop then box:SetBackdrop(nil) end
    local edge = UI.Shape(box, 4, "BACKGROUND", -6, 0)
    local fill = UI.Shape(box, 3, "BACKGROUND", -5, 1)
    local function Paint()
        if rawget(box, "open") then
            edge:SetColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3], 0.9)
            fill:SetColor(0.04, 0.13, 0.15, 0.97)
        elseif rawget(box, "hover") then
            edge:SetColor(0.4, 0.4, 0.42, 1)
            fill:SetColor(0.12, 0.12, 0.13, 0.97)
        else
            edge:SetColor(0.3, 0.3, 0.32, 1)
            fill:SetColor(0.06, 0.06, 0.065, 0.97)
        end
    end
    box:HookScript("OnEnter", function() box.hover = true Paint() end)
    box:HookScript("OnLeave", function() box.hover = false Paint() end)
    Paint()
    return Paint
end

function UI.SkinInput(input)
    if input.SetBackdrop then input:SetBackdrop(nil) end
    UI.Shape(input, 3, "BACKGROUND", -6, 0):SetColor(0.3, 0.3, 0.32, 1)
    UI.Shape(input, 2, "BACKGROUND", -5, 1):SetColor(0.06, 0.06, 0.065, 0.97)
end

function UI.SideMenu(nav)
    UI.GlassBox(nav, 12, 0.04)
end

function UI.MenuHeader(holder, text)
    local line = holder:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(1, 1, 1, 0.07)
    line:SetPoint("TOPLEFT", holder, "TOPLEFT", 4, -2)
    line:SetPoint("TOPRIGHT", holder, "TOPRIGHT", -4, -2)
    UI.PixelLine(line)
    local label = holder:CreateFontString(nil, "ARTWORK", UI.Font("GameFontNormal", UI.SIZES.menuHeader))
    label:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 8, 2)
    label:SetText(text)
    return label
end

function UI.MenuItem(item, color)
    item.text = item.text or item:CreateFontString(nil, "ARTWORK", UI.Font("GameFontNormalSmall", UI.SIZES.menuItem))
    item.text:ClearAllPoints()
    item.text:SetPoint("LEFT", item, "LEFT", UI.MENU_X, 0)
    item.pageColor = color
    item.marker = UI.NavMarker(item, color)
    local slide = { x = UI.MENU_X, driver = CreateFrame("Frame", nil, item) }
    local function Slide(want)
        if slide.want == want then return end
        slide.want = want
        slide.driver:SetScript("OnUpdate", function(self, elapsed)
            local step = elapsed * 60
            local x = slide.x
            if math.abs(want - x) <= step then x = want else x = x + (want > x and step or -step) end
            slide.x = x
            item.text:ClearAllPoints()
            item.text:SetPoint("LEFT", item, "LEFT", x, 0)
            if x == want then self:SetScript("OnUpdate", nil) end
        end)
    end
    local function Paint()
        local active = item.marker:IsShown()
        local hover = item.hover and not active
        Slide(hover and (UI.MENU_X + UI.MENU_NUDGE) or UI.MENU_X)
        if active or hover then item.text:SetTextColor(1, 1, 1) else item.text:SetTextColor(0.92, 0.92, 0.92) end
    end
    function item:SetActive(on)
        self.marker:SetShown(on and true or false)
        Paint()
    end
    item:HookScript("OnEnter", function(self) self.hover = true Paint() end)
    item:HookScript("OnLeave", function(self) self.hover = false Paint() end)
    item:SetActive(false)
end

function UI.TabStrip(strip)
    if strip.SetBackdrop then strip:SetBackdrop(nil) end
    local bg = strip:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(strip)
    bg:SetColorTexture(1, 1, 1, 0.03)
    local line = strip:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(1, 1, 1, 0.07)
    line:SetPoint("BOTTOMLEFT", strip, "BOTTOMLEFT", 4, 0)
    line:SetPoint("BOTTOMRIGHT", strip, "BOTTOMRIGHT", -4, 0)
    UI.PixelLine(line)
end

function UI.Tab(tab, color)
    color = color or UI.TEAL
    if not tab.text then
        tab.text = tab:CreateFontString(nil, "ARTWORK", UI.Font("GameFontNormalSmall", UI.SIZES.tab))
        tab.text:SetPoint("CENTER", 0, 1)
    end
    tab.underline = tab:CreateTexture(nil, "OVERLAY")
    tab.underline:SetColorTexture(color[1], color[2], color[3], 1)
    tab.underline:SetHeight(2)
    tab.underline:SetPoint("BOTTOMLEFT", tab, "BOTTOMLEFT", 0, 0)
    tab.underline:SetPoint("BOTTOMRIGHT", tab, "BOTTOMRIGHT", 0, 0)
    local hl = tab:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(tab)
    hl:SetColorTexture(1, 1, 1, 0.06)
    function tab:SetLabel(text)
        self.text:SetText(text)
        self:SetSize(math.max(self.text:GetStringWidth() + 40, 76), 28)
    end
    function tab:SetActive(on)
        self.underline:SetShown(on and true or false)
        if on then self.text:SetTextColor(color[1], color[2], color[3]) else self.text:SetTextColor(0.8, 0.8, 0.8) end
    end
    tab:SetActive(false)
end

UI.TAB_LABELS = { Look = "Style", Background = "Bar", ["Size & Border"] = "Bar", Extras = "Options", General = "Options", Sparkles = "Effects", Text = "Text/Icon" }

function UI.TabLabel(name, noIcon)
    if name == "Text" and noIcon then return "Text" end
    return UI.TAB_LABELS[name] or name
end

function UI.ChoiceCard(card, title, desc)
    card:SetSize(UI.CARD_W, UI.CARD_H)
    local c = UI.Card(card)
    c.title = card:CreateFontString(nil, "ARTWORK", UI.Font("GameFontNormal", UI.SIZES.check))
    c.title:SetPoint("TOPLEFT", card, "TOPLEFT", 10, -9)
    c.title:SetText(title)
    c.desc = card:CreateFontString(nil, "ARTWORK", UI.Font("GameFontHighlightSmall", UI.SIZES.value))
    c.desc:SetPoint("TOPLEFT", c.title, "BOTTOMLEFT", 0, -5)
    c.desc:SetPoint("RIGHT", card, "RIGHT", -10, 0)
    c.desc:SetJustifyH("LEFT")
    c.desc:SetJustifyV("TOP")
    c.desc:SetText(desc or "")
    local base = c.SetPicked
    function c:SetPicked(on)
        self.picked = on and true or false
        base(self, on)
        if on then self.title:SetTextColor(UI.TEAL[1], UI.TEAL[2], UI.TEAL[3]) else self.title:SetTextColor(UI.GOLD[1], UI.GOLD[2], UI.GOLD[3]) end
    end
    card:HookScript("OnEnter", function() if not c.picked then c.fill:SetColor(1, 1, 1, 0.09) end end)
    card:HookScript("OnLeave", function() if not c.picked then c.fill:SetColor(1, 1, 1, UI.TINT) end end)
    c:SetPicked(false)
    return c
end

function UI.Header(root, title, description, slash)
    local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    local version = GetMeta and GetMeta(addonName, "Version") or ""
    local head = root:CreateFontString(nil, "ARTWORK", UI.Font("GameFontNormal", UI.SIZES.title))
    head:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -16)
    head:SetText(title)
    local info = root:CreateFontString(nil, "ARTWORK", UI.Font("GameFontHighlightSmall", UI.SIZES.info))
    info:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -10)
    info:SetJustifyH("LEFT")
    info:SetText("|cffffd100Version|r " .. tostring(version))
    local desc = root:CreateFontString(nil, "ARTWORK", UI.Font("GameFontHighlight", UI.SIZES.description))
    desc:SetPoint("TOPLEFT", info, "BOTTOMLEFT", 0, -12)
    desc:SetJustifyH("LEFT")
    desc:SetText(description or "")
    local hint = root:CreateFontString(nil, "ARTWORK", UI.Font("GameFontDisableSmall", UI.SIZES.hint))
    hint:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -8)
    hint:SetText("|cff" .. UI.TEAL_HEX .. slash .. "|r opens these options")
    return head, info, desc, hint
end

function UI.PlaceMovePanel(panel)
    panel:ClearAllPoints()
    panel:SetPoint("CENTER", UIParent, "CENTER", 0, UIParent:GetHeight() * UI.MOVE_PANEL_Y)
end

function UI.CopyBox(parent, url, anchor, width)
    local box = CreateFrame("EditBox", nil, parent)
    box:SetSize(width or 380, 22)
    box:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -10)
    box:SetFontObject(UI.Font("GameFontHighlightSmall", UI.SIZES.check))
    box:SetTextInsets(8, 8, 0, 0)
    box:SetAutoFocus(false)
    UI.SkinInput(box)
    box:SetText(url)
    box:SetCursorPosition(0)
    box:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    box:SetScript("OnMouseUp", function(self) self:SetFocus() self:HighlightText() end)
    box:SetScript("OnTextChanged", function(self, user) if user then self:SetText(url) self:HighlightText() end end)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local hint = parent:CreateFontString(nil, "ARTWORK", UI.Font("GameFontDisableSmall", UI.SIZES.note))
    hint:SetPoint("LEFT", box, "RIGHT", 12, 0)
    hint:SetText("Click, then Ctrl+C to copy")
    return box, hint
end

function UI.AboutPage(parent, anchor, info)
    local function Line(a, text, y)
        local d = parent:CreateFontString(nil, "ARTWORK", UI.Font("GameFontHighlightSmall", UI.SIZES.check))
        d:SetPoint("TOPLEFT", a, "BOTTOMLEFT", 0, y or -4)
        d:SetWidth(info.width or 620)
        d:SetJustifyH("LEFT")
        d:SetTextColor(0.92, 0.92, 0.92)
        d:SetText(text)
        return d
    end
    local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    local version = info.version or (GetMeta and GetMeta(addonName, "Version")) or ""
    local last = UI.Heading(parent, "About", anchor, -6)
    last = Line(last, "|cffffd100Version|r  " .. tostring(version))
    last = Line(last, "|cffffd100Author|r  |cff" .. UI.TEAL_HEX .. (info.author or "Elva") .. "|r")
    if info.commands then
        last = UI.Heading(parent, "Slash commands", last, -18)
        for i, c in ipairs(info.commands) do
            local cmd = Line(last, "|cff" .. UI.TEAL_HEX .. c[1] .. "|r", i == 1 and -6 or -8)
            cmd:SetWidth(110)
            local what = parent:CreateFontString(nil, "ARTWORK", UI.Font("GameFontHighlightSmall", UI.SIZES.check))
            what:SetPoint("TOPLEFT", cmd, "TOPLEFT", 120, 0)
            what:SetJustifyH("LEFT")
            what:SetTextColor(0.92, 0.92, 0.92)
            what:SetText(c[2])
            last = cmd
        end
    end
    if info.fonts ~= false then
        last = UI.Heading(parent, "Fonts", last, -18)
        last = Line(last, "Every bundled font is free to use under the SIL Open Font License. The license files are in the Licenses folder.")
    end
    last = UI.Heading(parent, "Feedback", last, -18)
    last = Line(last, "Found a bug or have a request? Leave a comment on the CurseForge page.")
    if info.url then last = UI.CopyBox(parent, info.url, last) end
    return last
end

function UI.Tip(frame, text)
    if frame.EnableMouse and frame.IsMouseEnabled and not frame:IsMouseEnabled() then frame:EnableMouse(true) end
    frame:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(text, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", GameTooltip_Hide)
end

function UI.SkinAll(frame)
    if not frame or not frame.GetChildren then return end
    if frame.GetObjectType then
        local kind = frame:GetObjectType()
        if kind == "Button" and type(frame.Left) == "table" and type(frame.Right) == "table" then UI.SkinButton(frame) end
    end
    for _, child in ipairs({ frame:GetChildren() }) do UI.SkinAll(child) end
end

function UI.AddonsPanel(title, description, open)
    local blizz = CreateFrame("Frame")
    blizz.name = title
    local head = blizz:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
    head:SetPoint("TOPLEFT", blizz, "TOPLEFT", 16, -16)
    head:SetText(title)
    local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    local version = GetMeta and GetMeta(addonName, "Version") or ""
    local info = blizz:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    info:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -6)
    info:SetText("|cffffd100Version|r " .. tostring(version))
    local note = blizz:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    note:SetPoint("TOPLEFT", info, "BOTTOMLEFT", 0, -12)
    note:SetText(description or (title .. " has its own options window."))
    local button = CreateFrame("Button", nil, blizz, "UIPanelButtonTemplate")
    button:SetSize(180, 24)
    button:SetPoint("TOPLEFT", note, "BOTTOMLEFT", 0, -12)
    button:SetText("Open options")
    button:SetScript("OnClick", function()
        if not (InCombatLockdown and InCombatLockdown()) then
            if SettingsPanel and SettingsPanel:IsShown() then
                if SettingsPanel.Close then pcall(SettingsPanel.Close, SettingsPanel, true) elseif HideUIPanel then HideUIPanel(SettingsPanel) end
            end
            if InterfaceOptionsFrame and InterfaceOptionsFrame:IsShown() and HideUIPanel then HideUIPanel(InterfaceOptionsFrame) end
        end
        if open then open() end
    end)
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        Settings.RegisterAddOnCategory(Settings.RegisterCanvasLayoutCategory(blizz, title))
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(blizz)
    end
    return blizz
end
