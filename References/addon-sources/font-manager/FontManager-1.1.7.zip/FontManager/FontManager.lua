local ADDON_NAME, ns = ...
local UI = ns.ElvaUI
local own = setmetatable({}, { __mode = "k" })
local building = false
local FONT_DIR = "Interface\\AddOns\\" .. ADDON_NAME .. "\\Fonts\\"

local SECTIONS = {
    { key = "general", label = "General" },
    { key = "chat",    label = "Chat and tooltips" },
    { key = "combat",  label = "Characters and combat" },
    { key = "quests",  label = "Quests" },
    { key = "world",   label = "World and messages" },
}
local CATEGORIES = {
    { section = "general", key = "ui",       label = "General UI",  desc = "Menus, frames, buttons and everything else" },
    { section = "chat", key = "chat",     label = "Chat",        desc = "Chat windows and chat bubbles" },
    { section = "chat", key = "tooltips", label = "Tooltips",    desc = "Item, spell and unit tooltips" },
    { section = "combat", key = "names",    label = "Names",       desc = "Nameplates and names above heads. Names above heads change after a relog.", tag = "(relog)" },
    { section = "combat", key = "combat",   label = "Combat text", desc = "Floating damage and healing. Changes after a relog.", tag = "(relog)" },
    { section = "combat", key = "unitframes", label = "Unit frames",       desc = "Names, levels, and health and power numbers on player, target, focus and party frames. Names change after a reload. Health and power numbers change straight away.", tag = "(reload)" },
    { section = "combat", key = "actionbars", label = "Action bars",       desc = "Keybinds and stack counts on buttons. Also affects item counts in bags." },
    { section = "quests", key = "quests",     label = "Quests and NPCs",   desc = "Quest log, quest text and NPC chat windows" },
    { section = "quests", key = "tracker",    label = "Quest tracker",     desc = "Objectives listed at the side of the screen" },
    { section = "world", key = "zone",       label = "Zone text",         desc = "Zone and subzone names shown when entering an area" },
    { section = "world", key = "errors",     label = "Error messages",    desc = "Red messages such as \"Not enough mana\"" },
    { section = "world", key = "books",      label = "Books and letters", desc = "Mail, books and other readable items" },
}

local CATEGORY_OBJECTS = {
    names    = { "SystemFont_NamePlate", "SystemFont_NamePlateFixed", "SystemFont_LargeNamePlate",
                 "SystemFont_LargeNamePlateFixed", "SystemFont_NamePlateCastBar" },
    combat   = { "CombatTextFont", "CombatTextFontOutline" },
    tooltips = { "GameTooltipHeader", "GameTooltipHeaderText", "GameTooltipText", "GameTooltipTextSmall", "Tooltip_Med", "Tooltip_Small" },
    chat     = { "ChatFontNormal", "ChatFontSmall", "ChatBubbleFont" },
    quests   = { "QuestFont", "QuestFont_Large", "QuestFont_Huge", "QuestFont_Super_Huge", "QuestFont_Shadow_Small",
                 "QuestFont_Shadow_Huge", "QuestFont_Enormous", "QuestFontNormalSmall", "QuestFontHighlight",
                 "QuestFontLeft", "QuestTitleFont", "QuestTitleFontBlackShadow" },
    tracker  = { "ObjectiveFont", "ObjectiveTrackerHeaderFont", "ObjectiveTrackerLineFont" },
    unitframes = { "TextStatusBarText", "TextStatusBarTextLarge" },
    actionbars = { "NumberFontNormal", "NumberFontNormalSmall", "NumberFontNormalSmallGray", "NumberFontNormalLarge" },
    zone     = { "ZoneTextFont", "SubZoneTextFont", "PVPInfoTextFont" },
    errors   = { "ErrorFont" },
    books    = { "MailTextFontNormal", "InvoiceTextFontNormal", "InvoiceTextFontSmall", "ItemTextFontNormal" },
}

local GLOBAL_KEYS = {
    STANDARD_TEXT_FONT = "ui",
    UNIT_NAME_FONT     = "names",
    NAMEPLATE_FONT     = "names",
    DAMAGE_TEXT_FONT   = "combat",
}

local originalGlobals = {}
local wroteGlobal = {}
for key in pairs(GLOBAL_KEYS) do originalGlobals[key] = _G[key] end

local PREVIEW_DEFAULT = {
    ui = originalGlobals.STANDARD_TEXT_FONT,
    names = originalGlobals.UNIT_NAME_FONT,
    combat = originalGlobals.DAMAGE_TEXT_FONT,
    tooltips = originalGlobals.STANDARD_TEXT_FONT,
    chat = originalGlobals.STANDARD_TEXT_FONT,
}

local BUILTIN_FONTS = {
    { name = "Friz Quadrata", path = "Fonts\\FRIZQT__.TTF" },
    { name = "Arial Narrow",                path = "Fonts\\ARIALN.TTF" },
    { name = "Morpheus",                    path = "Fonts\\MORPHEUS.TTF" },
    { name = "Skurri",                      path = "Fonts\\SKURRI.TTF" },
}

local db
local root
local charKey
local originalPaths = {}
local baseSize = {}
local lastSize = {}
local SIZE_STEPS = { 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5 }
local originalFlags = {}
local OUTLINE_OPTIONS = {
    { value = "DEFAULT", name = "Default" },
    { value = "NONE", name = "None" },
    { value = "OUTLINE", name = "Outline" },
    { value = "THICKOUTLINE", name = "Thick outline" },
}
local SHADOW_OPTIONS = {
    { value = "DEFAULT", name = "Default" },
    { value = "NONE", name = "None" },
    { value = "SHADOW", name = "Shadow" },
}
local originalShadow = {}
local NO_LOCK = {}
local LOCKED = {
    names = { size = true, outline = true, shadow = true, note = "The game doesn't let addons change the size, outline or shadow of player names." },
    combat = { outline = true, shadow = true, note = "The game doesn't let addons change the outline or shadow of floating combat text." },
}

local normFlagsCache = {}

local function NormFlags(flags)
    if type(flags) ~= "string" or flags == "" then return "" end
    local cached = normFlagsCache[flags]
    if cached then return cached end
    local parts = {}
    for part in flags:upper():gmatch("[^,%s]+") do parts[#parts + 1] = part end
    table.sort(parts)
    cached = table.concat(parts, ",")
    normFlagsCache[flags] = cached
    return cached
end

local ACCENT = { 0x24 / 255, 0xe3 / 255, 0xd3 / 255 }
local ACCENT_HEX = "24e3d3"

local PROFILE_FIELDS = { "enabled", "fonts", "sizes", "outlines", "shadows", "excluded", "allFont", "allEnabled",
    "fontFile", "worldTextScaleOriginal" }

local DEFAULT_EXCLUDED = { ElvaCastBar = true }

local function AddonInstalled(name)
    local getInfo = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
    if not getInfo then return false end
    local ok, found = pcall(getInfo, name)
    return ok and type(found) == "string"
end

local exclusionsActive = false

local function RecountExclusions(profile)
    exclusionsActive = false
    for _, value in pairs(profile.excluded) do
        if value == true then
            exclusionsActive = true
            return
        end
    end
end

local function PrepareProfile(profile)
    if profile.enabled == nil then profile.enabled = true end
    profile.fonts = profile.fonts or {}
    profile.sizes = profile.sizes or {}
    profile.outlines = profile.outlines or {}
    profile.shadows = profile.shadows or {}
    profile.excluded = profile.excluded or {}
    for name in pairs(DEFAULT_EXCLUDED) do
        if profile.excluded[name] == nil and AddonInstalled(name) then profile.excluded[name] = true end
    end
    RecountExclusions(profile)
    profile.sizes.names = nil
    if profile.worldTextScaleOriginal ~= nil then
        if root and root.worldTextScaleOriginal == nil then root.worldTextScaleOriginal = profile.worldTextScaleOriginal end
        profile.worldTextScaleOriginal = nil
    end
    if profile.fontFile then
        profile.fonts.ui = profile.fonts.ui or ("Interface\\AddOns\\" .. ADDON_NAME .. "\\Fonts\\" .. profile.fontFile)
        profile.fontFile = nil
    end
    return profile
end

local function CopyTable(source)
    local copy = {}
    for key, value in pairs(source) do
        copy[key] = type(value) == "table" and CopyTable(value) or value
    end
    return copy
end

local function Print(msg)
    print("|cff" .. ACCENT_HEX .. "Font Manager|r: " .. msg)
end

local inOwnCall = false
local appliedPath = setmetatable({}, { __mode = "k" })

local pathKeyCache = {}

local function PathKey(path)
    if type(path) == "string" then
        local key = pathKeyCache[path]
        if not key then
            key = path:lower():gsub("/", "\\")
            pathKeyCache[path] = key
        end
        return key
    end
    return tostring(path)
end

local NON_ROMAN = { koKR = true, zhCN = true, zhTW = true, ruRU = true }
local romanLocale = not NON_ROMAN[(GetLocale and GetLocale()) or "enUS"]

local function RomanMember(fo)
    if not romanLocale or type(fo) ~= "table" or not fo.GetFontObjectForAlphabet then return end
    local ok, member = pcall(fo.GetFontObjectForAlphabet, fo, "roman")
    if ok and type(member) == "table" and member ~= fo and member.SetFont then return member end
end

local function IsFontObject(obj)
    local ok, kind = pcall(obj.GetObjectType, obj)
    return ok and kind == "Font"
end

local function Reattach(obj, path, size, flags)
    if own[obj] or not obj.GetFontObject or not obj.SetFontObject then return false end
    local okFo, fo = pcall(obj.GetFontObject, obj)
    if not okFo or type(fo) ~= "table" or not RomanMember(fo) then return false end
    local okFont, foPath, foSize, foFlags = pcall(fo.GetFont, fo)
    if not okFont or type(foPath) ~= "string" or type(path) ~= "string" or PathKey(foPath) ~= PathKey(path) then return false end
    if type(foSize) ~= "number" or math.abs(foSize - size) > 0.05 or NormFlags(foFlags) ~= NormFlags(flags) then return false end
    local okColor, r, g, b, a = pcall(obj.GetTextColor, obj)
    local okOff, x, y = pcall(obj.GetShadowOffset, obj)
    local okShadow, sr, sg, sb, sa = pcall(obj.GetShadowColor, obj)
    if not pcall(obj.SetFontObject, obj, fo) then return false end
    if okColor and r then pcall(obj.SetTextColor, obj, r, g, b, a) end
    if okOff and x then pcall(obj.SetShadowOffset, obj, x, y) end
    if okShadow and sr then pcall(obj.SetShadowColor, obj, sr, sg, sb, sa) end
    return true
end

local alphabetMembers = setmetatable({}, { __mode = "k" })
local MEMBER_ALPHABETS = { "korean", "simplifiedchinese", "traditionalchinese", "russian" }

local function NoteMembers(fo)
    if not RomanMember(fo) then return end
    for _, alphabet in ipairs(MEMBER_ALPHABETS) do
        local ok, member = pcall(fo.GetFontObjectForAlphabet, fo, alphabet)
        if ok and type(member) == "table" and member ~= fo then alphabetMembers[member] = true end
    end
end

local function FamilyLinked(fs)
    if not romanLocale or not fs.GetFontObject then return false end
    local ok, fo = pcall(fs.GetFontObject, fs)
    if not ok or RomanMember(fo) == nil then return false end
    local okA, pathA, sizeA = pcall(fs.GetFont, fs)
    local okB, pathB, sizeB = pcall(fo.GetFont, fo)
    if not (okA and okB) or type(pathA) ~= "string" or type(pathB) ~= "string" then return false end
    return PathKey(pathA) == PathKey(pathB) and type(sizeA) == "number" and type(sizeB) == "number" and math.abs(sizeA - sizeB) < 0.05
end

local function Relink(fs, fo)
    if not RomanMember(fo) then return false end
    local wasInOwnCall = inOwnCall
    inOwnCall = true
    local okColor, r, g, b, a = pcall(fs.GetTextColor, fs)
    local ok = pcall(fs.SetFontObject, fs, fo)
    if ok and okColor and r then pcall(fs.SetTextColor, fs, r, g, b, a) end
    inOwnCall = wasInOwnCall
    return ok
end

local function SafeSetFont(obj, path, size, flags, record)
    local wasInOwnCall = inOwnCall
    inOwnCall = true
    local ok, result
    local member = not own[obj] and IsFontObject(obj) and RomanMember(obj)
    if member then
        local okA, _, sizeA = pcall(obj.GetFont, obj)
        local okB, _, sizeB = pcall(member.GetFont, member)
        if not (okA and okB and type(sizeA) == "number" and type(sizeB) == "number" and math.abs(sizeA - sizeB) < 0.05) then member = nil end
    end
    if member then
        ok, result = pcall(member.SetFont, member, path, size, flags or "")
    else
        local okRe, done = pcall(Reattach, obj, path, size, flags or "")
        if okRe and done then
            ok, result = true, true
        else
            ok, result = pcall(obj.SetFont, obj, path, size, flags or "")
        end
    end
    inOwnCall = wasInOwnCall
    if ok and result ~= false then
        if record then appliedPath[obj] = path end
        return true
    end
    return false
end

local tester = CreateFont(ADDON_NAME .. "Tester")
own[tester] = true
local loadCache = {}
local function FontLoads(path)
    if not path then return false end
    local key = PathKey(path)
    if loadCache[key] == nil then
        local loaded = SafeSetFont(tester, path, 12, "")
        if loaded then
            local okGet, got = pcall(tester.GetFont, tester)
            if okGet and type(got) == "string" and type(path) == "string" then loaded = PathKey(got) == key end
        end
        loadCache[key] = loaded
    end
    return loadCache[key]
end

local fontListCache
local function FMName(name)
    return name .. " (FM)"
end

local function Trim(text)
    return (tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function TidyName(file)
    local base = tostring(file or ""):gsub("%.%w+$", ""):gsub("[_%-]+", " ")
    base = base:gsub("(%l)(%u)", "%1 %2")
    base = base:gsub("(%a)([%w']*)", function(first, rest) return first:upper() .. rest end)
    base = Trim(base:gsub("%s+", " "))
    if base == "" then return tostring(file or "") end
    return base
end

local function UserFontName(file)
    local names = root and root.userFontNames
    local custom = names and names[tostring(file):lower()]
    if type(custom) == "string" and custom ~= "" then return custom end
    return (tostring(file):gsub("%.%w+$", ""))
end

local function GetFontList()
    if fontListCache then return fontListCache end
    local list, seen = {}, {}
    local function add(name, path, trusted)
        local k = PathKey(path)
        if not seen[k] and (trusted or FontLoads(path)) then
            seen[k] = true
            list[#list + 1] = { name = name, path = path }
        end
    end

    for _, f in ipairs(BUILTIN_FONTS) do add(f.name, f.path) end

    local extra = {}
    for _, f in ipairs(FontManager_Files or {}) do
        extra[#extra + 1] = { name = FMName(f.name or f.file), path = FONT_DIR .. f.file }
    end
    for _, file in ipairs(root.userFonts) do
        extra[#extra + 1] = { name = UserFontName(file), path = FONT_DIR .. file }
    end

    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if LSM then
        for _, name in ipairs(LSM:List("font")) do
            local path = LSM:Fetch("font", name, true)
            if path then extra[#extra + 1] = { name = name, path = path, trusted = true } end
        end
    end
    table.sort(extra, function(a, b) return a.name:lower() < b.name:lower() end)
    for _, f in ipairs(extra) do add(f.name, f.path, f.trusted) end

    fontListCache = list
    return list
end

local function ResolveRaw(cat)
    if db.allEnabled then
        local v = db.allFont
        if v and v ~= "DEFAULT" and v ~= "INHERIT" and FontLoads(v) then return v end
        return nil
    end
    local v = db.fonts[cat]
    if cat ~= "ui" and (v == nil or v == "INHERIT") then v = db.fonts.ui end
    if v == nil or v == "DEFAULT" or v == "INHERIT" or not FontLoads(v) then return nil end
    return v
end

local function Resolve(cat)
    if not db.enabled then return nil end
    return ResolveRaw(cat)
end

local function NameFor(cat, v)
    if cat ~= "ui" and (v == nil or v == "INHERIT") then return "Same as General UI" end
    if v == nil or v == "DEFAULT" then return "Game default" end
    for _, f in ipairs(GetFontList()) do
        if PathKey(f.path) == PathKey(v) then return f.name end
    end
    return (v:match("([^\\/]+)$") or v) .. " (missing)"
end

local UNIT_FRAME_TEXT = {
    "PlayerName", "PlayerLevelText", "PetName",
    "TargetFrame.TargetFrameContent.TargetFrameContentMain.Name",
    "TargetFrame.TargetFrameContent.TargetFrameContentMain.LevelText",
    "FocusFrame.TargetFrameContent.TargetFrameContentMain.Name",
    "FocusFrame.TargetFrameContent.TargetFrameContentMain.LevelText",
    "TargetFrame.name", "TargetFrame.levelText", "FocusFrame.name", "FocusFrame.levelText",
    "TargetFrameTextureFrameName", "TargetFrameTextureFrameLevelText",
    "FocusFrameTextureFrameName", "FocusFrameTextureFrameLevelText",
    "TargetFrameToT.Name", "TargetFrameToT.name", "TargetFrameToTTextureFrameName",
    "FocusFrameToT.Name", "FocusFrameToT.name", "FocusFrameToTTextureFrameName",
}
for i = 1, 4 do
    UNIT_FRAME_TEXT[#UNIT_FRAME_TEXT + 1] = "PartyMemberFrame" .. i .. "Name"
    UNIT_FRAME_TEXT[#UNIT_FRAME_TEXT + 1] = "PartyFrame.Member" .. i .. ".name"
    UNIT_FRAME_TEXT[#UNIT_FRAME_TEXT + 1] = "PartyFrame.Member" .. i .. ".Name"
end

local unitFramePaths = {}
for _, path in ipairs(UNIT_FRAME_TEXT) do
    local parts = {}
    for part in path:gmatch("[^%.]+") do parts[#parts + 1] = part end
    unitFramePaths[#unitFramePaths + 1] = parts
end

local function Walk(parts)
    local current = _G[parts[1]]
    for i = 2, #parts do
        if type(current) ~= "table" then return nil end
        current = current[parts[i]]
    end
    return current
end

local function FindByPath(parts)
    local ok, result = pcall(Walk, parts)
    if ok and type(result) == "table" and result.GetObjectType then
        local okType, objectType = pcall(result.GetObjectType, result)
        if okType and objectType == "FontString" then return result end
    end
end

local unitFrameList = {}
local unitFrameCount = -1

local function UnitFrameTexts()
    local found = 0
    for _, parts in ipairs(unitFramePaths) do
        if FindByPath(parts) then found = found + 1 end
    end
    if found ~= unitFrameCount then
        unitFrameCount = found
        unitFrameList = {}
        for _, parts in ipairs(unitFramePaths) do
            local fs = FindByPath(parts)
            if fs then unitFrameList[#unitFrameList + 1] = fs end
        end
    end
    return unitFrameList
end

local function PlateName(plate)
    if type(plate) ~= "table" then return end
    local ok, forbidden = pcall(plate.IsForbidden, plate)
    if not ok or forbidden then return end
    local frame = plate.UnitFrame
    local fs = type(frame) == "table" and frame.name
    if type(fs) ~= "table" or not fs.GetFont then return end
    local okFs, fsForbidden = pcall(fs.IsForbidden, fs)
    if not okFs or fsForbidden then return end
    return fs
end

local function ForEachPlateName(fn)
    if not (C_NamePlate and C_NamePlate.GetNamePlates) then return end
    local ok, plates = pcall(C_NamePlate.GetNamePlates)
    if not ok or type(plates) ~= "table" then return end
    for _, plate in ipairs(plates) do
        local fs = PlateName(plate)
        if fs then fn(fs) end
    end
end

local TOOLTIP_FRAMES = { "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "EmbeddedItemTooltip" }

local function TooltipUsable(tt)
    if type(tt) ~= "table" then return false end
    local ok, forbidden = pcall(tt.IsForbidden, tt)
    return ok and not forbidden
end

local function ForEachLineOf(name, fn)
    for i = 1, 60 do
        local left = _G[name .. "TextLeft" .. i]
        if type(left) ~= "table" then return end
        fn(left, i)
        local right = _G[name .. "TextRight" .. i]
        if type(right) == "table" then fn(right, i) end
    end
end

local function ForEachTooltipLine(fn)
    for _, name in ipairs(TOOLTIP_FRAMES) do
        if TooltipUsable(_G[name]) then ForEachLineOf(name, fn) end
    end
end

local function TypeOf(obj)
    return obj.GetObjectType and obj:GetObjectType()
end

local seenTargets = {}
local visitFn

local function Visit(obj)
    if type(obj) == "table" and not seenTargets[obj] and not own[obj] and obj.GetFont and obj.SetFont then
        if obj.IsForbidden and obj:IsForbidden() then return end
        seenTargets[obj] = true
        visitFn(obj)
    end
end

local function VisitUnlinked(fs)
    if not FamilyLinked(fs) then Visit(fs) end
end

local function ForEachFontTarget(fn)
    for k in pairs(seenTargets) do seenTargets[k] = nil end
    visitFn = fn
    local visit = Visit

    if GetFonts then
        local list = GetFonts()
        for _, entry in ipairs(list) do
            local obj = type(entry) == "string" and _G[entry] or entry
            if type(obj) == "table" then NoteMembers(obj) end
        end
        for _, entry in ipairs(list) do
            local obj = type(entry) == "string" and _G[entry] or entry
            if not alphabetMembers[obj] then visit(obj) end
        end
    else
        for _, obj in pairs(_G) do
            if type(obj) == "table" then
                local ok, t = pcall(TypeOf, obj)
                if ok and t == "Font" then visit(obj) end
            end
        end
    end
    for _, names in pairs(CATEGORY_OBJECTS) do
        for _, n in ipairs(names) do
            local obj = _G[n]
            if type(obj) == "table" and not alphabetMembers[obj] then visit(obj) end
        end
    end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do visit(_G["ChatFrame" .. i]) end
    for _, fs in ipairs(UnitFrameTexts()) do visit(fs) end
    ForEachPlateName(VisitUnlinked)
    ForEachTooltipLine(VisitUnlinked)
end

local function SamePath(a, b)
    if a == b then return true end
    if a == nil or b == nil then return false end
    return PathKey(a) == PathKey(b)
end

local function HasFont(obj, target, current)
    if SamePath(target, current) then return true end
    if type(current) ~= "string" and appliedPath[obj] ~= nil then
        return SamePath(appliedPath[obj], target)
    end
    return false
end

local ownerOf = setmetatable({}, { __mode = "k" })

local function HasExclusions()
    return exclusionsActive
end

local function AddonFromPath(text)
    if type(text) ~= "string" then return end
    for name in text:gmatch("[Aa][Dd][Dd][Oo][Nn][Ss][/\\]([^/\\%]%s\"]+)[/\\]") do
        if name ~= ADDON_NAME and not name:find("^Blizzard_") then return name end
    end
end

local function CallerAddon()
    local ok, stack = pcall(debugstack, 3, 30, 0)
    if not ok or type(stack) ~= "string" then return end
    for line in stack:gmatch("[^\n]+") do
        if not line:lower():find("[/\\]libs?[/\\]") then
            local name = AddonFromPath(line)
            if name then return name end
        end
    end
end

local function CallMethod(obj, method)
    local fn = obj[method]
    if not fn then return nil end
    local ok, result = pcall(fn, obj)
    if ok then return result end
end

local function DetectOwner(obj)
    local owner = AddonFromPath(CallMethod(obj, "GetSourceLocation"))
    if owner then return owner end
    local current, depth = obj, 0
    while current and depth < 20 do
        local name = CallMethod(current, "GetName")
        if type(name) == "string" then
            for excluded, value in pairs(db.excluded) do
                if value == true and name:sub(1, #excluded):lower() == excluded:lower() then return excluded end
            end
        end
        current = CallMethod(current, "GetParent")
        depth = depth + 1
    end
    return false
end

local addonInfo
local addonParent

local function LoadAddonInfo()
    if addonInfo then return end
    addonInfo, addonParent = {}, {}
    local getNum = (C_AddOns and C_AddOns.GetNumAddOns) or GetNumAddOns
    local getInfo = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
    local getDeps = (C_AddOns and C_AddOns.GetAddOnDependencies) or GetAddOnDependencies
    local isLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local function Loaded(key)
        local ok, loadedOrLoading, loaded = pcall(isLoaded, key)
        return ok and (loaded or loadedOrLoading) and true or false
    end
    local okNum, count = pcall(getNum)
    local names = {}
    for i = 1, (okNum and count or 0) do
        local ok, name, addonTitle = pcall(getInfo, i)
        if ok and type(name) == "string" and name ~= ADDON_NAME and not name:find("^Blizzard_") then
            local deps = {}
            if getDeps then
                local okDeps = { pcall(getDeps, i) }
                if okDeps[1] then
                    for d = 2, #okDeps do
                        if type(okDeps[d]) == "string" then deps[#deps + 1] = okDeps[d] end
                    end
                end
            end
            addonInfo[name] = {
                name = name,
                title = (type(addonTitle) == "string" and addonTitle ~= "") and addonTitle or name,
                loaded = Loaded(i) or Loaded(name),
                deps = deps,
            }
            names[#names + 1] = name
        end
    end
    for _, name in ipairs(names) do
        local parent
        for _, dep in ipairs(addonInfo[name].deps) do
            if addonInfo[dep] then parent = dep break end
        end
        if not parent then
            local best = 0
            for _, other in ipairs(names) do
                if other ~= name and #other > best and #name > #other
                        and name:sub(1, #other):lower() == other:lower()
                        and name:sub(#other + 1, #other + 1):find("[_%-%. ]") then
                    parent, best = other, #other
                end
            end
        end
        addonParent[name] = parent
    end
end

local function AddonRoot(name)
    LoadAddonInfo()
    local depth = 0
    while addonParent[name] and depth < 10 do
        name = addonParent[name]
        depth = depth + 1
    end
    return name
end

local function IsExcluded(obj)
    if type(obj) == "table" and rawget(obj, "IgnoreFontManager") then return true end
    if not HasExclusions() then return false end
    local owner = ownerOf[obj]
    if owner == nil then
        owner = DetectOwner(obj)
        ownerOf[obj] = owner
    end
    if not owner then return false end
    return db.excluded[owner] == true or db.excluded[AddonRoot(owner)] == true
end

local function ForgetGuessedOwners()
    for obj, owner in pairs(ownerOf) do
        if owner == false then ownerOf[obj] = nil end
    end
end

local function ApplyShadow(obj, choice)
    if not obj.GetShadowOffset or not obj.SetShadowOffset then return end
    local custom = choice == "NONE" or choice == "SHADOW"
    local o = originalShadow[obj]
    if not custom then
        if o then
            pcall(obj.SetShadowOffset, obj, o[1], o[2])
            pcall(obj.SetShadowColor, obj, o[3], o[4], o[5], o[6])
            originalShadow[obj] = nil
        end
        return
    end
    local ok, x, yOff = pcall(obj.GetShadowOffset, obj)
    if not ok then return end
    if not o then
        local okColor, r, g, b, a = pcall(obj.GetShadowColor, obj)
        originalShadow[obj] = { x or 0, yOff or 0, okColor and r or 0, okColor and g or 0, okColor and b or 0, okColor and a or 1 }
    end
    local wantX, wantY = 0, 0
    if choice == "SHADOW" then wantX, wantY = 1, -1 end
    if math.abs((x or 0) - wantX) > 0.01 or math.abs((yOff or 0) - wantY) > 0.01 then
        pcall(obj.SetShadowOffset, obj, wantX, wantY)
    end
    if choice == "SHADOW" then pcall(obj.SetShadowColor, obj, 0, 0, 0, 1) end
end

local catOf = {}
local targets = {}
local forcedCache
local replacedOriginal = setmetatable({}, { __mode = "k" })
local setFlags = setmetatable({}, { __mode = "k" })
local fights = setmetatable({}, { __mode = "k" })
local gaveUp = setmetatable({}, { __mode = "k" })
local watched = setmetatable({}, { __mode = "k" })
local applying = false
local watchCount, watchWindow = 0, 0
local OnFontChanged

local fontMetaHooked = false

local function Watch(obj)
    if watched[obj] or not hooksecurefunc then return end
    watched[obj] = true
    if fontMetaHooked and obj.GetObjectType and obj:GetObjectType() == "Font" then return end
    pcall(hooksecurefunc, obj, "SetFont", OnFontChanged)
    if obj.SetFontObject then pcall(hooksecurefunc, obj, "SetFontObject", OnFontChanged) end
    if obj.CopyFontObject then pcall(hooksecurefunc, obj, "CopyFontObject", OnFontChanged) end
end
local wipe = wipe or function(t) for k in pairs(t) do t[k] = nil end return t end

local function TrueOriginal(obj, path)
    if not forcedCache or not SamePath(path, forcedCache) then return path end
    if replacedOriginal[obj] then return replacedOriginal[obj] end
    local fo = CallMethod(obj, "GetFontObject")
    if type(fo) == "table" and fo ~= obj then
        local o = originalPaths[fo] or replacedOriginal[fo]
        if o and not SamePath(o, forcedCache) then return o end
    end
    for _, name in ipairs(CATEGORY_OBJECTS[catOf[obj] or "ui"] or {}) do
        local o = _G[name] and originalPaths[_G[name]]
        if o and not SamePath(o, forcedCache) then return o end
    end
    return originalGlobals.STANDARD_TEXT_FONT or path
end

local function MarkNamesCategory(fs)
    catOf[fs] = "names"
end

local function MarkTooltipCategory(fs)
    catOf[fs] = "tooltips"
end

local function TrackTarget(obj)
    local path, size, flags = obj:GetFont()
    if not size or size <= 0 then return false end
    local applied = appliedPath[obj]
    if originalPaths[obj] == nil or applied == nil or not HasFont(obj, applied, path) then
        originalPaths[obj] = TrueOriginal(obj, path) or false
        if setFlags[obj] == nil or NormFlags(flags) ~= setFlags[obj] then
            originalFlags[obj] = flags or ""
        end
        appliedPath[obj] = nil
        setFlags[obj] = nil
    elseif setFlags[obj] == nil or NormFlags(flags) ~= setFlags[obj] then
        originalFlags[obj] = flags or ""
        setFlags[obj] = nil
    end
    local last = lastSize[obj]
    local isFont = obj.GetObjectType and obj:GetObjectType() == "Font"
    if last == nil or (not isFont and math.abs(size - last) > 0.1) then
        baseSize[obj] = size
    end
    return true
end

local function ApplyTarget(obj, withShadow)
    local path, size, flags = obj:GetFont()
    if not size or not baseSize[obj] then return false end
    local cat = catOf[obj] or "ui"
    local excluded = IsExcluded(obj)
    local locked = LOCKED[cat] or NO_LOCK
    local active = db.enabled and not excluded and not db.allEnabled
    local scale = (active and not locked.size) and db.sizes[cat] or 1
    local outline = (active and not locked.outline) and db.outlines[cat]
    local newFlags
    if outline and outline ~= "DEFAULT" then
        newFlags = (outline == "NONE") and "" or outline
    else
        newFlags = originalFlags[obj] or flags or ""
    end
    local newSize
    local isFont = obj.GetObjectType and obj:GetObjectType() == "Font"
    if scale == 1 and lastSize[obj] == nil and isFont then
        newSize = size
    else
        newSize = baseSize[obj] * scale
        lastSize[obj] = newSize
    end
    local changed = false
    local target = (not excluded and Resolve(cat)) or originalPaths[obj] or path
    if target and newSize and (not HasFont(obj, target, path) or math.abs(newSize - (size or 0)) > 0.01
            or NormFlags(newFlags) ~= NormFlags(flags)) then
        if SafeSetFont(obj, target, newSize, newFlags, true) then
            changed = true
            setFlags[obj] = NormFlags(newFlags)
        end
    end
    if not changed and target and type(target) == "string" and SamePath(target, path) then
        appliedPath[obj] = target
    end
    if withShadow then
        local shadow = (active and not locked.shadow) and db.shadows[cat]
        ApplyShadow(obj, shadow)
    end
    return changed
end

local function CollectTarget(obj)
    if TrackTarget(obj) then
        targets[#targets + 1] = obj
        Watch(obj)
    end
end

local function ApplyFontObjects()
    for key, cat in pairs(GLOBAL_KEYS) do
        local want = Resolve(cat)
        if want then
            if _G[key] ~= want then
                _G[key] = want
                wroteGlobal[key] = want
            end
        elseif wroteGlobal[key] then
            if _G[key] == wroteGlobal[key] then _G[key] = originalGlobals[key] end
            wroteGlobal[key] = nil
        end
    end

    wipe(catOf)
    for cat, names in pairs(CATEGORY_OBJECTS) do
        for _, n in ipairs(names) do
            if _G[n] then catOf[_G[n]] = cat end
        end
    end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local cf = _G["ChatFrame" .. i]
        if cf then catOf[cf] = "chat" end
    end
    for _, fs in ipairs(UnitFrameTexts()) do catOf[fs] = "unitframes" end
    ForEachPlateName(MarkNamesCategory)
    ForEachTooltipLine(MarkTooltipCategory)

    wipe(targets)
    ForEachFontTarget(CollectTarget)

    local ordered = {}
    for _, obj in ipairs(targets) do
        if (catOf[obj] or "ui") == "ui" then ordered[#ordered + 1] = obj end
    end
    for _, obj in ipairs(targets) do
        if (catOf[obj] or "ui") ~= "ui" then ordered[#ordered + 1] = obj end
    end
    for pass = 1, 2 do
        local changed = false
        for _, obj in ipairs(ordered) do
            if ApplyTarget(obj, pass == 1) then changed = true end
        end
        if not changed then break end
    end
end

local function GetCVarSafe(name)
    local ok, v = pcall(C_CVar and C_CVar.GetCVar or GetCVar, name)
    if ok then return v end
end

local combatSizePending = false

local function SetCVarSafe(name, value)
    if InCombatLockdown and InCombatLockdown() then
        combatSizePending = true
        return
    end
    pcall(C_CVar and C_CVar.SetCVar or SetCVar, name, value)
end

local function ApplyCombatSize()
    local scale = (db.enabled and not db.allEnabled) and db.sizes.combat or 1
    if not GetCVarSafe("WorldTextScale") then return end
    if scale ~= 1 then
        if root.worldTextScaleOriginal == nil then
            root.worldTextScaleOriginal = GetCVarSafe("WorldTextScale")
        end
        if GetCVarSafe("WorldTextScale") ~= tostring(scale) then SetCVarSafe("WorldTextScale", tostring(scale)) end
    elseif root.worldTextScaleOriginal ~= nil then
        if InCombatLockdown and InCombatLockdown() then
            combatSizePending = true
            return
        end
        SetCVarSafe("WorldTextScale", root.worldTextScaleOriginal)
        root.worldTextScaleOriginal = nil
    end
end

local function ForcedFont()
    return forcedCache
end

local function UpdateForcedFont()
    forcedCache = (db and db.enabled and db.allEnabled) and Resolve("ui") or nil
end

local function Skip(obj)
    if obj == tester or own[obj] or alphabetMembers[obj] then return true end
    local isForbidden = obj.IsForbidden
    if not isForbidden then return false end
    local ok, forbidden = pcall(isForbidden, obj)
    return not ok or forbidden
end

local function ForceOne(obj, force)
    if IsExcluded(obj) or FamilyLinked(obj) then return end
    local path, size, flags = obj:GetFont()
    if not path or not size or size <= 0 or HasFont(obj, force, path) then return end
    if replacedOriginal[obj] == nil then replacedOriginal[obj] = path end
    SafeSetFont(obj, force, size, flags, appliedPath[obj] ~= nil or type(path) ~= "string")
end

local callerTried = setmetatable({}, { __mode = "k" })

local function ForceOnSetFont(obj, path, size, flags)
    if building or not forcedCache then return end
    local force = forcedCache
    if not path or Skip(obj) or HasFont(obj, force, path) then return end
    local tracked = appliedPath[obj] ~= nil
    appliedPath[obj] = nil
    if HasExclusions() then
        if not ownerOf[obj] and not callerTried[obj] then
            callerTried[obj] = true
            local caller = CallerAddon()
            if caller then ownerOf[obj] = caller end
        end
        if IsExcluded(obj) then
            replacedOriginal[obj] = nil
            return
        end
    end
    replacedOriginal[obj] = path
    SafeSetFont(obj, force, size, flags, tracked or type(path) ~= "string")
end

local function OnAnySetFont(obj, path, size, flags)
    if inOwnCall or not forcedCache then return end
    pcall(ForceOnSetFont, obj, path, size, flags)
end

local function ForceAfterFontObject(obj)
    if building or not ForcedFont() then return end
    local ok, path, size, flags = pcall(obj.GetFont, obj)
    if ok and path then ForceOnSetFont(obj, path, size, flags) end
end

local function OnAnySetFontObject(obj)
    if inOwnCall or not forcedCache then return end
    pcall(ForceAfterFontObject, obj)
end

local hooksInstalled = false
local function InstallHooks()
    if hooksInstalled then return end
    hooksInstalled = true
    local samples = {
        UIParent:CreateFontString(nil, "ARTWORK"),
        CreateFrame("EditBox", nil, UIParent),
        CreateFont(ADDON_NAME .. "HookSample"),
    }
    samples[2]:Hide()
    samples[2]:SetAutoFocus(false)
    for _, sample in ipairs(samples) do
        local mt = getmetatable(sample)
        local methods = mt and mt.__index
        if type(methods) == "table" and methods.SetFont then
            hooksecurefunc(methods, "SetFont", OnAnySetFont)
            if methods.SetFontObject then hooksecurefunc(methods, "SetFontObject", OnAnySetFontObject) end
            if methods.CopyFontObject then hooksecurefunc(methods, "CopyFontObject", OnAnySetFontObject) end
        end
    end
end

local sweepToken = 0
local sweptFont

local function SweepRegions(force, ...)
    for i = 1, select("#", ...) do
        local r = select(i, ...)
        if r.GetObjectType and r:GetObjectType() == "FontString" and not Skip(r) then
            ForceOne(r, force)
        end
    end
end

local function SweepFrameUnsafe(frame, force)
    if Skip(frame) then return end
    if frame.GetObjectType and frame:GetObjectType() == "EditBox" then
        ForceOne(frame, force)
    end
    if frame.GetNumRegions and frame:GetNumRegions() == 0 then return end
    SweepRegions(force, frame:GetRegions())
end

local function SweepFrame(frame, force)
    pcall(SweepFrameUnsafe, frame, force)
end

local function SweepExisting(force, again)
    if not again and sweptFont and SamePath(sweptFont, force) then return end
    sweepToken = sweepToken + 1
    local token = sweepToken
    local frame = EnumerateFrames()

    local function step()
        if token ~= sweepToken or not SamePath(ForcedFont(), force) then return end
        local stopAt = debugprofilestop() + 4
        while frame do
            SweepFrame(frame, force)
            local ok, nextFrame = pcall(EnumerateFrames, frame)
            frame = ok and nextFrame or nil
            if frame and debugprofilestop() > stopAt then
                C_Timer.After(0, step)
                return
            end
        end
        sweptFont = force
    end
    step()
end

local function RestoreReplaced()
    for obj, path in pairs(replacedOriginal) do
        local ok, _, size, flags = pcall(obj.GetFont, obj)
        if ok and size and size > 0 then SafeSetFont(obj, path, size, flags) end
        replacedOriginal[obj] = nil
    end
end

local function ApplyPlateNameUnsafe(fs)
    if FamilyLinked(fs) then return end
    catOf[fs] = "names"
    if TrackTarget(fs) then ApplyTarget(fs, false) end
    Watch(fs)
end

local function ApplyTooltipLine(fs, index)
    if FamilyLinked(fs) then return end
    if romanLocale then
        local fo = index == 1 and _G.GameTooltipHeaderText or _G.GameTooltipText
        if Relink(fs, fo) then
            originalPaths[fs], appliedPath[fs], baseSize[fs], lastSize[fs] = nil, nil, nil, nil
            return
        end
    end
    catOf[fs] = "tooltips"
    if TrackTarget(fs) then ApplyTarget(fs, true) end
end

local function TooltipNeedsWork()
    if not db or not db.enabled then return false end
    if db.allEnabled then return ForcedFont() ~= nil end
    return Resolve("tooltips") ~= nil or db.sizes.tooltips ~= nil or db.outlines.tooltips ~= nil or db.shadows.tooltips ~= nil
end

local function FixTooltipNow(tt)
    if applying or not TooltipNeedsWork() then return end
    local name = tt and CallMethod(tt, "GetName")
    if type(name) ~= "string" then return end
    applying = true
    pcall(ForEachLineOf, name, ApplyTooltipLine)
    applying = false
end

local pendingTips = {}
local tipFlushQueued = false

local function FlushTips()
    tipFlushQueued = false
    for tt in pairs(pendingTips) do
        pendingTips[tt] = nil
        if CallMethod(tt, "IsShown") then FixTooltipNow(tt) end
    end
end

local function OnTooltipShown(tt)
    if type(tt) ~= "table" or not TooltipNeedsWork() then return end
    FixTooltipNow(tt)
    pendingTips[tt] = true
    if not tipFlushQueued and C_Timer then
        tipFlushQueued = true
        C_Timer.After(0, FlushTips)
    end
end

local hookedTips = {}

local function HookTooltips()
    if not hooksecurefunc then return end
    for _, name in ipairs(TOOLTIP_FRAMES) do
        local tt = _G[name]
        if TooltipUsable(tt) and not hookedTips[tt] then
            hookedTips[tt] = true
            pcall(hooksecurefunc, tt, "Show", OnTooltipShown)
            pcall(tt.HookScript, tt, "OnShow", OnTooltipShown)
            for _, script in ipairs({ "OnTooltipSetUnit", "OnTooltipSetItem", "OnTooltipSetSpell" }) do
                local okHas, has = pcall(tt.HasScript, tt, script)
                if okHas and has then pcall(tt.HookScript, tt, script, OnTooltipShown) end
            end
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and TooltipDataProcessor.AllTypes and not hookedTips.processor then
        hookedTips.processor = true
        pcall(TooltipDataProcessor.AddTooltipPostCall, TooltipDataProcessor.AllTypes, function(tt)
            if hookedTips[tt] then OnTooltipShown(tt) end
        end)
    end
end

local function ApplyPlateName(fs)
    if not db or own[fs] then return end
    local was = applying
    applying = true
    pcall(ApplyPlateNameUnsafe, fs)
    applying = was
end

local function RefreshChatFrames()
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local cf = _G["ChatFrame" .. i]
        if type(cf) == "table" then
            for _, method in ipairs({ "MarkDisplayDirty", "RefreshDisplay", "RefreshLayout" }) do
                if type(cf[method]) == "function" then pcall(cf[method], cf) end
            end
        end
    end
end

local function ApplyCore(force)
    if not force then
        sweptFont = nil
        sweepToken = sweepToken + 1
        if next(replacedOriginal) then RestoreReplaced() end
    end
    ApplyFontObjects()
    RefreshChatFrames()
    if C_Timer then
        C_Timer.After(0, RefreshChatFrames)
        C_Timer.After(0.2, RefreshChatFrames)
    end
    if db.enabled and romanLocale and RomanMember(_G.GameTooltipText) then
        for _, name in ipairs(TOOLTIP_FRAMES) do
            if TooltipUsable(_G[name]) then ForEachLineOf(name, ApplyTooltipLine) end
        end
    end
    ApplyCombatSize()
end

local function Apply()
    for k in pairs(gaveUp) do gaveUp[k] = nil end
    UpdateForcedFont()
    local force = ForcedFont()

    applying = true
    local ok, err = pcall(ApplyCore, force)
    applying = false
    if not ok then error(err) end
    if force then
        InstallHooks()
        SweepExisting(force)
    end
end


local function FixChangedFont(obj, a, b)
    if HasExclusions() and not ownerOf[obj] and not callerTried[obj] and not CallMethod(obj, "GetName") then
        callerTried[obj] = true
        local caller = CallerAddon()
        if caller then ownerOf[obj] = caller end
    end
    if IsExcluded(obj) then return end
    if type(a) == "table" and a ~= obj and originalPaths[a] ~= nil and baseSize[a] then
        originalPaths[obj] = originalPaths[a]
        originalFlags[obj] = originalFlags[a]
        baseSize[obj] = baseSize[a]
        lastSize[obj] = lastSize[a]
        appliedPath[obj] = appliedPath[a]
        setFlags[obj] = setFlags[a]
    elseif type(a) == "string" and type(b) == "number" and b > 0 and baseSize[obj]
            and not (lastSize[obj] and math.abs(b - lastSize[obj]) < 0.01) then
        baseSize[obj] = b
    end
    if TrackTarget(obj) then ApplyTarget(obj, true) end
end

OnFontChanged = function(obj, a, b)
    if applying or building or inOwnCall or not db or not db.enabled or ForcedFont() then return end
    if own[obj] or gaveUp[obj] or alphabetMembers[obj] then return end
    local now = GetTime and GetTime() or 0
    if now - watchWindow > 10 then
        watchWindow, watchCount = now, 0
        for k in pairs(fights) do fights[k] = nil end
    end
    watchCount = watchCount + 1
    if watchCount > 1000 then return end
    local n = (fights[obj] or 0) + 1
    fights[obj] = n
    if n > 8 then
        gaveUp[obj] = true
        return
    end
    applying = true
    pcall(FixChangedFont, obj, a, b)
    applying = false
end

do
    local sample = hooksecurefunc and _G.GameFontNormal
    local mt = sample and getmetatable(sample)
    local methods = mt and mt.__index
    if type(methods) == "table" and methods.SetFont then
        for _, method in ipairs({ "SetFont", "SetFontObject", "CopyFontObject" }) do
            if methods[method] then pcall(hooksecurefunc, methods, method, OnFontChanged) end
        end
        fontMetaHooked = true
    end
end

local panel = {}
function panel:Refresh() end
local CheckMemory

local lsmWatched = false

local function ShareFonts()
    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if not LSM then return end
    if not lsmWatched and LSM.RegisterCallback then
        lsmWatched = true
        pcall(LSM.RegisterCallback, ns, "LibSharedMedia_Registered", function(_, mediaType)
            if mediaType == "font" then
                fontListCache = nil
                panel:Refresh()
            end
        end)
    end
    local shared = {}
    for _, f in ipairs(FontManager_Files or {}) do
        shared[#shared + 1] = { FMName(f.name or f.file), FONT_DIR .. f.file }
    end
    for _, file in ipairs(root.userFonts) do
        shared[#shared + 1] = { UserFontName(file), FONT_DIR .. file }
        if not (root.userFontNames and root.userFontNames[file:lower()]) then
            shared[#shared + 1] = { FMName(UserFontName(file)), FONT_DIR .. file }
        end
    end
    for _, entry in ipairs(shared) do
        if FontLoads(entry[2]) then pcall(LSM.Register, LSM, "font", entry[1], entry[2]) end
    end
end

local function UpdateExclusions()
    RecountExclusions(db)
    ForgetGuessedOwners()
    for obj, path in pairs(replacedOriginal) do
        if IsExcluded(obj) then
            local ok, _, size, flags = pcall(obj.GetFont, obj)
            if ok and size and size > 0 then SafeSetFont(obj, path, size, flags) end
            replacedOriginal[obj] = nil
        end
    end
    Apply()
    local force = ForcedFont()
    if force then SweepExisting(force, true) end
end


local window
local TEAL = UI.TEAL_HEX
local PINK = UI.PINK_HEX
local ARROW = "Interface\\AddOns\\" .. ADDON_NAME .. "\\Textures\\UIArrow.tga"

local SZ = UI.SIZES
SZ.menuHeader = 14
SZ.menuItem = 12

local function F(template, size)
    local name = UI.Font(template, size)
    own[_G[name]] = true
    return name
end

local function HF()
    local name = UI.HeaderFont()
    own[_G[name]] = true
    return name
end

local function OwnKitFonts()
    if not GetFonts then return end
    local prefix = ADDON_NAME .. "ElvaUI"
    for _, entry in ipairs(GetFonts()) do
        if type(entry) == "string" and entry:sub(1, #prefix) == prefix and _G[entry] then own[_G[entry]] = true end
    end
end

local function MarkOwn(frame)
    if not frame then return end
    own[frame] = true
    if frame.GetRegions then
        for _, r in ipairs({ frame:GetRegions() }) do own[r] = true end
    end
    if frame.GetChildren then
        for _, c in ipairs({ frame:GetChildren() }) do MarkOwn(c) end
    end
end

local function CurrentProfileName()
    return root.profileKeys[charKey] or "Default"
end

local function SetReplaceAll(on)
    db.allEnabled = on
    if on and not db.allFont then
        local ui = db.fonts.ui
        if ui and ui ~= "DEFAULT" and FontLoads(ui) then db.allFont = ui end
    end
    Apply()
    panel:Refresh()
    if on and not db.allFont then
        Print("pick a font under \"Replace font for all in game text\".")
    end
end

local function SwitchProfile(name)
    if not root.profiles[name] then return end
    root.profileKeys[charKey] = name
    db = PrepareProfile(root.profiles[name])
    UpdateExclusions()
    panel:Refresh()
    Print("now using the |cff" .. ACCENT_HEX .. name .. "|r profile.")
end

local function ProfileNames(skipCurrent)
    local names = {}
    for name in pairs(root.profiles) do
        if not (skipCurrent and name == CurrentProfileName()) then names[#names + 1] = name end
    end
    table.sort(names, function(a, b)
        if a == "Default" then return true end
        if b == "Default" then return false end
        return a:lower() < b:lower()
    end)
    return names
end

local function PreviewDefault(cat)
    if cat == "chat" and ChatFrame1 and originalPaths[ChatFrame1] then return originalPaths[ChatFrame1] end
    for _, name in ipairs(CATEGORY_OBJECTS[cat] or {}) do
        local obj = _G[name]
        if obj and originalPaths[obj] then return originalPaths[obj] end
    end
    return PREVIEW_DEFAULT[cat] or originalGlobals.STANDARD_TEXT_FONT
end

local function SizeLabel(scale)
    return string.format("%d%%", math.floor((scale or 1) * 100 + 0.5))
end

local function ChoiceLabel(options, value)
    for _, o in ipairs(options) do
        if o.value == (value or "DEFAULT") then return o.name end
    end
    return options[1].name
end

StaticPopupDialogs["FONTMANAGER_RESET"] = {
    text = "Reset all fonts to default?",
    button1 = YES,
    button2 = NO,
    OnAccept = function()
        db.fonts = {}
        db.sizes = {}
        db.outlines = {}
        db.shadows = {}
        db.allFont = nil
        db.allEnabled = false
        Apply()
        panel:Refresh()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["FONTMANAGER_COPY"] = {
    text = "Copy settings from %s into %s?",
    button1 = YES,
    button2 = NO,
    OnAccept = function(_, source)
        local name = CurrentProfileName()
        root.profiles[name] = PrepareProfile(CopyTable(root.profiles[source]))
        SwitchProfile(name)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["FONTMANAGER_DELETE"] = {
    text = "Delete the profile %s?",
    button1 = YES,
    button2 = NO,
    OnAccept = function(_, name)
        root.profiles[name] = nil
        for key, value in pairs(root.profileKeys) do
            if value == name then root.profileKeys[key] = "Default" end
        end
        if root.profiles[CurrentProfileName()] then panel:Refresh() else SwitchProfile("Default") end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

local reloadDialog, reloadSecure
local RELOAD_X, RELOAD_Y = -76, 86

local function DialogButton(parent, text)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(140, 24)
    b:SetText(text)
    b:SetNormalFontObject(F("GameFontNormal", SZ.button))
    b:SetHighlightFontObject(F("GameFontHighlight", SZ.button))
    b:SetDisabledFontObject(F("GameFontDisable", SZ.button))
    UI.SkinButton(b)
    return b
end

local function BuildReloadSecure()
    if reloadSecure or not reloadDialog or InCombatLockdown() then return end
    local s = CreateFrame("Button", "FontManagerReloadButton", UIParent, "SecureActionButtonTemplate")
    s:SetAttribute("type", "macro")
    s:SetAttribute("macrotext", "/reload")
    s:RegisterForClicks("AnyUp", "AnyDown")
    s:SetFrameStrata("FULLSCREEN_DIALOG")
    s:SetFrameLevel(reloadDialog:GetFrameLevel() + 20)
    s:SetSize(140, 24)
    s:SetPoint("CENTER", UIParent, "CENTER", RELOAD_X, RELOAD_Y)
    s:HookScript("OnEnter", function() reloadDialog.yes:LockHighlight() end)
    s:HookScript("OnLeave", function() reloadDialog.yes:UnlockHighlight() end)
    s:Hide()
    reloadSecure = s
end

local function BuildReloadDialog()
    if reloadDialog then return end
    local d = CreateFrame("Frame", "FontManagerReloadDialog", UIParent)
    d:SetSize(340, 124)
    d:SetPoint("CENTER", UIParent, "CENTER", 0, RELOAD_Y + 34)
    d:SetFrameStrata("FULLSCREEN_DIALOG")
    d:EnableMouse(true)
    d:Hide()
    UI.Panel(d, 10)
    local text = d:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.description))
    text:SetPoint("TOP", d, "TOP", 0, -22)
    text:SetWidth(300)
    text:SetText("Reload the interface now?")
    local note = d:CreateFontString(nil, "ARTWORK", F("GameFontHighlightSmall", SZ.note))
    note:SetPoint("TOP", text, "BOTTOM", 0, -8)
    note:SetWidth(300)
    note:SetTextColor(0.7, 0.7, 0.7)
    note:SetText("Unit frame names change after a reload.")
    d.yes = DialogButton(d, "Reload")
    d.yes:SetPoint("CENTER", d, "CENTER", RELOAD_X, -34)
    d.yes:SetScript("OnClick", function() ReloadUI() end)
    local no = DialogButton(d, CANCEL or "Cancel")
    no:SetPoint("CENTER", d, "CENTER", -RELOAD_X, -34)
    no:SetScript("OnClick", function() d:Hide() end)
    d:SetScript("OnShow", function()
        BuildReloadSecure()
        if reloadSecure and not InCombatLockdown() then
            reloadSecure:SetFrameLevel(d.yes:GetFrameLevel() + 10)
            reloadSecure:Show()
        end
    end)
    d:SetScript("OnHide", function()
        if reloadSecure and not InCombatLockdown() then reloadSecure:Hide() end
    end)
    d:RegisterEvent("PLAYER_REGEN_DISABLED")
    d:RegisterEvent("PLAYER_REGEN_ENABLED")
    d:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_REGEN_ENABLED" then BuildReloadSecure() end
        if not reloadSecure then return end
        if event == "PLAYER_REGEN_DISABLED" then
            reloadSecure:Hide()
        elseif self:IsShown() then
            reloadSecure:SetFrameLevel(self.yes:GetFrameLevel() + 10)
            reloadSecure:Show()
        end
    end)
    tinsert(UISpecialFrames, "FontManagerReloadDialog")
    reloadDialog = d
    MarkOwn(d)
end

local function AskReload()
    if not reloadDialog then
        building = true
        local ok, err = pcall(BuildReloadDialog)
        building = false
        if not ok then error(err) end
    end
    reloadDialog:Show()
end

local function Build()
    F("GameFontNormal")
    F("GameFontNormal", SZ.menuHeader)
    F("GameFontNormalSmall", SZ.menuItem)
    HF()

    local W, H = UI.WIDTH, UI.HEIGHT
    local rootFrame = CreateFrame("Frame", "FontManagerOptions", UIParent)
    window = rootFrame
    rootFrame:SetSize(W, H)
    rootFrame:SetFrameStrata("DIALOG")
    rootFrame:SetToplevel(true)
    rootFrame:Hide()
    tinsert(UISpecialFrames, "FontManagerOptions")
    UI.Window(rootFrame, root.panelScale)
    if not root.panelScale then
        local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
        if sw and sh and sw > 0 and sh > 0 then
            local fit = math.min(sw * 0.75 / W, sh * 0.85 / rootFrame:GetHeight())
            if fit < rootFrame:GetScale() then rootFrame:SetScale(math.max(0.8, fit)) end
        end
    end
    UI.Placement(rootFrame, root)
    UI.CloseButton(rootFrame)

    local menu
    local refitScrolls = {}
    UI.ResizeGrip(rootFrame, root, function()
        menu:Hide()
        for _, sc in ipairs(refitScrolls) do
            if sc.UpdateScrollChildRect then sc:UpdateScrollChildRect() end
        end
    end)

    UI.Header(rootFrame, "Font Manager", "Customize the fonts used throughout the game.", "/fm")

    UI.FadeLine(rootFrame, "TOPLEFT", 16, -106, W - 32)
    UI.FadeLine(rootFrame, "BOTTOMLEFT", 16, 44, W - 32)

    local function Button(parent, w, h, text)
        local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        b:SetSize(w, h)
        b:SetText(text)
        b:SetNormalFontObject(F("GameFontNormal", SZ.button))
        b:SetHighlightFontObject(F("GameFontHighlight", SZ.button))
        b:SetDisabledFontObject(F("GameFontDisable", SZ.button))
        UI.SkinButton(b)
        return b
    end

    local function Check(parent, text)
        local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        local box = UI.SkinCheck(cb)
        local builtIn = cb.Text or cb.text
        if builtIn then builtIn:SetText("") end
        cb.label = parent:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.check))
        cb.label:SetPoint("LEFT", box, "RIGHT", 8, 0)
        function cb:SetLabel(t)
            self.label:SetText(t or "")
            local width = math.ceil(self.label:GetStringWidth() or 0)
            self:SetHitRectInsets(0, -(width + 8), 0, 0)
        end
        cb:SetLabel(text)
        return cb
    end

    local function Input(parent, w, placeholder)
        local e = CreateFrame("EditBox", nil, parent)
        e:SetSize(w, 26)
        e:SetAutoFocus(false)
        e:SetFontObject(F("GameFontHighlight", SZ.check))
        e:SetTextInsets(8, 8, 0, 0)
        UI.SkinInput(e)
        e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        e.hint = e:CreateFontString(nil, "ARTWORK", F("GameFontDisable", SZ.check))
        e.hint:SetPoint("LEFT", 8, 0)
        e.hint:SetText(placeholder or "")
        e:HookScript("OnTextChanged", function(self) self.hint:SetShown((self:GetText() or "") == "") end)
        e:HookScript("OnEditFocusGained", function(self) self.hint:Hide() end)
        e:HookScript("OnEditFocusLost", function(self) self.hint:SetShown((self:GetText() or "") == "") end)
        return e
    end

    local function Dropdown(parent, w)
        local b = CreateFrame("Button", nil, parent)
        b:SetSize(w, 26)
        b.label = b:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.check))
        b.label:SetPoint("LEFT", 8, 0)
        b.label:SetPoint("RIGHT", -22, 0)
        b.label:SetJustifyH("LEFT")
        b.label:SetWordWrap(false)
        b.arrow = b:CreateTexture(nil, "ARTWORK")
        b.arrow:SetTexture(ARROW)
        b.arrow:SetSize(12, 12)
        b.arrow:SetPoint("RIGHT", -6, 0)
        b.arrow:SetTexCoord(0, 1, 1, 0)
        b.arrow:SetVertexColor(0.7, 0.7, 0.72)
        b.Paint = UI.SkinDropdown(b)
        function b:SetText(t) self.label:SetText(t) end
        return b
    end

    local MENU_ROWS, ROW_H, MENU_W = 14, 20, 286
    menu = CreateFrame("Frame", nil, UIParent)
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetClampedToScreen(true)
    menu:EnableMouse(true)
    menu:EnableMouseWheel(true)
    menu:Hide()
    UI.Panel(menu, 8)
    menu.buttons = {}

    menu.more = menu:CreateFontString(nil, "ARTWORK", F("GameFontDisableSmall", SZ.note))
    menu.more:SetPoint("BOTTOM", 0, 7)
    menu.more:SetText("Scroll for more")

    menu.search = Input(menu, MENU_W - 16, "Search fonts")
    menu.search:SetPoint("TOPLEFT", 8, -8)
    menu.search:SetScript("OnTextChanged", function(self)
        local text = self:GetText() or ""
        self.hint:SetShown(text == "" and not self:HasFocus())
        menu:Filter(text)
    end)
    menu.search:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        menu:Hide()
    end)
    menu.search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    menu.search:Hide()

    for i = 1, MENU_ROWS do
        local b = CreateFrame("Button", nil, menu)
        b:SetSize(MENU_W - 16, ROW_H)
        local hl = b:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints(b)
        hl:SetColorTexture(1, 1, 1, 0.08)
        b.text = b:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.check))
        b.text:SetPoint("LEFT", 6, 0)
        b.text:SetPoint("RIGHT", -22, 0)
        b.text:SetJustifyH("LEFT")
        b.text:SetWordWrap(false)
        b.check = b:CreateTexture(nil, "OVERLAY")
        b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        b.check:SetSize(16, 16)
        b.check:SetPoint("RIGHT", -4, 0)
        b:SetScript("OnClick", function(self)
            menu:Hide()
            menu.onPick(self.value)
        end)
        menu.buttons[i] = b
    end

    function menu:SetChoices(options, current, owner, searchable)
        self.allOptions = options
        self.options = options
        self.current = current
        self.owner = owner
        self.offset = 0
        self.searchable = searchable
        self.search:SetShown(searchable)
        self.search:SetText("")
        self.search:ClearFocus()
        for i, o in ipairs(options) do
            if o.value == current then self.offset = i - math.floor(MENU_ROWS / 2) break end
        end
    end

    function menu:Filter(text)
        text = (text or ""):lower()
        if text == "" then
            self.options = self.allOptions
        else
            local filtered = {}
            for _, o in ipairs(self.allOptions) do
                if o.name:lower():find(text, 1, true) then filtered[#filtered + 1] = o end
            end
            self.options = filtered
            self.offset = 0
        end
        self:Render()
    end

    function menu:Render()
        local opts = self.options
        local maxOffset = math.max(0, #opts - MENU_ROWS)
        self.offset = math.min(math.max(self.offset, 0), maxOffset)
        local top = self.searchable and -38 or -8
        for i, b in ipairs(self.buttons) do
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", 8, top - (i - 1) * ROW_H)
            local o = opts[i + self.offset]
            if o then
                b.value = o.value
                b.text:SetFontObject(F("GameFontHighlight", SZ.check))
                if o.path and not SafeSetFont(b.text, o.path, 13, "") then
                    b.text:SetFontObject(F("GameFontHighlight", SZ.check))
                end
                b.text:SetText(o.name)
                b.check:SetShown(o.value == self.current)
                b:Show()
            else
                b:Hide()
            end
        end
        local shown = math.max(math.min(#opts, MENU_ROWS), self.searchable and 1 or 0)
        self.more:SetShown(maxOffset > 0)
        self:SetSize(MENU_W, shown * ROW_H + 16 + (maxOffset > 0 and 14 or 0) + (self.searchable and 30 or 0))
    end

    function menu:Open(owner)
        self:SetScale(rootFrame:GetScale())
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", owner, "BOTTOMLEFT", 0, -2)
        self:SetFrameLevel(owner:GetFrameLevel() + 50)
        self:Show()
        self:Render()
        if rawget(owner, "Paint") then
            owner.open = true
            owner.Paint()
        end
    end

    menu:SetScript("OnHide", function(self)
        local owner = self.owner
        if owner and rawget(owner, "Paint") then
            owner.open = false
            owner.Paint()
        end
    end)

    menu:SetScript("OnMouseWheel", function(self, delta)
        self.offset = self.offset - delta * 3
        self:Render()
    end)

    pcall(menu.RegisterEvent, menu, "GLOBAL_MOUSE_DOWN")
    menu:SetScript("OnEvent", function(self)
        if self:IsShown() and not self:IsMouseOver() and not (self.owner and self.owner:IsMouseOver()) then
            self:Hide()
        end
    end)

    local function Toggle(owner)
        if menu:IsShown() and menu.owner == owner then
            menu:Hide()
            return true
        end
    end

    local function OpenFontMenu(owner, catKey)
        if Toggle(owner) then return end
        local opts = {}
        if catKey ~= "ui" and catKey ~= "all" then opts[#opts + 1] = { name = "Same as General UI", value = "INHERIT" } end
        opts[#opts + 1] = { name = "Game default", value = "DEFAULT" }
        for _, f in ipairs(GetFontList()) do
            opts[#opts + 1] = { name = f.name, value = f.path, path = f.path }
        end
        local current
        if catKey == "all" then
            current = db.allFont
        else
            current = db.fonts[catKey] or (catKey == "ui" and "DEFAULT" or "INHERIT")
        end
        menu:SetChoices(opts, current, owner, true)
        menu.onPick = function(value)
            if catKey == "all" then db.allFont = value else db.fonts[catKey] = value end
            Apply()
            panel:Refresh()
        end
        menu:Open(owner)
    end

    local function OpenChoiceMenu(owner, list, current, onPick)
        if Toggle(owner) then return end
        local opts = {}
        for _, o in ipairs(list) do opts[#opts + 1] = { name = o.name, value = o.value } end
        menu:SetChoices(opts, current, owner, false)
        menu.onPick = onPick
        menu:Open(owner)
    end

    local SIZE_CHOICES = {}
    for _, step in ipairs(SIZE_STEPS) do SIZE_CHOICES[#SIZE_CHOICES + 1] = { name = SizeLabel(step), value = step } end

    local function OpenSizeMenu(owner, catKey)
        OpenChoiceMenu(owner, SIZE_CHOICES, db.sizes[catKey] or 1, function(value)
            db.sizes[catKey] = (value ~= 1) and value or nil
            Apply()
            panel:Refresh()
        end)
    end

    local function OpenOutlineMenu(owner, catKey)
        OpenChoiceMenu(owner, OUTLINE_OPTIONS, db.outlines[catKey] or "DEFAULT", function(value)
            db.outlines[catKey] = (value ~= "DEFAULT") and value or nil
            Apply()
            panel:Refresh()
        end)
    end

    local function OpenShadowMenu(owner, catKey)
        OpenChoiceMenu(owner, SHADOW_OPTIONS, db.shadows[catKey] or "DEFAULT", function(value)
            db.shadows[catKey] = (value ~= "DEFAULT") and value or nil
            Apply()
            panel:Refresh()
        end)
    end

    local nav = CreateFrame("Frame", nil, rootFrame)
    nav:SetPoint("TOPLEFT", rootFrame, "TOPLEFT", 16, -118)
    nav:SetPoint("BOTTOMLEFT", rootFrame, "BOTTOMLEFT", 16, 56)
    nav:SetWidth(150)
    UI.SideMenu(nav)

    local content = CreateFrame("Frame", nil, rootFrame)
    content:SetPoint("TOPLEFT", nav, "TOPRIGHT", 16, 0)
    content:SetPoint("BOTTOMRIGHT", rootFrame, "BOTTOMRIGHT", -16, 56)

    local pages, items = {}, {}

    local function Select(key)
        menu:Hide()
        for k, p in pairs(pages) do p:SetShown(k == key) end
        for k, it in pairs(items) do it:SetActive(k == key) end
    end

    local NAV = {
        { header = "Options" },
        { key = "fonts", label = "Fonts" },
        { key = "addons", label = "Addons" },
        { key = "addfonts", label = "Add fonts" },
        { header = "Profiles" },
        { key = "profiles", label = "Profiles" },
        { header = "Help" },
        { key = "about", label = "About" },
    }

    local ny = -8
    for _, entry in ipairs(NAV) do
        if entry.header then
            local h = (ny < -8) and 30 or 22
            local holder = CreateFrame("Frame", nil, nav)
            holder:SetPoint("TOPLEFT", nav, "TOPLEFT", 0, ny)
            holder:SetPoint("TOPRIGHT", nav, "TOPRIGHT", 0, ny)
            holder:SetHeight(h)
            local label = UI.MenuHeader(holder, entry.header)
            label:ClearAllPoints()
            label:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 18, 2)
            ny = ny - h - 4
        else
            local it = CreateFrame("Button", nil, nav)
            it:SetPoint("TOPLEFT", nav, "TOPLEFT", 6, ny)
            it:SetPoint("TOPRIGHT", nav, "TOPRIGHT", -6, ny)
            it:SetHeight(24)
            UI.MenuItem(it)
            it.text:SetText(entry.label)
            it:SetScript("OnClick", function() Select(entry.key) end)
            items[entry.key] = it
            ny = ny - 28
        end
    end

    local profileTitle = nav:CreateFontString(nil, "ARTWORK", F("GameFontNormalSmall", SZ.profile))
    profileTitle:SetPoint("BOTTOMLEFT", nav, "BOTTOMLEFT", 18, 28)
    profileTitle:SetTextColor(0.6, 0.6, 0.6)
    profileTitle:SetText("Profile")
    local profileName = nav:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.profile))
    profileName:SetPoint("TOPLEFT", profileTitle, "BOTTOMLEFT", 0, -3)
    profileName:SetPoint("RIGHT", nav, "RIGHT", -10, 0)
    profileName:SetJustifyH("LEFT")
    profileName:SetWordWrap(false)
    profileName:SetTextColor(UI.PINK[1], UI.PINK[2], UI.PINK[3])
    local profileHit = CreateFrame("Button", nil, nav)
    profileHit:SetPoint("TOPLEFT", profileTitle, "TOPLEFT", -4, 4)
    profileHit:SetPoint("BOTTOMRIGHT", profileName, "BOTTOMRIGHT", 4, -4)
    profileHit:SetScript("OnClick", function() Select("profiles") end)

    local function NewPage(key)
        local p = CreateFrame("Frame", nil, content)
        p:SetAllPoints(content)
        p:Hide()
        pages[key] = p
        return p
    end

    local lineWidths = {}
    local function Heading(page, text, y, lineAbove, x)
        local h = page:CreateFontString(nil, "ARTWORK", HF())
        h:SetPoint("TOPLEFT", page, "TOPLEFT", x or 4, y)
        h:SetText(text)
        if lineAbove then UI.SectionLine(page, h, (lineWidths[page] or 700) - (x or 4) + 6) end
        return h
    end

    local function Text(page, text, y, template)
        local t = page:CreateFontString(nil, "ARTWORK", template and F(template, SZ.note) or F("GameFontHighlight", SZ.description))
        t:SetPoint("TOPLEFT", page, "TOPLEFT", 4, y)
        t:SetWidth((lineWidths[page] or 690) - 8)
        t:SetJustifyH("LEFT")
        t:SetText(text)
        return t, math.max(math.ceil(t:GetStringHeight() or 0), 12)
    end

    local COL = { font = 136, size = 312, outline = 384, shadow = 496, preview = 588 }
    local WID = { font = 168, size = 64, outline = 104, shadow = 84, preview = 88 }
    local rows = {}

    local function ColumnLabels(page, y)
        for _, c in ipairs({ { "Font", "font" }, { "Size", "size" }, { "Outline", "outline" }, { "Shadow", "shadow" }, { "Preview", "preview" } }) do
            local t = page:CreateFontString(nil, "ARTWORK", F("GameFontDisableSmall", SZ.note))
            t:SetPoint("TOPLEFT", page, "TOPLEFT", COL[c[2]] + 2, y)
            t:SetText(c[1])
        end
    end

    local function Row(page, cat, y)
        local row = CreateFrame("Frame", nil, page)
        row:SetPoint("TOPLEFT", page, "TOPLEFT", 0, y)
        row:SetPoint("TOPRIGHT", page, "TOPRIGHT", 0, y)
        row:SetHeight(36)
        UI.GlassBox(row, 6, 0.03)

        row.label = row:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.setting))
        row.label:SetPoint("LEFT", row, "LEFT", 10, 0)
        row.label:SetWidth(COL.font - 16)
        row.label:SetJustifyH("LEFT")
        row.label:SetWordWrap(false)
        row.label:SetText(cat.label)
        local hit = CreateFrame("Frame", nil, row)
        hit:SetPoint("TOPLEFT", row.label, "TOPLEFT", -4, 6)
        hit:SetPoint("BOTTOMRIGHT", row.label, "BOTTOMRIGHT", 4, -6)
        UI.Tip(hit, cat.desc)
        if cat.tag then
            local tag = row:CreateFontString(nil, "ARTWORK", F("GameFontNormal", SZ.note))
            tag:SetPoint("LEFT", row, "LEFT", 10 + math.ceil(row.label:GetStringWidth()) + 5, 0)
            tag:SetText(cat.tag)
        end

        row.button = Dropdown(row, WID.font)
        row.button:SetPoint("LEFT", row, "LEFT", COL.font, 0)
        row.button:SetScript("OnClick", function(self) OpenFontMenu(self, cat.key) end)

        row.size = Dropdown(row, WID.size)
        row.size:SetPoint("LEFT", row, "LEFT", COL.size, 0)
        row.size:SetScript("OnClick", function(self) OpenSizeMenu(self, cat.key) end)

        row.outline = Dropdown(row, WID.outline)
        row.outline:SetPoint("LEFT", row, "LEFT", COL.outline, 0)
        row.outline:SetScript("OnClick", function(self) OpenOutlineMenu(self, cat.key) end)

        row.shadow = Dropdown(row, WID.shadow)
        row.shadow:SetPoint("LEFT", row, "LEFT", COL.shadow, 0)
        row.shadow:SetScript("OnClick", function(self) OpenShadowMenu(self, cat.key) end)

        row.preview = row:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.setting))
        row.preview:SetPoint("LEFT", row, "LEFT", COL.preview, 0)
        row.preview:SetWidth(WID.preview)
        row.preview:SetJustifyH("LEFT")
        row.preview:SetWordWrap(false)
        row.preview:SetText("Aa Bb 123")

        row.covers = {}
        for _, key in ipairs({ "button", "size", "outline", "shadow" }) do
            local cover = CreateFrame("Frame", nil, row)
            cover:SetAllPoints(row[key])
            cover:SetFrameLevel(row[key]:GetFrameLevel() + 5)
            cover:EnableMouse(true)
            cover:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(cat.label, 1, 0.82, 0)
                GameTooltip:AddLine(self.note or "", 1, 1, 1, true)
                GameTooltip:Show()
            end)
            cover:SetScript("OnLeave", GameTooltip_Hide)
            cover:Hide()
            row.covers[key] = cover
        end

        rows[cat.key] = row
    end

    local fontsPage = NewPage("fonts")
    local fontsScroll = CreateFrame("ScrollFrame", nil, fontsPage, "UIPanelScrollFrameTemplate")
    fontsScroll:SetPoint("TOPLEFT", fontsPage, "TOPLEFT", 0, 0)
    fontsScroll:SetPoint("BOTTOMRIGHT", fontsPage, "BOTTOMRIGHT", -24, 0)
    UI.SkinScrollBar(fontsScroll)
    refitScrolls[#refitScrolls + 1] = fontsScroll
    local fc = CreateFrame("Frame", nil, fontsScroll)
    fc:SetSize(676, 10)
    lineWidths[fc] = 676
    fontsScroll:SetScrollChild(fc)
    fontsScroll:HookScript("OnVerticalScroll", function() menu:Hide() end)

    Heading(fc, "All text", -4)
    local allCheck = Check(fc, "Replace font for all in game text")
    allCheck:SetPoint("TOPLEFT", fc, "TOPLEFT", 4, -34)
    UI.CheckTip(allCheck, "Replace font for all in game text", "One font everywhere, including other addons' text. The separate font settings are ignored while this is on.", function()
        if not db.enabled then return "Font Manager is turned off. Click \"Enable Font Manager\" to change this." end
    end)
    local allButton = Dropdown(fc, 240)
    allButton:SetPoint("TOPLEFT", fc, "TOPLEFT", 4, -70)
    allButton:SetScript("OnClick", function(self) OpenFontMenu(self, "all") end)
    local allPreview = fc:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.setting))
    allPreview:SetPoint("LEFT", allButton, "RIGHT", 14, 0)
    allPreview:SetText("Aa Bb Cc 123")

    local fy = -124
    for index, section in ipairs(SECTIONS) do
        Heading(fc, section.label, fy, true)
        fy = fy - 30
        if index == 1 then
            ColumnLabels(fc, fy)
            fy = fy - 20
        end
        for _, cat in ipairs(CATEGORIES) do
            if cat.section == section.key then
                Row(fc, cat, fy)
                fy = fy - 42
            end
        end
        fy = fy - 16
    end
    local reloadNote = fc:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.description))
    reloadNote:SetPoint("TOPLEFT", fc, "TOPLEFT", 4, fy)
    reloadNote:SetWidth(660)
    reloadNote:SetJustifyH("LEFT")
    reloadNote:SetTextColor(1, 0.25, 0.25)
    reloadNote:SetText("Most text updates instantly. Reload if something looks stuck. Unit frame names need a reload. Names above heads and combat text need a relog.")
    fy = fy - math.max(math.ceil(reloadNote:GetStringHeight() or 0), 16) - 16
    fc:SetHeight(-fy)

    allCheck:SetScript("OnClick", function(self)
        SetReplaceAll(self:GetChecked() and true or false)
    end)

    local addonsPage = NewPage("addons")
    Heading(addonsPage, "Addons", -4)
    Text(addonsPage, "Untick an addon to let it keep its own fonts.", -34)
    local scroll = CreateFrame("ScrollFrame", nil, addonsPage, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", addonsPage, "TOPLEFT", 0, -60)
    scroll:SetPoint("BOTTOMRIGHT", addonsPage, "BOTTOMRIGHT", -24, 0)
    UI.SkinScrollBar(scroll)
    refitScrolls[#refitScrolls + 1] = scroll
    local list = CreateFrame("Frame", nil, scroll)
    list:SetSize(660, 10)
    scroll:SetScrollChild(list)
    local emptyText = list:CreateFontString(nil, "ARTWORK", F("GameFontDisable", SZ.note))
    emptyText:SetPoint("TOPLEFT", 6, -6)
    emptyText:SetText("No other addons are loaded.")
    emptyText:Hide()

    local addonRows = {}
    local ADDON_ROW_H = 30

    local function BuildAddonList()
        LoadAddonInfo()
        local isLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
        for name, info in pairs(addonInfo) do
            local ok, loadedOrLoading, loaded = pcall(isLoaded, name)
            info.loaded = ok and (loaded or loadedOrLoading) and true or false
            info.childLoaded = nil
        end
        local entries, children = {}, {}
        for name, info in pairs(addonInfo) do
            local top = AddonRoot(name)
            if top == name then
                entries[#entries + 1] = info
            else
                children[top] = (children[top] or 0) + 1
                if info.loaded and addonInfo[top] then addonInfo[top].childLoaded = true end
            end
        end
        for _, info in ipairs(entries) do
            info.extra = children[info.name] or 0
            info.shownLoaded = info.loaded or info.childLoaded
        end
        table.sort(entries, function(a, b)
            if a.shownLoaded ~= b.shownLoaded then return a.shownLoaded end
            return a.name:lower() < b.name:lower()
        end)

        local made = false
        building = true
        for i, info in ipairs(entries) do
            local row = addonRows[i]
            if not row then
                row = Check(list, "")
                row:SetPoint("TOPLEFT", list, "TOPLEFT", 4, -(i - 1) * ADDON_ROW_H)
                row:SetScript("OnClick", function(self)
                    if self:GetChecked() then
                        if DEFAULT_EXCLUDED[self.addon] then
                            db.excluded[self.addon] = false
                        else
                            db.excluded[self.addon] = nil
                        end
                    else
                        db.excluded[self.addon] = true
                    end
                    UpdateExclusions()
                end)
                addonRows[i] = row
                made = true
            end
            row.addon = info.name
            local text = info.title
            if info.extra > 0 then
                text = text .. " |cff808080(+" .. info.extra .. (info.extra == 1 and " plugin)|r" or " plugins)|r")
            end
            if info.shownLoaded then
                row:SetLabel(text)
                row.label:SetAlpha(1)
            else
                row:SetLabel(text .. " |cff808080(not loaded)|r")
                row.label:SetAlpha(0.6)
            end
            row:SetChecked(db.excluded[info.name] ~= true)
            row:Show()
            row.label:Show()
        end
        building = false
        for i = #entries + 1, #addonRows do
            addonRows[i]:Hide()
            addonRows[i].label:Hide()
        end
        list:SetHeight(math.max(#entries * ADDON_ROW_H, 10))
        emptyText:SetShown(#entries == 0)
        if made then MarkOwn(list) end
    end
    addonsPage:SetScript("OnShow", function()
        local ok, err = pcall(BuildAddonList)
        building = false
        if not ok then error(err) end
    end)

    local addPage = NewPage("addfonts")
    Heading(addPage, "Add your own fonts", -4)
    local ay = -34
    local STEPS = {
        "Find the font you want to use. It needs to be a .ttf file.",
        "Copy it into this folder: |cff" .. TEAL .. "Interface\\AddOns\\FontManager\\Fonts|r",
        "Close WoW completely and open it again. A /reload won't find new files.",
        "Type the file name in the first box below, for example |cff" .. TEAL .. "MyFont.ttf|r. You can type a name for it in the second box. Then click Add.",
        "Pick your font from any font menu.",
    }
    for index, step in ipairs(STEPS) do
        local _, h = Text(addPage, index .. ".  " .. step, ay)
        ay = ay - h - 8
    end
    local _, tipH = Text(addPage, "The Interface folder is inside your World of Warcraft folder, for example World of Warcraft\\_retail_\\Interface.", ay - 2, "GameFontDisableSmall")
    ay = ay - tipH - 22

    local RefreshAddedList
    local addBox = Input(addPage, 220, "MyFont.ttf")
    addBox:SetPoint("TOPLEFT", addPage, "TOPLEFT", 4, ay)
    UI.Tip(addBox, "The font's file name, exactly as it is in the Fonts folder.")
    local nameBox = Input(addPage, 200, "Display name (optional)")
    nameBox:SetPoint("LEFT", addBox, "RIGHT", 8, 0)
    UI.Tip(nameBox, "The name shown in font menus. Leave it empty to use the file name, for example font-bold becomes Font Bold.")
    local addButton = Button(addPage, 90, 24, "Add")
    addButton:SetPoint("LEFT", nameBox, "RIGHT", 8, 0)
    addButton:SetScript("OnClick", function()
        local file = Trim(addBox:GetText())
        if file == "" then return end
        if not file:find("%.%w+$") then file = file .. ".ttf" end
        local path = FONT_DIR .. file
        loadCache[PathKey(path)] = nil
        if not FontLoads(path) then
            Print("could not load |cff" .. ACCENT_HEX .. file .. "|r. Check the spelling, and fully restart WoW after adding new files.")
            return
        end
        for _, existing in ipairs(root.userFonts) do
            if existing:lower() == file:lower() then Print(file .. " is already in the list.") return end
        end
        local name = Trim(nameBox:GetText())
        if name == "" then name = TidyName(file) end
        table.insert(root.userFonts, file)
        root.userFontNames[file:lower()] = name
        fontListCache = nil
        ShareFonts()
        RefreshAddedList()
        addBox:SetText("")
        nameBox:SetText("")
        addBox:ClearFocus()
        nameBox:ClearFocus()
        Print("added |cff" .. ACCENT_HEX .. name .. "|r. Pick it from any font menu.")
        panel:Refresh()
    end)
    addBox:SetScript("OnEnterPressed", function() addButton:Click() end)
    nameBox:SetScript("OnEnterPressed", function() addButton:Click() end)

    ay = ay - 56
    Heading(addPage, "Fonts you've added", ay, true)
    local addedScroll = CreateFrame("ScrollFrame", nil, addPage, "UIPanelScrollFrameTemplate")
    addedScroll:SetPoint("TOPLEFT", addPage, "TOPLEFT", 0, ay - 28)
    addedScroll:SetPoint("BOTTOMRIGHT", addPage, "BOTTOMRIGHT", -24, 0)
    UI.SkinScrollBar(addedScroll)
    refitScrolls[#refitScrolls + 1] = addedScroll
    local addedList = CreateFrame("Frame", nil, addedScroll)
    addedList:SetSize(660, 10)
    addedScroll:SetScrollChild(addedList)
    local noneText = addedList:CreateFontString(nil, "ARTWORK", F("GameFontDisable", SZ.description))
    noneText:SetPoint("TOPLEFT", addedList, "TOPLEFT", 4, -4)
    noneText:SetText("None yet.")

    local ADDED_ROW_H = 32
    local addedRows = {}
    local renameBox = Input(addedList, 240, "New name")
    renameBox:Hide()

    local function FinishRename(save)
        local file = renameBox.file
        if save and file then
            local name = Trim(renameBox:GetText())
            if name == "" then name = TidyName(file) end
            root.userFontNames[file:lower()] = name
            fontListCache = nil
            ShareFonts()
            panel:Refresh()
            Print("renamed to |cff" .. ACCENT_HEX .. name .. "|r.")
        end
        renameBox.file = nil
        renameBox:ClearFocus()
        renameBox:Hide()
        RefreshAddedList()
    end
    renameBox:SetScript("OnEnterPressed", function() FinishRename(true) end)
    renameBox:SetScript("OnEscapePressed", function() FinishRename(false) end)

    RefreshAddedList = function()
        local made = false
        for i, file in ipairs(root.userFonts) do
            local row = addedRows[i]
            if not row then
                row = CreateFrame("Frame", nil, addedList)
                row:SetPoint("TOPLEFT", addedList, "TOPLEFT", 0, -(i - 1) * ADDED_ROW_H)
                row:SetPoint("TOPRIGHT", addedList, "TOPRIGHT", 0, -(i - 1) * ADDED_ROW_H)
                row:SetHeight(ADDED_ROW_H - 4)
                UI.GlassBox(row, 6, 0.03)
                row.name = row:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", SZ.setting))
                row.name:SetPoint("LEFT", row, "LEFT", 10, 0)
                row.name:SetWidth(240)
                row.name:SetJustifyH("LEFT")
                row.name:SetWordWrap(false)
                row.file = row:CreateFontString(nil, "ARTWORK", F("GameFontDisable", SZ.check))
                row.file:SetPoint("LEFT", row, "LEFT", 262, 0)
                row.file:SetWidth(260)
                row.file:SetJustifyH("LEFT")
                row.file:SetWordWrap(false)
                row.rename = Button(row, 90, 22, "Rename")
                row.rename:SetPoint("RIGHT", row, "RIGHT", -8, 0)
                row.rename:SetScript("OnClick", function(self)
                    local target = self:GetParent()
                    renameBox.file = target.fileName
                    renameBox:ClearAllPoints()
                    renameBox:SetPoint("LEFT", target, "LEFT", 4, 0)
                    renameBox:SetFrameLevel(target:GetFrameLevel() + 10)
                    renameBox:SetText(UserFontName(target.fileName))
                    renameBox:Show()
                    renameBox:SetFocus()
                    renameBox:HighlightText()
                end)
                UI.Tip(row.rename, "Change the name shown in font menus. Press Enter to save or Escape to cancel.")
                addedRows[i] = row
                made = true
            end
            row.fileName = file
            row.name:SetText(UserFontName(file))
            row.file:SetText(file)
            row:Show()
        end
        for i = #root.userFonts + 1, #addedRows do addedRows[i]:Hide() end
        noneText:SetShown(#root.userFonts == 0)
        addedList:SetHeight(math.max(#root.userFonts * ADDED_ROW_H, 20))
        if made then MarkOwn(addedList) end
    end
    addPage:SetScript("OnShow", RefreshAddedList)
    addPage:HookScript("OnHide", function() if renameBox:IsShown() then FinishRename(false) end end)

    local profilesPage = NewPage("profiles")
    local card = CreateFrame("Frame", nil, profilesPage)
    card:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 0, -4)
    card:SetSize(500, 58)
    UI.GlassCard(card, 8)
    UI.Tip(card, "Profiles are shared by all your characters. Each character can use a different profile.")
    local cardTitle = card:CreateFontString(nil, "ARTWORK", F("GameFontNormal", SZ.info))
    cardTitle:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -14)
    cardTitle:SetText("Current profile")
    local cardName = card:CreateFontString(nil, "ARTWORK", F("GameFontHighlight", 15))
    cardName:SetPoint("TOPLEFT", cardTitle, "BOTTOMLEFT", 0, -3)
    cardName:SetPoint("RIGHT", card, "RIGHT", -16, 0)
    cardName:SetJustifyH("LEFT")
    cardName:SetWordWrap(false)
    cardName:SetTextColor(UI.PINK[1], UI.PINK[2], UI.PINK[3])

    local RIGHT = UI.RIGHT_COLUMN
    local DW = 240
    local function Label(text, x, y)
        local t = profilesPage:CreateFontString(nil, "ARTWORK", UI.TitleFont())
        own[_G[UI.TitleFont()]] = true
        t:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", x + 4, y)
        t:SetText(text)
        return t
    end

    Heading(profilesPage, "Switch or create", -84, true)

    Label("New profile", 0, -114)
    local newProfileBox = Input(profilesPage, 220, "Type a name, press Enter")
    newProfileBox:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 4, -134)
    UI.Tip(newProfileBox, "Starts with the default settings.")
    newProfileBox:SetScript("OnEnterPressed", function()
        local name = strtrim(newProfileBox:GetText() or "")
        if name == "" then newProfileBox:ClearFocus() return end
        if root.profiles[name] then
            Print("a profile called |cff" .. ACCENT_HEX .. name .. "|r already exists.")
            return
        end
        root.profiles[name] = PrepareProfile({})
        newProfileBox:SetText("")
        newProfileBox:ClearFocus()
        SwitchProfile(name)
    end)

    Label("Switch to", RIGHT, -114)
    local profileButton = Dropdown(profilesPage, DW)
    profileButton:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", RIGHT + 4, -134)
    profileButton:SetScript("OnClick", function(self)
        local choices = {}
        for _, name in ipairs(ProfileNames(false)) do choices[#choices + 1] = { name = name, value = name } end
        OpenChoiceMenu(self, choices, CurrentProfileName(), SwitchProfile)
    end)

    Heading(profilesPage, "Copy and delete", -182, true)

    Label("Copy settings from", 0, -212)
    local copyButton = Dropdown(profilesPage, DW)
    copyButton:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 4, -232)
    UI.Tip(copyButton, "Replaces everything in the current profile with a copy of the profile you pick.")
    copyButton:SetScript("OnClick", function(self)
        local choices = {}
        for _, name in ipairs(ProfileNames(true)) do choices[#choices + 1] = { name = name, value = name } end
        OpenChoiceMenu(self, choices, nil, function(value)
            StaticPopup_Show("FONTMANAGER_COPY", value, CurrentProfileName(), value)
        end)
    end)

    Label("Delete a profile", RIGHT, -212)
    local deleteButton = Dropdown(profilesPage, DW)
    deleteButton:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", RIGHT + 4, -232)
    UI.Tip(deleteButton, "Characters using a deleted profile go back to Default. The Default profile can't be deleted.")
    deleteButton:SetScript("OnClick", function(self)
        local choices = {}
        for _, name in ipairs(ProfileNames(false)) do
            if name ~= "Default" then choices[#choices + 1] = { name = name, value = name } end
        end
        OpenChoiceMenu(self, choices, nil, function(value)
            StaticPopup_Show("FONTMANAGER_DELETE", value, nil, value)
        end)
    end)

    local aboutHost = NewPage("about")
    local aboutScroll = CreateFrame("ScrollFrame", nil, aboutHost, "UIPanelScrollFrameTemplate")
    aboutScroll:SetPoint("TOPLEFT", aboutHost, "TOPLEFT", 0, 0)
    aboutScroll:SetPoint("BOTTOMRIGHT", aboutHost, "BOTTOMRIGHT", -24, 0)
    UI.SkinScrollBar(aboutScroll)
    refitScrolls[#refitScrolls + 1] = aboutScroll
    local aboutPage = CreateFrame("Frame", nil, aboutScroll)
    aboutPage:SetSize(676, 10)
    lineWidths[aboutPage] = 676
    aboutScroll:SetScrollChild(aboutPage)
    local aboutTop = CreateFrame("Frame", nil, aboutPage)
    aboutTop:SetSize(1, 1)
    aboutTop:SetPoint("TOPLEFT", aboutPage, "TOPLEFT", 4, 4)
    UI.AboutPage(aboutPage, aboutTop, {
        width = 660,
        commands = {
            { "/fm", "Open or close these options." },
            { "/fm toggle", "Turn Font Manager on or off." },
        },
        url = "https://www.curseforge.com/wow/addons/font-manager",
    })
    aboutPage:SetHeight(420)

    local footerLabels = { "Reload UI", "Reset To Default", "Disable Font Manager", "Close" }
    local footer = {}
    local bw = (W - 32 - 3 * 8) / 4
    for i, text in ipairs(footerLabels) do
        local b = Button(rootFrame, bw, 24, text)
        b:SetPoint("BOTTOMLEFT", rootFrame, "BOTTOMLEFT", 16 + (i - 1) * (bw + 8), 12)
        footer[i] = b
    end
    footer[1]:SetScript("OnClick", AskReload)
    UI.Tip(footer[1], "Most text updates instantly. Unit frame names need a reload. Names above heads and combat text need a relog.")
    footer[2]:SetScript("OnClick", function() StaticPopup_Show("FONTMANAGER_RESET") end)
    footer[3]:SetScript("OnClick", function()
        db.enabled = not db.enabled
        Apply()
        panel:Refresh()
    end)
    footer[4]:SetScript("OnClick", function() rootFrame:Hide() end)

    UI.SkinAll(rootFrame)

    function panel:Refresh()
        if not db then return end
        local current = CurrentProfileName()
        profileName:SetText(current)
        cardName:SetText(current)
        profileButton:SetText(current)
        local others = #ProfileNames(true)
        for _, b in ipairs({ copyButton, deleteButton }) do
            local on = others > 0
            b:SetText("Select a profile...")
            b.label:SetTextColor(0.6, 0.6, 0.6)
            b:SetEnabled(on)
            b:SetAlpha(on and 1 or 0.5)
        end
        footer[3]:SetText(db.enabled and "Disable Font Manager" or "Enable Font Manager")

        allCheck:SetChecked(db.allEnabled)
        allCheck:SetEnabled(db.enabled)
        allCheck.label:SetAlpha(db.enabled and 1 or 0.5)
        allButton:SetText(db.allFont and NameFor("ui", db.allFont) or "Choose a font")
        allButton:SetEnabled(db.enabled)
        allButton:SetAlpha(db.enabled and 1 or 0.4)
        allPreview:SetFontObject(F("GameFontHighlight", SZ.setting))
        local allPath = db.allFont == "DEFAULT" and originalGlobals.STANDARD_TEXT_FONT or db.allFont
        if allPath and not SafeSetFont(allPreview, allPath, 15, "") then
            allPreview:SetFontObject(F("GameFontHighlight", SZ.setting))
        end

        local rowsActive = db.enabled and not db.allEnabled
        local blockedNote
        if not db.enabled then
            blockedNote = "Font Manager is turned off. Click \"Enable Font Manager\" to change this."
        elseif db.allEnabled then
            blockedNote = "\"Replace font for all in game text\" is on, so this can't be changed. Turn it off to set fonts separately."
        end
        for _, cat in ipairs(CATEGORIES) do
            local row = rows[cat.key]
            local locked = LOCKED[cat.key] or {}
            row.button:SetText(NameFor(cat.key, db.fonts[cat.key]))
            row.size:SetText(SizeLabel(not locked.size and db.sizes[cat.key] or 1))
            row.outline:SetText(ChoiceLabel(OUTLINE_OPTIONS, not locked.outline and db.outlines[cat.key] or nil))
            row.shadow:SetText(ChoiceLabel(SHADOW_OPTIONS, not locked.shadow and db.shadows[cat.key] or nil))
            local a = rowsActive and 1 or 0.4
            row.label:SetAlpha(a)
            row.preview:SetAlpha(a)
            for _, key in ipairs({ "button", "size", "outline", "shadow" }) do
                local note = (locked[key] and locked.note) or blockedNote
                local usable = note == nil
                row[key]:SetEnabled(usable)
                row[key]:SetAlpha(usable and 1 or 0.4)
                row.covers[key].note = note
                row.covers[key]:SetShown(not usable)
            end
            local previewFlags = ""
            local o = not locked.outline and db.outlines[cat.key]
            if o == "OUTLINE" or o == "THICKOUTLINE" then previewFlags = o end
            local p = ResolveRaw(cat.key) or PreviewDefault(cat.key)
            row.preview:SetFontObject(F("GameFontHighlight", SZ.setting))
            if p and not SafeSetFont(row.preview, p, 14, previewFlags) then
                row.preview:SetFontObject(F("GameFontHighlight", SZ.setting))
            end
            local sh = not locked.shadow and db.shadows[cat.key]
            if sh == "NONE" then
                row.preview:SetShadowOffset(0, 0)
            else
                row.preview:SetShadowOffset(1, -1)
                row.preview:SetShadowColor(0, 0, 0, 1)
            end
        end
    end

    rootFrame:HookScript("OnShow", function(self)
        local ratio = UIParent:GetEffectiveScale() / self:GetEffectiveScale()
        local room = UIParent:GetHeight() * ratio - 16
        local wanted = math.max(UI.MIN_HEIGHT, math.min(UI.MAX_HEIGHT, tonumber(root.panelHeight) or H))
        local height = math.max(math.min(wanted, room), math.min(UI.MIN_HEIGHT, room))
        if math.abs(self:GetHeight() - height) > 0.5 then
            self:SetHeight(height)
            for _, sc in ipairs(refitScrolls) do
                if sc.UpdateScrollChildRect then sc:UpdateScrollChildRect() end
            end
        end
        local bottom, left, top = self:GetBottom(), self:GetLeft(), self:GetTop()
        if bottom and left and top and bottom < 0 then
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top - bottom + 8)
        end
        panel:Refresh()
    end)
    rootFrame:HookScript("OnHide", function()
        menu:Hide()
        if reloadDialog then reloadDialog:Hide() end
    end)

    Select("fonts")
    MarkOwn(rootFrame)
    MarkOwn(menu)
    OwnKitFonts()
end

local function BuildWindow()
    building = true
    local ok, err = pcall(Build)
    building = false
    if not ok then error(err) end
end

local function OpenOptions(forceShow)
    if not window then BuildWindow() end
    if window:IsShown() and not forceShow then
        window:Hide()
    else
        window:Show()
        panel:Refresh()
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
pcall(f.RegisterEvent, f, "NAME_PLATE_UNIT_ADDED")
f:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        FontManagerDB = FontManagerDB or {}
        root = FontManagerDB
        root.userFonts = root.userFonts or {}
        root.userFontNames = root.userFontNames or {}
        root.profiles = root.profiles or {}
        root.profileKeys = root.profileKeys or {}
        if not root.profiles.Default then
            local legacy = {}
            for _, key in ipairs(PROFILE_FIELDS) do
                legacy[key] = root[key]
                root[key] = nil
            end
            root.profiles.Default = legacy
        end
        charKey = (UnitName("player") or "Unknown") .. " - " .. (GetRealmName() or "Unknown")
        local name = root.profileKeys[charKey]
        if not name or not root.profiles[name] then
            name = "Default"
            root.profileKeys[charKey] = name
        end
        db = PrepareProfile(root.profiles[name])
        HookTooltips()
        UI.AddonsPanel("Font Manager", nil, function() OpenOptions(true) end)
        Apply()
        ShareFonts()
    elseif event == "PLAYER_LOGIN" then
        ShareFonts()
        fontListCache = nil
        Apply()
        if C_Timer then
            C_Timer.After(6, function()
                local force = ForcedFont()
                if force then SweepExisting(force, true) end
            end)
        end
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        if db and C_NamePlate and C_NamePlate.GetNamePlateForUnit then
            local ok, plate = pcall(C_NamePlate.GetNamePlateForUnit, arg1)
            local fs = ok and PlateName(plate)
            if fs then ApplyPlateName(fs) end
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if combatSizePending and db then
            combatSizePending = false
            ApplyCombatSize()
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        if C_Timer then
            C_Timer.After(1, Apply)
            if not self.settled then
                self.settled = true
                C_Timer.After(5, Apply)
            end
        else
            Apply()
        end
    end
end)

local function FormatMemory(kb)
    if kb >= 1024 then return string.format("%.1f MB", kb / 1024) end
    return string.format("%.1f KB", kb)
end

local memoryChecking = false

CheckMemory = function()
    local update = (C_AddOns and C_AddOns.UpdateAddOnMemoryUsage) or UpdateAddOnMemoryUsage
    local get = (C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage
    if not update or not get then
        Print("memory can't be checked on this version of the game.")
        return
    end
    if memoryChecking then
        Print("already checking, wait a few seconds.")
        return
    end
    pcall(update)
    local okShown, shown = pcall(get, ADDON_NAME)
    collectgarbage("collect")
    pcall(update)
    local okClean, clean = pcall(get, ADDON_NAME)
    if not (okShown and okClean and shown and clean) then
        Print("memory can't be checked right now.")
        return
    end
    Print("memory: " .. FormatMemory(shown) .. " shown, " .. FormatMemory(clean) .. " after clean-up (the rest was old garbage). Checking again in 10 seconds...")
    if not C_Timer then return end
    memoryChecking = true
    C_Timer.After(10, function()
        memoryChecking = false
        pcall(update)
        local okNow, now = pcall(get, ADDON_NAME)
        if not okNow or not now then return end
        local perSecond = math.max(0, now - clean) / 10
        Print("memory: " .. FormatMemory(perSecond) .. " of new garbage per second over the last 10 seconds.")
    end)
end

SLASH_FONTMANAGER1 = "/fm"
SLASH_FONTMANAGER2 = "/fontmanager"
SlashCmdList.FONTMANAGER = function(input)
    local cmd = strtrim((input or "")):lower()
    if cmd == "" or cmd == "options" or cmd == "config" then
        OpenOptions()
    elseif cmd == "toggle" or cmd == "on" or cmd == "off" then
        if cmd == "toggle" then db.enabled = not db.enabled else db.enabled = (cmd == "on") end
        Apply()
        panel:Refresh()
        Print("custom fonts " .. (db.enabled and "|cff00ff00enabled|r." or "|cffff5555disabled|r. /reload to reset text already on screen."))
    elseif cmd == "help" then
        Print("commands:")
        print("  |cff" .. ACCENT_HEX .. "/fm|r  open or close the options")
        print("  |cff" .. ACCENT_HEX .. "/fm on|r, |cff" .. ACCENT_HEX .. "/fm off|r, |cff" .. ACCENT_HEX .. "/fm toggle|r  turn Font Manager on or off")
        print("  |cff" .. ACCENT_HEX .. "/fm all|r  turn \"Replace font for all in game text\" on or off")
        print("  |cff" .. ACCENT_HEX .. "/fm memory|r  check how much memory Font Manager uses")
        print("  |cff" .. ACCENT_HEX .. "/fm help|r  show this list")
    elseif cmd == "memory" or cmd == "mem" then
        CheckMemory()
    elseif cmd == "all" then
        SetReplaceAll(not db.allEnabled)
        Print("replace font for all in game text " .. (db.allEnabled and "|cff00ff00on|r." or "|cffff5555off|r."))
    else
        Print("unknown command. Type |cff" .. ACCENT_HEX .. "/fm help|r for a list.")
    end
end
