Put your font files (.ttf works best) in this folder.

Then fully restart WoW (a /reload is not enough for new files),
type /fm, open the Add fonts tab, and add each file by name.
Or list them in FontList.lua so they always show up.

A file named Custom.ttf is picked up automatically.
