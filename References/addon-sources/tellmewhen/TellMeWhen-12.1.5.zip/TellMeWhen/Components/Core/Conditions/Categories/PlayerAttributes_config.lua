﻿-- --------------------
-- TellMeWhen
-- Originally by NephMakes

-- Other contributions by:
--		Sweetmms of Blackrock, Oozebull of Twisting Nether, Oodyboo of Mug'thol,
--		Banjankri of Blackrock, Predeter of Proudmoore, Xenyr of Aszune

-- Currently maintained by
-- Cybeloras of Aerie Peak
-- --------------------


if not TMW then return end

local TMW = TMW
local L = TMW.L
local print = TMW.print

local SUG = TMW.SUG
local strlowerCache = TMW.strlowerCache
local GetSpellInfo = TMW.GetSpellInfo
local GetSpellName = TMW.GetSpellName

local _, pclass = UnitClass("Player")



local Module = SUG:NewModule("stances", SUG:GetModule("spell"))
Module.noMin = true
Module.showColorHelp = false
Module.helpText = L["SUG_TOOLTIPTITLE_GENERIC"]

Module.stances = {
	[2457] = 	GetSpellName(2457), 	-- Battle Stance
	[71] = 		GetSpellName(71),		-- Defensive Stance
	[2458] = 	GetSpellName(2458), 	-- Berserker Stance
	[386164] = 	GetSpellName(386164), 	-- Battle Stance (dragonflight)
	[386208] = 	GetSpellName(386208),	-- Defensive Stance (dragonflight)
	[386196] = 	GetSpellName(386196), 	-- Berserker Stance (dragonflight)
	[412513] =  GetSpellName(412513),   -- Gladiator Stance (SOD)
	
	[5487] = 	GetSpellName(5487), 	-- Bear Form
	[768] = 	GetSpellName(768),		-- Cat Form
	[1066] = 	GetSpellName(1066), 	-- Aquatic Form
	[783] = 	GetSpellName(783),		-- Travel Form
	[24858] = 	GetSpellName(24858), 	-- Moonkin Form
	[33891] = 	GetSpellName(33891), 	-- Tree of Life
	[33943] = 	GetSpellName(33943), 	-- Flight Form
	[40120] = 	GetSpellName(40120), 	-- Swift Flight Form	
	[9634] = 	GetSpellName(9634), 	-- Dire Bear Form
	[171745] = 	GetSpellName(171745), 	-- Claws of Shirvallah	

	[1784] = 	GetSpellName(1784), 	-- Stealth	

	[13165] = 	GetSpellName(13165), 	-- Aspect of the Hawk
	[109260] = 	GetSpellName(109260), 	-- Aspect of the Iron Hawk
	[5118] = 	GetSpellName(5118), 	-- Aspect of the Cheetah
	[13159] = 	GetSpellName(13159), 	-- Aspect of the Pack

	[48263] = 	GetSpellName(48263), 	-- Blood Presence
	[48266] = 	GetSpellName(48266), 	-- Frost Presence
	[48265] = 	GetSpellName(48265), 	-- Unholy Presence	

	[103958] = 	GetSpellName(103958),	-- Metamorphosis
	[403789] =  GetSpellName(403789),   -- Metamorphosis (SOD)
	[114168] = 	GetSpellName(114168),	-- Dark Apotheosis

	[15473] = 	GetSpellName(15473), 	-- Shadowform	(classic-ish)
	[232698] = 	GetSpellName(232698), 	-- Shadowform	(retail)

	[115069] = 	GetSpellName(115069),	-- Sturdy Ox
	[115070] = 	GetSpellName(115070),	-- Wise Serpent
	[103985] = 	GetSpellName(103985),	-- Fierce Tiger

	[105361] = 	GetSpellName(105361), 	-- Seal of Command
	[20165] = 	GetSpellName(20165), 	-- Seal of Insight
	[20164] = 	GetSpellName(20164),	-- Seal of Justice
	[20154] = 	GetSpellName(20154), 	-- Seal of Righteousness
	[31801] = 	GetSpellName(31801),	-- Seal of Truth
	[19746] = 	GetSpellName(19746), 	-- Concentration Aura
	[32223] = 	GetSpellName(32223), 	-- Crusader Aura
	[465] = 	GetSpellName(465),		-- Devotion Aura
	[19900] = 	GetSpellName(19891), 	-- Fire Resistance Aura
	[19898] = 	GetSpellName(19891), 	-- Frost Resistance Aura
	[19896] = 	GetSpellName(19891), 	-- Shadow Resistance Aura
	[7294] = 	GetSpellName(7294),		-- Retribution Aura	
}

function Module:Table_Get()
	local allStances = {}
	for spellID, name in pairs(Module.stances) do
		allStances[spellID] = name
	end
	return allStances
end
function Module:Entry_AddToList_1(f, spellID)
	if spellID == 0 then
		f.Name:SetText(NONE)
		f.ID:SetText(nil)

		f.tooltiptitle = NONE

		f.insert = NONE

		f.Icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
	else
		local name, _, tex = GetSpellInfo(spellID)

		f.Name:SetText(name)
		f.ID:SetText(spellID)

		f.tooltipmethod = TMW.GameTooltip_SetSpellByIDWithClassIcon
		f.tooltiparg = spellID

		f.insert = SUG.inputType == "number" and spellID or name
		f.insert2 = SUG.inputType ~= "number" and spellID or name

		f.Icon:SetTexture(tex)
	end
end
function Module:Table_GetNormalSuggestions(suggestions, tbl)
	local atBeginning = SUG.atBeginning
	local lastName = SUG.lastName

	for id, name in pairs(tbl) do
		if strfind(strlower(name), atBeginning) then
			suggestions[#suggestions + 1] = id
		end
	end
end
function Module:Table_GetSpecialSuggestions_1(suggestions)
	local atBeginning = SUG.atBeginning
	if strfind(strlower(NONE), atBeginning) then
		suggestions[#suggestions + 1] = 0
	end
end



local Module = SUG:NewModule("tracking", SUG:GetModule("default"))
Module.noMin = true
Module.showColorHelp = false
Module.helpText = L["SUG_TOOLTIPTITLE_GENERIC"]

local TrackingCache = {}
if C_Minimap and C_Minimap.GetTrackingInfo and C_Minimap.GetNumTrackingTypes() > 0 and type(C_Minimap.GetTrackingInfo(1)) == "table" then
	local GetTrackingInfo = C_Minimap.GetTrackingInfo
	local GetNumTrackingTypes = C_Minimap.GetNumTrackingTypes
	-- Wow 11.0+
	
	function Module:Table_Get()
		for i = 1, GetNumTrackingTypes() do
			local data = GetTrackingInfo(i)
			TrackingCache[i] = strlower(data.name)
		end
		
		return TrackingCache
	end

	function Module:Entry_AddToList_1(f, id)
		local info = GetTrackingInfo(id)
	
		f.Name:SetText(info.name)
		f.ID:SetText(nil)
	
		f.tooltiptitle = info.name
		
		f.insert = info.name
	
		f.Icon:SetTexture(info.texture)
	end

elseif C_Minimap and C_Minimap.GetTrackingInfo and C_Minimap.GetNumTrackingTypes() > 0 then
	-- Cata Classic
	local GetTrackingInfo = C_Minimap.GetTrackingInfo
	local GetNumTrackingTypes = C_Minimap.GetNumTrackingTypes

	function Module:Table_Get()
		for i = 1, GetNumTrackingTypes() do
			local name, _, active = GetTrackingInfo(i)
			TrackingCache[i] = strlower(name)
		end
		
		return TrackingCache
	end

	function Module:Entry_AddToList_1(f, id)
		local name, texture = GetTrackingInfo(id)
	
		f.Name:SetText(name)
		f.ID:SetText(nil)
	
		f.tooltiptitle = name
		
		f.insert = name
	
		f.Icon:SetTexture(texture)
	end
	
else
	-- WoW Classic
	for _, id in pairs{
		2580, -- Find Minerals
		2383, -- Find Herbs
		2481, -- Find Treasure
		1494, -- Track Beasts
		19878, -- Track Demons
		19879, -- Track Dragonkin
		19880, -- Track Elementals
		19882, -- Track Giants
		19885, -- Track Hidden
		5225, -- Track Humanoids (druid)
		19883, -- Track Humanoids
		19884, -- Track Undead
	} do
		local name = GetSpellName(id)
		TrackingCache[id] = strlower(name)
	end

	function Module:Table_Get()
		return TrackingCache
	end

	function Module:Entry_AddToList_1(f, id)
		local name, _, texture = GetSpellInfo(id)
	
		f.Name:SetText(name)
		f.ID:SetText(nil)
	
		f.tooltiptitle = name
		
		f.insert = name
	
		f.Icon:SetTexture(texture)
	end
end
function Module:Table_GetSorter()
	return nil
end


if C_EquipmentSet then
	local Module = SUG:NewModule("blizzequipset", SUG:GetModule("default"))
	Module.noMin = true
	Module.showColorHelp = false
	Module.helpText = L["SUG_TOOLTIPTITLE_GENERIC"]

	local EquipSetCache = {}
	function Module:Table_Get()
		for i, id in pairs(C_EquipmentSet.GetEquipmentSetIDs()) do
			local name, icon = C_EquipmentSet.GetEquipmentSetInfo(id)

			EquipSetCache[id] = strlower(name)
		end
		
		return EquipSetCache
	end
	function Module:Table_GetSorter()
		return nil
	end
	function Module:Entry_AddToList_1(f, id)
		local name, icon = C_EquipmentSet.GetEquipmentSetInfo(id)

		f.Name:SetText(name)
		f.ID:SetText(nil)

		f.tooltipmethod = "SetEquipmentSet"
		f.tooltiparg = name

		f.insert = name

		f.Icon:SetTexture(icon)
	end
end
