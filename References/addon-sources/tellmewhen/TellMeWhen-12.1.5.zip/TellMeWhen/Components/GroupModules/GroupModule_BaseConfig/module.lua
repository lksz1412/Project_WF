﻿-- --------------------
-- TellMeWhen
-- Originally by NephMakes

-- Other contributions by:
--		Sweetmms of Blackrock, Oozebull of Twisting Nether, Oodyboo of Mug'thol,
--		Banjankri of Blackrock, Predeter of Proudmoore, Xenyr of Aszune

-- Currently maintained by
-- Cybeloras of Aerie Peak
-- --------------------


if not TMW then return end

local TMW = TMW
local L = TMW.L
local print = TMW.print


local BaseConfig = TMW:NewClass("GroupModule_BaseConfig", "GroupModule")

BaseConfig.DefaultPanelColumnIndex = 1


BaseConfig:RegisterConfigPanel_XMLTemplate(1, "TellMeWhen_GM_Rename"):SetColumnIndex(2)

BaseConfig:RegisterConfigPanel_ConstructorFunc(2, "TellMeWhen_GM_View", function(self)
	self:SetTitle(L["UIPANEL_GROUPTYPE"])
	
	local data = { numPerRow = 3, }

	local function Reload()
		-- Reload the group config once setup finishes so that we get the correct panels
		-- after the view changes.
		TMW:Update(function()
			TMW.IE:LoadGroup(1)
		end)
	end

	for view, viewData in TMW:OrderedPairs(TMW.Views, TMW.OrderSort, true) do
		tinsert(data, function(check)
			check:SetTexts(viewData.name, viewData.desc)
			check:SetSetting("View", view)
			check:CScriptAddPre("SettingSaved", Reload)
		end)
	end

	self:BuildSimpleCheckSettingFrame(data)
end)

BaseConfig:RegisterConfigPanel_ConstructorFunc(9, "TellMeWhen_GS_Combat", function(self)
	self:SetTitle(COMBAT)
	
	self:BuildSimpleCheckSettingFrame({
		numPerRow = 1,
		function(check)
			check:SetTexts(L["UIPANEL_ONLYINCOMBAT"], L["UIPANEL_TOOLTIP_ONLYINCOMBAT"])
			check:SetSetting("OnlyInCombat")
		end,
	})
end)

BaseConfig:RegisterConfigPanel_ConstructorFunc(11, "TellMeWhen_GS_Role", function(self)
	self:SetTitle(ROLE)
	
	local data = {
		numPerRow = 3
	}	

	for i, role in TMW:Vararg("TANK", "HEALER", "DAMAGER") do
		tinsert(data, function(check)
			check:SetLabel("")
			check:SetTexts(_G[role], L["UIPANEL_ROLE_DESC"])

			-- This subtraction is because the bit order is reversed from this.
			-- We put the settings in this order since it is the role order in the default UI.
			check:SetSetting("Role")
			check:SetSettingBitID(4 - i)

			local border = CreateFrame("Frame", nil, check, "TellMeWhen_GenericBorder")
			border:ClearAllPoints()
			border:SetPoint("LEFT", check, "RIGHT", 4, 0)
			border:SetSize(21, 21)

			local tex = border:CreateTexture(nil, "ARTWORK")
			tex:SetTexture("Interface\\Addons\\TellMeWhen\\Textures\\" .. role)
			tex:SetAllPoints()
		end)
	end

	self:BuildSimpleCheckSettingFrame("Config_CheckButton_BitToggle", data)
end)

BaseConfig:RegisterConfigPanel_ConstructorFunc(12, "TellMeWhen_GS_Tree", function(self)
	self:SetTitle(SPECIALIZATION)
	
	local data = {
		numPerRow = TMW.GetNumSpecializations()
	}	

	for i = 1, TMW.GetNumSpecializations() do
		local specID, name, _, texture = TMW.GetSpecializationInfo(i)
		tinsert(data, function(check)
			check:SetLabel("")
			check:SetTexts(name, L["UIPANEL_TREE_DESC"])
			check:SetSetting(specID)

			local border = CreateFrame("Frame", nil, check, "TellMeWhen_GenericBorder")
			border:ClearAllPoints()
			border:SetPoint("LEFT", check, "RIGHT", 4, 0)
			border:SetSize(21, 21)

			local tex = border:CreateTexture(nil, "ARTWORK")
			tex:SetTexture(texture)
			tex:SetAllPoints()
			tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
		end)
	end

	self:BuildSimpleCheckSettingFrame(data)

	self:CScriptAdd("SettingTableRequested", function()
		return TMW.CI.gs and TMW.CI.gs.EnabledSpecs or false
	end)
end)

if TMW.clientHasSecrets then

    local viewers = {
        EssentialCooldownViewer,
        BuffIconCooldownViewer,
        BuffBarCooldownViewer,
        UtilityCooldownViewer
    }
    -- Remove nil viewers
    for i = #viewers, 1, -1 do
        if not viewers[i] then
            table.remove(viewers, i)
        end
    end
	
	BaseConfig:RegisterConfigPanel_ConstructorFunc(13, "TellMeWhen_GS_CDMViewerHide", function(self)
		self:SetTitle(L["UIPANEL_GROUP_CDM_HIDE"])

		local function OnClick(button, dropdown)
			local settingTable = TMW.CI.gs.CDMViewerHide
			local key = button.value
			settingTable[key] = not settingTable[key]
			dropdown:OnSettingSaved()
			TMW:Update()
		end

		self.CDMViewerDropdown = TMW.C.Config_DropDownMenu:New("Frame", "$parentCDMViewerHide", self, "TMW_DropDownMenuTemplate")
		self.CDMViewerDropdown:SetTexts(L["UIPANEL_GROUP_CDM_HIDE"], L["UIPANEL_GROUP_CDM_HIDE_DESC"])
		self.CDMViewerDropdown:SetWidth(200)
		self.CDMViewerDropdown:SetFunction(function(dropdown)
			local settingTable = TMW.CI.gs.CDMViewerHide
			for _, viewer in ipairs(viewers) do
				local settingKey = viewer.systemIndex
				local info = TMW.DD:CreateInfo()
				info.text = viewer.systemNameString
				info.tooltipTitle = viewer.systemNameString
				info.tooltipText = L["UIPANEL_GROUP_CDM_HIDE_DESC"]
				info.value = settingKey
				info.func = OnClick
				info.arg1 = dropdown
				info.keepShownOnClick = true
				info.isNotRadio = true
				info.checked = settingTable[settingKey]

				TMW.DD:AddButton(info)
			end
		end)

		self.CDMViewerDropdown:SetPoint("TOPLEFT", 5, -5)
		self.CDMViewerDropdown:SetPoint("RIGHT", -5, 0)

		self:CScriptAdd("ReloadRequested", function()
			local settingTable = TMW.CI.gs and TMW.CI.gs.CDMViewerHide
			if not settingTable then return end
			local names = {}
			for _, viewer in ipairs(viewers) do
				if settingTable[viewer.systemIndex]then
					tinsert(names, viewer.systemNameString)
				end
			end

			if #names == 0 then
				self.CDMViewerDropdown:SetText(NONE)
			else
				self.CDMViewerDropdown:SetText(table.concat(names, ", "))
			end
		end)

		self:AdjustHeight()
	end)
    
    -- Find the first active group that is hiding a specific viewer by its systemIndex.
    local function GetGroupHidingViewer(settingKey)
        for group in TMW:InGroups() do
            if group:ShouldUpdateIcons() and group:GetSettings().CDMViewerHide[settingKey] then
                return group
            end
        end
        return nil
    end

    local function ApplyViewerOverride(viewer)
        local settingName = viewer.systemIndex
        if not TMW.db then return end

        local shouldHide = not EditModeManagerFrame:IsEditModeActive() and (GetGroupHidingViewer(settingName) ~= nil)

        if shouldHide then
            viewer:SetAlpha(0)
			viewer._tmwHidden = 1
            -- DONT call SetTooltipsShown, it will taint.
            -- Instead, manually iterate and disable mouse motion so tooltips don't appears on invisible frames.
            for itemFrame in viewer.itemFramePool:EnumerateActive() do
                itemFrame:SetMouseMotionEnabled(false);
            end
        elseif viewer._tmwHidden then
			viewer._tmwHidden = false
			-- DONT call UpdateSystemSettingShowTooltips, it will taint.
			-- viewer:UpdateSystemSettingShowTooltips()
			viewer:UpdateSystemSettingOpacity()
		end
    end

    local groupHideAnchor
    local groupHideText

    -- Position against UIParent from the dialog's measured rect rather than anchoring to
    -- the dialog itself. SetPoint'ing to EditModeSystemSettingsDialog would leave an
    -- insecure frame in its anchor graph; reading GetRect/IsShown off it does not taint it.
    local function PositionGroupHideAnchor()
        local left, bottom, _, height = EditModeSystemSettingsDialog:GetRect()
        if not left then return end

        local scale = EditModeSystemSettingsDialog:GetEffectiveScale() / groupHideAnchor:GetEffectiveScale()
        groupHideAnchor:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT",
            (left * scale) + 20,
            ((bottom + height) * scale) - 30
        )
    end

    TMW.safecall(function()
        for _, viewer in pairs(viewers) do
            hooksecurefunc(viewer, "RefreshLayout", ApplyViewerOverride)
        end

        -- Create an anchor frame and a text label to show which group is hiding this viewer
        groupHideAnchor = CreateFrame("Frame", "TMWEditModeCDMHidden", TMW)
        groupHideAnchor:SetFrameStrata("FULLSCREEN")
        groupHideAnchor:SetSize(1, 1)
        groupHideAnchor:Hide()

        groupHideText = groupHideAnchor:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        groupHideText:SetPoint("TOPLEFT")
        groupHideText:SetWidth(280)
        groupHideText:SetJustifyH("LEFT")

        -- HookScript on EditModeSystemSettingsDialog taints every execution path that hides it,
        -- which includes exiting edit mode - that path goes on to show Blizzard's damage meter,
        -- whose event registrations then carry TMW's taint forever. Poll instead. #2463
        groupHideAnchor:SetScript("OnUpdate", function(self)
            if not EditModeSystemSettingsDialog:IsShown() then
                self:Hide()
                return
            end
            PositionGroupHideAnchor()
        end)
    end)

	local function DrawEditModeSettings()
		local self = EditModeSystemSettingsDialog
		local systemFrame = self.attachedToSystem
		if not groupHideText then return end
		if not tContains(viewers, systemFrame) or not self:IsShown() then
			groupHideAnchor:Hide()
			return
		end

		local settingName = systemFrame.systemIndex

		-- Show which group is hiding this viewer, if any
		if groupHideText then
			local hidingGroup = GetGroupHidingViewer(settingName)
			if hidingGroup then
				groupHideText:SetText("|cFFFF5050" .. L["CDM_HIDDEN_BY_GROUP"]:format(hidingGroup:GetGroupName()))
				PositionGroupHideAnchor()
				groupHideAnchor:Show()
			else
				groupHideAnchor:Hide()
			end
		end
    end

    local function ApplyAllViewerOverrides()
        for _, viewer in pairs(viewers) do
            TMW.safecall(ApplyViewerOverride, viewer)
        end
		TMW.safecall(DrawEditModeSettings)
    end

    -- A full update spans many frames and fires TMW_GROUP_SETUP_POST per group as it walks them.
    -- Groups it hasn't reached yet still hold last pass's settings, so applying mid-walk would
    -- flash the viewers on stale state. Wait for the epilogue instead.
    local fullUpdateInFlight = false
    TMW:RegisterCallback("TMW_GLOBAL_UPDATE", function() fullUpdateInFlight = true end)

    TMW:RegisterCallback("TMW_GLOBAL_UPDATE_POST", function()
        fullUpdateInFlight = false
        ApplyAllViewerOverrides()
    end)

    -- Toggling a group's Enabled/spec/role in the config only re-runs that one group's Setup, so
    -- ShouldUpdateIcons can flip without a full update ever happening to reapply the override.
    TMW:RegisterCallback("TMW_GROUP_SETUP_POST", function()
        if fullUpdateInFlight then return end
        ApplyAllViewerOverrides()
    end)

    -- Add the checkbox to the edit mode dialog when appropriate
    hooksecurefunc(EditModeSystemSettingsDialog, "AttachToSystemFrame", DrawEditModeSettings)
end

BaseConfig:RegisterConfigPanel_XMLTemplate(20, "TellMeWhen_GM_Dims")

BaseConfig:RegisterConfigPanel_XMLTemplate(21, "TellMeWhen_GM_Texture")

