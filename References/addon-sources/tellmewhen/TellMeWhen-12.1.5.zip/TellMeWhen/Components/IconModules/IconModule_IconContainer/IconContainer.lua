﻿-- --------------------
-- TellMeWhen
-- Originally by NephMakes

-- Other contributions by:
--		Sweetmms of Blackrock, Oozebull of Twisting Nether, Oodyboo of Mug'thol,
--		Banjankri of Blackrock, Predeter of Proudmoore, Xenyr of Aszune

-- Currently maintained by
-- Cybeloras of Aerie Peak
-- --------------------


if not TMW then return end

local TMW = TMW
local L = TMW.L
local print = TMW.print

local IconContainer = TMW:NewClass("IconModule_IconContainer", "IconModule")

IconContainer:RegisterAnchorableFrame("IconContainer")

function IconContainer:OnNewInstance_IconContainer(icon)
	local container = CreateFrame("Button", self:GetChildNameBase() .. "IconContainer", icon)

	container:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	container:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")

	self.container = container
	container.module = self

	-- Everything that currently wants the activation overlay shown. See ShowOverlayGlow.
	self.overlayOwners = {}

	container:EnableMouse(false)

	-- Start hidden so the container (and its child border) only ever show while the
	-- module is enabled (shown in OnEnable, hidden in OnDisableDelayed). A type that
	-- disallows this module leaves it never-enabled, and thus hidden, rather than
	-- showing an orphaned icon square/border.
	container:Hide()
end

function IconContainer:OnEnable()
	local icon = self.icon
	local container = self.container
	
	if not container:IsShown() then
		container:Show()
	end
	
	container:SetFrameLevel(icon:GetFrameLevel())
end

function IconContainer:OnDisable()
	self:SetBorder(0, "ffffffff")
end

function IconContainer:OnDisableDelayed()
	self.container:Hide()
end

function IconContainer:SetBorder(size, color, inset)
	if not self.border and size ~= 0 then
		self.border = CreateFrame("Frame", nil, self.container, "TellMeWhen_GenericBorder")
	end

	if inset then size = -size end

	if self.border then
		self.border:SetBorderSize(size)
		self.border:SetColor(TMW:StringToRGBA(color))
	end
end





-- SpellActivationAlert animation handling:
local activationAlertTemplate = "ActionBarButtonSpellActivationAlert"
if pcall(CreateFrame, "Frame", nil, UIParent, "ActionButtonSpellAlertTemplate") then
	-- Wow 11.1.7 renamed ActionBarButtonSpellActivationAlert to ActionButtonSpellAlertTemplate
	activationAlertTemplate = "ActionButtonSpellAlertTemplate"
end

local hasProcAnim = CreateFrame("Frame", nil, UIParent, activationAlertTemplate).ProcStartAnim ~= nil

if hasProcAnim then
	-- Wow 10.1.5+
	function IconContainer:ShowOverlayGlowInternal()
		local container = self.container
		local overlay = container.overlay

		if not overlay then
			-- Parented to the icon rather than the container, but still anchored to the
			-- container: an aura container dims the container to hide the icon's own art,
			-- and the glow draws over the auras rather than being part of what's hidden.
			overlay = CreateFrame("Frame", nil, self.icon, "TellMeWhen_ProcLoopGlow")
			container.overlay = overlay

			local frameWidth, frameHeight = container:GetSize()
			overlay:SetSize(frameWidth * 1.4, frameHeight * 1.4)
			overlay:SetPoint("CENTER", container, "CENTER", 0, 0)
			overlay:Hide()
		end
		if not overlay:IsShown() then
			overlay:Show()
			overlay.anim:Play()
			overlay.fadeIn:Play()
		end
	end

	function IconContainer:HideOverlayGlowInternal()
		local container = self.container
		local overlay = container.overlay

		if overlay then
			overlay.anim:Stop()
			overlay:Hide()
		end
	end
else

	-- Legacy:
	local function OverlayGlowAnimOutFinished(animGroup)
		local overlay = animGroup:GetParent();
		local container = overlay:GetParent();
		overlay:Hide();
	end
	local function OverlayOnHide(overlay)
		if ( overlay.animOut:IsPlaying() ) then
			overlay.animOut:Stop();
			OverlayGlowAnimOutFinished(overlay.animOut);
		end
	end

	function IconContainer:ShowOverlayGlowInternal()
		local container = self.container
		local overlay = container.overlay

		if overlay then
			overlay:Show();
			if overlay.animOut:IsPlaying() then
				overlay.animOut:Stop();
			end
		else
			-- Parented to the icon rather than the container, but still anchored to the
			-- container: an aura container dims the container to hide the icon's own art,
			-- and the glow draws over the auras rather than being part of what's hidden.
			overlay = CreateFrame("Frame", nil, self.icon, "ActionBarButtonSpellActivationAlert");
			container.overlay = overlay

			-- Override scripts from the blizzard template:
			-- We do this so we don't have to duplicate the template as well.
			overlay.animOut:SetScript("OnFinished", OverlayGlowAnimOutFinished)
			overlay:SetScript("OnHide", OverlayOnHide)

			local frameWidth, frameHeight = container:GetSize();
			overlay:ClearAllPoints();
			--Make the height/width available before the next frame:
			overlay:SetSize(frameWidth * 1.4, frameHeight * 1.4);
			overlay:SetPoint("TOPLEFT", container, "TOPLEFT", -frameWidth * 0.2, frameHeight * 0.2);
			overlay:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", frameWidth * 0.2, -frameHeight * 0.2);
		end

		overlay.animIn:Play();
	end

	function IconContainer:HideOverlayGlowInternal()
		local container = self.container
		local overlay = container.overlay

		if ( overlay ) then
			if ( overlay.animIn:IsPlaying() ) then
				overlay.animIn:Stop();
			end
			if ( container:IsVisible() ) then
				overlay.animOut:Play();
			else
				OverlayGlowAnimOutFinished(overlay.animOut);	--We aren't shown anyway, so we'll instantly hide it.
			end
		end
	end
end

--- Shows the Blizzard spell activation overlay on this container.
-- @param owner [any|nil] A token identifying what wants the overlay shown. The overlay
-- stays up until every owner that showed it has called HideOverlayGlow with its token,
-- so the Activation Border animation and the automatic activation border
-- (IconModule_ActivationGlow) don't turn each other off.
function IconContainer:ShowOverlayGlow(owner)
	self.overlayOwners[owner or true] = true

	self:ShowOverlayGlowInternal()

	self.container.overlay:SetFrameLevel(self.icon:GetFrameLevel() + TMW.CONST.FRAMELEVEL.ANIMATION)
end

--- Releases this owner's claim on the Blizzard spell activation overlay, hiding it
-- if nothing else still wants it shown. See ShowOverlayGlow.
-- @param owner [any|nil] The token that was passed to ShowOverlayGlow.
function IconContainer:HideOverlayGlow(owner)
	local overlayOwners = self.overlayOwners
	overlayOwners[owner or true] = nil

	if next(overlayOwners) then
		return
	end

	self:HideOverlayGlowInternal()
end


-- The overscale ShowOverlayGlowInternal gives this art, so it reads as a halo around the
-- icon square rather than a border on it.
local ACTVTNGLOW_OVERSCALE = 1.4

-- Wrap `target` with `region`, grown outward by `scale` about its center. The size is passed
-- rather than read back because a persistent copy of this art can live on a frame whose
-- GetSize is secret (see IconModule_AuraContainer).
local function WrapWithGlow(region, target, w, h, scale)
	local insetX, insetY = w * (scale - 1) / 2, h * (scale - 1) / 2

	region:ClearAllPoints()
	region:SetPoint("TOPLEFT", target, "TOPLEFT", -insetX, insetY)
	region:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", insetX, -insetY)
end

local ACTVTNGLOW = {
	text = L["ANIM_ACTVTNGLOW"],
	desc = L["ANIM_ACTVTNGLOW_DESC"],
	ConfigFrames = {
		"Duration",
		"Infinite",
		"Scale"
	},

	Play = function(icon, eventSettings)
		icon:Animations_Start{
			eventSettings = eventSettings,
			Start = TMW.time,
			Scale = eventSettings.Scale,
			Duration = eventSettings.Infinite and math.huge or eventSettings.Duration,
		}
	end,

	OnUpdate = function(icon, table)
		if table.Duration - (TMW.time - table.Start) < 0 then
			icon:Animations_Stop(table)
		end
	end,
	OnStart = function(icon, table)
		local IconModule_IconContainer = icon:GetModuleOrModuleChild("IconModule_IconContainer")
		local container = IconModule_IconContainer.container
		
		IconModule_IconContainer:ShowOverlayGlow()

		-- overlay is a field created by IconModule_IconContainer:ShowOverlayGlow(),
		-- which also picks its frame level.
		container.overlay:SetScale(table.Scale)
	end,
	OnStop = function(icon, table)
		local IconModule_IconContainer = icon:GetModuleOrModuleChild("IconModule_IconContainer", true, true)

		IconModule_IconContainer:HideOverlayGlow()
	end,
}

if hasProcAnim then
	-- A persistent copy of the overlay, for displays whose art has to run without Lua
	-- touching it (see IconModule_AuraContainer). The module's own overlay can't be shared:
	-- it belongs to the icon, and this one is parented to whatever is hosting it.
	ACTVTNGLOW.Persistent = {
		Build = function(parent)
			-- Our own copy of the art (Glows.xml), which Blizzard's template can't be used for
			-- here. It carries only the loop half, the same half ShowOverlayGlowInternal keeps.
			local overlay = CreateFrame("Frame", nil, parent, "TellMeWhen_ProcLoopGlow")

			-- Nothing will ever start it again: scripts don't fire on a descendant of the
			-- restricted button that hosts this.
			overlay.anim:Play()
			return overlay
		end,
		Configure = function(overlay, eventSettings, placement)
			local square = placement.square
			WrapWithGlow(overlay, square.frame, square.width, square.height,
				ACTVTNGLOW_OVERSCALE * eventSettings.Scale)
			overlay:SetFrameLevel(placement.level)
		end,
	}
end

IconContainer:RegisterEventHandlerData("Animations", 60, "ACTVTNGLOW", ACTVTNGLOW)


-- Blizzard's Cooldown Manager draws this art outside the frame it surrounds - 6px around a
-- ~40px icon - so it reads as a halo rather than an inner border.
local CDMPANDEMIC_OVERSCALE = 1.3

-- Our own copy of Blizzard's art (Glows.xml), so the atlas is what says whether this
-- client has it - the template exists everywhere TMW does.
local cdmPandemicTemplate = "TellMeWhen_CDMPandemicFX"

if C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("UI-CooldownManager-PandemicBorder") then
	IconContainer:RegisterEventHandlerData("Animations", 61, "CDMPANDEMIC", {
		text = L["ANIM_CDMPANDEMIC"],
		desc = L["ANIM_CDMPANDEMIC_DESC"],

		-- No color: the art has its own color.
		ConfigFrames = {
			"Duration",
			"Infinite",
			"Scale",
		},

		Play = function(icon, eventSettings)
			icon:Animations_Start{
				eventSettings = eventSettings,
				Start = TMW.time,
				Scale = eventSettings.Scale,
				Duration = eventSettings.Infinite and math.huge or eventSettings.Duration,
			}
		end,

		OnUpdate = function(icon, table)
			if table.Duration - (TMW.time - table.Start) < 0 then
				icon:Animations_Stop(table)
			end
		end,
		OnStart = function(icon, table)
			local container = icon:GetModuleOrModuleChild("IconModule_IconContainer").container

			local fx = container.cdmPandemic
			if not fx then
				-- Parented to the icon rather than the container for the reason
				-- ShowOverlayGlowInternal gives: an aura container dims the container to hide
				-- the icon's own art, and this draws over the auras instead.
				fx = CreateFrame("Frame", nil, icon, cdmPandemicTemplate)
				container.cdmPandemic = fx
				fx:SetFrameLevel(icon:GetFrameLevel() + TMW.CONST.FRAMELEVEL.ANIMATION)
			end

			local w, h = container:GetSize()
			WrapWithGlow(fx, container, w, h, CDMPANDEMIC_OVERSCALE * table.Scale)

			fx.FX.anim:Play()
			fx:Show()
		end,
		OnStop = function(icon, table)
			local IconModule_IconContainer = icon:GetModuleOrModuleChild("IconModule_IconContainer", true, true)

			local fx = IconModule_IconContainer.container.cdmPandemic
			fx.FX.anim:Stop()
			fx:Hide()
		end,

		Persistent = {
			Build = function(parent)
				local fx = CreateFrame("Frame", nil, parent, cdmPandemicTemplate)

				-- Nothing will ever start it again: scripts don't fire on a descendant of the
				-- restricted button that hosts this.
				fx.FX.anim:Play()
				return fx
			end,
			Configure = function(fx, eventSettings, placement)
				local square = placement.square
				WrapWithGlow(fx, square.frame, square.width, square.height,
					CDMPANDEMIC_OVERSCALE * eventSettings.Scale)
				fx:SetFrameLevel(placement.level)
			end,
		},
	})
end






IconContainer:SetScriptHandler("OnEnter", function(Module, icon)
	-- While locked, an icon can be taking mouse motion purely so that it can show a
	-- tooltip (IconModule_IconTooltip). Lighting it up like a button is only right for
	-- the icons that are actually clickable.
	if TMW.Locked and not icon:IsMouseClickEnabled() then
		return
	end

	Module.container:LockHighlight()
end)
IconContainer:SetScriptHandler("OnLeave", function(Module, icon)
	Module.container:UnlockHighlight()
	Module.container:SetButtonState("NORMAL")
end)
IconContainer:SetScriptHandler("OnMouseDown", function(Module, icon)
	Module.container:SetButtonState("PUSHED")
end)
IconContainer:SetScriptHandler("OnMouseUp", function(Module, icon)
	Module.container:SetButtonState("NORMAL")
end)



