## [12.1.5.4] ##
### Fixed ###

  * fix: **guild and community roster names are no longer dimmed.** Blizzard raises the member list's inset above the rows so its border draws over them, and with Aurora's backdrop on it the inset covered every name. It now sits under the list [mainline/forever]
  * fix: **trainer list rows are skinned.** Only the skill step button had the skin, so every row kept Blizzard's dark row plate. Forever's category headers get a flat backdrop [mainline/forever]
  * fix: the divider above an open letter's attachments is hidden. The skin matched it by texture path, but `GetTexture()` returns a file ID, so the match never fired [mainline/forever]
  * fix: the profession window's Create and Create All buttons are skinned to match the template the page uses. On Forever that is `SharedButtonSmallTemplate`, whose red center plate and end caps showed through the old skin [forever]

## Detailed Changes ##
[12.1.5.4]: https://github.com/RealUI/Aurora/compare/12.1.5.3...12.1.5.4

