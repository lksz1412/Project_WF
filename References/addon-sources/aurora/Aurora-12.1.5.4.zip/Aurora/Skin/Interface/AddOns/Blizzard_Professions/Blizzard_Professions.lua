local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals CreateFrame next

--[[ Core ]]
local Aurora = private.Aurora
local Base, Hook, Skin = Aurora.Base, Aurora.Hook, Aurora.Skin
local Color, Util = Aurora.Color, Aurora.Util

do --[[ AddOns\Blizzard_Professions ]]
    function Skin.ProfessionsFrameTabTemplate(Button)
        Skin.PanelTabButtonTemplate(Button)
        Button._auroraTabResize = true
    end

    function Skin.NumericInputSpinnerTemplate(EditBox)
        if EditBox.Left then EditBox.Left:Hide() end
        if EditBox.Middle then EditBox.Middle:Hide() end
        if EditBox.Right then EditBox.Right:Hide() end
        Base.SetBackdrop(EditBox, Color.frame, Color.frame.a)
        if EditBox.DecrementButton then Skin.NavButtonPrevious(EditBox.DecrementButton) end
        if EditBox.IncrementButton then Skin.NavButtonNext(EditBox.IncrementButton) end
    end

    function Skin.ProfessionsButtonTemplate(Button)
        if Button.SlotBackground then Button.SlotBackground:SetAlpha(0) end
        if Button.IconBorder then Button.IconBorder:Hide() end
        Button:ClearNormalTexture()
        Base.SetBackdrop(Button, Color.black, Color.frame.a)
        Button._auroraIconBorder = Button
        if Button.Icon then
            Base.CropIcon(Button.Icon)
            Base.KeepIconCrop(Button.Icon)
        end
        -- The ItemButton intrinsic draws item textures on the lowercase `icon`
        -- child (SetItem path); the template's `Icon` is only assigned
        -- manually (currencies). Crop both (B40).
        if Button.icon then
            Base.CropIcon(Button.icon)
            Base.KeepIconCrop(Button.icon)
        end
        -- B40: match the action bar treatment on the state textures
        Base.CropIcon(Button:GetPushedTexture())
        Base.CropIcon(Button:GetHighlightTexture())
    end

    Hook.ProfessionsRecipeListCategoryMixin = {}
    function Hook.ProfessionsRecipeListCategoryMixin:Init(node)
        if not private.IsSkinned(self) then
            -- ProfessionsRecipeListCategoryTemplate inherits
            -- ListHeaderVisualTemplate, whose three-slice is Left/Middle/Right
            -- (Options_ListExpand_*) with a HighlightLeft/Middle/Right set over
            -- it. The old keys here -- LeftPiece/RightPiece/CenterPiece --
            -- exist nowhere in that template, so these headers were never
            -- actually skinned. **Not a Camelot difference: the template is
            -- byte-identical in both trees, so this was equally broken on
            -- retail.**
            for _, key in next, {"Left", "Middle", "Right"} do
                local region = self[key]
                if region then region:SetAlpha(0) end
            end

            -- The highlight trio keeps its job and loses Blizzard's art.
            for _, key in next, {"HighlightLeft", "HighlightMiddle", "HighlightRight"} do
                local region = self[key]
                if region then Util.SetHighlightColor(region, 0.2) end
            end

            private.SetSkinned(self, true)
        end
    end

    Hook.ProfessionsRecipeListRecipeMixin = {}
    function Hook.ProfessionsRecipeListRecipeMixin:Init(node)
        if not private.IsSkinned(self) then
            -- B40: replace the ornate gold selection/hover atlases with the
            -- simple flat row highlights used elsewhere in Aurora.
            local selected = self.SelectedOverlay
            if selected then
                selected:ClearAllPoints()
                selected:SetPoint("TOPLEFT")
                selected:SetPoint("BOTTOMRIGHT")
                Util.SetHighlightColor(selected, 0.3)
            end
            local highlight = self.HighlightOverlay
            if highlight then
                highlight:ClearAllPoints()
                highlight:SetPoint("TOPLEFT")
                highlight:SetPoint("BOTTOMRIGHT")
                Util.SetHighlightColor(highlight, 0.4)
            end
            private.SetSkinned(self, true)
        end
    end

    Hook.ProfessionsReagentSlotButtonMixin = {}
    function Hook.ProfessionsReagentSlotButtonMixin:Init()
        Util.SkinOnce(self, Skin.ProfessionsButtonTemplate)
        -- B40: the decorative circular ring around choice reagents fights the
        -- square Aurora slot; alpha 0 survives the SetShown toggling.
        if self.CropFrame then
            self.CropFrame:SetAlpha(0)
        end
    end
    function Hook.ProfessionsReagentSlotButtonMixin:SetModifyingRequired(isModifyingRequired)
        -- B40: Blizzard re-applies the rounded UI-Quickslot2 ring as the
        -- normal/pushed texture on every update, undoing the skin's
        -- ClearNormalTexture. The green "add" plus for optional reagents
        -- (isModifyingRequired) is functional and stays.
        if not isModifyingRequired then
            self:ClearNormalTexture()
            self:ClearPushedTexture()
        end
    end

    Hook.ProfessionsFlyoutButtonMixin = {}
    function Hook.ProfessionsFlyoutButtonMixin:Init(elementData, behavior)
        -- B40: the reagent-picker flyout items never got the standard icon
        -- treatment.
        Util.SkinOnce(self, Skin.ProfessionsButtonTemplate)
    end

    Hook.ProfessionsButtonMixin = {}
    function Hook.ProfessionsButtonMixin:SetSlotQuality(quality)
        if self._auroraIconBorder then
            if self.IconBorder then self.IconBorder:Hide() end
            Hook.SetItemButtonQuality(self, quality)
        end
    end
end

function Skin.ProfessionsRankBarTemplate(Frame)
    if Frame and Skin.ColoredProgressBarTemplate then
        Skin.ColoredProgressBarTemplate(Frame)
    end
end

-- Camelot folds the professions book into ProfessionsFrame as a page
-- (Blizzard_ProfessionsCrafting.xml's ProfessionsBookPageTemplate inherits
-- ProfessionsBookFrameTemplate, and Camelot's ProfessionsFrame.xml instantiates
-- it as parentKey="BookPage"). Retail keeps it as the standalone
-- ProfessionsBookFrame, which Camelot's TOC excludes -- so
-- Blizzard_ProfessionsBook's own skin bails there (T1.5) and the cards inside
-- this page were left stock: a tan Background per card with the panel already
-- dark around them.
--
-- The card templates keep their retail *names* and change shape, as usual:
-- Camelot adds Background and Overlay, drops IconBorder / Rank / $parentIcon,
-- and swaps ProfessionStatusBarTemplate for the Frame-based
-- ProfessionsRankBarTemplate.
local function SkinProfessionCard(Frame)
    if not Frame or private.IsSkinned(Frame) then return end
    private.SetSkinned(Frame, true)

    -- The card art. Background is the parchment plate; Overlay is the faded
    -- illustration on the secondary cards.
    if Frame.Background then Frame.Background:SetAlpha(0) end
    if Frame.Overlay then Frame.Overlay:SetAlpha(0) end

    Base.SetBackdrop(Frame, Color.button)

    if Frame.missingHeader then
        Frame.missingHeader:SetTextColor(Color.white:GetRGB())
    end
    if Frame.missingText then
        Frame.missingText:SetTextColor(Color.grayLight:GetRGB())
    end

    -- Primary cards carry two spell buttons, secondary cards up to four.
    for i = 1, 4 do
        local SpellButton = Frame["SpellButton" .. i]
        if SpellButton and Skin.ProfessionButtonTemplate then
            Skin.ProfessionButtonTemplate(SpellButton)
        end
    end

    -- ProfessionsRankBarTemplate is a Frame with a masked Fill, not a
    -- StatusBar -- the same shape as Camelot's ColoredProgressBarTemplate, and
    -- the same trap: Skin.FrameTypeStatusBar would throw on it. The green Fill
    -- is left alone: it is skill progress, not chrome.
    if Frame.StatusBar then
        Skin.ProfessionsRankBarTemplate(Frame.StatusBar)
    end

    -- The unlearn button sits bare next to the rank bar: a 20x20 Button whose
    -- only art is the Profession-button-red-crossmark atlas. The crossmark is
    -- the affordance and is kept; it just needs a frame under it.
    if Frame.UnlearnButton then
        Skin.FrameTypeButton(Frame.UnlearnButton)
    end
end

local function SkinCamelotBookPage(BookPage)
    local Content = BookPage and BookPage.ProfessionsContentFrame
    if not Content then return end

    SkinProfessionCard(Content.PrimaryProfession1)
    SkinProfessionCard(Content.PrimaryProfession2)
    for i = 1, 3 do
        SkinProfessionCard(Content["SecondaryProfession" .. i])
    end
end

function private.AddOns.Blizzard_Professions()
    local ProfessionsFrame = _G.ProfessionsFrame

    Skin.PortraitFrameTemplateNoCloseButton(ProfessionsFrame)

    if ProfessionsFrame.Bg then
        ProfessionsFrame.Bg:SetColorTexture(Color.panelBg:GetRGB())
        ProfessionsFrame.Bg:SetAllPoints(ProfessionsFrame.NineSlice)
        ProfessionsFrame.Bg:Show()
    end

    Skin.UIPanelCloseButton(ProfessionsFrame.CloseButton)
    -- Camelot replaces Blizzard_ProfessionsFrame.xml and drops the
    -- maximize/minimize toggle, so this is nil on Forever.
    if ProfessionsFrame.MaximizeMinimize then
        Skin.MaximizeMinimizeButtonFrameTemplate(ProfessionsFrame.MaximizeMinimize)
    end

    -- The TabSystem is declared by the flavor's own ProfessionsFrame.xml, not by
    -- the shared ProfessionsFrameBase, and Camelot's replacement does not have
    -- one -- it uses a single ProfessionsOverviewTab instead. (Skinning that tab
    -- is new-surface work, not a port of this loop.)
    if ProfessionsFrame.TabSystem then
        for i = 1, 3 do
            local tab = select(i, ProfessionsFrame.TabSystem:GetChildren())
            if tab then
                Skin.ProfessionsFrameTabTemplate(tab)
            end
        end
    end

    -- Camelot's replacement for that TabSystem: a column of side tabs down the
    -- right edge -- ProfessionsOverviewTab plus up to seven rightProfessionTabs.
    -- Both are LargeSideTabButtonTemplate underneath (the Wrapper adds only a
    -- fillToInterior KeyValue), so they take the same skin as the character
    -- panel's mode tabs, including its UpdateIconInterior hook -- fillToInterior
    -- is exactly what re-crops the icon and undoes Base.CropIcon without it.
    if ProfessionsFrame.ProfessionsOverviewTab then
        Skin.LargeSideTabButtonTemplate(ProfessionsFrame.ProfessionsOverviewTab)
    end
    for _, tab in next, (ProfessionsFrame.rightProfessionTabs or {}) do
        Skin.LargeSideTabButtonTemplate(tab)
    end

    SkinCamelotBookPage(ProfessionsFrame.BookPage)

    -- CraftingPage (Recipes tab) -----------------------------------------
    local CraftingPage = ProfessionsFrame.CraftingPage

    if not CraftingPage._auroraBackground then
        local bg = CraftingPage:CreateTexture(nil, "BACKGROUND", nil, -8)
        bg:SetColorTexture(Color.panelBg:GetRGB())
        bg:SetAllPoints(CraftingPage)
        CraftingPage._auroraBackground = bg
    end

    if CraftingPage.TutorialButton then
        CraftingPage.TutorialButton:Hide()
    end

    -- Concentration currency display on the rank-bar header row (B08/B40)
    if CraftingPage.ConcentrationDisplay and CraftingPage.ConcentrationDisplay.Icon then
        Base.CropIcon(CraftingPage.ConcentrationDisplay.Icon)
    end

    local RecipeList = CraftingPage.RecipeList
    if RecipeList then
        if RecipeList.Background then RecipeList.Background:SetAlpha(0) end
        Skin.SearchBoxTemplate(RecipeList.SearchBox)
        Skin.DropdownButton(RecipeList.FilterDropdown)
    end

    Util.Mixin(_G.ProfessionsRecipeListCategoryMixin, Hook.ProfessionsRecipeListCategoryMixin)

    if CraftingPage.MinimizedSearchBox then
        Skin.SearchBoxTemplate(CraftingPage.MinimizedSearchBox)
    end

    local SchematicForm = CraftingPage.SchematicForm
    if SchematicForm then
        local function HideSchematicBg(self)
            if self.Background then self.Background:SetAlpha(0) end
            if self.MinimalBackground then self.MinimalBackground:SetAlpha(0) end

            -- Camelot's SchematicFormCraftingTemplate is Mainline's plus a
            -- resize and one unnamed BORDER texture: a common-insideframe
            -- parchment panel with ornate corners. It carries no parentKey, so
            -- it has to be matched by atlas -- and the loop is confined to the
            -- form's own regions, since its children are the recipe content.
            for _, region in next, {self:GetRegions()} do
                if region:IsObjectType("Texture") then
                    local atlas = region:GetAtlas()
                    if atlas and atlas:find("common%-insideframe") then
                        region:SetAlpha(0)
                    end
                end
            end
            if self.NineSlice then
                for _, region in pairs({self.NineSlice:GetRegions()}) do
                    if region:IsObjectType("Texture") then region:SetAlpha(0) end
                end
            end
            local Details = self.Details
            if Details then
                if Details.BackgroundTop then Details.BackgroundTop:SetAlpha(0) end
                if Details.BackgroundBottom then Details.BackgroundBottom:SetAlpha(0) end
                if Details.BackgroundMiddle then Details.BackgroundMiddle:SetAlpha(0) end
                if Details.BackgroundMinimized then Details.BackgroundMinimized:SetAlpha(0) end
            end
        end
        HideSchematicBg(SchematicForm)
        SchematicForm:HookScript("OnShow", HideSchematicBg)
        if _G.ProfessionsRecipeSchematicFormMixin then
            _G.hooksecurefunc(_G.ProfessionsRecipeSchematicFormMixin, "Init", HideSchematicBg)
        end
        if _G.ProfessionsRecipeCrafterDetailsMixin then
            _G.hooksecurefunc(_G.ProfessionsRecipeCrafterDetailsMixin, "SetStats", function(self)
                if self.BackgroundTop then self.BackgroundTop:SetAlpha(0) end
                if self.BackgroundBottom then self.BackgroundBottom:SetAlpha(0) end
                if self.BackgroundMiddle then self.BackgroundMiddle:SetAlpha(0) end
                if self.BackgroundMinimized then self.BackgroundMinimized:SetAlpha(0) end
            end)
        else
            local frame = CreateFrame("Frame")
            frame:RegisterEvent("ADDON_LOADED")
            frame:SetScript("OnEvent", function(f, _, name)
                if name == "Blizzard_ProfessionsTemplates" and _G.ProfessionsRecipeCrafterDetailsMixin then
                    _G.hooksecurefunc(_G.ProfessionsRecipeCrafterDetailsMixin, "SetStats", function(self)
                        if self.BackgroundTop then self.BackgroundTop:SetAlpha(0) end
                        if self.BackgroundBottom then self.BackgroundBottom:SetAlpha(0) end
                        if self.BackgroundMiddle then self.BackgroundMiddle:SetAlpha(0) end
                        if self.BackgroundMinimized then self.BackgroundMinimized:SetAlpha(0) end
                    end)
                    f:UnregisterEvent("ADDON_LOADED")
                end
            end)
        end

        if SchematicForm.OutputIcon then
            Skin.CircularGiantItemButtonTemplate(SchematicForm.OutputIcon)
        end

        if SchematicForm.TrackRecipeCheckbox then
            Skin.UICheckButtonTemplate(SchematicForm.TrackRecipeCheckbox)
        end
        if SchematicForm.AllocateBestQualityCheckbox then
            Skin.UICheckButtonTemplate(SchematicForm.AllocateBestQualityCheckbox)
        end

        local Details = SchematicForm.Details
        if Details then
            local CraftingChoices = Details.CraftingChoicesContainer
            local ConcentrateContainer = CraftingChoices and CraftingChoices.ConcentrateContainer
            if ConcentrateContainer and ConcentrateContainer.ConcentrateToggleButton then
                local Btn = ConcentrateContainer.ConcentrateToggleButton
                Btn:ClearNormalTexture()
                Btn:ClearPushedTexture()
                Btn:ClearHighlightTexture()
                if Btn.CheckedTexture then Btn.CheckedTexture:SetAlpha(0) end
                if Btn.DisabledTexture then Btn.DisabledTexture:SetAlpha(0) end
                Base.SetBackdrop(Btn, Color.black, Color.frame.a)
                Btn._auroraIconBorder = Btn
                if Btn.Icon then Base.CropIcon(Btn.Icon) end
            end
        end
    end

    Util.Mixin(_G.ProfessionsReagentSlotButtonMixin, Hook.ProfessionsReagentSlotButtonMixin)
    Util.Mixin(_G.ProfessionsButtonMixin, Hook.ProfessionsButtonMixin)
    if _G.ProfessionsRecipeListRecipeMixin then
        Util.Mixin(_G.ProfessionsRecipeListRecipeMixin, Hook.ProfessionsRecipeListRecipeMixin)
    end
    if _G.ProfessionsFlyoutItemButtonMixin then
        Util.Mixin(_G.ProfessionsFlyoutItemButtonMixin, Hook.ProfessionsFlyoutButtonMixin)
    end
    if _G.ProfessionsFlyoutCurrencyButtonMixin then
        Util.Mixin(_G.ProfessionsFlyoutCurrencyButtonMixin, Hook.ProfessionsFlyoutButtonMixin)
    end

    -- Correction: these are **not** dropped on Camelot -- both buttons are
    -- visible in the crafting view. They are built in Lua by
    -- ProfessionsCraftingPageMixin:CreateControls (Blizzard_ProfessionsCrafting.lua:258)
    -- from GetButtonTemplate(), which runs *after* this skin, so the guards
    -- below simply found nil and skipped them. Hook the creation point as well;
    -- the sweep below still covers the case where controls already exist.
    --
    -- The template is the page's own choice: GetButtonTemplate() is
    -- UIPanelButtonTemplate on Mainline but SharedButtonSmallTemplate on
    -- Camelot (Camelot\Blizzard_ProfessionsCrafting.lua:28), a three-slice
    -- whose pieces are Left/Center/Right and are re-set on every state change.
    -- The UIPanelButton skin hides Left/Right once and never touches Center,
    -- so on Forever the red Center plate and the re-set end caps showed
    -- through. Skin with the skin that matches the template.
    local function SkinCreateButton(page, button)
        if not button then return end
        local template = page.GetButtonTemplate and page:GetButtonTemplate()
        local skin = template and Skin[template] or Skin.UIPanelButtonTemplate
        skin(button)
    end

    if CraftingPage.CreateControls then
        _G.hooksecurefunc(CraftingPage, "CreateControls", function(self)
            SkinCreateButton(self, self.CreateButton)
            SkinCreateButton(self, self.CreateAllButton)
        end)
    end

    SkinCreateButton(CraftingPage, CraftingPage.CreateButton)
    SkinCreateButton(CraftingPage, CraftingPage.CreateAllButton)
    if CraftingPage.ViewGuildCraftersButton then
        Skin.UIPanelButtonTemplate(CraftingPage.ViewGuildCraftersButton)
    end

    if CraftingPage.CreateMultipleInputBox then
        Skin.NumericInputSpinnerTemplate(CraftingPage.CreateMultipleInputBox)
    end

    if CraftingPage.InventorySlots then
        for _, slot in ipairs(CraftingPage.InventorySlots) do
            Skin.FrameTypeItemButton(slot)
        end
    end

    if CraftingPage.LinkButton then
        local btn = CraftingPage.LinkButton
        btn:SetSize(19, 19)
        btn:ClearNormalTexture()
        btn:ClearPushedTexture()
        if btn.Texture then btn.Texture:Hide() end
        Base.SetBackdrop(btn, Color.button)
        btn:ClearAllPoints()
        btn:SetPoint("LEFT", CraftingPage.RankBar, "RIGHT", 0, -3)
        -- B40: at 8px with a 30% center crop the chain glyph read as an empty
        -- slot next to the rank bar; a wider crop at 13px is legible.
        local icon = btn:CreateTexture(nil, "ARTWORK")
        icon:SetTexture([[Interface\Buttons\UI-LinkProfession-Up]])
        icon:SetTexCoord(.25, .75, .25, .75)
        icon:SetSize(13, 13)
        icon:SetPoint("CENTER")
        local pushedIcon = btn:CreateTexture(nil, "ARTWORK")
        pushedIcon:SetTexture([[Interface\Buttons\UI-LinkProfession-Down]])
        pushedIcon:SetTexCoord(.25, .75, .25, .75)
        pushedIcon:SetSize(13, 13)
        pushedIcon:SetPoint("CENTER")
        pushedIcon:Hide()
        btn:HookScript("OnMouseDown", function() icon:Hide(); pushedIcon:Show() end)
        btn:HookScript("OnMouseUp",   function() pushedIcon:Hide(); icon:Show() end)
    end

    local RankBar = CraftingPage.RankBar
    if RankBar then
        if RankBar.Background then RankBar.Background:SetAlpha(0) end
        if RankBar.Border then RankBar.Border:SetAlpha(0) end
        local dropdown = RankBar.ExpansionDropdownButton
        if dropdown then
            Skin.DropdownButton(dropdown)
            dropdown:SetFrameStrata("HIGH")
            dropdown:SetFrameLevel(5)
        end

        if RankBar.Rank then
            RankBar.Rank:SetFrameStrata("HIGH")
            RankBar.Rank:SetFrameLevel(10)
        end

        if RankBar.Fill then RankBar.Fill:Hide() end
        if RankBar.Flare then RankBar.Flare:Hide() end

        local bar = CreateFrame("Frame", nil, RankBar)
        bar:SetFrameStrata("HIGH")
        bar:SetFrameLevel(1)
        bar:SetPoint("TOPLEFT",     RankBar, "TOPLEFT",     0,  -3)
        bar:SetPoint("BOTTOMRIGHT", RankBar, "BOTTOMRIGHT", -31, -4)

        local bg = bar:CreateTexture(nil, "BACKGROUND", nil, -1)
        bg:SetColorTexture(Color.black:GetRGBA())
        bg:SetAllPoints(bar)

        local r, g, b = Color.blue:GetRGB()
        local fill = bar:CreateTexture(nil, "BACKGROUND", nil, 0)
        fill:SetColorTexture(r, g, b, 1)
        fill:SetPoint("TOPLEFT")
        fill:SetPoint("BOTTOMLEFT")

        RankBar._auroraBar = {container = bar, fill = fill}

        _G.hooksecurefunc(RankBar, "Update", function(self, professionInfo)
            if self.Fill then self.Fill:Hide() end
            if self.Flare then self.Flare:Hide() end

            local ratio = 0
            if professionInfo.maxSkillLevel > 0 then
                ratio = math.min(professionInfo.skillLevel / professionInfo.maxSkillLevel, 1)
            end
            local a = self._auroraBar
            local w = a.container:GetWidth()
            if w == 0 then w = self:GetWidth() - 2 end
            if ratio > 0 and w > 0 then
                a.fill:SetWidth(w * ratio)
                a.fill:Show()
            else
                a.fill:Hide()
            end
        end)
    end

    -- Camelot's ProfessionsFrame declares only BookPage, CraftingPage,
    -- ProfessionsOverviewTab and TabIndicators: specializations and crafting
    -- orders are both retail-only systems, so neither page exists. The two
    -- sections below index their page unguarded, and nothing follows
    -- OrdersPage, so bail here rather than wrap ~200 lines in a conditional.
    -- Checked together because they stand or fall together on every flavor
    -- that has them; split this if one ever ships without the other.
    if not (ProfessionsFrame.SpecPage and ProfessionsFrame.OrdersPage) then
        return
    end

    -- SpecPage -----------------------------------------------------------
    local SpecPage = ProfessionsFrame.SpecPage

    if not SpecPage._auroraBackground then
        local bg = SpecPage:CreateTexture(nil, "BACKGROUND", nil, -8)
        bg:SetColorTexture(Color.panelBg:GetRGB())
        bg:SetAllPoints(SpecPage)
        SpecPage._auroraBackground = bg
    end

    if SpecPage.Background then SpecPage.Background:SetAlpha(0) end
    if SpecPage.BlackBG then SpecPage.BlackBG:Hide() end

    if SpecPage.PanelFooter then
        for _, region in pairs({SpecPage.PanelFooter:GetRegions()}) do
            if region:IsObjectType("Texture") then
                region:SetAlpha(0)
            end
        end
    end

    -- Blizzard's ProfessionSpecTabMixin:SetState anchors the lock/state icon to
    -- Text's RIGHT edge. Aurora's tab skin sets Text to fill the whole tab, so
    -- that anchor lands on the tab's edge and the lock bleeds into the next tab.
    -- Re-anchor it inside the tab after every SetState.
    local function SpecTabSetState(tab)
        if tab.StateIcon and tab.StateIcon:IsShown() then
            tab.StateIcon:ClearAllPoints()
            tab.StateIcon:SetPoint("RIGHT", tab, "RIGHT", -6, 0)
        end
    end
    local function SkinSpecTab(tab)
        if private.IsSkinned(tab) then return end
        private.SetSkinned(tab, true)
        Skin.TabSystemButtonTemplate(tab)
        if tab.BottomBorderGlow then tab.BottomBorderGlow:SetAlpha(0) end
        if tab.SetState then
            _G.hooksecurefunc(tab, "SetState", SpecTabSetState)
            SpecTabSetState(tab)
        end
    end
    if SpecPage.ButtonsParent then
        for _, child in ipairs({SpecPage.ButtonsParent:GetChildren()}) do
            if child.Left and child.LeftActive then
                SkinSpecTab(child)
            end
        end
    end
    if _G.ProfessionSpecTabMixin then
        _G.hooksecurefunc(_G.ProfessionSpecTabMixin, "OnLoad", SkinSpecTab)
    end

    if SpecPage.UndoButton then Skin.SquareIconButtonTemplate(SpecPage.UndoButton) end

    local TreeView = SpecPage.TreeView
    if TreeView and TreeView.Background then TreeView.Background:SetAlpha(0) end

    local TreePreview = SpecPage.TreePreview
    if TreePreview and TreePreview.Background then
        TreePreview.Background:SetColorTexture(Color.panelBg:GetRGB())
    end

    local DetailedView = SpecPage.DetailedView
    if DetailedView then
        if DetailedView.Background then DetailedView.Background:SetAlpha(0) end
        if DetailedView.SpendPointsButton then
            Skin.UIPanelButtonTemplate(DetailedView.SpendPointsButton)
        end
        if DetailedView.UnlockPathButton then
            Skin.UIPanelButtonTemplate(DetailedView.UnlockPathButton)
        end
    end

    if SpecPage.UnspentPoints and SpecPage.UnspentPoints.CurrencyBackground then
        SpecPage.UnspentPoints.CurrencyBackground:SetAlpha(0)
    end

    for _, divider in ipairs({SpecPage.VerticalDivider, SpecPage.TopDivider}) do
        if divider then
            for _, region in pairs({divider:GetRegions()}) do
                if region:IsObjectType("Texture") then region:SetAlpha(0) end
            end
        end
    end

    if SpecPage.ApplyButton then Skin.UIPanelButtonTemplate(SpecPage.ApplyButton) end
    if SpecPage.UnlockTabButton then Skin.UIPanelButtonTemplate(SpecPage.UnlockTabButton) end
    if SpecPage.ViewTreeButton then Skin.UIPanelButtonTemplate(SpecPage.ViewTreeButton) end
    if SpecPage.BackToPreviewButton then Skin.UIPanelButtonTemplate(SpecPage.BackToPreviewButton) end
    if SpecPage.ViewPreviewButton then Skin.UIPanelButtonTemplate(SpecPage.ViewPreviewButton) end
    if SpecPage.BackToFullTreeButton then Skin.UIPanelButtonTemplate(SpecPage.BackToFullTreeButton) end

    if SpecPage.UpdateSpecBackground then
        _G.hooksecurefunc(SpecPage, "UpdateSpecBackground", function(self)
            if self.Background then self.Background:SetAlpha(0) end
            if self.BlackBG then self.BlackBG:Hide() end
        end)
    end

    -- OrdersPage ---------------------------------------------------------
    local OrdersPage = ProfessionsFrame.OrdersPage

    if not OrdersPage._auroraBackground then
        local bg = OrdersPage:CreateTexture(nil, "BACKGROUND", nil, -8)
        bg:SetColorTexture(Color.panelBg:GetRGB())
        bg:SetAllPoints(OrdersPage)
        OrdersPage._auroraBackground = bg
    end

    local BrowseFrame = OrdersPage.BrowseFrame
    if BrowseFrame then
        local BrowseRecipeList = BrowseFrame.RecipeList
        if BrowseRecipeList then
            if BrowseRecipeList.Background then BrowseRecipeList.Background:SetAlpha(0) end
            if BrowseRecipeList.SearchBox then Skin.SearchBoxTemplate(BrowseRecipeList.SearchBox) end
            if BrowseRecipeList.CollapseAllButton then
                Skin.UIPanelButtonTemplate(BrowseRecipeList.CollapseAllButton)
            end
            if BrowseRecipeList.FilterDropdown then
                Skin.DropdownButton(BrowseRecipeList.FilterDropdown)
            end
        end

        if BrowseFrame.FavoritesSearchButton then
            Skin.SquareIconButtonTemplate(BrowseFrame.FavoritesSearchButton)
        end

        if BrowseFrame.SearchButton then Skin.UIPanelButtonTemplate(BrowseFrame.SearchButton) end
        if BrowseFrame.BackButton then Skin.UIPanelButtonTemplate(BrowseFrame.BackButton) end

        local function HideOrderTypeTabLayers(tab)
            if tab.Glow then tab.Glow:SetAlpha(0) end
            if tab.LeftActive then tab.LeftActive:SetAlpha(0) end
            if tab.MiddleActive then tab.MiddleActive:SetAlpha(0) end
            if tab.RightActive then tab.RightActive:SetAlpha(0) end
            if tab.LeftHighlight then tab.LeftHighlight:SetAlpha(0) end
            if tab.MiddleHighlight then tab.MiddleHighlight:SetAlpha(0) end
            if tab.RightHighlight then tab.RightHighlight:SetAlpha(0) end
        end

        local function SkinOrderTypeTab(tab)
            if not private.IsSkinned(tab) then
                private.SetSkinned(tab, true)
                Skin.TabSystemButtonTemplate(tab)

                -- Store Aurora's intended size for CraftSim resilience
                tab._auroraTabWidth, tab._auroraTabHeight = tab:GetSize()

                -- Clamp back if another addon oversizes the tab (>150% of Aurora's values)
                _G.hooksecurefunc(tab, "SetSize", function(self, newW, newH)
                    if self._auroraTabWidth and (newW > self._auroraTabWidth * 1.5 or newH > self._auroraTabHeight * 1.5) then
                        self:SetSize(self._auroraTabWidth, self._auroraTabHeight)
                    end
                end)

                if tab.SetTabSelected then
                    _G.hooksecurefunc(tab, "SetTabSelected", HideOrderTypeTabLayers)
                end
            end

            HideOrderTypeTabLayers(tab)
        end
        for _, tab in ipairs({
            BrowseFrame.PublicOrdersButton,
            BrowseFrame.GuildOrdersButton,
            BrowseFrame.NpcOrdersButton,
            BrowseFrame.PersonalOrdersButton,
        }) do
            if tab then SkinOrderTypeTab(tab) end
        end
        if BrowseFrame.orderTypeTabs then
            for _, tab in ipairs(BrowseFrame.orderTypeTabs) do
                SkinOrderTypeTab(tab)
            end
        end

        -- OrderList area
        local OrderList = BrowseFrame.OrderList
        if OrderList then
            if OrderList.Background then OrderList.Background:SetAlpha(0) end
            if OrderList.NineSlice then
                for _, region in pairs({OrderList.NineSlice:GetRegions()}) do
                    if region:IsObjectType("Texture") then region:SetAlpha(0) end
                end
            end
        end

        local ORD = BrowseFrame.OrdersRemainingDisplay
        if ORD then
            if ORD.Background then ORD.Background:SetAlpha(0) end
            Base.SetBackdrop(ORD, Color.frame)
        end
    end

    local OrderView = OrdersPage.OrderView
    if OrderView then
        if OrderView.ConcentrationDisplay and OrderView.ConcentrationDisplay.Icon then
            Base.CropIcon(OrderView.ConcentrationDisplay.Icon)
        end
        local OrderInfo = OrderView.OrderInfo
        if OrderInfo then
            if OrderInfo.Background then OrderInfo.Background:SetAlpha(0) end
            if OrderInfo.NineSlice then
                for _, region in pairs({OrderInfo.NineSlice:GetRegions()}) do
                    if region:IsObjectType("Texture") then region:SetAlpha(0) end
                end
            end
            if OrderInfo.CutDivider then OrderInfo.CutDivider:SetAlpha(0) end

            local NoteBox = OrderInfo.NoteBox
            if NoteBox and NoteBox.Background and NoteBox.Background.Border then
                NoteBox.Background.Border:SetAlpha(0)
            end

            local NPCRewardsFrame = OrderInfo.NPCRewardsFrame
            if NPCRewardsFrame and NPCRewardsFrame.Background then
                NPCRewardsFrame.Background:SetAlpha(0)
            end

            if OrderInfo.SocialDropdown then
                Base.SetBackdrop(OrderInfo.SocialDropdown, Color.button)
            end

            if OrderInfo.BackButton then Skin.UIPanelButtonTemplate(OrderInfo.BackButton) end
            if OrderInfo.StartOrderButton then Skin.UIPanelButtonTemplate(OrderInfo.StartOrderButton) end
            if OrderInfo.DeclineOrderButton then Skin.UIPanelButtonTemplate(OrderInfo.DeclineOrderButton) end
            if OrderInfo.ReleaseOrderButton then Skin.UIPanelButtonTemplate(OrderInfo.ReleaseOrderButton) end
        end

        local OrderDetails = OrderView.OrderDetails
        if OrderDetails then
            if OrderDetails.Background then OrderDetails.Background:SetAlpha(0) end
            if OrderDetails.NineSlice then
                for _, region in pairs({OrderDetails.NineSlice:GetRegions()}) do
                    if region:IsObjectType("Texture") then region:SetAlpha(0) end
                end
            end
            local FulfillmentForm = OrderDetails.FulfillmentForm
            if FulfillmentForm then
                local NoteEditBox = FulfillmentForm.NoteEditBox
                if NoteEditBox and NoteEditBox.Border then
                    NoteEditBox.Border:SetAlpha(0)
                end
            end
        end

        local OVRankBar = OrderView.RankBar
        if OVRankBar then
            if OVRankBar.Background then OVRankBar.Background:SetAlpha(0) end
            if OVRankBar.Border then OVRankBar.Border:SetAlpha(0) end
            local ovDropdown = OVRankBar.ExpansionDropdownButton
            if ovDropdown then
                Skin.DropdownButton(ovDropdown)
                ovDropdown:SetFrameStrata("HIGH")
                ovDropdown:SetFrameLevel(5)
            end
            if OVRankBar.Rank then
                OVRankBar.Rank:SetFrameStrata("HIGH")
                OVRankBar.Rank:SetFrameLevel(10)
            end
            if OVRankBar.Fill then OVRankBar.Fill:Hide() end
            if OVRankBar.Flare then OVRankBar.Flare:Hide() end

            local ovBar = CreateFrame("Frame", nil, OVRankBar)
            ovBar:SetFrameStrata("HIGH")
            ovBar:SetFrameLevel(1)
            ovBar:SetPoint("TOPLEFT",     OVRankBar, "TOPLEFT",     0,  -3)
            ovBar:SetPoint("BOTTOMRIGHT", OVRankBar, "BOTTOMRIGHT", -31, -4)
            local ovBg = ovBar:CreateTexture(nil, "BACKGROUND", nil, -1)
            ovBg:SetColorTexture(Color.black:GetRGBA())
            ovBg:SetAllPoints(ovBar)
            local r, g, b = Color.blue:GetRGB()
            local ovFill = ovBar:CreateTexture(nil, "BACKGROUND", nil, 0)
            ovFill:SetColorTexture(r, g, b, 1)
            ovFill:SetPoint("TOPLEFT")
            ovFill:SetPoint("BOTTOMLEFT")
            OVRankBar._auroraBar = {container = ovBar, fill = ovFill}

            _G.hooksecurefunc(OVRankBar, "Update", function(self, professionInfo)
                if self.Fill then self.Fill:Hide() end
                if self.Flare then self.Flare:Hide() end
                local ratio = 0
                if professionInfo.maxSkillLevel > 0 then
                    ratio = math.min(professionInfo.skillLevel / professionInfo.maxSkillLevel, 1)
                end
                local a = self._auroraBar
                local w = a.container:GetWidth()
                if w == 0 then w = self:GetWidth() - 2 end
                if ratio > 0 and w > 0 then
                    a.fill:SetWidth(w * ratio)
                    a.fill:Show()
                else
                    a.fill:Hide()
                end
            end)
        end

        if OrderView.CreateButton then Skin.UIPanelButtonTemplate(OrderView.CreateButton) end
        if OrderView.CompleteOrderButton then Skin.UIPanelButtonTemplate(OrderView.CompleteOrderButton) end
        if OrderView.StartRecraftButton then Skin.UIPanelButtonTemplate(OrderView.StartRecraftButton) end
        if OrderView.StopRecraftButton then Skin.UIPanelButtonTemplate(OrderView.StopRecraftButton) end

        local DeclineOrderDialog = OrderView.DeclineOrderDialog
        if DeclineOrderDialog then
            if DeclineOrderDialog.Background then DeclineOrderDialog.Background:SetAlpha(0) end
            local DODNote = DeclineOrderDialog.NoteEditBox
            if DODNote and DODNote.Border then DODNote.Border:SetAlpha(0) end
            if DeclineOrderDialog.CancelButton then
                Skin.UIPanelButtonTemplate(DeclineOrderDialog.CancelButton)
            end
            if DeclineOrderDialog.ConfirmButton then
                Skin.UIPanelButtonTemplate(DeclineOrderDialog.ConfirmButton)
            end
        end
    end

    if _G.ProfessionsCraftingOrderPageMixin then
        _G.hooksecurefunc(_G.ProfessionsCraftingOrderPageMixin, "Refresh", function(self)
            local bg = self.OrderView and self.OrderView.OrderDetails and self.OrderView.OrderDetails.Background
            if bg then bg:SetAlpha(0) end
        end)
    end
end
