local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals next ipairs

--[[ Core ]]
local Aurora = private.Aurora
local Base = Aurora.Base
local Skin = Aurora.Skin
local Util = Aurora.Util

-- This addon ships per-family variants and Aurora's skin was written against
-- the Classic ones. Forever loads the Mainline variants, where the lists use
-- MinimalScrollBar instead of WowClassicScrollBar (Mainline\…_Browse.xml vs
-- Classic\…_Browse.xml). Skin.WowClassicScrollBar is itself only registered by
-- Blizzard_SharedXML\Classic\, which the Forever manifest does not include, so
-- calling it there is a nil call, not just the wrong look.
local function SkinScrollBar(ScrollBar)
    if not ScrollBar then return end
    if private.isForever then
        Skin.MinimalScrollBar(ScrollBar)
    else
        Skin.WowClassicScrollBar(ScrollBar)
    end
end

-- LFGVanillaTabButtonTemplate has a different base per flavor: the classic
-- clients load Classic\LFGVanillaTabTemplates.xml, where it inherits
-- CharacterFrameTabButtonTemplate, while Forever loads Mainline\Templates.xml,
-- where it inherits PanelTabButtonTemplate. Aurora's
-- Skin.CharacterFrameTabButtonTemplate is also only registered by the
-- Cata/Classic FrameXML skins, which the Forever manifest does not include.
-- Kept out of the addon function: inlined, the and/or pick tipped it over the
-- cyclomatic complexity limit.
local function SkinTab(Tab)
    if not Tab then return end
    if private.isForever then
        Skin.PanelTabButtonTemplate(Tab)
    else
        Skin.CharacterFrameTabButtonTemplate(Tab)
    end
end

--[[ Vanilla-style Group Finder (era-only addon).
    Evidence: wow-ui-source-era/Interface/AddOns/Blizzard_GroupFinder_VanillaStyle/
    Blizzard_LFGVanilla_{ParentFrame,Browse,Listing}.xml — LFGParentFrame is a
    plain 384x512 shell (chrome art lives on the Browse/Listing child panels
    as UI-LFG-FRAME sheets + a groupfinder-background-classic parchment inset);
    two CharacterFrameTab buttons, an unnamed UIPanelCloseButton, the animated
    LFG eye as portrait. Legacy UIDropDownMenu dropdowns; modern
    WowScrollBoxList + WowClassicScrollBar lists.

    NOT touched: the LFGListingComment EditBox (Blizzard secure-references it
    and disables SetText/paste — anti-automation hardening; only its
    UIPanelInputScrollFrameTemplate container is skinned), the role icon
    buttons and gear OptionsButtons (meaningful icon art), and the LFG eye
    animation (active-queue indicator).
]]

--[[ Row templates (deferred in the first pass; added 2026-09-13).

    All three row families are recycled by their container, so each is skinned
    from an update/add hook rather than once at load:
      * Browse results   -- WowScrollBoxList + LFGBrowseSearchEntryTemplate
                            (Blizzard_LFGVanilla_Browse.lua:58-65)
      * Listing rows     -- CreateScrollBoxListTreeListView + LFGListingActivityRowTemplate
                            (Blizzard_LFGVanilla_Listing.lua:741+)
      * Category buttons -- created lazily into CategoryView.CategoryButtons by
                            LFGListingCategorySelection_AddButton (Listing.lua:704-716)

    ScrollBox:ForEachFrame hands the callback `(frame, elementData)` with no
    owner (ScrollBoxListView.lua:152), so these take the frame first.

    Kept, per the "NOT touched" policy above: the party/class/newcomer icons on
    a result row, the Enumerate and Solo role art, and the category icons --
    all of it carries meaning. What gets recoloured is the ADD-blended
    highlight/selected bars, the parts that actually fight the theme; the blend
    reset plus Aurora's highlight colour is the same treatment the classic
    AuctionUI rows use (Blizzard_AuctionUI/Classic/Blizzard_AuctionUI.lua:32-41).
]]
local function SkinHighlight(texture, alpha)
    if not texture then return end
    texture:SetBlendMode("BLEND")
    Util.SetHighlightColor(texture, alpha)
end

local function SkinRoleCount(Frame)
    -- RoleCountNoScriptsTemplate. Skin.RoleCountNoScriptsTemplate is Mainline-only,
    -- so the three swaps are inlined; the parentKeys match the era template at
    -- Blizzard_UIPanelTemplates/Classic/UIPanelTemplates.xml:323 and Forever's
    -- RoleCountLargeNoScriptsTemplate (large role atlases, same keys). Base.SetTexture
    -- is safe to repeat on a recycled frame (texture.lua tracks what it built).
    if not Frame then return end
    if Frame.TankIcon then Base.SetTexture(Frame.TankIcon, "iconTANK") end
    if Frame.HealerIcon then Base.SetTexture(Frame.HealerIcon, "iconHEALER") end
    if Frame.DamagerIcon then Base.SetTexture(Frame.DamagerIcon, "iconDAMAGER") end
end

local function SkinSearchEntry(Button)
    if not Button or private.IsSkinned(Button) then return end
    private.SetSkinned(Button, true)

    -- Forever 70009 rows (entry, nested entry and grouping header) carry a
    -- ResultBG list-button atlas; Aurora draws its own flat row instead.
    if Button.ResultBG then
        Button.ResultBG:SetAlpha(0)
        -- list-row idiom, as the Communities roster rows
        Base.SetBackdrop(Button, Aurora.Color.button, Aurora.Color.frame.a)
    end

    -- groupfinder-highlightbar-yellow / -blue
    SkinHighlight(Button.Selected, 0.5)
    SkinHighlight(Button.Highlight, 0.2)

    if Button.DataDisplay then
        SkinRoleCount(Button.DataDisplay.RoleCount)
    end
end

local function SkinActivityRow(Frame)
    if not Frame or private.IsSkinned(Frame) then return end
    private.SetSkinned(Frame, true)

    -- Raw CheckButton carrying the stock UI-CheckBox-* art, which is what the
    -- classic Skin.UICheckButtonTemplate expects even though the XML does not
    -- inherit the template (Blizzard_LFGVanilla_Listing.xml:168).
    if Frame.CheckButton then
        Skin.UICheckButtonTemplate(Frame.CheckButton)
    end

    -- ExpandOrCollapseButton left alone: Skin.ExpandOrCollapse is Mainline-only
    -- and the stock +/- art stays legible against the dark backdrop, so a
    -- half-port would look worse than none.
end

local function SkinCategoryButton(Button)
    if not Button or private.IsSkinned(Button) then return end
    private.SetSkinned(Button, true)

    if Button.Cover then
        Button.Cover:SetAlpha(0)  -- groupfinder-button-cover gradient over the icon
    end
    SkinHighlight(Button.SelectedTexture, 0.5)
    SkinHighlight(Button.HighlightTexture or Button:GetHighlightTexture(), 0.2)
end

-- Square icon buttons (common-button-tertiary-square-*): strip the frame
-- states, keep the Icon. Same treatment as Browse's refresh button.
local function SkinSquareIconButton(Button)
    if not Button then return end
    Button:SetNormalTexture("")
    Button:SetPushedTexture("")
    Button:ClearHighlightTexture()
    Skin.FrameTypeButton(Button)
end

local function SkinWhoButton(Button)
    if not Button or private.IsSkinned(Button) then return end
    private.SetSkinned(Button, true)

    -- Flat row like the Browse results (common-button-list-large art out)
    if Button.Background then
        Button.Background:SetAlpha(0)
        Base.SetBackdrop(Button, Aurora.Color.button, Aurora.Color.frame.a)
    end

    -- common-button-list-large-selected / -hover
    SkinHighlight(Button.Selected, 0.5)
    SkinHighlight(Button:GetHighlightTexture(), 0.2)
    SkinSquareIconButton(Button.InviteButton)
end

-- Forever 70009 restyled the Mainline variant (LFGVANILLA_SETTING_MODERN_STYLE):
-- each panel is now a PortraitFrameTemplateNoCloseButton filling the parent,
-- whose NineSlice (frame level 500) drew Blizzard's metal border over Aurora's
-- backdrop. Strip each panel's chrome so the parent's backdrop is the frame.
-- SetAlpha, not Hide: NineSlice layouts re-show their pieces.
local function StripPanel(Panel)
    if not Panel then return end
    for _, key in ipairs({"NineSlice", "Bg", "TopTileStreaks", "PortraitContainer", "BarTop", "BarMiddle"}) do
        if Panel[key] then
            Panel[key]:SetAlpha(0)
        end
    end
    -- LFGBrowseFrame redefines `Bg` (the header stone) under the template's
    -- own name, $parentBg, which orphans the template's full-panel background:
    -- neither .Bg nor the global points at it any more. Every BACKGROUND
    -- texture the panel itself owns is art Aurora replaces, so sweep them.
    for _, region in ipairs({Panel:GetRegions()}) do
        if region:IsObjectType("Texture") and region:GetDrawLayer() == "BACKGROUND" then
            region:SetAlpha(0)
        end
    end
    local Inset = Panel.Inset
    if Inset then
        if Inset.Border then Inset.Border:SetAlpha(0) end
        if Inset.CustomBG then Inset.CustomBG:SetAlpha(0) end
    end
end

-- Who tab (Tab3). Forever loads [Family]\WhoList.xml, where the Who list that
-- Camelot cut from FriendsFrame lives now; restyled with a filter dropdown and
-- per-row invite buttons in 1.60.1.70009. Kept out of the addon function for
-- the same complexity reason as SkinTab.
local function SkinWhoList()
    local Who = _G.LFGWhoListFrame
    if not Who then return end

    SkinTab(_G.LFGParentFrameTab3)
    StripPanel(Who)

    for _, key in ipairs({"BackgroundArt", "headerBackground", "insideFrame", "BarTop", "BarMiddle"}) do
        if Who[key] then
            Who[key]:SetAlpha(0)
        end
    end

    if Who.EditBox then
        Skin.SearchBoxTemplate(Who.EditBox)
    end
    SkinSquareIconButton(Who.WhoSearch)
    if Who.FilterDropdown then
        Skin.FilterButton(Who.FilterDropdown)
    end

    SkinScrollBar(Who.ScrollBar)
    if Who.ScrollBox then
        Skin.WowScrollBoxList(Who.ScrollBox)
        _G.hooksecurefunc(Who.ScrollBox, "Update", function(self)
            self:ForEachFrame(SkinWhoButton)
        end)
    end
end

-- Modern style only (Forever): the parts of the 70009 restyle outside the
-- three panels' chrome. Kept out of the addon function for the complexity limit.
local function SkinModernStyle(LFGParentFrame)
    if not LFGParentFrame.ListingTab then return end

    -- The panels fill the whole 458x535 frame now; the classic sheet's
    -- art-bound offsets no longer apply.
    LFGParentFrame:SetBackdropOption("offsets", {
        left = 0,
        right = 0,
        top = 0,
        bottom = 0,
    })

    -- Named now ($parentCloseButton), so the unnamed-child sweep misses it.
    -- Inherits UIPanelCloseButtonDefaultAnchors since Forever 70450.
    if _G.LFGParentFrameCloseButton then
        Skin.UIPanelCloseButtonDefaultAnchors(_G.LFGParentFrameCloseButton)
    end

    -- The bottom Tab1-3 are hidden in modern style; these right-side tabs
    -- replace them.
    Skin.LargeSideTabButtonTemplate(LFGParentFrame.ListingTab)
    Skin.LargeSideTabButtonTemplate(LFGParentFrame.BrowsingTab)
    Skin.LargeSideTabButtonTemplate(LFGParentFrame.WhoListingTab)

    StripPanel(_G.LFGBrowseFrame)

    local Listing = _G.LFGListingFrame
    StripPanel(Listing)
    if _G.LFGListingFrameRoleBackground then
        _G.LFGListingFrameRoleBackground:SetAlpha(0) -- groupfinder-roles-background
    end
    if Listing.DividerFrame then
        Listing.DividerFrame:SetAlpha(0) -- common-framedivider, metal
    end
    local ActivityView = Listing.ActivityView
    if ActivityView then
        if ActivityView.BarTop then ActivityView.BarTop:SetAlpha(0) end
        local levelRanges = ActivityView.LevelRangesCheckbox
        if levelRanges and levelRanges.Checkbox then
            Skin.UICheckButtonTemplate(levelRanges.Checkbox)
        end
    end
end

local function SkinActivityView(ActivityView)
    if not ActivityView then return end
    for _, key in ipairs({"BarLeft", "BarMiddle", "BarRight"}) do
        if ActivityView[key] then
            ActivityView[key]:SetAlpha(0)
        end
    end
    if ActivityView.ScrollBar then
        SkinScrollBar(ActivityView.ScrollBar)
    end
    if ActivityView.ScrollBox then
        Skin.WowScrollBoxList(ActivityView.ScrollBox)
        _G.hooksecurefunc(ActivityView.ScrollBox, "Update", function(self)
            self:ForEachFrame(SkinActivityRow)
        end)
    end
    -- Container chrome only — the EditBox inside is secure (see header)
    if ActivityView.Comment then
        Skin.UIPanelInputScrollFrameTemplate(ActivityView.Comment)
    end
    -- Forever 1.60.1.70205: a WowStyle1 playstyle dropdown that must be
    -- set before a listing can be posted. Absent on the classic clients.
    if ActivityView.PlayStyleDropdown then
        Skin.DropdownButton(ActivityView.PlayStyleDropdown)
    end
    -- Forever 1.60.1.70291: the voice chat choice (Discord as a second
    -- voice provider), the same WowStyle1 template.
    if ActivityView.VoiceChatDropdown then
        Skin.DropdownButton(ActivityView.VoiceChatDropdown)
    end
end

function private.AddOns.Blizzard_GroupFinder_VanillaStyle()
    local LFGParentFrame = _G.LFGParentFrame

    Skin.FrameTypeFrame(LFGParentFrame)
    -- Art bounds of the classic 384x512 sheet (from the frame's HitRectInsets)
    LFGParentFrame:SetBackdropOption("offsets", {
        left = 0,
        right = 30,
        top = 0,
        bottom = 74,
    })

    SkinTab(_G.LFGParentFrameTab1)
    SkinTab(_G.LFGParentFrameTab2)

    -- The close button is the only unnamed direct Button child
    for _, child in next, {LFGParentFrame:GetChildren()} do
        if child:GetObjectType() == "Button" and not child:GetName() then
            Skin.UIPanelCloseButton(child)
        end
    end

    -- Portrait ring behind the animated LFG eye (the eye itself is kept)
    if _G.LFGParentFramePortraitIcon then
        _G.LFGParentFramePortraitIcon:SetAlpha(0)
    end

    ------------
    -- Browse --
    ------------
    local Browse = _G.LFGBrowseFrame
    for _, name in ipairs({"LFGBrowseFrameFrameBackgroundTop", "LFGBrowseFrameFrameBackgroundMiddle", "LFGBrowseFrameFrameBackgroundBottom"}) do
        local texture = _G[name]
        if texture then
            texture:SetTexture("")
        end
    end
    if Browse.BackgroundArt then
        Browse.BackgroundArt:SetAlpha(0)
    end

    -- era: legacy UIDropDownMenus (CategoryDropDown); anniversary 2.5.6:
    -- modern WowStyle1 dropdowns with lowercase-d parentKeys
    if Browse.CategoryDropDown then
        Skin.UIDropDownMenuTemplate(Browse.CategoryDropDown)
        Skin.UIDropDownMenuTemplate(Browse.ActivityDropDown)
    else
        if Browse.CategoryDropdown then
            Skin.DropdownButton(Browse.CategoryDropdown)
        end
        if Browse.ActivityDropdown then
            Skin.DropdownButton(Browse.ActivityDropdown)
        end
    end

    -- Square refresh button: strip the SquareButton states, keep the icon
    local refresh = Browse.RefreshButton
    if refresh then
        refresh:SetNormalTexture("")
        refresh:SetPushedTexture("")
        refresh:SetDisabledTexture("")
        Skin.FrameTypeButton(refresh)
    end

    if Browse.ScrollBar then
        SkinScrollBar(Browse.ScrollBar)
    end
    if Browse.ScrollBox then
        Skin.WowScrollBoxList(Browse.ScrollBox)
        _G.hooksecurefunc(Browse.ScrollBox, "Update", function(self)
            self:ForEachFrame(SkinSearchEntry)
        end)
    end
    if Browse.SendMessageButton then
        Skin.UIPanelButtonTemplate(Browse.SendMessageButton)
    end
    if Browse.GroupInviteButton then
        Skin.UIPanelButtonTemplate(Browse.GroupInviteButton)
    end
    if _G.LFGBrowseSearchEntryTooltip then
        Skin.TooltipBackdropTemplate(_G.LFGBrowseSearchEntryTooltip)
    end

    -------------
    -- Listing --
    -------------
    local Listing = _G.LFGListingFrame
    for _, name in ipairs({"LFGListingFrameFrameBackgroundTop", "LFGListingFrameFrameBackgroundBottom"}) do
        local texture = _G[name]
        if texture then
            texture:SetTexture("")
        end
    end
    if Listing.BackgroundArt then
        Listing.BackgroundArt:SetAlpha(0)
    end

    for _, key in ipairs({"BackButton", "PostButton"}) do
        if Listing[key] then
            Skin.UIPanelButtonTemplate(Listing[key])
        end
    end
    local roleButtons = Listing.GroupRoleButtons
    if roleButtons then
        if roleButtons.RolePollButton then
            Skin.UIPanelButtonTemplate(roleButtons.RolePollButton)
        end
        if roleButtons.RoleDropDown then
            Skin.UIDropDownMenuTemplate(roleButtons.RoleDropDown)
        elseif roleButtons.RoleDropdown then
            Skin.DropdownButton(roleButtons.RoleDropdown)
        end
    end

    SkinActivityView(Listing.ActivityView)

    -- Category buttons are built on demand, so catch them as they are added and
    -- sweep any that already exist (a no-op at load, a re-skin on reload).
    if _G.LFGListingCategorySelection_AddButton then
        _G.hooksecurefunc("LFGListingCategorySelection_AddButton", function(self, btnIndex)
            local buttons = self and self.CategoryButtons
            if buttons then
                SkinCategoryButton(buttons[btnIndex])
            end
        end)
    end
    local CategoryView = Listing.CategoryView
    if CategoryView and CategoryView.CategoryButtons then
        for _, button in ipairs(CategoryView.CategoryButtons) do
            SkinCategoryButton(button)
        end
    end

    SkinWhoList()
    SkinModernStyle(LFGParentFrame)
end
