local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals

--[[ Core ]]
local Aurora = private.Aurora
local Hook = Aurora.Hook
local Color, Util = Aurora.Color, Aurora.Util

do --[[ FrameXML\TalentFrameBase.lua ]]
    function Hook.TalentFrame_Update(TalentFrame, talentUnit)
        for tier = 1, _G.MAX_TALENT_TIERS do
            local talentRow = TalentFrame["tier"..tier]
            for column = 1, _G.NUM_TALENT_COLUMNS do
                local button = talentRow["talent"..column]
                local talentInfoQuery = {};
				talentInfoQuery.tier = tier;
				talentInfoQuery.column= column;
				talentInfoQuery.groupIndex = TalentFrame.talentGroup;
				talentInfoQuery.isInspect = TalentFrame.inspect;
				talentInfoQuery.target = talentUnit;
                local talentInfo = _G.C_SpecializationInfo.GetTalentInfo(talentInfoQuery);
                if button.knownSelection then
                    if talentInfo.grantedByAura then
                        local color = _G.ITEM_QUALITY_COLORS[_G.Enum.ItemQuality.Legendary]
                        button.knownSelection:SetColorTexture(color.r, color.g, color.b, 0.5)
                    elseif talentInfo.selected then
                        Util.SetHighlightColor(button.knownSelection, 0.5)
                    end
                end

                if TalentFrame.inspect then
                    if talentInfo.grantedByAura then
                        local color = _G.ITEM_QUALITY_COLORS[_G.Enum.ItemQuality.Legendary]
                        button._auroraIconBG:SetColorTexture(color.r, color.g, color.b)
                    elseif talentInfo.selected then
                        -- Inspected unit's class can be secret in combat (WoW 12);
                        -- indexing with a secret key throws — fall back to black.
                        local _, class = _G.UnitClass(talentUnit)
                        local color = class and not _G.issecretvalue(class)
                            and _G.CUSTOM_CLASS_COLORS[class]
                        if color then
                            button._auroraIconBG:SetColorTexture(color:GetRGB())
                        else
                            button._auroraIconBG:SetColorTexture(Color.black:GetRGB())
                        end
                    else
                        button._auroraIconBG:SetColorTexture(Color.black:GetRGB())
                    end
                end
            end
        end
    end
    Hook.PvpTalentSlotMixin = {}
    function Hook.PvpTalentSlotMixin:Update()
        if not self._auroraBG then return end
        local slotInfo = _G.C_SpecializationInfo.GetPvpTalentSlotInfo(self.slotIndex)

        local selectedTalentID = self:GetSelectedTalent()
        if selectedTalentID then
            local _, _, texture = _G.GetPvpTalentInfoByID(selectedTalentID)
            self.Texture:SetTexture(texture)
            self.Texture:SetTexCoord(.08, .92, .08, .92)
        else
            self.Texture:SetTexCoord(.18, .85, .18, .85)
        end

        if slotInfo.enabled then
            self._auroraBG:SetColorTexture(Color.black:GetRGB())
            self.Texture:SetDesaturated(false)
        else
            self._auroraBG:SetColorTexture(Color.gray:GetRGB())
        end
    end
end

function private.FrameXML.TalentFrameBase()
    _G.hooksecurefunc("TalentFrame_Update", Hook.TalentFrame_Update)
    Util.Mixin(_G.PvpTalentSlotMixin, Hook.PvpTalentSlotMixin)
end
