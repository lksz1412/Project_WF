# NugComboBar

## [12.1.3](https://github.com/rgd87/NugComboBar/tree/12.1.3) (2026-11-11)
[Full Changelog](https://github.com/rgd87/NugComboBar/compare/12.1.2...12.1.3) [Previous Releases](https://github.com/rgd87/NugComboBar/releases)

- Fixed error with last point not showing in dungeons with sounds enabled  
