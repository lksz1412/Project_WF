--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local _, KT = ...

local SS = KT:NewSubsystem("AddonCompartment")

local function Compartment_OnClick(data, menuInputData, menu)
    if menuInputData.buttonName == "LeftButton" then
        KT:Tracker_SetHidden()
    elseif menuInputData.buttonName == "RightButton" then
        if KT:Addon_IsModule(KT.Options) then
            KT.Options:Open()
        end
    end
end

local function Compartment_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_NONE")
    GameTooltip:SetPoint("TOPRIGHT", self, "TOPLEFT", -11, 7)
    GameTooltip:AddLine(KT.TITLE)
    GameTooltip:AddLine("Left Click - Show / Hide tracker", 1, 1, 1)
    GameTooltip:AddLine("Right Click - Open addon Options", 1, 1, 1)
    GameTooltip:Show()
end

local function Compartment_OnLeave(self)
    GameTooltip:Hide()
end

function SS:Init()
    local data = {
        text = KT.TITLE,
        icon = KT.MEDIA_PATH.."KT_logo",
        notCheckable = true,
        registerForAnyClick = true,
        func = Compartment_OnClick,
        funcOnEnter = Compartment_OnEnter,
        funcOnLeave = Compartment_OnLeave
    }
    AddonCompartmentFrame:RegisterAddon(data)
end