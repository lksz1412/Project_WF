--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local addonName, KT = ...

---@class AddonTomTom
local M = KT:NewModule("AddonTomTom")
M.COMPATIBLE_VERSION = "v4.4.1-release"
M.MIN_COMPATIBLE_VERSION = "v4.4.0-release"
KT.AddonTomTom = M

local _DBG = function(...) if _DBG then _DBG("KT", ...) end end

-- Lua API
local format = string.format
local ipairs = ipairs
local strmatch = string.match
local strsplit = string.split

-- WoW API
local HaveQuestData = HaveQuestData

local db, dbChar
local tomtomArrow
local questWaypoint
local userWaypointID = 999999
local superTrackedID
local ticker = {}
local stopUpdate = false
local stopCleanup = false
local autoQuestWatch = GetCVarBool("autoQuestWatch")

local cTitle = "|cffffd200"
local cBold = "|cff00ffe3"

local OTF = KT_ObjectiveTrackerFrame

-- Internal ------------------------------------------------------------------------------------------------------------

local function SetCharWaypointData(stype, id, type, mapID)
	if not dbChar.waypoint then return end  -- WTF - because some addons create stupid things during PLAYER_LOGOUT

	dbChar.waypoint.stype = stype
	dbChar.waypoint.id = id
	dbChar.waypoint.type = type
	dbChar.waypoint.mapID = mapID or 0
end

local function SetupOptions(versionText)
	if not KT:Addon_IsModule(KT.Options) then return end

	KT.Options.AddAddonOption("addons", {
		addonTomTom = {
			name = "TomTom",
			desc = "Version: "..versionText,
			descStyle = "inline",
			type = "toggle",
			width = 1.05,
			disabled = function()
				return not C_AddOns.IsAddOnLoaded("TomTom")
			end,
			arg = function(value)
				-- cleanup
				if value then
					C_SuperTrack.ClearAllSuperTracked()
				else
					SetCharWaypointData()
				end
			end,
			order = 8.1,
		},
		addonTomTomDesc = {
			name = "Enables integration of Blizzard's POI with TomTom's Arrow for better navigation.",
			type = "description",
			width = "double",
			order = 8.2,
		}
	})
end

local function SetupOptions_Module()
	if not KT:Addon_IsModule(KT.Options) then return end

	KT.Options.AddAddonTab("tomtom", {
		name = "TomTom",
		type = "group",
		order = 8,
		args = {
			info = {
				name = "Info",
				type = "group",
				inline = true,
				order = 1,
				args = {
					tomtomDesc = {
						name = " TomTom support combines Blizzard's POI and TomTom's arrow.\n\n"..
								" |cffff7f00Warning:|r Original \"TomTom > Quest Objectives\" options are ignored!\n\n\n"..
								"|TInterface\\WorldMap\\UI-QuestPoi-NumberIcons:32:32:-2:10:256:256:128:160:96:128|t+"..
								"|T"..KT.MEDIA_PATH.."KT-TomTomTag:32:32:-8:10:32:16:0:16:0:16|t...   Active POI button with TomTom waypoint.\n"..
								"|TInterface\\WorldMap\\UI-QuestPoi-NumberIcons:32:32:-2:10:256:256:128:160:96:128|t+"..
								"|T"..KT.MEDIA_PATH.."KT-TomTomTag:32:32:-8:10:32:16:16:32:0:16|t...   Active POI button without TomTom waypoint (no data).",
						type = "description",
						order = 1,
					},
				},
			},
			tomtomArrow = {
				name = "TomTom Arrow",
				type = "group",
				inline = true,
				order = 2,
				args = {
					tomtomArrowDesc = {
						name = " - "..cBold.."Left Click|r - opens World Map.\n"..
								" - "..cBold.."Right Click|r - removes the waypoint from the arrow, clears the POI selection\n"..
								"    and deletes the waypoint (if created by "..KT.TITLE..").\n"..
								" - "..cBold.."Shift + Right Click|r - opens the TomTom context menu.\n\n",
						type = "description",
						order = 1,
					},
					tomtomArrival = {
						name = "Arrival distance",
						type = "range",
						min = 0,
						max = 150,
						step = 5,
						set = function(_, value)
							db.tomtomArrival = value
						end,
						order = 2,
					},
				},
			},
		},
	})

	-- Reverts the option to display Quest Objectives
	if not GetCVarBool("questPOI") then
		SetCVar("questPOI", 1)
	end
end

local function GetMapIDByCursor(mapID)
	if WorldMapFrame.ScrollContainer:IsMouseOver() then
		local normalizedCursorX, normalizedCursorY = WorldMapFrame:GetNormalizedCursorPosition()
		local positionMapInfo = C_Map.GetMapInfoAtPosition(mapID, normalizedCursorX, normalizedCursorY)
		if positionMapInfo and positionMapInfo.mapID ~= mapID then
			mapID = positionMapInfo.mapID
		end
	end
	return mapID
end

local function NormalizePOIData(mapID, x, y, questID)
    local currentMapID = KT.GetCurrentMapAreaID()
    if questID then
        currentMapID = KT.MAP_ZONE_OVERRIDES[currentMapID] or currentMapID
    end
    local mapInfo = C_Map.GetMapInfo(currentMapID)
    if mapInfo and mapInfo.mapType == Enum.UIMapType.Micro then
        currentMapID = mapInfo.parentMapID
    end

    mapID = mapID or 0
    local sameZone, sameContinent = KT.CompareZones(mapID, currentMapID)
	local waypointMapID, waypointText
	local fakeData = false
	if not sameZone then
		if mapID > 0 then
			waypointText = "Travel to "..KT.GetMapNameByID(mapID)
		end
		if x and y and (not sameContinent or (questID and KT.IsInstanceQuest(questID))) then
			waypointMapID, x, y = currentMapID, 0, 0
			fakeData = true
		end
	end
	return mapID, x, y, waypointMapID, waypointText, fakeData
end

-- Super turbo function :)
local function QuestPOIGetIconInfo(questID)
	local fakeData = false
	local waypointMapID
	local waypointText = C_QuestLog.GetNextWaypointText(questID)
	local mapID, x, y = C_QuestLog.GetNextWaypoint(questID)
	if not x or not y then
		mapID = GetQuestUiMapID(questID)
		if mapID and mapID > 0 then
			local quests = C_QuestLog.GetQuestsOnMap(mapID)
			if quests then
				for _, info in ipairs(quests) do
					if info.questID == questID then
						x = info.x
						y = info.y
						break
					end
				end
			end

			if not waypointText then
				mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y, questID)
			end
		end
	end
	return mapID, x, y, waypointMapID, waypointText, fakeData
end

local function TaskQuestPOIGetIconInfo(questID)
	local fakeData = false
	local x, y, waypointMapID, waypointText
	local mapID = C_TaskQuest.GetQuestZoneID(questID)
	if mapID then
		local tasks = KT.GetTasksOnMapCached(mapID)
		if tasks then
			for _, info  in ipairs(tasks) do
				if HaveQuestData(info.questID) then
					if info.questID == questID then
						x = info.x
						y = info.y
						break
					end
				end
			end
		end

		mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	end
	return mapID, x, y, waypointMapID, waypointText, fakeData
end

local function UserWaypointGetIconInfo(ignoreUI)
	local x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local posVector = C_Map.GetUserWaypointPositionForMap(mapID)
	if posVector then
		x, y = posVector:GetXY()
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return mapID, x, y, waypointMapID, waypointText, fakeData
end

local function AreaPOIGetIconInfo(id, ignoreUI)
	local title, x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID > 0 and dbChar.waypoint.mapID or C_EventScheduler.GetEventUiMapID(id)
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local info = C_AreaPoiInfo.GetAreaPOIInfo(mapID, id)
	if info then
		title = info.name
		if info.atlasName then
			local width, height, offsetX, offsetY = 18, 18, -3, 0
			local atlas = KT.GetPoiIcon(info.atlasName, "atlas") or info.atlasName
			title = CreateAtlasMarkup(atlas, width, height, offsetX, offsetY)..title
		end
		x, y = info.position:GetXY()
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function QuestOfferGetIconInfo(id, ignoreUI)
	local title, x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local info = KT.GetQuestOfferInfo(mapID, id)
	if info then
		title = info.questName
		local iconMarkup = KT.GetPoiIcon("Quest"..info.questClassification, "markup")
		if iconMarkup then
			title = iconMarkup..title
		end
		x, y = info.x, info.y
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function TaxiNodeGetIconInfo(id, ignoreUI)
	local title, x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local info = KT.GetTaxiNodeInfo(mapID, id)
	if info then
		title = KT.GetPoiIcon("TaxiNode", "markup")..strsplit(",", info.name)
		x, y = info.position:GetXY()
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function DigSiteGetIconInfo(id, ignoreUI)
	local title, x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local info = KT.GetDigSiteInfo(mapID, id)
	if info then
		title = KT.GetPoiIcon("DigSite", "markup")..info.name
		x, y = info.position:GetXY()
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function HousingPlotGetIconInfo(id, ignoreUI)
    local title, x, y, waypointMapID, waypointText, fakeData
    local mapID = dbChar.waypoint.mapID
    if not ignoreUI and WorldMapFrame:IsShown() then
        mapID = WorldMapFrame:GetMapID()
        mapID = GetMapIDByCursor(mapID)
    end

    local info = KT.GetHousingPlotInfo(id)
    if info then
        title = format(HOUSING_PLOT_NUMBER.." (%s)", info.plotID, info.ownerName or HOUSING_CORNERSTONE_FORSALE)
        local iconMarkup = KT.GetPoiIcon("Housing"..info.ownerType, "markup")
        if iconMarkup then
            title = iconMarkup..title
        end
        x, y = info.mapPosition:GetXY()
    end

    mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
    return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function ContentGetIconInfo(type, id)
	local title, x, y, waypointMapID, waypointText, fakeData
	local result, mapID = C_ContentTracking.GetBestMapForTrackable(type, id)
	if result ~= Enum.ContentTrackingResult.Success then
		return title, mapID, x, y, waypointMapID, waypointText, fakeData
	end

	title = C_ContentTracking.GetTitle(type, id)
	if not title then
		return title, mapID, x, y, waypointMapID, waypointText, fakeData
	end
	title = KT.GetPoiIcon("MapPin", "markup")..title

	local _, info = C_ContentTracking.GetNextWaypointForTrackable(type, id, mapID)
	if not info then
		local _, infos = C_ContentTracking.GetTrackablesOnMap(type, mapID)
		if infos and #infos == 1 then
			info = infos[1]
		end
	end
	if info then
		local objectiveText = C_ContentTracking.GetObjectiveText(info.targetType, info.targetID)
		if objectiveText then
			local target = strmatch(objectiveText, "^(.-):")
			if target then
				title = format(KT.FORMAT_TEXT_HINT, title, target)
			end
		end
		x, y = info.x, info.y
		waypointText = info.waypointText
	end

	if not waypointText or waypointText == "" then
		mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	end
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function VignetteGetIconInfo(guid, ignoreUI)
	local title, x, y, waypointMapID, waypointText, fakeData
	local mapID = dbChar.waypoint.mapID
	if not ignoreUI and WorldMapFrame:IsShown() then
		mapID = WorldMapFrame:GetMapID()
		mapID = GetMapIDByCursor(mapID)
	end

	local info = C_VignetteInfo.GetVignetteInfo(guid)
	if info then
		title = info.name
		if info.atlasName then
			local width, height, offsetX, offsetY = 18, 18, -3, 0
			local atlas = KT.GetPoiIcon(info.atlasName, "atlas") or info.atlasName
			title = CreateAtlasMarkup(atlas, width, height, offsetX, offsetY)..title
		end
		local position = C_VignetteInfo.GetVignettePosition(guid, mapID)
		if position then
			x, y = position:GetXY()
		end
	end

	mapID, x, y, waypointMapID, waypointText, fakeData = NormalizePOIData(mapID, x, y)
	return title, mapID, x, y, waypointMapID, waypointText, fakeData
end

local function SetWaypointTag(button, show)
	local tag = button.Display.KTtomtom
	if not tag then return end

	if show then
		tag:Show()
		if questWaypoint then
			tag:SetTexCoord(0, 0.5, 0, 1)
		else
			tag:SetTexCoord(0.5, 1, 0, 1)
		end
	else
		tag:Hide()
	end
end

local function UpdateWaypointTag(button)
	local show = (TomTom.profile.arrow.enable
			and superTrackedID ~= nil
			and (superTrackedID == button.questID or superTrackedID == button.areaPOIID))
	SetWaypointTag(button, show)
end

local function RefreshWaypointTags()
	for button in KT.POIButtons_EnumerateActive() do
		UpdateWaypointTag(button)
	end
end

local function AddTicker(id, func, seconds)
	if not ticker[id] then
		ticker[id] = C_Timer.NewTicker(seconds or 0.5, function()
			if id == superTrackedID then
				func()
			end
		end)
	end
end

local function RemoveTicker(id)
	if ticker[id] then
		ticker[id]:Cancel()
		ticker[id] = nil
	end
end

local function AddWaypoint(id, pinType, force)
	if type(id) == "number" and C_QuestLog.IsQuestCalling(id) then
		return false
	end

	local title, mapID, x, y, waypointMapID, waypointText, fakeData
	local superTrackingType = C_SuperTrack.GetHighestPrioritySuperTrackingType()
	if superTrackingType == Enum.SuperTrackingType.Quest then
		if C_QuestLog.IsQuestTask(id) then
			local iconName = QuestUtils_IsQuestWorldQuest(id) and "WorldQuest" or "BonusObjective"
			title = C_TaskQuest.GetQuestInfoByQuestID(id)
			if title then
				title = KT.GetPoiIcon(iconName, "markup")..title
				mapID, x, y, waypointMapID, waypointText, fakeData = TaskQuestPOIGetIconInfo(id)
			end
		else
			local iconName = C_QuestLog.IsComplete(id) and "QuestTurnin" or "Quest"
			title = C_QuestLog.GetTitleForQuestID(id)
			if title then
				title = KT.GetPoiIcon(iconName, "markup")..title
				mapID, x, y, waypointMapID, waypointText, fakeData = QuestPOIGetIconInfo(id)
			end
		end
	elseif superTrackingType == Enum.SuperTrackingType.UserWaypoint then
		if id == userWaypointID then
			title = KT.GetPoiIcon("MapPin", "markup").."My waypoint"
			mapID, x, y, waypointMapID, waypointText, fakeData = UserWaypointGetIconInfo(force)
		end
	elseif superTrackingType == Enum.SuperTrackingType.Content then
		title, mapID, x, y, waypointMapID, waypointText, fakeData = ContentGetIconInfo(pinType, id)
	elseif superTrackingType == Enum.SuperTrackingType.MapPin then
		if pinType == Enum.SuperTrackingMapPinType.AreaPOI then
			title, mapID, x, y, waypointMapID, waypointText, fakeData = AreaPOIGetIconInfo(id, force)
		elseif pinType == Enum.SuperTrackingMapPinType.QuestOffer then
			title, mapID, x, y, waypointMapID, waypointText, fakeData = QuestOfferGetIconInfo(id, force)
		elseif pinType == Enum.SuperTrackingMapPinType.TaxiNode then
			title, mapID, x, y, waypointMapID, waypointText, fakeData = TaxiNodeGetIconInfo(id, force)
		elseif pinType == Enum.SuperTrackingMapPinType.DigSite then
			title, mapID, x, y, waypointMapID, waypointText, fakeData = DigSiteGetIconInfo(id, force)
		elseif pinType == Enum.SuperTrackingMapPinType.HousingPlot then
			title, mapID, x, y, waypointMapID, waypointText, fakeData = HousingPlotGetIconInfo(id, force)
		end
	elseif superTrackingType == Enum.SuperTrackingType.Vignette then
		title, mapID, x, y, waypointMapID, waypointText, fakeData = VignetteGetIconInfo(id, force)
	end

	if not title or not mapID or not x or not y then
		return false
	end

	if waypointText then
		title = title.."\n|cff00ff00("..waypointText..")"
	end

	if questWaypoint then
		stopCleanup = true  -- prevent tracking cleanup in callback WaypointRemoved
		TomTom:RemoveWaypoint(questWaypoint)
		stopCleanup = false
	end

	local uid = TomTom:AddWaypoint(waypointMapID or mapID, x, y, {
		title = title,
		silent = true,
		world = false,
		minimap = false,
		crazy = true,
		persistent = false,
		arrivaldistance = db.tomtomArrival,
		from = KT.TITLE,
		KTid = id,
		KTfakeData = fakeData,
	})
	questWaypoint = uid
	SetCharWaypointData(superTrackingType, id, pinType, mapID)

	return true
end

local function RemoveWaypoint(id)
	if id == superTrackedID then
		TomTom:RemoveWaypoint(questWaypoint)  -- see callback WaypointRemoved
	end
end

local function SetSuperTrackedWaypoint(id, pinType, force)
	if id == superTrackedID and not force then return end
	local added = false

	if not force and superTrackedID ~= nil then
		RemoveWaypoint(superTrackedID)
	end
	local isEmpty = (id == nil or id == 0 or id == "")
	if not isEmpty then
		added = AddWaypoint(id, pinType, force)
		superTrackedID = id
		RefreshWaypointTags()
	end

	return added
end

local function SetSuperTrackedUserWaypoint(superTracked, force)
	local id = superTracked and userWaypointID
	SetSuperTrackedWaypoint(id, nil, force)
end

local function TomTomArrow_SetShown(show)
	if tomtomArrow.KTarrow then
		tomtomArrow.KTarrow:SetShown(show)
		tomtomArrow.KTtravel:SetShown(not show)
		tomtomArrow.status:SetShown(show and TomTom.profile.arrow.showdistance)
		C_Timer.After(0, function()
			tomtomArrow.tta:SetShown(show and TomTom.profile.arrow.showtta)
		end)
	end
	tomtomArrow.KTshown = show
end

local function TomTom_PatchOptions()
	KT:Bliz_RegisterOptionsPatch("TOMTOM_ARROW_MENU", function(options)
		options.description = {
			text = KT.TEXT.ADDON_IS_CONTROLLED.."\n"..
					"- "..cBold.."Left Click|r - opens World Map.\n"..
					"- "..cBold.."Right Click|r - removes the waypoint from the arrow, clears the POI selection\n"..
					"   and deletes the waypoint (if created by "..KT.TITLE..").\n"..
					"- "..cBold.."Shift + Right Click|r - opens the TomTom context menu.",
			indent = 30,
			paddingTop = -8,
		}
	end)

	KT:Bliz_RegisterOptionsPatch("TOMTOM_ARROW_SETCLOSEST", function(options, nextOptions)
		options.description = {
			text = KT.TEXT.ADDON_IS_CONTROLLED,
			indent = 30,
			paddingTop = -8,
		}
		nextOptions.hidden = true
	end)

	KT:Bliz_RegisterOptionsPatch("TOMTOM_POI_SETCLOSEST", function(options, nextOptions)
		options.description = {
			text = KT.TEXT.ADDON_IS_CONTROLLED,
			paddingTop = -8,
		}
		nextOptions.hidden = true
	end)
end

local function TomTom_Setup()
	if not db.addonTomTom then return end

	-- TomTom
	TomTom:SuppressFeature(KT.TITLE, "poi")
	TomTom:SuppressFeature(KT.TITLE, "arrow.setclosest")

	TomTom.RegisterCallback(addonName, "ArrowThemeChanged", function(event, key)
		tomtomArrow.KTarrow = TomTom:GetCrazyArrowTexture()
		if questWaypoint then
			TomTomArrow_SetShown(tomtomArrow.KTshown)
		end
	end)

	TomTom.RegisterCallback(addonName, "WaypointRemoved", function(event, uid)
		if not db.width then return end  -- WTF - because some addons create stupid things during PLAYER_LOGOUT
		if stopCleanup then return end
		if uid ~= questWaypoint then return end

		if uid.KTid == superTrackedID then
			RemoveTicker(uid.KTid)
			questWaypoint = nil
			superTrackedID = nil
			SetCharWaypointData()
			RefreshWaypointTags()
		end
	end)

	TomTom.RegisterCallback(addonName, "ArrowTargetChanged", function(event, uid)
		if not uid then return end

		if not uid.KTid then
			C_SuperTrack.ClearAllSuperTracked()
		end

		local fakeData = uid.KTfakeData ~= nil and uid.KTfakeData or false
		TomTomArrow_SetShown(not fakeData)
	end)

	-- TomTom Arrow
	tomtomArrow = TomTomCrazyArrow
	tomtomArrow.KTarrow = TomTom:GetCrazyArrowTexture()
	tomtomArrow.KTshown = true

	local travel = tomtomArrow:CreateTexture(nil, "OVERLAY")
	travel:SetAtlas("poi-traveldirections-arrow2", true)
	travel:SetScale(0.9)
	travel:SetPoint("BOTTOM")
	travel:Hide()
	tomtomArrow.KTtravel = travel
end

local function SetHooks()
	-- TomTom
	hooksecurefunc(TomTom, "ShowHideCrazyArrow", RefreshWaypointTags)

	TomTomCrazyArrow:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	local bck_TomTomCrazyArrow_OnClick = TomTomCrazyArrow:GetScript("OnClick")
	TomTomCrazyArrow:SetScript("OnClick", function(self, btn, down)
		if btn == "LeftButton" then
            if not KT.InCombatBlocked() and dbChar.waypoint.id ~= nil and dbChar.waypoint.mapID > 0 then
                C_Map.OpenWorldMap(dbChar.waypoint.mapID)
            end
		else
			if IsShiftKeyDown() then
				bck_TomTomCrazyArrow_OnClick(self, btn, down)
			else
				C_SuperTrack.ClearAllSuperTracked()
				-- remove other TomTom waypoints
				C_Timer.After(0, function()
					TomTom:ClearCrazyArrowPoint()
				end)
			end
		end
	end)

	-- Blizzard
	hooksecurefunc(C_SuperTrack, "SetSuperTrackedQuestID", function(questID)
		SetSuperTrackedWaypoint(questID)
	end)

	hooksecurefunc(C_SuperTrack, "ClearAllSuperTracked", function()
		if superTrackedID ~= nil then
			RemoveWaypoint(superTrackedID)
		end
	end)

	hooksecurefunc(C_SuperTrack, "SetSuperTrackedContent", function(trackableType, trackableID)
		SetSuperTrackedWaypoint(trackableID, trackableType)
	end)

	hooksecurefunc(C_SuperTrack, "SetSuperTrackedMapPin", function(type, typeID)
		SetSuperTrackedWaypoint(typeID, type)
	end)

	hooksecurefunc(C_SuperTrack, "ClearSuperTrackedMapPin", function()
		if superTrackedID ~= nil then
			RemoveWaypoint(superTrackedID)
		end
	end)

	hooksecurefunc(C_SuperTrack, "SetSuperTrackedVignette", function(vignetteGUID)
		SetSuperTrackedWaypoint(vignetteGUID)

		-- War Supply Crate
		local info = C_VignetteInfo.GetVignetteInfo(vignetteGUID)
		if info and info.atlasName == "Vehicle-Air-Occupied" then
			AddTicker(vignetteGUID, function()
				if not SetSuperTrackedWaypoint(vignetteGUID, nil, true) then
					RemoveTicker(vignetteGUID)
				end
			end)
		end
	end)

	hooksecurefunc(C_SuperTrack, "SetSuperTrackedUserWaypoint", function(superTracked)
		SetSuperTrackedUserWaypoint(superTracked)
	end)

	hooksecurefunc(C_QuestLog, "AbandonQuest", function()
		local questID = QuestMapFrame.DetailsFrame.questID or QuestLogPopupDetailFrame.questID
		RemoveWaypoint(questID)
	end)

	hooksecurefunc("QuestMapQuestOptions_TrackQuest", function(questID)
		if questID == C_SuperTrack.GetSuperTrackedQuestID() then
			SetSuperTrackedWaypoint(questID, nil, true)
		end
	end)

	hooksecurefunc(C_ContentTracking, "StopTracking", function(type, id, stopType)
		C_SuperTrack.ClearSuperTrackedContent()  -- dirty fix Blizz bug
		RemoveWaypoint(id)
	end)

	-- Only for Events
	if KT_BonusObjectiveTracker then
		hooksecurefunc(KT_BonusObjectiveTracker, "OnQuestRemoved", function(self, questID)
			if questID == superTrackedID then
				C_SuperTrack.ClearSuperTrackedMapPin()
			end
		end)
	end

	-- Only for World Quests
	if KT_WorldQuestObjectiveTracker then
		hooksecurefunc(KT_WorldQuestObjectiveTracker, "OnQuestTurnedIn", function(self, questID)
			RemoveWaypoint(questID)
		end)
	end

	hooksecurefunc(KT_POIButtonMixin, "UpdateButtonStyle", UpdateWaypointTag)
end

local function SetEvents()
	KT:RegEvent("PLAYER_ENTERING_WORLD", function(eventID, isInitialLogin)
		if isInitialLogin then
			if dbChar.waypoint.id == userWaypointID then
				SetCharWaypointData()
			end
			if dbChar.waypoint.mapID > 0 and dbChar.waypoint.type == 1 then
				KT.SetMapID(dbChar.waypoint.mapID)
			end
		end
		KT:UnregEvent(eventID)
	end, M)

	-- Update waypoint after login/reload with supertracking
	KT:RegSignal("QUESTS_READY", function()
		if dbChar.waypoint.stype == Enum.SuperTrackingType.Quest then
			local questID = C_SuperTrack.GetSuperTrackedQuestID() or dbChar.waypoint.id
			if questID and (QuestUtils_IsQuestWatched(questID) or C_QuestLog.IsComplete(questID) or QuestUtil.IsQuestTrackableTask(questID)) then
				C_SuperTrack.SetSuperTrackedQuestID(questID)
			end
		elseif dbChar.waypoint.stype == Enum.SuperTrackingType.UserWaypoint then
			if dbChar.waypoint.id == userWaypointID and C_SuperTrack.IsSuperTrackingUserWaypoint() then
				SetSuperTrackedUserWaypoint(true)
			end
		elseif dbChar.waypoint.stype == Enum.SuperTrackingType.Content then
			local trackableType, trackableID = C_SuperTrack.GetSuperTrackedContent()
			if not trackableType and not trackableID then
				trackableType = dbChar.waypoint.type
				trackableID = dbChar.waypoint.id
			end
			if trackableType and trackableID then
				C_SuperTrack.SetSuperTrackedContent(trackableType, trackableID)
			end
		elseif dbChar.waypoint.stype == Enum.SuperTrackingType.MapPin then
			local type, superTrackedPoiID = C_SuperTrack.GetSuperTrackedMapPin()
			if not type and not	superTrackedPoiID then
				type = dbChar.waypoint.type
				superTrackedPoiID = dbChar.waypoint.id
			end
			if type and superTrackedPoiID then
				C_SuperTrack.SetSuperTrackedMapPin(type, superTrackedPoiID)
			end
		elseif dbChar.waypoint.stype == Enum.SuperTrackingType.Vignette then
			local vignetteGUID = C_SuperTrack.GetSuperTrackedVignette()
			if vignetteGUID then
				C_SuperTrack.SetSuperTrackedVignette(vignetteGUID)
			end
		end
	end, M)

	KT:RegEvent("QUEST_ACCEPTED", function(_, questID)
		-- Quest - enable/disable stop update
		stopUpdate = not autoQuestWatch

		-- Bonus/World quest - create waypoint
		if C_QuestLog.IsQuestTask(questID) and questID == C_SuperTrack.GetSuperTrackedQuestID() then
			SetSuperTrackedWaypoint(questID)
		end
	end, M)

	-- Enable stop update after quest is removed
	KT:RegEvent("QUEST_REMOVED", function()
		stopUpdate = true

		local questID = C_SuperTrack.GetSuperTrackedQuestID()
		if questID and QuestUtils_IsQuestWatched(questID) then
			C_Timer.After(0, function()
				SetSuperTrackedWaypoint(questID)
			end)
		end
	end, M)

	-- Enable stop update after quest is turned in
	KT:RegEvent("QUEST_TURNED_IN", function()
		stopUpdate = true
	end, M)

	-- Update waypoint after quest objectives changed
	KT:RegEvent("QUEST_WATCH_UPDATE", function(_, questID)
		if questID == C_SuperTrack.GetSuperTrackedQuestID() then
			C_Timer.After(0.6, function()
				if not stopUpdate then
					SetSuperTrackedWaypoint(questID, nil, true)
				end
			end)
		end
	end, M)

	-- Updates waypoint while moving
	KT:RegEvent("WAYPOINT_UPDATE", function()
		local questID = C_SuperTrack.GetSuperTrackedQuestID()
		if questID then
			SetSuperTrackedWaypoint(questID, nil, true)
		end
	end, M)

	-- Updates waypoint while change zone
	KT:RegEvent("ZONE_CHANGED_NEW_AREA", function()
		C_Timer.After(0, function()
			if dbChar.waypoint.stype == Enum.SuperTrackingType.Quest then
				local questID = C_SuperTrack.GetSuperTrackedQuestID() or dbChar.waypoint.id
				if questID and (QuestUtils_IsQuestWatched(questID) or C_QuestLog.IsComplete(questID) or QuestUtil.IsQuestTrackableTask(questID)) then
					SetSuperTrackedWaypoint(questID, nil, true)
				end
			elseif dbChar.waypoint.stype == Enum.SuperTrackingType.UserWaypoint then
				if dbChar.waypoint.id == userWaypointID and C_SuperTrack.IsSuperTrackingUserWaypoint() then
					SetSuperTrackedUserWaypoint(true, true)
				end
			elseif dbChar.waypoint.stype == Enum.SuperTrackingType.Content then
				local trackableType, trackableID = C_SuperTrack.GetSuperTrackedContent()
				if trackableType and trackableID then
					SetSuperTrackedWaypoint(trackableID, trackableType, true)
				end
			elseif dbChar.waypoint.stype == Enum.SuperTrackingType.MapPin then
				local type, superTrackedPoiID = C_SuperTrack.GetSuperTrackedMapPin()
				if superTrackedPoiID then
					SetSuperTrackedWaypoint(superTrackedPoiID, type, true)
				end
			elseif dbChar.waypoint.stype == Enum.SuperTrackingType.Vignette then
				C_SuperTrack.ClearAllSuperTracked()
			end
		end)
	end, M)

	-- Create waypoint after accept quest (2nd time)
	KT:RegEvent("QUEST_POI_UPDATE", function()
        C_Timer.After(0.1, function()
            local questID = C_SuperTrack.GetSuperTrackedQuestID()
            if questID and QuestUtils_IsQuestWatched(questID) then
                SetSuperTrackedWaypoint(questID, nil, true)
            end
        end)
	end, M)
end

-- External ------------------------------------------------------------------------------------------------------------

function M:OnInitialize()
	_DBG("|cffffff00Init|r - "..self:GetName(), true)
	db = KT.db.profile
	dbChar = KT.db.char
    self.isAvailable = true

	if self.isAvailable then
		local defaults = KT.MergeTables({
			profile = {
				tomtomArrival = 15,
			}
		}, KT.db.defaults)
		KT.db:RegisterDefaults(defaults)
	end
end

function M:OnEnable()
	_DBG("|cff00ff00Enable|r - "..self:GetName(), true)
	local loaded, versionText = KT.CheckAddOn("TomTom", self.COMPATIBLE_VERSION)

	SetupOptions(versionText)
	if loaded and db.addonTomTom then
		KT:Alert_IncompatibleAddon("TomTom", self.MIN_COMPATIBLE_VERSION)

		SetupOptions_Module()
		SetEvents()
		SetHooks()

		TomTom_PatchOptions()
		TomTom_Setup()
	end
end