--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local addonName, KT = ...

KT.FLAVOR.name = "Forever"
KT.FLAVOR.slug = "camelot"

KT.MIN_COMPATIBLE_VERSION = "1.0.0"

KT.VISIBILITY_CONTEXTS = {
    "world",
    "city",
    "dungeon",
    "raid",
    "battleground",
    "rare",
}

KT.BUTTON.ACHIEVEMENTS = LegacyMicroButton

KT.KEYBINDINGS.EXTRAACTIONBUTTON1 = nil
KT.KEYBINDINGS.keyBindActiveButton = { frameName = addonName.."ActiveButton" }

KT.LANG.csCZ = { code = "CZ", name = "Čeština", flag = "|T"..KT.MEDIA_PATH.."KT-flag-cz:16:16|t" }

KT.TEXT.TRACKER_ACHIEVEMENTS = LEGACY_BUTTON
KT.TEXT.OPTION_CONTROLS_VISIBILITY_LEGEND = ""
KT.TEXT.OPTION_CONTROLS_VISIBILITY_LEGEND_MARKER = ""