--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local _, KT = ...

local M = KT.AddonBtWQuests
M.COMPATIBLE_VERSION = "v2.69.1-forever"
M.MIN_COMPATIBLE_VERSION = "v2.68.0-forever"