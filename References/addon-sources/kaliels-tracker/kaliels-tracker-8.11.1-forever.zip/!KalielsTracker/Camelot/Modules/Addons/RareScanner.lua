--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local _, KT = ...

local M = KT.AddonRareScanner
M.COMPATIBLE_VERSION = "1.60.1.3"
M.MIN_COMPATIBLE_VERSION = "1.60.1"