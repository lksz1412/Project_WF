--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local _, KT = ...

local addon, version, apiVersion = "WoWFCzech", "1.1.2", 5.1

---@class AddonWoWFCzech
local M = KT:NewModule("Addon"..addon)
KT["Addon"..addon] = M

local LSM = LibStub("LibSharedMedia-3.0")
local _DBG = function(...) if _DBG then _DBG("KT", ...) end end

-- WoW API
local _G = _G

local db, dbChar
local api

local FONT_FRIZQT = KT.MEDIA_PATH.."Fonts\\FRIZQT__-CZ.ttf"
local FONT_MORPHEUS = KT.MEDIA_PATH.."Fonts\\MORPHEUS-CZ.ttf"

local fields = {
    tooltip = {
        title = { frame = "GameTooltipTextLeft1", font = FONT_FRIZQT },
        objectives = { frame = "GameTooltipTextLeft4", font = FONT_FRIZQT },
    }
}

local PlayButton, LangButton

-- Internal ------------------------------------------------------------------------------------------------------------

local function SetupOptions(versionText)
    if not KT:Addon_IsModule(KT.Options) then return end

    KT.Options.AddAddonOption("addons", {
        ["addon"..addon] = {
            name = "WoWFCzech",
            desc = "Version: "..versionText,
            descStyle = "inline",
            type = "toggle",
            width = 1.05,
            disabled = function()
                return not C_AddOns.IsAddOnLoaded(addon)
            end,
            order = 9.1,
        },
        ["addon"..addon.."Desc"] = {
            name = "Enables Czech quest translations and voice-over controls in the tracker and Quest Log.",
            type = "description",
            width = "double",
            order = 9.2,
        },
    })
end

local backupFont = {}
local function UpdateFont(frame, font)
    local backup = backupFont[frame]

    if font then
        if not backup then
            backup = { frame:GetFont() }
            backupFont[frame] = backup
        end

        frame:SetFont(font, backup[2], backup[3] or "")
    elseif backup then
        frame:SetFont(backup[1], backup[2], backup[3] or "")
        backupFont[frame] = nil
    end
end

local function RestoreTooltipFont()
    for frame in pairs(backupFont) do
        UpdateFont(frame)
    end
end

local function ContextMenu_Extend(_, info, type, questID)
    if type ~= "quest" then return end
    if info.KTmenuSource == "questDetails" then return end
    if not api.AudioEnabled() then return end

    if not info.KTmenuExtended then
        KT.Menu_AddSeparator()
        info.KTmenuExtended = true
    end

    local text, func
    if api.PlayingQuestID() == questID then
        text = "Zastavit"
        func = function()
            api.Stop()
        end
    else
        text = "Přehrát česky"
        func = function()
            api.PlayQuest(questID, "DESCRIPTION")
        end
    end
    info.fontObject = KT_GameFontHighlightSmallLeft_CZ
    info.fontObjectDisable = KT_GameFontDisableSmallLeft_CZ
    KT.Menu_AddButton(KT.LANG.csCZ.flag.."  "..text, func, not api.HasQuestAudio(questID, "DESCRIPTION"))
    info.fontObject = nil
    info.fontObjectDisable = nil

    KT.Menu_AddSeparator()
end

local function WoWFCzech_HasValidAPI()
    api = WoWFCzechAPI
    if api and type(api.version) == "number" and api.version >= apiVersion then
        return true
    else
        db["addon"..addon] = false
        KT.StaticPopup_Show("ReloadUIWide", nil,
                KT.FORMAT.TEXT_BOLD.." support has been disabled. Version "..KT.FORMAT.TEXT_BOLD..
                        " provides an API%s that this version of "..KT.TITLE.." does not support.",
                C_AddOns.GetAddOnMetadata(addon, "Title"),
                C_AddOns.GetAddOnMetadata(addon, "Version"),
                api and "v"..api.version or "")
        return false
    end
end

local function WoWFCzech_Setup()
    local detailsFrame = KT_QuestsFrame.DetailsFrame
    local detailsTopFrame = detailsFrame.BackFrame

    LSM:Register(LSM.MediaType["FONT"], "Friz Quadrata TT CZ", FONT_FRIZQT)
    LSM:Register(LSM.MediaType["FONT"], "Morpheus CZ", FONT_MORPHEUS)

    if db.font == "Friz Quadrata TT" then
        db.font = "Friz Quadrata TT CZ"
    end
    if db.questLog.detailsHeadingFont == "Morpheus" then
        db.questLog.detailsHeadingFont = "Morpheus CZ"
    end
    if db.questLog.detailsBodyFont == "Friz Quadrata TT" then
        db.questLog.detailsBodyFont = "Friz Quadrata TT CZ"
    end

    KT.LocalizationService_Override("quest.tracker.title", function(questID)
        return api.QuestText(questID, "NAME")
    end)

    KT.LocalizationService_Override("quest.tooltip.title", function(questID)
        local text = api.QuestText(questID, "NAME")
        local field = fields.tooltip.title
        UpdateFont(_G[field.frame], text ~= nil and field.font or nil)
        return text
    end)

    KT.LocalizationService_Override("quest.tooltip.objectives", function(questID)
        local text = api.QuestText(questID, "OBJECTIVE")
        local field = fields.tooltip.objectives
        UpdateFont(_G[field.frame], text ~= nil and field.font or nil)
        return text
    end)

    KT.LocalizationService_Override("quest.detail.title", function(questID)
        if api.GetDetailsLanguage() == "cz" then
            return api.QuestText(questID, "NAME")
        end
        return
    end)

    KT.LocalizationService_Override("quest.detail.description", function(questID)
        if api.GetDetailsLanguage() == "cz" then
            return api.QuestText(questID, "DESCRIPTION")
        end
        return
    end)

    KT.LocalizationService_Override("quest.detail.objectives", function(questID)
        if api.GetDetailsLanguage() == "cz" then
            return api.QuestText(questID, "OBJECTIVE")
        end
        return
    end)

    api.OnChange(function()
        KT:Tracker_Update()
    end)

    GameTooltip:HookScript("OnTooltipCleared", RestoreTooltipFont)

    local fontNames = { "GameFontNormal", "GameFontHighlight", "GameFontDisable", "GameFontHighlightSmallLeft", "GameFontDisableSmallLeft" }
    for _, name in ipairs(fontNames) do
        local font = CreateFont("KT_"..name.."_CZ")
        font:CopyFontObject(_G[name])
        local _, fontSize, fontFlags = font:GetFont()
        font:SetFont(FONT_FRIZQT, fontSize, fontFlags)
    end

    local _, fontSize, fontFlags = ErrorFont:GetFont()
    ErrorFont:SetFont(FONT_FRIZQT, fontSize, fontFlags)

    local function Tooltip_Show(self)
        local desc
        if self == LangButton then
            if api.IsDetailsOriginal() then
                desc = "Kliknutím zobrazíš český text."
            else
                desc = "Kliknutím zobrazíš původní text ("..KT.LANG[KT.LOCALE].name..")."
            end
        else
            desc = "České audio."
        end

        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip_SetTitle(GameTooltip, addon)
        GameTooltip:AddLine(desc, 0.57, 0.57, 0.57)
        for i = 1, GameTooltip:NumLines() do
            UpdateFont(_G["GameTooltipTextLeft"..i], FONT_FRIZQT)
        end

        GameTooltip:Show()
    end

    local function Tooltip_Hide()
        GameTooltip:Hide()
    end

    local function CreateButton(width, height, ...)
        local button = CreateFrame("Button", nil, detailsTopFrame, "UIPanelButtonTemplate")
        button:SetSize(width, height)
        button:SetPoint(...)
        button:SetNormalFontObject(KT_GameFontNormal_CZ)
        button:SetHighlightFontObject(KT_GameFontHighlight_CZ)
        button:SetDisabledFontObject(KT_GameFontDisable_CZ)
        button:SetScript("OnEnter", Tooltip_Show)
        button:SetScript("OnLeave", Tooltip_Hide)
        return button
    end

    LangButton = CreateButton(34, 22, "RIGHT", -10, 4)
    api.SetupLanguageButton(LangButton, {
        czechText = KT.LANG.csCZ.code,
        originalText = KT.LANG[KT.LOCALE].code,
    }, function(questID)
        KT_QuestMapFrame_ShowQuestDetails(questID)
        if GameTooltip:IsOwned(LangButton) then
            Tooltip_Show(LangButton)
        end
    end)

    PlayButton = CreateButton(74, 22, "RIGHT", LangButton, "LEFT")
    api.SetupPlayButton(PlayButton, {
        playText = "Přehrát",
        stopText = "Zastavit",
    })

    local bck_KT_QuestMapFrame_ShowQuestDetails = KT_QuestMapFrame_ShowQuestDetails
    KT_QuestMapFrame_ShowQuestDetails = function(questID)
        api.DetailsOpened(questID)

        PlayButton:ClearAllPoints()
        if LangButton:IsShown() then
            PlayButton:SetPoint("RIGHT", LangButton, "LEFT")
        else
            PlayButton:SetPoint("RIGHT", -10, 4)
        end

        bck_KT_QuestMapFrame_ShowQuestDetails(questID)
    end

    hooksecurefunc("KT_QuestMapFrame_CloseQuestDetails", function()
        api.DetailsClosed()
    end)

    local bck_Menu_AddRadio = KT.Menu_AddRadio
    KT.Menu_AddRadio = function(text, state, value, ...)
        if state[1] == dbChar.filter.quests and state[2] == "sort" and value == "title" then
            return
        end
        return bck_Menu_AddRadio(text, state, value, ...)
    end

    if dbChar.filter.quests.sort == "title" then
        dbChar.filter.quests.sort = nil
    end
end

-- External ------------------------------------------------------------------------------------------------------------

function M:OnInitialize()
    _DBG("|cffffff00Init|r - "..self:GetName(), true)
    db = KT.db.profile
    dbChar = KT.db.char
    self.isAvailable = true

    if self.isAvailable then
        local defaults = KT.MergeTables({
            profile = {
                ["addon"..addon] = false,
            }
        }, KT.db.defaults)
        KT.db:RegisterDefaults(defaults)
    end
end

function M:OnEnable()
    _DBG("|cff00ff00Enable|r - "..self:GetName(), true)
    local loaded, versionText = KT.CheckAddOn(addon, version)

    SetupOptions(versionText)
    if loaded and db.addonWoWFCzech then
        if WoWFCzech_HasValidAPI() then
            WoWFCzech_Setup()

            KT:RegSignal("CONTEXT_MENU_UPDATE", ContextMenu_Extend, self)
        end
    end
end