--- Kaliel's Tracker
--- Copyright (c) 2012-2026, Marouan Sabbagh <mar.sabbagh@gmail.com>
--- All Rights Reserved.
---
--- This file is part of addon Kaliel's Tracker.

---@type KT
local _, KT = ...

local M = KT.Help

local HELP_PATH = KT.MEDIA_PATH.."Help\\"
local ICON_URL = HELP_PATH.."help_icon-url"

local cTitle = "|cffffd200"
local offs = "\n|T:1:9|t"

M.pages.wowfczech = {
	font = KT.MEDIA_PATH.."Fonts\\FRIZQT__-CZ.ttf",
	image = HELP_PATH.."help_addon-wowfczech",
	heading = "Support addon WoWFCzech",
	text = "WoWFCzech support adds Czech quest translations and voice-over controls to the tracker and Quest Log. "..
			"The following details are in Czech language.\n\n"..
			"|T"..KT.MEDIA_PATH.."KT-flag-cz:10:16:0:0:16:16:0:16:3:13|t  Podpora WoWFCzech přidává české překlady úkolů "..
			"a ovládání hlasového přehrávání do Trackeru (Sledovač úkolů) a Quest Logu (Deník úkolů). Všechny funkce "..
			"respektují možnosti nastavení addonu WoWFCzech.\n\n"..
			cTitle.."Tracker|r\n"..
			"- České názvy úkolů.\n"..
	  		"- České názvy a stručné popisy v tooltipech úkolů.\n"..
	  		"- Zapnutí/vypnutí hlasového přehrávání v kontextovém menu úkolu.\n\n"..
			cTitle.."Quest Log - Detail úkolu|r\n"..
	  		"- Kompletní české překlady úkolu.\n"..
	  		"- Tlačítko pro hlasové přehrávání textu úkolu.\n"..
	  		"- Tlačítko pro přepínání mezi češtinou a jazykem hry.\n"..
			M.AddonInfo("WoWFCzech"),
	editbox = {
		{
			icon = ICON_URL,
			text = "https://www.curseforge.com/wow/addons/wowfczech",
			width = 510,
			bottom = 4,
		}
	},
}

M.helpPages = {
	M.pages.intro,
	M.pages.header,
	M.pages.quests,
	M.pages.filters,
	M.pages.buttons,
	M.pages.activeButton,
	M.pages.modules,
	M.pages.masque,
	M.pages.tomtom,
	M.pages.waypoints,
	M.pages.wowfczech,
	M.pages.rarescanner,
	M.pages.whatsNew,
}