# Kaliel's Tracker changelog
### 8.11.1
- FIXED - TomTom - options notes missing
### 8.11.0
- ADDED - addon support - Auctionator 341 (search button inside the Profession module header)
- ADDED - Profession recipe tracking
- ADDED - addon support - BtWQuests 2.69.1-forever (&quot;Open Quest Chain&quot; option in the Quest context menu)
- CHANGED - addon support - Auctionator 343
- CHANGED - addon support - TomTom 4.4.1
- CHANGED - addon support - RareScanner 1.60.1.3
- CHANGED - addon support - WoWFCzech 1.1.2
- FIXED - Active Button keybinding unavailable without ExtraActionButton1
### 8.10.0
- CHANGED - addon support - Battle Pet Completionist 12.1.5-20261105-1
- CHANGED - addon support - ElvUI 16.01
- CHANGED - enable Pixel Perfect Scale by default
- CHANGED - addon support - BtWQuests 2.68.0
- CHANGED - Options - apply changes requiring Reload UI with a single confirmation
