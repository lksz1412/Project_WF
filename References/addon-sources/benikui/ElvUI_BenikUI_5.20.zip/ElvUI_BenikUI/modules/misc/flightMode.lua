local BUI, E, L, V, P, G = unpack((select(2, ...)))
local mod = BUI:GetModule('FlightMode')
local AB = E:GetModule('ActionBars')
local LO = E:GetModule('Layout')
local M = E:GetModule('WorldMap')

local _G = _G
local GetTime = GetTime
local unpack, floor, pairs, ipairs, tinsert, twipe = unpack, floor, pairs, ipairs, table.insert, table.wipe
local join = string.join
local hooksecurefunc = hooksecurefunc

local GameTooltip = _G.GameTooltip
local C_TimerAfter = C_Timer.After
local CreateFrame = CreateFrame
local UnitOnTaxi = UnitOnTaxi
local GetFramerate = GetFramerate
local GetBattlefieldStatus = GetBattlefieldStatus
local IsInInstance = IsInInstance
local ToggleWorldMap = ToggleWorldMap
local GetClampedCurrentExpansionLevel = GetClampedCurrentExpansionLevel
local GetExpansionDisplayInfo = GetExpansionDisplayInfo
local GetRealZoneText, GetMinimapZoneText = GetRealZoneText, GetMinimapZoneText
local GetZonePVPInfo = (C_PvP and C_PvP.GetZonePVPInfo) or GetZonePVPInfo
local C_Map_GetBestMapForUnit = C_Map.GetBestMapForUnit
local C_Map_GetPlayerMapPosition = C_Map.GetPlayerMapPosition
local GetScreenWidth = GetScreenWidth
local InCombatLockdown = InCombatLockdown
local TaxiRequestEarlyLanding = TaxiRequestEarlyLanding
local UIFrameFadeIn, UIFrameFadeOut, PlaySound = UIFrameFadeIn, UIFrameFadeOut, PlaySound
local TAXI_CANCEL_DESCRIPTION, UNKNOWN = TAXI_CANCEL_DESCRIPTION, UNKNOWN
local MinimapCluster = _G.MinimapCluster
local ObjectiveTrackerFrame = _G.ObjectiveTrackerFrame

local GetCVar = C_CVar.GetCVar

local menuFrame = CreateFrame('Frame', 'BuiGameClickMenu', E.UIParent)
menuFrame:SetTemplate('Transparent', true)
menuFrame:CreateWideShadow()

local LOCATION_WIDTH = 399
local classColor = E:ClassColor(E.myclass, true)

local isFlightMode = false

local function AutoColoring()
	local pvpType = GetZonePVPInfo()

	if (pvpType == "sanctuary") then
		return 0.41, 0.8, 0.94
	elseif(pvpType == "arena") then
		return 1, 0.1, 0.1
	elseif(pvpType == "friendly") then
		return 0.1, 1, 0.1
	elseif(pvpType == "hostile") then
		return 1, 0.1, 0.1
	elseif(pvpType == "contested") then
		return 1, 0.7, 0.10
	elseif(pvpType == "combat" ) then
		return 1, 0.1, 0.1
	else
		return 1, 1, 0
	end
end

function mod:CreateCoords()
	local mapID = C_Map_GetBestMapForUnit("player")
	local mapPos = mapID and C_Map_GetPlayerMapPosition(mapID, "player")
	if mapPos then x, y = mapPos:GetXY() end

	x = (mapPos and x) and E:Round(100 * x) or 0
	y = (mapPos and y) and E:Round(100 * y) or 0

	return x, y
end

function mod:UpdateLocation()
	local subZoneText = GetMinimapZoneText() or ""
	local zoneText = GetRealZoneText() or UNKNOWN;
	local displayLine

	if (subZoneText ~= "") and (subZoneText ~= zoneText) then
		displayLine = zoneText .. ": " .. subZoneText
	else
		displayLine = subZoneText
	end

	local r, g, b = AutoColoring()
	mod.FlightMode.top.location.text:SetText(displayLine)
	mod.FlightMode.top.location.text:SetTextColor(r, g, b)
	mod.FlightMode.top.location.text:Width(LOCATION_WIDTH - 30)
end

function mod:UpdateCoords()
	local x, y = mod.CreateCoords()
	local xt,yt

	if x == 0 and y == 0 then
		mod.FlightMode.top.location.x.text:SetText("-")
		mod.FlightMode.top.location.y.text:SetText("-")
	else
		if x < 10 then
			xt = "0"..x
		else
			xt = x
		end

		if y < 10 then
			yt = "0"..y
		else
			yt = y
		end
		mod.FlightMode.top.location.x.text:SetText(xt)
		mod.FlightMode.top.location.y.text:SetText(yt)
	end
end

function mod:UpdateTimer()
	local time = GetTime() - mod.startTime
	mod.FlightMode.bottom.timeFlying.txt:SetFormattedText("%02d:%02d", floor(time/60), time % 60)

	local createdTime = BUI:createTime()
	mod.FlightMode.top.timeText:SetFormattedText(createdTime)
end

local statusColors = {
	'|cff0CD809',	-- green
	'|cffE8DA0F',	-- yellow
	'|cffD80909'	-- red
}

function mod:UpdateFps()
	local value = floor(GetFramerate())
	local fpscolor = 3
	local max = 120

	if(value * 100 / max >= 45) then
		fpscolor = 1
	elseif value * 100 / max < 45 and value * 100 / max > 30 then
		fpscolor = 2
	else
		fpscolor = 3
	end
	local displayFormat = join('', statusColors[fpscolor], '%d|rFps')
	mod.FlightMode.bottom.fps.txt:SetFormattedText(displayFormat, value)
end

function mod:SetFrameParent()
	if E.db.benikui.misc.flightMode.enable ~= true then return end

	local WorldMapFrame = _G.WorldMapFrame
	local buttonBar = _G.SquareMinimapButtonBar
	if mod.inFlightMode == true then
		WorldMapFrame:SetParent(_G.UIParent)
		if BUI.PA then
			if buttonBar then
				buttonBar:SetParent(E.UIParent)
			end
		end
	else
		WorldMapFrame:SetParent(E.UIParent)
		if BUI.PA then
			if buttonBar then
				buttonBar:SetParent(_G.UIParent)
			end
		end
	end
end

local DCR = _G.LibStub('AceAddon-3.0'):GetAddon('Decursive', true)
local function Decursive(hide)
	if not DCR then return end
	if hide then
		_G.DcrMUFsContainer:Hide()
	else
		if DCR.profile.ShowDebuffsFrame == true then
			_G.DcrMUFsContainer:Show()
		end
	end
end

local function CenteredCDM()
	if BUI:IsAddOnEnabled('CooldownManagerCentered') then
		return false
	end
end

local cdmHiddenFrames = {
	EssentialCooldownViewer	= false,
	UtilityCooldownViewer	= false,
	BuffIconCooldownViewer	= false,
}

local function UpdateCooldownManagerVisibility()
	if CenteredCDM() or (GetCVar("cooldownViewerEnabled") ~= "1") then return end
	for frameName, _ in pairs(cdmHiddenFrames) do
		local frame = _G[frameName]
		if frame then
			if isFlightMode then
				if frame:IsShown() then
					cdmHiddenFrames[frameName] = true
					frame:Hide()
				end
			else
				if cdmHiddenFrames[frameName] then
					cdmHiddenFrames[frameName] = false
					frame:Show()
				end
			end
		end
	end
end

local AddonsToHide = {
	-- addon, frame
	{'ZygorGuidesViewer', 'ZygorGuidesViewerFrame'},
	{'ZygorGuidesViewer', 'Zygor_Notification_Center'},
	{'ZygorGuidesViewer', 'ZygorGuidesViewer_ActionBar'},
	{'WorldQuestTracker', 'WorldQuestTrackerScreenPanel'},
	{'WorldQuestTracker', 'WorldQuestTrackerFinderFrame'},
	{'XIV_Databar', 'XIV_Databar'},
	{'VuhDo', 'VuhDoBuffWatchMainFrame'},
	{'HeroRotation','HeroRotation_ToggleIconFrame'},
	{'!KalielsTracker','!KalielsTrackerFrame'},
	{'!KalielsTracker','!KalielsTrackerScrollChild'},
	{'!KalielsTracker','!KalielsTrackerScrollBar'},
	{'!KalielsTracker','!KalielsTrackerScroll'},
	{'!KalielsTracker','!KalielsTrackerBackground'},
	{'!KalielsTracker','!KalielsTrackerButtons'},
	{'!KalielsTracker','KT_ObjectiveTracker'},
	{'!KalielsTracker','KT_ObjectiveTrackerUIWidgetContainer'},
	{'!KalielsTracker','KT_AchievementObjectiveTracker'},
	{'!KalielsTracker','KT_ProfessionsRecipeTracker'},
	{'!KalielsTracker','!KalielsTrackerHeaderButtons'},
	{'RareTrackerCore','RT'},
	{'MinimapButtonButton','MinimapButtonButtonButton'},
}

local AllTheThingsFrames = {}
local DamageMeterFrames = {}
local VisibleFrames = {}

function mod:SetFlightMode(status)
	if(InCombatLockdown()) then return end
	local tracking = MinimapCluster.Tracking.Button
	local containerFrame = _G.ElvUI_ContainerFrame
	local zoneFrame = _G.ZoneTextFrame
	local leftPanel = _G.LeftChatPanel

	UpdateCooldownManagerVisibility()

	if(status) then
		mod.inFlightMode = true
		mod.FlightMode:Show()
		mod:SetFrameParent()

		E.UIParent:Hide()

		-- Hide some frames
		if ObjectiveTrackerFrame then
			ObjectiveTrackerFrame:SetParent(E.HiddenFrame)
		end

		if E.private.general.minimap.enable then
			_G.MinimapCluster:Hide()
		end

		if _G.ZoneAbilityFrame and _G.ZoneAbilityFrame:GetParent() then
			_G.ZoneAbilityFrame:GetParent():Hide()
		end

		if not E.db.general.addonCompartment.hide then
			_G.AddonCompartmentFrame:Hide()
		end

		C_TimerAfter(0.05, function()
			_G.MainMenuBarVehicleLeaveButton:Hide()
			tracking:SetAlpha(0)
		end)

		mod.FlightMode.bottom.map:EnableMouse(true)
		mod.FlightMode.top.menuButton:EnableMouse(true)

		-- Bags
		if containerFrame then
			containerFrame:SetParent(mod.FlightMode)
			if containerFrame.wideshadow then
				containerFrame.wideshadow:Show()
			end
			if containerFrame.shadow then
				containerFrame.shadow:Hide()
			end
		end

		-- Left Chat
		if E.private.chat.enable then
			_G.BuiDummyChat:SetParent(mod.FlightMode)
			leftPanel:SetParent(mod.FlightMode)
			if leftPanel.backdrop.shadow then
				leftPanel.backdrop.shadow:Hide()
			end
			leftPanel.backdrop.wideshadow:Show()
			leftPanel.backdrop.wideshadow:SetFrameStrata('BACKGROUND') -- it loses its framestrata somehow. Needs digging
			leftPanel:ClearAllPoints()
			leftPanel:Point("BOTTOMLEFT", mod.FlightMode.bottom, "TOPLEFT", 24, 24)

			if leftPanel.backdrop.style then
				leftPanel.backdrop.style:SetFrameStrata('BACKGROUND')
				leftPanel.backdrop.style:SetFrameLevel(2)
				if leftPanel.backdrop.style.styleShadow then
					leftPanel.backdrop.style.styleShadow:SetFrameStrata('BACKGROUND')
					leftPanel.backdrop.style.styleShadow:SetFrameLevel(0)
				end
			end
			_G.LeftChatDataPanel:Hide()
		end

		-- Hide SquareMinimapButtonBar
		if BUI.PA then
			if _G.SquareMinimapButtonBar then
				_G.SquareMinimapButtonBar:Hide()
			end
		end

		-- Details
		if BUI:IsAddOnEnabled('Details') then
			local Details = _G._detalhes
			local instances_amount = Details:GetNumInstancesAmount()

			if instances_amount > 0 then
				for i = 1, instances_amount do
					if _G['DetailsBaseFrame'..i] then
						_G['DetailsBaseFrame'..i]:Hide()
					end

					if _G['Details_SwitchButtonFrame'..i] then
						_G['Details_SwitchButtonFrame'..i]:Hide()
					end

					if _G['DetailsRowFrame'..i] then
						_G['DetailsRowFrame'..i]:Hide()
					end
				end
			end
		end

		for _, v in ipairs(AddonsToHide) do
			local addon, frame = unpack(v)
			if BUI:IsAddOnEnabled(addon) then
				if _G[frame] then
					if _G[frame]:IsVisible() then
						VisibleFrames[frame] = true
						_G[frame]:Hide()
					end
				end
			end
		end

		-- special handling for VuhDo panels
		if BUI:IsAddOnEnabled('VuhDo') then
			if VUHDO_CONFIG["SHOW_PANELS"] then
				VisibleFrames['VuhDoHealPanels'] = true
				VUHDO_slashCmd('hide')
			end
		end

		-- Blizzard DamageMeter
		if GetCVar("damageMeterEnabled") == "1" then
			local currentCount = 0
			_G.DamageMeter:ForEachSessionWindow(function(sessionWindow)
				if sessionWindow:IsShown() then
					currentCount = currentCount + 1
				end
				if currentCount > 0 then
					for i = 1, currentCount do
						if _G['DamageMeterSessionWindow'..i] then
							_G['DamageMeterSessionWindow'..i]:Hide()
							tinsert(DamageMeterFrames, _G['DamageMeterSessionWindow'..i])
						end
					end
				end
			end)
		end

		-- AllTheThings
		if BUI:IsAddOnEnabled('AllTheThings') then
			local att = _G.AllTheThings
			for _, window in pairs(att.Windows) do
				if window:IsShown() then
					window:Hide()
					tinsert(AllTheThingsFrames, window)
				end
			end
		end

		-- special handling for Elkano Buff Bars
		if BUI:IsAddOnEnabled('ElkBuffBars') then
			ElkBuffBars:PET_BATTLE_OPENING_START()
		end

		-- Decursive
		Decursive(true)

		-- Handle ActionBars. This needs to be done if Global Fade is active
		for _, bar in pairs(AB.handledBars) do
			if bar then
				if bar:GetParent() == AB.fadeParent then
					bar:SetAlpha(0)
				end
			end
		end

		-- Disable Blizz location messsages
		zoneFrame:UnregisterAllEvents()

		mod.startTime = GetTime()
		mod.timer = mod:ScheduleRepeatingTimer('UpdateTimer', 1)
		mod.locationTimer = mod:ScheduleRepeatingTimer('UpdateLocation', 0.2)
		mod.coordsTimer = mod:ScheduleRepeatingTimer('UpdateCoords', 0.2)
		mod.fpsTimer = mod:ScheduleRepeatingTimer('UpdateFps', 1)

	elseif(mod.inFlightMode) then
		mod.inFlightMode = false
		_G.MainMenuBarVehicleLeaveButton:SetParent(_G.UIParent)
		mod:SetFrameParent()

		E.UIParent:Show()

		-- Show hidden frames
		if ObjectiveTrackerFrame then
			ObjectiveTrackerFrame:SetParent(_G.UIParent)
		end

		if E.private.general.minimap.enable then
			_G.MinimapCluster:Show()
		end

		tracking:SetAlpha(1)

		if _G.ZoneAbilityFrame and _G.ZoneAbilityFrame:GetParent() then
			_G.ZoneAbilityFrame:GetParent():Show()
		end

		if not E.db.general.addonCompartment.hide then
			_G.AddonCompartmentFrame:Show()
		end

		_G.MainMenuBarVehicleLeaveButton:SetScript('OnShow', nil)

		mod.FlightMode:Hide()

		-- Enable Blizz location messsages.
		-- Added support for LocationPlus & NutsAndBolts LocationLite
		if (BUI.LP and E.db.locplus.zonetext) or (BUI.NB and not E.db.NutsAndBolts.LocationLite.hideDefaultZonetext) then
			zoneFrame:UnregisterAllEvents()
		else
			zoneFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
			zoneFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
			zoneFrame:RegisterEvent("ZONE_CHANGED")
		end

		mod:CancelAllTimers()

		mod.FlightMode.bottom.timeFlying.txt:SetText("00:00")
		mod.FlightMode.bottom.requestStop:EnableMouse(true)
		mod.FlightMode.bottom.requestStop.img:SetVertexColor(1, 1, 1, .7)
		mod.FlightMode.message:Hide()

		-- Revert Bags
		if containerFrame then
			containerFrame:SetParent(E.UIParent)
			if containerFrame.wideshadow then
				containerFrame.wideshadow:Hide()
			end
			if containerFrame.shadow then
				containerFrame.shadow:Show()
			end
		end

		for i, v in ipairs(AddonsToHide) do
			local addon, frame = unpack(v)
			if BUI:IsAddOnEnabled(addon) then
				if _G[frame] then
					if VisibleFrames[frame] then
						_G[frame]:Show()
					end
				end
			end
		end

		-- special handling for VuhDo panels
		if BUI:IsAddOnEnabled('VuhDo') then
			if VisibleFrames['VuhDoHealPanels'] then
				VUHDO_slashCmd('show')
			end
		end

		-- Details
		if BUI:IsAddOnEnabled('Details') then
			local Details = _G._detalhes
			local instances_amount = Details:GetNumInstancesAmount()

			if instances_amount > 0 then
				for i = 1, instances_amount do
					if _G['DetailsBaseFrame'..i] then
						_G['DetailsBaseFrame'..i]:Show()
					end

					if _G['Details_SwitchButtonFrame'..i] then
						_G['Details_SwitchButtonFrame'..i]:Show()
					end

					if _G['DetailsRowFrame'..i] then
						_G['DetailsRowFrame'..i]:Show()
					end
				end
			end
		end

		-- AllTheThings
		if BUI:IsAddOnEnabled('AllTheThings') then
			for _, frame in pairs(AllTheThingsFrames) do
				frame:Show()
			end
			twipe(AllTheThingsFrames)
		end

		-- Blizzard DamageMeter
		if GetCVar("damageMeterEnabled") == "1" then
			for _, frame in pairs(DamageMeterFrames) do
				if frame then
					frame:Show()
				end
			end
			twipe(DamageMeterFrames)
		end

		-- special handling for Elkano Buff Bars
		if BUI:IsAddOnEnabled('ElkBuffBars') then
			ElkBuffBars:PET_BATTLE_CLOSE()
		end

		-- Decursive
		Decursive(false)

		-- revert Left Chat
		if E.private.chat.enable then
			_G.BuiDummyChat:SetParent(E.UIParent)
			leftPanel:SetParent(E.UIParent)
			if leftPanel.backdrop.shadow then
				leftPanel.backdrop.shadow:Show()
				leftPanel.backdrop.shadow:SetFrameStrata('BACKGROUND') -- it loses its framestrata somehow. Needs digging
				leftPanel.backdrop.shadow:SetFrameLevel(0)
			end
			if leftPanel.backdrop.style then
				leftPanel.backdrop.style:SetFrameStrata('BACKGROUND')
				leftPanel.backdrop.style:SetFrameLevel(2)
				if leftPanel.backdrop.style.styleShadow then
					leftPanel.backdrop.style.styleShadow:SetFrameStrata('BACKGROUND')
					leftPanel.backdrop.style.styleShadow:SetFrameLevel(0)
				end
			end
			leftPanel.backdrop.wideshadow:Hide()
			leftPanel:ClearAllPoints()
			leftPanel:Point("BOTTOMLEFT", _G.LeftChatMover, "BOTTOMLEFT")
			leftPanel:SetFrameStrata('BACKGROUND')
			LO:RepositionChatDataPanels()
			LO:ToggleChatPanels()
		end

		-- revert Actionbars
		for barName in pairs(AB.handledBars) do
			AB:PositionAndSizeBar(barName)
		end

		-- Show SquareMinimapButtonBar
		if BUI.PA then
			if _G.SquareMinimapButtonBar then
				_G.SquareMinimapButtonBar:Show()
			end
		end

		if _G.BuiTaxiButton then
			_G.BuiTaxiButton:SetParent(E.UIParent)
		end
	end
end

function mod:OnEvent(event, ...)
	local forbiddenArea = BUI:CheckFlightMapID()

	if forbiddenArea then return end

	if(event == "LFG_PROPOSAL_SHOW" or event == "UPDATE_BATTLEFIELD_STATUS") then
		if(event == "UPDATE_BATTLEFIELD_STATUS") then
			local status = GetBattlefieldStatus(...);
			if ( status == "confirm" ) then
				mod:SetFlightMode(false)
			end
		else
			mod:SetFlightMode(false)
		end

		isFlightMode = false
		return
	end

	if IsInInstance() then return end

	isFlightMode = UnitOnTaxi("player")
	mod:SetFlightMode(isFlightMode)
end

function mod:ToggleLogo()
	if E.db.benikui.misc.flightMode.enable ~= true then return end
	local db = E.db.benikui.misc.flightMode.logo

	if db == 'WOW' then
		mod.FlightMode.bottom.wowlogo:Show()
		mod.FlightMode.bottom.benikui:Hide()
		mod.FlightMode.bottom.logo:Hide()
	elseif db == 'BENIKUI' then
		mod.FlightMode.bottom.wowlogo:Hide()
		mod.FlightMode.bottom.benikui:Show()
		mod.FlightMode.bottom.logo:Show()
	else
		mod.FlightMode.bottom.wowlogo:Hide()
		mod.FlightMode.bottom.benikui:Hide()
		mod.FlightMode.bottom.logo:Hide()
	end
end

function mod:LoadEvents()
	mod:RegisterEvent("UPDATE_BONUS_ACTIONBAR", "OnEvent")
	mod:RegisterEvent("UPDATE_MULTI_CAST_ACTIONBAR", "OnEvent")
	mod:RegisterEvent("LFG_PROPOSAL_SHOW", "OnEvent")
	mod:RegisterEvent("UPDATE_BATTLEFIELD_STATUS", "OnEvent")
	mod:RegisterEvent("PLAYER_ENTERING_WORLD", "OnEvent")
	mod:RegisterEvent("ZONE_CHANGED_NEW_AREA", "OnEvent")
end

function mod:CreateFlightMode()
	if E.db.benikui.misc.flightMode.enable ~= true then return end

	local db = E.db.benikui.colors
	mod.FlightMode = CreateFrame("Frame", "BenikUIFlightModeFrame", _G.UIParent)
	mod.FlightMode:SetFrameLevel(1)
	mod.FlightMode:SetFrameStrata('BACKGROUND')
	mod.FlightMode:SetAllPoints(_G.UIParent)
	mod.FlightMode:Hide()

	-- Top frame
	mod.FlightMode.top = CreateFrame('Frame', nil, mod.FlightMode)
	mod.FlightMode.top:SetFrameLevel(0)
	mod.FlightMode.top:SetFrameStrata("HIGH")
	mod.FlightMode.top:Point("TOP", mod.FlightMode, "TOP", 0, E.Border)
	mod.FlightMode.top:SetTemplate('Transparent', true, true)
	mod.FlightMode.top:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.top:CreateWideShadow()
	mod.FlightMode.top:Width(GetScreenWidth() + (E.Border*2))
	mod.FlightMode.top:Height(40)

	-- Menu button
	mod.FlightMode.top.menuButton = CreateFrame('Button', 'FlightModeMenuBtn', mod.FlightMode.top)
	mod.FlightMode.top.menuButton:Size(32, 32)
	mod.FlightMode.top.menuButton:Point("LEFT", mod.FlightMode.top, "LEFT", 6, 0)

	mod.FlightMode.top.menuButton.img = mod.FlightMode.top.menuButton:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.top.menuButton.img:Point("CENTER")
	mod.FlightMode.top.menuButton.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\menu.tga')
	mod.FlightMode.top.menuButton.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.top.menuButton:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.top.menuButton, 'ANCHOR_BOTTOMRIGHT', 4, -4)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(L['Show an enhanced game menu'], 1, 1, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.top.menuButton.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.top.menuButton.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.top.menuButton.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.top.menuButton:SetScript('OnLeave', function()
		mod.FlightMode.top.menuButton.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.top.menuButton:SetScript('OnClick', function()
		if E.Retail then
			BUI:Dropmenu(BUI.MenuListRetail, menuFrame, _G.FlightModeMenuBtn, 'bRight', (E.PixelMode and -32 or -30), (E.PixelMode and -13 or -15), 4, 36)
		elseif E.Forever then
			BUI:Dropmenu(BUI.MenuListForever, menuFrame, _G.FlightModeMenuBtn, 'bRight', (E.PixelMode and -32 or -30), (E.PixelMode and -13 or -15), 4, 36)
		end
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end)

	-- Close button
	mod.FlightMode.top.closeButton = CreateFrame('Button', nil, mod.FlightMode.top)
	mod.FlightMode.top.closeButton:Size(32, 32)
	mod.FlightMode.top.closeButton:Point("RIGHT", mod.FlightMode.top, "RIGHT", -6, 0)

	mod.FlightMode.top.closeButton.img = mod.FlightMode.top.closeButton:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.top.closeButton.img:Point("CENTER")
	mod.FlightMode.top.closeButton.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\close.tga')
	mod.FlightMode.top.closeButton.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.top.closeButton:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.top.closeButton, 'ANCHOR_BOTTOMLEFT', -4, -4)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(L['Exit FlightMode'], 1, 1, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.top.closeButton.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.top.closeButton.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.top.closeButton.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.top.closeButton:SetScript('OnLeave', function()
		mod.FlightMode.top.closeButton.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.top.closeButton:SetScript('OnClick', function()
		mod:SetFlightMode(false)
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end)

	-- Time
	mod.FlightMode.top.timeText = mod.FlightMode.top:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.top.timeText:FontTemplate(nil, 14)
	mod.FlightMode.top.timeText:Point('RIGHT', mod.FlightMode.top.closeButton, 'LEFT', -10, 0)
	mod.FlightMode.top.timeText:SetTextColor(classColor.r, classColor.g, classColor.b)
	mod.FlightMode.top.timeText:SetText("")

	-- Location frame
	mod.FlightMode.top.location = CreateFrame('Frame', 'FlightModeLocation', mod.FlightMode.top)
	mod.FlightMode.top.location:SetFrameLevel(1)
	mod.FlightMode.top.location:SetTemplate('Default', true, true)
	mod.FlightMode.top.location:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.top.location:CreateWideShadow()
	mod.FlightMode.top.location:Point("TOP", mod.FlightMode.top, "CENTER", 0, 6)
	mod.FlightMode.top.location:Width(LOCATION_WIDTH)
	mod.FlightMode.top.location:Height(50)

	mod.FlightMode.top.location.text = mod.FlightMode.top.location:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.top.location.text:FontTemplate(nil, 18)
	mod.FlightMode.top.location.text:Point('CENTER')
	mod.FlightMode.top.location.text:SetWordWrap(false)

	-- Coords X frame
	mod.FlightMode.top.location.x = CreateFrame('Frame', nil, mod.FlightMode.top.location)
	mod.FlightMode.top.location.x:SetTemplate('Default', true, true)
	mod.FlightMode.top.location.x:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.top.location.x:CreateWideShadow()
	mod.FlightMode.top.location.x:Point("RIGHT", mod.FlightMode.top.location, "LEFT", (E.PixelMode and -4 or -6), 0)
	mod.FlightMode.top.location.x:Width(60)
	mod.FlightMode.top.location.x:Height(40)

	mod.FlightMode.top.location.x.text = mod.FlightMode.top.location.x:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.top.location.x.text:FontTemplate(nil, 18)
	mod.FlightMode.top.location.x.text:Point('CENTER')

	-- Coords Y frame
	mod.FlightMode.top.location.y = CreateFrame('Frame', nil, mod.FlightMode.top.location)
	mod.FlightMode.top.location.y:SetTemplate('Default', true, true)
	mod.FlightMode.top.location.y:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.top.location.y:CreateWideShadow()
	mod.FlightMode.top.location.y:Point("LEFT", mod.FlightMode.top.location, "RIGHT", (E.PixelMode and 4 or 6), 0)
	mod.FlightMode.top.location.y:Width(60)
	mod.FlightMode.top.location.y:Height(40)

	mod.FlightMode.top.location.y.text = mod.FlightMode.top.location.y:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.top.location.y.text:FontTemplate(nil, 18)
	mod.FlightMode.top.location.y.text:Point('CENTER')

	-- Bottom frame
	mod.FlightMode.bottom = CreateFrame("Frame", nil, mod.FlightMode)
	mod.FlightMode.bottom:SetFrameLevel(0)
	mod.FlightMode.bottom:SetTemplate('Transparent', true, true)
	mod.FlightMode.bottom:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.bottom:CreateWideShadow()
	mod.FlightMode.bottom:Point("BOTTOM", mod.FlightMode, "BOTTOM", 0, -E.Border)
	mod.FlightMode.bottom:Width(GetScreenWidth() + (E.Border*2))
	mod.FlightMode.bottom:Height(52)

	-- BenikUI logo
	mod.FlightMode.bottom.logo = mod.FlightMode:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.bottom.logo:Size(420, 105)
	mod.FlightMode.bottom.logo:Point("BOTTOM", mod.FlightMode.bottom, "CENTER", 0, -20)
	mod.FlightMode.bottom.logo:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\logo_benikui.tga')
	mod.FlightMode.bottom.logo:Hide()

	-- WoW logo
	mod.FlightMode.bottom.wowlogo = CreateFrame('Frame', nil, mod.FlightMode) -- need this to upper the logo layer
	mod.FlightMode.bottom.wowlogo:Point("BOTTOM", mod.FlightMode.bottom, "CENTER", 0, -20)
	mod.FlightMode.bottom.wowlogo:SetFrameStrata("MEDIUM")
	mod.FlightMode.bottom.wowlogo:Size(300, 150)
	mod.FlightMode.bottom.wowlogo.tex = mod.FlightMode.bottom.wowlogo:CreateTexture(nil, 'OVERLAY')

	local currentExpansionLevel = GetClampedCurrentExpansionLevel();
	local expansionDisplayInfo = GetExpansionDisplayInfo(currentExpansionLevel);
	if expansionDisplayInfo then
		mod.FlightMode.bottom.wowlogo.tex:SetTexture(expansionDisplayInfo.logo)
	end

	mod.FlightMode.bottom.wowlogo.tex:SetInside()
	mod.FlightMode.bottom.wowlogo:Hide()

	-- BenikUI version
	mod.FlightMode.bottom.benikui = mod.FlightMode.bottom:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.bottom.benikui:FontTemplate(nil, 10)
	mod.FlightMode.bottom.benikui:SetFormattedText("v%s", BUI.Version)
	mod.FlightMode.bottom.benikui:Point("TOP", mod.FlightMode.bottom.logo, "BOTTOM", 0, 12)
	mod.FlightMode.bottom.benikui:SetTextColor(1, 1, 1)
	mod.FlightMode.bottom.benikui:Hide()

	-- Message frame. Shows when request stop is pressed
	mod.FlightMode.message = CreateFrame("Frame", nil, mod.FlightMode)
	mod.FlightMode.message:SetFrameLevel(0)
	mod.FlightMode.message:Point("CENTER", UIParent, "CENTER")
	mod.FlightMode.message:Size(10, 30)
	mod.FlightMode.message:Hide()

	mod.FlightMode.message.text = mod.FlightMode.message:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.message.text:FontTemplate(nil, 18)
	mod.FlightMode.message.text:SetFormattedText("%s", TAXI_CANCEL_DESCRIPTION)
	mod.FlightMode.message.text:Point("CENTER")
	mod.FlightMode.message.text:SetTextColor(1, 1, 0, .7)
	mod.FlightMode.message.text:SetAlpha(0)

	-- Request Stop button
	mod.FlightMode.bottom.requestStop = CreateFrame('Button', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.requestStop:Size(32, 32)
	mod.FlightMode.bottom.requestStop:Point("LEFT", mod.FlightMode.bottom, "LEFT", 10, 0)
	mod.FlightMode.bottom.requestStop:EnableMouse(true)

	mod.FlightMode.bottom.requestStop.img = mod.FlightMode.bottom.requestStop:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.bottom.requestStop.img:Point("CENTER")
	mod.FlightMode.bottom.requestStop.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\arrow.tga')
	mod.FlightMode.bottom.requestStop.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.bottom.requestStop:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.bottom.requestStop, 'ANCHOR_RIGHT', 1, 0)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(TAXI_CANCEL_DESCRIPTION, 1, 1, 1)
		GameTooltip:AddLine(L['LeftClick to Request Stop'], 0.7, 0.7, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.bottom.requestStop.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.bottom.requestStop.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.bottom.requestStop.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.bottom.requestStop:SetScript('OnLeave', function()
		mod.FlightMode.bottom.requestStop.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.bottom.requestStop:SetScript('OnClick', function()
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
		TaxiRequestEarlyLanding();
		mod.FlightMode.bottom.requestStop:EnableMouse(false)
		mod.FlightMode.bottom.requestStop.img:SetVertexColor(1, 0, 0, .7)
		mod.FlightMode.message:Show()
		C_TimerAfter(.5, function()
			UIFrameFadeIn(mod.FlightMode.message.text, 1, 0, 1)
		end)
		C_TimerAfter(8, function()
			UIFrameFadeOut(mod.FlightMode.message, 1, 1, 0)
		end)
	end)

	-- Toggle Location button
	mod.FlightMode.bottom.info = CreateFrame('Button', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.info:Size(32, 32)
	mod.FlightMode.bottom.info:Point("LEFT", mod.FlightMode.bottom.requestStop, "RIGHT", 10, 0)

	mod.FlightMode.bottom.info.img = mod.FlightMode.bottom.info:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.bottom.info.img:Point("CENTER")
	mod.FlightMode.bottom.info.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\info.tga')
	mod.FlightMode.bottom.info.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.bottom.info:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.bottom.info, 'ANCHOR_RIGHT', 1, 0)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(L['Toggle Location and Coords'], 1, 1, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.bottom.info.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.bottom.info.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.bottom.info.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.bottom.info:SetScript('OnLeave', function()
		mod.FlightMode.bottom.info.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.bottom.info:SetScript('OnClick', function()
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
		if _G.FlightModeLocation:GetAlpha() == 1 then
			UIFrameFadeOut(_G.FlightModeLocation, 0.2, 1, 0)
		else
			UIFrameFadeIn(_G.FlightModeLocation, 0.2, 0, 1)
		end
	end)

	-- Toggle Map button
	mod.FlightMode.bottom.map = CreateFrame('Button', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.map:Size(32, 32)
	mod.FlightMode.bottom.map:Point("LEFT", mod.FlightMode.bottom.info, "RIGHT", 10, 0)

	mod.FlightMode.bottom.map.img = mod.FlightMode.bottom.map:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.bottom.map.img:Point("CENTER")
	mod.FlightMode.bottom.map.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\map.tga')
	mod.FlightMode.bottom.map.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.bottom.map:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.bottom.map, 'ANCHOR_RIGHT', 1, 0)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(L['Toggle World Map'], 1, 1, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.bottom.map.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.bottom.map.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.bottom.map.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.bottom.map:SetScript('OnLeave', function()
		mod.FlightMode.bottom.map.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.bottom.map:SetScript('OnClick', function()
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
		ToggleWorldMap()
	end)

	-- Toggle bags button
	mod.FlightMode.bottom.bags = CreateFrame('Button', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.bags:Size(32, 32)
	mod.FlightMode.bottom.bags:Point("LEFT", mod.FlightMode.bottom.map, "RIGHT", 10, 0)

	mod.FlightMode.bottom.bags.img = mod.FlightMode.bottom.bags:CreateTexture(nil, 'OVERLAY')
	mod.FlightMode.bottom.bags.img:Point("CENTER")
	mod.FlightMode.bottom.bags.img:SetTexture('Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\flightMode\\bags.tga')
	mod.FlightMode.bottom.bags.img:SetVertexColor(1, 1, 1, .7)

	mod.FlightMode.bottom.bags:SetScript('OnEnter', function()
		GameTooltip:SetOwner(mod.FlightMode.bottom.bags, 'ANCHOR_RIGHT', 1, 0)
		GameTooltip:ClearLines()
		GameTooltip:AddLine(L['Toggle Bags'], 1, 1, 1)
		GameTooltip:Show()
		if db.gameMenuColor == 1 then
			mod.FlightMode.bottom.bags.img:SetVertexColor(classColor.r, classColor.g, classColor.b)
		elseif db.gameMenuColor == 2 then
			mod.FlightMode.bottom.bags.img:SetVertexColor(BUI:unpackColor(E.db.benikui.colors.customGameMenuColor))
		else
			mod.FlightMode.bottom.bags.img:SetVertexColor(BUI:unpackColor(E.db.general.valuecolor))
		end
	end)

	mod.FlightMode.bottom.bags:SetScript('OnLeave', function()
		mod.FlightMode.bottom.bags.img:SetVertexColor(1, 1, 1, .7)
		GameTooltip:Hide()
	end)

	mod.FlightMode.bottom.bags:SetScript('OnClick', function()
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
		_G.ToggleAllBags()
	end)

	-- Time flying
	mod.FlightMode.bottom.timeFlying = CreateFrame('Frame', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.timeFlying:Point("RIGHT", mod.FlightMode.bottom, "RIGHT", -10, 0)
	mod.FlightMode.bottom.timeFlying:SetTemplate("Default", true, true)
	mod.FlightMode.bottom.timeFlying:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.bottom.timeFlying:Size(70,30)
	mod.FlightMode.bottom.timeFlying.txt = mod.FlightMode.bottom.timeFlying:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.bottom.timeFlying.txt:FontTemplate(nil, 14)
	mod.FlightMode.bottom.timeFlying.txt:SetText("00:00")
	mod.FlightMode.bottom.timeFlying.txt:Point("CENTER", mod.FlightMode.bottom.timeFlying, "CENTER")
	mod.FlightMode.bottom.timeFlying.txt:SetTextColor(1, 1, 1)

	-- fps
	mod.FlightMode.bottom.fps = CreateFrame('Frame', nil, mod.FlightMode.bottom)
	mod.FlightMode.bottom.fps:Point('RIGHT', mod.FlightMode.bottom.timeFlying, 'LEFT', -10, 0)
	mod.FlightMode.bottom.fps:SetTemplate("Default", true, true)
	mod.FlightMode.bottom.fps:SetBackdropBorderColor(.3, .3, .3, 1)
	mod.FlightMode.bottom.fps:Size(70,30)
	mod.FlightMode.bottom.fps.txt = mod.FlightMode.bottom.fps:CreateFontString(nil, 'OVERLAY')
	mod.FlightMode.bottom.fps.txt:FontTemplate(nil, 14)
	mod.FlightMode.bottom.fps.txt:Point('CENTER', mod.FlightMode.bottom.fps, 'CENTER')
	mod.FlightMode.bottom.fps.txt:SetText("")

	-- Add Shadow at the bags
	local containerFrame = _G.ElvUI_ContainerFrame
	if containerFrame then
		containerFrame:CreateWideShadow()
		containerFrame.wideshadow:Hide()
	end

	-- Add Shadow at the left chat
	local leftPanel = _G.LeftChatPanel
	leftPanel.backdrop:CreateWideShadow()
	leftPanel.backdrop.wideshadow:Hide()
	leftPanel.backdrop.wideshadow:OffsetFrameLevel(-1, leftPanel.backdrop)

	mod:LoadEvents()
	mod:ToggleLogo()

	hooksecurefunc(M, "SetLargeWorldMap", mod.SetFrameParent)
	hooksecurefunc(M, "SetSmallWorldMap", mod.SetFrameParent)

	-- force databars parent. This should fix databars showing after a Pet Battle
	E.FrameLocks['ElvUI_ExperienceBar'] = { parent = E.UIParent }
	E.FrameLocks['ElvUI_ReputationBar'] = { parent = E.UIParent }
	E.FrameLocks['ElvUI_HonorBar'] = { parent = E.UIParent }
	E.FrameLocks['ElvUI_AzeriteBar'] = { parent = E.UIParent }
end

function mod:Init()
	mod:CreateFlightMode()

	mod.initialized = true
end

function mod:PLAYER_LOGIN()
	mod:Init()
end

function mod:Initialize()
	mod:RegisterEvent('PLAYER_LOGIN')
end

BUI:RegisterModule(mod:GetName())