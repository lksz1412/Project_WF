local BUI, E, L, V, P, G = unpack((select(2, ...)))
local mod = BUI:GetModule('Units')
local UF = E:GetModule('UnitFrames')
local NP = E:GetModule('NamePlates')
local AB = E:GetModule('ActionBars')

local _G = _G
local pairs, next, select = pairs, next, select
local hooksecurefunc = hooksecurefunc

local groupUnits = {'party', 'raid1', 'raid2', 'raid3', 'boss', 'arena', 'raidpet'}

function mod:UnitDefaults()
	if E.db.benikui.unitframes.player.portraitWidth == nil then
		E.db.benikui.unitframes.player.portraitWidth = 110
	end
	if E.db.benikui.unitframes.player.portraitHeight == nil then
		E.db.benikui.unitframes.player.portraitHeight = 85
	end
	if E.db.benikui.unitframes.target.portraitWidth == nil then
		E.db.benikui.unitframes.target.portraitWidth = 110
	end
	if E.db.benikui.unitframes.target.portraitHeight == nil then
		E.db.benikui.unitframes.target.portraitHeight = 85
	end
end

function mod:UpdateUF()
	local db = E.db.unitframe.units

	if db.player.enable then
		mod:ArrangePlayer()
	end

	if db.target.enable then
		mod:ArrangeTarget()
	end

	if db.focus.enable then
		mod:ArrangeFocus()
	end

	if db.pet.enable then
		mod:ArrangePet()
	end

	if db.targettarget.enable then
		mod:ArrangeTargetTarget()
	end

	if db.party.enable then
		UF:CreateAndUpdateHeaderGroup('party')
	end
end

function mod:Configure_ReadyCheckIcon(frame)
	local tex = frame.ReadyCheckIndicator

	tex.readyTexture = [[Interface\AddOns\ElvUI_BenikUI\media\textures\ready]]
	tex.notReadyTexture = [[Interface\AddOns\ElvUI_BenikUI\media\textures\notready]]
	tex.waitingTexture = [[Interface\AddOns\ElvUI_BenikUI\media\textures\waiting]]
end

-- Unit Shadows
function mod:UnitShadows()
	for _, frame in pairs(UF.units) do
		if frame and not frame.hasShadow then
			frame.hasShadow = true
			frame:CreateSoftShadow()
			frame.Health.backdrop:CreateSoftShadow()
			frame.Health.backdrop.shadow:Hide()
			frame.Power.backdrop:CreateSoftShadow()
			frame.Power.backdrop.shadow:Hide()
			frame.Buffs.PostUpdateButton = UF.PostUpdateAura
			frame.Debuffs.PostUpdateButton = UF.PostUpdateAura
		end
	end
end

-- Fix unit Power Shadows
function mod:UnitPowerShadows(frame)
	if frame and frame.shadow and frame.Health.backdrop.shadow and frame.Power.backdrop.shadow then
		local power = frame.Power
		local health = frame.Health
		
		if frame.USE_POWERBAR then
			if frame.USE_POWERBAR_OFFSET or frame.USE_MINI_POWERBAR then
				frame.shadow:Hide()
				health.backdrop.shadow:Show()
				power.backdrop.shadow:Show()
			elseif frame.USE_INSET_POWERBAR or frame.POWERBAR_DETACHED then
				frame.shadow:Show()
				health.backdrop.shadow:Hide()
				power.backdrop.shadow:Show()
			else
				frame.shadow:Show()
				health.backdrop.shadow:Hide()
				power.backdrop.shadow:Hide()
			end
		else
			frame.shadow:Show()
		end
	end
end

-- Party Shadows
function mod:PartyShadows()
	local header = _G['ElvUF_Party']
	for i = 1, header:GetNumChildren() do
		local group = select(i, header:GetChildren())

		for j = 1, group:GetNumChildren() do
			local unitbutton = select(j, group:GetChildren())
			if unitbutton and not unitbutton.hasShadow then
				unitbutton.hasShadow = true
				unitbutton:CreateSoftShadow()
				unitbutton.Health.backdrop:CreateSoftShadow()
				unitbutton.Health.backdrop.shadow:Hide()
				unitbutton.Power.backdrop:CreateSoftShadow()
				unitbutton.Power.backdrop.shadow:Hide()
				unitbutton.Portrait.backdrop:CreateSoftShadow()
				unitbutton.Portrait.backdrop.shadow:Hide()
				unitbutton.Buffs.PostUpdateButton = UF.PostUpdateAura
				unitbutton.Debuffs.PostUpdateButton = UF.PostUpdateAura
			end
		end
	end
end

-- Raid Shadows
function mod:RaidShadows()
	for i = 1, 3 do
		local header = _G['ElvUF_Raid'..i]

		for j = 1, header:GetNumChildren() do
			local group = select(j, header:GetChildren())

			for k = 1, group:GetNumChildren() do
				local unitbutton = select(k, group:GetChildren())
				if unitbutton and not unitbutton.hasShadow then
					unitbutton.hasShadow = true
					unitbutton:CreateSoftShadow()
					unitbutton.Health.backdrop:CreateSoftShadow()
					unitbutton.Health.backdrop.shadow:Hide()
					unitbutton.Power.backdrop:CreateSoftShadow()
					unitbutton.Power.backdrop.shadow:Hide()
					unitbutton.Buffs.PostUpdateButton = UF.PostUpdateAura
					unitbutton.Debuffs.PostUpdateButton = UF.PostUpdateAura
				end
			end
		end
	end
end

-- Boss shadows
local MAX_BOSS_FRAMES = 8
function mod:BossShadows()
	for i = 1, MAX_BOSS_FRAMES do
		local unitbutton = _G["ElvUF_Boss"..i]
		if unitbutton and not unitbutton.hasShadow then
			unitbutton.hasShadow = true
			unitbutton:CreateSoftShadow()
			unitbutton.Health.backdrop:CreateSoftShadow()
			unitbutton.Health.backdrop.shadow:Hide()
			unitbutton.Power.backdrop:CreateSoftShadow()
			unitbutton.Power.backdrop.shadow:Hide()
			unitbutton.Buffs.PostUpdateButton = UF.PostUpdateAura
			unitbutton.Debuffs.PostUpdateButton = UF.PostUpdateAura
		end
	end
end

-- Arena shadows
function mod:ArenaShadows()
	for i = 1, 5 do
		local unitbutton = _G["ElvUF_Arena"..i]
		if unitbutton and not unitbutton.hasShadow then
			unitbutton.hasShadow = true
			unitbutton:CreateSoftShadow()
			unitbutton.Trinket:CreateSoftShadow()
			unitbutton.Health.backdrop:CreateSoftShadow()
			unitbutton.Health.backdrop.shadow:Hide()
			unitbutton.Power.backdrop:CreateSoftShadow()
			unitbutton.Power.backdrop.shadow:Hide()
			unitbutton.Buffs.PostUpdateButton = UF.PostUpdateAura
			unitbutton.Debuffs.PostUpdateButton = UF.PostUpdateAura
		end
	end
end

function mod:UpdateGroupPower(unit)
	if unit == 'party' or unit == 'raid1' or unit == 'raid2' or unit == 'raid3' then
		for _, child in next, { UF[unit]:GetChildren() } do
			for _, subchild in next, { child:GetChildren() } do
				mod:UnitPowerShadows(subchild)
			end
		end
	elseif unit == 'boss' or unit == 'arena' then
		for i = 1, 10 do
			mod:UnitPowerShadows(UF[unit..i])
		end
	else
		mod:UnitPowerShadows(UF[unit])
	end
end

-- Tank shadows
function mod:TankShadows()
	for i = 1, 2 do
		local unitbutton = _G["ElvUF_TankUnitButton"..i]
		if unitbutton and not unitbutton.hasShadow then
			unitbutton.hasShadow = true
			unitbutton:CreateSoftShadow()
			unitbutton.Buffs.PostUpdateButton = UF.PostUpdateAura
			unitbutton.Debuffs.PostUpdateButton = UF.PostUpdateAura
		end
	end
end

-- TankTarget shadows
function mod:TankTargetShadows()
	for i = 1, 2 do
		local unitbutton = _G["ElvUF_TankUnitButton"..i.."Target"]
		if unitbutton and not unitbutton.hasShadow then
			unitbutton.hasShadow = true
			unitbutton:CreateSoftShadow()
		end
	end
end

-- Assist shadows
function mod:AssistShadows()
	-- this should also cover the AssistTarget frames since they are children of the Assist header
	hooksecurefunc(UF, "Update_AssistFrames", function(_, frame)
		if frame and not frame.hasShadow then
			frame.hasShadow = true
			frame:CreateSoftShadow()
		end
	end)
end

-- Raidpet Shadows
function mod:RaidpetShadows()
	hooksecurefunc(UF, "Update_RaidpetFrames", function(_, frame)
		if frame and not frame.hasShadow then
			frame.hasShadow = true
			frame:CreateSoftShadow()
		end
	end)
end

-- Hook doesn't work, so wrap instead
local originalPostUpdateAura = UF.PostUpdateAura
UF.PostUpdateAura = function(self, unit, button)
	originalPostUpdateAura(self, unit, button)

	if E.db.benikui.general.shadows then
		if button and not button.hasShadow then
			button.hasShadow = true
			button:CreateSoftShadow()
		end
	end
end

function mod:ChangeDefaultOptions()
	E.Options.args.unitframe.args.individualUnits.args.player.args.power.args.generalGroup.args.height.max = 300
	E.Options.args.unitframe.args.individualUnits.args.player.args.power.args.generalGroup.args.detachGroup.args.detachedWidth.min = ((E.db.unitframe.thinBorders or E.PixelMode) and 3 or 7)
	E.Options.args.unitframe.args.individualUnits.args.target.args.power.args.generalGroup.args.height.max = 300
	E.Options.args.unitframe.args.individualUnits.args.target.args.power.args.generalGroup.args.detachGroup.args.detachedWidth.min = ((E.db.unitframe.thinBorders or E.PixelMode) and 3 or 7)
end

function mod:ADDON_LOADED(event, addon)
	if addon ~= "ElvUI_Options" then return end
	mod:UnregisterEvent(event)
	mod:ChangeDefaultOptions()
end

function mod:Setup()
	mod:UnitDefaults()
	mod:InitPlayer()
	mod:InitTarget()
	mod:InitFocus()
	mod:InitPet()
	mod:InitTargetTarget()

	mod:InitParty()
	mod:InitRaid()

	mod:ChangePowerBarTexture()
	mod:ChangeHealthBarTexture()

	mod:Configure_RoleIcons()

	if E.db.benikui.general.shadows then
		mod:UnitShadows()

		mod:PartyShadows()
		mod:RaidShadows()
		mod:BossShadows()
		mod:ArenaShadows()
		mod:TankShadows()
		mod:TankTargetShadows()
		mod:AssistShadows()
		mod:RaidpetShadows()

		mod:CastBarShadows()

		for _, frame in pairs(UF.units) do
			if frame then
				mod:UnitPowerShadows(frame)
			end
		end

		for _, group in pairs(groupUnits) do
			if group then
				mod:UpdateGroupPower(group)
			end
		end

		hooksecurefunc(UF, "Configure_Power", function(self, frame)
			for _, group in pairs(groupUnits) do
				if group then
					mod:UpdateGroupPower(group)
				end
			end
		end)

		-- AuraBars Shadows
		hooksecurefunc(UF, 'Configure_AuraBars', mod.Configure_AuraBars)
	end

	-- Group Health textures hooks
	if E.db.benikui.unitframes.textures.enableHealth then
		hooksecurefunc(UF, 'Update_PartyFrames', mod.ChangePartyHealthBarTexture)
		hooksecurefunc(UF, 'Update_RaidFrames', mod.ChangeRaidHealthBarTexture)
		hooksecurefunc(UF, 'Update_StatusBars', mod.ChangeHealthBarTexture)
	end

	-- Group Power textures hooks
	if E.db.benikui.unitframes.textures.enablePower then
		hooksecurefunc(UF, 'Update_AllFrames', mod.ChangeUnitPowerBarTexture)
		hooksecurefunc(UF, 'Update_RaidFrames', mod.ChangeRaidPowerBarTexture)
		hooksecurefunc(UF, 'Update_PartyFrames', mod.ChangePartyPowerBarTexture)
		hooksecurefunc(UF, 'Update_ArenaFrames', mod.ChangeArenaPowerBarTexture)
		hooksecurefunc(UF, 'Update_BossFrames', mod.ChangeBossPowerBarTexture)
		hooksecurefunc(UF, 'Update_StatusBars', mod.ChangePowerBarTexture)
	end

	-- ShapeShift fix
	hooksecurefunc(AB, 'StyleShapeShift', mod.ChangeUnitPowerBarTexture)
end


function mod:Init()
	if E.private.unitframe.enable ~= true then return end

	mod:Setup()

	hooksecurefunc(UF, "Configure_ReadyCheckIcon", mod.Configure_ReadyCheckIcon)

	self:RegisterEvent("ADDON_LOADED")

	mod.initialized = true
end

function mod:PLAYER_LOGIN()
	mod:Init()
end

function mod:Initialize()
	mod:RegisterEvent('PLAYER_LOGIN')
end

BUI:RegisterModule(mod:GetName())
