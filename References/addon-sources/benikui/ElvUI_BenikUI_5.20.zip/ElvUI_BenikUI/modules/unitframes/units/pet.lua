﻿local BUI, E, L, V, P, G = unpack((select(2, ...)))
local BU = BUI:GetModule('Units');
local UF = E:GetModule('UnitFrames');

local _G = _G
local CreateFrame = CreateFrame
local hooksecurefunc = hooksecurefunc

function BU:Construct_PetFrame()
	local frame = _G["ElvUF_Pet"]

	if E.db.benikui.general.shadows then
		if not frame.Portrait.backdrop.shadow then
			frame.Portrait.backdrop:CreateSoftShadow()
			frame.Portrait.backdrop.shadow:Hide()
		end
	end

	local f = CreateFrame("Frame", nil, frame)
	frame.portraitmover = f

	self:ArrangePet()
end

function BU:ArrangePet()
	local frame = _G["ElvUF_Pet"]

	do
		frame.PORTRAIT_DETACHED = E.db.benikui.unitframes.pet.detachPortrait
		frame.PORTRAIT_TRANSPARENCY = E.db.benikui.unitframes.pet.portraitTransparent
		frame.PORTRAIT_SHADOW = E.db.benikui.unitframes.pet.portraitShadow
		frame.DETACHED_PORTRAIT_STRATA = E.db.benikui.unitframes.pet.portraitFrameStrata
		frame.PORTRAIT_BACKDROP = E.db.benikui.unitframes.pet.portraitBackdrop

		frame.DETACHED_PORTRAIT_WIDTH = E.db.benikui.unitframes.pet.portraitWidth
		frame.DETACHED_PORTRAIT_HEIGHT = E.db.benikui.unitframes.pet.portraitHeight

		frame.PORTRAIT_AND_INFOPANEL = E.db.benikui.unitframes.infoPanel.fixInfoPanel and frame.USE_INFO_PANEL and frame.PORTRAIT_WIDTH
	end

	-- Portrait
	BU:Configure_Portrait(frame, false)

	-- InfoPanel
	BU:Configure_Infopanel(frame)

	frame:UpdateAllElements("BenikUI_UpdateAllElements")
end

function BU:InitPet()
	if not E.db.unitframe.units.pet.enable then return end
	self:Construct_PetFrame()
	hooksecurefunc(UF, 'Update_PetFrame', BU.ArrangePet)

	-- Needed for some post updates
	hooksecurefunc(UF, "Configure_Portrait", function(self, frame)
		local unitframeType = frame.unitframeType

		if unitframeType == "pet" then
			BU:Configure_Portrait(frame, false)
		end
	end)

	hooksecurefunc(UF, "Configure_Power", function(self, frame)
		local unitframeType = frame.unitframeType

		if unitframeType == "pet" then
			BU:UnitPowerShadows(frame)
		end
	end)
end