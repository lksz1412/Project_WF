local BUI, E, L, V, P, G = unpack((select(2, ...)))
local mod = BUI:GetModule('Dashboards')
local DT = E:GetModule('DataTexts')

local _G = _G
local hooksecurefunc = hooksecurefunc
local tinsert, twipe, tsort = table.insert, table.wipe, table.sort
local ipairs, next = ipairs, next
local format = format
local strfind, tostring = strfind, tostring

local GameTooltip = _G.GameTooltip
local C_CurrencyInfo_GetCurrencyInfo = C_CurrencyInfo.GetCurrencyInfo
local C_CurrencyInfo_GetCurrencyListSize = C_CurrencyInfo.GetCurrencyListSize
local C_CurrencyInfo_GetCurrencyListInfo = C_CurrencyInfo.GetCurrencyListInfo
local C_CurrencyInfo_GetCurrencyListLink = C_CurrencyInfo.GetCurrencyListLink
local C_CurrencyInfo_GetCurrencyIDFromLink = C_CurrencyInfo.GetCurrencyIDFromLink
local C_CurrencyInfo_ExpandCurrencyList = C_CurrencyInfo.ExpandCurrencyList
local C_CurrencyInfo_IsAccountTransferableCurrency = C_CurrencyInfo.IsAccountTransferableCurrency
local GetExpansionLevel = GetExpansionLevel
local IsShiftKeyDown = IsShiftKeyDown
local InCombatLockdown = InCombatLockdown
local BreakUpLargeNumbers = BreakUpLargeNumbers
local LFG_TYPE_DUNGEON = LFG_TYPE_DUNGEON
local MISCELLANEOUS = MISCELLANEOUS
local PLAYER_V_PLAYER = PLAYER_V_PLAYER

local DASH_HEIGHT = 20
local DASH_SPACING = 3
local SPACING = 1
local tokensDB = mod.TokensDB

local position, Xoffset

local classColor = E:ClassColor(E.myclass, true)
local expansion = _G['EXPANSION_NAME'..GetExpansionLevel()]

mod.CurrencyList = {}

local function sortFunction(a, b)
	return a.name < b.name
end

local function CheckTokensPosition()
	if E.db.benikui.dashboards.tokens.enable ~= true then return end

	position, Xoffset = mod:CheckPositionForTooltip(mod.tokensHolder)
end

local function barOnMouseUp(self, btn)
	if InCombatLockdown() then return end
	local id = self.id

	if btn == "RightButton" then
		if IsShiftKeyDown() then
			E.private.benikui.dashboards.tokens.chooseTokens[id] = false
			mod:UpdateTokens()
		else
			E:ToggleOptions()
			local ACD = E.Libs.AceConfigDialog
			if ACD then ACD:SelectGroup("ElvUI", "benikui", "dashboards", "tokens") end
		end
	end
end

local function barOnEnter(self)
	local db = E.db.benikui.dashboards
	local id = self.id

	if db.tokens.tooltip then
		GameTooltip:SetOwner(self, position, Xoffset, 0);
		GameTooltip:SetCurrencyByID(id)
		GameTooltip:AddLine(' ')
		GameTooltip:AddDoubleLine(L['Shift+RightClick to remove'], format('|cffff0000%s |r%s','ID', id), 0.7, 0.7, 1)
		GameTooltip:Show()
	end

	self.Text:SetFormattedText('%s', self.name)
	if db.tokens.mouseover then
		E:UIFrameFadeIn(self, 0.2, self:GetAlpha(), 1)
	end
end

local function barOnLeave(self)
	local db = E.db.benikui.dashboards
	local displayString

	if self.capValue > 0 then
		displayString = format('%s / %s', BreakUpLargeNumbers(self.progress), BreakUpLargeNumbers(self.capValue))
	else
		displayString = format('%s', BreakUpLargeNumbers(self.amount))
	end

	self.Text:SetText(displayString)

	GameTooltip:Hide()

	if db.tokens.mouseover then
		E:UIFrameFadeOut(self, 0.2, self:GetAlpha(), 0)
	end
end

local function holderOnEnter(self)
	local db = E.db.benikui.dashboards

	if db.tokens.mouseover then
		E:UIFrameFadeIn(self, 0.2, self:GetAlpha(), 1)
	end
end

local function holderOnLeave(self)
	local db = E.db.benikui.dashboards

	if db.tokens.mouseover then
		E:UIFrameFadeOut(self, 0.2, self:GetAlpha(), 0)
	end
end

function mod:GetTokenInfo(id)
	local info = C_CurrencyInfo_GetCurrencyInfo(id)

	if info then
		return info.name, info.quantity, info.iconFileID, info.maxWeeklyQuantity, info.maxQuantity, info.discovered, info.quantityEarnedThisWeek, info.totalEarned, info.trackedQuantity, info.useTotalEarnedForMaxQty, info.description
	else
		return
	end
end

function mod:UpdateTokens()
	local db = E.db.benikui.dashboards
	local holder = mod.tokensHolder

	if not db.tokens.enable then holder:Hide() return end

	if(tokensDB[1]) then
		for i = 1, #tokensDB do
			tokensDB[i]:Hide()
		end
		twipe(tokensDB)
		holder:Hide()
	end

	if db.tokens.mouseover then holder:SetAlpha(0) else holder:SetAlpha(1) end

	for _, info in ipairs(mod.CurrencyList) do
		local _, id = unpack(info)

		if id then
			local name, amount, icon, weeklyMax, totalMax, isDiscovered, quantityEarnedThisWeek, totalEarned, trackedQuantity, useTotalEarnedForMaxQty = mod:GetTokenInfo(id)
			if name then
				if isDiscovered == false then E.private.benikui.dashboards.tokens.chooseTokens[id] = nil end

				if E.private.benikui.dashboards.tokens.chooseTokens[id] == true then
					if db.tokens.zeroamount or amount > 0 then
						holder:SetShown(mod:ShouldShowDashboard('tokens'))

						if db.tokens.orientation == 'BOTTOM' then
							holder:Height(((DASH_HEIGHT + (E.PixelMode and 1 or DASH_SPACING)) * (#tokensDB + 1)) + DASH_SPACING + (E.PixelMode and 0 or 2))
							holder:Width(db.tokens.width)
						else
							holder:Height(DASH_HEIGHT + (DASH_SPACING))
							holder:Width(db.tokens.width * (#tokensDB + 1) + ((#tokensDB) *db.tokens.spacing))
						end

						local bar = mod:CreateDashboard(holder, 'tokens', true, false, true)
						local BarColor = (db.barColor == 1 and classColor) or db.customBarColor
						local TextColor = (db.textColor == 1 and classColor) or db.customTextColor
						local isValidCurrency = C_CurrencyInfo_IsAccountTransferableCurrency(id)
						local isWeeklyCapped = weeklyMax == quantityEarnedThisWeek and weeklyMax > 0
						local isSeasonCapped = useTotalEarnedForMaxQty and totalMax == totalEarned and totalMax > 0
						local capped = isWeeklyCapped or isSeasonCapped
						local showWeekly = (db.tokens.weekly and weeklyMax and weeklyMax > 0)
						local capValue = showWeekly and weeklyMax or (totalMax and totalMax > 0 and totalMax) or 0
						local BarMaxValue
						local displayString = ''
						local progress = amount

						if showWeekly then
							progress = quantityEarnedThisWeek or 0
						elseif useTotalEarnedForMaxQty and totalEarned and totalEarned > 0 then
							progress = totalEarned
						elseif trackedQuantity and trackedQuantity > 0 then
							progress = trackedQuantity
						end

						if capValue > 0 then
							displayString = format('%s / %s', BreakUpLargeNumbers(progress), BreakUpLargeNumbers(capValue))
						else
							displayString = format('%s', BreakUpLargeNumbers(amount))
						end

						BarMaxValue = (capValue > 0) and capValue or ((progress > 0) and progress or (amount > 0 and amount or 1))

						bar.Status:SetMinMaxValues(0, BarMaxValue)
						bar.Status:SetValue(progress)
						bar.Status:SetStatusBarColor(BarColor.r, BarColor.g, BarColor.b)

						if capped then
							bar.Text:SetTextColor(1, 0.2, 0.2)
						else
							bar.Text:SetTextColor(TextColor.r, TextColor.g, TextColor.b)
						end

						bar.Text:SetText(displayString)
						bar.IconBG.Icon:SetTexture(icon)

						bar:SetScript('OnEnter', barOnEnter)
						bar:SetScript('OnLeave', barOnLeave)
						bar:SetScript('OnMouseUp', barOnMouseUp)

						bar.awicon:SetShown(isValidCurrency)

						bar.id = id
						bar.name = name
						bar.totalMax = totalMax
						bar.amount = amount
						bar.weeklyMax = weeklyMax
						bar.capped = capped
						bar.progress = progress
						bar.capValue = capValue

						tinsert(tokensDB, bar)
					end
				end
			end
		end
	end

	tsort(tokensDB, sortFunction)

	for key, frame in next, tokensDB do
		frame:ClearAllPoints()
		if(key == 1) then
			frame:Point('TOPLEFT', holder, 'TOPLEFT', 0, -SPACING -(E.PixelMode and 0 or 4))
		else
			if db.tokens.orientation == 'BOTTOM' then
				frame:Point('TOP', tokensDB[key - 1], 'BOTTOM', 0, -SPACING -(E.PixelMode and 0 or 2))
			else
				frame:Point('LEFT', tokensDB[key - 1], 'RIGHT', db.tokens.spacing +(E.PixelMode and 0 or 2), 0)
			end
		end
	end

	mod:FontStyle(tokensDB)
	mod:FontColor(tokensDB, true)
	mod:BarColor(tokensDB)
	mod:IconPosition(tokensDB, 'tokens')
end

function mod:PopulateCurrencyData()
	local Collapsed = {}
	local listSize, i = C_CurrencyInfo_GetCurrencyListSize(), 1

	local headerIndex
	while listSize >= i do
		local info = C_CurrencyInfo_GetCurrencyListInfo(i)
		if info.isHeader and not info.isHeaderExpanded then
			C_CurrencyInfo_ExpandCurrencyList(i, true)
			listSize = C_CurrencyInfo_GetCurrencyListSize()
			Collapsed[info.name] = true
		end

		if info.isHeader then
			local isMain = (info.name == expansion or info.name == MISCELLANEOUS or info.name == PLAYER_V_PLAYER) or strfind(info.name, LFG_TYPE_DUNGEON)
			mod.CurrencyList[i] = { info.name, nil, nil, isMain }
			headerIndex = i
		end

		if not info.isHeader then
			local currencyLink = C_CurrencyInfo_GetCurrencyListLink(i)
			local currencyID = currencyLink and C_CurrencyInfo_GetCurrencyIDFromLink(currencyLink)
			if currencyID then
				mod.CurrencyList[tostring(currencyID)] = info.name
				mod.CurrencyList[i] = { info.name, currencyID, headerIndex}
			end
		end
		i = i + 1
	end

	for k = 1, listSize do
		local info = C_CurrencyInfo_GetCurrencyListInfo(k)
		if not info then
			break
		elseif info.isHeader and info.isHeaderExpanded and Collapsed[info.name] then
			C_CurrencyInfo_ExpandCurrencyList(k, false)
		end
	end

	twipe(Collapsed)
end

function mod:CURRENCY_DISPLAY_UPDATE(_, currencyID)
	if currencyID and not mod.CurrencyList[tostring(currencyID)] then
		local info = C_CurrencyInfo_GetCurrencyInfo(currencyID)
		if info then
			mod:PopulateCurrencyData()
		end
	end
	mod:UpdateTokens()
end

function mod:ToggleTokens()
	local db = E.db.benikui.dashboards
	local holder = mod.tokensHolder

	if db.tokens.enable then
		E:EnableMover(holder.mover.name)
		mod:RegisterEvent('CURRENCY_DISPLAY_UPDATE')

		mod:PopulateCurrencyData()
		mod:ToggleStyle(holder, 'tokens')
		mod:ToggleTransparency(holder, 'tokens')

		holder:SetScript('OnEnter', holderOnEnter)
		holder:SetScript('OnLeave', holderOnLeave)
	else
		E:DisableMover(holder.mover.name)
		mod:UnregisterEvent('CURRENCY_DISPLAY_UPDATE')

		holder:SetScript('OnEnter', nil)
		holder:SetScript('OnLeave', nil)
	end

	mod:UpdateTokens()
	CheckTokensPosition()
end

function mod:CreateTokensDashboard()
	local db = E.db.benikui.dashboards
	local holder = mod:CreateDashboardHolder('BUI_TokensDashboard', 'tokens')
	holder:Point('TOPLEFT', E.UIParent, 'TOPLEFT', 4, -123)
	holder:Width(db.tokens.width or 150)

	mod.tokensHolder = holder

	E:CreateMover(holder, 'tokenHolderMover', L['Tokens'], nil, nil, nil, 'ALL,BENIKUI', nil, 'benikui,dashboards,tokens')
	mod:ToggleTokens()
end

function mod:LoadTokens()
	mod:CreateTokensDashboard()

	hooksecurefunc(DT, 'LoadDataTexts', mod.UpdateTokens)
	hooksecurefunc(E, 'ToggleMoveMode', CheckTokensPosition)
	mod:SecureHook(_G.TokenFrame, 'Update', mod.PopulateCurrencyData)
end
