local BUI, E, L, V, P, G = unpack((select(2, ...)))
local mod = BUI:GetModule('Dashboards')
local DT = E:GetModule('DataTexts')

local _G = _G
local format = format
local next, ipairs = next, ipairs
local tinsert, twipe, tsort, tostring = table.insert, table.wipe, table.sort, tostring
local hooksecurefunc = hooksecurefunc

local GameTooltip = _G.GameTooltip
local GetProfessions = GetProfessions
local GetProfessionInfo = GetProfessionInfo
local C_TradeSkillUI_OpenTradeSkill = C_TradeSkillUI.OpenTradeSkill
local InCombatLockdown = InCombatLockdown
local TRADE_SKILLS = TRADE_SKILLS

local DASH_HEIGHT = 20
local DASH_SPACING = 3
local SPACING = 1
local professionsDB = mod.ProfessionsDB

local classColor = E:ClassColor(E.myclass, true)

local function sortFunction(a, b)
	return a.name < b.name
end

local function barOnMouseUp(self, btn)
	if InCombatLockdown() then return end
	local skillLine = self.skillLine

	if btn == "RightButton" then
		E:ToggleOptions()
		local ACD = E.Libs.AceConfigDialog
		if ACD then ACD:SelectGroup("ElvUI", "benikui", "dashboards", "professions") end
	else
		C_TradeSkillUI_OpenTradeSkill(skillLine)
	end
end

local function barOnEnter(self)
	local db = E.db.benikui.dashboards
	local holder = self:GetParent()

	self.Text:SetFormattedText('%s', self.name)

	if db.professions.mouseover then
		E:UIFrameFadeIn(holder, 0.2, holder:GetAlpha(), 1)
	end
end

local function barOnLeave(self)
	local db = E.db.benikui.dashboards
	local holder = self:GetParent()

	if (self.rankModifier and self.rankModifier > 0) then
		self.Text:SetFormattedText('%s |cFF6b8df4+%s|r / %s', self.rank, self.rankModifier, self.maxRank)
	else
		self.Text:SetFormattedText('%s / %s', self.rank, self.maxRank)
	end

	GameTooltip:Hide()

	if db.professions.mouseover then
		E:UIFrameFadeOut(holder, 0.2, holder:GetAlpha(), 0)
	end
end

local function holderOnEnter(self)
	local db = E.db.benikui.dashboards

	if db.professions.mouseover then
		E:UIFrameFadeIn(self, 0.2, self:GetAlpha(), 1)
	end
end

local function holderOnLeave(self)
	local db = E.db.benikui.dashboards

	if db.professions.mouseover then
		E:UIFrameFadeOut(self, 0.2, self:GetAlpha(), 0)
	end
end

function mod:UpdateProfessions()
	local db = E.db.benikui.dashboards
	local holder = mod.proHolder

	if not db.professions.enable then holder:Hide() return end

	if(professionsDB[1]) then
		for i = 1, #professionsDB do
			professionsDB[i]:Hide()
		end
		twipe(professionsDB)
		holder:Hide()
	end

	if db.professions.mouseover then holder:SetAlpha(0) else holder:SetAlpha(1) end

	local prof1, prof2, archy, fishing, cooking = GetProfessions()

	if (prof1 or prof2 or archy or fishing or cooking) then
		local proftable = { GetProfessions() }

		for i = 1, 5 do
			local id = proftable[i]
			if id then
				local name, icon, rank, maxRank, _, _, skillLine, rankModifier, _, _, skillLineName = GetProfessionInfo(id)

				if name and (rank < maxRank or (not db.professions.capped)) then
					if E.private.benikui.dashboards.professions.chooseProfessions[id] == true then
						holder:SetShown(mod:ShouldShowDashboard('professions'))

						if db.professions.orientation == 'BOTTOM' then
							holder:Height(((DASH_HEIGHT + (E.PixelMode and 1 or DASH_SPACING)) * (#professionsDB + 1)) + DASH_SPACING + (E.PixelMode and 0 or 2))
							holder:Width(db.professions.width)
						else
							holder:Height(DASH_HEIGHT + (DASH_SPACING))
							holder:Width(db.professions.width * (#professionsDB + 1) + ((#professionsDB) *db.professions.spacing))
						end

						local bar
						if not bar then
							bar = mod:CreateDashboard(holder, 'professions', true)

							local RankModifier = (rankModifier and rankModifier > 0)
							local MaxValue = (RankModifier and (maxRank + rankModifier)) or maxRank
							local StatusBarValue = (RankModifier and (rank + rankModifier)) or rank
							local BarColor = (db.barColor == 1 and classColor) or db.customBarColor
							local TextColor = (db.textColor == 1 and classColor) or db.customTextColor
							local displayString = ''

							bar.Status:SetMinMaxValues(1, MaxValue)
							bar.Status:SetValue(StatusBarValue)
							bar.Status:SetStatusBarColor(BarColor.r, BarColor.g, BarColor.b)

							if RankModifier then
								displayString = format('%s |cFF6b8df4+%s|r / %s', rank, rankModifier, maxRank)
							else
								displayString = format('%s / %s', rank, maxRank)
							end

							bar:SetScript('OnEnter', barOnEnter)
							bar:SetScript('OnLeave', barOnLeave)
							bar:SetScript('OnMouseUp', barOnMouseUp)

							bar.Text:SetText(displayString)
							bar.Text:SetTextColor(TextColor.r, TextColor.g, TextColor.b)
							bar.IconBG.Icon:SetTexture(icon)

							bar.db = db
							bar.name = name
							bar.skillLine = skillLine
							bar.rank = rank
							bar.maxRank = maxRank
							bar.rankModifier = rankModifier

							tinsert(professionsDB, bar)
						end
					end
				end
			end
		end
	end

	tsort(professionsDB, sortFunction)

	for key, frame in next, professionsDB do
		frame:ClearAllPoints()
		if(key == 1) then
			frame:Point('TOPLEFT', holder, 'TOPLEFT', 0, -SPACING -(E.PixelMode and 0 or 4))
		else
			if db.professions.orientation == 'BOTTOM' then
				frame:Point('TOP', professionsDB[key - 1], 'BOTTOM', 0, -SPACING -(E.PixelMode and 0 or 2))
			else
				frame:Point('LEFT', professionsDB[key - 1], 'RIGHT', db.professions.spacing +(E.PixelMode and 0 or 2), 0)
			end
		end
	end

	mod:FontStyle(professionsDB)
	mod:FontColor(professionsDB)
	mod:BarColor(professionsDB)
	mod:IconPosition(professionsDB, 'professions')
end

function mod:ToggleProfessions()
	local db = E.db.benikui.dashboards
	local holder = mod.proHolder

	if db.professions.enable then
		E:EnableMover(holder.mover.name)
		mod:RegisterEvent('SKILL_LINES_CHANGED', 'UpdateProfessions')
		mod:RegisterEvent('CHAT_MSG_SKILL', 'UpdateProfessions')

		mod:ToggleStyle(holder, 'professions')
		mod:ToggleTransparency(holder, 'professions')

		holder:SetScript('OnEnter', holderOnEnter)
		holder:SetScript('OnLeave', holderOnLeave)
	else
		E:DisableMover(holder.mover.name)
		mod:UnregisterEvent('SKILL_LINES_CHANGED')
		mod:UnregisterEvent('CHAT_MSG_SKILL')

		holder:SetScript('OnEnter', nil)
		holder:SetScript('OnLeave', nil)
	end
	mod:UpdateProfessions()
end

function mod:CreateProfessionsDashboard()
	local db = E.db.benikui.dashboards
	local ElvUI_MinimapClusterHolder = _G.ElvUI_MinimapClusterHolder
	local mapholderWidth = E.private.general.minimap.enable and ElvUI_MinimapClusterHolder:GetWidth() or 150
	local DASH_WIDTH = db.professions.width or 150

	local holder = mod:CreateDashboardHolder('BUI_ProfessionsDashboard', 'professions')

	if E.private.general.minimap.enable then
		holder:Point('TOPLEFT', ElvUI_MinimapClusterHolder, 'BOTTOMLEFT', 0, -5)
	else
		holder:Point('TOPRIGHT', E.UIParent, 'TOPRIGHT', -5, -184)
	end

	holder:Width(mapholderWidth or DASH_WIDTH)

	mod.proHolder = holder

	E:CreateMover(holder, 'ProfessionsMover', TRADE_SKILLS, nil, nil, nil, 'ALL,BENIKUI', nil, 'benikui,dashboards,professions')
	mod:ToggleProfessions()
end

local CopyTable = CopyTable
local function fixChooseProfessionsTypo()
	local db = E.private.benikui.dashboards.professions

	if not db.choosePofessions then return end

	if not db.chooseProfessions then
		db.chooseProfessions = CopyTable(db.choosePofessions)
	end

	db.choosePofessions = nil
end

function mod:LoadProfessions()
	fixChooseProfessionsTypo() -- temp

	mod:CreateProfessionsDashboard()
	hooksecurefunc(DT, 'LoadDataTexts', mod.UpdateProfessions)
end