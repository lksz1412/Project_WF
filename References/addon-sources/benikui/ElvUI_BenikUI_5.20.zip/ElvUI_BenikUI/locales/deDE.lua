-- German localization file for deDE
local L = ElvUI[1].Libs.ACL:NewLocale("ElvUI", "deDE")

-- WoW Locales
L["CLASS_COLORS"] = "Klassenfarben";
L["COLOR_PICKER"] = "Farbauswahl";
L["EDIT"] = "Bearbeiten";
L["HOME"] = "Heim"; -- Changed the Blizzard default, it would make no sense otherwise!
L["WORLD"] = "Welt";

--core
L['is loaded. For any issues or suggestions, please visit'] = "ist geladen. Für Fehler oder Vorschläge besucht bitte:"
L["%s\n\nYour ElvUI version %.2f is not compatible with BenikUI.\nMinimum ElvUI version needed is %.2f. Please download it from here:\n"] = "%s\n\nIhre ElvUI-Version %.2f ist nicht mit BenikUI kompatibel.\nDie mindestens benötigte ElvUI-Version ist %.2f. Bitte lade sie hier herunter:\n"
L["|cffff0000BenikUI Error|r\n\nIt seems like BenikUI Retail version is installed on WoW Classic. Please install BenikUI Classic version.\n|cff00c0faTip: Usually happens with Twitch Client|r"] = "|cffff0000BenikUI-Fehler|r\n\nAnscheinend ist die BenikUI Retail Version auf WoW Classic installiert. Bitte installiere die BenikUI Classic-Version.\n|cff00c0faTipp: Tritt normalerweise beim Twitch Client auf|r"

-- General options
L["BenikUI is a completely external ElvUI mod. More available options can be found in ElvUI options (e.g. Actionbars, Unitframes, Player and Target Portraits), marked with "] = "BenikUI ist ein komplett externer ElvUI Mod. Weitere verfügbare Optionen findest Du in den ElvUI Optionen (z.B. Aktionsleisten, Einheitenfenster, Spieler und Ziel Portrait), markiert in "
L["Credits:"] = "Danksagung:"
L['ActionBar Style Color'] = "Aktionsleiste Stilfarbe"
L['BenikUI Style'] = "BenikUI Stil"
L['Game Menu Color'] = "Spielmenü Farbe"
L['Enable/Disable the decorative bars from UI elements'] = "Aktiviert/Deaktiviert die dekorativen Leisten für UI Elemente"
L['Hide BenikUI Style'] = "Verstecke BenikUI Stil"
L['Show/Hide the decorative bars from UI elements. Usefull when applying Shadows, because BenikUI Style must be enabled. |cff00c0faNote: Some elements like the Actionbars, Databars or BenikUI Datatexts have their own Style visibility options.|r'] = "Zeigt/Versteckt die dekorativen Leisten für UI Elemente. Nützlich wenn die Schatten angewandt wurden, BenikUI Stil muss aktiviert sein. |cff00c0faHinweis: Einige Elemente wie Aktionsleisten, Informationsleisten oder BenikUI Infotexte haben ihre eigene Sichtbarkeits Optionen.|r"
L['Style Color'] = "Stilfarbe"
L['by Benik (EU-Emerald Dream)'] = "von Benik (EU-Emerald Dream)"
L['light blue color.'] = "hellblau"
L['Splash Screen'] = "Startbildschirm"
L['Shadow'] = "Schatten"
L['Shadow Size'] = "Schattengröße"
L['Shadow Alpha'] = "Schattentransparenz"
L['Font Size'] = "Schriftgröße"
L["Miscellaneous"] = "Sonstiges"

-- Layout
L['LeftClick: Toggle Configuration'] = "Links Klick: Einstellungen umschalten"
L['RightClick: Toggle Embedded Addon'] = "Rechts Klick: Einbettung Addon umschalten"
L['ShiftClick to toggle chat'] = "Shift Klick um Chat umzuschalten"
L['Click to show the Addon List'] = "Klicken um die AddOn-Liste zu zeigen"

-- Custom Panels
L['Custom Panels'] = "Benutzerdefinierte Leisten"
L['Clone'] = "Klone"
L['Clone the Custom Panel: |cff00c0fa%s|r.\nPlease type the new Name'] = "Benutzerdefiniertes Bedienfeld klonen: |cff00c0fa%s|r.\nBitte gebe den neuen Namen ein"
L["Create"] = "Erstelle"
L["Enable tooltip to reveal the panel name"] = "Aktiviere den Tooltip um den Leistenamen zu erfahren"
L["Hide in Pet Battle"] = "Verstecke in Haustiefkämpfen"
L["Name Tooltip"] = "Namenstooltip"
L['New Custom Panel'] = "Neue Benutzerdefinierte Leiste"
L['Style Position'] = "Stilposition"
L["Texture Color"] = "Texturfarbe"
L["The Custom Panel name |cff00c0fa%s|r already exists. Please choose another one."] = "Der Name |cff00c0fa%s|r von einer Benutzerdefiniertem Leiste existiert bereits. Bitte wähle einen anderen."
L["This will delete the Custom Panel named |cff00c0fa%s|r.\nContinue?"] = "Dies wird die Benutzerdefinierte Leiste mit dem Namen |cff00c0fa%s|r löschen.\nFortfahren?"
L["This works like a macro, you can run different situations to get the panel to show/hide differently.\n Example: '[combat] show;hide'"] = "Dies funktioniert wie ein Makro, Du kannst verschiedene Situationen ausführen, um das Fenster unterschiedlich anzuzeigen/auszublenden.\n Beispiel: '[combat] show;hide'"
L["Title Bar Position"] = "Titelleisten Position"
L["Title Text Position"] = "Titeltext Position"
L["Title"] = "Titel"
L["Type a unique name for the new panel. \n|cff00c0faNote: 'BenikUI_' will be added at the beginning, to ensure uniqueness|r"] = "Gib einen einzigartigen Namen für die neue Leiste ein. \n|cff00c0faHinweis: 'BenikUI_' wird am Anfang hinzugefügt um die Einzigarigkeit zu gewährleisten|r"

-- Profiles
L['Successfully created and applied profile(s) for |cffffff00%s|r'] = "Erfolgreich ein Profil erstellt und angewandt für |cffffff00%s|r" -- %s is the addon name
L['|cffffff00%s|r profile for this character already exists. Aborting.'] = "|cffffff00%s|r Profil für diesen Charakter besteht bereits. Abbruch." -- %s is the addon name

-- Skins
L['|cff00c0faNote:|r The Skin and the Half Bar options will not apply if |cffffa500%s|r DBM profile is not selected in DBM options.'] = true

-- Misc
L['Shown Logo'] = "Zeige Logo"
L['iLevel'] = true --No need to translate
L['Show item level per slot, on the character info frame'] = "Zeigt das Gegenstandslevel pro Slot, im Spielerfenster"
L['Inside the item slot'] = "Innerhalb des Ausrüstungsplatz"
L['Outside the item slot'] = "Ausserhalb des Ausrüstungsplatz"
L['Chat EditBox'] = true
L['Position'] = true
L['Position of the Chat EditBox, if datatexts are disabled this will be forced to be above chat.'] = true

-- Flight mode
L['Flight Mode'] = "Flugmodus"
L['Exit FlightMode'] = "Verlasse den Flugmodus"
L['Show an enhanced game menu'] = "Zeigt ein erweitertes Spielmenu"
L['Toggle Location and Coords'] = "Schalte Umgebungstext und Koordinaten um"
L['Toggle World Map'] = "Schalte Weltkarte um"
L['Display the Flight Mode screen when taking flight paths'] = "Zeige den Flugmodus wenn du eine Flugroute benutzt"

-- DataTexts
L['BenikUI Middle DataText'] = "BenikUI mittlerer Infotext"
L['Hide Mail Icon'] = "Verstecke das Postsymbol"
L['Middle'] = "Mitte"
L['New Mail'] = "Neue Post"
L['No Mail'] = "Keine Post"
L['Set Datatext Values'] = "Datentextwerte festlegen"
L['Show/Hide Chat DataTexts. ElvUI chat datatexts must be disabled'] = "Chat Infotexte anzeigen/ausblenden. ElvUI Infotexte müssen dafür deaktiviert sein"
L['Show/Hide Mail Icon on minimap'] = "Postsymbol an der Minimap anzeigen/ausblenden"
L['Styles the chat datetexts and buttons only if both chat backdrops are set to "Hide Both".'] = "Passt die Chatinfotexte und Tasten an, wenn der Chathintergrund auf 'Verstecke Beide' gesetzt ist."
L['Left Chat Panel'] = "Linkes Chatfenster"
L['Right Chat Panel'] = "Rechtes Chatfenster"
L['Middle Panel'] = "Mittlere Leiste"

-- install
L["BenikUI didn't find any supported addons for profile creation"] = "BenikUI konnte keine unterstütze Profile für Addons finden"
L['BenikUI successfully created and applied profile(s) for:'] = "BenikUI hat erfolgreich Addon Profile erstellt und angewandt für:"
L["By pressing the Continue button, BenikUI will be applied on your current ElvUI installation.\n\n|cffff8000 TIP: It would be nice if you apply the changes in a new profile, just in case you don't like the result.|r"] = "Durch drücken der Weiter-Taste werden die BenikUI-Änderungen in der vorhandenen ElvUI Installation angewand.\n\n|cffff8000 TIP: Es wäre gut, wenn Du die Änderungen in einem neuen Profil erstellst. Nur für den Fall dass Du mit den Änderungen nicht zufrieden bist.|r"
L["This part of the installation process will fill BenikUI datatexts.\n\n|cffff8000This doesn't touch ElvUI datatexts|r"] = "Dieser Teil des Installationsprozesses wird die BenikUI Infotexte einstellen.\n\n|cffff8000Hierbei werden die ElvUI Infotexte nicht verändert|r"
L["This part of the installation process will reposition your Unitframes."] = "Dieser Teil des Installationsprozesses wird die Einheitenfenster neu positionieren."
L['Actionbars Set'] = "Aktionsleisten gesetzt"
L['Addons Set'] = "Addons gesetzt"
L["BenikUI options are marked with light blue color, inside ElvUI options."] = "BenikUI Optionen sind in hellblau hervorgehoben in den ElvUI Optionen."
L['Color Theme Set'] = "Farbschema gesetzt"
L['Color Themes'] = "Farbschema"
L['DataTexts Set'] = "Infotexte gesetzt"
L['Diablo'] = true --No need to translate
L['ElvUI'] = true --No need to translate
L['Hearthstone'] = true --No need to translate
L['Installation'] = true --No need to translate
L['Mists'] = true --No need to translate
L['Please click a button below to apply a color theme.'] = "Bitte klick eine der Tasten unten um ein Farbschema anzuwenden."
L['Please click the button below to apply the new layout.'] = "Bitte klick die Taste unten um das neue Layout anzuwenden."
L['Please click a button below to setup your Unitframes.'] = "Bitte klick auf die Taste unten um das Einheitenfenster einzustellen."
L['Please click a button below to setup your actionbars.'] = "Bitte klick auf die Taste unten um die Aktionsleisten einzustellen."
L['Please click the button below to setup your addons.'] = "Bitte klick auf die Taste unten um deine Addons einzustellen."
L['Please click the button below to setup your chat windows.'] = "Bitte klick auf die Taste unten um das Chatfenster einzustellen."
L['Please click the button below to setup your datatexts.'] = "Bitte klick auf die Taste unten um die Infotexte einzustellen."
L['Setup Addons'] = "Addons einstellen"
L['Setup Layout'] = "Layout einstellen"
L['This part of the installation process sets up your chat fonts and colors.'] = "Dieser Teil des Installationsprozesses ändert die Chatschrifart und -farbe."
L['This part of the installation process will create and apply profiles for addons like Recount, DBM, ElvUI plugins, etc'] = "Dieser Teil des Installationsprozesses erstellt und wendet Profile für Addons wie Recount, DBM und andere ElvUI Plugins an"
L['This part of the installation process will reposition your Actionbars and will enable backdrops'] = "Dieser Teil des Installationsprozesses wird die Aktionsleisten neu positionieren und wird den Hintergrund einschalten"
L['This part of the installation will apply a Color Theme'] = "Dieser Teil der Installation wendet ein Farbschema an"
L['This part of the installation will change the default ElvUI look.'] = "Dieser Teil der Installation ändert das standard Aussehen von ElvUI."
L['UnitFrames'] = "Einheitenfenster"
L['Unitframes Set'] = "Einheitenfenster setzen"
L['Welcome to BenikUI version %s, for ElvUI %s.'] = "Willkommen zu BenikUI Version %s, für ElvUI %s."
L['Welcome'] = "Willkommen"
L['You are now finished with the installation process. If you are in need of technical support please visit us at https://www.tukui.org.'] = "Du hast den Installationsprozess jetzt abgeschlossen. Wenn du technische Unterstützung brauchst besuch uns bitte https://www.tukui.org."

-- actionbar options
L['Bar 1'] = "Leiste 1"
L['Bar 2'] = "Leiste 2"
L['Request Stop button'] = "Haltewunschtaste"

-- Request stop button
L['LeftClick to Request Stop'] = "Links-Klick um am nächsten Flugpunkt zu landen"
L['RightClick to Hide'] = "Rechts-Klick zum verstecken"

-- afk Mode
L["Logout Timer"] = "Ausloggzeit"
L["Random Stats"] = "Zufällige Werte"
L["remaining till level"] = "verbleibend bis zum Level"

-- Dashboards
L["Change the Professions Dashboard width."] = "Ändert die Beruf-Dashboard Breite."
L["Change the Tokens Dashboard width."] = "Ändert die Token-Dashboard Breite."
L["Enable the Professions Dashboard."] = "Aktiviert das Berufe Dashboard."
L["Filter Capped"] = "Filtere am Cap"
L['Amount'] = "Menge"
L['Bar Color'] = "Leistenfarbe"
L['Bar Height'] = "Leistenhöhe"
L['Change the Bar Height.'] = "Ändert die Leistenhöhe."
L['Change the System Dashboard width.'] = "Ändert die System Dashboardbreite."
L['Choose font for all dashboards.'] = "Wähle Schriftart für alle Dashboards."
L['Click :'] = "Klick :"
L["Custom Color"] = "Benutzerdefinierte Farben"
L['Dashboards'] = true --No need to translate
L['Enable the System Dashboard.'] = "Aktiviert das System Dashboard."
L['Enable the Tokens Dashboard.'] = "Aktivert das Abzeichen Dashboard."
L['Enable/Disable'] = "Aktivieren/Deaktivieren"
L['Faction Colors'] = "Fraktionsfarben"
L['Fast Volume +/-'] = "Schnelle Lautstärke +/-"
L['Filter Capped'] = "Filter Gekappt"
L['Hide in Instance'] = "Verstecke in Instanz"
L['Latency (MS)'] = "Latenz (MS)"
L['MouseWheel :'] = "Mausrad :"
L['RightClick :'] = "Rechtsklick :"
L['Select Professions'] = "Berufe auswählen"
L['Select System Board'] = "Wähle System Board"
L['Select Tokens'] = "Abzeichen auswählen"
L['Set the font size.'] = "Schriftgröße auswählen."
L['Shift+MouseWheel :'] = "Shift+Moausrad :"
L['Shift+RightClick to remove'] = "Shift+Rechtsklick um zu entfernen"
L['Show the token, even if the amount is 0'] = "Abzeichen anzeigen, auch wenn die Anzahl 0 ist"
L['Show Weekly max tokens instead of total max'] = "Zeige Wöchentliches max. Abzeichen anstatt vom totalem Max."
L['Show Weekly max'] = "Zeige wöchentliches Maximum"
L['Show zero amount tokens'] = "Zeige Abzeichen mit der Anzahl 0"
L['Show/Hide Professions Dashboard when in combat'] = "Berufe Dashboard im Kampf ein-/ausblenden"
L['Show/Hide Reputations Dashboard when in combat'] = "Ruf Dashboard im Kampf ein-/ausblenden"
L['Show/Hide System Dashboard when in combat'] = "System Dashboard im Kampf anzeigen/ausblenden"
L['Show/Hide Tokens Dashboard when in combat'] = "Abzeichen Dashboard im Kampf anzeigen/ausblenden"
L['Show/Hide Tooltips'] = "Tooltip anzeigen/ausblenden"
L['System'] = true --No need to translate
L['Text Alignment'] = "Textausrichtung"
L['Tip: Click to free memory'] = "Tip: Klicken um den Speicher zu bereinigen"
L['Tip: Grayed tokens are not yet discovered'] = "Tip: Ausgegraute Abzeichen sind bis jetzt noch nicht entdeckt"
L['Update Throttle'] = "Aktualisierung drosseln"
L['Use DataTexts font'] = "Benutze Infotext Schriftart"
L['Use Faction Colors on Bars'] = "Benutze Fraktionsfarben auf Leisten"
L['Use Faction Colors on Text'] = "Benutze Fraktionsfarben auf Texten"
L['Hide in Housing'] = true

-- Items
L['Items'] = "Gegenstände"
L['Enable the Items Dashboard.'] = "Aktiviere das Item Dashboard"
L['New Item by ID'] = "Neuer Gegenstand mit ID"
L["The ID |cff00c0fa%d|r doesn't exist in the game."] = "Diese ID |cff00c0fa%d|r existiert nicht in diesem Spiel."
L['The Item |cff00c0fa%s|r already exists.'] = "Das Item |cff00c0fa%s|r existiert bereits."
L['Change the Items Dashboard width.'] = "Ändere die Breite des Item Dashboards."
L['Show/Hide items Dashboard when in combat'] = "Anzeigen/Ausblenden von dem Item Dashboards im Kampf"
L['Show Max Amount'] = "Maximalanzahl anzeigen"

-- Databars Options
L['Notifiers'] = "Benachrichtigungen"
L['Button Backdrop'] = "Tasten Hintergrund"
L['Without Backdrop'] = "Ohne Hintergrund"

-- Skins Options
L['AddOnSkins'] = true --No need to translate
L['AddOns Decor'] = "AddOns Dekor"
L['Choose which addon you wish to be decorated to fit with BenikUI style'] = "Wähle aus, welches Addon du stylen möchtest so dass es am besten zu BenikUI passt"
L['ElvUI AddOns'] = true --No need to translate
L['decor.'] = "dekor."
L['This will create and apply profile for '] = "Dieses wird ein Profil erstellen und anwenden für "
L['Profiles'] = "Profile"

-- UnitFrame Options
L['Apply shadow under the portrait'] = "Aktiviere den Schatten unter dem Portrait"
L['Apply transparency on the portrait backdrop.'] = "Wende Transparenz auf den Portrait Hintergrund an."
L['BenikUI Style on Portrait'] = "BenikUI Stil auf dem Portrait"
L['Castbar Backdrop Color'] = "Zauberleisten Hintergrundfarbe"
L['Castbar Text'] = "Zauberleisten Text"
L['Change the detached portrait height'] = "Ändert die Höhe des abgetrennten Portrait"
L['Change the detached portrait width'] = "Ändert die Breite des abgetrennten Portrait"
L['Copy Player portrait width and height'] = "Kopiere Spieler Portrait Breite und Höhe"
L['Detach Portrait'] = "Abgetrenntes Portrait"
L['Fix InfoPanel width'] = "Behebt InfoPanel Breite"
L['Health statusbar texture. Applies only on Group Frames'] = "Gesundheit Statusleiste Texture. Wird nur auf GruppenFrames angewandt"
L['Ignore Transparency'] = "Ignoriere Transparenz"
L['Lower InfoPanel width when potraits are enabled.'] = "Verringert die InfoPanel Breite, wenn Portraits aktiviert sind."
L['Makes the portrait backdrop transparent'] = "Dadurch wird der Portrait Hintergrund transparent"
L['Player Size'] = "Spieler Größe"
L['Power statusbar texture.'] = "Kraft Statusleiste Textur."
L['Replaces the default role icons with SVUI ones.'] = "Ersetzt die Standard Rollen Symbole mit denen von SVUI."
L['Style Height'] = "Stil Höhe"
L['SVUI Icons'] = "SVUI Symbole"
L['This will ignore ElvUI Health Transparency setting on all Group Frames.'] = "Dieses ignoriert die ElvUI Gesundheit Transparenz Einstellung auf allen Gruppenfenstern."
L['Vertical power statusbar'] = "Vertikale Kraft Statusleiste"

-- Castbar
L['Castbar'] = "Zauberleiste"
L['Force show any text placed on the InfoPanel, while casting.'] = "Zwinge die Anzeige des Textes auf dem InfoPanel, während des zauberns."
L['Show Castbar text'] = "Zeige Zauberleisten Text"
L['Show InfoPanel text'] = "Zeige InfoPanel Text"
L['Show on Target'] = "Zeige auf dem Ziel"
L['This applies on all available castbars.'] = "Wird auf allen verfügbaren Zauberleisten angewendet."

-- Raid
L['Class Hover'] = "Klassenfarbeneffekt"
L['Enable Class color on health border, when mouse over'] = "Aktiviert den Klassenfarbeneffekt auf den Gesundheitsrand während Mouseover"

-- Widget Bars
L['Widget Bars'] = "Widget Leisten"
L['Maw Bar'] = "Schlundleiste"
L['Prey Bar'] = true
L['Color by Tier'] = "Farbe nach Stufe"
L['Text yOffset'] = "Text Y-Versatz"
L['Half Bar'] = "Halbe Leisten"
L["Percent"] = "Prozent"
L['Preview Bar'] = true
L['Hide Preview'] = true

-- Information
L['Information'] = "Informationen"
L['Support'] = "Unterstützung"
L['Download'] = true --No need to translate
L['Beta versions'] = "Beta Versionen"
L['Coding'] = true --No need to translate
L['Testing & Inspiration'] = "Tester & Inspiration"
L['Donations'] = "Spenden"
L['My other Addons'] = "Meine anderen Addons"
L['Discord Server'] = true --No need to translate
L['Git Ticket tracker'] = true --No need to translate
L['Tukui.org'] = true --No need to translate
-- Location Plus
L['Adds player location, coords + 2 Datatexts and a tooltip with info based on player location/level.'] = "Fügt Spieler Aufenthaltsort, Koordinaten + 2 Infotexte und einen Tooltip mit Informationen basierend auf dem Aufenthaltsort/Level hinzu."
-- Nuts & Bolts
L['ElvUI Nuts & Bolts is a compilation of my addons hosted at tukui.org/Twitch plus some features that are moved from BenikUI'] = "ElvUI Nuts & Bolt ist eine Sammlung von meinen AddOns auf tukui.org/Twitch und einigen Ergänzungen die von BenikUI waren"

-- afk
L["Jan"] = true
L["Feb"] = true
L["Mar"] = true
L["Apr"] = true
L["May"] = "Mai"
L["Jun"] = true
L["Jul"] = true
L["Aug"] = true
L["Sep"] = true
L["Oct"] = "Okt"
L["Nov"] = true
L["Dec"] = "Dez"

L["Sun"] = "So"
L["Mon"] = "Mo"
L["Tue"] = "Di"
L["Wed"] = "Mi"
L["Thu"] = "Do"
L["Fri"] = "Fr"
L["Sat"] = "Sa"

-- Addon friendly names (no need to translate)
L['Altoholic'] = true
L['AtlasLoot'] = true
L['Clique'] = true
L['Details'] = true
L['ElvUI_Enhanced'] = true
L['LocationPlus'] = true
L['Recount'] = true
L['Shadow & Light'] = true
L['Skada'] = true
L['TinyDPS'] = true
L['oRA3'] = true
L['Deadly Boss Mods'] = true
L['BigWigs'] = true
L['Zygor Guides'] = true
L['Immersion'] = true
L['Project Azilroka'] = true
L['Kaliels Tracker'] = true