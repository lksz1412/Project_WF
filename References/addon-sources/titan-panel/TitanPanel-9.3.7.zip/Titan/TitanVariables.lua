--[===[ File
This file contains the routines to initialize, get, and set the basic data structures used by Titan.
--]===]

--[===[ Var
TitanBarData ^^: Titan static bar reference and placement info
TitanAll is used for settings used for Titan itself such as use global profile, tootip modifier, etc.
TitanSettings, TitanSkins,  are the structures saved to disk (listed in toc).
TitanSettings : is the table that holds the Titan variables by character and the plugins used by that character.
TitanSkins : holds the list of Titan and custom skins available to the user.
   It is assumed that the skins are in the proper folder on the hard drive. Blizzard does not allow addons to access the disk.


TitanSettings has major sections with associated shortcuts in the code
TitanPlayerSettings =		TitanSettings.Players[toon]
TitanPluginSettings =		TitanSettings.Players[toon].Plugins		: Successful registered plugins with all flags
TitanPanelSettings =		TitanSettings.Players[toon].Panel		: **
TitanPanelRegister =		TitanSettings.Players[toon].Register	: .registry of all plugins (Titan and LDB) to be registered with Titan
TitanBarDataVars ^^=		TitanSettings.Players[toon].BarVars		: Titan user selected placement info
TitanAdjustSettings =		TitanSettings.Players[toon].Adjust		: List of frames Titan can adjust, vertically only

Note: Way back there may have been reasons for separating Titan 'all' and 'panel'.
They are kept distinct to not break any legacy plugins.

** :
- Has Plugin placement data under Location and Buttons
- Bar settings Show / Hide, transparency, skins, etc
- Per character Titan settings plugin spacing, global skin, etc

^^ :
- The index is the string name of the Titan Bar.
Having the same index helps coordinate static and user selected bar data
--]===]

local L = LibStub("AceLocale-3.0"):GetLocale(TITAN_ID, true)
local _G = getfenv(0);
local media = LibStub("LibSharedMedia-3.0")

if (GetLocale() == "ruRU") then
	-- Special fix for Russian - "Friz Quadrata TT" does not seem to work
	TITAN_PANEL_CONSTANTS.FONT_NAME = "Arial Narrow"
end
local TPC = TITAN_PANEL_CONSTANTS -- shortcut

--[===[ Var
TitanBarData table.
The table holds:
: the name of each Titan bar (as the index)
: the short name of the bar
: whether the bar is relative - top or bottom or short (user placed)
: the order they should be considered
: SetPoint values for show / hide
: short bar specific values

The short name is used to build names of the various saved variables, frames,
 and buttons used by Titan.
--]===]
local SHORT_WIDTH = 200
local y_top = GetScreenHeight() -- * UIParent:GetEffectiveScale()
local x_max = GetScreenWidth()
local x_mid = (GetScreenWidth() / 2) - (SHORT_WIDTH / 2)

---local Calc screen Y
---@return number
local function Calc_Y(n)
	return (GetScreenHeight() - (Titan_G.bars.HEIGHT * n))
end

---local Calc screen X
---@return number
local function Calc_X()
	return (GetScreenWidth() / 2) - (SHORT_WIDTH / 2)
end

--[[
--]]
---@class TitanBarData Titan Bar description
---@field frame_name string Full bar frame name, same as index
---@field locale_name string Localized short name
---@field name string Internal short name
---@field vert string TITAN_TOP | TITAN_BOTTOM | TITAN_SHORT
---@field tex_name string Full frame name for texture - Titan skin
---@field hider string Full frame name of hider - TITAN_TOP / TITAN_BOTTOM only
---@field hide_y integer Offset to move if hidden (offscreen)
---@field plugin_y_offset integer Plugin offset within bar
---@field plugin_x_offset integer Min width, short bars only
---@field show table Used for SetPoint to display the bar
---@field bott? table Used for SetPoint to display full bar only (sized using two points)
---@field user_move boolean false - full bar; true - short bar
---This holds the static data used to set up and control Titan bars.

TitanBarData = {
	[Titan_G.bars.PRE_STR .. "Bar"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Bar",
		locale_name = L["TITAN_PANEL_MENU_TOP"],
		name = "Bar",
		vert = TITAN_TOP,
		order = 1,
		tex_name = Titan_G.bars.TEX_PRE .. "Bar",
		hider = Titan_G.bars.HIDER_PRE .. "Bar",
		hide_y = (Titan_G.bars.HEIGHT * 3),
		plugin_y_offset = 1,
		plugin_x_offset = 5,
		show = { pt = "TOPLEFT", rel_fr = "UIParent", rel_pt = "TOPLEFT", },
		bott = { pt = "BOTTOMRIGHT", rel_fr = "UIParent", rel_pt = "TOPRIGHT", },
		user_move = false,
	},
	[Titan_G.bars.PRE_STR .. "Bar2"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Bar2",
		locale_name = L["TITAN_PANEL_MENU_TOP2"],
		name = "Bar2",
		vert = TITAN_TOP,
		order = 2,
		tex_name = Titan_G.bars.TEX_PRE .. "Bar2",
		hider = Titan_G.bars.HIDER_PRE .. "Bar2",
		hide_y = (Titan_G.bars.HEIGHT * 10),
		plugin_y_offset = 1,
		plugin_x_offset = 5,
		show = { pt = "TOPLEFT", rel_fr = "UIParent", rel_pt = "TOPLEFT", },
		bott = { pt = "BOTTOMRIGHT", rel_fr = "UIParent", rel_pt = "TOPRIGHT", },
		user_move = false,
	},
	[Titan_G.bars.PRE_STR .. "AuxBar2"] = {
		frame_name = Titan_G.bars.PRE_STR .. "AuxBar2",
		locale_name = L["TITAN_PANEL_MENU_BOTTOM2"],
		name = "AuxBar2",
		vert = TITAN_BOTTOM,
		order = 3,
		tex_name = Titan_G.bars.TEX_PRE .. "AuxBar2",
		hider = Titan_G.bars.HIDER_PRE .. "AuxBar2",
		hide_y = -(Titan_G.bars.HEIGHT * 2),
		plugin_y_offset = 1,
		plugin_x_offset = 5,
		show = { pt = "TOPLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		bott = { pt = "BOTTOMRIGHT", rel_fr = "UIParent", rel_pt = "BOTTOMRIGHT", },
		user_move = false,
	},
	[Titan_G.bars.PRE_STR .. "AuxBar"] = {
		frame_name = Titan_G.bars.PRE_STR .. "AuxBar",
		locale_name = L["TITAN_PANEL_MENU_BOTTOM"],
		name = "AuxBar",
		vert = TITAN_BOTTOM,
		order = 4,
		tex_name = Titan_G.bars.TEX_PRE .. "AuxBar",
		hider = Titan_G.bars.HIDER_PRE .. "AuxBar",
		hide_y = -(Titan_G.bars.HEIGHT * 3),
		plugin_y_offset = 1,
		plugin_x_offset = 5,
		show = { pt = "TOPLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		bott = { pt = "BOTTOMRIGHT", rel_fr = "UIParent", rel_pt = "BOTTOMRIGHT", },
		user_move = false,
	},
	[Titan_G.bars.PRE_STR .. "Short01"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short01",
		locale_name = SHORT .. " 01",
		name = "Short01",
		vert = TITAN_SHORT,
		order = 5,
		tex_name = Titan_G.bars.TEX_PRE .. "Short01",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short02"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short02",
		locale_name = SHORT .. " 02",
		name = "Short02",
		vert = TITAN_SHORT,
		order = 6,
		tex_name = Titan_G.bars.TEX_PRE .. "Short02",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short03"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short03",
		locale_name = SHORT .. " 03",
		name = "Short03",
		vert = TITAN_SHORT,
		order = 7,
		tex_name = Titan_G.bars.TEX_PRE .. "Short03",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short04"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short04",
		locale_name = SHORT .. " 04",
		name = "Short04",
		vert = TITAN_SHORT,
		order = 8,
		tex_name = Titan_G.bars.TEX_PRE .. "Short04",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short05"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short05",
		locale_name = SHORT .. " 05",
		name = "Short05",
		vert = TITAN_SHORT,
		order = 9,
		tex_name = Titan_G.bars.TEX_PRE .. "Short05",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short06"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short06",
		locale_name = SHORT .. " 06",
		name = "Short06",
		vert = TITAN_SHORT,
		order = 10,
		tex_name = Titan_G.bars.TEX_PRE .. "Short06",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short07"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short07",
		locale_name = SHORT .. " 07",
		name = "Short07",
		vert = TITAN_SHORT,
		order = 11,
		tex_name = Titan_G.bars.TEX_PRE .. "Short07",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short08"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short08",
		locale_name = SHORT .. " 08",
		name = "Short08",
		vert = TITAN_SHORT,
		order = 12,
		tex_name = Titan_G.bars.TEX_PRE .. "Short08",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short09"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short09",
		locale_name = SHORT .. " 09",
		name = "Short09",
		vert = TITAN_SHORT,
		order = 13,
		tex_name = Titan_G.bars.TEX_PRE .. "Short09",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
	[Titan_G.bars.PRE_STR .. "Short10"] = {
		frame_name = Titan_G.bars.PRE_STR .. "Short10",
		locale_name = SHORT .. " 10",
		name = "Short10",
		vert = TITAN_SHORT,
		order = 14,
		tex_name = Titan_G.bars.TEX_PRE .. "Short10",
		hider = nil,
		hide_y = -(Titan_G.bars.HEIGHT * 4),
		plugin_y_offset = 1,
		plugin_x_offset = 10,
		show = { pt = "BOTTOMLEFT", rel_fr = "UIParent", rel_pt = "BOTTOMLEFT", },
		user_move = true,
	},
}

--[===[ Var TitanBarPositions table
The table holds:
- the name of each Titan bar (as the index)
- the X and Y position of the bar
- the width of the bar

The index must be matched to the TitanBarData table!
This table wil be saved under "Players" to rember the placement of Short bars.

The cooresponding Defaults table holds the starting values.
The original Titan (full width) bars values are used for default X and Y
--]===]
TitanBarDataVars = {}

TitanSkinsDefaultPath = "Interface\\AddOns\\Titan\\Artwork\\"
TitanSkinsCustomPath = TitanSkinsDefaultPath .. "Custom\\"
TitanSkinsPathEnd = "\\"

---@class TitanBarVars Titan Bar variables selectable by user
---@field off_x integer Offset for SetPoint
---@field off_y integer Offset for SetPoint
---@field off_w integer Bar width
---@field skin table Path and alpha / transparency
---@field color table r,b,g,alpha as number 1.0 - 0.0
---@field texure string Titan_G.NONE | Titan_G.SKIN | Titan_G.COLOR
---@field show boolean Whether user wants this Bar shown or not
---@field auto_hide boolean Whether user wants this Bar on auto hide or not
---@field align integer TITAN_PANEL_BUTTONS_ALIGN_LEFT | TITAN_PANEL_BUTTONS_ALIGN_CENTER
---@field hide_in_combat boolean Whether user wants this Bar hidden during combat or not
---Index is the Full bar frame name, same as TitanBarData.
---Global is an additional index used if the user wants all Bars to be the same skin or color.

TitanBarVarsDefaults = {
	--[[
	["Global"] = -- holds 'global' user settings; NOT for use in the frame loop!
	{
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		texure = Titan_G.NONE, -- Titan_G.NONE or Titan_G.SKIN or Titan_G.COLOR
		hide_in_combat = false,
	},
	--]]
	[Titan_G.bars.PRE_STR .. "Bar"] = {
		off_x = 0,
		off_y = 0,
		off_w = x_max,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN, -- or Titan_G.COLOR
		show = true,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Bar2"] = {
		off_x = 0,
		off_y = -(Titan_G.bars.HEIGHT),
		off_w = x_max,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "AuxBar2"] = {
		off_x = 0,
		off_y = (Titan_G.bars.HEIGHT * 2),
		off_w = x_max,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "AuxBar"] = {
		off_x = 0,
		off_y = (Titan_G.bars.HEIGHT),
		off_w = x_max,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short01"] = {
		off_x = x_mid,
		off_y = Calc_Y(3),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short02"] = {
		off_x = x_mid,
		off_y = Calc_Y(4),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short03"] = {
		off_x = x_mid,
		off_y = Calc_Y(5),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short04"] = {
		off_x = x_mid,
		off_y = Calc_Y(6),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short05"] = {
		off_x = x_mid,
		off_y = Calc_Y(7),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short06"] = {
		off_x = x_mid,
		off_y = Calc_Y(8),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short07"] = {
		off_x = x_mid,
		off_y = Calc_Y(9),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short08"] = {
		off_x = x_mid,
		off_y = Calc_Y(10),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short09"] = {
		off_x = x_mid,
		off_y = Calc_Y(11),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		color_border = true,
		texure = Titan_G.SKIN,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
	[Titan_G.bars.PRE_STR .. "Short10"] = {
		off_x = x_mid,
		off_y = Calc_Y(12),
		off_w = SHORT_WIDTH,
		skin = { path = TitanSkinsDefaultPath, alpha = 0.7 },
		color = { r = 1.0, g = .5, b = 1.0, alpha = 1.0 },
		texure = Titan_G.SKIN,
		color_border = true,
		show = false,
		auto_hide = false,
		align = TITAN_PANEL_BUTTONS_ALIGN_LEFT, -- TITAN_PANEL_BUTTONS_ALIGN_CENTER
		hide_in_combat = false,
		hide_in_pvp = false,
		plugin_off_y = 0,
	},
}

local TitanAdjDefaults = {
	adjust = false,
	offset = 0,
}
TitanAdjustSettings = {} -- holds frames that Titan allows user to adjust

-- Timers used within Titan
TitanTimers = {}

--[===[ Var
TitanPluginToBeRegistered table holds each plugin that is requesting to be a plugin.
TitanPluginToBeRegisteredNum is the number of plugins that have requested.
Each plugin in the table will be updated with the status of the registration and will be available in the Titan Attempted option.
--]===]
TitanPluginToBeRegistered = {}
TitanPluginToBeRegisteredNum = 0

TitanPluginRegisteredNum = 0

--[===[ Var
TitanPluginExtras table holds the plugin data for plugins that are in saved variables but not loaded on the current character.
Saved as TitanPlayerSettings.Extra
TitanPluginExtrasNum is the number of plugins not loaded.
--]===]
TitanPluginExtras = {}
TitanPluginExtrasNum = 0

-- Global to hold where the Titan menu orginated from...
TitanPanel_DropMenu = nil

--[===[ Var
TITAN_PANEL_SAVED_VARIABLES table holds the Titan Panel Default SavedVars.
--]===]
-- These two MUST be in sync, same number of entries
local Default_Buttons = {
	"Location",
	"XP",
	"Gold",
	"Clock",
	"Volume",
	"AutoHide_Bar",
	"Bag",
	"Repair",
}
local Default_Button_Locs = {
	"Bar",
	"Bar",
	"Bar",
	"Bar",
	"Bar",
	"Bar",
	"Bar",
	"Bar",
}
TITAN_PANEL_SAVED_VARIABLES = {
	Buttons = Default_Buttons,
	Location = Default_Button_Locs,
	TexturePath = "Interface\\AddOns\\Titan\\Artwork\\",
	Transparency = 0.7,
	AuxTransparency = 0.7,
	Scale = 1,
	ButtonSpacing = 20,
	IconSpacing = 0,
	TooltipTrans = 1,
	TooltipFont = 1,
	TooltipTimeout = 0.0, -- New 2026 Jan
	DisableTooltipFont = 1,
	FontName = TPC.FONT_NAME,
	FrameStrata = "LOW",
	FontSize = TPC.FONT_SIZE,
	LogAdjust = false,
	MinimapAdjust = false,
	BagAdjust = 1,
	TicketAdjust = 1,
	Position = 1,
	ButtonAlign = 1,
	LockButtons = false,
	LockAutoHideInCombat = false,
	VersionShown = 1,
	ToolTipsShown = 1,
	HideTipsInCombat = false,
	--	HideBarsInCombat = false, -- removed for 8.4.0 Sep 2025
	--	HideBarsInPVP = false,    -- removed for 8.4.0 Sep 2025
	-- Classic
	ScreenAdjust = false,
	AuxScreenAdjust = false,
	MainMenuBarXAdj = 0,
	-- End
	-- for the independent bars
	Bar_Show = true,
	Bar_Hide = false,
	Bar_Align = TITAN_PANEL_BUTTONS_ALIGN_LEFT,
	Bar_Transparency = 0.7,
	Bar2_Show = false,
	Bar2_Hide = false,
	Bar2_Transparency = 0.7,
	Bar2_Align = TITAN_PANEL_BUTTONS_ALIGN_LEFT,
	AuxBar_Show = false,
	AuxBar_Hide = false,
	AuxBar_Transparency = 0.7,
	AuxBar_Align = TITAN_PANEL_BUTTONS_ALIGN_LEFT,
	AuxBar2_Show = false,
	AuxBar2_Hide = false,
	AuxBar2_Transparency = 0.7,
	AuxBar2_Align = TITAN_PANEL_BUTTONS_ALIGN_LEFT,
	--
	SyncWithProfile = "<>" -- new Oct 2025
};

--[===[ Var
TITAN_ALL_SAVED_VARIABLES table holds the Titan Panel Global SavedVars.
--]===]
TITAN_ALL_SAVED_VARIABLES = {
	-- for timers in seconds
	TimerLDB = 2,
	-- Global profile
	GlobalProfileUse = false,
	GlobalProfileName = TITAN_PROFILE_NONE,
	Silenced = false, -- Silent Load : name and version
	Registered = false, -- for debug
	-- OrderHallCommandBar Status
	OrderHall = true,
	UseTooltipModifer = false,
	TooltipModiferAlt = false,
	TooltipModiferCtrl = false,
	TooltipModiferShift = false,
	-- Classic
	TimerPEW = 4,
	TimerDualSpec = 2,
	TimerAdjust = 1,
	TimerVehicle = 1,
	-- End
};

-- The skins released with Titan
TitanSkinsDefault = {
	{ name = "Titan Default",  titan = true, path = TitanSkinsDefaultPath },
	{ name = "AllBlack",       titan = true, path = TitanSkinsCustomPath .. "AllBlack Skin" .. TitanSkinsPathEnd },
	{ name = "BlackPlusOne",   titan = true, path = TitanSkinsCustomPath .. "BlackPlusOne Skin" .. TitanSkinsPathEnd },
	{ name = "Christmas",      titan = true, path = TitanSkinsCustomPath .. "Christmas Skin" .. TitanSkinsPathEnd },
	{ name = "Charcoal Metal", titan = true, path = TitanSkinsCustomPath .. "Charcoal Metal" .. TitanSkinsPathEnd },
	{ name = "Crusader",       titan = true, path = TitanSkinsCustomPath .. "Crusader Skin" .. TitanSkinsPathEnd },
	{ name = "Cursed Orange",  titan = true, path = TitanSkinsCustomPath .. "Cursed Orange Skin" .. TitanSkinsPathEnd },
	{ name = "Dark Wood",      titan = true, path = TitanSkinsCustomPath .. "Dark Wood Skin" .. TitanSkinsPathEnd },
	{ name = "Deep Cave",      titan = true, path = TitanSkinsCustomPath .. "Deep Cave Skin" .. TitanSkinsPathEnd },
	{ name = "Elfwood",        titan = true, path = TitanSkinsCustomPath .. "Elfwood Skin" .. TitanSkinsPathEnd },
	{ name = "Engineer",       titan = true, path = TitanSkinsCustomPath .. "Engineer Skin" .. TitanSkinsPathEnd },
	{ name = "Frozen Metal",   titan = true, path = TitanSkinsCustomPath .. "Frozen Metal Skin" .. TitanSkinsPathEnd },
	{ name = "Graphic",        titan = true, path = TitanSkinsCustomPath .. "Graphic Skin" .. TitanSkinsPathEnd },
	{ name = "Graveyard",      titan = true, path = TitanSkinsCustomPath .. "Graveyard Skin" .. TitanSkinsPathEnd },
	{ name = "Hidden Leaf",    titan = true, path = TitanSkinsCustomPath .. "Hidden Leaf Skin" .. TitanSkinsPathEnd },
	{ name = "Holy Warrior",   titan = true, path = TitanSkinsCustomPath .. "Holy Warrior Skin" .. TitanSkinsPathEnd },
	{ name = "Nightlife",      titan = true, path = TitanSkinsCustomPath .. "Nightlife Skin" .. TitanSkinsPathEnd },
	{ name = "Orgrimmar",      titan = true, path = TitanSkinsCustomPath .. "Orgrimmar Skin" .. TitanSkinsPathEnd },
	{ name = "Plate",          titan = true, path = TitanSkinsCustomPath .. "Plate Skin" .. TitanSkinsPathEnd },
	{ name = "Tribal",         titan = true, path = TitanSkinsCustomPath .. "Tribal Skin" .. TitanSkinsPathEnd },
	{ name = "X-Perl",         titan = true, path = TitanSkinsCustomPath .. "X-Perl" .. TitanSkinsPathEnd },
};
TitanSkins = {}

TITAN_VERSION = Titan_G.plugins.GetMetadata(TITAN_ID, "Version")
--[[
-- trim version if it exists
local fullversion = Titan_G.plugins.GetMetadata(TITAN_ID, "Version")
if fullversion then
	local pos = string.find(fullversion, " -", 1, true);
	if pos then
		TITAN_VERSION = string.sub(fullversion, 1, pos - 1);
	end
end
--]]

--[=[ local Classic
NAME: TitanRegisterExtra
DESC: Add the saved variable data of an unloaded plugin to the 'extra' list in case the user wants to delete the data via Titan Extras option.
VAR: id - the name of the plugin (string)
OUT:  None
local function TitanRegisterExtra(id)
	TitanPluginExtrasNum = TitanPluginExtrasNum + 1
	TitanPluginExtras[TitanPluginExtrasNum] =
	{
		num = TitanPluginExtrasNum,
		id = (id or "?"),
	}
end
--]=]

-- routines to sync toon data

---local Hide the current set of plugins to prevent overlap (creates a very messy bar!)
local function CleanupProfile()
	if TitanPanelSettings and TitanPanelSettings["Buttons"] then
		-- Hide the current set of plugins to prevent overlap (creates a very messy bar!)
		for index, id in pairs(TitanPanelSettings["Buttons"]) do
			local currentButton =
				TitanUtils_GetButton(TitanPanelSettings["Buttons"][index]);
			-- safeguard
			if currentButton then
				currentButton:Hide();
			end
		end
	end
	TitanPanelRightClickMenu_Close();
end

--]]
---local Helper routine to sync two sets of toon data - Titan settings and loaded plugins.
---@param registeredVariables table current loaded data (destination)
---@param savedVariables table data to compare with (source)
local function TitanVariables_SyncRegisterSavedVariables(registeredVariables, savedVariables)
	if (registeredVariables and savedVariables) then
		-- Init registeredVariables
		for index, value in pairs(registeredVariables) do
			--[[
print(".._sync"
.." "..tostring(index)..""
.." : "..tostring(value)..""
)
--]]
			if (not TitanUtils_TableContainsIndex(savedVariables, index)) then
				savedVariables[index] = value;
			end
		end

		-- Remove out-of-date savedVariables
		for index, value in pairs(savedVariables) do
			if (not TitanUtils_TableContainsIndex(registeredVariables, index)) then
				savedVariables[index] = nil;
			end
		end
	end
end

---local Set the plugins (if registered) per the curent profile.
local function TitanVariables_PluginSettingsInit()
	--[[
- The saved variables of the given profile will be used.
- These will be saved on exit or reload in the given profile.
- The saved display list will be used but only the registered plugins will be displayed.
- The plugins that are not registered will NOT be removed from the saved list.
This allows a single saved display list to be used for toons that have different plugins enabled.
	--]]
	-- Loop through the user's displayed plugins and see what is
	-- actually registered
	for idx, display_plugin in pairs(TitanPanelSettings.Buttons) do
		local id = display_plugin
		local plugin = Titan_G.plugins.Get(id)
		-- See if plugin is registered
		if (plugin) then
			-- Synchronize registered and saved variables
			TitanVariables_SyncRegisterSavedVariables(
				plugin.savedVariables, TitanPluginSettings[id])
			-- Button will be updated later
		else
			-- Do not display this plugin.
			-- Do NOT remove the button from the displayed list.
			-- This is an old 'feature' that people like...
		end
	end
end

---local Routine to sync two sets of skins data - Titan defaults and Titan saved vars.
---@return table
--- Safety in case Titan changes the default list.
--- Blizz does not allow LUA to read the hard drive directly.
local function TitanVariables_SyncSkins()
	local skins = {}
	if (TitanSkinsDefault and TitanSkins) then
		-- insert all the Titan defaults
		for idx, v in pairs(TitanSkinsDefault) do
			table.insert(skins, TitanSkinsDefault[idx])
			--			table.sort(skins, function(a, b)
			--				return string.lower(skins[a] and skins[a].name or "")
			--					< string.lower(skins[b] and skins[b].name or "")
			--			end)
		end

		-- search through the saved vars and compare against the defaults
		local found = nil
		for index, value in pairs(TitanSkins) do
			found = nil
			-- See if the skin is a default one
			for idx, v in pairs(TitanSkinsDefault) do
				if TitanSkinsDefault[idx].name == TitanSkins[index].name then
					found = idx
				end
			end
			if found then
				-- already inserted
			else -- could be user placed or old Titan
				if TitanSkins[index].titan then
					-- old Titan skin - let it drop
				else
					-- assume it is a user installed skin
					table.insert(skins, TitanSkins[index])
					--					table.sort(skins, function(a, b)
					--						return string.lower(skins[a] and skins[a].name or "")
					--							< string.lower(skins[b] and skins[b].name or "")
					--					end)
				end
			end
		end
	end
	return skins
end

---local Helper to reset / sync Titan settings.
---@param reset boolean
local function Set_Timers(reset)
	-- Titan is loaded so set the timers we want to use
	TitanTimers = {
		["LDBRefresh"] = { obj = "LDB", callback = Titan_G.ldb.RefreshAll, delay = 2, },
	}

	if reset then
		Titan_G.vars.Set("TimerLDB", TitanTimers["LDBRefresh"].delay)
	else
		TitanTimers["LDBRefresh"].delay = Titan_G.vars.Get("TimerLDB")
	end
end

---Sync one plugin - current loaded (lua file) to its plugin saved vars (last save to disk).
---@param id string Plugin id name
function Titan_G.vars.SyncAPlugin(id)
	-- Init this plugin
	local plugin = Titan_G.plugins.info[id]
	if (plugin and plugin.savedVariables) then
		-- Init savedVariables table
		if TitanPluginSettings then
			-- exists
		else
			TitanPluginSettings = {};
		end
		if TitanPluginSettings[id] then
			-- exists
		else
			TitanPluginSettings[id] = {};
		end

		-- Synchronize registered and saved variables
		TitanVariables_SyncRegisterSavedVariables(
			plugin.savedVariables, TitanPluginSettings[id]);
	end
end

---Sync plugin data - current loaded (lua file) to any plugin saved vars (last save to disk).
--- one plugin uses this
function Titan_G.vars.SyncPlugins()
	-- Init / sync every plugin
	for id, plugin in pairs(Titan_G.plugins.info) do
		if (plugin and plugin.savedVariables) then
			Titan_G.vars.SyncAPlugin(id) -- sync this plugin
		else
			-- Remove plugin savedVariables table if there's one
			if (TitanPluginSettings[id]) then
				TitanPluginSettings[id] = nil;
			end
		end
	end
end

local function AdjBarVars(to_profile)
		local BV = TitanSettings.Players[to_profile].BarVars
		for idx, v in pairs(TitanBarData) do
			if BV[idx].color_border == nil then -- NEW Jan 2026
				BV[idx].color_border = true
			end
			if BV[idx].plugin_off_y == nil then -- NEW Jan 2026
				BV[idx].plugin_off_y = 0
			end
--print("Vars Y"
--	.. " " .. tostring(idx) .. ""
--	.. " " .. tostring(BV[idx].plugin_off_y) .. ""
--)
		end
end

---local Set the Titan bar settings of the given profile from saved variables
---@param to_profile string
--- If no profile found, use Titan defaults
local function Set_bar_vars(to_profile)
	local str = "" -- for debug output

	if TitanSettings.Players[to_profile].BarVars == nil then
		-- Likely a new toon or new to Titan so just get defaults.
		-- build debug output
		str = "Set_bar_vars init"
			.. " " .. tostring(to_profile) .. ""
		Titan_Debug.Out('titan', 'profile', str)

		-- Set to defaults
		TitanSettings.Players[to_profile].BarVars = TitanBarVarsDefaults
		local BV = TitanSettings.Players[to_profile].BarVars

		-- Cannot assume profile is current / cannot use Get Var routines.
		local panel = TitanSettings.Players[to_profile].Panel

		local tex = panel["TexturePath"]:gsub("TitanClassic", "Titan") -- hold over, just in case...
		Titan_Debug.Out('titan', 'profile', "tex path '" .. tex .. "'")

		for idx, v in pairs(TitanBarData) do
			if v.user_move == false then
				-- Set original Bar options from the 'old' saved vars location
				BV[idx].show = panel[v.name .. "_Show"]
				BV[idx].auto_hide = panel[v.name .. "_Hide"]
				BV[idx].align = panel[v.name .. "_Align"]
				-- only skins before 7.x
				BV[idx].texure = Titan_G.SKIN
				BV[idx].skin.alpha = panel[v.name .. "_Transparency"]
				BV[idx].skin.path = tex
			end
		end
	else
		-- All good
		-- build debug output
		str = "Set_bar_vars found"
			.. " " .. tostring(to_profile) .. ""
		Titan_Debug.Out('titan', 'profile', str)
	end

	-- New 2026 : Add any new BarVar or delete removed fields to ALL known profiles
	AdjBarVars(to_profile)
end

local function Check_Titan_settings()
	-- ==== Ensure Titan level settings are whole
	if (TitanSettings) then
		-- all is good
	else
		-- empty saved vars. New install or wipe
		TitanSettings = {}
		Titan_Debug.Out('titan', 'profile', "TitanSettings {}")
	end

	-- check for player list per issue #745
	if TitanSettings.Players then
		-- all is good
	else
		TitanSettings.Players = {}
		Titan_Debug.Out('titan', 'profile', "TitanSettings.Players {}")
	end
	-- ==== At minimum, THIS toon must exist
	local profile = Titan_G.utils.GetPlayer() -- only need profile
	if TitanSettings.Players[profile] == nil then
		TitanSettings.Players[profile] = {}
	else
		-- exists, good
	end

	-- Info for THIS toon for display in Profile
	if TitanSettings.Players[profile].Info == nil then
		TitanSettings.Players[profile].Info = {}
	else
		-- exists, good
	end

	if (TitanAll) then
		-- All good
	else
		TitanAll = {}
	end
end

---local Check the given profile ensuring any profile pointed to exists;
--- This updates ONLY profile settings
---@param profile string
local function TitanVariables_ValidateProfile(profile)
	local toon = profile --
	if toon == nil then -- sanity check to return something valid
		toon = Titan_G.utils.GetPlayer()
	end

	local glob = (Titan_G.vars.Get("GlobalProfileUse") == true)
	local sync = TitanSettings.Players[toon].Panel["SyncWithProfile"]

	local gcheck = ""
	local scheck = ""

	local str = "_ValidateProfile [" .. tostring(profile) .. "]"
	str = str
		.. " > '" .. tostring(toon) .. "'"
		.. " g'" .. tostring(glob) .. "'"
		.. " s'" .. tostring(sync) .. "'"
	Titan_Debug.Out('titan', 'profile', str)
	--
	-- Validate profile against settings

	-- First Global
	if glob then
		gcheck = Titan_G.vars.Get("GlobalProfileName")
		if TitanSettings.Players[gcheck] then
			-- Referenced profile exists
		else
			-- Need to clear, the profile is not known...
			Titan_G.vars.Set("GlobalProfileUse", false)
			glob = false
		end
	else
		-- not global
	end

	-- Second Sync
	-- Checking this separately ensures profile settings in saved vars stays consistent when a user
	-- mixes global and sync over time.
	if not (sync == Titan_G.profile.NONE) then
		scheck = TitanSettings.Players[toon].Panel["SyncWithProfile"]
		if TitanSettings.Players[scheck].Panel then
			-- Referenced profile exists
		else
			-- Need to clear, the profile is not known...
			TitanSettings.Players[toon].Panel["SyncWithProfile"] = Titan_G.profile.NONE
			sync = Titan_G.profile.NONE
		end
	else
		-- not sync
	end

	-- Third Toon
	-- The PEW process Titan will ensure the toon is whole

	str = "..._ValidateProfile [" .. tostring(toon) .. "]"
		.. "g [" .. tostring(gcheck) .. "] > "
		.. " '" .. tostring(glob) .. "'"
		.. "s [" .. tostring(scheck) .. "] > "
		.. " '" .. tostring(sync) .. "'"
	Titan_Debug.Out('titan', 'profile', str)
end

---Get the current profile per user settings with type and color-code version;
--- Priority is Global; Sync; current toon
---@param get_me string
---@return Get_Profile_Result res Profile info
function Titan_G.vars.GetProfile(get_me)
	local ptype = ""
	local profile = ""
	local cprofile = ""
	local res = {}
	local toon = get_me --

	local glob = (Titan_G.vars.Get("GlobalProfileUse") == true)
	local sync = TitanSettings.Players[toon].Panel["SyncWithProfile"]

	--
	-- Gather profile data per settings
	if glob then
		-- Use the global toon user as set
		ptype = Titan_G.profile.GLOBAL
		profile = Titan_G.vars.Get("GlobalProfileName")
		cprofile = TitanUtils_GetHexText(profile, Titan_G.colors.orange)
	elseif (sync == Titan_G.profile.NONE) then
		-- Use the current player
		ptype = Titan_G.profile.TOON
		profile = toon
		cprofile = TitanUtils_GetHexText(profile, Titan_G.colors.gold)
	else
		-- use the sync as set
		ptype = Titan_G.profile.SYNC
		profile = sync
		cprofile = TitanUtils_GetHexText(profile, Titan_G.colors.green)
	end

	local str = "_GetProfile"
		.. " " .. tostring(ptype) .. ""
		.. " '" .. tostring(cprofile) .. "'"
		.. " g'" .. tostring(glob) .. "'"
		.. " s'" .. tostring(sync) .. "'"
		.. " t'" .. tostring(toon) .. "'"
	Titan_Debug.Out('titan', 'profile', str)

	res.ptype = ptype
	res.pname = profile
	res.cname = cprofile
--	res.sync = sync
	return res
end

---Set the profile per user settings
---@param set_me? string Profile to set / update
---@param ptype string Type of profile being set: Global | Sync | Toon
---@param to_profile string Profile to use
function Titan_G.vars.SetProfile(set_me, ptype, to_profile)
	local str = "_SetProfile"
		.. " [" .. tostring(set_me) .. "]"
		.. " " .. tostring(ptype) .. ""
		.. " to '" .. tostring(to_profile) .. "'"
	Titan_Debug.Out('titan', 'profile', str)

	-- Nov 2025 : The change to Sync only touched a nerve :); adding back Global override...
	if ptype == Titan_G.profile.GLOBAL then
		Titan_G.vars.Set("GlobalProfileUse", true)
		Titan_G.vars.Set("GlobalProfileName", to_profile)
	elseif ptype == Titan_G.profile.SYNC then
		TitanSettings.Players[set_me].Panel["SyncWithProfile"] = to_profile
	else
		-- just current toon
	end
end

--- Ensure the given toon is ready to accept profile values; sync to defaults
---@param toon string Toon name <name>@<server>
---@param toon_table table From TitanSettings (saved vars)
local function Check_toon_settings(toon, toon_table)
	local v = toon_table
	local str = ""

	if TitanSettings.Players[toon] == nil
	or TitanSettings.Players[toon] == TITAN_PROFILE_RESET then
		-- build debug output
		str = "Init_player_settings"
			.. " " .. tostring(TitanSettings.Players[toon]) .. ""
			.. " " .. tostring("TitanSettings.Players[] {}") .. ""
		Titan_Debug.Out('titan', 'profile', str)

		-- Create the bare player tables so profile(s) can be added
		TitanSettings.Players[toon] = {}

		-- ptr changed
		v = TitanSettings.Players[toon]
	else
		-- all is good
		-- build debug output
		str = "Init_player_settings"
			.. " " .. tostring("TitanSettings.Players[] ") .. ""
			.. " " .. tostring(toon) .. ""
		Titan_Debug.Out('titan', 'profile', str)
	end

	-- The saved vars were grown organically over years making this section piece meal
	Titan_Debug.Out('titan', 'profile', "Sync " .. toon .. " toon defaults (Panel)(BarVars)")
	if v["Panel"] then
		-- exists
	else
		v["Panel"] = {}
	end
	-- Note: the sync routine only ensures first level, NOT recursive
	TitanVariables_SyncRegisterSavedVariables(TITAN_PANEL_SAVED_VARIABLES, v["Panel"])

---[[
	-- 2026 Mar - transfer Gold and Post to same level as Info
	-- Remove the old one.
	if  TitanSettings.Players[toon]
	and TitanSettings.Players[toon].Info
	and TitanSettings.Players[toon].Info.Gold then
		TitanSettings.Players[toon].Gold = {}
		TitanVariables_SyncRegisterSavedVariables(
			TitanSettings.Players[toon].Info.Gold, TitanSettings.Players[toon].Gold)
		TitanSettings.Players[toon].Info.Gold = nil
	else
		-- already transfered
	end
	if  TitanSettings.Players[toon]
	and TitanSettings.Players[toon].Info
	and TitanSettings.Players[toon].Info.Post then
		TitanSettings.Players[toon].Post = {}
		TitanVariables_SyncRegisterSavedVariables(
			TitanSettings.Players[toon].Info.Post, TitanSettings.Players[toon].Post)
		TitanSettings.Players[toon].Info.Post = nil
	else
		-- already transfered
	end
--]]

	-- ====== New Mar 2023 : TitanSettings.Players[player].BarData to hold Short bar data
	Set_bar_vars(toon)

	-- These are dynamically filled, just make sure the entry exists
	if v.Plugins then
		-- exists
	else
		v.Plugins = {}
	end
	if v.Register then
		-- exists
	else
		v.Register = {}
	end
	if v.Adjust then -- New May 2023
		-- exists
	else
		v.Adjust = {}
	end

	-- Toon is now ready to accept profile values
end

---Create an export string form a list of toons and whether to include Titan saved vars
---@param export table
---@param titan_all boolean
---@return string export string
function Titan_G.vars.CreateExport(export, titan_all)
	local res = ""
	local str = ""
	local new_ex =
	{
		version = 1,
		addon = "Titan_export",
		titan_all = false,
		toons = {}, -- list of toons exported
	}

	str = "_CreateExport"
	.." ".. tostring(export) .. ""
	.." ".. tostring(titan_all) .. ""
	Titan_Debug.Out('titan', 'profile', "_CreateExport")

	str = "... loop "..type(export).."\n"
	if type(export) == 'table' then
		for index, val in pairs(export) do
			local added = false
			str = str .."... toon".. " '" .. tostring(index) .. "'"
			if val then
				str = str.." include"
				if TitanSettings.Players[index] then
					new_ex.toons[index] = TitanSettings.Players[index]
					added = true
				else
					-- no player?
					added = false
				end
				str = str .. " + " .. tostring(added) .. ""
			else
				str = str.." exclude"
			end
			str = str.." \n"
		end
	else
		-- something
		str = str.."not table?? \n"
	end
	Titan_Debug.Out('titan', 'profile', str)

	res = Titan_G.utils.CompressData(new_ex, "print")

	str = "... result length ".. string.len(res).." bytes"
	Titan_Debug.Out('titan', 'profile', str)
	Titan_Debug.Out('titan', 'profile', "_CreateExport fini")

	return res
end

function Titan_G.vars.ProcessImport(import)
	local res = false
	local str = ""
	local new_im = {}
	local ok = false

	str = "_ProcessImport"
	.." ".. type(import) .. ""
	.." ".. string.len(import) .. ""
	Titan_Debug.Out('titan', 'profile', "_CreateExport")

	str = "... loop ".."\n"
	if type(import) == 'string' then
		-- decompress and make into a table...
		ok, new_im = Titan_G.utils.DecompressData(import, "print")

		if ok then
			-- process any toons found by putting them into TitanSettings.Players
			for index, val in pairs(new_im.toons) do
				str = str .."... toon".. " '" .. tostring(index) .. "'"
				if TitanSettings.Players[index] then
					TitanSettings.Players[index] = nil -- likely not needed but safe
				else
					-- just add below
				end
				TitanSettings.Players[index] = val
				str = str.." \n"
			end
			res = true -- all should be ok...
		else
			-- The decompress should have output an err...
		end
	else
		-- something
		str = str.."not string?? \n"
	end
	Titan_Debug.Out('titan', 'profile', str)

	Titan_Debug.Out('titan', 'profile', "_ProcessImport fini")

	return res
end

--[[
function TitanVariables_ProcessExport(export)
end
--]]

---Ensure TitanSettings (one of the saved vars in the toc) exists and set the Titan version.
--- Called early when processing PLAYER_ENTERING_WORLD event)
function Titan_G.vars.InitSettings()
	local player = Titan_G.utils.GetPlayer()
	Titan_Debug.Out('titan', 'profile', "_Init begin " .. tostring(player))

	-- ==== Ensure Titan level settings are whole and contain this toon at min
	Check_Titan_settings()

	Titan_Debug.Out('titan', 'profile', "Sync TitanAll defaults")
	TitanVariables_SyncRegisterSavedVariables(TITAN_ALL_SAVED_VARIABLES, TitanAll)
	--	Titan_Debug.Out('titan', 'profile', "> Sync Done")

	-- ==== Create Titan toon list and ensure settings are whole.
	-- Sort in alphabetical order.
	-- Sync *each* toon with defaults to ensure latest data changes are applied.
	-- Used for menus.
	local str = ""
	for idx, v in pairs(TitanSettings.Players) do
		if type(idx) == string then -- for sanity and IDE
			table.insert(Titan_G.players, idx)
		end

		-- Sync with defaults - in case of changed defaults
		-- New Oct 2025 : All toons instead of current toon (Init_player_settings)
		Titan_Debug.Out('titan', 'profile', "Sync " .. idx .. " toon defaults (Panel)(BarVars)")
		Check_toon_settings(idx, v)

		-- Ensure profile vars are proper
		TitanVariables_ValidateProfile(idx)
	end
	table.sort(Titan_G.players, function(a, b)
		return a < b
	end)

	TitanSettings.Version = TITAN_VERSION;

	Titan_Debug.Out('titan', 'profile', "_Init end " .. tostring(player))
end

---Update local and saved vars to new bar position per user or reset to default
---@param self table Bar frame
---@param reset boolean Set to default position
---@param x_off? number Set to X
---@param y_off? number Set to Y
---@param w_off? number Set to width
function Titan_G.vars.SetBarPos(self, reset, x_off, y_off, w_off)
	-- Collect bar x & y and save so bar stays put.
	local bar_frame = self:GetName()

	if TitanBarDataVars[bar_frame] then
		if reset then
			-- Initial defaults calc to screen size and scaling at that time - it could have changed!
			TitanBarDataVars[bar_frame].off_x = Calc_X()
			TitanBarDataVars[bar_frame].off_y = Calc_Y(TitanBarData[bar_frame].order - 2)
			TitanBarDataVars[bar_frame].off_w = SHORT_WIDTH
		else
			-- local to show bars as needed
			TitanBarDataVars[bar_frame].off_x = x_off
			TitanBarDataVars[bar_frame].off_y = y_off
			TitanBarDataVars[bar_frame].off_w = w_off
		end
	end
	-- This is intended to prevent the bar fromk 'walking' on the screen due to rounding errors...
	TitanBarDataVars[bar_frame].tscale = Titan_G.vars.PanelGet("Scale")
	-- :GetPoint(1) results in incorrect values based on point used
end

---Retrieve saved vars of bar position
---@param frame_str string Bar name
---@return number off_x
---@return number off_y
---@return number off_width
---@return number tscale last Titan scale seen for this bar
function Titan_G.vars.GetBarPos(frame_str)
	-- tscale may not exist so return 0 as 'invalid'
	return
		TitanBarDataVars[frame_str].off_x,
		TitanBarDataVars[frame_str].off_y,
		TitanBarDataVars[frame_str].off_w,
		(TitanBarDataVars[frame_str].tscale or 0)
end

---Build the frame name from the bar name
---@param bar_str string? Short bar name
---@return string is_icon Bar frame name
function Titan_G.vars.GetFrameName(bar_str)
	return tostring(Titan_G.bars.PRE_STR) .. bar_str
end

---local Original : lua-users.org/wiki/CopyTable
---@param orig any
---@return any
local function deepcopy(orig)
	local orig_type = type(orig)
	local copy
	if orig_type == 'table' then
		copy = {}
		for orig_key, orig_value in next, orig, nil do
			copy[deepcopy(orig_key)] = deepcopy(orig_value)
		end
		setmetatable(copy, deepcopy(getmetatable(orig)))
	else -- number, string, boolean, etc
		copy = orig
	end
	return copy
end

---local Use the Titan settings, the plugin settings, the 'extras' data of the given profile.
---@param from_profile string?
---@param to_profile string
---@param action string TITAN_PROFILE_USE | TITAN_PROFILE_RESET | TITAN_PROFILE_INIT
--- In form "toon"@"server"
--- Create the "to" profile if it does not exist.
local function Init_player_settings(from_profile, to_profile, action)
	--[[
- Called at PLAYER_ENTERING_WORLD event after Titan has registered plugins.
- There are 3 actions: USE, RESET, and INIT
- USE:
 From: the user chosen profile
 To: Player or profile
- RESET:
 From: Titan defaults
 To: Player or profile
- INIT:
 From: saved variables of that profile
 To: Player or Global profile
	--]]
	local str = "" -- for debug output
	local old_player = {}
	local old_panel = {}
	local old_plugins = {}
	local reset = (action == TITAN_PROFILE_RESET)

	str = "Init_player_settings"
		.. " from: " .. tostring(from_profile) .. ""
		.. " to: " .. tostring(to_profile) .. ""
		.. " action: " .. tostring(action) .. ""
	Titan_Debug.Out('titan', 'profile', str)

	CleanupProfile() -- hide currently shown plugins

	if reset then
		-- ensure the profile is rebuilt with defaults
		TitanSettings.Players[to_profile] = nil
	else
		-- proceed
	end

	-- === Ensure we have a place to store profile, could be new toon or new install
	Check_toon_settings(to_profile, TitanSettings.Players[to_profile])

	-- Set variables used to reference this profile
	TitanPlayerSettings = TitanSettings.Players[to_profile];
	TitanPluginSettings = TitanPlayerSettings["Plugins"];
	TitanPanelSettings = TitanPlayerSettings["Panel"];

	-- ====== New May 2023 : Back to adjusting a couple frames per user settings
	TitanAdjustSettings = TitanPlayerSettings["Adjust"]

	-- ======

	if action == TITAN_PROFILE_RESET then
		TitanAll = {}
		TitanVariables_SyncRegisterSavedVariables(TITAN_ALL_SAVED_VARIABLES, TitanAll)
	elseif action == TITAN_PROFILE_INIT then
		--	
	elseif action == TITAN_PROFILE_USE then
		-- Copy the from_profile to profile - not anything in saved vars

		if from_profile and TitanSettings.Players[from_profile] then
			old_player = TitanSettings.Players[from_profile]
			-- The requested from profile at least exists so we can copy from it
			if old_player["Panel"] then
				old_panel = old_player["Panel"]
			end
			if old_player["Plugins"] then
				old_plugins = old_player["Plugins"]
			end

			-- Get the profile Bar data...
			TitanSettings.Players[to_profile]["BarVars"] = deepcopy(old_player["BarVars"])

			-- Copy the panel settings
			for index, id in pairs(old_panel) do
				Titan_G.vars.PanelSet(index, old_panel[index]);
			end

			-- Copy the plugin settings
			for plugin, i in pairs(old_plugins) do
				for var, id in pairs(old_plugins[plugin]) do
					Titan_G.plugins.SetVar(plugin, var, old_plugins[plugin][var])
				end
			end
		end
	end

	TitanBarDataVars = TitanPlayerSettings["BarVars"] -- works here, after setting BarVars
	-- build debug output
	str = "Init_player_settings"
		.. " " .. tostring("BarVars now set") .. ""
	Titan_Debug.Out('titan', 'profile', str)

	if (TitanPlayerSettings) then
		-- build debug output
		str = "Init_player_settings"
			.. " " .. tostring("_SyncPluginSettings") .. ""
		Titan_Debug.Out('titan', 'profile', str)
		-- Synchronize plugin settings with plugins that were registered
		Titan_G.vars.SyncPlugins()
		-- Display the plugins the user selected AND are registered
		TitanVariables_PluginSettingsInit()
	end

	TitanSkins = TitanVariables_SyncSkins()

	Set_Timers(reset)

	-- for debug if a user needs to send in the Titan saved vars
--	TitanPanelRegister = TitanPlayerSettings["Register"]
	TitanPlayerSettings["Register"] = nil
end

---Get the value of the requested plugin variable.
---@param id string Plugin name
---@param var string Variable name
---@return any Value
---From the plugin <button>.registry.savedVariables table as created in the plugin Lua.
function Titan_G.plugins.GetVar(id, var)
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]) then
		-- compatibility check
		if TitanPluginSettings[id][var] == "Titan Nil" then
			TitanPluginSettings[id][var] = false
		end
		return TitanPluginSettings[id][var];
		--return TitanUtils_Ternary(TitanPluginSettings[id][var] == false, nil, TitanPluginSettings[id][var]);
	end
end
TitanGetVar = Titan_G.plugins.GetVar --API

---Determine if requested plugin variable exists.
---@param id string Plugin name
---@param var string Variable name
---From the plugin <button>.registry.savedVariables table as created in the plugin Lua.
function Titan_G.plugins.VarExists(id, var)
	-- We need to check for existance not true!
	-- If the value is nil then it will not exist...
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]
			and (TitanPluginSettings[id][var]
				or TitanPluginSettings[id][var] == false))
	then
		return true
	else
		return false
	end
end
TitanVarExists = Titan_G.plugins.VarExists --API

---Set the value of the requested plugin variable.
---@param id string Plugin name
---@param var string Variable name
---@param value any Value
---From the plugin <button>.registry.savedVariables table as created in the plugin Lua.
function Titan_G.plugins.SetVar(id, var, value)
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]) then
		TitanPluginSettings[id][var] = TitanUtils_Ternary(value, value, false);
	end
end
TitanSetVar = Titan_G.plugins.SetVar --API

---Toggle the value of the requested plugin variable. This assumes var value represents a boolean.
---@param id string Plugin name
---@param var string Variable name
function Titan_G.plugins.ToggleVar(id, var)
	-- Boolean in this case could be true / false or non zero / zero or nil.
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]) then
		Titan_G.plugins.SetVar(id, var, TitanUtils_Toggle(Titan_G.plugins.GetVar(id, var)));
	end
end
TitanToggleVar = Titan_G.plugins.ToggleVar --API

---Get the value of the requested Titan global variable.
---@param var string Titan saved variable name
---@return any? Value
function Titan_G.vars.PanelGet(var)
	if (var and TitanPanelSettings) then
		if TitanPanelSettings[var] == "Titan Nil" then
			TitanPanelSettings[var] = false
		end
		return TitanUtils_Ternary(TitanPanelSettings[var] == false, nil, TitanPanelSettings[var]);
	end
end
TitanPanelGetVar = Titan_G.vars.PanelGet --API

---Set the value of the requested Titan global variable.
---@param var string Titan saved variable name
---@param value any?
function Titan_G.vars.PanelSet(var, value)
	if (var and TitanPanelSettings) then
		TitanPanelSettings[var] = TitanUtils_Ternary(value, value, false);
	end
end
TitanPanelSetVar = Titan_G.vars.PanelSet  --API

---Toggle the value of the requested Titan variable. This assumes var value represents a boolean.
---@param var string Titan saved variable name
function Titan_G.vars.PanelToggle(var)
	-- Boolean in this case could be true / false or non zero / zero or nil.
	if (var and TitanPanelSettings) then
		Titan_G.vars.PanelSet(var, TitanUtils_Toggle(Titan_G.vars.PanelGet(var)));
	end
end
TitanPanelToggleVar = Titan_G.vars.PanelToggle --API

---Set the value of the requested Titan global variable.
---@param var string Titan saved variable name
---@return any? Value
function Titan_G.vars.Get(var)
	if (var and TitanAll) then
		if TitanAll[var] == "Titan Nil" then
			TitanAll[var] = false
		end
		return TitanUtils_Ternary(TitanAll[var] == false, nil, TitanAll[var]);
	end
end
TitanAllGetVar = Titan_G.vars.Get --API

---Set the value of the requested Titan global variable.
---@param var string Titan saved variable name
---@param value any?
function Titan_G.vars.Set(var, value)
	if (var and TitanAll) then
		TitanAll[var] = TitanUtils_Ternary(value, value, false);
	end
end
TitanAllSetVar = Titan_G.vars.Set --API

---Toggle the value of the requested Titan global variable. This assumes var value represents a boolean.
---@param var string Titan saved variable name
function Titan_G.vars.Toggle(var)
	if (var and TitanAll) then
		Titan_G.vars.Set(var, TitanUtils_Toggle(Titan_G.vars.Get(var)));
	end
end
TitanAllToggleVar = Titan_G.vars.Toggle --API

---Return the strata and the next highest strata of the given value
---@param value string Strata
---@return string Next
---@return string Passed
function Titan_G.vars.GetStrata(value)
	-- obligatory check
	if not value then value = "DIALOG" end

	local index;
	local indexpos = 5 -- DIALOG
	local StrataTypes = { "BACKGROUND", "LOW", "MEDIUM", "HIGH",
		"DIALOG", "FULLSCREEN", "FULLSCREEN_DIALOG" }

	for index in ipairs(StrataTypes) do
		if value == StrataTypes[index] then
			indexpos = index
			break
		end
	end

	return StrataTypes[indexpos + 1], StrataTypes[indexpos]
end
TitanVariables_GetPanelStrata = Titan_G.vars.GetStrata  --API

---API Set the Titan bars to the given strata and the plugins to the next highest strata.
---@param value string WoW strata name
function Titan_G.vars.SetStrata(value)
	local plugins, bars = Titan_G.vars.GetStrata(value)
	-- Set all the Titan bars
	for idx, v in pairs(TitanBarData) do
		_G[idx]:SetFrameStrata(bars)
	end
	-- Set all the registered plugins
	for idx, v in pairs(Titan_G.plugins.index) do
		local button = TitanUtils_GetButton(v)
		if button then
			button:SetFrameStrata(plugins)
		end
	end
end
TitanVariables_SetPanelStrata = Titan_G.vars.SetStrata  --API

---Set the Titan variables and plugin variables to the passed in profile.
--- Called from the Titan right click menu
--- profile is compared using 'lower' so the case does not matter
---@param from? string profile to copy from
---@param profile string required: profile to use, may not be player!
---@param action string Use | Reset | Init
function Titan_G.vars.UseSettings(from, profile, action)
	local str = "" -- for debug output if requested
	local _ = nil -- for scope; do not care about this value

	-- Oct and Dec 2025 : 
	-- Added 'from' to be explicit when Load of a source profile
	-- Profile param is now required - usually current player
	-- The target profile could be overridden per global or sync featuresettings

	local from_profile = from

	str = "_UseSettings"
		.. " " .. tostring(action) .. ""
		.. " : '" .. tostring(from) .. "'"
		.. " > '" .. tostring(profile) .. "'"
	Titan_Debug.Out('titan', 'profile', str)

	-- ==== Determine the profile to use based on profile settings
	local profile_info = Titan_G.vars.GetProfile(profile)
	local profile_name = profile_info.pname
	-- Find the profile in a case insensitive manner
	local new_profile = ""
	profile_name = string.lower(profile_name)
	for index, id in pairs(TitanSettings.Players) do
		if profile_name == string.lower(index) then
			new_profile = index
		end
	end
	if new_profile == "" then
		-- new toon to Titan; needs to be created
		new_profile = Titan_G.utils.GetPlayer()
		action = TITAN_PROFILE_RESET
	end

	-- Now that we know what profile to use - act on the data
	str = "_UseSettings"
		.. " " .. tostring(action) .. ""
		.. " from '" .. tostring(from_profile) .. "'"
		.. " to '" .. tostring(new_profile) .. "'"
	Titan_Debug.Out('titan', 'profile', str)
	Init_player_settings(from_profile, new_profile, action)

	-- set strata in case it has changed
	Titan_G.vars.SetStrata(Titan_G.vars.PanelGet("FrameStrata"))

	-- show the new profile
--[[
	-- build debug output
	str = "...init bars"
		.. " " .. tostring(action) .. ""
	Titan_Debug.Out('titan', 'profile', str)
	TitanPanel_InitPanelBarButton("UseSettings");
--]]
	-- build debug output
	str = "...init plugins on bars"
		.. " " .. tostring(action) .. ""
	Titan_Debug.Out('titan', 'profile', str)
	Titan_G.bars.ShowPlugins("_UseSettings");
end

-- decrecated routines
--[[

function TitanGetVarTable(id, var, position)
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]) then
		-- compatibility check
		if TitanPluginSettings[id][var][position] == "Titan Nil" then TitanPluginSettings[id][var][position] = false end
		return TitanUtils_Ternary(TitanPluginSettings[id][var][position] == false, nil, TitanPluginSettings[id][var][position]);
	end
end

function TitanSetVarTable(id, var, position, value)
	if (id and var and TitanPluginSettings and TitanPluginSettings[id]) then
		TitanPluginSettings[id][var][position] = TitanUtils_Ternary(value, value, false);
	end
end

--]]
