--[===[ File
Contains the basic routines of Titan.
All the event handler routines, initialization routines, Titan menu routines, and select plugin handler routines.
--]===]

-- Locals
local TPC = TITAN_PANEL_CONSTANTS -- shortcut
local TITAN_PANEL_BUTTONS_INIT_FLAG = nil;

local _G = _G --getfenv(0);
local InCombatLockdown = _G.InCombatLockdown;

-- Library references
local L = LibStub("AceLocale-3.0"):GetLocale(TITAN_ID, true)
local AceTimer = LibStub("AceTimer-3.0")
local media = LibStub("LibSharedMedia-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")

--------------------------------------------------------------
--

---local Reset current toon to default Titan settings.
local function TitanPanel_ResetToDefault()
	-- Found as of 2025 Sep, the reload is not needed
	-- build debug output
	local str = "/titan reset invoked"
	Titan_Debug.Out('titan', 'profile', str)

	Titan_G.vars.UseSettings(nil, Titan_G.utils.GetPlayer(), TITAN_PROFILE_RESET);
end

--- Reset Titan to default settings then reload UI. Equivilant to deleting saved vars.
function Titan_G.ResetTitanToDefault()
	-- A reload is safest course
	-- build debug output
	local str = "/titan reset all invoked"
	Titan_Debug.Out('titan', 'profile', str)

	TitanSettings = nil
	TitanAll = nil

	C_UI.Reload() -- Reuse the PEW code to ensure Titan is whole.
end

--- The user wants to save a custom Titan profile. Show the user the dialog boxes to make it happen.
--- The profile is written to the Titan saved variables. A reload of the UI is needed to ensure the profile is written to disk for the user to load later.
function Titan_G.SaveCustomProfile(profile_name)
	-- Create the dialog box code we'll need...

	---helper to get the edit box depending on expansion API
	---@param self table
	---@return table
	local function GetBox(self)
		if self.editBox then
			-- Older version of API
			return self.editBox
		else
			return self:GetEditBox()
		end
	end

	-- helper to actually write the profile to the Titan saved vars
	local function Write_profile(name)
		--		local currentprofilevalue, _, _ = Titan_G.utils.GetPlayer()
		local currentprofilevalue = profile_name
		local profileName = Titan_G.utils.CreateName(name, TITAN_CUSTOM_PROFILE_POSTFIX)
		TitanSettings.Players[profileName] =
			Titan_G.utils.DeepCopy(TitanSettings.Players[currentprofilevalue])

		-- Do NOT allow a sync on a custom profile
		TitanSettings.Players[profileName].Panel["SyncWithProfile"] = Titan_G.profile.NONE

		TitanPrint(L["TITAN_PANEL_MENU_PROFILE_SAVE_PENDING"]
			.. "'" .. profile_name .. "'"
			.. " > '" .. profileName .. "'"
			--			.. " > '" .. name .. "'"
			, "info")
	end
	-- helper to ask the user to overwrite a profile
	local function Overwrite_profile(name)
		local dialogFrame =
			StaticPopup_Show("TITAN_OVERWRITE_CUSTOM_PROFILE", name);
		if dialogFrame then
			dialogFrame.data = name;
		end
	end
	-- helper to handle getting the profile name from the user
	local function Get_profile_name(self)
		local rawprofileName = GetBox(self):GetText();
		-- remove any spaces the user may have typed in the name
		local conc2profileName = string.gsub(rawprofileName, " ", "");
		if conc2profileName == "" then return; end
		-- no '@' is allowed or it will mess with the Titan profile naming convention
		local concprofileName = string.gsub(conc2profileName, Titan_G.constants.AT_SYM, "-");
		local profileName = Titan_G.utils.CreateName(concprofileName, TITAN_CUSTOM_PROFILE_POSTFIX)
		if TitanSettings.Players[profileName] then
			-- Warn the user of an existing profile
			Overwrite_profile(rawprofileName)
			self:Hide();
			return;
		else
			-- Save the requested profile
			Write_profile(rawprofileName)
			self:Hide();
			StaticPopup_Show("TITAN_RELOADUI");
		end
	end
	-- Dialog box to warn the user that the UI will be reloaded
	-- This ensures the profile is written to disk
	StaticPopupDialogs["TITAN_RELOADUI"] = {
		text = TitanUtils_GetNormalText(L["TITAN_PANEL_MENU_TITLE"]) .. "\n\n"
			.. L["TITAN_PANEL_MENU_PROFILE_RELOADUI"],
		button1 = "OKAY",
		OnAccept = function(self)
			C_UI.Reload(); -- ensure profile is written to disk
		end,
		showAlert = 1,
		whileDead = 1,
		timeout = 0,
	};

	-- Dialog box to warn the user that an existing profile will be overwritten.
	StaticPopupDialogs["TITAN_OVERWRITE_CUSTOM_PROFILE"] = {
		text = TitanUtils_GetNormalText(L["TITAN_PANEL_MENU_TITLE"]) .. "\n\n"
			.. L["TITAN_PANEL_MENU_PROFILE_ALREADY_EXISTS"],
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function(self, data)
			Write_profile(data)
			self:Hide();
			StaticPopup_Show("TITAN_RELOADUI");
		end,
		showAlert = 1,
		whileDead = 1,
		timeout = 0,
		hideOnEscape = 1
	};

	-- Dialog box to save the profile.
	StaticPopupDialogs["TITAN_SAVE_CUSTOM_PROFILE"] = {
		text = TitanUtils_GetNormalText(L["TITAN_PANEL_MENU_TITLE"]) .. "\n\n"
			.. L["TITAN_PANEL_MENU_PROFILE_SAVE_CUSTOM_TITLE"],
		button1 = ACCEPT,
		button2 = CANCEL,
		hasEditBox = 1,
		maxLetters = 20,
		OnAccept = function(self)
			-- self refers to this frame with the Accept button
			Get_profile_name(self)
		end,
		OnShow = function(self)
			GetBox(self):SetFocus();
		end,
		OnHide = function(self)
			GetBox(self):SetText("");
		end,
		EditBoxOnEnterPressed = function(self)
			-- We need to get the parent because self refers to the edit box.
			Get_profile_name(self:GetParent())
		end,
		EditBoxOnEscapePressed = function(self)
			self:GetParent():Hide();
		end,
		timeout = 0,
		exclusive = 1,
		whileDead = 1,
		hideOnEscape = 1
	};

	StaticPopup_Show("TITAN_SAVE_CUSTOM_PROFILE");

	-- Can NOT cleanup. Execution does not stop when a dialog box is invoked!
	--	StaticPopupDialogs["TITAN_RELOADUI"] = {}
	--	StaticPopupDialogs["TITAN_OVERWRITE_CUSTOM_PROFILE"] = {}
	--	StaticPopupDialogs["TITAN_SAVE_CUSTOM_PROFILE"] = {}
end

local function RegisterForEvents()
	-- Need to be careful of regeristering for events that initiate
	-- show / hide of Bars before the Bars can be initialized...
	Titan_G.control.frame:RegisterEvent("CVAR_UPDATE");
	Titan_G.control.frame:RegisterEvent("PLAYER_LOGOUT");

	-- For the pet battle - for now we'll hide the Titan bars...
	-- Cannot seem to move the 'top' part of the pet battle frame.
	Titan_G.control.frame:RegisterEvent("PET_BATTLE_OPENING_START");
	Titan_G.control.frame:RegisterEvent("PET_BATTLE_CLOSE");

	-- Hide Titan bars in combat (global or per bar); may be useful when using Short bars
	Titan_G.control.frame:RegisterEvent("PLAYER_REGEN_ENABLED");
	Titan_G.control.frame:RegisterEvent("PLAYER_REGEN_DISABLED");

	-- User request to hide Top bar(s) in BG or arena; more areas later?
	Titan_G.control.frame:RegisterEvent("ZONE_CHANGED");
	Titan_G.control.frame:RegisterEvent("ZONE_CHANGED_INDOORS");
	Titan_G.control.frame:RegisterEvent("ZONE_CHANGED_NEW_AREA");

	-- 2026 Apr Add more info for Alts
	Titan_G.control.frame:RegisterEvent("PLAYER_MONEY")
	Titan_G.control.frame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
	Titan_G.control.frame:RegisterEvent("TIME_PLAYED_MSG")
	Titan_G.control.frame:RegisterEvent("PLAYER_LEVEL_UP")
	Titan_G.control.frame:RegisterEvent("PLAYER_XP_UPDATE")
end

--------------------------------------------------------------
---
-- Need to set here - TitanGlobal is too early.
Titan_G.control.frame = TitanPanelBarButton -- Created in Template XML, see .toc

Titan_G.control.frame:RegisterEvent("ADDON_LOADED");
--
-- Event routine : redirects to Titan_G.control.frame:<registered event> routines below.
Titan_G.control.frame:SetScript("OnEvent", function(_, event, ...)
	Titan_G.control.frame[event](Titan_G.control.frame, ...)
end)

local function RegisterAddonCompartment()
	if AddonCompartmentFrame then
		AddonCompartmentFrame:RegisterAddon(
			{
				text = TITAN_ID,
				icon = "Interface\\Icons\\Achievement_Dungeon_UlduarRaid_Titan_01",
				notCheckable = true,
				func = function(button, menuInputData, menu)
					Titan_G.config.OpenConfig("Minimap compartment")
				end,
				funcOnEnter = function(button)
					MenuUtil.ShowTooltipEx(button, GetAppropriateTooltip(), function(tooltip)
						local msg = ""
							.. L["TITAN_PANEL"]
							.. " " .. L["TITAN_PANEL_MENU_CONFIGURATION"]
---@diagnostic disable-next-line: missing-parameter
						tooltip:SetText(msg) -- wants parameters for color...
					end)
				end,
				funcOnLeave = function(button)
					MenuUtil.HideTooltipEx(button, GetAppropriateTooltip())
				end,
			}
		)
	else
	end
end

local function SetToonZoneInfo()
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	toon_info.zoneText = GetZoneText()
	toon_info.subZoneText = GetSubZoneText() or ""
end

local function GetElapsed(time_ago)
	return (_G.time() - time_ago)
end

--local Collect info for time played
local function SetToonPlayedInfo(action, total, level)
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo

	if toon_info == nil then
		-- Titan not ready?
		-- What ever reason, do nothing for now.
	else
	if action == 'init' then
		Titan_G.utils.GetTimePlayed("Titan") -- TIME_PLAYED_MSG
		toon_info.played_start = _G.time()
	elseif action == 'update' then -- via event TIME_PLAYED_MSG
		toon_info.played_total = total + GetElapsed(toon_info.played_start)
		toon_info.played_this_level = level + GetElapsed(toon_info.played_start)
	elseif action == 'logout' then -- 
		toon_info.played_total = toon_info.played_total + GetElapsed(toon_info.played_start)
		toon_info.played_this_level = toon_info.played_this_level + GetElapsed(toon_info.played_start)
	elseif action == 'level' then
		toon_info.played_start = _G.time()
		toon_info.played_total = toon_info.played_total + GetElapsed(toon_info.played_start)
		toon_info.played_this_level = GetElapsed(toon_info.played_start)
	else
		-- !?
	end
	end
end

local function SetToonInfo(toon)
	-- New Dec 2025 Collect some toon info for profile display (Alts)
	-- Unlikely to change on reload but...
	local toon_info = TitanSettings.Players[toon].Info ---@class CharInfo
	local unit = "player"

	local p, s, is_custom = Titan_G.utils.ParseName(toon)
	toon_info.name = p
	toon_info.server = s

	local classFilename, classID = UnitClassBase(unit) -- regardless of cosmetic changes
	local classInfo = C_CreatureInfo.GetClassInfo(classID)
	if classInfo == nil then
		toon_info.class = "??"
		toon_info.className = "??"
		toon_info.classId = 0
	else
		toon_info.class = classInfo.className -- localized
		toon_info.className = classInfo.classFile -- for comparison
		toon_info.classId = classInfo.classID
	end

	local englishFaction, localizedFaction = UnitFactionGroup(unit)
	toon_info.faction = localizedFaction
	toon_info.factionName = englishFaction

	local level = UnitLevel(unit)
	toon_info.level = level
	toon_info.levelText = tostring(level)

	local localizedRaceName, englishRaceName, raceID = UnitRace(unit)
	toon_info.race = localizedRaceName
	toon_info.raceName = englishRaceName
	toon_info.raceId = raceID

	-- 2026 Apr Add more info for Alts
	-- Set initially, updates via events
	toon_info.gold_toon = GetMoney() -- NO Warband

	local avgItemLevel, avgItemLevelEquipped, avgItemLevelPvp = GetAverageItemLevel()
	toon_info.itemLevelAve = avgItemLevel -- using only equip change event, this may not be accurate...
	toon_info.itemLevelEquipped = avgItemLevelEquipped -- this is the one we are tracking
	toon_info.itemLevelPvp = avgItemLevelPvp

	SetToonPlayedInfo('init')

	toon_info.unit_xp = UnitXP("player")
	toon_info.unit_xp_max = UnitXPMax("player")

	toon_info.zoneText = GetZoneText()
	toon_info.subZoneText = GetSubZoneText() or ""

	-- seems to return current location if hearth not bound
	toon_info.hearth_binding = GetBindLocation()

end

local function SetToonLogout(toon)
	-- New Dec 2025 Collect some toon info for profile display
	-- Do NOT call any API routines here!!
	-- WoW is shutting down and the return values are usually nil or wrong...
	--
	local toon_info = TitanSettings.Players[toon].Info

	local now = _G.time()
	toon_info.logout = now
	toon_info.logoutStr = TitanUtils_GetDateText(now, true)

	-- Zone and subzone set via events

	SetToonPlayedInfo('logout')
end

local function SetPluginsAndConfig()
	-- Some addons wait to create their LDB component or a Titan addon could
	-- create additional buttons as needed.
	Titan_Debug.Out('titan', 'p_e_w', "Register any plugins found")
	Titan_G.plugins.RegisterList()
	Titan_Debug.Out('titan', 'p_e_w', "> Register any plugins done")

	-- Loop through the LDB objects to sync with their created Titan plugin
	Titan_Debug.Out('titan', 'p_e_w', "Register any LDB (Titan) plugins")
	Titan_G.ldb.RefreshAll()
	Titan_Debug.Out('titan', 'p_e_w', "> Register any LDB (Titan) plugins done")

	-- Now sync saved variables to the profile chosen by the user.
	-- This will set the bar(s) and enabled plugins (via OnShow).
	Titan_Debug.Out('titan', 'p_e_w', "Synch plugin saved vars")
end

local function SetupTitan()
	Titan_Debug.Out('titan', 'p_e_w', "Init settings")

	-- Get Saved Vars; sync with defaults
	Titan_G.vars.InitSettings()

	-- Init panel font
	-- In case the user does not load the addon with the font they were using
	local isfontvalid = media:IsValid("font", Titan_G.vars.PanelGet("FontName"))
	if isfontvalid then
		-- should be good
	else
		-- if the selected font is not valid, revert to default (Friz Quadrata TT)
		Titan_G.vars.PanelSet("FontName", TPC.FONT_NAME);
	end

	if Titan_G.vars.Get("Silenced") then
		-- No header output
	else
		TitanPrint("", "header")
	end

	-- Set the two anchors in their default positions
	-- until the Titan bars are drawn
	Titan_Debug.Out('titan', 'p_e_w', "Create anchors for other addons")
	TitanPanelTopAnchor:ClearAllPoints();
	TitanPanelTopAnchor:SetPoint("TOPLEFT", "UIParent", "TOPLEFT", 0, 0);
	TitanPanelBottomAnchor:ClearAllPoints();
	TitanPanelBottomAnchor:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 0, 0);

	-- Ensure the bars are created before the plugins are registered.
	Titan_Debug.Out('titan', 'p_e_w', "Create frames for Titan bars")
	for idx, v in pairs(TitanBarData) do
		Titan_Debug.Out('titan', 'bars_setup', "... " .. tostring(v.name))

		Titan_G.bars.CreateBar(idx, v.locale_name)
	end
	--		Titan_AutoHide_Create_Frames()

	-- Add to Addon Compartment, if feature is present
	RegisterAddonCompartment()

	-- Should be safe to register for events that could show / hide Bars
	Titan_Debug.Out('titan', 'p_e_w', "Register for events Titan needs")
	RegisterForEvents()

	local _ = nil
	SetToonInfo(Titan_G.utils.GetPlayer())
	Titan_Debug.Out('titan', 'p_e_w', "Init settings done")
end

local function SetupUser()
	-- User could have changed the addons loaded, so register plugins and LDB again.
	SetPluginsAndConfig()

	-- Set the profile per the user choices.
	Titan_Debug.Out('titan', 'p_e_w', "Set up player")
	Titan_G.vars.UseSettings(nil, Titan_G.utils.GetPlayer(), TITAN_PROFILE_INIT)

	Titan_Debug.Out('titan', 'p_e_w', "Init config data (right click menu)")
	-- all addons are loaded so update the config (options)
	-- some could have registered late...
	Titan_G.config.Update("init")
	Titan_Debug.Out('titan', 'p_e_w', "Init config data (right click menu) done")
end

--------------------------------------------------------------
--
-- Event handlers
--

local function FrameCleanup()
	-- Without a wait this was happening WAY too early in the PEW


	Titan_Menu.CloseMenus() -- cleanup any open menus

	-- Nuke the tooltip, if open
	-- Titan tooltip - newer (2026 Jan)
	-- Game tooltip - older or custom


	-- Ugly until this is wrapped properly
	if TitanPanelTooltip and TitanPanelTooltip:IsVisible() then
		TitanPanelTooltip:Hide()
	else
		-- not open
	end
	if GameTooltip and GameTooltip:IsVisible() then
		-- WoW may handle this but just in case...
		GameTooltip:Hide()
	else
		-- not open
	end
end

local function StopTitan(err_str, ret_val)
	-- something really bad occured...
	TitanPrint(err_str .. "!!!!  Cleaning up...", "error")
	TitanPrint("--" .. ret_val, "error")
	-- Hide the bars. At times they are there but at 0% transparency.
	-- They can be over the Blizz action bars creating havoc.
	TitanPrint("-- Hiding Titan bars...", "warning")
	Titan_G.bars.HideAllBars()

	-- Remove the options pages, just in case; likely config would not work...
	Titan_G.config.Update("nuke")
	-- What else to clean up???

	-- raise the error to WoW for display, if display errors is set.
	-- This *will be* the last statement of PLAYER_ENTERING_WORLD!
	error(ret_val, 1)
end

---local Ensure the Titan tooltip backdrop is set.
local function StyleTooltip()

	if TitanPanelTooltip and SharedTooltip_SetBackdropStyle then
		SharedTooltip_SetBackdropStyle(TitanPanelTooltip)
	end
	--[[ 2026 Jul
Skinning addons (ElvUI, EllesmereUI, ...) restyle a fixed list of tooltips when they
initialize, then catch every other tooltip by hooking SharedTooltip_SetBackdropStyle.
TitanPanelTooltip is in no addon's list, and WoW calls that routine for a tooltip only
when it is hidden. Without this the first plugin tooltip shown after login or reload
keeps the default Blizzard look and only later tooltips are skinned.

No addon detection or setting check is needed: a skinning addon installs its hook only
while its tooltip skin is enabled, and with none installed this simply re-applies the
default style TitanPanelTooltip already has. A nil style means default.

In effect, this allows an addon to 'skin' Titan tooltips to its own style.
	--]]
end

---Handle PLAYER_ENTERING_WORLD Initialize Titan, set and display Titan bars and plugins.
---@param arg1 boolean isLogin
---@param arg2 boolean isReload
function Titan_G.control.frame:PLAYER_ENTERING_WORLD(arg1, arg2, arg3, arg4)
	local call_ok = nil
	local ret_val = nil

	Titan_Debug.Out('titan', 'p_e_w', "Titan PLAYER_ENTERING_WORLD pcall setup routine")

	--[[
	With profile and API changes over the years, the PEW has evolved into 3 distinct sections:
	1) Setup : Titan vars; variables; events; and creation of bars
	2) Load :
	- Profiles : Determining the actual profile to use; cleanup and adjustments of profile data
	- Plugins : Built-ins, third party, and LDB
	3) Draw : Place Titan and plugins on WoW UI per the profile

	1) Needed only on login
	2) and 3) Needed on reload of UI
	If the user is just changing map locations then no work is needed
	
	2026 Feb : redone to improve splash screen timing and make Titan more stable on errors
	--]]

	if arg1 == true then -- login, only once
		-- if tooltip gets stuck allow user to tap ESC to clear
		tinsert(UISpecialFrames, "TitanPanelTooltip")

	else
	end

	if arg1 == true -- login
		or arg2 == true -- reload
	then
		-- StopTitan will force error and end this routine
		Titan_G.utils.SetPlayer()

		call_ok, ret_val = pcall(SetupTitan) -- including player
		if call_ok then
			-- Titan initialized properly
		else
			StopTitan("Could not initialize", ret_val) -- something really bad occured...
		end

		-- Register plugins; set profile; set config
		call_ok, ret_val = pcall(SetupUser)
		if call_ok then
			-- Titan initialized properly
		else
			StopTitan("Setup error", ret_val) -- something really bad occured...
		end

		-- Set tooltip style
		StyleTooltip()
	else
		-- map change
	end

	do -- a little UI cleanup, just in case
		C_Timer.After(1.0, function() FrameCleanup() end)
	end

	-- Titan Panel has initialized its variables and registered plugins.
	Titan_G.InitializedPEW = true

	Titan_Debug.Out('titan', 'p_e_w', "Titan init processing done")
end

---Handle CVAR_UPDATE React to user changed WoW options.
function Titan_G.control.frame:CVAR_UPDATE(cvarname, cvarvalue)
	if cvarname == "USE_UISCALE"
		or cvarname == "WINDOWED_MODE"
		or cvarname == "uiScale" then
		if TitanPlayerSettings and Titan_G.vars.PanelGet("Scale") then
			--TitanPanel_InitPanelBarButton("CVAR_ " .. tostring(cvarname))
			Titan_G.bars.ShowPlugins("CVAR_ " .. tostring(cvarname))
		end
	end
end

---Handle PLAYER_LOGOUT On logout, set some debug data in saved variables.
function Titan_G.control.frame:PLAYER_LOGOUT()
	-- many API calls will not work; data is not caught before the actual logout...
	--[[
		-- for debug
		if TitanPanelRegister then
			TitanPanelRegister.ToBe = TitanPluginToBeRegistered
			TitanPanelRegister.ToBeNum = TitanPluginToBeRegisteredNum
			TitanPanelRegister.Titan_G.plugins.info = Titan_G.plugins.info
		end
	Titan_G.InitializedPEW = false

	--]]
	SetToonLogout(Titan_G.utils.GetPlayer())
end

---Handle ZONE_CHANGED_INDOORS Hide Titan top bars if user requested to hide Top bar(s) in BG or arena
function Titan_G.control.frame:ZONE_CHANGED()
	Titan_G.bars.DisplayBarsWanted("ZONE_CHANGED")
	SetToonZoneInfo()
end

---Handle ZONE_CHANGED_INDOORS Hide Titan top bars if user requested to hide Top bar(s) in BG or arena
function Titan_G.control.frame:ZONE_CHANGED_INDOORS()
	Titan_G.bars.DisplayBarsWanted("ZONE_CHANGED_INDOORS")
	SetToonZoneInfo()
end

---Handle ZONE_CHANGED_INDOORS Hide Titan top bars if user requested to hide Top bar(s) in BG or arena
function Titan_G.control.frame:ZONE_CHANGED_NEW_AREA()
	Titan_G.bars.DisplayBarsWanted("ZONE_CHANGED_NEW_AREA")
	SetToonZoneInfo()
end

---Handle PET_BATTLE_CLOSE Hide Titan bars during pet battle.
function Titan_G.control.frame:PET_BATTLE_OPENING_START()
	Titan_G.bars.DisplayBarsWanted("PET_BATTLE_OPENING_START")
end

---Handle PET_BATTLE_CLOSE Show Titan bars hidden bars during pet battle.
function Titan_G.control.frame:PET_BATTLE_CLOSE()
	Titan_G.bars.DisplayBarsWanted("PET_BATTLE_CLOSE")
end

local in_combat = false -- seems InCombatLockdown may not be set fast enough to reliably hide bars...

---Handle PLAYER_REGEN_ENABLED Titan bars may be hidden during combat.
--- Use local in_combat - seems InCombatLockdown() may not be set fast enough to reliably hide bars...
function Titan_G.control.frame:PLAYER_REGEN_ENABLED()
	in_combat = false
	Titan_G.bars.DisplayBarsWanted("PLAYER_REGEN_ENABLED")
end

---Handle PLAYER_REGEN_DISABLED Titan bars may have been hidden during combat.
--- Use local in_combat - seems InCombatLockdown() may not be set fast enough to reliably hide bars...
function Titan_G.control.frame:PLAYER_REGEN_DISABLED()
	in_combat = true
	Titan_G.bars.DisplayBarsWanted("PLAYER_REGEN_DISABLED")
end

-- Events 'for profile' are needed because routines called during logout event return invalid results.

---Store in profile
function Titan_G.control.frame:PLAYER_MONEY()
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	-- 2026 Mar Add more info for Alts
	toon_info.gold_toon = GetMoney() -- NO Warband
end

---Store in profile
function Titan_G.control.frame:PLAYER_EQUIPMENT_CHANGED()
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info
	-- 2026 Mar Add more info for Alts
	local avgItemLevel, avgItemLevelEquipped, avgItemLevelPvp = GetAverageItemLevel()
	toon_info.itemLevelAve = avgItemLevel -- not accurate w/o tracking armor in bags
	toon_info.itemLevelEquipped = avgItemLevelEquipped
	toon_info.itemLevelPvp = avgItemLevelPvp
	-- Poss info to save for Alts
	-- professions, XP (Rested), level %, bags (free/total), connected realms (server click)
	-- raid (locked list on click), num quests, currencies (on click - virtual)

end

---For /played in profile
function Titan_G.control.frame:TIME_PLAYED_MSG(a1, a2, ...)
--	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	SetToonPlayedInfo('update', a1, a2)
end

---For player level in profile
function Titan_G.control.frame:PLAYER_LEVEL_UP(a1, ...)
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	toon_info.level = a1
	toon_info.levelText = tostring(a1)

	SetToonPlayedInfo('level')
end

---For player XP in profile
function Titan_G.control.frame:PLAYER_XP_UPDATE(...)
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	toon_info.unit_xp = UnitXP("player")
	toon_info.unit_xp_max = UnitXPMax("player")
end

---For player hearth in profile
function Titan_G.control.frame:HEARTHSTONE_BOUND(...)
	local toon_info = TitanSettings.Players[Titan_G.utils.GetPlayer()].Info ---@class CharInfo
	-- seems to return current location if hearth not bound
	toon_info.hearth_binding = GetBindLocation()
end

---local Handle the button clicks on any Titan bar.
--- This only reacts to the right or left mouse click without modifiers.
--- Used in the set script for the Titan display and hider frames
---@param self table Titan bar frame
---@param button string Button clicked
local function Bar_OnClick(self, button)
	-- ensure that the right-click menu will not appear on "hidden" bottom bar(s)
	if (button == "LeftButton") then
		Titan_G.control.CloseAllControlFrames();
		Titan_Menu.CloseMenus();
	elseif (button == "RightButton") then
		Titan_G.control.CloseAllControlFrames();
		TitanPanelRightClickMenu_Close();
		-- Show RightClickMenu anyway
		TitanPanelRightClickMenu_Toggle(self)
	end
end

--
-- Slash command handler
--


---local Helper to parse the user commands from Chat.
---@param cmd any
---@return table cmds List of 'words' user typed
--- each 'word' is made lower case for comparison simplicity
local function TitanPanel_ParseSlashCmd(cmd)
	local words = {}
	for w in string.gmatch(cmd, "%w+") do
		words[#words + 1] = (w and string.lower(w) or "?")
	end
	return words
end

---local Helper to tell the user the relevant Titan help commands.
---@param cmd string? 'all' default | 'reset' | 'gui' | 'silent'
local function handle_slash_help(cmd)
	cmd = cmd or "all"

	--	Give the user the general help if we can not figure out what they want
	TitanPrint("", "header")

	if cmd == "reset" then
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_1"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_2"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_3"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_4"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_5"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_RESET_6"], "plain")
	end
	if cmd == "gui" then
		TitanPrint(L["TITAN_PANEL_SLASH_GUI_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_GUI_1"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_GUI_2"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_GUI_3"], "plain")
	end
	if cmd == "profile" then
		TitanPrint(L["TITAN_PANEL_SLASH_PROFILE_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_PROFILE_1"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_PROFILE_2"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_PROFILE_3"], "plain")
	end
	if cmd == "silent" then
		TitanPrint(L["TITAN_PANEL_SLASH_SILENT_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_SILENT_1"], "plain")
	end
	if cmd == "orderhall" then
		TitanPrint(L["TITAN_PANEL_SLASH_ORDERHALL_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_ORDERHALL_1"], "plain")
	end
	if cmd == "help" then
		TitanPrint(L["TITAN_PANEL_SLASH_HELP_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_HELP_1"], "plain")
	end
	if cmd == "all" then
		TitanPrint(L["TITAN_PANEL_SLASH_ALL_0"], "plain")
		TitanPrint(L["TITAN_PANEL_SLASH_ALL_1"], "plain")
	end
end

---local Helper to handle 'reset' commands.
---@param cmd_list table  'tipfont' | 'panelscale' | "spacing" | none - Reset to Titan defaults
local function handle_reset_cmds(cmd_list)
	local cmd = cmd_list[1]
	local p1 = cmd_list[2] or nil
	-- sanity check
	if (not cmd == "reset") then
		return
	end

	if p1 == nil then
		TitanPanel_ResetToDefault()
	elseif p1 == "all" then
		Titan_G.ResetTitanToDefault()
	elseif p1 == "tipfont" then
		Titan_G.vars.PanelSet("TooltipFont", 1);
		GameTooltip:SetScale(Titan_G.vars.PanelGet("TooltipFont"));
		TitanPrint(L["TITAN_PANEL_SLASH_RESP1"], "info")
	elseif p1 == "panelscale" then
		if not InCombatLockdown() then
			Titan_G.vars.PanelSet("Scale", 1);
			--TitanPanel_InitPanelBarButton("/panelscale reset ")
			Titan_G.bars.ShowPlugins("/panelscale reset ")
			TitanPrint(L["TITAN_PANEL_SLASH_RESP3"], "info")
		else
			TitanPrint(L["TITAN_PANEL_MENU_IN_COMBAT_LOCKDOWN"], "warning")
		end
	elseif p1 == "spacing" then
		Titan_G.vars.PanelSet("ButtonSpacing", 20);
		Titan_G.bars.ShowPlugins("/spacing reset");
		TitanPrint(L["TITAN_PANEL_SLASH_RESP4"], "info")
	else
		handle_slash_help("reset")
	end
end

---local Helper to handle 'gui' commands - open Titan options.
---@param cmd_list table
local function handle_giu_cmds(cmd_list)
	local cmd = cmd_list[1]
	local p1 = cmd_list[2] or nil
	-- sanity check
	if (not cmd == "gui") then
		return
	end

	Titan_G.config.OpenConfig("slash gui")
end

---local Helper to handle profile commands - Set to profile if not using global profile.
---@param cmd_list table
local function handle_profile_cmds(cmd_list)
	local cmd = cmd_list[1]
	-- sanity check
	if (not cmd == "profile") then
		return
	end
	AceConfigDialog:Open("Titan Panel Addon Profiles")
end

---local Helper to handle 'silent' commands - Toggle "Silenced" setting.
---@param cmd_list table
local function handle_silent_cmds(cmd_list)
	local cmd = cmd_list[1]
	-- sanity check
	if (not cmd == "silent") then
		return
	end

	if Titan_G.vars.Get("Silenced") then
		Titan_G.vars.Set("Silenced", false);
		TitanPrint(L["TITAN_PANEL_MENU_SILENT_LOAD"] .. " " .. L["TITAN_PANEL_MENU_DISABLED"], "info")
	else
		Titan_G.vars.Set("Silenced", true);
		TitanPrint(L["TITAN_PANEL_MENU_SILENT_LOAD"] .. " " .. L["TITAN_PANEL_MENU_ENABLED"], "info")
	end
end

---local Helper to handle 'orderhall' commands - Toggle "OrderHall" setting.
---@param cmd_list table
local function handle_orderhall_cmds(cmd_list)
	local cmd = cmd_list[1]
	local p1 = cmd_list[2] or nil
	-- sanity check
	if (not cmd == "orderhall") then
		return
	end

	if Titan_G.vars.Get("OrderHall") then
		Titan_G.vars.Set("OrderHall", false);
		TitanPrint(L["TITAN_PANEL_MENU_HIDE_ORDERHALL"] .. " " .. L["TITAN_PANEL_MENU_ENABLED"], "info")
		StaticPopupDialogs["TITAN_RELOAD"] = {
			text = TitanUtils_GetNormalText(L["TITAN_PANEL_MENU_TITLE"]) .. "\n\n"
				.. L["TITAN_PANEL_RELOAD"],
			button1 = ACCEPT,
			button2 = CANCEL,
			OnAccept = function(self)
				C_UI.Reload();
			end,
			showAlert = 1,
			timeout = 0,
			whileDead = 1,
			hideOnEscape = 1
		};
		StaticPopup_Show("TITAN_RELOAD");
	else
		Titan_G.vars.Set("OrderHall", true);
		TitanPrint(L["TITAN_PANEL_MENU_HIDE_ORDERHALL"] .. " " .. L["TITAN_PANEL_MENU_DISABLED"], "info")
		StaticPopupDialogs["TITAN_RELOAD"] = {
			text = TitanUtils_GetNormalText(L["TITAN_PANEL_MENU_TITLE"]) .. "\n\n"
				.. L["TITAN_PANEL_RELOAD"],
			button1 = ACCEPT,
			button2 = CANCEL,
			OnAccept = function(self)
				C_UI.Reload();
			end,
			showAlert = 1,
			timeout = 0,
			whileDead = 1,
			hideOnEscape = 1
		};
		StaticPopup_Show("TITAN_RELOAD");
	end
end

--[=[ local
DESC: Helper to execute the help commands from the user.
VAR: cmd_list - A table containing the list of 'words' the user typed in
OUT: None
local function handle_help_cmds(cmd_list)
	local cmd = cmd_list[1]
	local p1 = cmd_list[2] or nil
	-- sanity check
	if (not cmd == "help") then
		return
	end

	handle_slash_help(p1 or "all")
end
--]=]

---local Helper to parse and execute all the Titan slash commands from the user.
---@param cmd_str string
local function TitanPanel_RegisterSlashCmd(cmd_str)
	local cmd_list = {}
	-- parse what the user typed
	cmd_list = TitanPanel_ParseSlashCmd(cmd_str)
	local cmd = cmd_list[1] or ""
	local p1 = cmd_list[2] or ""
--	local p2 = cmd_list[3] or ""
--	local p3 = cmd_list[4] or ""

	if (cmd == "reset") then
		handle_reset_cmds(cmd_list)
	elseif (cmd == "gui") then
		handle_giu_cmds(cmd_list)
	elseif (cmd == "profile") then
		handle_profile_cmds(cmd_list)
	elseif (cmd == "silent") then
		handle_silent_cmds(cmd_list)
	elseif (cmd == "orderhall") then
		handle_orderhall_cmds(cmd_list)
	elseif (cmd == "help") then
		handle_slash_help(p1)
	else
		handle_slash_help("all")
	end
end

--====== Register slash commands for Titan Panel
SlashCmdList["TitanPanel"] = TitanPanel_RegisterSlashCmd;
SLASH_TitanPanel1 = "/titanpanel";
SLASH_TitanPanel2 = "/titan";

--------------------------------------------------------------
--
-- Texture routines


---local Set the Titan bar color per user selection
---@param frame string Titan bar name
---@param tex table Texture frame to set
---@param color table Color - RBGA
local function Set_Color(frame, tex, color)
	-- Jan 2026 : Put gorder on option
	local edge = TitanBarDataVars[frame].color_border
	local edge_file = ""
	if edge then
		edge_file = "Interface\\Glues\\Common\\TextPanel-Border"
	else
		edge_file = ""
	end

	--[[
print("_Set bar color"
.." '"..tostring(frame).."'"
.." "..tostring(TitanBarData[frame].tex_name)..""
--.." "..tostring(tex:GetName())..""
.." "..tostring(format("%0.1f", color.r))..""
.." "..tostring(format("%0.1f", color.g))..""
.." "..tostring(format("%0.1f", color.b))..""
.." "..tostring(format("%0.1f", color.alpha))..""
.." "..tostring(edge)..""
)
--]]

	_G[frame]:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		--		edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
		--		edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
		edgeFile = edge_file,
		tile = true,
		tileEdge = edge,
		--		insets = { left = 1, right = 1, top = 1, bottom = 1 },
		tileSize = 8,
		edgeSize = 8,
	})

	_G[frame]:SetBackdropBorderColor(
		TOOLTIP_DEFAULT_COLOR.r,
		TOOLTIP_DEFAULT_COLOR.g,
		TOOLTIP_DEFAULT_COLOR.b,
		color.alpha); -- 2024 Aug : Border will use the color alpha

	_G[frame]:SetBackdropColor(
		color.r,
		color.g,
		color.b,
		color.alpha);
end

---local Set the Titan bar texture / skin per user selectable options
---@param frame string Titan bar name
---@param tex table Texture frame to set
---@param skin table Skin to use
local function Set_Skin(frame, tex, skin)
	-- skins are in two parts - top & bottom...
	-- TODO : have Short bars choose top or bottom skin??
	local edge = ""
	if TitanBarData[frame].vert == TITAN_BOTTOM
	then
		edge = TITAN_BOTTOM
	else
		edge = TITAN_TOP
	end

	-- Apply the texture to the bar, using the system repeat to fill it
	local texture_file = skin.path .. "TitanPanelBackground" .. edge .. "0"
	--[[
print("_Skin"
.." "..tostring(TitanBarData[frame].tex_name..""
--.." "..tostring(tex:GetName())..""
.." "..tostring(skin.path)..""
--.."\n "..tostring(edge)..""
--.." "..tostring(skin.alpha)..""
--.."\n "..tostring(tex:GetTexture())..""
)
--]]
	--[[ -- appears seeting image this way just smears image...
	_G[frame]:SetBackdrop({
		bgFile=texture_file,
--		edgeFile=nil,
		tile = true,
--		tileSize = 256,
--		tileEdge = true,
--		insets = { left = 1, right = 1, top = 1, bottom = 1 },
--		tileSize = 8,
--		edgeSize = 8,
	})
--]]
	tex:SetAllPoints()
	tex:SetHorizTile(true) -- ensures repeat; 'smears' if not sest to true
	tex:SetTexture(texture_file, "REPEAT")
	tex:SetVertTile(true) -- ensures image is 'full' height of frame
	tex:SetAlpha(skin.alpha)
end

---Set the texture / skin of the bar per the user selection.
---@param frame string Titan bar frame name
function Titan_G.bars.SetTexture(frame)
	if frame and TitanBarData[frame] then
		-- proceed
	else
		return
	end

	-- Create the path & file name to the texture
	local tex = TitanBarData[frame].tex_name
	local titanTexture = {}
	if _G[tex] then
		titanTexture = _G[tex]
	else
		titanTexture = _G[frame]:CreateTexture(tex, "BACKGROUND")
	end
	titanTexture:SetTexture()
	_G[frame]:SetBackdrop({
		bgFile = "",
	})

	--[[
print("_Tex"
.." "..tostring(TitanBarData[frame].name)..""
--.." "..tostring(tex)..""
.." "..tostring(titanTexture:GetName())..""
--.." "..tostring(skin.path)..""
--.."\n "..tostring(edge)..""
--.." "..tostring(skin.alpha)..""
--.."\n "..tostring(tex:GetTexture())..""
.." "..tostring(TitanBarDataVars["Global"].texure)..""
.." "..tostring(TitanBarDataVars[frame].texure)..""
)
--]]
	-- Use the texture / skin per user selectable options
	--[[
	if TitanBarDataVars["Global"].texure == Titan_G.SKIN then
		Set_Skin(frame, titanTexture, TitanBarDataVars["Global"].skin) -- tex_path = Titan_G.vars.PanelGet("TexturePath")
	elseif TitanBarDataVars["Global"].texure == Titan_G.COLOR then
		Set_Color(frame, titanTexture, TitanBarDataVars["Global"].color)
	else
--]]
	if TitanBarDataVars[frame].texure == Titan_G.SKIN then
		Set_Skin(frame, titanTexture, TitanBarDataVars[frame].skin)
	elseif TitanBarDataVars[frame].texure == Titan_G.COLOR then
		Set_Color(frame, titanTexture, TitanBarDataVars[frame].color)
	end
end

---On leaving the display check if we have to hide the Titan bar. A timer is used - when it expires the bar is hidden.
---@param self table Titan bar frame
function Titan_G.bars.OnLeave(self)
	local frame = (self and self:GetName() or nil)
	local bar = (TitanBarData[frame] and TitanBarData[frame].name or nil)

	-- if auto hide is active then let the timer hide the bar
	local hide = (bar and TitanBarDataVars[frame].auto_hide or nil)
	if hide then
		Titan_G.bars.HideTimers(frame, "Leave")
	end
end

---No code - this is a place holder for the XML template.
---@param self table Titan Hider bar frame
function Titan_G.bars.OnEnter(self)
	-- no work to do
end

---No code - this is a place holder for the XML template.
---@param self table Titan Hider bar frame
function Titan_G.bars.Hider_OnLeave(self)
	-- no work to do
end

---On entering the hider, check if we need to show the display bar.
--- No action is taken if the user is on combat.
---@param self table Titan Hider bar frame
function Titan_G.bars.Hider_OnEnter(self)
	-- make sure self is valid
	local index = self and self:GetName() or nil
	if not index then return end -- sanity check

	-- so the bar does not 'appear' when moused over in combat
	if Titan_G.vars.PanelGet("LockAutoHideInCombat") and InCombatLockdown() then return end

	-- find the relevant bar data
	local frame = nil
	for idx, v in pairs(TitanBarData) do
		if index == TitanBarData[idx].hider then
			frame = idx
		end
	end
	-- Now process that bar
	if frame then
		Titan_G.bars.HideTimers(frame, "Enter")
		Titan_G.bars.Show(frame)
	end
end

--[[ Appears unused...
---Toggle the auto hide of the given Titan bar per the user's new choice.
---@param frame string Frame mame of the Titan bar
function TitanPanelBarButton_ToggleAutoHide(frame)
	local frName = _G[frame]
	local plugin = (TitanBarData[frame] and TitanBarData[frame].auto_hide_plugin or nil)

	if frName then
		Titan_G.bars.ToggleHide(_G[plugin])
	end
end
--]]

--====== Titan Bar
--
--==========================
-- Routines to handle moving and sizing of short bars
--

---local Check the change in width; snap to edge of any part goes off screen.
---@param self table Titan short bar frame
---@param width number New width
---@param reason string Note on why this was called
---@return table result .ok boolean; .err string
local function CheckBarBounds(self, width, reason)
	-- This is a touchy routine - change with care!! :)
	--
	-- Let WoW handle any change in game scale.
	-- When Titan scaling changes, recalc the bar placement.
	-- Although the user may want to move bars in response to any scale change.
	local trace = false -- true false
	local result = {}
	result.ok = true
	result.err = ""
	local err = ""

	local f_name = self:GetName()
	local bar_name = TitanBarData[f_name].name
	local locale_name = TitanBarData[f_name].locale_name

	if TitanBarData[f_name].user_move
		and TitanBarDataVars[f_name].show
	then
		---[[
		if trace then
			print("Bounds"
				.. " " .. tostring(bar_name) .. ""
				.. " " .. tostring(width) .. ""
				.. " " .. tostring(reason) .. ""
			)
		end
		--]]

		local tscale = Titan_G.vars.PanelGet("Scale")
		local bar_data = {Titan_G.vars.GetBarPos(f_name)}
		local scale = bar_data[4]
		local scale_change = false
		if tscale == scale then
			-- no need to use scaling to recalc position
		else
			scale_change = true
			-- The 'set' will update the sacaling for next time
		end
		local screen = Titan_G.utils.ScreenSize()
--		local screen_right_scaled = screen.scaled_x
--		local screen_top_scaled = screen.scaled_y
		local screen_right = screen.x
		local screen_top = screen.y
		local screen_right_t = screen.x * tscale
		local screen_top_t = screen.y * tscale

		local bar_left = math.floor(self:GetLeft())
		local bar_right = math.floor(self:GetRight())
		local bar_top = math.floor(self:GetTop())
		local bar_bottom = math.floor(self:GetBottom())

		local orig_w = self:GetWidth() -- * tscale --math.floor(self:GetWidth() * tscale)
		local l_off = bar_left
		local r_off = bar_right
		local t_off = bar_top
		local b_off = bar_bottom
		local hght = (t_off - b_off)

		if scale_change then
			-- Apply the Titan scaling to get 'real' position within WoW window;
			-- Use floor to trunc decimal places where the side could be right on the edge of the screen.
			l_off = math.floor(bar_left * tscale)
			r_off = math.floor(bar_right * tscale)
			t_off = math.floor(bar_top * tscale)
			b_off = math.floor(bar_bottom * tscale)
		else
			-- Just check the bar position
		end
		---[[
		if trace then
			print(">Bounds"
				.. " " .. tostring(bar_name) .. ""
				.. "\n"
				.. " L " .. tostring(format("%0.1f", l_off)) .. ""
				.. " R " .. tostring(format("%0.1f", r_off)) .. ""
				.. " T " .. tostring(format("%0.1f", t_off)) .. ""
				.. " B " .. tostring(format("%0.1f", b_off)) .. ""
				.. " W " .. tostring(format("%0.1f", orig_w)) .. ""
				.. " H " .. tostring(format("%0.1f", hght)) .. ""
				.. "\n"
				.. " SR " .. tostring(format("%0.1f", screen_right)) .. ""
				.. " ST " .. tostring(format("%0.1f", screen_top)) .. ""
				.. " SR_t " .. tostring(format("%0.1f", screen_right_t)) .. ""
				.. " ST_t " .. tostring(format("%0.1f", screen_top_t)) .. ""
			)
		end
		--]]
		local w = 0
		local x_off = 0
		local y_off = 0
		local w_off = 0

		-- Assume all ok :)
		x_off = l_off
		y_off = b_off

		if (width == 0) then -- drag & drop OR entry / reload
			-- Assumes BOTTOMLEFT of screen per Short bar defaults.
			-- if resolution is not 'pixel perfect' rounding could cause algorithm to think bar is off screen

			-- Keep the width
			w_off = orig_w

			if l_off < 0 then
				x_off = 0
				err = "Off left of screen, snap to edge"
			elseif (r_off) > screen_right then
				x_off = math.floor(screen_right - (r_off - l_off))
				err = "Off right side of screen, snap to edge"
			end
			if err ~= "" then
				result.ok = false
				result.err = err
				if trace then
					TitanPrint(locale_name .. " " .. err .. "!!!!"
					, "warning")
				end
			end
			err = ""
			if (t_off) > screen_top then
				y_off = math.floor(screen_top - (t_off - b_off))
				err = "Off top of screen, snap to edge"
			elseif b_off < 0 then
				y_off = 0
				err = "Off bottom of screen, snap to edge"
			end
			if err ~= "" then
				result.ok = false
				result.err = result.err .. "\n" .. err
				if trace then
					TitanPrint(locale_name .. " " .. err .. "!!!!"
						.. " [" .. tostring(format("%0.1f", x_off)) .. "]"
						.. " [" .. tostring(format("%0.1f", y_off)) .. "]"
						, "warning")
				end
			end
		else -- width change
			local min_w, min_h, max_w, max_h = self:GetResizeBounds()
			-- Keep the X and Y
			local w_new = orig_w + width
			if w_new < min_w then
				-- do nothing - too small
				w_off = min_w
				err = "Width too small. Set to min width."
			elseif w_new > max_w then
				w_off = max_w
				err = "Width too big. Set to max width." -- too wide
			elseif x_off + (w_new * tscale) > screen_right then
				w_off = orig_w
				err = "Off right of screen, snap to edge"
			else
				w_off = w_new
			end

			self:SetSize(w_off, Titan_G.bars.HEIGHT)
			--			self:SetWidth(w_off)
		end

		if scale_change then
			-- Back out Titan scaling
			x_off = math.floor(x_off / tscale)
			y_off = math.floor(y_off / tscale)
		else
			-- Accept the results of the checks
		end
		w_off = w_off --/ tscale
		Titan_G.vars.SetBarPos(self, false, x_off, y_off, w_off)

		if trace then
			print(">>Bounds"
				.. " " .. tostring(bar_name) .. ""
				.. " " .. tostring(result.ok) .. ""
				.. " SC " .. tostring(scale_change) .. ""
				.. " X " .. tostring(format("%0.1f", x_off)) .. "(" .. tostring(bar_left) .. ")"
				.. " Y " .. tostring(format("%0.1f", y_off)) .. "(" .. tostring(bar_bottom) .. ")"
				.. " W " .. tostring(format("%0.1f", w_off)) .. ""
			)
			if err ~= "" then
				TitanPrint(locale_name .. " " .. err .. "!!!!"
					.. " [" .. tostring(format("%0.1f", x_off)) .. "]"
					.. " [" .. tostring(format("%0.1f", y_off)) .. "]"
					.. " [" .. tostring(format("%0.1f", w_off)) .. "]"
					, "warning")
			end
		end
	else
		-- Controlled with anchor points; cannot move so no check is needed
	end


	return result
end

---local Start the grap of a Short Titan bar if Shift and left mouse are held.
---@param self table
local function OnMoveStart(self)
	if IsShiftKeyDown() then
		if self:IsMovable() then
			self.isMoving = true
			self:StartMoving()
			_G.GameTooltip:Hide()
		end
	else
		-- Do not move
	end
end

---local When a Short Titan bar drag is stopped.
---@param self table
local function OnMovingStop(self)
	self:StopMovingOrSizing()
	self.isMoving = nil

	local res = CheckBarBounds(self, 0, "OnMovingStop")
	if res.ok then
		-- placement ok
	else
		-- Need to 'snap' it to an edge
		--TitanPanel_InitPanelBarButton("OnMovingStop")
		Titan_G.bars.ShowPlugins("OnMovingStop")
	end
	-- Seems overkill - this will recalc all bars...
end

---local Change the width of a Short Titan bar when mouse is over the bar and Shift is held when the mouse wheel is used.
---@param self table Frame mouse is over
---@param d integer Mouse wheel direction (1 larger; -1 smaller)
--- Assuming a 1 'click' is a pixel
local function OnMouseWheel(self, d)
	-- Can get noisy, "Initializes" all bars at each click to ensure the bar is drawn.
	if IsShiftKeyDown() then
		local msg = "OnMouseWheel"
		local delta = d
		if IsControlKeyDown() then
			delta = d * 10
			msg = msg .. " +Alt"
		else
			-- use 1
		end
		local res = CheckBarBounds(self, delta, msg)
		if res.ok then
		end
		--[[
print("wheel"
.." "..tostring(self:GetName())..""
.." "..tostring(d)..""
.." old: "..tostring(format("%0.1f", old_w))..""
.." new: "..tostring(format("%0.1f", self:GetWidth()))..""
.." ok: "..tostring(res.ok)..""
)
--]]
		--		TitanPanel_InitPanelBarButton("OnMouseWheel")
	end
end

---Force all plugins created from LDB addons, visible or not, to be on the right side of the Titan bar.
--- Any visible plugin will be forced to the right side on the same bar it is currently on.
function Titan_G.bars.ForceLDBLaunchersRight()
	local plugin --= {}
	for index, id in pairs(Titan_G.plugins.index) do
		plugin = Titan_G.plugins.Get(id);
		if plugin and plugin.ldb == "launcher"
			and not Titan_G.plugins.GetVar(id, "DisplayOnRightSide") then
			Titan_G.plugins.ToggleVar(id, "DisplayOnRightSide");
			local button = TitanUtils_GetButton(id)
			if button then
				local buttonText = _G[button:GetName() .. Titan_G.bars.TEXT_STR];
				if not Titan_G.plugins.GetVar(id, "ShowIcon") then
					Titan_G.plugins.ToggleVar(id, "ShowIcon");
				end
				Titan_G.plugins.UpdateButton(id);
				if buttonText then
					buttonText:SetText("")
					button:SetWidth(16);
					Titan_G.plugins.info[id].buttonTextFunction = nil;
					_G[TitanUtils_ButtonName(id) .. Titan_G.bars.TEXT_STR] = nil;
					if button:IsVisible() then
						local bar = Titan_G.plugins.GetWhichBar(id)
						Titan_G.bars.RemovePlugin(id);
						Titan_G.plugins.AddOnBar(bar, id)
					end
				end
			end
		end
	end
end

---Show all the Titan bars the user has selected.
---@param reason string Debug note on where the call initiated
function Titan_G.bars.DisplayBarsWanted(reason)
	-- build debug output
	local str = "_DisplayBarsWanted"
		.. " " .. tostring(reason) .. ""
	Titan_Debug.Out('titan', 'bars_setup', str)

	-- Check all bars to see if the user has requested they be shown
	for idx, v in pairs(TitanBarData) do
		-- Show / hide plus kick auto hide, if needed
		Titan_G.bars.HideInit(idx)
	end
end

---This routine will hide all the Titan bars (and hiders) regardless of what the user has selected.
--- For example when the pet battle is active. We cannot figure out how to move the pet battle frame so we are punting and hiding Titan...
--- We only need to hide the bars (and hiders) - not adjust frames
function Titan_G.bars.HideAllBars()
	for idx, v in pairs(TitanBarData) do
		Titan_G.bars.Hide(idx)
	end
end

---local Show the requested Titan bar.
---@param frame_str string Titan bar
---@return boolean CanShow False if there is a restricting condition
local function showBar(frame_str)
	local flag = true -- only set false for known conditions

	if frame_str == Titan_G.vars.GetFrameName("Bar")
		or frame_str == Titan_G.vars.GetFrameName("Bar2")
	then
		-- ===== Battleground or Arena : User selected
		if TitanBarDataVars[frame_str].hide_in_pvp
			and (C_PvP and C_PvP.IsBattleground and C_PvP.IsBattleground())
			or (C_PvP and C_PvP.IsArena and C_PvP.IsArena()
			--			or GetZoneText() == "Stormwind City"
			--			or GetZoneText() == "Tempest Keep"
			)
		then
			flag = false
		end
	end

	-- ===== In Combat : User selected
	if TitanBarDataVars[frame_str].hide_in_combat
	then
		if in_combat then -- InCombatLockdown() too slow
			flag = false
		end
	end

	-- ===== In Pet Battle
	if C_PetBattles and C_PetBattles.IsInBattle() then
		if TitanBarData[frame_str].user_move then
			-- leave as is
		else
			flag = false
		end
	end
	--[[
print("showBar"
--.." "..tostring(C_PetBattles.IsInBattle())..""
.." > "..tostring(flag)..""
.." '"..tostring(frame_str).."'"
)
--]]
	return flag
end

---local Set the position of the requested Titan bar.
---@param frame string Titan bar
local function SetBar(frame)
	local trace = false
	local display = _G[frame];

	local x, y, w = Titan_G.vars.GetBarPos(frame)
	local show = TitanBarData[frame].show
	local bott = TitanBarData[frame].bott


	display:ClearAllPoints()
	if trace then
		--		local screen = Titan_G.utils.ScreenSize()
		--		local sx = screen.scaled_x
		--		local sy = screen.scaled_y
		print("SetBar"
			.. " " .. tostring(TitanBarData[frame].name) .. ""
			.. " x:" .. tostring(format("%0.1f", x)) .. ""
			.. " y:" .. tostring(format("%0.1f", y)) .. ""
			.. " w:" .. tostring(format("%0.1f", w)) .. ""
		)
	end

	if TitanBarData[frame].user_move then
		display:SetPoint(show.pt, show.rel_fr, show.rel_pt, x, y)
		display:SetSize(w, Titan_G.bars.HEIGHT)
	else
		display:SetPoint(show.pt, show.rel_fr, show.rel_pt, x, y)
		local h = Titan_G.bars.HEIGHT
		display:SetPoint(bott.pt, bott.rel_fr, bott.rel_pt, x, y - h)
	end
end

---Toggle the given Titan bar based on the user selection.
---@param frame string Frame mame of the Titan bar
function Titan_G.bars.Show(frame)
	local display = _G[frame];

	if display and TitanBarData[frame].name
	then
		if TitanBarDataVars[frame].show -- User requested
			and showBar(frame)    -- No preventing condition
		then                      -- Place Bar
			SetBar(frame)
			---[[			
			-- The bar may need to be moved back onto the screen.
			local res = CheckBarBounds(display, 0, "_Show the bar")
			if res.ok then
				-- placement ok
			else
				-- Need to 'snap' it to an edge
				SetBar(frame)
			end
			--]]
			Titan_G.bars.SetTexture(frame)

			if TitanBarData[frame].hider then
				_G[TitanBarData[frame].hider]:Hide()
			else
				-- not allowed for this bar
			end
		else
			-- The user has not elected to show this bar
			Titan_G.bars.Hide(frame)
		end
	end
end

---Hide the given Titan bar based on the user selection.
--- Hide moves rather than just 'not shown'. Otherwise the buttons will stay visible defeating the purpose of hide.
--- Also moves the hider bar if auto hide is not selected.
---@param frame string Frame mame of the Titan bar
function Titan_G.bars.Hide(frame)
	if TITAN_PANEL_MOVING == 1 then return end

	local display = _G[frame]
	local data = TitanBarData[frame]

	if display and data
	then
		local x, y, w = Titan_G.vars.GetBarPos(frame)
		-- This moves rather than hides. If we just hide then the plugins will still show.
		-- Hide by ensuriing the Y offset is off the screen.
		display:ClearAllPoints()
--		local h = (math.abs(y) + Titan_G.bars.HEIGHT * 2) * (-1 * y)
		local h = data.hide_y
		--[[
print("_Hide"
--.." "..tostring(frame)..""
.." "..tostring(data.name)..""
.." "..tostring(TitanBarDataVars[frame].show)..""
.." "..tostring(h)..""
)
--]]
		if TitanBarData[frame].user_move then
			display:SetPoint(data.show.pt, data.show.rel_fr, data.show.rel_pt, x, h)
		else
			display:SetPoint(data.show.pt, data.show.rel_fr, data.show.rel_pt, x, h)
			display:SetPoint(data.bott.pt, data.bott.rel_fr, data.bott.rel_pt, x, h - Titan_G.bars.HEIGHT)
		end

		if TitanBarData[frame].hider then
			local hider = _G[data.hider]
			if TitanBarDataVars[frame].show
				and TitanBarDataVars[frame].auto_hide then
				-- Auto hide is requested so show the hider bar in the right place
				hider:ClearAllPoints();
				hider:SetPoint(data.show.pt, data.show.rel_fr, data.show.rel_pt, x, y);
				hider:Show()
			else
				-- The bar was not requested
				hider:Hide()
			end
		else
			-- not allowed for this bar
		end
	end
end

---Show all user selected plugins on the Titan bar(s) then justify per the user selection.
--- This is done an all bars whether shown or not.
---@param reason string For debug
function Titan_G.bars.ShowPlugins(reason)
	local button
	local r_prior = {}
	local l_prior = {}

	-- 2026 Feb : Added setting scale and font on bars and plugins here to consolidate
	-- processing and reduce routines and hopefully be clearer for future changes
	local scale = Titan_G.vars.PanelGet("Scale");

	local button_spacing = Titan_G.vars.PanelGet("ButtonSpacing") * scale
	local icon_spacing = Titan_G.vars.PanelGet("IconSpacing") * scale

	-- build debug output
	local str = "_InitPanelButtons"
		.. " " .. tostring(reason) .. ""
	Titan_Debug.Out('titan', 'bars_setup', str)

	local prior = {}
	-- set prior to the starting offsets
	-- The right side plugins are set here.
	-- Justify adjusts the left side start according to the user setting
	-- The effect is left side plugins has spacing on the right side and
	-- right side plugins have spacing on the left.
	for idx, v in pairs(TitanBarData) do
		local bar = TitanBarData[idx].name
		local y_off = TitanBarData[idx].plugin_y_offset
		prior[bar] = {
			right = {
				button = Titan_G.vars.GetFrameName(bar),
				anchor = "RIGHT",
				x = 5, -- Offset of first plugin to right side of screen
				y = y_off,
			},
			left = {
				button = Titan_G.vars.GetFrameName(bar),
				anchor = "LEFT",
				x = 0, -- Justify adjusts - center or not
				y = y_off,
			},
		}
		_G[idx]:SetScale(scale)
	end
	--
	Titan_G.bars.DisplayBarsWanted("Titan_G.bars.ShowPlugins");

	-- Position all the buttons
	for idx = 1, table.maxn(TitanPanelSettings.Buttons) do
		local id = TitanPanelSettings.Buttons[idx];
		if (Titan_G.plugins.IsRegistered(id)) then
			local i = Titan_G.bars.GetPluginIndex(id);
			button = TitanUtils_GetButton(id);

			if button then
				-- Should help with spacing on init
				-- At point of need on config change rather than looping over plugins
				Titan_G.plugins.UpdateButton(id)
				-- If the plugin has asked to be on the right
				if Titan_G.plugins.ToRight(id) then
					-- =========================
					-- position the plugin relative to the prior plugin
					-- or the bar if it is the 1st
					r_prior = prior[TitanPanelSettings.Location[i]].right
					-- =========================
					button:ClearAllPoints();
					button:SetPoint("RIGHT", _G[r_prior.button]:GetName(), r_prior.anchor, (-(r_prior.x) * scale),
						r_prior.y)

					-- =========================
					-- capture the button for the next plugin
					r_prior.button = TitanUtils_ButtonName(id)
					-- set prior[x] the anchor points and offsets for the next plugin
					r_prior.anchor = "LEFT"
					r_prior.x = icon_spacing
					r_prior.y = 0
					-- =========================
				else
					--  handle plugins on the left side of the bar
					--
					-- =========================
					-- position the plugin relative to the prior plugin
					-- or the bar if it is the 1st
					l_prior = prior[TitanPanelSettings.Location[i]].left
					-- =========================
					--
					button:ClearAllPoints();
					button:SetPoint("LEFT", _G[l_prior.button]:GetName(), l_prior.anchor, l_prior.x * scale, l_prior.y);

					-- =========================
					-- capture the next plugin
					l_prior.button = TitanUtils_ButtonName(id)
					-- set prior[x] (anchor points and offsets) for the next plugin
					l_prior.anchor = "RIGHT"
					l_prior.x = (button_spacing)
					l_prior.y = 0
					-- =========================
				end
				button:Show()
			end
		end
	end
	-- Set panel button init flag
	TITAN_PANEL_BUTTONS_INIT_FLAG = 1;
	Titan_G.bars.Justify();
end

---local Reorder all the shown all user selected plugins on the Titan bar(s). Typically used after a button has been removed / hidden.
---@param index number of the plugin removed
local function Reorder_Plugins(index)
	for i = index, #TitanPanelSettings.Buttons do
		--		for i = index, table.getn(TitanPanelSettings.Buttons) do
		TitanPanelSettings.Location[i] = TitanPanelSettings.Location[i + 1]
	end
end

---Remove a plugin then show the rest of user selected plugins on the Titan bar(s).
---@param id string Unique ID of the plugin
---@param hide_plugin? boolean whether to hide plugin after removal
function Titan_G.bars.RemovePlugin(id, hide_plugin)
	if (not TitanPanelSettings) then
		return;
	end

	local hide_me = hide_plugin
	if hide_me == nil then
		hide_me = true -- not passed
	else
		-- was passed
	end

	local i = Titan_G.bars.GetPluginIndex(id)
	local currentButton = TitanUtils_GetButton(id);

	-- safeguard ...
	-- This cancels all timers of name "TitanPanel"..id as a safeguard to destroy any active plugin timers
	-- based on a fixed naming convention : TitanPanel..id, eg. "TitanPanelClock" this prevents "rogue"
	-- timers being left behind by lack of an OnHide check
	---@diagnostic disable-next-line: missing-parameter
	if id then AceTimer.CancelAllTimers() end -- ??? seems confused 0 or 1 params  "TitanPanel" .. id

	Reorder_Plugins(i);
	table.remove(TitanPanelSettings.Buttons, TitanUtils_GetCurrentIndex(TitanPanelSettings.Buttons, id));
	if currentButton and hide_me then
		currentButton:Hide();
	end
	-- Show the existing buttons
	Titan_G.bars.ShowPlugins("_RemoveButton");
end
TitanPanel_RemoveButton = Titan_G.bars.RemovePlugin ---Titan contact author before using this as a Titan API. This is a Titan internal function and may change without notice.

---Get the index of the given plugin from the Titan plugin displayed list.
--- The routine returns +1 if not found so it is 'safe' to add to the list
---@param id string Unique ID of the plugin
---@return number num position or num + 1 for end
function Titan_G.bars.GetPluginIndex(id)
	-- getn deprecated as of 5.2 - IDE now complaining 2024 Aug
	if (TitanPanelSettings) then
		for i = 1, #TitanPanelSettings.Buttons do
			if (TitanPanelSettings.Buttons[i] == id) then
				return i;
			end
		end
		return #TitanPanelSettings.Buttons + 1;
	else
		return 0;
	end
end

---Justify the plugins on each Titan bar.
--- Used when :
---- Init / show of a Titan bar
----the user changes the 'center' option on a Titan bar
function Titan_G.bars.Justify()
	-- Only the left side buttons are justified.
	if (not TITAN_PANEL_BUTTONS_INIT_FLAG or not TitanPanelSettings) then
		return;
	end
	if InCombatLockdown() then
		return; -- Issue 856 where some taint is caused if the plugin size is updated during combat. Seems since Mists was released...
	end

	local bar
	local x_offset
	local y_offset
	local firstLeftButton
	local scale = Titan_G.vars.PanelGet("Scale");
	local button_spacing = Titan_G.vars.PanelGet("ButtonSpacing") * scale
	local icon_spacing = Titan_G.vars.PanelGet("IconSpacing") * scale
	local leftWidth = 0;
	local rightWidth = 0;
	local counter = 0;
	local align = 0;
	local center_offset = 0;

	-- Look at each bar for plugins.
	for idx, v in pairs(TitanBarData) do
		bar = TitanBarData[idx].name
		--print("Bar Y"
		--	.. " " .. tostring(idx) .. ""
		--	.. " " .. tostring(TitanBarData[idx].plugin_y_offset) .. ""
		--	.. " " .. tostring(TitanBarDataVars[idx].plugin_off_y) .. ""
		--)
		y_offset = TitanBarData[idx].plugin_y_offset + TitanBarDataVars[idx].plugin_off_y -- user may offset
		x_offset = TitanBarData[idx].plugin_x_offset
		firstLeftButton = TitanUtils_GetButton(TitanPanelSettings.Buttons
			[Titan_G.plugins.GetFirstOnBar(bar, TITAN_LEFT)])
		align = TitanBarDataVars[idx].align --Titan_G.vars.PanelGet(bar.."_Align")
		leftWidth = 0;
		rightWidth = 0;
		counter = 0;
		-- If there is a plugin on this bar then justify the first button.
		-- The other buttons are relative to the first.
		if (firstLeftButton) then
			if (align == TITAN_PANEL_BUTTONS_ALIGN_LEFT) then
				-- Now offset the plugins
				firstLeftButton:ClearAllPoints();
				firstLeftButton:SetPoint("LEFT", idx, "LEFT", x_offset, y_offset);
			end
			-- Center if requested
			if (align == TITAN_PANEL_BUTTONS_ALIGN_CENTER) then
				leftWidth = 0;
				rightWidth = 0;
				counter = 0;
				-- Calc the total width of the icons so we know where to start
				for index, id in pairs(TitanPanelSettings.Buttons) do
					local button = TitanUtils_GetButton(id);
					if button and button:GetWidth() then
						if Titan_G.plugins.GetWhichBar(id) == bar then
							if (Titan_G.plugins.GetVar(id, "DisplayOnRightSide")) then
								rightWidth = rightWidth
									+ icon_spacing
									+ button:GetWidth();
							else
								counter = counter + 1;
								leftWidth = leftWidth
									+ button_spacing
									+ button:GetWidth()
							end
						end
					end
				end
				-- Now offset the plugins on the bar
				firstLeftButton:ClearAllPoints();
				-- remove the last spacing otherwise the buttons appear justified too far left
				center_offset = (0 - (leftWidth - button_spacing) / 2)
				firstLeftButton:SetPoint("LEFT", idx, "CENTER", center_offset, y_offset);
			end
		end
	end
end

--------------------------------------------------------------
--
-- Local routines for Titan menu creation

---Determine if the given plugin is on any Titan bar.
---@param id string Unique ID of the plugin
---@return boolean shown True on a Titan bar even if hidden or on auto hide
function Titan_G.bars.IsPluginShown(id)
	if (id and TitanPanelSettings) then
		return TitanUtils_TableContainsValue(TitanPanelSettings.Buttons, id)
	else
		return false
	end
end

---Determine if the given plugin is / would be on right or left of a Titan bar.
---@param id string Unique ID of the plugin
---@return string R_L  TITAN_RIGHT("Right") or TITAN_Left("Left")
function Titan_G.bars.GetPluginSide(id)
	if (Titan_G.plugins.GetVar(id, "DisplayOnRightSide")) then
		return TITAN_RIGHT;
	else
		return TITAN_LEFT;
	end
end

---Handle ADDON_LOADED Minimal setup in prep for player login.
function Titan_G.control.frame:ADDON_LOADED(addon)
	if addon == TITAN_ID then
		Titan_G.control.frame:RegisterEvent("PLAYER_ENTERING_WORLD")

		Titan_Debug.Out('titan', 'events', "ADDON_LOADED")

		-- Unregister event - saves a few event calls.
		self:UnregisterEvent("ADDON_LOADED");
		self.ADDON_LOADED = nil
	end
end

local function AddPlugin(owner, bar, category)
	local plugin

	for index, id in pairs(Titan_G.plugins.index) do
		plugin = Titan_G.plugins.Get(id)
		if plugin then
			plugin.category = plugin and plugin.category or "General";
			if (plugin.category == category) then -- add the plugin to the menu
				local bar_data = {Titan_G.plugins.GetWhichBar(id)}
				local which_bar = bar_data[2]
				if not Titan_G.plugins.GetVar(id, "ForceBar")
					or (Titan_G.plugins.GetVar(id, "ForceBar") == TitanBarData[bar:GetName()].name) then
					local info = {};
					local ver = plugin and plugin.version or ""
					if Titan_G.vars.PanelGet("VersionShown") then
						if ver == nil or ver == "" then
							ver = "" -- safety in case of nil
						else
							ver = TitanUtils_GetGreenText(" (" .. ver .. ")")
						end
					else
						ver = "" -- not requested
					end
					info.text = plugin and plugin.menuText .. ver or ""

					-- Add Bar
					if which_bar == nil then
						-- Plugin not shown
					else
						info.text = info.text .. TitanUtils_GetGoldText(" (" .. which_bar .. ")")
					end

					local opts_plugin = Titan_Menu.AddSelectorGeneric(owner, info.text,
						function(data)
							return (Titan_G.bars.IsPluginShown(data.p_id) or false)
						end,
						function(data)
							-- frame_str is the bar the user clicked to get the menu...
							local p_bar = TitanBarData[data.f_str].name

							if Titan_G.bars.IsPluginShown(data.p_id) then
								Titan_G.bars.RemovePlugin(data.p_id);
							else
								Titan_G.plugins.AddOnBar(p_bar, data.p_id)
							end
						end,
						{ f_str = bar:GetName(), p_id = id }
					)
					Titan_Menu.AddControlVars(opts_plugin, id)
				end
			end
		else
		end
	end
end

local function GetLayout()
	local res = ""

	-- Defined as part of the Edit Mode frame
	--../Blizzard_EditMode/Shared/EditModeManager.lua
	local EMM = EditModeManagerFrame
	local layout = EMM:GetActiveLayoutInfo()
	if layout then
		res = layout.layoutName
	else
		res = "Layout?"
	end

	return res
end

---Generate and display right click menu options for user.
---@param owner table Plugin frame
---@param rootDescription table Menu context root
local function GeneratorFunction(owner, rootDescription)
	local bar = owner
	local id = owner.registry.id
	local root = rootDescription -- menu widget to start with

	Titan_Menu.AddText(root, L["TITAN_PANEL_MENU_PLUGINS"])
	do -- plugins under category
		-- Get virtual height in pixels
		local scroll_hgt = math.floor(GetScreenHeight() * .6) -- virtual height in pixels
		---@diagnostic disable-next-line: assign-type-mismatch, param-type-mismatch
		for index, id in pairs(L["TITAN_PANEL_MENU_CATEGORIES"]) do
			local cat = TITAN_PANEL_BUTTONS_PLUGIN_CATEGORY[index]
			local cat_locale = L["TITAN_PANEL_MENU_CATEGORIES"][index]
			local opts_plugins = Titan_Menu.AddButton(root, cat_locale)
			Titan_Menu.SetScroll(opts_plugins, scroll_hgt) -- in case menu height is larger than screen / window
			AddPlugin(opts_plugins, bar, cat) -- if same category
		end
	end

	Titan_Menu.AddDivider(root)

	-----------------
	-- Bars - Show / Hide
	local opts_bars = Titan_Menu.AddButton(root, L["TITAN_PANEL_MENU_OPTIONS_BARS"])
	do
		-- sort the bar data by their intended order
		local bar_list = {}
		for _, v in pairs(TitanBarData) do
			bar_list[v.order] = v
		end
		table.sort(bar_list, function(a, b)
			return a.order < b.order
		end)

		for idx = 1, #bar_list do
			local v = bar_list[idx] -- process this bar
			local name = v.locale_name

			Titan_Menu.AddSelectorGeneric(opts_bars, name,
				function(data)
					return TitanBarDataVars[data.f_str].show
				end,
				function(data)
					TitanBarDataVars[data.f_str].show = not TitanBarDataVars[data.f_str].show
					Titan_G.bars.DisplayBarsWanted(data.f_str ..
						" right click menu " .. tostring(TitanBarDataVars[data.f_str].show))
				end,
				{ f_str = v.frame_name }
			)
		end
	end

	Titan_Menu.AddDivider(root)
	-- Config - open the Titan options screen
	Titan_Menu.AddCommand(root, id, L["TITAN_PANEL_MENU_CONFIGURATION"],
		function()
			Titan_G.config.OpenConfig("Titan menu")
		end
	)

	Titan_Menu.AddDivider(root)
		local lay_out = GetLayout()
		Titan_Menu.AddCommand(root, id, HUD_EDIT_MODE_MENU..": "..lay_out,
			function()
				ShowUIPanel(EditModeManagerFrame)
			end
	)

	Titan_Menu.AddDivider(root)
	-----------------
	-- Profiles
	Titan_Menu.AddCommand(root, id, L["TITAN_PANEL_MENU_PROFILES"] .. " " .. L["TITAN_PANEL_MENU_CONFIGURATION"],
		function()
			Titan_G.config.Update("init")
			AceConfigDialog:Open("Titan Panel Addon Profiles")
		end
	)

	local res = Titan_G.vars.GetProfile(Titan_G.utils.GetPlayer())
	Titan_Menu.AddText(root, res.cname)

	Titan_Menu.AddDivider(root)

	Titan_Menu.AddCommand(root, id, L["TITAN_PANEL_MENU_HELP"],
		function()
			Titan_G.config.Update("init")
			AceConfigDialog:Open("Titan Panel Help List")
		end
	)

	Titan_Menu.AddDivider(root)

	-----------------
	-- Hide this bar
	local frame_str = owner:GetName()
	Titan_Menu.AddCommand(root, id, (HIDE or "Hide"),
		function(frame_bar)
			TitanBarDataVars[frame_bar].show = not TitanBarDataVars[frame_bar].show
			Titan_G.bars.DisplayBarsWanted(frame_bar .. " user clicked Hide")
		end,
		frame_str
	)
end
--
--==========================
-- Routines to handle creation of Titan bars
--

---Create a Titan bar that can show plugins.
---@param frame_str string Name of frame to create
---@param short_name string Short localized name of bar
function Titan_G.bars.CreateBar(frame_str, short_name)
	local this_bar = frame_str
	local a_bar = CreateFrame("Button", this_bar, UIParent, "Titan_Bar__Display_Template")

	local bar_data = TitanBarData[this_bar]

	-- ======
	-- Scripts
	a_bar:SetScript("OnEnter", function(self) Titan_G.bars.OnEnter(self) end)
	a_bar:SetScript("OnLeave", function(self) Titan_G.bars.OnLeave(self) end)
	a_bar:SetFrameStrata("DIALOG")

	if bar_data.user_move then
		a_bar:SetMovable(true)
		a_bar:SetResizable(true)
		a_bar:EnableMouse(true)
		a_bar:RegisterForDrag("LeftButton")
		a_bar:SetScript("OnDragStart", OnMoveStart)
		a_bar:SetScript("OnDragStop", OnMovingStop)
		a_bar:SetScript("OnMouseWheel", OnMouseWheel)
	else
		-- Static full width bar
	end

	-- Jan 2026 Put .registry on each bar for the new menu scheme
	-- A bit funky but the right click looks into .registry.menuContextFunction
	-- off the frame for the menu function in the new scheme
	local notes = ""
		.. "Titan ONLY for menu, possibly more.\n"
	a_bar.registry = {
		id = short_name,
		category = Titan_G.categories.TitanBar,
		version = TITAN_VERSION,
		menuText = bar_data.locale_name,
		--menuTextFunction = CreateMenu, -- OLD
		menuContextFunction = GeneratorFunction, -- NEW scheme
		--tooltipTitle = "",
		--tooltipTextFunction = GetTooltipText,
		--buttonTextFunction = FindGold,
		icon = "Interface\\AddOns\\Titan\\Artwork\\Titan",
		iconWidth = 16,
		notes = notes,
		controlVariables = {
			ShowIcon = false,
			ShowLabelText = false,
			ShowRegularText = false,
			ShowColoredText = false,
			DisplayOnRightSide = false,
		},
		savedVariables = {
			ShowIcon = true,
			ShowLabelText = false,
			ShowColoredText = true,
			DisplayOnRightSide = false,
		}
	};

	-- ======
	-- Bounds only effective on Short bars for now
	-- Min : No smaller than the padding & one icon
	-- Max : No wider than the screen
	-- does not seem to work to restrict size automatically...
	local screen = Titan_G.utils.ScreenSize()
	a_bar:SetResizeBounds(TitanBarData[this_bar].plugin_x_offset + 16, Titan_G.bars.HEIGHT, screen.x,
		Titan_G.bars.HEIGHT)
	a_bar:RegisterForClicks("LeftButtonUp", "RightButtonUp");
	a_bar:SetScript("OnClick", function(self, button) Bar_OnClick(self, button) end)

	-- ======
	-- Frame for right clicks
	-- Use the plugin naming scheme for one frame to rule them all
	-- 2024 Feb : Change to match plugin right click menu scheme so one routine can be used.
	TitanPanelRightClickMenu_CreateFrame(this_bar)

	-- ======
	-- Hider for auto hide feature
	local hide_bar_name = Titan_G.bars.HIDER_PRE .. bar_data.name
	if bar_data.hider then
		local hide_bar = CreateFrame("Button", hide_bar_name, UIParent, "TitanPanelBarButtonHiderTemplate")
		hide_bar:SetFrameStrata("DIALOG")

		-- Set script handlers for display
		hide_bar:RegisterForClicks("LeftButtonUp", "RightButtonUp");
		hide_bar:SetScript("OnEnter", function(self) Titan_G.bars.Hider_OnEnter(self) end)
		hide_bar:SetScript("OnLeave", function(self) Titan_G.bars.Hider_OnLeave(self) end)
		hide_bar:SetScript("OnClick", function(self, button) Bar_OnClick(self, button) end)

		hide_bar:SetFrameStrata("BACKGROUND")
		hide_bar:SetSize(screen.x, Titan_G.bars.HEIGHT)
	else
		-- Hider not allowed for this bar
	end
end

--====== deprecated / Unused
--[====[


--]====]
