--[===[ File
This file contains the TitanAmmo plugin used by Forever and old Classic versions
--]===]

--[[ Notes and change history
-- 2026 Nov - Updated when Forever was released; refactored
-- 2024 Jan - Combined Classic Era and Wrath into one version
-- 2019 Aug - reverted and updated for Classic
--
-- This will track the count of ammo (bows and guns) or thrown (knives) equipped.
-- Ammo is placed in the 'ammo' slot where Blizzard counts ALL of that *type of ammo*,
-- regardless of where it is in your bags.
-- Thrown is placed in the actual weapon slot where Blizzard counts ALL of that *type of thrown*.
--]]

-- ******************************** Constants *******************************
local _G            = getfenv(0);
local TITAN_AMMO_ID = "Ammo";
local TITAN_BUTTON  = "TitanPanel" .. TITAN_AMMO_ID .. "Button"

local ICON_DEF      = 132387 -- snowball

local SHOOT_STACK   = 200
local ARROW_STACK   = 200
local THROW_STACK   = 200

local LIM_GOOD      = 2
local LIM_OK        = 1.5
local LIM_BAD       = .5

-- Use ammo stack and threshold limits above to calc colored text
-- 2026 Nov - simplify to thresholds for 'count' versus 'duration'; keep others for reference
-- just incase we need to revert
local THRESHOLD     = {
	["INVTYPE_RANGEDRIGHT"] = {
		Values = { SHOOT_STACK * LIM_BAD, SHOOT_STACK * LIM_OK, SHOOT_STACK * LIM_GOOD }, -- 100,150,400
		Colors = { RED_FONT_COLOR, ORANGE_FONT_COLOR, YELLOW_FONT_COLOR, GREEN_FONT_COLOR },
	},
	["INVTYPE_RANGED"] = {
		Values = { ARROW_STACK * LIM_BAD, ARROW_STACK * LIM_OK, ARROW_STACK * LIM_GOOD }, -- 100,150,400
		Colors = { RED_FONT_COLOR, ORANGE_FONT_COLOR, YELLOW_FONT_COLOR, GREEN_FONT_COLOR },
	},
	["INVTYPE_THROWN"] = {
		Values = { THROW_STACK / 10, THROW_STACK / 4, THROW_STACK / 2 }, -- 20, 50, 100
		Colors = { RED_FONT_COLOR, ORANGE_FONT_COLOR, YELLOW_FONT_COLOR, GREEN_FONT_COLOR },
	},
	["INVTYPE_COUNT"] = { -- 100,150,400 : same stack size for all types
		Values = { SHOOT_STACK * LIM_BAD, SHOOT_STACK * LIM_OK, SHOOT_STACK * LIM_GOOD },
		Colors = { RED_FONT_COLOR, ORANGE_FONT_COLOR, YELLOW_FONT_COLOR, GREEN_FONT_COLOR },
	},
	["INVTYPE_DURATION"] = {
		Values = { 20, 50, 75 }, -- % durability
		Colors = { RED_FONT_COLOR, ORANGE_FONT_COLOR, YELLOW_FONT_COLOR, GREEN_FONT_COLOR },
	},
};

-- ******************************** Variables *******************************
local ammoSlotID    = GetInventorySlotInfo("AMMOSLOT")
local rangedSlotID  = GetInventorySlotInfo("RANGEDSLOT")

-- Info to show on the plugin
local display       = {
	ammo_count    = 0,
	ammo_type     = "",
	ammo_name     = "", -- L["TITAN_AMMO_BUTTON_NOAMMO"]
	weapon        = "",
	weapon_type   = "",
	mismatch      = false,
	mismatch_text = "",
}

local L             = LibStub("AceLocale-3.0"):GetLocale("Titan", true)

local debug_flow    = false

-- ******************************** Functions *******************************

---Debug message to chat frame
---@param Message string
local function debug_msg(Message)
	local msg = ""
	local stamp = date("%H:%M:%S") -- date("%m/%d/%y %H:%M:%S")
	local milli = GetTime()     -- seconds with millisecond precision (float)
	local milli_str = string.format("%0.2F", milli - math.modf(milli))
	msg = msg .. TitanUtils_GetGoldText(stamp .. milli_str .. " " .. TITAN_AMMO_ID .. ": ")
	msg = msg .. TitanUtils_GetGreenText(Message)
	DEFAULT_CHAT_FRAME:AddMessage(msg)
	--		DEFAULT_CHAT_FRAME:AddMessage(TITAN_AMMO_ID..": " .. Message, 1.00, 0.49, 0.04)
end

---Init display(table) used by Update and Tooltip
local function ClrAmmoInfo()
	display.ammo_count    = 0;
	display.label         = L["TITAN_AMMO_BUTTON_NOAMMO"]
	display.ammo_name     = ""
	display.weapon        = ""
	display.weapon_type   = ""
	display.mismatch      = false
	display.mismatch_text = ""
end

---Is player class one that uses ammo?
---@return boolean
local function IsAmmoClass()
	local class = select(2, UnitClass("player"))
	local res = false
	if class == "ROGUE"
		or class == "WARRIOR"
		or class == "HUNTER"
	then
		res = true
	else
		res = false
	end
	return res
end

local valid = {}
valid[2] = {}; valid[2][2] = true    -- bow with arrows
valid[3] = {}; valid[3][3] = true    -- gun with bullets
valid[16] = {}; valid[16][16] = true -- thrown
valid[18] = {}; valid[18][2] = true  -- crossbow with arrows

local function IsAmmoMismatched(weap_type, ammo_type)
	local res = false
--	local check = valid[weap_type][ammo_type]
	if valid[weap_type] and valid[weap_type][ammo_type]
	then
		res = true
	else
		res = false
	end
	return res
end

---Get info on given slot location
---@param slot number ranged or ammo
---@return table item_info
local function GetItem(slot)
	local res = {}
	local item = GetInventoryItemID("player", slot)

	--[[ https://warcraft.wiki.gg/wiki/API:C_Item.GetItemInfo
	We will take advantage of Lua syntax to return a table versus a list multiple parameters.

	As of 2026 Nov :
	itemName, itemLink, itemQuality, itemLevel, itemMinLevel, itemType,
	itemSubType, itemStackCount, itemEquipLoc, itemTexture, sellPrice,
	classID, subclassID, bindType, expansionID, setID, isCraftingReagent,
	itemDescription = C_Item.GetItemInfo(itemInfo)
	--]]
	local t       = { C_Item.GetItemInfo(item) }

	-- Translate needed values from API to local. This MUST adhere to the API !!!
	res.item_name = t[1] -- itemName : localized
	res.sub_type  = t[7] -- itemSubType : localized
	res.slot_loc  = t[9] -- itemEquipLoc
	res.item_tex  = t[10] -- itemTexture
	res.sub_class = t[13] -- subclassID

	return res
end

---Get the ammo type and set display(table) with info to use in Update and Tooltip
local function GetAmmoCount()
	local weapon_name = ""
	local weapon_type = 0
	local weapon_class = 0
	local ammo_thresh = ""
	local ammo_tex = 0
	local ammo_id = 0
	local mis = false
	local mist = ""
	local ammo_name = ""
	local ammo_count = 0
	local label = ""
	local text = ""
	local tool_tip = ""
	local slot_id = 0

	ClrAmmoInfo()

	-- See if anything is in ranged weapon slot; not all classes have a ranged slot
	local weap = GetInventoryItemID("player", rangedSlotID)
	if weap == nil then
		-- nothing in slot
		label = L["TITAN_AMMO_BUTTON_NOAMMO"]
	else
		local plug   = Titan_G.plugins.Get(TITAN_AMMO_ID)

		-- get ranged weapon info
		local weapon = GetItem(rangedSlotID)
		weapon_name  = weapon.item_name
		weapon_type  = weapon.sub_class
		weapon_class = weapon.sub_class
		ammo_name    = ""
		ammo_count   = 0
		tool_tip = ""
			.. tostring(weapon_name)

		-- set ammo name and count
		if (weapon_class == 16) -- Thrown
		then
			-- ranged weapon IS the ammo
			label   = L["TITAN_AMMO_BUTTON_LABEL_THROWN"]
			slot_id = rangedSlotID
		elseif (weapon_class == 3) -- Gun
			or (weapon_class == 2) -- Bow
			or (weapon_class == 18) -- Crossbow
		then
			label = L["TITAN_AMMO_BUTTON_LABEL_AMMO"]
			slot_id = ammoSlotID
		tool_tip = tool_tip
			.. "\n" .. tostring(ammo_name) .. ""

			-- Ranged slot is weapon, need to go one 'deeper' for ammo
			weapon = GetItem(ammoSlotID)
		else
			ammo_name = UNKNOWN
			ammo_count = 0
			-- no mismatch
		end

		ammo_name = weapon.item_name
		ammo_tex = weapon.item_tex
		ammo_id = weapon.sub_class

		if ammo_name == nil
			or ammo_tex == nil then
			ammo_count = 0
		else
			local minimum, maximum = GetInventoryItemDurability(slot_id)
			if minimum == nil then -- get count
				ammo_thresh = "INVTYPE_COUNT"
				ammo_count = GetInventoryItemCount("player", slot_id) or ammo_count
				text = format(L["TITAN_AMMO_FORMAT"], ammo_count);
			else -- get durability
				ammo_thresh = "INVTYPE_DURATION"
				ammo_count = ((maximum > 0 and floor(minimum / maximum * 100)) or 100)
				text = format(L["TITAN_AMMO_FORMAT"] .. "%%", ammo_count);
			end
		end
		if Titan_G.plugins.GetVar(TITAN_AMMO_ID, "ShowAmmoName") and ammo_name ~= "" then
			text = text .. "|cffffff9a" .. " (" .. ammo_name .. ")" .. "|r"
		end
		if IsAmmoMismatched(weapon_type, ammo_id)
		then
			mis = false
			mist = ""
		else
			mis = true
			mist = ""
				.. tostring(weapon_name)
				.. " <> "
				.. tostring(ammo_name)
			mist = TitanUtils_GetRedText(mist)
		end
		-- Set plugin icon to what is in slot; default if nothing
		if ammo_tex == nil then
			plug.icon = ICON_DEF
		else
			plug.icon = ammo_tex
		end
		--[[
local msg =
	"GII-ammo"
	.." ("..tostring(itemType)..""
	.." "..tostring(classID)..""
	.." "..tostring(subclassID) ..")"
	.." ? ("..tostring(ammoID)..""
	.." "..tostring(subammoID)..")"
	.." "..tostring(mis)..""
debug_msg(msg)
local msg =
	"GII-ammo > "
	.." '"..tostring(label).."'"
	.." '"..tostring(text).."'"
debug_msg(msg)
--]]
	end

	-- Set variables
	display.label = label
	display.text = text
	display.tool_tip = tool_tip
	display.weapon = weapon_name
	display.weapon_type = weapon_type
	display.ammo_name = ammo_name
	display.ammo_count = ammo_count
	display.ammo_thresh = ammo_thresh
	display.weapon_class = weapon_class
	display.mismatch = mis
	display.mismatch_text = mist

	if debug_flow then
		local msg =
			"Count"
			.. " '" .. tostring(weapon_type) .. "'"
			.. " '" .. tostring(weapon_name) .. "'"
		debug_msg(msg)
	else
		-- not requested
	end
end

---Handle registered events
---@param action string
---@param reason string
local function Events(action, reason)
	if action == "register" then
		TitanPanelAmmoButton:RegisterEvent("UNIT_INVENTORY_CHANGED")
		TitanPanelAmmoButton:RegisterEvent("MERCHANT_CLOSED")
	elseif action == "unregister" then
		TitanPanelAmmoButton:UnregisterEvent("UNIT_INVENTORY_CHANGED")
		TitanPanelAmmoButton:UnregisterEvent("MERCHANT_CLOSED")
	else
		-- action unknown ???
	end

	if debug_flow then
		local msg =
			"Events"
			.. " " .. tostring(reason) .. ""
		debug_msg(msg)
	else
		-- not requested
	end
end

---Create display  text for plugin
---@param id string Plugin ID
---@return string label for plugin
---@return string ptext for plugin
function GetButtonText(id)
	local labelText, ammoText, ammoRichText, color;

	labelText = display.label
	ammoText = display.text or ""

	if display.mismatch then
		ammoRichText = tostring(display.mismatch_text)
	elseif (Titan_G.plugins.GetVar(TITAN_AMMO_ID, "ShowColoredText")) then
		color = TitanUtils_GetThresholdColor(THRESHOLD[display.ammo_thresh], display.ammo_count);
		ammoRichText = TitanUtils_GetColoredText(ammoText, color);
	else
		ammoRichText = TitanUtils_GetHighlightText(ammoText);
	end

	if debug_flow then
		local msg =
			"Btn_Text"
			.. " '" .. tostring(display.weapon_type) .. "'"
			.. " '" .. tostring(ammoRichText) .. "'"
		debug_msg(msg)
	else
		-- not requested
	end

	return labelText, ammoRichText;
end

---Create the plugin R click menu
function CreateMenu()
	TitanPanelRightClickMenu_AddTitle(Titan_G.plugins.info[TITAN_AMMO_ID].menuText);

	local info = {};
	info.text = L["TITAN_AMMO_BULLET_NAME"];
	info.func = function()
		TitanPanelRightClickMenu_ToggleVar({ TITAN_AMMO_ID, "ShowAmmoName" })
		GetAmmoCount()
		Titan_G.plugins.UpdateButton(TITAN_AMMO_ID);
	end
	info.checked = TitanUtils_Ternary(Titan_G.plugins.GetVar(TITAN_AMMO_ID, "ShowAmmoName"), 1, nil);
	TitanPanelRightClickMenu_AddButton(info, TitanPanelRightClickMenu_GetDropdownLevel())
	TitanPanelRightClickMenu_AddSpacer();

	info = {};
	TitanPanelRightClickMenu_AddToggleIcon(TITAN_AMMO_ID);
	TitanPanelRightClickMenu_AddToggleLabelText(TITAN_AMMO_ID);
	TitanPanelRightClickMenu_AddToggleColoredText(TITAN_AMMO_ID);

	TitanPanelRightClickMenu_AddToggleRightSide(TITAN_AMMO_ID);
	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelRightClickMenu_AddCommand(L["TITAN_PANEL_MENU_HIDE"], TITAN_AMMO_ID, Titan_G.constants.MENU_FUNC_HIDE);
end

---Create the plugin tooltip
---@return string
local function GetTooltipText()
	local txt = display.tool_tip
	if display.mismatch then
		txt = txt
			.. "\n\n"
			.. tostring(display.mismatch_text) .. ""
	else
		-- weapon and projectile match
	end
	return txt
end

---Registers the plugin upon it loading
---@param self any Plugin frame
local function OnLoad(self)
	self.registry = {
		id = TITAN_AMMO_ID,
		--builtIn = 1,
		category = "Built-ins",
		version = TITAN_VERSION,
		menuText = L["TITAN_AMMO_MENU_TEXT"],
		menuTextFunction = CreateMenu,
		buttonTextFunction = GetButtonText,
		tooltipTitle = L["TITAN_AMMO_TOOLTIP"],
		tooltipTextFunction = GetTooltipText,
		icon = ICON_DEF, --"Interface\\AddOns\\TitanAmmo\\TitanClassicThrown",
		iconWidth = 16,
		controlVariables = {
			ShowIcon = true,
			ShowLabelText = true,
			ShowRegularText = false,
			ShowColoredText = true,
			DisplayOnRightSide = true
		},
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = 1,
			ShowColoredText = 1,
			ShowAmmoName = false,
			DisplayOnRightSide = false,
		}
	}
end

---Prep the plugin for display on Titan bar
---@param self any Plugin frame
local function OnShow(self)
	ClrAmmoInfo()

	if IsAmmoClass() then
		-- No need to start events and consume cycles if no ammo
		GetAmmoCount()

		Events("register", "OnShow")
	else
		-- Just set the default text on button
		-- for a class w/o ammo
	end

	Titan_G.plugins.UpdateButton(TITAN_AMMO_ID);
end

---Prep the plugin for removal from Titan bar
---@param self any Plugin frame
local function OnHide(self)
	ClrAmmoInfo()

	Events("unregister", "OnHide")
end

---Update the plugin icon and text
local function UpdateDisplay()
	GetAmmoCount()

	Titan_G.plugins.UpdateButton(TITAN_AMMO_ID);
end


---React to registered events
---@param self any Plugin frame
---@param event string WoW registered event
---@param arg1 any
---@param arg2 any
---@param ... unknown
local function OnEvent(self, event, arg1, arg2, ...)
	if event == "PLAYER_ENTERING_WORLD" then
		if arg1 == true then -- login
			-- EnterWorld()
		end
		if arg2 == true then -- reload / zoning
			UpdateDisplay()
		end
	elseif event == "UNIT_INVENTORY_CHANGED" then
		if arg1 == "player" then
			UpdateDisplay()
		end
	elseif event == "MERCHANT_CLOSED" then
		UpdateDisplay()
	end
end

--- Create needed frames
local function Create_Frames()
	if _G[TITAN_BUTTON] then
		return -- if already created
	end

	-- general container frame
	local f = CreateFrame("Frame", nil, UIParent)
	--	f:Hide()

	-- Titan plugin button
	local window = CreateFrame("Button", TITAN_BUTTON, f, "TitanPanelComboTemplate")
	window:SetFrameStrata("FULLSCREEN")
	-- Using SetScript("OnLoad",   does not work
	OnLoad(window);

	window:SetScript("OnEvent", function(self, event, ...)
		OnEvent(self, event, ...)
	end)
	window:SetScript("OnShow", function(self, button)
		OnShow(self)
	end)
	window:SetScript("OnHide", function(self, button)
		OnHide(self)
	end)
end

Create_Frames() -- do the work
