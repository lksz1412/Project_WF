local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals

--[[ Core ]]
local Aurora = private.Aurora
local Base = Aurora.Base
local Hook, Skin = Aurora.Hook, Aurora.Skin
local Color = Aurora.Color
-- local Util = Aurora.Util

do --[[ AddOns\Blizzard_TokenUI\Blizzard_TokenUI.xml ]]
    function Skin.TokenButtonTemplate(Button)
        local stripe = Button.Stripe
        stripe:SetPoint("TOPLEFT", 1, 1)
        stripe:SetPoint("BOTTOMRIGHT", -1, -1)

        Button.Icon.bg = Base.CropIcon(Button.Icon, Button)

        Button.CategoryLeft:SetAlpha(0)
        Button.CategoryRight:SetAlpha(0)
        Button.CategoryMiddle:SetAlpha(0)
        Skin.FrameTypeButton(Button)

        Button.ExpandIcon:SetTexture("")
        local minus = Button:CreateTexture(nil, "ARTWORK")
        minus:SetSize(7, 1)
        minus:SetPoint("LEFT", 8, 0)
        minus:SetColorTexture(1, 1, 1) -- static: not a theme color
        minus:Hide()
        Button._auroraMinus = minus

        local plus = Button:CreateTexture(nil, "ARTWORK")
        plus:SetSize(1, 7)
        plus:SetPoint("LEFT", 11, 0)
        plus:SetColorTexture(1, 1, 1) -- static: not a theme color
        plus:Hide()
        Button._auroraPlus = plus
        if not private.IsSkinned(Button) then
            private.SetSkinned(Button, true)
        end
    end
    function Skin.BackpackTokenTemplate(Button)
        Base.CropIcon(Button.Icon, Button)
        Button.Count:SetPoint("RIGHT", Button.Icon, "LEFT", -2, 0)
    end

    local function SecureUpdateCollapse(texture, atlas)
        if not atlas then
            local parent = texture:GetParent()
            if parent:IsCollapsed() then
                texture:SetAtlas('Soulbinds_Collection_CategoryHeader_Expand')
            else
                texture:SetAtlas('Soulbinds_Collection_CategoryHeader_Collapse')
            end
        end
    end
    local function SecureUpdateCurrencyScrollBoxEntries(entry)
        if not private.IsSkinned(entry) then
            if entry.Right then
                Base.SetBackdrop(entry, Color.button)
                SecureUpdateCollapse(entry.Right)
                SecureUpdateCollapse(entry.HighlightRight)
                _G.hooksecurefunc(entry.Right, 'SetAtlas', SecureUpdateCollapse)
                _G.hooksecurefunc(entry.HighlightRight, 'SetAtlas', SecureUpdateCollapse)
            end
            local icon = entry.Content and entry.Content.CurrencyIcon
            if icon then
                Base.CropIcon(icon)
            end
            private.SetSkinned(entry, true)
        end
    end
    function Hook.UpdateCurrencyScrollBox(frame)
        frame:ForEachFrame(SecureUpdateCurrencyScrollBoxEntries)
    end
end

function private.FrameXML.Blizzard_TokenUI()
    local TokenFrame = _G.TokenFrame
    Skin.WowScrollBoxList(TokenFrame.ScrollBox)
    _G.hooksecurefunc(TokenFrame.ScrollBox, 'Update', Hook.UpdateCurrencyScrollBox)
    Hook.UpdateCurrencyScrollBox(TokenFrame.ScrollBox)

    -- WoW Forever's currency tab is a different panel: Camelot's CharacterFrame
    -- inherits PortraitFrameBaseTemplate rather than ButtonFrameTemplate, so it
    -- has no Inset, and Camelot anchors the ScrollBox to CharacterFrameLeftPaneHost
    -- itself. Leave Blizzard's own anchoring alone when there is no Inset to
    -- anchor to. Camelot also drops the filter dropdown and the transfer log
    -- toggle, and replaces TokenFramePopup with an inline TokenDetailFrame.
    local characterFrameInset = _G.CharacterFrame and _G.CharacterFrame.Inset
    if characterFrameInset then
        TokenFrame.ScrollBox:SetPoint("TOPLEFT", characterFrameInset, 4, -35)
    end

    if TokenFrame.filterDropdown then
        Skin.DropdownButton(TokenFrame.filterDropdown)
        TokenFrame.filterDropdown:ClearAllPoints()
        TokenFrame.filterDropdown:SetPoint("TOPLEFT", 18,  -30)
    end

    if TokenFrame.CurrencyTransferLogToggleButton then
        TokenFrame.CurrencyTransferLogToggleButton:SetPoint("TOPRIGHT", -10, -30)
    end

    -- WoW Forever (Camelot Blizzard_TokenUI.xml) has no TokenFramePopup: the
    -- currency options popout and the transfer flow with it.
    local TokenFramePopup = _G.TokenFramePopup
    if TokenFramePopup then
        Skin.SecureDialogBorderTemplate(TokenFramePopup.Border)
        TokenFramePopup:SetSize(175, 90)
        local titleText = TokenFramePopup.Title
        titleText:ClearAllPoints()
        titleText:SetPoint("TOPLEFT")
        titleText:SetPoint("BOTTOMRIGHT", TokenFramePopup, "TOPRIGHT", 0, -private.FRAME_TITLE_HEIGHT)
        Skin.UICheckButtonTemplate(TokenFramePopup.InactiveCheckbox)
        TokenFramePopup.InactiveCheckbox:SetPoint("TOPLEFT", TokenFramePopup, 24, -26)
        Skin.UICheckButtonTemplate(TokenFramePopup.BackpackCheckbox)
        TokenFramePopup.BackpackCheckbox:SetPoint("TOPLEFT", TokenFramePopup.InactiveCheckbox, "BOTTOMLEFT", 0, -8)
        Skin.UIPanelButtonTemplate(TokenFramePopup.CurrencyTransferToggleButton)
        TokenFramePopup.CurrencyTransferToggleButton:SetPoint("TOPLEFT", TokenFramePopup.BackpackCheckbox, "BOTTOMLEFT", 0, -8)
        Skin.UIPanelCloseButton(TokenFramePopup["$parent.CloseButton"])
    end

    -- Camelot replaces the popup with TokenDetailFrame, a
    -- CharacterFrameSidePaneTemplate that slides into the character frame's
    -- right pane -- the same shape as its ReputationDetailFrame and
    -- SkillDetailFrame. No border, no title, no close button, and nothing to
    -- re-anchor: the pane owns its own geometry.
    local TokenDetailFrame = _G.TokenDetailFrame
    if TokenDetailFrame then
        -- Both are bare CheckButtons carrying checkbox-minimal /
        -- checkmark-minimal atlases, byte-for-byte the shape
        -- Skin.UICheckButtonTemplate already handles on the reputation pane.
        if TokenDetailFrame.InactiveCheckbox then
            Skin.UICheckButtonTemplate(TokenDetailFrame.InactiveCheckbox)
        end
        if TokenDetailFrame.BackpackCheckbox then
            Skin.UICheckButtonTemplate(TokenDetailFrame.BackpackCheckbox)
        end
        -- Pooled category/icon rows, shared with every other Camelot side pane.
        -- Registered by Blizzard_UIPanels_Game\Camelot\CharacterFrame.lua, which
        -- is not LoadOnDemand, so it is always defined before this runs.
        if Skin.CharacterFrameSidePaneTemplate then
            Skin.CharacterFrameSidePaneTemplate(TokenDetailFrame)
        end

        if TokenDetailFrame.CurrencyTransferToggleButton then
            Skin.UIPanelButtonTemplate(TokenDetailFrame.CurrencyTransferToggleButton)
        end
    end

    local CurrencyTransferMenu = _G.CurrencyTransferMenu
    Skin.DialogBorderNoCenterTemplate(CurrencyTransferMenu.NineSlice)
    Skin.UIPanelButtonTemplate(CurrencyTransferMenu.Content.AmountSelector.MaxQuantityButton)
    Skin.InputBoxTemplate(CurrencyTransferMenu.Content.AmountSelector.InputBox)
    Skin.UIPanelButtonTemplate(CurrencyTransferMenu.Content.ConfirmButton)
    Skin.UIPanelButtonTemplate(CurrencyTransferMenu.Content.CancelButton)
    Skin.UIPanelCloseButton(CurrencyTransferMenu.CloseButton)
    Skin.DropdownButton(CurrencyTransferMenu.Content.SourceSelector.Dropdown)
end
