local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals

--[[ Core ]]
local Aurora = private.Aurora
local Skin = Aurora.Skin
local Color, Util = Aurora.Color, Aurora.Util

--do --[[ FrameXML\CharacterFrame.lua ]]
--end

do --[[ FrameXML\CharacterFrame.xml ]]
    function Skin.CharacterStatFrameCategoryTemplate(Button)
        local bg = Button.Background
        bg:SetTexture([[Interface\LFGFrame\UI-LFG-SEPARATOR]])
        bg:SetTexCoord(0, 0.6640625, 0, 0.3125)
        bg:ClearAllPoints()
        bg:SetPoint("CENTER", 0, -5)
        bg:SetSize(210, 30)

        local r, g, b = Color.highlight:GetRGB()
        bg:SetVertexColor(r * 0.7, g * 0.7, b * 0.7)
    end
    function Skin.CharacterStatFrameTemplate(Button)
        local bg = Button.Background
        bg:ClearAllPoints()
        bg:SetPoint("TOPLEFT")
        bg:SetPoint("BOTTOMRIGHT")
        bg:SetColorTexture(1, 1, 1, 0.2) -- static: not a theme color
    end
    function Skin.CharacterFrameTabTemplate(Button)
        Skin.PanelTabButtonTemplate(Button)
    end
end

function private.FrameXML.CharacterFrame()
    local CharacterFrame = _G.CharacterFrame
    Skin.ButtonFrameTemplate(CharacterFrame)

    CharacterFrame.TitleContainer:SetPoint("TOPRIGHT", CharacterFrame.Inset, "RIGHT")
    CharacterFrame.Inset:SetPoint("TOPLEFT", 4, -private.FRAME_TITLE_HEIGHT)
    CharacterFrame.Inset:SetPoint("BOTTOMRIGHT", CharacterFrame, "BOTTOMLEFT", _G.PANEL_DEFAULT_WIDTH + _G.PANEL_INSET_RIGHT_OFFSET, 4)

    Skin.CharacterFrameTabTemplate(_G.CharacterFrameTab1)
    Skin.CharacterFrameTabTemplate(_G.CharacterFrameTab2)
    Skin.CharacterFrameTabTemplate(_G.CharacterFrameTab3)
    Util.PositionRelative("TOPLEFT", CharacterFrame, "BOTTOMLEFT", 20, -1, 1, "Right", {
        _G.CharacterFrameTab1,
        _G.CharacterFrameTab2,
        _G.CharacterFrameTab3,
    })

    Skin.InsetFrameTemplate(CharacterFrame.InsetRight)
    CharacterFrame.InsetRight:SetPoint("TOPLEFT", CharacterFrame.Inset, "TOPRIGHT", 1, -20)

    local CharacterStatsPane = _G.CharacterStatsPane
    _G.hooksecurefunc("PaperDollFrame_SetStat", function(statFrame)
        if statFrame and statFrame.Background then
            Skin.CharacterStatFrameTemplate(statFrame)
        end
    end)

    local ClassBackground = CharacterStatsPane.ClassBackground
    local atlas = "talents-animations-class-"..private.charClass.token
    local info = _G.C_Texture.GetAtlasInfo(atlas)
    if info then
        -- C_Texture.GetAtlasInfo("talents-animations-class-warrior")
        -- C_Texture.GetAtlasInfo("legionmission-landingpage-background-EVOKER")
        ClassBackground:ClearAllPoints()
        ClassBackground:SetPoint("CENTER")
        ClassBackground:SetSize(_G.Round(info.width * 0.7), _G.Round(info.height * 0.7))
        ClassBackground:SetAtlas(atlas)
        ClassBackground:SetDesaturated(true)
        ClassBackground:SetAlpha(0.4)
    end


    CharacterStatsPane.ItemLevelFrame.Value:SetFontObject("SystemFont_Shadow_Huge2")
    CharacterStatsPane.ItemLevelFrame.Value:SetShadowOffset(0, 0)
    CharacterStatsPane.ItemLevelFrame.Background:Hide()
    Skin.CharacterStatFrameCategoryTemplate(CharacterStatsPane.ItemLevelCategory)
    Skin.CharacterStatFrameCategoryTemplate(CharacterStatsPane.AttributesCategory)
    Skin.CharacterStatFrameCategoryTemplate(CharacterStatsPane.EnhancementsCategory)
end
