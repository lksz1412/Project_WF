local _, private = ...
if private.shouldSkip() then return end

--[[ Lua Globals ]]
-- luacheck: globals

--[[ Core ]]
local Aurora = private.Aurora
local Skin = Aurora.Skin

--do --[[ FrameXML\SharedBasicControls.lua ]]
--end

do --[[ FrameXML\SharedBasicControls.xml ]]
    function Skin.UIPanelDialogTemplate(Frame)
        local name = Frame:GetName()

        _G[name.."TopLeft"]:Hide()
        _G[name.."TopRight"]:Hide()
        _G[name.."Top"]:Hide()
        _G[name.."BottomLeft"]:Hide()
        _G[name.."BottomRight"]:Hide()
        _G[name.."Bottom"]:Hide()
        _G[name.."Left"]:Hide()
        _G[name.."Right"]:Hide()

        Skin.FrameTypeFrame(Frame)

        Frame.Title:ClearAllPoints()
        Frame.Title:SetPoint("TOPLEFT")
        Frame.Title:SetPoint("BOTTOMRIGHT", Frame, "TOPRIGHT", 0, -private.FRAME_TITLE_HEIGHT)

        local titleBG = _G[name.."TitleBG"]
        titleBG:SetAllPoints(Frame.Title)
        titleBG:Hide()

        _G[name.."DialogBG"]:Hide()

        Skin.UIPanelCloseButton(_G[name.."Close"])
    end
end

function private.SharedXML.SharedBasicControls()
    local ScriptErrorsFrame = _G.ScriptErrorsFrame

    Skin.UIPanelDialogTemplate(ScriptErrorsFrame)
    ScriptErrorsFrame:SetSize(600, 400)
    ScriptErrorsFrame:SetScale(_G.UIParent:GetScale())

    Skin.ScrollFrameTemplate(ScriptErrorsFrame.ScrollFrame)
    ScriptErrorsFrame.ScrollFrame:SetPoint("BOTTOMRIGHT", -26, 34)
    ScriptErrorsFrame.ScrollFrame.Text:SetPoint("BOTTOMRIGHT", -26, 34)

    Skin.UIPanelButtonTemplate(ScriptErrorsFrame.Reload)
    ScriptErrorsFrame.Reload:SetPoint("BOTTOMLEFT", 5, 5)

    Skin.NavButtonPrevious(ScriptErrorsFrame.PreviousError)
    Skin.NavButtonNext(ScriptErrorsFrame.NextError)

    -- WoW Forever renames the dialog's dismiss button parentKey from Close to
    -- CloseButton in Blizzard_ScriptErrorsFrame.xml.
    local closeButton = ScriptErrorsFrame.Close or ScriptErrorsFrame.CloseButton
    if closeButton then
        Skin.UIPanelButtonTemplate(closeButton)
    end
    ScriptErrorsFrame.ScrollFrame:SetPoint("BOTTOMRIGHT", -5, 5)
end
