﻿## [12.1.5.4] ##
### Fixed ###

  * fix: **guild and community roster names are no longer dimmed.** Blizzard raises the member list's inset above the rows so its border draws over them, and with Aurora's backdrop on it the inset covered every name. It now sits under the list [mainline/forever]
  * fix: **trainer list rows are skinned.** Only the skill step button had the skin, so every row kept Blizzard's dark row plate. Forever's category headers get a flat backdrop [mainline/forever]
  * fix: the divider above an open letter's attachments is hidden. The skin matched it by texture path, but `GetTexture()` returns a file ID, so the match never fired [mainline/forever]
  * fix: the profession window's Create and Create All buttons are skinned to match the template the page uses. On Forever that is `SharedButtonSmallTemplate`, whose red center plate and end caps showed through the old skin [forever]


## [12.1.5.3] ##
### Fixed ###

  * fix: **the PvP scoreboard and match results are skinned on Forever.** Build 70755 gave both frames new layouts, so the old skin failed without an error and left them stock. Forever now has its own skin for them, including the results window's Leave button [forever]
  * fix: **item icons stay cropped.** Forever 70755 resets an item button's texture coordinates on every icon change, which undid Aurora's crop and brought back each icon's built-in border. `Base.KeepIconCrop` re-applies it on bags, vendors, quest rewards and the other item buttons. The 12.1.7 PTR has the same reset, so retail is covered ahead of that patch [mainline/forever]
  * fix: empty slots in combined bags draw the bag's icon inside the slot, cropped, instead of uncropped across the whole button [forever]
  * fix: the gold border on the profession cards' spell buttons is hidden; it drew over the square icons [forever]
  * fix: the swing timer's bar art stays hidden; since 70532 Forever resets its alpha on every swing [forever]
  * fix: reward track cards hide Blizzard's new hover highlight, which brought back the card plate, and light up their border on hover instead [forever]
  * fix: the minimize button on the ready popups fits its 20 px size, where the box was 5 px tall and the dash hung outside it [mainline]

### Changed ###

  * chg: skin manifests regenerated for Forever 1.60.1.70790 [forever]


## [12.1.5.2] ##
### Added ###

  * add: the guild Preferred Play tab (locale and datacenter settings) is skinned and joins the Communities side tabs; its dropdowns and Apply buttons are skinned [forever]
  * add: the new-character keyboard and mouse intro's OK and Skip Tutorial buttons are skinned [mainline/forever]

### Fixed ###

  * fix: **pet battle tooltips stay skinned on Forever 1.60.1.70450.** Forever now ships its own floating pet battle tooltip, so the Mainline skin no longer loads there, and the battle pet tooltip skin, which still does, would have called a template skin that no longer existed. A Camelot copy of the skin covers both [forever]
  * fix: the hunter stable's 70450 redesign is skinned: the header and footer plates, dividers and slot frames are hidden while the lock and pet icons stay, and the experience bar, which lost its skin when Blizzard changed its type, uses the progress bar skin [forever]
  * fix: progress bars (skills, reputation, professions, pet experience) line up with their backdrop again; 70450 insets the fill 6 px from each side [forever]
  * fix: close and maximize/minimize buttons keep their 24 px size on Forever, where 70450 grew them to 28 px [forever]
  * fix: the group finder's close button uses the default-anchors close button skin, matching the template it now inherits [forever]

### Changed ###

  * chg: skin manifests regenerated for Forever 1.60.1.70450 and retail 12.1.5.70448 [forever/mainline]
  * chg: the unused `Skin.PetExpStatusBarTemplate` and `Skin.PetStableLoyaltyLevelTemplate` are removed; 70450 dropped both templates [forever]


## [12.1.5.1] ##
### Added ###

  * add: **the Trading Post is skinned throughout.** The cart lists and ensemble item lists have flat rows and square icons; the item being previewed has its icon border in the highlight colour, where Blizzard shows a gold border; the gold ensemble outline is gone. Product rows' add/remove cart button is a flat button with a plus or minus badge, and the cart's remove-item X uses Aurora's close button [mainline]

### Fixed ###

  * fix: **the PvP window's activity buttons** (Quick Match bonus list, special events, Rated and Training Grounds) lose Blizzard's button art. Their skin cleared it with `SetNormalTexture("")`, which no longer removes an atlas; it now uses `ClearNormalTexture` and its siblings, still with nothing written onto the buttons, so queueing stays untainted. A flat fill stands in for the art [mainline]
  * fix: three-slice buttons clear their middle slice too, not only the ends, so no red middle stays behind (the Trading Post's buttons, the AddOn list, the Barbershop) [mainline/forever]
  * fix: the Trading Post's footer buttons (Leave, Purchase, Add to Cart, Refund) and the cart's buy, close and clear-cart buttons are skinned; the view-cart and clear-cart buttons keep their cart and trash icons [mainline]
  * fix: group finder applicant rows on your own listing are skinned, including the invite tick and the decline button [mainline]
  * fix: renown and unlock toasts use one Aurora backdrop the size of Blizzard's toast panel, which they replace, so the title, icons and text all sit inside it; the reward icon is square without its round ring [mainline/forever]

### Changed ###

  * chg: the quest log's story and campaign tooltips have a solid background instead of the frame alpha; they open over the quest log's side tabs and the objective tracker, which read through otherwise [mainline/forever]
  * chg: `X-Min-Interface` is 120105 [mainline]
  * chg: a nineslice layout with no name is noted in the debug log instead of chat on dev builds [shared]
  * chg: the unused `Skin.CampaignTooltipTemplate` is removed [mainline/forever]


## [12.1.5.0] ##
### Added ###

  * add: **the quest log's story and campaign tooltips are skinned**, once at load through the taint-safe tooltip path: Blizzard's border cleared, Aurora's background. Nothing is hooked on the story or campaign header hover [mainline/forever]
  * add: the end-of-match celebration screen is skinned: the model scene and the Leave and extra buttons. Its themed border, title and topper keep Blizzard's texture-kit art, and the score widget stays Blizzard's [mainline/forever]
  * add: the Trading Post's model preview toggles (Hide Player, Mount Special Animation, Hide Armor, Attack Animation) and its rotate buttons are skinned [mainline]

### Fixed ###

  * fix: **Aurora loads on 12.1.5.** Its retail `RequiredDeps` listed four `Blizzard_Deprecated*` addons that 12.1.5 deletes (the Currency, Item, Pvp and Sound scripts), and a missing required dependency stops an addon loading. The Deprecated dependencies are now classic-only: Blizzard's own addons always load first, and the retail and Forever skins call none of the shims [mainline]
  * fix: opening the PvP window no longer errors. 12.1.5 renamed the Training Grounds battleground button and the skin stopped there, leaving the type dropdown and the battleground list stock. The skin now walks the button list, which also skins the Arena button for the first time [mainline]
  * fix: hovering a group finder listing no longer errors. Its class colouring called `C_LFGList.GetSearchResultMemberInfo`, a deprecated shim 12.1.5 deletes, and now uses `GetSearchResultPlayerInfo` [mainline]
  * fix: renown and unlock toasts: the backdrop spans the faction name and reward text (12.1.5 wraps long faction names at a fixed width), and the top border and bottom glow line stay hidden; the toast's show animation faded them back in [mainline/forever]
  * fix: reputation category headers on Forever lose Blizzard's bar art under Aurora's backdrop [forever]

### Changed ###

  * chg: Interface 120105 for 12.1.5 [mainline]
  * chg: `Skin.ListHeaderThreeSliceTemplate` moves to the SharedXML ListTemplates skin. It lived in the housing blueprint skin, which Forever does not load [mainline/forever]


## [12.1.0.15] ##
### Added ###

  * add: vehicle pitch controls skin [mainline/forever]


## [12.1.0.14] ##
### Added ###

  * add: **a reload prompt after a live colour-mode switch** in Aurora's options. Buttons, tabs, check buttons and status bar backdrops keep the old mode's colours until a reload, so the panel now asks for one [all]
  * add: `Color.SetTokenOverride`, for a host addon to pin a palette colour (RealUI's gradient button style and its Skins colour pickers) so that a colour-mode switch keeps it [all]

### Fixed ###

  * fix: **the `ShouldShowMawBuffs` wrapper was what tainted the objective tracker, and it is removed.** A login taint log showed the scenario tracker's `LayoutContents` reading the replaced global inside the tracker's first update; the next layout write carried that taint into the whole tracker for the session. The `GetAuraDataByIndex()` error the wrapper was added to hide only happens in a tainted tracker. With the wrapper and RealUI's own login source gone, a delve raised no error [mainline/forever]
  * fix: **opening the world map no longer taints the quest data the tracker reads.** The help tip skin wrote fields onto the help tip Blizzard acquires when the map opens, so the rest of the map open ran tainted, including the world quest pins that create a new quest's cache entry, which the tracker reads next. Help tips are left as Blizzard's, and the help tip pool's `Acquire` is no longer replaced [mainline]
  * fix: **hovering a quest title in the quest log no longer taints the tracker.** Aurora replaced the global `QuestMapLogTitleButton_OnEnter`, which the title buttons call by name, so every hover ran Aurora code, including the quest cache reads the tracker shares. The replacement is removed, together with an unused `SetTooltipMoney` replacement [mainline/forever]
  * fix: the channel list's header pool `Acquire` is no longer replaced; its headers are restyled after the list updates [mainline/forever]
  * fix: the delve companion portrait's `OnEnter` is no longer replaced with a wrapper; the wrapper made the whole hover run tainted [mainline/forever]
  * fix: `Util.WrapPoolAcquire` post-hooks a pool's `Acquire` with `hooksecurefunc` and skins new frames from a pass over the active ones, instead of replacing `Acquire` with an Aurora function that every Blizzard acquire then ran through [all]
  * fix: disabled buttons follow the colour mode instead of the Normal mode's grey, and a live switch keeps host-pinned colours, including the gradient button colour [all]
  * fix: **world-event status bars are skinned again** (gated since August), see Changed [mainline/forever]
  * fix: **the inspect window is skinned again on Forever build 70291.** That build removes the Talents button from the inspect paperdoll and replaces the PvP tab with a rank panel, and the skin stopped at the missing button, leaving the slots, model and PvP tab stock. The button is skipped when absent, the rank panel gets the same treatment as the character sheet's PvP tab (decorative rule and bar backing cleared, reward badge skinned), and the new third side tab (Guild) is skinned [forever]
  * fix: on Forever build 70291 the character sheet's new stone strip above the model is hidden, and the group finder's new voice chat dropdown is skinned [forever]
  * fix: the raid manager's toggle buttons no longer get no-op `OnMouseDown` and `OnMouseUp` scripts, and the housing charter's signature pool is no longer hooked; neither did anything but put Aurora code on Blizzard frames [mainline/forever]

### Changed ###

  * chg: **the objective tracker skin is rewritten to restyle in place.** Headers get a flat dark band on Blizzard's own background texture, white titles and triangle collapse arrows drawn on the existing button textures. Quest, bonus, world quest and timer bars and the Mythic+ timer take Aurora's bar texture and colour, with Blizzard's border and flare art cleared. The "Quest Discovered!" popup is restyled in place; its badge, shine and flash stay Blizzard's. Quest lines, POI, item and find-group buttons, and the scenario and delve section below its header (stage block, criteria bars, Maw buffs, delve traits) stay Blizzard's: styling them is what tainted the tracker. The skin stores nothing on tracker frames and creates no frames or textures on them [mainline/forever]
  * chg: **the UI widget skin is rewritten and its gate removed.** Status-bar widgets are restyled only in the top-centre container, below the minimap, on the encounter power bar and in the delve difficulty picker, from post-hooks on the widget templates' `Setup`: caps, borders, spark and glows cleared, the background recoloured, Blizzard's fill colour kept. Widgets anywhere else, including tooltips, nameplates and the tracker, are Blizzard's. No widget container is modified any more; the delve picker's modifier icons stay square through the allow-list [mainline/forever]
  * chg: the Maw buffs container and the delve traits flyout are no longer skinned; both sit inside the scenario tracker [mainline/forever]
  * chg: **quest log headers are restyled in place** after Blizzard builds the quest log: a flat coloured band on the headers' own textures, the filigree and callings divider cleared. Campaign headers lose their faint emblem. No header pool is wrapped [mainline/forever]
  * chg: **every tooltip uses the taint-safe tooltip skin** the main tooltip already used: secondary tooltips (item links from chat, reward items inside quest and world quest tooltips, comparison, contribution and garrison tooltips) are borderless with Aurora's background, and no tooltip goes through the NineSlice hook any more. The status bar under the main tooltip is Blizzard's [mainline/forever]
  * chg: tooltip progress and status bars have their borders cleared and their background recoloured, with 1px dividers; their size and layering are Blizzard's [mainline/forever]
  * chg: **quest rewards** in the quest frame and the map's quest details are restyled after Blizzard lays them out: a cropped square icon, a flat name strip and Blizzard's quality border. The six reward-pool `Acquire` replacements are gone [mainline/forever]
  * chg: **toasts and alerts are restyled in place** (achievement, criteria, loot won and upgrade, money, honor, new recipe, pet, mount, toy, cosmetic, warband scene, runeforge, monthly activity, housing, initiative, guild challenge, garrison, digsite, entitlement, RAF, world quest, legendary, scenario, invasion and dungeon completion): a flat strip instead of a bordered box, square icons, Blizzard's glow, shine and text positions, no stripes. Upgrade and new-item toasts keep Blizzard's quality border. The skin no longer re-runs on every alert show [mainline/forever]
  * chg: pooled frames in the Encounter Journal's Journeys tab, the customization checkboxes, the social tab icon, talent icons, Adventure Map rewards and covenant callings are restyled after Blizzard sets them up instead of on `Acquire` [mainline/forever]
  * chg: housing bulletin board headers, dashboard rewards, house finder tiles and catalog categories are restyled in place [mainline]
  * chg: transmog outfit slots lose the backdrop square behind them [all]
  * chg: the Main Menu Bar option is off by default on Forever, as on every other client. It defaulted on while the Forever client discarded settings; now that they persist, turn it on in Aurora's options. Installs that already saved it keep their setting [forever]
  * chg: campaign lore dividers are tinted in place [mainline/forever]
  * chg: PvP results loot and the item belt show a cropped square icon with Blizzard's quality ring or no border; the queue status role icons are Blizzard's [mainline/forever]
  * chg: the NineSlice hook keeps its re-entry guard in an Aurora table instead of on the frame [mainline/forever]

### Known Issues ###

  * **Upgrading from 12.1.0.10 or older: delete the `Aurora` folder before installing.** A client prefers a suffixed TOC such as `Aurora_Mainline.toc` over `Aurora.toc`, so if the old files are left behind by unzipping over the folder, they keep loading instead of the new one. Addon managers that replace the folder are not affected [all]
  * Camelot's gamepad addons and the Legacy system's tree page are deliberately left unskinned, as described under 12.1.0.10 [forever]
  * Hovering some map points of interest, such as a special assignment, can log a secret-value error from the tooltip's widget (`TextWithState.lua:35`), and that tooltip line does not show; under investigation [mainline]
  * Widgets on nameplates the client marks forbidden cannot be skinned by any addon [mainline]

## [12.1.0.13] ##
### Added ###

  * add: **the Vanilla-style group finder's playstyle dropdown is skinned.** Build 1.60.1.70205 added it to the listing panel [forever]

### Fixed ###

  * fix: **upgrading an item with a long effect description works again.** Aurora replaced the global `GameTooltip_InsertFrame` to guard secret line heights on the loot history roll tooltips. On an item whose effect text reached the truncation branch of the upgrade preview, the replacement wrote `insertedFrames` onto Blizzard's preview tooltip, and on confirm Blizzard read that field one call before `C_ItemUpgrade.UpgradeItem()`, which was then refused. It showed either as nothing happening or as `AddOn 'RealUI' tried to call the protected function 'UpgradeItem()'`. The replacement is gone and Blizzard's original runs. A test with the original confirmed both sides: long-text trinkets upgrade, and the LFR loot history raises no errors [mainline/forever]
  * fix: **the loot history no longer taints its own roll tooltips.** Two overrides in the loot history skin wrote into Blizzard state that every roll tooltip reads: a hook that re-ran each row's `Init` for uncached items, and a replacement `Layout` on the roll-line mixin. Both are removed. Rows get their card backdrop from a child frame, so nothing is stored on the row [mainline/forever]
  * fix: **the LFR and dungeon "group has been formed" popup, the ready-status board, the role check and invite popups, and the battleground and rated PvP ready popups are skinned again.** Since an August 2025 change their skins were registered under keys the loader never runs, so all of them showed Blizzard's art. Enter and Leave use the taint-safe button skin, because they call `AcceptProposal()` and `AcceptBattlefieldPort()`. The rated PvP popup skin is reduced to art; it no longer re-lays Blizzard's role buttons. The leader icon keeps Blizzard's crown, and the minimize buttons sit inside the border [mainline]
  * fix: **the role poll popup shows Aurora's role icons.** Blizzard re-sets each role button's atlas every time the popup opens, which put its role circle under Aurora's tint and mask. Aurora re-applies its icon after that, desaturated for a role your class cannot take [mainline]
  * fix: **housing blueprint dialogs are darker,** and their share-code boxes lost Blizzard's rounded input border. The House Settings and house list windows get Aurora's close button [mainline]
  * fix: **the text field in Blizzard popups is skinned,** for example the "type DELETE" box. Its rounded tooltip border sat over Aurora's backdrop [mainline/forever]
  * fix: **the Add Friend dialog uses a dark backdrop,** so the contacts list no longer shows through it [mainline/forever]
  * fix: **the loot history window has Aurora's title bar, close button and resize handle** [mainline/forever]
  * fix: the Trading Post panels printed "Report: No NineSlice for nil" three times; their border is under `Border`, which Aurora now strips directly [mainline/forever]
  * fix: Camelot's character title pane, its own tab since build 70205, showed a gold border [forever]

### Changed ###

  * chg: **the `/aurora insertframe` and `/aurora mawbuffs` dev toggles are removed,** together with their `AuroraConfig` keys. The `GameTooltip_InsertFrame` replacement is gone (see Fixed). The `ShouldShowMawBuffs` wrapper was removed after clean test runs, the objective tracker error returned in the next delve, and the wrapper is back. It stays until the objective tracker skin no longer taints that code [mainline/forever]
  * chg: the backpack's free-slot count, its own string since build 70205, sits in the bag-slot corner like the other counts [forever]
  * chg: the dev test data no longer errors on items the client does not have [shared]

### Known Issues ###

  * **Upgrading from 12.1.0.10 or older: delete the `Aurora` folder before installing.** A client prefers a suffixed TOC such as `Aurora_Mainline.toc` over `Aurora.toc`, so if the old files are left behind by unzipping over the folder, they keep loading instead of the new one. Addon managers that replace the folder are not affected [all]
  * The Forever SavedVariables issue listed under 12.1.0.10 to 12.1.0.12 is resolved by the client (build 70009): `AuroraConfig` persists [forever]
  * Camelot's gamepad addons and the Legacy system's tree page are deliberately left unskinned, as described under 12.1.0.10 [forever]
  * The `ShouldShowMawBuffs` guard still owns a Blizzard global [mainline]
  * The world-event, scenario and encounter UI widgets still render with Blizzard's styling while that skin is gated. Widgets on nameplates the client marks forbidden cannot be skinned by any addon [mainline]

## [12.1.0.12] ##
A hotfix for how 12.1.0.11 was published. The addon files are unchanged.

### Fixed ###

  * fix: **Forever releases are tagged for Forever on CurseForge.** The release workflows pinned BigWigs packager v2.5.1, which predates WoW Forever. It read `1.60.1` from `Aurora.toc` but looked it up among CurseForge's retail versions, found nothing, and fell back: 12.1.0.11 was uploaded as retail `1.0.0` on CurseForge and `9.2.7` on WoWInterface and Wago, with no Forever tag. The workflows now pin packager v2.6.1, which looks `1.60.1` up under CurseForge's Forever version type. WoWInterface has no Forever category, so the packager skips Forever there rather than mislabel it [forever]

### Known Issues ###

  * **Upgrading from 12.1.0.10 or older: delete the `Aurora` folder before installing.** A client prefers a suffixed TOC such as `Aurora_Mainline.toc` over `Aurora.toc`, so if the old files are left behind by unzipping over the folder, they keep loading instead of the new one. Addon managers that replace the folder are not affected [all]
  * On the 1.60.1 Forever beta the client does not keep SavedVariables across a reload, so `AuroraConfig` is empty at every load and only the defaults apply. Confirmed by the Forever developers; not an Aurora bug [forever]
  * Camelot's gamepad addons and the Legacy system's tree page are deliberately left unskinned, as described under 12.1.0.10 [forever]
  * The `ShouldShowMawBuffs` guard still owns a Blizzard global; `/aurora mawbuffs` (12.1.0.11) is the means to re-price it [mainline]
  * The world-event/scenario UI widgets still render with Blizzard's styling while that skin is gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.11] ##
### Added ###

  * add: **the group finder Who tab on Forever.** Camelot cut the Who list from `FriendsFrame` and moved it into the group finder as `LFGWhoListFrame` (tab 3), restyled in 1.60.1.70009 with a filter dropdown and per-row invite buttons. The tab, search box, search button, filter dropdown, scroll bar and list are skinned; rows are recycled by the scroll box, so they are skinned from its `Update` hook, each getting a flat Aurora row in place of the `common-button-list-large` art, recoloured selected and hover highlights, and a stripped invite button that keeps its icon [forever]
  * add: **`/aurora mawbuffs`**, a dev toggle for the `ShouldShowMawBuffs` wrapper added in 12.1.0.8. It flips `AuroraConfig.devRestoreMawBuffs` so Blizzard's original is left in place after a `/reload`, and Aurora prints a notice at load while the wrapper is off. It exists to measure whether the wrapper is still needed: run an LFR wing and a delve with the objective tracker visible, once each way, and compare the error count and a taint log. The default is unchanged — the wrapper stays on [mainline/forever]

### Fixed ###

  * fix: **the group finder showed Blizzard's metal border over Aurora's frame on Forever build 70009.** That build restyles the group finder (`LFGVANILLA_SETTING_MODERN_STYLE`): each of the three panels is now a `PortraitFrameTemplateNoCloseButton` filling the parent, and its `NineSlice` at frame level 500 drew over the parent's backdrop. Each panel's chrome — `NineSlice`, background, streaks, portrait, header bars and inset border — is set to alpha 0 rather than hidden, because NineSlice layouts re-show their pieces. The parent's backdrop offsets drop to zero now that the panels fill the whole frame; the close button, which is named in this build and so missed by the unnamed-child sweep, is skinned explicitly; the three right-hand side tabs that replace the hidden bottom tabs take `Skin.LargeSideTabButtonTemplate`; and the listing panel's role background, divider and level-range checkbox are handled [forever]
  * fix: **the Browse panel kept a full-panel background, and its result rows kept Blizzard's list-button art.** `LFGBrowseFrame` redefines `Bg` under the template's own name, which orphans the template's full-panel background — neither `.Bg` nor the global reaches it — so every `BACKGROUND` texture the panel owns is now swept. Result rows (entry, nested entry and grouping header) hide their `ResultBG` atlas and take a flat Aurora row, the same treatment as the Who rows [forever]

### Changed ###

  * chg: **Aurora now ships a single `Aurora.toc` for every client** in place of `Aurora_Mainline.toc`, `Aurora_Mists.toc`, `Aurora_TBC.toc` and `Aurora_Vanilla.toc`. It declares all five interface versions (`120100, 16001, 50504, 20506, 11509`), and each client loads only its own skin manifest, chosen per line with `AllowLoadGameType` — the way Blizzard's own TOCs split per flavor. The Forever line keeps its extra `ExcludeLoadGameType standard, classic`, because a client that does not know the `camelot` token treats an unknown `AllowLoadGameType` as a match. `RequiredDeps` is limited to `standard, classic`, since Forever lacks several `Blizzard_Deprecated*` shims, and `LoadWith: Blizzard_EncounterJournal` stays retail-only. The classic flavors now also get the `IconAtlas` line [all]
  * chg: the release and nightly workflows and `dev/updatexmls.py` read the version from `Aurora.toc` [shared]
  * chg: the Forever manifest was regenerated for build 70009, which adds `Blizzard_UIPanelTemplates\Camelot\UIPanelTemplatesOverrides.lua` as a commented-out `replacement` entry; no skin is loaded for it [forever]
  * chg: the README was rewritten against the code — the five clients including Forever, the options panel, `/aurora skinaudit`, the file layout and the dev tooling [shared]

### Known Issues ###

  * **Upgrading from 12.1.0.10 or older: delete the `Aurora` folder before installing.** A client prefers a suffixed TOC such as `Aurora_Mainline.toc` over `Aurora.toc`, so if the old files are left behind by unzipping over the folder, they keep loading instead of the new one. Addon managers that replace the folder are not affected [all]
  * The Forever group finder restyle has had a static pass against build 70009 but only a partial in-game walk-through [forever]
  * On the 1.60.1 Forever beta (build 69913) the client never restores account-level SavedVariables, so `AuroraConfig` is empty at every load and only the defaults apply; on an affected build `/aurora mawbuffs` does not survive the `/reload` it asks for. Confirmed by the Forever developers; not an Aurora bug [forever]
  * Camelot's gamepad addons and the Legacy system's tree page are deliberately left unskinned, as described under 12.1.0.10 [forever]
  * The `ShouldShowMawBuffs` guard still owns a Blizzard global, at the 25%-of-`taintLog` cost measured for 12.1.0.9; `/aurora mawbuffs` above is the means to re-price it [mainline]
  * The world-event/scenario UI widgets still render with Blizzard's styling while that skin is gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.10] ##
### Added ###

  * add: **WoW Forever support.** Aurora loads and skins on the Forever beta (1.60.x, client folder `_classic_beta_`, interface `16001`). Despite the 1.x version this is **not** a classic port: Blizzard built Forever on the Mainline UI architecture with a `Camelot` game overlay, so it is handled as a Mainline-family flavor. `private.isForever` is gated on the interface range (16000–19999) rather than on `WOW_PROJECT_ID`, which reports Mainline there, and `AURORA_DEBUG_PROJECT = 60` selects it. The Forever client also matches `Aurora_Mainline.toc`, so Aurora has no TOC of its own for the flavor: that one file declares `## Interface: 120100, 16001` and picks `AddOns_Mainline.xml` or the generated `AddOns_Forever.xml` per line, with `[AllowLoadGameType standard]` against `[AllowLoadGameType camelot][ExcludeLoadGameType standard, classic]` — the extra Exclude is needed because a client that does not know the `camelot` token treats an unknown `AllowLoadGameType` as a match. Camelot-only skins live in `Blizzard_X\Camelot\` beside `Mainline\`, mirroring Blizzard's own paths. Nothing here changes retail [forever]
  * add: **the Camelot character panel** — `CharacterFrame` (six mode tabs and the right-hand pane host), `PaperDollFrame` (ranged and ammo slots, gear-slot border art hidden by atlas so the bare ammo slot is covered, the model control bar), `ReputationFrame`, `SkillsFrame`, `PVPRankFrame`, `BankFrame` (page tabs, no TabSystem) and `EquipmentFlyout` (Camelot's new four-direction popout button). Every `CharacterFrameSidePaneTemplate` builds its contents from one `FramePoolCollection` of four row templates, so the category and icon rows are skinned once in `CharacterFrame.lua` and that covers the reputation, skills, currency and PvP rank panes together [forever]
  * add: **the three Forever-only addons.** `Blizzard_Statistics` — mode tab 6 of the character panel, which retail has no counterpart for since achievements absorbed statistics. `Blizzard_LegacySystem` — the Progress Track window: frame, side tabs, reward track and challenge page; **the talent-style legacy tree page is deliberately left stock**, because its contents inherit `TalentButtonSquareTemplate` and friends, which Aurora skins on no flavor, and doing it here would mean writing the shared talent-tree treatment as a side effect of a Forever-only addon. `Blizzard_SwingTimer` — the main-hand, off-hand and ranged bars; they are Edit Mode systems, so nothing re-anchors them [forever]
  * add: **the remaining Camelot surfaces** — the classic pet journal and `PetStableFrame` (`Blizzard_StableUI` splits per flavor), the professions book as a page inside `ProfessionsFrame` (Camelot's TOC excludes the standalone `ProfessionsBookFrame`) plus the unlearn button, the crafting schematic form, the `TokenDetailFrame` side pane, collections side tabs and the count-style toy tracker, the bag bar and the micro menu bar art, and Camelot's nameplate level badge. The badge is skinned with **widget calls only — no Aurora backdrop**: that frame belongs to the restricted nameplate system, where `Base.SetBackdrop` writes BackdropMixin methods onto the frame table and the taint resurfaces as secret-number errors on the next nameplate reuse cycle. It is gated on `selectedBorder`, which exists only in the Camelot copy, so retail's badge is untouched [forever]
  * add: **`/aurora skinaudit`** — lists the skins whose `pcall` failed this session, with the client build and interface version. Skins run behind `pcall`, so a skin written against frames a client does not have fails silently; this turns a login on an unfamiliar flavor into a work list, and it is how the Forever pass was verified wave by wave [shared]
  * add: **`dev/forever_report.py`**, regenerating the Camelot-vs-Mainline gap analysis from the two source trees and the manifests, with Camelot files in collapsed addons surfaced in section 3. `dev/updatexmls.py` grew two report sections of its own: **section 9** finds skin templates a flavor calls but never registers — which is what surfaced the nil calls fixed below, and which ignores Lua comments so disabled calls stop reporting — and **section 10** lists positional child and region picks (`select(n, ...)` against a frame's children) for review, those being exactly what breaks when a client adds a child. Named `hooksecurefunc` targets the flavor's own tree does not define are flagged too, and each Camelot manifest entry is now marked `additive` or `replacement`: the distinction decides whether a Camelot file needs a guard in the existing Mainline skin or a skin of its own [shared]
  * add: `Skin.UIPanelArrowDropdownButtonTemplate` — a 15x16 arrow dropdown whose whole look is one gold `common-dropdown-a-button` atlas. Aurora had no skin for it, so callers reached for `Skin.DropdownButton`, which is written against `WowStyle1DropdownTemplate` and leaves the gold arrow alone; on retail that is the yellow button beside the spellbook search box [all]
  * add: `Skin.ModelSceneControlFrameTemplate` — the zoom/rotate/reset bar above a model scene. Camelot shows it on the character panel where retail does not, so it sat there as five `common-button-square-gray` buttons over the model [all]

### Fixed ###

  * fix: **every bag after the first lost its skin.** `ClickableTitleFrame` was removed from `ContainerFrameTemplate` — a deletion, not a rename; bags drag at frame level now — and the line re-anchoring it had been throwing, silently, behind the skin `pcall`, taking the rest of the function with it. Removing it exposed a second fault underneath: `Skin.ContainerMoneyFrameTemplate` is called by the backpack skin and had never been defined, on any flavor, so it had been killing that function since it was written and only the first throw hid it. Both are fixed. The money frame delegates to `Skin.SmallMoneyFrameTemplate`, which Aurora deliberately no-ops, rather than no-opping here, so bags follow if money frames are ever skinned [mainline/forever]
  * fix: **the pet bar's auto-cast decorations were unskinned, and every line after them in that skin function stopped applying.** Blizzard replaced the `AutoCastable` texture and the `AutoCastShine` frame with an `AutoCastOverlay` frame holding `.Corners` and `.Shine`; the old field names survived in the skin and had been throwing behind the `pcall`. The original intent is carried over — the overlay covers the button so its corner art lands on the square button's corners, and the rotating "ants" are pulled inside the button edge instead of overhanging it by 5px [mainline]
  * fix: **the spellbook category tabs kept Blizzard's gold plate.** `SpellBookCategoryTabTemplate` inherits `TabSystemButtonTemplate`, not a panel tab, and `Init()` puts it in square icon mode — but only the text half of `TabSystemButtonArtTemplate` was ever handled, so routing these through `Skin.PanelTabButtonTemplate` skinned art they were not showing. Icon tabs now get their own treatment: square art zeroed, icon cropped and fitted, sized 32x32 to match Blizzard's tab height. It is applied from the tab system's hooks rather than once at skin time, because the tab pool hands the same button back on `RemoveAllTabs`/`AddTab` and a button skinned while its icon was still textureless is locked out of ever being treated as an icon tab by `IsSkinned` — measured on the spellbook, of six pooled tabs four were right, one was raw 44x32 and one was sized but unfitted. Same template, same bug on retail and Forever [mainline/forever]
  * fix: **the profession recipe category headers were never actually skinned.** The hook zeroed `LeftPiece`/`RightPiece`/`CenterPiece`, keys that exist nowhere in `ListHeaderVisualTemplate` — its three-slice is `Left`/`Middle`/`Right` with a `HighlightLeft`/`Middle`/`Right` set over it. **Not a Camelot difference: the template is byte-identical in both trees, so this was equally broken on retail.** The highlight trio keeps its job and loses Blizzard's art. The crafting page's two Create buttons are skinned as well; they are built in Lua by `ProfessionsCraftingPageMixin:CreateControls`, which runs after this skin, so the existing guards had simply found nil and skipped them [all]
  * fix: `Skin.WowStyle2DropdownTemplate` was undefined — the one genuinely live call to an unregistered skin template, reached by `Blizzard_HouseEditor` for the pet behaviour and customize-panel dropdowns, and killing the rest of that skin each time. It is a `DropdownButton` like the WowStyle1 ones, differing only in mixin and art, so it takes the same skin [mainline]
  * fix: `Skin.UIPanelScrollBarButton` had likewise never been defined, although its callers expect it to leave a retexturable arrow at `_auroraTextures[1]`. Its only callers today are the Oribos scroll arrows, whose Blizzard templates are gone from every source tree; the skin is defined rather than the callers deleted, because Aurora dispatches skins dynamically in several files and "no static caller" is not proof of unreachable [mainline]
  * fix: **the open-mail divider was hidden by region index** — `select(9, ...)`, which counts the inherited `ButtonFrameTemplate` regions and does not hold on Forever, where it returned nil and took the rest of the mail skin with it. Both halves share one texture and are matched on it now, so the count no longer matters [mainline/forever]
  * fix: **`ModelPreviewFrame`'s template close button was found at child index 4**, an index that shifts on Forever, where `ButtonFrameTemplate` gains four gamepad focus children (`FrameGlow`, `LeftJumpHint`, `RightJumpHint`, `FocusJumpHint`). The historical index stays the first guess, so retail behaviour is unchanged, and the search by shape runs only when it does not hold [all]
  * fix: **side tabs showed a gold border around every icon and a glow that kept re-painting itself.** `TabGlowAnimation` loops the glow's alpha, so `SetAlpha` alone never stuck; the animation is stopped. The icon is masked into a tab silhouette by `common-sidetab-mask` and is now cropped square like every other Aurora icon — and **re-cropped after `UpdateIconInterior`**, which `SetChecked` calls last on every state change and which re-sets the texcoords to a shallower crop, leaving each icon's own bevelled edge showing. The selected and hover textures keep their roles and lose their tab shape [all]
  * fix: Frame-based progress bars no longer throw out of `Skin.FrameTypeStatusBar`. Camelot's `ColoredProgressBarTemplate` is a Frame driving a masked fill through its mixin, with none of the `SetStatusBar*` API that function uses, so one such frame threw "SetStatusBarTexture is not a function" and took its caller's whole skin with it. They route to the new `Skin.ColoredProgressBarTemplate` instead; on retail every caller passes a genuine StatusBar, so nothing changes there [all]
  * fix: `RatingMenuFrame`'s classic branch called `Skin.OptionsButtonTemplate`, defined nowhere in Aurora and naming a Blizzard template that exists in no source tree — a fossil from an older client. The branch is unreachable as things stand, but it is pointed at the button skin the retail branch uses rather than left calling a nil [mainline]
  * fix: **the skins retail shares with Camelot now tolerate Forever's trimmed frames**, where before they threw on the first missing member and lost everything below it. Friends (no `WhoFrame`, no `FriendsFrameTab2`, no `WhoList_InitButton` hook, no trial-state hook), Inspect (no `InspectFrameTab3`, guarded paperdoll slots and `InspectPaperDollFrame_OnShow`), TokenUI (no currency popup), Mail (paging buttons resolved from `InboxFrame`), TrainerUI (cost display from `ClassTrainerFrame.money`), Professions (no standalone book, no maximize button), the group finder (per-flavor tab and scrollbar templates, role buttons only when the template is registered), `ScriptErrorsFrame` (`CloseButton`, Forever's rename of `Close`), the spec frame, the tracking button, the character-sheet hook, the parchment page textures, the filter dropdown and the transfer log toggle. Each is a guard or a per-flavor pick, so retail is unaffected [forever]

### Changed ###

  * chg: the shared `PaperDollFrame` and `ReputationFrame` skin bodies moved to `Skin\shared\`, with thin per-flavor callers under `Mainline\` and `Camelot\`; `Blizzard_StableUI` splits the same way, and the manifests point at the new paths. No behaviour change on retail [shared]
  * chg: `Skin.LargeSideTabButtonTemplate` is now shared across five surfaces — the Camelot character panel's mode tabs, the bank page tabs, Professions, Collections and the Legacy system — and it crops the bank page tab icons itself rather than each caller doing it [all]
  * chg: `mainmenubar` defaults **on** for Forever and stays off everywhere else. On retail the bar theming is redundant for most users, who run Bartender4 or Dominos; on Forever there is no such expectation, and the bag bar, micro menu and action bar end caps are all gated behind this one flag, so defaulting it off left three finished skins dead on that client [forever]
  * chg: the dev-only nil-frame warnings for `DropdownButton` and `FilterButton` name the caller, and frames in addons Aurora does not skin are marked as not-a-gap in the Forever report so they stop showing as work [shared]

### Known Issues ###

  * On the 1.60.1 Forever beta (build 69913) the client never restores account-level SavedVariables, so `AuroraConfig` is empty at every load and only the defaults apply. Confirmed by the Forever developers; not an Aurora bug. Whether `mainmenubar` should default on for Forever permanently is a separate, still-open call [forever]
  * Camelot's gamepad addons are deliberately unskinned — 81 frames, 73 of them in `Blizzard_GamepadActionBars`. None of it renders without a controller attached, so none of it can be verified; the gamepad focus children that leak into ordinary Camelot panels are handled where they matter. Revisit if a controller-using tester appears [forever]
  * The Legacy system's tree page renders with Blizzard's styling, as above [forever]
  * The Camelot bank, and slot and pane positioning across the character panel, have had a static and skin-audit pass but no in-game walk-through [forever]
  * The `ShouldShowMawBuffs` guard added in 12.1.0.8 still owns a Blizzard global, and the 25%-of-`taintLog` cost measured for 12.1.0.9 is unchanged. The trade should be re-priced rather than left standing [mainline]
  * The world-event/scenario UI widgets still render with Blizzard's styling while that skin is gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.9] ##
### Added ###

  * add: **NamePlates skin for the classic flavors** — era, TBC and Mists now resolve `Blizzard_NamePlates\Classic\`. Blizzard unified the nameplate file set across flavors, so the file is a deliberate verbatim copy of the Mainline skin plus a flavor note; every symbol it touches was verified present in all three trees (`NamePlateDriverMixin`, `OnNamePlateAdded`, `NamePlateAurasMixin:RefreshAuras`/`:RefreshLossOfControl`, `HealthBarsContainer`, the aura/debuff/crowd-control/loss-of-control list frames, `ForEachNamePlate`, and all three `SetClassNameplateBar*` driver methods — the driver methods exist on classic even though the frames never arrive, so the `hooksecurefunc` calls are safe and stay in for parity). Health and cast bars are deliberately **not** skinned: `Base.SetBackdrop` writes BackdropMixin functions and `_backdropInfo` directly onto the bar, which taints it, and on the next nameplate reuse cycle `CompactUnitFrame_UpdateHealPrediction` then reads `GetMinMaxValues()` tainted and errors on a secret number. Only the aura icons are cropped. Keep the two files in sync — a plain diff between them should show only the flavor note [classic]
  * add: **TimeManager skin for the classic flavors** — clock globe and stopwatch frame/tab art removed, the stopwatch check and the alarm dropdowns and edit box skinned. Blizzard splits this addon per flavor, but the frame structure the skin touches is the same in both trees: `TimeManagerFrame` inherits `ButtonFrameTemplate`, the alarm dropdowns hang off `AlarmTimeFrame` by parentKey, and the stopwatch textures keep their `$parent*` names. The one real difference is that classic's alarm dropdowns inherit `WowStyle1ThinDropdownTemplate` where retail uses `WowStyle1DropdownTemplate`, which `Skin.DropdownButton` already handles; the explicit dropdown widths are cosmetic tuning picked against the retail template, so they are what to eyeball on a classic client rather than anything that can fail loudly [classic]
  * add: **vanilla-style group finder row templates** — browse results (`LFGBrowseSearchEntryTemplate`), listing activity rows (`LFGListingActivityRowTemplate`) and the lazily-created category buttons, closing the deferral left in the skin header. All three families are recycled by their container, so each is skinned from an update/add hook rather than once at load. Meaningful art is kept per the file's existing policy — party, class and newcomer icons on a result row, the Enumerate and Solo role art, and the category icons; what gets recoloured is the ADD-blended highlight and selected bars, the parts that actually fight the theme, using the same blend reset plus Aurora highlight colour as the classic AuctionUI rows. The `RoleCountNoScriptsTemplate` icon swaps are inlined because `Skin.RoleCountNoScriptsTemplate` is Mainline-only [classic]

### Fixed ###

  * fix: **the chat edit-box border hook threw `attempt to index local 'channeleditBox' (a nil value)` at login** (×3 for a user with channel-bound chat windows). `Hook.ChatFrameEditBoxMixinUpdateHeader` read `ChatFrameUtil.GetActiveWindow()` — which returns `ACTIVE_CHAT_EDIT_BOX`, the edit box the user currently has **open** — instead of the edit box it was handed. That is nil whenever `UpdateHeader` runs outside a user-opened edit box, which is exactly the reported path: `UPDATE_CHAT_WINDOWS` → `ChatFrameMixin:UpdateDefaultChatTarget` → `editBox:UpdateHeader()` fires as chat settings arrive at login, and reaches the `CHANNEL` branch for any window whose default target is a channel. A mis-port dating to the WoW 12 removal of `ChatEdit_GetChannelTarget(editBox)`; it also read the wrong window's channel colour whenever it did not crash. It now uses `editBox:GetChannelTarget()`, matching Blizzard's own `UpdateHeader` at `ChatFrameEditBox.lua:641`, with a comment recording why `GetActiveWindow()` is the wrong object so the next API rename does not repeat it [mainline]

### Known Issues ###

  * The `ShouldShowMawBuffs` guard added in 12.1.0.8 owns a Blizzard global, which taints it permanently for every later reader. A 4½-minute field log on a shipped build has since put a number on that cost: **38,407 of 152,518 lines (25%) are RealUI_Skins reading the global**, sustained at ~140/sec, because `ScenarioObjectiveTrackerMixin:OnEvent` reads it inside its `UNIT_AURA` branch. That is a rare error traded for a continuously tainted aura path, and it makes `taintLog` close to unusable for any other diagnosis on an affected setup. The trade should be re-priced rather than left standing [mainline]
  * The world-event/scenario UI widgets still render with Blizzard's styling while that skin is gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.8] ##
### Fixed ###

  * fix: **the objective tracker threw `GetAuraDataByIndex(): Auras cannot be accessed when secret while tainted by 'RealUI_Skins'` in LFR and delves.** Blizzard's `ShouldShowMawBuffs` reads `C_UnitAuras.GetAuraDataByIndex("player", 1, "MAW")` unguarded, and under the Midnight secret-aura rules that API throws rather than returning nil when the execution is tainted. All three of its callers are `MawBuffsContainerMixin:Update` and the scenario tracker's `OnEvent`/`LayoutContents`, so the throw landed mid-layout and took the stage block down with it. The function is wrapped to short-circuit to `false` when `C_Secrets.ShouldAurasBeSecret()` reports secret auras — the only honest answer at that point, and the Maw/Torghast surface it gates is legacy content. This silences the throw; it does not undo the tracker-side taint (see Known Issues) [mainline]
  * fix: **the Delves companion abilities panel had two blank boxes where the page arrows belong**, plus an unskinned close button, role dropdown and portrait ring. The arrows went through `Skin.FrameTypeButton`, which clears the normal/pushed/disabled textures — Blizzard's art was stripped and nothing put back; they now take `Skin.NavButtonNext`/`NavButtonPrevious`, as `Blizzard_PlayerSpells` already does on the identical paging template. The frame also inherits `PortraitFrameTemplate`, and `StripBlizzardTextures` reaches only the frame's own regions and its NineSlice, never the child frames, so `CloseButton`, `PortraitContainer` and the role dropdown are handled explicitly [mainline]
  * fix: **hovering the Delves companion portrait threw `GameTooltip.lua:607: attempt to perform arithmetic on a secret number value`.** Skinning the tooltip hierarchy makes `widgetContainer:GetHeight()` return a secret number, which `GameTooltip_AddWidgetSet` then adds padding to. The skin already carried a `securecallfunction` guard for this, and it had never applied: `mixin=` copies `CompanionPortraitFrameMixin` onto the frame when the XML loads, before the addon callback runs, so patching the prototype missed the instance — and securecallfunction would not have helped anyway, since secret values error on any arithmetic regardless of execution context. The guard now sits on the instance and swallows only the failing tail, whose return value this call site discards; the `GameTooltip:Show()` the throw used to skip is re-asserted [mainline]

### Changed ###

  * chg: **the objective tracker skin is enabled again**, gated off since 12.1.0.5. With the MawBuffs aura throw guarded, the fault that was aborting `LayoutContents` no longer fires, and a full play session produced no tracker errors. This removes the symptom, not the cause — the skin still writes to tracker frames in the ways `objective-tracker-taint.md` prohibits, and the gate is one flag away if faults return. Treat any new tracker-side secret-value or layout error as this gate, and reach for the rewrite rather than for another guard [mainline]

### Known Issues ###

  * The `ShouldShowMawBuffs` guard owns a Blizzard global, which taints it permanently for every later reader — the same cost documented for `GameTooltip_InsertFrame`. Accepted because all three of its readers already sit inside the poisoned tracker set, and because the alternative is an error that aborts tracker layout [mainline]
  * The world-event/scenario UI widgets still render with Blizzard's styling while that skin is gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.7] ##
### Fixed ###

  * fix: **hovering a talent button poisoned the action bar highlight system for the whole session.** The skin hooked `ClassTalentButtonArtMixin.UpdateStateBorder` to hide the rotating gold sheen on talent nodes — and `ClassTalentButtonSpendMixin:OnEnter` reads that mixin key one line before calling `ShowActionBarHighlights`, which writes the global `ON_BAR_HIGHLIGHT_MARKS`. Blizzard's own source flags that table as taint-vulnerable, and `ActionBarController_UpdateAllSpellHighlights` re-reads it constantly: 1428 taint events in a nine-minute log from one hover, the single largest taint source and the only global Aurora was tainting at all. The hook is removed outright — the sheen is back for now; a taint-free suppression (a one-time `SetTexture("")` sweep, no hook) is noted in the source for a later release, deliberately not bundled with the removal so the two verify separately [mainline]

### Changed ###

  * chg: the ~546 lines below the UIWidgets gate are now explicitly flagged as dead code. The gate at the top of the block returns unconditionally, but the block reads as live — it carries comments describing SafeNumber protections that are not in force — and it misled a taint investigation into a confident wrong diagnosis. No behaviour change; the block either gets the taint-safe rewrite it was parked for, or gets deleted [mainline]

### Known Issues ###

  * The objective tracker and world-event/scenario widgets still render with Blizzard's styling while those skins are gated (unchanged from 12.1.0.5) [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.6] ##
### Fixed ###

  * fix: **opening the world map threw a blocked-action error, and map pins lost their mouse handling.** Two separate hooks in the same execution: `WorldMapFrame`'s `Minimize`/`Maximize` and `BorderFrame`'s `SetBorder` were both hooked, and Blizzard reads all three from inside `WorldMapMixin:OnShow` — via `SetDisplayState`, which runs only when the display state is stale, hence the intermittency. Reading a hooked key taints the execution, and the same OnShow then calls the protected `C_ChatInfo.PerformEmote` and acquires the AreaPOI/delve pins, which call `SetPropagateMouseClicks`. Both hooks are gone: the empty `Maximize` hook is deleted, and the NavBar nudge and border restyle now ride Blizzard's own `WorldMapMinimized`/`WorldMapMaximized` events [mainline]
  * fix: **the chat system was tainted at every login.** `Util.WrapPoolAcquire` replaces a pool's `Acquire`, and Blizzard acquires chat-config tabs from inside `ChatConfig_UpdateChatSettings → UpdateTabDisplay → UpdateSelection` — which writes the global `CURRENT_CHAT_FRAME_ID`. Written inside an addon-owned call, that global stayed tainted for the session and every later `FCF_GetCurrentChatFrame` reader inherited it. The tabs are skinned from the config frame's `OnShow` instead, so nothing of ours runs during Blizzard's login path. Confirmed by taint.log going from three RealUI_Skins entries per login to none [mainline]
  * fix: **auction house and item-link comparison tooltips had no background.** `ShoppingTooltip1/2` and the `ItemRef` pair went through the generic `NineSlicePanelTemplate` route, which stacks an Aurora backdrop on top of Blizzard's nine-slice; the backdrop was present and simply never drew. GameTooltip's taint-safe path — hide the border pieces, colour Blizzard's own Center via `SetCenterColor` — is what actually renders a tooltip panel, and all four now use it. As a side effect they leave the heavy `NineSliceUtil.ApplyLayout` hook entirely [mainline]
  * fix: **community and guild list entries are skinned again**, having been left stock after the avatar-loading fix in 12.1.0.5. They are styled from the ScrollBox's own `OnInitializedFrame` callback, which fires after Blizzard's initializer has set the avatar and is re-secured per element — not by hooking `CommunitiesListEntryMixin`, which is what made `C_Club.SetAvatarTexture` refuse in the first place. The entry plates are also re-anchored: every one is declared 80px tall on a 68px button, so a flat colour left a 6px lip. Panel insets, scroll bars and the calendar button (an empty skin stub) are skinned too [mainline]
  * fix: **battleground scoreboard errors on entering a match** — x10 "Secret values are only allowed during untainted execution". `Skin.WowScrollBoxList` backdrops the ScrollBox itself, marking it addon-modified, and both PVPMatch scroll boxes drive TableBuilder cell construction whose `Populate` feeds a secret `honorLevel` to `C_PvP.GetHonorRewardInfo`. The backdrop moves to a sibling frame behind the scroll box, the same cure already used for `HonorFrame.SpecificScrollBox` [mainline]
  * fix: **end-of-match reward icons rendered as empty black boxes** — the loot buttons take a square skin, matching the rest of the UI [mainline]
  * fix: **the spellbook "not on any action bar" indicator** was the rounded `spellbook-item-unassigned-glow` atlas anchored to overhang the button by 3–4px, reading as a rounded glow around a square icon. It is squared to the icon and takes the flat highlight colour; the pulse animation is unaffected [mainline]

### Changed ###

  * chg: `Util.WrapPoolAcquire` carries a taint-hazard note. It replaces `pool.Acquire` outright, so any Blizzard code that acquires from that pool runs addon code inside its own execution — and if that execution writes a global or calls a protected function, the damage is permanent for the session. Fifty-one call sites remain; only the one with evidence was changed. Prefer an `OnShow` sweep over `pool:EnumerateActive()` when in doubt [shared]

### Known Issues ###

  * The objective tracker and world-event/scenario widgets still render with Blizzard's styling while those skins are gated (unchanged from 12.1.0.5) [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.5] ##
### Added ###

  * add: **OverrideActionBar** (vehicle/override bar) — ported from the pre-reorg FrameXML skin, updated to the mixin API (`SetSkin`/`CalcSize` method hooks): endcap and background art removed, status bars flattened, xp-bar ticks; the six spell buttons inherit `ActionBarButtonTemplate` and take the same skin as the main action buttons [mainline]

### Fixed ###

  * fix: **scrollbar arrows showed Blizzard's atlas at login** on every scrollbar, switching to Aurora's arrow only after the first scroll — 12.x moved the stepper's atlas application from `UpdateAtlas` into `OnButtonStateChanged` (fires on enable/disable/hover/press, login init included), so the skin's OnShow-only fallback never held. Arrows are applied at skin time and re-asserted after every state change; also fixes the arrow flickering back to Blizzard's on hover. Same fix on the Oribos scrollbar variant [shared]
  * fix: **chat return-to-bottom button** — the pale double-triangle was the button's `Flash` overlay: `ChatFrameMixin:OnUpdate` runs `UIFrameFlash` on it whenever the frame is scrolled up, overwriting the skin's `SetAlpha(0)` every frame. The overlay is restyled to Aurora's arrow instead of hidden (the unread-below alert keeps working), and the button is sized to the stepper geometry so all three arrows match [mainline]
  * fix: **community and guild avatars failed to load** — runtime icon cropping in the list-entry hooks modified the same texture `C_Club.SetAvatarTexture()` writes to, and the protected call refuses addon-modified textures once ScrollBox recycles an entry (`ADDON_ACTION_BLOCKED`). The crops are removed; the template's hidden circle mask already squares the icons. The Club Finder card logo had the identical pattern waiting undetonated and gets the same treatment [mainline]

### Changed ###

  * chg: **the objective tracker and UI widget skins are disabled** pending a taint-safe rewrite. Field evidence (taint.log plus `issecurevariable` sweeps) showed the tracker's own layout state written under skin taint — self-perpetuating, and surfacing in delves as a refused aura read mid-update. The injection class is geometry writes (resize/re-anchor of measured frames) running Blizzard layout handlers synchronously inside skin executions; the rewrite rules are recorded in the workspace steering doc `objective-tracker-taint.md` [mainline]

### Known Issues ###

  * The objective tracker and world-event/scenario widgets render with Blizzard's styling while the skins above are gated [mainline]
  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged [mainline]

## [12.1.0.4] ##
### Added ###

  * add: **UI widget templates** — the icon-bearing widget types are skinned for the first time (`ItemDisplay` and the shared item/currency bases, `IconTextAndBackground`, `DoubleIconAndText`). Aurora only ever defined skins for a handful of the ~35 widget templates, so every other type rendered with Blizzard's rounded icon art wherever widgets appear [mainline]
  * add: **delves scenario header widget** (`UIWidgetTemplateScenarioHeaderDelves`) — the objective tracker's delve block drew its own artwork and fonts because no skin existed for its widget type [mainline]

### Fixed ###

  * fix: **the delve objective-tracker error is resolved.** Aurora wrote four shared font globals (`STANDARD_TEXT_FONT`, `UNIT_NAME_FONT`, `NAMEPLATE_FONT`, `DAMAGE_TEXT_FONT`); writing a global from an addon taints it permanently and every later reader inherits that taint — it was caught spreading to unrelated third-party addons. Separately, the objective tracker skin stored `_auroraBG`/`_auroraOverlay` directly on `ScenarioStageBlock`, tainting the very frame whose `LayoutContents` calls `GetAuraDataByIndex`. Together those produced "Auras cannot be accessed when secret while tainted by 'RealUI_Skins'" in delves, aborting tracker layout. Both writes are gone; verified across a full delve with `taintLog 2` [shared]
  * fix: **delve entry screen** — the Map Properties icon kept Blizzard's circular border (its widget container is declared in the addon's own XML, so it never reached the widget skins), and the reward rows were never skinned at all: Aurora wrapped a reward pool that Blizzard creates but never acquires from, while the rows actually come from the ScrollBox element factory. Reward icons also stayed square now that the list stretches each row [mainline]
  * fix: **objective tracker** — scenario/delve blocks, their criteria progress bars, and any block acquired through `GetBlock` are skinned. Progress bars are acquired by the module's own pool rather than the block, so `AddProgressBar` never reached them; block templates with a skin function but no call site (the "Quest Discovered!" popup) were never skinned at all [mainline]
  * fix: **dropdown arrows** — skinned dropdowns and filter buttons lost their arrow with no replacement (Currency character filter, Calendar filters). `UIDropDownMenu`-style dropdowns — which AceGUI uses, so every RealUI config dropdown — expose their parts by global name rather than parentKeys, so they now get their own button's artwork replaced instead of a second arrow stacked on top [mainline]
  * fix: **reputation** — the filter dropdown was never skinned, and the sub-header expand button kept Blizzard's plus/minus artwork: 12.x renamed it from `ExpandOrCollapseButton` to `ToggleCollapseButton` and drives its state through `RefreshIcon`, which sets the atlas on the texture object where Aurora's hooks never saw it [mainline]
  * fix: **spellbook** buttons kept the rounded `IconHighlight` atlas, re-applied by `UpdateVisuals`, instead of the flat action-bar highlight [mainline]
  * fix: **professions** — reagent and item icons render on the ItemButton intrinsic's lowercase `icon`, which was never cropped; the rounded quickslot ring is re-cleared after `SetModifyingRequired` re-applies it; the reagent flyout was entirely unskinned; recipe list gold hover/selection atlases replaced with flat bars [mainline]
  * fix: **quest log** headers drew Aurora's legacy expand glyph on top of Blizzard's collapse button — two "+" per collapsed header. Campaign headers had the same stacking [mainline]
  * fix: **chat** — the return-to-bottom button kept Blizzard's atlas while the scroll bar's own arrows were skinned, so one chat frame showed three arrow styles [mainline]
  * fix: **expand/collapse glyphs** were anchored from `TOPLEFT` with offsets tuned for a 13px button, sitting off-centre on anything larger [shared]
  * fix: **world map** maximize/minimize buttons rendered as missing-glyph boxes — the icons are drawn as text (the map is under a widget-API-only taint regime) and the font has no arrow or geometric-shape characters [mainline]

### Changed ###

  * chg: the **chat skin follows the "Skin Chat" setting** again. It still causes tainted reads of `CURRENT_CHAT_FRAME_ID` at zone-in — Blizzard's own `ChatConfigFrame` writes that global — but with the tracker-side frame writes gone that taint no longer reaches the objective tracker. Do not reintroduce addon fields on tracker frames [mainline]

## [12.1.0.3] ##
### Added ###

  * add: **Blizzard_TieredEntranceTraits** module — the scenario/delve trait flyout: container chrome, themed overlay and flyout arrow suppressed, spell buttons cropped and backdropped, tooltip and tier rows restyled [mainline]
  * add: at-war factions are tinted red in the reputation list again — the pre-ScrollBox skin signalled it with a red row backdrop, and 12.x rows have none, so the faction name carries the indication instead (re-applied on every row `Initialize`, since the ScrollBox recycles rows across factions) [mainline]

### Changed ###

  * chg: skinned-state tracking moved from an `_auroraSkinned` field on the widget to a weak-keyed side table (`private.IsSkinned` / `private.SetSkinned`). Writing to a Blizzard frame's table taints it, and that taint can bleed into secure paths whenever the table is iterated or copied (frame pool reset, `Mixin`, `CopyTable`); weak keys let entries drop with the frame. Applied across the whole skin surface — the same approach `Blizzard_CooldownViewer` and `Blizzard_UIWidgets` already used [shared]

### Fixed ###

  * fix: AchievementFrame skin errored at load on 12.1 (`BackgroundBlackCover` removed), leaving the whole frame unskinned — skin updated for the 12.1 header restructure: search box, filter dropdown, and search preview moved to `AchievementFrame.HeaderDetails.Filters`, `AchievementFrameFilterDropdown` global and `LeftDDLInset` removed; new `HeaderDetails` back button skinned and `TopTileStreaks` hidden; box/dropdown positioning left to Blizzard's layout frame (comparison mode re-anchors it) [mainline]
  * fix: reputation rows rendered completely unskinned on 12.x — the frame moved to a ScrollBox, so the four `ReputationFrame_*` globals Aurora hooked and the `ReputationBar1..N` loop were both silent no-ops; rows are now skinned through the `ReputationHeader`/`ReputationEntry`/`ReputationSubHeader` template mixins, and the reputation bar's leftover end caps, background fill, and highlight regions are hidden [mainline]
  * fix: bag and vendor item buttons kept Blizzard's rounded quality border on top of Aurora's square one — `Hook.SetItemButtonQuality` only catches callers of the global, and most 12.x callers use the mixin method; the border is now hidden from `SetItemButtonBorder_Base`, the single choke point every path converges on, and re-hidden per call since Blizzard re-shows it on each quality update [mainline]
  * fix: masked icons (Giant/Circular item buttons, action bar icons) were never cropped square — the client refuses `SetTexCoord` on a masked texture and `Base.CropIcon`'s `pcall` swallowed the refusal, so icons silently stayed rounded; `CropIcon` now drops the masks first, keeping the `pcall` only for textures that refuse for other reasons [shared]
  * fix: dropdown menu backgrounds followed Frame Opacity all the way down (0.2 by default), making popups unreadable over world content — menu background alpha is now floored at 0.9 while still tracking the frame colour [mainline]
  * fix: talent-derived frames (class/spec trees, hero talents, generic trait UIs) had no background — `Base.StripBlizzardTextures` ran *after* `Skin.FrameTypeFrame` and wiped the backdrop regions it had just created; the strip now runs first [mainline]
  * fix: housing item-earned and endeavor task-complete toasts still showed the ornate gold border — the `housing-item-toast-glow`/lightrays/sparkles ADD-layers that `SetUp` animates on every acquire are now hidden along with the frame art and divider [mainline]
  * fix: profession specialization tab lock icon overflowed into the neighbouring tab — Blizzard anchors it to the Text's right edge, which Aurora's tab skin stretches to the full tab width; the icon is re-anchored inside the tab on every `SetState` [mainline]

### Known Issues ###

  * The `GameTooltip_InsertFrame` taint described under 12.1.0.2 is unchanged — `/aurora insertframe` remains the A/B toggle for it [mainline]


## [12.1.0.2] ##
### Added ###

  * add: `/aurora insertframe` — dev toggle (`AuroraConfig.devRestoreInsertFrame`, default off) that runs Blizzard's original `GameTooltip_InsertFrame` instead of Aurora's replacement, so the surfaces relying on the replacement can be A/B tested; prints a load-time notice while active [mainline]

### Changed ###

  * chg: README documents the embedded-host caveat — `gui.lua` is only loaded when Aurora runs standalone, so `/aurora` and its subcommands do not exist in hosts that embed just the skin XML (e.g. RealUI_Skins, which mirrors the toggle as `/auroraInsertFrame`)

### Known Issues ###

  * Aurora replaces the global `GameTooltip_InsertFrame`, which taints it for every secure reader. `Blizzard_ItemUpgradeUI` reads it inside `PlayUpgradedCelebration()` one line before `C_ItemUpgrade.UpgradeItem()`, so item upgrades are blocked with `ADDON_ACTION_FORBIDDEN` whenever an item's effect text is long enough to reach the tooltip truncation branch (trinkets in practice). The replacement guards two things Blizzard's original does not — `SafeNumber()` on the `Round()` inputs, and a nil-guard on `GetLeftLine(2)` — and the toggle above exists to determine which, if either, is still required before it can be removed [mainline]


## [12.1.0.1] ##
### Fixed ###

  * fix: CropIcon secret-layer fallback goes to BACKGROUND - ARTWORK painted the border over BORDER-layer aura icons


## [12.1.0.0] ##
### Added ###

  * add: **Social UI skins** for the 12.1 social hub (`SocialUIFrame`, replaces FriendsFrame when Blizzard enables the system) — new `Blizzard_SocialUI` and `Blizzard_SocialUIShared` modules: hub frame, BattleNet bar, pooled side tabs, all six tab content frames (Friends/Recent Allies/Quick Join/Friend Requests/Recruit-a-Friend/Raid), ignore list, broadcast and unavailable-notice dialogs; the existing FriendsFrame skin is untouched and both UIs coexist [mainline]
  * add: **Blizzard_HousingBlueprint** module — blueprint export/import/content-list/rename dialogs, plus the blueprint collections embedded in the House Editor storage panel and the Housing Dashboard [mainline]
  * add: **Blizzard_MicroMenu** module — micro buttons moved to a new Blizzard addon in the classic convergence; restyle-only skin (the new grid layout owns positions), serves era, TBC, and Mists [classic]
  * add: Housing Dashboard **Collection tab** (12.1's third side tab): gear dropdown, content summary, blueprint list, categories sidebar [mainline]
  * add: House Editor **pet customization pane** (chest-style panel: search, filters, scroll list) and pet behavior dropdown in the decor customization pane [mainline]
  * add: CooldownViewer 12.1 surfaces: settings side tabs, **group-buff filter** tab (section headers + pooled item icons; grid layout untouched per CDM taint rules), and both edit-alert dialogs [mainline]
  * add: **Discord integration surfaces**: chat-config additional-colors box with its swatches, and the guild-control Discord rank pane incl. the lazily-created link/unlink frames [mainline]

### Changed ###

  * chg: TOC interface bumped to **120100** (12.1.0 "Curse of Ula'tek") on Mainline and **11509** (Classic Era 1.15.9) on Vanilla
  * chg: **era 1.15.9 shared-codebase convergence** — vanilla skins re-routed to the already-modern TBC equivalents instead of repairing legacy files: BuffFrame (retail `AuraFrameMixin` system), AddOnList (ScrollBox-based), ActionBarController (chrome-only + StatusTrackingBar; per-button skinning retired — the modern button art machinery re-applies atlases, the lesson learned on anniversary), casting bar (`PlayerCastingBarFrame` via `Blizzard_UIPanels_Game`) [vanilla]
  * chg: GameMenu skin rebuilt for the pooled-button `MainMenuFrameTemplate` menu shared by all converged classic clients (the old static-global skin was silently dead on TBC/Mists too) [classic]
  * chg: skins orphaned by 12.1 addon extractions re-routed to their new homes: ColorPickerFrame, SplashFrame, chat bubbles (`Blizzard_ChatBubble`), RolePoll [mainline]
  * chg: `updatexmls.py` v0.3.0 — new `[ExcludeLoadGameType]` TOC directive support, whitespace-agnostic directive parsing (era TOCs use tabs), TBC skin-dir fallback for the Vanilla flavor; all four `AddOns_*.xml` manifests regenerated against current client trees
  * chg: `Blizzard_HousingControls` buttons resolved via the new `GetButtons()` accessor (12.1 moved the visitor buttons under a container) [mainline]
  * chg: Housing Dashboard side tabs restyled for the shared `LargeSideTabButtonTemplate` (12.1 deleted the bespoke template); selection texture flattened but kept functional [mainline]

### Fixed ###

  * fix: era 1.15.9 hard errors at login — `AuraButton_Update`, `MoveMicroButtons`/`MICRO_BUTTONS`, `AddonListForceLoad`, and the deleted `Blizzard_CastingBar` addon all removed from the vanilla skin surface [vanilla]
  * fix: FriendsFrame skin errored on 12.1 — `BattleTagInviteFrame` was deleted; now skins its replacement `BattleNetInviteFrame` (proper parentKeys, no more positional child fishing) [mainline]
  * fix: `UIParentLoadAddOn` removed client-wide in 12.1 — debug-tools loader now uses `DebugTools_LoadUI` with a `C_AddOns.LoadAddOn` fallback [mainline]
  * fix: chat-config swatch hook nil-called on 12.1's new Discord color template, aborting chat settings; unknown swatch templates now degrade to stock [mainline]
  * fix: chat editbox header recolor silently dead since the convergence — Blizzard calls the `ChatFrameEditBoxMixin` method, not the deprecated global; rehooked mixin-copy-aware (table + existing instances) on classic and Mainline [shared]
  * fix: quest-item bag highlight silently dead — `LE_ITEM_CLASS_QUESTITEM` no longer exists on any current client; replaced with `Enum.ItemClass.Questitem` on classic and Mainline [shared]
  * fix: `CovenantCallingsHeaderTemplate` lost `HighlightBackground` in 11.x — use `HighlightTexture` and guard unskinned calling headers [mainline]
  * fix: House Editor dye widgets follow their 12.1 move under `CustomizeComponentContainer` [mainline]


## [12.0.7.2] ##
### Fixed ###

  * fix: remove CooldownViewer grid-padding hook - writing childXPadding/oldGridSettings from addon context tainted the CDM and caused mass secret-value errors at raid-end cinematics [mainline]


## [12.0.7.1] ##
### Added ###

  * add: **Classic Era (Vanilla) support** — new `Aurora_Vanilla.toc` / `AddOns_Vanilla.xml`, full skin coverage across FrameXML and Blizzard AddOns:
  * ActionBarController & MainMenuBar, StanceBar, BuffFrame, CastingBar, ChatFrame
  * ContainerFrame (bags), GameDialog & StaticPopup, GossipFrame, LootFrame
  * MailFrame, MerchantFrame (+ NavButtons backport), MoneyFrame, TradeFrame, TrainerUI, UnitFrame
  * QuestFrame, QuestInfo, QuestLog, CharacterFrame (incl. Reputation/Skills/Honor tabs)
  * WorldMap, Blizzard_GroupFinder_VanillaStyle
  * AddOnList, AuctionUI, BankFrame, BattlefieldFrame, BindingUI, CoinPick, ColorPicker, CraftUI, FriendsFrame, GuildRegistration, HelpFrame, InspectUI, ItemTextFrame, MacroUI, MirrorTimer, Petition, SpellbookFrame, StackSplit, TabardFrame, TaxiFrame, TradeSkillUI
  * shared menu/dropdown/template layer additions (Dialog family, sliders, check/radio buttons), Classic font file, `Util.HideFrameTextures`, CinematicFrame capability fix
  * add: **Burning Crusade Classic (TBC) support** — new `Aurora_TBC.toc`, full skin coverage:
  * CharacterFrame, ActionBarController, QuestInfo/QuestFrame, GossipFrame updates
  * InspectUI, CastingBar, BankFrame, MerchantFrame, WorldMap, TaxiFrame
  * CraftUI, RaidFrame, TradeSkillUI, QuestLog, SpellBookFrame (all pages)
  * spec/glyph/talent/reforge UI
  * 2.5.6 Anniversary-client `[Game]` token TOC-parsing compatibility
  * add: **Mists of Pandaria Classic support** — new `Aurora_Mists.toc`, full skin coverage:
  * LFG/LFR/LFPvP group-finder frames, EncounterJournal, ScenarioFinder
  * item upgrade window (modernized ReforgingUI), Collections (all tabs)
  * QuestLogFrame, QuestInfo, Blizzard_AchievementUI
  * add: `isMists` build-flavor check in Aurora core

### Changed ###

  * chg: HybridScrollFrame made shared across all client flavors
  * chg: TransmogUI enabled for TBC and Mists
  * chg: ArchaeologyUI (5.5.4) shared between Mainline and Mists
  * chg: CharacterFrame and TrimScrollBar shared across flavors
  * chg: shared Classic code paths adjusted to also run correctly on Mists
  * chg: `MainMenuBarBagButtons` no longer skinned on the Anniversary (TBC) client
  * chg: `TradePlayerInputMoneyFrame` intentionally left unskinned on Era — Blizzard's `SetForbidden()` anti-scam hardening prevents addon tampering with trade gold
  * chg: `MoneyInputFrame` coin placement adjusted on Vanilla
  * chg: reworked interface-build detection to accommodate multiple WoW client versions side by side
  * chg: reorganized addon manifest entries so Mainline-only addons load only on the Mainline path, leaving room for the other client builds
  * chg: fixed stale AddOn entry `Blizzard_HousingPhotoSharing` → `Blizzard_PhotoSharing`
  * chg: numerous `AddOns_*.xml` manifest and path updates as Mainline/TBC/Vanilla/Mists skin coverage expanded
  * chg: attempted mitigation of Blizzard_CooldownViewer (CDM) taint/errors occurring at the end of raid/boss-fight cutscenes
  * chg: luacheck configuration fixed so it no longer breaks Aurora nightly builds
  * chg: removed outdated pkgmeta files

### Fixed ###

  * fix: `SubtitlesFrame` backdrop caused a persistent translucent black bar across the bottom of the screen during every movie/cinematic, whether or not subtitle text was on screen; the unconditional backdrop on the full 128px-tall subtitle strip has been disabled ([#179])
  * fix: guard against widget types that expose an invalid `GetName` reference
  * fix: `updatexmls.py` manifest generator made compatible with multiple WoW client versions
  * fix: Aurora test scripts failing to load on Classic clients
  * fix: Era-only guardrails and initial TBC compatibility fixes
  * fix: `[Game]` token substitution in TOC parsing for the 2.5.6 Anniversary client
  * fix: Mainline `Blizzard_Menu` variant handling corrected on Vanilla
  * fix: backdrop safeguard added on Vanilla


## [12.0.7.0] ##
### Added ###

  * add: skin `Blizzard_ExpansionLandingPage`

### Changed ###

  * chg: update progress bar style for dialogs with countdown timers
  * chg: guard `Blizzard_ProfessionsCustomerOrders` tab layout against third-party tab insertions and layout modifications

### Fixed ###

  * fix: hide `TradeRecipientBG` white overlay that made the recipient side of the trade frame appear lighter


## [12.0.5.13] ##
### Fixed ###

  * fix: remove `UIWidgetBaseStatusBarTemplateMixin.InitPartitions` replacement — writing an addon-owned slot on the mixin taints the execution context when nameplate widgets call it from the secure `OnNamePlateAdded` path, causing `GetScaledRect()` to fail


## [12.0.5.12] ##
### Fixed ###

  * fix: track skinned `UIWidget` frames in a separate weak-key table instead of writing `_auroraSkinned` onto the frame to prevent `GetScaledRect()` taint in the secure `OnNamePlateAdded` path
  * fix: remove `SetPoint` and `SetHeight` calls from `QueueStatusEntry` hooks — layout writes on pool entry sub-frames taint frame geometry and crash `QueueStatusEntry_SetMinimalDisplay`


## [12.0.5.11] ##
### Fixed ###

  * fix: remove `MapCanvasScrollControllerMixin` method replacements — direct writes to the mixin table tainted every frame using it, causing `SetPropagateMouseClicks` to fail in the secure pin-acquisition path (`secureexecuterange → AcquirePin → OnAcquired → UpdateMousePropagation`)
  * fix: skip nameplate health/cast bar skinning entirely — `Base.SetBackdrop` writes onto restricted nameplate bar frames, tainting them; that taint propagated into `CompactUnitFrame_UpdateHealPrediction` causing `GetMinMaxValues()` to return "secret number value" errors
  * fix: guard nameplate units in `CompactUnitFrame_UpdateHealthColor` hook — calling `SetStatusBarColor` on nameplate bars tainted the execution context and caused `GetMinMaxValues()` in `UpdateHealPrediction` to return "secret number value" errors
  * fix: remove `GameTooltip_AddWidgetSet` global wrapper — replacing the global with an addon-owned function tainted execution before `RegisterForWidgetSet`, causing `GetUnscaledFrameRect` → `GetScaledRect` to return secret values in widget layout
  * fix: remove `UIWidgetContainerMixin.CreateWidget` global `hooksecurefunc` — callbacks fired inside `CreateWidget` propagated taint into the synchronous `UpdateWidgetLayout → DefaultWidgetLayout → GetScaledRect` call chain for tooltip widget containers


## [12.0.5.10] ##
### Fixed ###
  * fix: skip UIWidget skinning for nameplate `WidgetContainer` to prevent `GetScaledRect` taint in the secure `OnNamePlateAdded` call chain
  * fix: use `Color.button` for inactive `TabSystemButton` tabs so borders remain visible
  * fix: use `Color.button` for inactive Achievement tabs so borders remain visible
  * fix: use `Color.button` for inactive Garrison mission tabs so borders remain visible
  * fix: use `Color.button` for inactive Garrison landing page tabs so borders remain visible


## [12.0.5.9] ##
### Changed ###
  * chg: update TOC for WoW 12.0.7 (120007)

### Fixed ###
  * fix: remove `UpdatePresence` mixin to eliminate `CommunitiesMemberList` taint
  * fix: remove `securecallfunction` wrapper from `GameTooltip_AddWidgetSet` to fix tooltip arithmetic taint ([#178])
  * fix: make `Skin.StatusTrackingBarTemplate` taint-safe ([#178])
  * fix: make `UIWidgetBaseStatusBarTemplate` taint-safe; guard `InitPartitions` bar width with `SafeNumber`
  * fix: use `Color.button` for inactive panel tabs so borders remain visible


## [12.0.5.8] ##
### Fixed ###
  * fix: replace circular CDM cooldown swipe with plain square texture so the overlay covers the full cropped icon area
  * fix: re-apply icon texcoord crop after CDM refreshes the spell texture (`SetTexture` resets coords to 0–1)
  * fix: prevent C stack overflow in SpellBook spec-button border hooks by removing recursive `SetTexture(nil)` calls


## [12.0.5.7] ##
### Changed ###
  * chg: overhaul Blizzard_CooldownViewer skinning in preparation for RealUI_Auras, including robust mixin hooks, viewer child re-skinning on show, icon mask/overlay cleanup, and BuffBar visual restyling
  * chg: use full `Skin.ButtonFrameTemplate` pass for CooldownViewerSettings to align with ButtonFrameTemplate visuals
  * chg: refresh README documentation

### Fixed ###
  * fix: increase HDR mode button brightness to improve visibility against darker panel backgrounds


## [12.0.5.6] ##
### Fixed ###
  * fix: guard `private.Integration` nil check in `Color.SetMode` to prevent errors when called before Integration is initialised


## [12.0.5.5] ##
### Added ###
  * add: **Color Mode system** — switch between named palette presets that control the neutral UI palette (backgrounds, borders) and modulate the class color highlight. All switching is live, no reload required.
  * **Normal** — default Aurora look, unchanged from previous versions
  * **HDR** — deeper blacks, more opaque panels, brighter borders for high-contrast displays
  * **Deuteranopia / Protanopia / Tritanopia** — accessibility modes that shift the class color highlight hue to compensate for color vision deficiencies
  * add: `Color.border` token for UI element borders, used by the mode system
  * add: `Color.SetMode`, `Color.GetActiveMode`, `Color.PreviewMode` API for programmatic mode switching
  * add: color mode radio selector in the Appearance options panel
  * add: HDR info note in options when HDR boost is inactive due to custom highlight override
  * add: palette element tracking system — 500+ frames auto-refresh on mode switch with smart border preservation
  * add: scrollable Appearance options panel to accommodate the new color mode selector


### Changed ###
  * chg: TalkingHeadUI background now uses `Color.panelBg` token instead of lightened `Color.frame` — darker on Normal, true black on HDR ([#177])
  * chg: color consistency audit — replaced hardcoded color values across skin files with `Color.*` tokens; annotated intentionally static colors

### Fixed ###
  * fix(tooltip): make SetTooltipMoney workaround load-order safe ([#176])
  * fix: guard nil dropdown skin calls in FriendsFrame and PlayerSpells


## [12.0.5.4] ##
### Added ###
  * add: skin for Blizzard_FrameXML TalkingHeadUI

### Changed ###
  * chg: update LFGDungeonReadyStatus skinning pass
  * chg: refine icon skinning in MacroUI


### Fixed ###
  * fix: make DelvesCompanionConfigurationFrame skin non-transparent
  * fix: add defensive guard for SendMailFrame.SendMailAttachments ([#174])
  * fix: apply startup UI scale on login
  * fix: make standalone mode reliably skin delayed Blizzard addon loads ([#175])
  * fix: ensure setup popup waits for UI skinning to complete in standalone mode ([#175])


## [12.0.5.3] ##
### Fixed ###
  * fix: prefer base spell texture for PlayerSpells spec icons
  * fix: prevent UIWidget container taint in restricted layout paths
  * fix: wrap GameTooltip_AddWidgetSet in securecallfunction to avoid LayoutFrame secret-number taint
  * fix: prevent PaperDoll stat taint from CharacterFrame skinning
  * fix: use SharedButtonSmallTemplate for dialog buttons (12.0.5)


## [12.0.5.2] ##
### Fixed ###
  * fix: avoid QueueStatusFrame taint by no longer skinning the protected tooltip backdrop directly; queue entries are still skinned via the entry pool
  * fix: protect backdrop vertex coloring on WoW 12.0.5 by converting Aurora Color objects to Blizzard color objects before SetVertexColor


## [12.0.5.1] ##
### Fixed ###
  * fix: handle MovieFrame CloseDialog button nesting change — buttons moved into CloseDialog.Buttons HorizontalLayoutFrame wrapper
  * fix: guard OpenMailFrameIcon removed in 12.0.5 MailFrame update — portrait now managed by ButtonFrameTemplate
  * fix: guard CharacterBag0Slot-CharacterBag3Slot removed from Mainline XML — bags now dynamically created by BagsBarMixin


## [12.0.5.0] ##
### Changed ###
  * chg: bump ## Interface to 120005

### Fixed ###
  * fix: handle MovieFrame CloseDialog button nesting change — buttons moved into CloseDialog.Buttons HorizontalLayoutFrame wrapper
  * fix: guard OpenMailFrameIcon removed in 12.0.5 MailFrame update — portrait now managed by ButtonFrameTemplate
  * fix: guard CharacterBag0Slot-CharacterBag3Slot removed from Mainline XML — bags now dynamically created by BagsBarMixin


## [12.0.1.31] ##
### Changed ###
  * chg: make TextStatusBarText and TextStatusBarTextLarge use outlined fonts

### Fixed ###
  * fix: remove ExternalDefensivesFrame container backdrop to prevent an always-visible empty bar
  * fix: hide LootHistory BackgroundArtFrame textures so item names remain visible


## [12.0.1.30] ##
### Added ###
  * add: skin for Blizzard_HouseEditor — 6-mode editor, deferred mode-frame skinning, hooksecurefunc-only, IsForbidden() guards
  * add: skin for Blizzard_HouseList — house entry list with expand/collapse backdrop hooks
  * add: skin for Blizzard_HousingBulletinBoard — roster list, column headers, invite dialog, pendingInvitesPool wrap
  * add: skin for Blizzard_HousingCharter — charter creation, signaturePool wrap, request signature dialog
  * add: skin for Blizzard_HousingCornerstone — tabbed panel with TabSystem skinning, confirmation dialogs
  * add: skin for Blizzard_HousingCreateNeighborhood — charter and guild neighborhood creation dialogs
  * add: skin for Blizzard_HousingHouseFinder — neighborhood button pools, map canvas border hiding
  * add: skin for Blizzard_HousingHouseSettings — access dropdowns, checkboxes, abandon house dialog
  * add: skin for Blizzard_HousingModelPreview — PortraitFrame with ModelScene left unskinned
  * add: skin for Blizzard_HousingMarketCart — cart items/bundles, CropIcon on icons, FullUpdate re-skin hook
  * add: skin for Blizzard_HousingPhotoSharing — photo preview and browser panels
  * add: skin for Blizzard_GenericShoppingCart — base ShoppingCartVisualsFrameTemplate for all cart consumers
  * add: skin for Blizzard_Subtitles — minimal backdrop with reduced alpha for readability

### Changed ###
  * update: register 13 AddOn skins in AddOns_Mainline.xml — Midnight housing feature complete

### Fixed ###
  * fix: use DefaultPanelTemplate instead of PortraitFrameTemplate for ButtonFrameTemplateNoPortrait frames (HousingCornerstone, HousingPhotoSharing browsers)
  * fix: replace Util.HideNineSlice with direct region hiding for GenericShoppingCart Background NineSlice
  * fix: replace AcquireTab hooksecurefunc with SetTab hook on TabSystemOwner for HouseEditor StoragePanel tabs


## [12.0.1.29] ##
### Added ###
  * add: skin for Blizzard_AlliedRacesUI — race info overlay and abilities
  * add: skin for Blizzard_AutoCompletePopupList — chat autocomplete popup
  * add: skin for Blizzard_ClassTrial — trial dialog and timer, no font mods
  * add: skin for Blizzard_ClickBindingUI — click binding config dialog
  * add: skin for Blizzard_ContentTracking — tracking checkmark guard
  * add: skin for Blizzard_CovenantToasts — covenant choice and renown toasts
  * add: skin for Blizzard_CustomizationUI — character customization frame
  * add: skin for Blizzard_DelvesToast — delves completion toast
  * add: skin for Blizzard_ExpansionTrial — expansion trial checkpoint dialog
  * add: skin for Blizzard_GenericTraitUI — generic trait frame decorations
  * add: skin for Blizzard_GuildRename — guild rename dialog
  * add: skin for Blizzard_ItemBeltFrame — quick-use item belt bar
  * add: skin for Blizzard_MajorFactions — renown and unlock toasts
  * add: skin for Blizzard_NamePlates — health/cast bars, aura icons, hooksecurefunc only
  * add: skin for Blizzard_ObliterumUI — Legion obliterum forge
  * add: skin for Blizzard_PerksProgram — Trading Post product browser
  * add: skin for Blizzard_PlunderstormPrematchUI — Plunderstorm lobby
  * add: skin for Blizzard_ProfessionsCustomerOrders — crafting order panels
  * add: skin for Blizzard_QuestTimer — timed quest countdown frame
  * add: skin for Blizzard_QuickKeybind — keybind dialog, tooltip untouched
  * add: skin for Blizzard_RemixArtifactUI — MoP Remix artifact talent frame
  * add: skin for Blizzard_ReportFrame — player report dialog
  * add: skin for Blizzard_RuneforgeUI — Shadowlands legendary crafting
  * add: skin for Blizzard_SharedTalentUI — talent tree nodes and frame
  * add: skin for Blizzard_StableUI — pet stable management panel

### Changed ###
  * update: register 25 AddOn skins in AddOns_Mainline.xml

### Fixed ###
  * fix: guard NameFrame nil in LargeItemButtonTemplate for PVP loot buttons
  * fix: taint-safe PVP queue/join button skinning to prevent JoinBattlefield ADDON_ACTION_FORBIDDEN


## [12.0.1.28] ##
### Added ###
  * add: skin for Blizzard_DamageMeter — EditMode child-visual-only with ScrollBox entry skinning
  * add: skin for Blizzard_EncounterTimeline — EditMode child-visual-only with EventRegistry callback
  * add: skin for Blizzard_EncounterWarnings — EditMode child-visual-only, no SetAttribute/GetStringWidth
  * add: skin for Blizzard_CooldownViewer — EditMode child-visual-only with external weak table for taint-safe skinned state
  * add: skin for Blizzard_BuffFrame — hooksecurefunc-only approach for taint-sensitive aura update paths
  * add: skin for Blizzard_MatchmakingQueueDisplay — queue type buttons, ready/leave buttons
  * add: skin for Blizzard_EndOfMatchUI — 3 pool wraps with PVPMatch color coordination
  * add: skin for Blizzard_PersonalResourceDisplay — health/power/alternate StatusBars with Util.Mixin re-skin hooks
  * add: skin for Blizzard_SpellDiminishUI — trayItemPool wrap via Util.Mixin
  * add: skin for Blizzard_WorldLootObjectList — ScrollBox acquired frame callback
  * add: skin for Blizzard_CombatLog — quick-filter buttons and filter bar backdrop
  * add: skin for Blizzard_ScriptErrorsFrame — UIPanelDialogTemplate dialog with nav/action buttons
  * add: skin for Blizzard_HelpPlate — hooksecurefunc on HelpPlate.Show for dynamic tiles
  * add: skin for Blizzard_DelvesCompanionConfiguration — config slots, ability list, paging controls

### Fixed ###
  * fix: CooldownViewer taint — use external weak table instead of writing _auroraSkinned on item frames to avoid tainting secure cooldown/aura update paths
  * fix: CooldownViewer EnumeratePools crash — categoryPool is a plain table, not a FramePoolCollection
  * fix: CooldownViewer CharacterSpecificLayoutCheckButton — target inner .Button child instead of wrapper frame for Skin.FrameTypeCheckButton


## [12.0.1.27] ##
### Added ###
  * add: Util.SkinOnce helper and convert 30 guard patterns
  * add: Base.CropCircularIcon to consolidate circular icon cropping
  * add: Util.SetHighlightColor to consolidate highlight color texture calls

### Changed ###
  * ci: trim CHANGELOG.md to current version section for GitHub releases

### Fixed ###
  * fix: replace GetBackdrop call with _auroraSkinned check to prevent nil method error in combat


## [12.0.1.26] ##
### Added ###
  * add: Hero Talents anchor preset dropdown to config with preset-based positioning
  * add: optional HeroTalentsContainer custom re-anchor with default-off per-character behavior

### Changed ###
  * chg: additional tuning for heroTalentsAnchorPreset
  * chg: updated AddOns_Mainline.xml with data from wow-ui-sources
  * chg: ignore Mists TOC types when running on live branch
  * chg: removed deprecated Blizzard_UIMenu code

### Fixed ###
  * fix: restore backdrop alpha transparency in Base.SetBackdropColor (#171)
  * fix: re-parent item Name into bg frame to fix hidden text
  * fix: move MainMenuBarBagButtons skin to standalone Blizzard_MainMenuBarBagButtons addon
  * fix: move TabSystemTemplates.lua to Shared/TabSystem/ to match Blizzard restructure
  * fix: unused file detection in updatexmls.py — scope bug, stale addon, remove XML fallback


## [12.0.1.25] ##
### Changed ###
  * chg: continued work on PVPMatchResults skin

### Fixed ###
  * fix: replace securecallfunction wrapper with SafeNumber reimplementation for GameTooltip_AddWidgetSet to avoid secret-number taint
  * fix: remove securecallfunction branches and sanitize orderIndex after Setup calls
  * fix: wrap QuestMapLogTitleButton_OnEnter in securecallfunction to prevent GetStringWidth secret number taint
  * fix: SafeNumber for all InsertFrame tooltip paths and LootHistory tooltip line layout
  * fix: pass RGBA values to backdrop APIs instead of Aurora Color objects
  * fix: Aurora NineSlice layout resolution for tooltip backdrop hooks


## [12.0.1.24] ##
### Fixed ###
  * fix: update DelvesDifficultyPicker to skin its dropdown with DropdownButton instead of the old WowStyle1DropdownTemplate
  * fix: stop skinning pooled QuestMapFrame title rows to avoid tooltip-owner taint in the quest log


## [12.0.1.23] ##
### Fixed ###
  * fix: call GameTooltip_AddWidgetSet via securecallfunction to prevent secret layoutIndex taint on delve tooltip hide
  * fix: removed taint from titleFramePool
  * fix: AdventureMapFrame nil error by hooking AdventureMapMixin:OnLoad for pool wrap


## [12.0.1.22] ##
### Fixed ###
  * fix: race condition in VisitHouse
  * fix: protect against AuroraConfig being nil on embedded Aurora


## [12.0.1.21] ##
### Added ###
  * add: skins for Blizzard_CovenantCallings, Blizzard_DelvesDifficultyPicker, Blizzard_HousingControls, Blizzard_HousingTemplates, and PVP match results

### Changed ###
  * chg: expand pooled-frame skinning across housing dashboard rewards, weekly rewards extra items, adventure map widgets, quest map frames, queue status entries, chat config tabs, campaign headers, and transmog collection/set buttons
  * chg: consolidate pooled frame acquisition helpers into Util.WrapPoolAcquire and remove the obsolete WardrobeOutfits shim
  * chg: stop touching CommunitiesListEntryTemplate buttons at runtime to keep Communities skinning combat-safe

### Fixed ###
  * fix: taint-safe tooltip status/progress bar skinning and securecallfunction wrapping for DefaultWidgetLayout to avoid UIWidget secret-number layout errors (WoWUIBugs[#811])
  * fix: replace SetTooltipMoney with GetCoinTextureString to avoid MoneyFrame secret-number taint in tooltips (WoWUIBugs[#801])
  * fix: remove taint-unsafe ChannelRoster skinning that could break voice activity notifications
  * fix: make VehicleLeaveButton and TaintSafeUIPanelButtonTemplate skinning safe, and align auxiliary/zone ability cooldown overlays
  * fix: follow wardrobe custom set renames and guard campaign header/map canvas edge cases


## [12.0.1.20] ##
### Added ###
  * add: GUI toggles for character sheet, objective tracker, and talent background skins ([#151], [#158], [#160])
  * add: Color.panelBg constant and unified panel background colors ([#155])
  * add: SetSize clamping hook to crafting order tabs ([#167])
  * add: config and compatibility foundations ([#151], [#158], [#160], [#167])

### Changed ###
  * chg: gate character sheet skin on config toggle ([#151])
  * chg: gate objective tracker skin on config toggle ([#158])
  * chg: gate talent background hiding on config toggle ([#160])
  * chg: clamp PlayerChoice frame to screen bounds ([#164])
  * chg: reduce border width on Achievement and Loot frames ([#157])
  * chg: talentArtBackground defaults to true


## [12.0.1.19] ##
### Changed ###
  * chg: Add taint-safe frame skinning for high-risk protected-function frames (ItemUpgrade, ItemInteraction, Scrapping, AzeriteEssence, AzeriteUI)
  * chg: call Base.CropIcon(texture) without the parent argument to avoid tainting button geometry

### Fixed ###
  * fix: nil texture name crash in ClubFinder role icons and SetTexture assertion
  * fix: move CUSTOM_CLASS_COLORS early-return guard below private definitions so they're always available to host addons
  * fix: duplicate scale message on login in dev mode
  * fix: remove GetUnscaledFrameRect override that tainted GameMenu secure callback path [#166]
  * fix: taint-safe replacement for GameTooltip_AddWidgetSet in SharedTooltipTemplates.lua
  * fix: taint-safe status bar skinning to prevent OverlayPlayerCastingBarFrame taint propagating into action bar secure execution path


## [12.0.1.18] ##
### Changed ###
  * chg: stop aroura from doing any scaling when a host addon is handling scaling..


## [12.0.1.17] ##
### Fixed ###
  * fix: UIWidgetContainerMixin is tainting again
  * fix: replace GameTooltip_InsertFrame to avoid taint
  * fix: replaced $$$$%%%%$$$$$ to just #'s


## [12.0.1.16] ##
### Added ###
  * add: configurable GC tuning modes (smooth / default / combat-pause) to reduce microstutter — selectable in Aurora settings UI
  * add: object pooling for Color objects and backdrop tables, plus a reusable NineSlice layout, to eliminate per-frame table allocations feeding GC pressure
  * add: GC settings UI available in both Aurora standalone config and when used with other addons


## [12.0.1.15] ##
### Fixed ###
  * fix: attempt to fix potentional stutter issues when using large amount of memory.. GC is an issue
  * fix: taint safe skinning of  LFGPVP Join Battle button..
  * fix: taint-safe Blizzard_Communities skin — remove FrameTypeButton/CreateTexture/SetBackdrop from list entries and ScrollBox, guard UpdatePresence with InCombatLockdown()
  * fix: more attempts of fixing taints in tables for widgets


## [12.0.1.14] ##
### Fixed ###
  * fix: attempt to fix [#149]
  * fix: another attempt on uiwidgets fixes


## [12.0.1.13] ##
### Added ###
  * add: skinning of VehicleLeaveButton [#125]

### Fixed ###
  * fix: PlayerChoice frames being too high (Worldsoul Memories) [#156]
  * fix: Tradeskills screen with addon TradeSkillFluxCapacitor buttons out of bonds [#154]
  * fix: skin of custom tabs in QuestMapFrame.... and removed border from Tabs
  * fix: VehicleLeaveButton skinning [#125]


## [12.0.1.12] ##
### Fixed ###
  * fix: Widget containers parented to a GameTooltip must NOT be skinned.
  * chg: somewhat taint safe Blizzard_WorldMap -- until we allow it to be moved...
  * fix: QuestMapFrame Tabs to be skinned and not repositioned..
  * fix: more taint fixes for tooltips
  * fix: trying to make GameTooltip taint safe


## [12.0.1.11] ##
### Fixed ###
  * fix: Revert GetUnscaledFrameRect global replacement — overwriting this global taints every LayoutFrame call, causing massive CooldownViewer combat taint.

## [12.0.1.10] ##
### Fixed ###
  * fix: Protect GetUnscaledFrameRect against secret (tainted) values from GetScaledRect.
  * fix: ADDON_LOADED contaminates the execution context that feeds into the action bar initialization chain.

## [12.0.1.9] ##
### Added ###
  * add: skin for Blizzard_Transmog
  * add: three new reusable Skin.* functions to SharedUIPanelTemplates.lua: Skin.InputBoxNineSliceTemplate, Skin.InputBoxInstructionsNineSliceTemplate and Skin.SearchBoxNineSliceTemplate

### Changed ###
  * chg: cleaned up Blizzard_Communities
  * chg: Replaced deprecated calls with current API in AdventureMap skin.

### Fixed ###
  * fix: another taint in communitiesListScrollBox
  * fix: only hide ScrollBar borders when they exist
  * fix: safeguarding possible taints from in-combat issues
  * fix: replacing more out of date calls
  * fix: deprecated ui calls


## [12.0.1.8] ##
### Fixed ###
  * fix: possible "Texture:SetTextCoord(): Cannot set tex coords when texture has mask" error
  * fix: Aurora.test loot windows and roll behavior
  * fix: additional Aurora Test Loot fixes
  * fix: update "Running on" UI information
  * fix: Blizzard_BlackMarketUI and gfx crash


## [12.0.1.7] ##
### Added ###
  * add: Blizzard_HousingDashboard skin
  * add: skin for EventToastManager

### Fixed ###
  * fix: another tain in UIWidgets
  * fix: hooking of alerts
  * fix: for uiscale
  * fix: random taints
  * fix: uiScale taints
  * fix: error in Blizzard_CompactRaidFrames
  * fix: updates to Blizzard_HousingDashboard


## [12.0.1.6] ##
### Fixed ###
  * fix: skinning of BankFrame
  * fix: skins for PVEFrame tabs
  * fix: Blizzard_AddOnList - skinning AddonList entries
  * fix: skin - replace removed convertToGroup/convertToRaid with new settings button in CompactRaidFrameManager
  * fix: removed dead code from GossipFrame
  * fix: AlertFrameSystem - updated to cover all 31 alert systems (up from 8)
  * fix: safeguard Util.Mixin
  * fix: RecruitAFriendRewardsFrame.rewardPool can no longer use ObjectPoolMixin
  * fix: ZoneAbilityFrameTemplate
  * fix: replacement of dead Hook.ObjectPoolMixin with proper acquires
  * fix: removed deprecated Wardrobe code from Collections
  * fix: ArchaeologyUI fixes
  * fix: skinning of AchievementUI was incomplete
  * fix: cleaned up deprecated code in Blizzard_ArchaeologyUI
  * fix: Blizzard_TimeManager to no longer use deprecated APIs
  * fix: skin StopwatchResetButton/StopwatchPlayPauseButton from Blizzard_TimeManager
  * fix: SpecificScrollBox taint
  * fix: LFD/LFG/LFR fixes for Frames/RaidFinder
  * fix: partly fixed taint bug in the Blizzard_Communities - Guild Finder
  * fix: instanceButton gets garbled by DropIcon
  * fix: updated ObjectiveTracker for WOW11+
  * fix: Blizzard_StaticPopup_Game_GameDialog updated for WOW12
  * fix: Blizzard_ActionBarController updated for wow12
  * fix: updated OrderHallUI for wow12
  * fix: Blizzard_AuctionHouseUI for wow12
  * fix: updated Blizzard_Collections for wow12
  * fix: updated Blizzard_Collections ToggleDynamicFlightFlyoutButton
  * fix: LFGList menus
  * fix: added fixes to FriendsFrame

### Changed ###
  * chg: update for wow12 compatibility
  * chg: cleanup deprecated compatibility API from deprecated.lua
  * chg: cleaned up Blizzard_UIPanels_Game QuestMapFrame

### Removed ###
  * removed: Hook.ObjectPoolMixin removed in 11.0.0 (private API), no replacement
  * removed: Blizzard_SharedXMLBase\Pools.lua - dead code
  * removed: unused and outdated code from Blizzard_Calendar

## [12.0.1.5] ##
### Added ###
  * add: skinning Blizzard_Professions
  * add: skinning of all Blizzard_PlayerSpells panels
  * add: skinning of PlayerChoice

### Fixed ###
  * fix: arrow down on dropdown buttons
  * fix: skinned Blizzard_ProffesionsBook
  * fix: don't skin CommunitiesList ScrollBox to prevent SetAvatarTexture taint
  * fix: backdrops and playchoice fixes
  * fix: skinning of all Blizzard_PlayerSpells panels
  * fix: SpellBookFrame skinned properly
  * fix: skinning of PlayerChoice

### Removed ###
  * removed: Blizzard_PlayerSpellsFrame.lua duplicates Blizzard_PlayerSpells.lua

## [12.0.1.4] ##
### Fixed ###
  * fix: use SetAlpha(0) instead of Hide() on LFG InfoBackground
  * fix: Lua error ui widget [#146]
  * fix: Error on certain mouseovers that impacts mouseover tooltips afterwards [#147]
  * fix: quit catch-up button doesn't show up [#148]
  * fix: fixed error "calling 'SetAlpha' on bad self" when nameplate widget containers are registered with pooled/recycled frames (Blizzard_UIWidgets) [#139]
  * fix: isMidnight starts with 12.0.0

### Changed ###
  * chg: remove isPatch as it is no longer used


## [12.0.1.3] ##

** wrongly tagged **

## [12.0.1.2] ##
### Fixed ###
  * fix: Protect from calling GetStatusBarTexture on invalid objects
  * fix(aurora): guard backdrop setup on forbidden/invalid frames to prevent NineSlice CreateTexture crashes in UIWidgets/nameplates
  * fix: Updated DeathRecap skin for WoW 12 API changes
  * fix: Wrapped debug name handling to safely process tainted/secret strings from WoW API values


### Changed ###
  * chg: Added Blizzard_PlayerSpells skinning and follow-up cleanup
  * chg: Updated Aurora options menu
  * chg: Updated updatexmls.py for WoW 12 XML changes
  * chg: Added configuration management system, color/highlight management, theme/frame processing, and configuration UI
  * chg: Integrated analytics/external systems and finalized integration polish
  * chore: linting updates


## [12.0.1.1] ##
### Fixed ###
  * fix: Added a nil check to the CropIcon function in api.lua. Gethe/Aurora#145
  * chg: prevents Aurora from interfering with Chonky Character Sheet's modifications to the character frame Gethe/Aurora#142
  * fix(aurora): apply proper Aurora styling to game menu buttons Gethe/Aurora#143
  * chg: Cleaned up ChatFrame
  * fix(aurora): sanitize chat sender names to avoid secret-string taint
  * fix(aurora): guard UIWidget debug name calls against tainted frames
  * fix: crash path in the chat bubble skin.
  * fix: prevents secret-value violations in chatbubbles


## [12.0.1.0] ##
### Fixed ###
  * chg: Hook_SetStatusBarTexture now uses pcall when indexing private.assetColors (prevents protected/secret-index error)
  * chg: fix 12.0.1 tables now being secret
  * chg: combat-safeMultiActionBar skinning so the action bar buttons are only skinned out of combat


## [12.0.0.2] ##
### Fixed ###
  * chg: fix hooking of SetPortraitToTexture and BuildIconArray if they exist
  * chg: avoid passing secret widgetSizeSetting into SetWidth.
  * fix: chatframe errors in raid


## [12.0.0.1] ##
### Fixed ###
  * chg: intial EventsFrame list setup (intial idea found from Wetxius/ShestakUI)
  * chg: fixes to GameMenu to not taint shop
  * chg; updates to PVEFrame and Blizzard_PVPUI
  * chg: updated Blizzard_EncounterJournal
  * chg: only skin FrameTypeButton SetNormalTexture when SetNormalTexture exists
  * chg: skin EncounterJournalJourneysTab
  * fix: DressUpFrame fixes for wow12
  * chg: skin TutorialsFrame.Contents.StartButton


## [12.0.0.0] ##
### Fixed ###
  * fix: added back removed Skin.FrameTypeScrollBarButton ...
  * chg: updated AddOns_Mainline.xml file
  * fix: removed some references to F.Reskin* (deprecated code) with newer Skin.. for BlackMarketFrame
  * chg: SetsTransmogFrame, WardrobeFrame and WardrobeTransmogFrame removed - disabled code for now
  * fix: LFGRoleButtonTemplate missing Button - catch error
  * chg: remove old debug messages left in the codebase
  * fix: Aurora AddOn Config window fix and /slashcmd fix
  * chg: ChatEdit_UpdateHeader is now ChatFrameEditBoxMixinUpdateHeader so renaming functions
  * beta: wrappers to make things run in beta
  * chore: toc update for beta


## Detailed Changes ##
[Unreleased]: https://github.com/RealUI/Aurora/compare/12.1.5.4...develop
[12.1.5.4]: https://github.com/RealUI/Aurora/compare/12.1.5.3...12.1.5.4
[12.1.5.3]: https://github.com/RealUI/Aurora/compare/12.1.5.2...12.1.5.3
[12.1.5.2]: https://github.com/RealUI/Aurora/compare/12.1.5.1...12.1.5.2
[12.1.5.1]: https://github.com/RealUI/Aurora/compare/12.1.5.0...12.1.5.1
[12.1.5.0]: https://github.com/RealUI/Aurora/compare/12.1.0.15...12.1.5.0
[12.1.0.15]: https://github.com/RealUI/Aurora/compare/12.1.0.14...12.1.0.15
[12.1.0.14]: https://github.com/RealUI/Aurora/compare/12.1.0.13...12.1.0.14
[12.1.0.13]: https://github.com/RealUI/Aurora/compare/12.1.0.12...12.1.0.13
[12.1.0.12]: https://github.com/RealUI/Aurora/compare/12.1.0.11...12.1.0.12
[12.1.0.11]: https://github.com/RealUI/Aurora/compare/12.1.0.10...12.1.0.11
[12.1.0.10]: https://github.com/RealUI/Aurora/compare/12.1.0.9...12.1.0.10
[12.1.0.9]: https://github.com/RealUI/Aurora/compare/12.1.0.8...12.1.0.9
[12.1.0.8]: https://github.com/RealUI/Aurora/compare/12.1.0.7...12.1.0.8
[12.1.0.7]: https://github.com/RealUI/Aurora/compare/12.1.0.6...12.1.0.7
[12.1.0.6]: https://github.com/RealUI/Aurora/compare/12.1.0.5...12.1.0.6
[12.1.0.5]: https://github.com/RealUI/Aurora/compare/12.1.0.4...12.1.0.5
[12.1.0.4]: https://github.com/RealUI/Aurora/compare/12.1.0.3...12.1.0.4
[12.1.0.3]: https://github.com/RealUI/Aurora/compare/12.1.0.2...12.1.0.3
[12.1.0.2]: https://github.com/RealUI/Aurora/compare/12.1.0.1...12.1.0.2
[12.1.0.1]: https://github.com/RealUI/Aurora/compare/12.1.0.0...12.1.0.1
[12.1.0.0]: https://github.com/RealUI/Aurora/compare/12.0.7.2...12.1.0.0
[12.0.7.2]: https://github.com/RealUI/Aurora/compare/12.0.7.1...12.0.7.2
[12.0.7.1]: https://github.com/RealUI/Aurora/compare/12.0.7.0...12.0.7.1
[12.0.7.0]: https://github.com/RealUI/Aurora/compare/12.0.5.13...12.0.7.0
[12.0.5.13]: https://github.com/RealUI/Aurora/compare/12.0.5.12...12.0.5.13
[12.0.5.12]: https://github.com/RealUI/Aurora/compare/12.0.5.11...12.0.5.12
[12.0.5.11]: https://github.com/RealUI/Aurora/compare/12.0.5.10...12.0.5.11
[12.0.5.10]: https://github.com/RealUI/Aurora/compare/12.0.5.9...12.0.5.10
[12.0.5.9]: https://github.com/RealUI/Aurora/compare/12.0.5.8...12.0.5.9
[12.0.5.8]: https://github.com/RealUI/Aurora/compare/12.0.5.7...12.0.5.8
[12.0.5.7]: https://github.com/RealUI/Aurora/compare/12.0.5.6...12.0.5.7
[12.0.5.6]: https://github.com/RealUI/Aurora/compare/12.0.5.5...12.0.5.6
[12.0.5.5]: https://github.com/RealUI/Aurora/compare/12.0.5.4...12.0.5.5
[12.0.5.4]: https://github.com/RealUI/Aurora/compare/12.0.5.3...12.0.5.4
[12.0.5.3]: https://github.com/RealUI/Aurora/compare/12.0.5.2...12.0.5.3
[12.0.5.2]: https://github.com/RealUI/Aurora/compare/12.0.5.1...12.0.5.2
[12.0.5.1]: https://github.com/RealUI/Aurora/compare/12.0.5.0...12.0.5.1
[12.0.5.0]: https://github.com/RealUI/Aurora/compare/12.0.1.31...12.0.5.0
[12.0.1.31]: https://github.com/RealUI/Aurora/compare/12.0.1.30...12.0.1.31
[12.0.1.30]: https://github.com/RealUI/Aurora/compare/12.0.1.29...12.0.1.30
[12.0.1.29]: https://github.com/RealUI/Aurora/compare/12.0.1.28...12.0.1.29
[12.0.1.28]: https://github.com/RealUI/Aurora/compare/12.0.1.27...12.0.1.28
[12.0.1.27]: https://github.com/RealUI/Aurora/compare/12.0.1.26...12.0.1.27
[12.0.1.26]: https://github.com/RealUI/Aurora/compare/12.0.1.25...12.0.1.26
[12.0.1.25]: https://github.com/RealUI/Aurora/compare/12.0.1.24...12.0.1.25
[12.0.1.24]: https://github.com/RealUI/Aurora/compare/12.0.1.23...12.0.1.24
[12.0.1.23]: https://github.com/RealUI/Aurora/compare/12.0.1.22...12.0.1.23
[12.0.1.22]: https://github.com/RealUI/Aurora/compare/12.0.1.21...12.0.1.22
[12.0.1.21]: https://github.com/RealUI/Aurora/compare/12.0.1.20...12.0.1.21
[12.0.1.20]: https://github.com/RealUI/Aurora/compare/12.0.1.19...12.0.1.20
[12.0.1.19]: https://github.com/RealUI/Aurora/compare/12.0.1.18...12.0.1.19
[12.0.1.18]: https://github.com/RealUI/Aurora/compare/12.0.1.17...12.0.1.18
[12.0.1.17]: https://github.com/RealUI/Aurora/compare/12.0.1.16...12.0.1.17
[12.0.1.16]: https://github.com/RealUI/Aurora/compare/12.0.1.15...12.0.1.16
[12.0.1.15]: https://github.com/RealUI/Aurora/compare/12.0.1.14...12.0.1.15
[12.0.1.14]: https://github.com/RealUI/Aurora/compare/12.0.1.13...12.0.1.14
[12.0.1.13]: https://github.com/RealUI/Aurora/compare/12.0.1.12...12.0.1.13
[12.0.1.12]: https://github.com/RealUI/Aurora/compare/12.0.1.11...12.0.1.12
[12.0.1.11]: https://github.com/RealUI/Aurora/compare/12.0.1.10...12.0.1.11
[12.0.1.10]: https://github.com/RealUI/Aurora/compare/12.0.1.9...12.0.1.10
[12.0.1.9]: https://github.com/RealUI/Aurora/compare/12.0.1.8...12.0.1.9
[12.0.1.8]: https://github.com/RealUI/Aurora/compare/12.0.1.7...12.0.1.8
[12.0.1.7]: https://github.com/RealUI/Aurora/compare/12.0.1.6...12.0.1.7
[12.0.1.6]: https://github.com/RealUI/Aurora/compare/12.0.1.5...12.0.1.6
[12.0.1.5]: https://github.com/RealUI/Aurora/compare/12.0.1.4...12.0.1.5
[12.0.1.4]: https://github.com/RealUI/Aurora/compare/12.0.1.3...12.0.1.4
[12.0.1.3]: https://github.com/RealUI/Aurora/compare/12.0.1.2...12.0.1.3
[12.0.1.2]: https://github.com/RealUI/Aurora/compare/12.0.1.1...12.0.1.2
[12.0.1.1]: https://github.com/RealUI/Aurora/compare/12.0.1.0...12.0.1.1
[12.0.1.0]: https://github.com/RealUI/Aurora/compare/12.0.0.2...12.0.1.0
[12.0.0.2]: https://github.com/RealUI/Aurora/compare/12.0.0.1...12.0.0.2
[12.0.0.1]: https://github.com/RealUI/Aurora/compare/12.0.0.0...12.0.0.1
[12.0.0.0]: https://github.com/RealUI/Aurora/compare/11.2.7.2...12.0.0.0
