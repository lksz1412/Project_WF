-- ============================================================
-- MythicTimer - Localization
-- Detected via GetLocale(). Supported : frFR, frCA, everything else = enUS.
-- Access via MT.L["key"]
-- ============================================================
local MT = MythicTimerAddon

local locale = GetLocale()
local L = {}
MT.L = L

-- ================================================================
-- ENGLISH (default)
-- ================================================================
L["ADDON_LOADED"]          = "|cff00aaffMythicTimer|r loaded! Type |cffffff00/myt|r for help."
L["KEY_STARTED"]           = "|cff00aaffMythicTimer|r: +%d key started in %s!"
L["KEY_FINISHED"]          = "|cff00aaffMythicTimer|r: Key finished! Result: %s in %s"

L["WAITING_KEY"]           = "Waiting for a key..."
L["ELAPSED"]               = "%s elapsed"
L["DEATHS_NONE"]           = "Deaths: 0 (+0 sec)"
L["DEATHS_FMT"]            = "|cffff4444Deaths: %d (+%d sec)|r"
L["DEATHS_TOOLTIP_TITLE"]  = "|cffff4444Deaths during the key|r"
L["TRASH_PCT"]             = "Trash: %.1f%%"
L["TRASH_NA"]              = "|cffaaaaaa Trash: N/A|r"
L["TRASH_FULL"]            = "|cffff4444Trash: 100%% [FULL]|r"
L["TRASH_FULL_OVER"]       = "|cffff4444Trash: 100%% [FULL] |cffdd8888(+%.1f%%)|r"
L["TRASH_ETA"]             = "ETA trash: ~%s"

L["RESULT_TITLE"]          = "|cff00aaffMythic+|r Timer  -  Results"
L["RESULT_P3"]             = "+3"
L["RESULT_P2"]             = "+2"
L["RESULT_TIMED"]          = "Timed"
L["RESULT_FAIL"]           = "Failed"
L["TIME_AHEAD"]            = "|cff00ff00+%s ahead|r"
L["TIME_OVER"]             = "|cffff4444-%s overtime|r"
L["TIME_LIMIT"]            = "|cffaaaaaa(limit: %s)|r"
L["BOSS_HEADER_NONE"]      = "|cffaaaaaa  Bosses (none detected)|r"
L["BOSS_HEADER_FMT"]       = "|cff99ccff  Bosses  (%d killed)|r"
L["DEATHS_RECAP_NONE"]     = "|cff00ff00No deaths|r"
L["DEATHS_RECAP_FMT"]      = "|cffff4444Deaths: %d  (+%d sec penalty)|r"
L["BTN_CLOSE"]             = "Close"
L["BTN_LOCK_RESULT"]       = "Lock pos."
L["BTN_UNLOCK_RESULT"]     = "Unlock pos."
L["OPT_BTN_RESULT_POS"]    = "Position results window"
L["SLASH_RESULT_PREVIEW"]  = "|cff00aaffMythicTimer|r: Results window shown. Drag to reposition."
L["SLASH_RESULT_SHOWN"]    = "|cff00aaffMythicTimer|r: Last run results displayed."
L["OPT_PROGRESS_LABEL"]    = "Trash display:"
L["OPT_PROGRESS_BAR"]      = "Bar"
L["OPT_PROGRESS_TEXT"]     = "Text only"
L["SLASH_BARMODE_BAR"]     = "|cff00aaffMythicTimer|r: Progress display -> |cffffff00bar|r."
L["SLASH_BARMODE_TEXT"]    = "|cff00aaffMythicTimer|r: Progress display -> |cffffff00text|r."

L["OPT_TITLE"]             = "|cff00aaffMythic+|r Timer - Options"
L["OPT_LOCK"]              = "Lock window position"
L["OPT_HIDE_BLIZZ"]        = "Hide Blizzard timer in keys"
L["OPT_SEC_TIMER"]         = "Timer window"
L["OPT_SEC_DEATH"]         = "Death alerts"
L["OPT_SEC_MISC"]          = "Windows & tools"
L["OPT_DEATH_SOUND"]       = "Play sound on death"
L["OPT_DEATH_ALERT"]       = "Show text alert on death"
L["DEATH_ALERT_FMT"]       = "%s died!"
L["DEATH_ALERT_UNKNOWN"]   = "A party member died!"
L["OPT_BTN_HISTORY"]       = "Show run history"
L["OPT_BTN_CLEAR"]         = "Clear history"
L["OPT_BTN_CENTER"]        = "Recenter timer window"
L["OPT_SCALE"]             = "Window size"
L["OPT_OPACITY"]           = "Background opacity"
L["OPT_MINIMAP"]           = "Show minimap button"
L["OPT_LOCK_RESULT"]       = "Lock results window position"
L["OPT_BTN_TEST"]          = "Test"
L["OPT_BTN_TOGGLE_TIMER"]  = "Show / hide timer"
L["OPT_BTN_FORCES"]        = "M+ Forces panel"
L["OPT_CONFIRM_CLEAR"]     = "Clear the whole run history?"
L["OPT_FOOTER_HINT"]       = "Type /myt for commands"
L["OPT_SETTINGS_DESC"]     = "Options open in their own window."
L["OPT_BTN_OPEN"]          = "Open options"
L["OPT_FOOTER_CLEARED"]    = "|cff00aaffMythicTimer|r: History cleared."
L["OPT_FOOTER_CENTERED"]   = "|cff00aaffMythicTimer|r: Position reset."

L["SLASH_WINDOW_SHOWN"]    = "|cff00aaffMythicTimer|r: Window shown."
L["SLASH_WINDOW_HIDDEN"]   = "|cff00aaffMythicTimer|r: Window hidden."
L["SLASH_LOCKED"]          = "|cff00aaffMythicTimer|r: Window locked."
L["SLASH_UNLOCKED"]        = "|cff00aaffMythicTimer|r: Window unlocked (drag to move)."
L["SLASH_RESET"]           = "|cff00aaffMythicTimer|r: Position reset."
L["SLASH_BLIZZ_HIDDEN"]    = "|cff00aaffMythicTimer|r: Blizzard timer |cffff4444hidden|r during keys."
L["SLASH_BLIZZ_SHOWN"]     = "|cff00aaffMythicTimer|r: Blizzard timer |cff00ff00shown|r."
L["HIST_TITLE"]            = "|cff00aaffMythic+|r Timer - History"
L["HIST_EMPTY"]            = "No runs recorded yet."
L["HIST_CHAR"]             = "By: %s"
L["HIST_TIME"]             = "Time: %s"
L["HIST_DEATHS"]           = "Deaths: %d"
L["HIST_NO_DEATHS"]        = "|cff00ff00No deaths|r"

L["SLASH_NO_HISTORY"]      = "|cff00aaffMythicTimer|r: No runs recorded."
L["SLASH_HISTORY_TITLE"]   = "|cff00aaffMythicTimer|r - |cffffff00Last 10 runs:|r"
L["SLASH_HISTORY_ROW"]     = "  |cffaaaaaa%s|r |cffffff00+%d|r %s - %s - %d death(s) - %s"
L["SLASH_HISTORY_CLEARED"] = "|cff00aaffMythicTimer|r: History cleared."
L["SLASH_MINIMAP"]         = "|cff00aaffMythicTimer|r: Minimap button repositioned."
L["SLASH_HELP"] = {
    "|cff00aaffMythicTimer|r - Available commands:",
    "  |cffffff00/myt show|r         - Show the window",
    "  |cffffff00/myt hide|r         - Hide the window",
    "  |cffffff00/myt lock|r         - Lock position",
    "  |cffffff00/myt unlock|r       - Unlock position",
    "  |cffffff00/myt reset|r        - Recenter window",
    "  |cffffff00/myt default|r      - Toggle Blizzard timer",
    "  |cffffff00/myt history|r      - Show last 10 runs",
    "  |cffffff00/myt clearhistory|r - Clear history",
    "  |cffffff00/myt result|r        - Show results window",
    "  |cffffff00/myt barmode|r       - Toggle bar/text progress",
}
L["COUNTDOWN_FMT"]         = "|cffffff00Starting in %ds|r"
L["MINIMAP_TOOLTIP"]       = "|cff00aaffMythicTimer|r"
L["MINIMAP_TOOLTIP_L"]     = "|cffffffffLeft-click|r to open options"
L["MINIMAP_TOOLTIP_R"]     = "|cffffffffRight-click|r to show/hide window"
L["MINIMAP_TOOLTIP_M"]     = "|cffffffffMiddle-click|r to show/hide M+ Forces"

-- ================================================================
-- FRENCH override
-- ================================================================
if locale == "frFR" or locale == "frCA" then

L["ADDON_LOADED"]          = "|cff00aaffMythicTimer|r charge ! Tapez |cffffff00/myt|r pour l'aide."
L["KEY_STARTED"]           = "|cff00aaffMythicTimer|r : Cle +%d demarree dans %s !"
L["KEY_FINISHED"]          = "|cff00aaffMythicTimer|r : Cle terminee ! Resultat : %s en %s"

L["WAITING_KEY"]           = "En attente d'une cle..."
L["ELAPSED"]               = "%s ecoule"
L["DEATHS_NONE"]           = "Morts : 0 (+0 sec)"
L["DEATHS_FMT"]            = "|cffff4444Morts : %d (+%d sec)|r"
L["DEATHS_TOOLTIP_TITLE"]  = "|cffff4444Morts durant la cle|r"
L["TRASH_PCT"]             = "Trash : %.1f%%"
L["TRASH_NA"]              = "|cffaaaaaa Trash : N/A|r"
L["TRASH_FULL"]            = "|cffff4444Trash : 100%% [FULL]|r"
L["TRASH_FULL_OVER"]       = "|cffff4444Trash : 100%% [FULL] |cffdd8888(+%.1f%%)|r"
L["TRASH_ETA"]             = "ETA trash : ~%s"

L["RESULT_TITLE"]          = "|cff00aaffMythic+|r Timer  -  Resultats"
L["RESULT_P3"]             = "+3"
L["RESULT_P2"]             = "+2"
L["RESULT_TIMED"]          = "Time"
L["RESULT_FAIL"]           = "Echec"
L["TIME_AHEAD"]            = "|cff00ff00+%s d'avance|r"
L["TIME_OVER"]             = "|cffff4444-%s de depassement|r"
L["TIME_LIMIT"]            = "|cffaaaaaa(limite : %s)|r"
L["BOSS_HEADER_NONE"]      = "|cffaaaaaa  Boss (aucun detecte)|r"
L["BOSS_HEADER_FMT"]       = "|cff99ccff  Boss  (%d tues)|r"
L["DEATHS_RECAP_NONE"]     = "|cff00ff00Aucune mort|r"
L["DEATHS_RECAP_FMT"]      = "|cffff4444Morts : %d  (+%d sec de penalite)|r"
L["BTN_CLOSE"]             = "Fermer"
L["BTN_LOCK_RESULT"]       = "Verrouiller"
L["BTN_UNLOCK_RESULT"]     = "Deverrouiller"
L["OPT_BTN_RESULT_POS"]    = "Positionner les resultats"
L["SLASH_RESULT_PREVIEW"]  = "|cff00aaffMythicTimer|r : Fenetre des resultats affichee. Glissez pour deplacer."
L["OPT_PROGRESS_LABEL"]    = "Affichage trash :"
L["OPT_PROGRESS_BAR"]      = "Barre"
L["OPT_PROGRESS_TEXT"]     = "Texte seul"
L["SLASH_BARMODE_BAR"]     = "|cff00aaffMythicTimer|r : Affichage trash -> |cffffff00barre|r."
L["SLASH_BARMODE_TEXT"]    = "|cff00aaffMythicTimer|r : Affichage trash -> |cffffff00texte|r."

L["OPT_TITLE"]             = "|cff00aaffMythic+|r Timer - Options"
L["OPT_LOCK"]              = "Verrouiller la position de la fenetre"
L["OPT_HIDE_BLIZZ"]        = "Masquer le timer Blizzard en cle"
L["OPT_SEC_TIMER"]         = "Fenetre du timer"
L["OPT_SEC_DEATH"]         = "Alertes de mort"
L["OPT_SEC_MISC"]          = "Fenetres & outils"
L["OPT_DEATH_SOUND"]       = "Jouer un son a chaque mort"
L["OPT_DEATH_ALERT"]       = "Afficher un texte a chaque mort"
L["DEATH_ALERT_FMT"]       = "%s est mort !"
L["DEATH_ALERT_UNKNOWN"]   = "Un membre du groupe est mort !"
L["OPT_BTN_HISTORY"]       = "Historique des runs"
L["OPT_BTN_CLEAR"]         = "Effacer l'historique"
L["OPT_BTN_CENTER"]        = "Recentrer le timer"
L["OPT_SCALE"]             = "Taille de la fenetre"
L["OPT_OPACITY"]           = "Opacite du fond"
L["OPT_MINIMAP"]           = "Afficher le bouton minimap"
L["OPT_LOCK_RESULT"]       = "Verrouiller la fenetre des resultats"
L["OPT_BTN_TEST"]          = "Tester"
L["OPT_BTN_TOGGLE_TIMER"]  = "Afficher / masquer le timer"
L["OPT_BTN_FORCES"]        = "Panneau Forces M+"
L["OPT_CONFIRM_CLEAR"]     = "Effacer tout l'historique des runs ?"
L["OPT_FOOTER_HINT"]       = "Tapez /myt pour les commandes"
L["OPT_SETTINGS_DESC"]     = "Les options s'ouvrent dans leur propre fenetre."
L["OPT_BTN_OPEN"]          = "Ouvrir les options"
L["OPT_FOOTER_CLEARED"]    = "|cff00aaffMythicTimer|r : Historique efface."
L["OPT_FOOTER_CENTERED"]   = "|cff00aaffMythicTimer|r : Position reinitialisee."

L["SLASH_WINDOW_SHOWN"]    = "|cff00aaffMythicTimer|r : Fenetre affichee."
L["SLASH_WINDOW_HIDDEN"]   = "|cff00aaffMythicTimer|r : Fenetre cachee."
L["SLASH_LOCKED"]          = "|cff00aaffMythicTimer|r : Fenetre verrouillee."
L["SLASH_UNLOCKED"]        = "|cff00aaffMythicTimer|r : Fenetre deverrouillee (glissez pour deplacer)."
L["SLASH_RESET"]           = "|cff00aaffMythicTimer|r : Position reinitialisee."
L["SLASH_BLIZZ_HIDDEN"]    = "|cff00aaffMythicTimer|r : Timer Blizzard |cffff4444masque|r pendant les cles."
L["SLASH_BLIZZ_SHOWN"]     = "|cff00aaffMythicTimer|r : Timer Blizzard |cff00ff00affiche|r."
L["HIST_TITLE"]            = "|cff00aaffMythic+|r Timer - Historique"
L["HIST_EMPTY"]            = "Aucun run enregistre."
L["HIST_CHAR"]             = "Par : %s"
L["HIST_TIME"]             = "Temps : %s"
L["HIST_DEATHS"]           = "Morts : %d"
L["HIST_NO_DEATHS"]        = "|cff00ff00Aucune mort|r"

L["SLASH_NO_HISTORY"]      = "|cff00aaffMythicTimer|r : Aucun run enregistre."
L["SLASH_HISTORY_TITLE"]   = "|cff00aaffMythicTimer|r - |cffffff00Historique des 10 derniers runs :|r"
L["SLASH_HISTORY_ROW"]     = "  |cffaaaaaa%s|r |cffffff00+%d|r %s - %s - %d mort(s) - %s"
L["SLASH_HISTORY_CLEARED"] = "|cff00aaffMythicTimer|r : Historique efface."
L["SLASH_MINIMAP"]         = "|cff00aaffMythicTimer|r : Bouton minimap repositionne."
L["SLASH_HELP"] = {
    "|cff00aaffMythicTimer|r - Commandes disponibles :",
    "  |cffffff00/myt show|r          - Affiche la fenetre",
    "  |cffffff00/myt hide|r          - Cache la fenetre",
    "  |cffffff00/myt lock|r          - Verrouille la position",
    "  |cffffff00/myt unlock|r        - Deverrouille la position",
    "  |cffffff00/myt reset|r         - Remet la fenetre au centre",
    "  |cffffff00/myt default|r       - Afficher/masquer le timer Blizzard",
    "  |cffffff00/myt history|r       - Affiche les 10 derniers runs",
    "  |cffffff00/myt clearhistory|r  - Efface l'historique",
    "  |cffffff00/myt result|r          - Affiche la fenetre des resultats",
    "  |cffffff00/myt barmode|r         - Bascule barre/texte (trash)",
}
L["COUNTDOWN_FMT"]         = "|cffffff00Demarrage dans %ds|r"
L["MINIMAP_TOOLTIP"]       = "|cff00aaffMythicTimer|r"
L["MINIMAP_TOOLTIP_L"]     = "|cffffffffClic gauche|r pour ouvrir les options"
L["MINIMAP_TOOLTIP_R"]     = "|cffffffffClic droit|r pour afficher/masquer la fenetre"
L["MINIMAP_TOOLTIP_M"]     = "|cffffffffClic milieu|r pour afficher/masquer les Forces M+"

end -- frFR / frCA

-- ================================================================
-- GERMAN override
-- ================================================================
if locale == "deDE" then

L["ADDON_LOADED"]          = "|cff00aaffMythicTimer|r geladen! Gib |cffffff00/myt|r fuer Hilfe ein."
L["KEY_STARTED"]           = "|cff00aaffMythicTimer|r: +%d Schluessel gestartet in %s!"
L["KEY_FINISHED"]          = "|cff00aaffMythicTimer|r: Schluessel abgeschlossen! Ergebnis: %s in %s"

L["WAITING_KEY"]           = "Warte auf einen Schluessel..."
L["ELAPSED"]               = "%s vergangen"
L["DEATHS_NONE"]           = "Tode: 0 (+0 Sek)"
L["DEATHS_FMT"]            = "|cffff4444Tode: %d (+%d Sek)|r"
L["DEATHS_TOOLTIP_TITLE"]  = "|cffff4444Tode waehrend des Schluessels|r"
L["TRASH_PCT"]             = "Trash: %.1f%%"
L["TRASH_NA"]              = "|cffaaaaaa Trash: N/A|r"
L["TRASH_FULL"]            = "|cffff4444Trash: 100%% [VOLL]|r"
L["TRASH_FULL_OVER"]       = "|cffff4444Trash: 100%% [VOLL] |cffdd8888(+%.1f%%)|r"
L["TRASH_ETA"]             = "ETA Trash: ~%s"

L["RESULT_TITLE"]          = "|cff00aaffMythic+|r Timer  -  Ergebnisse"
L["RESULT_P3"]             = "+3"
L["RESULT_P2"]             = "+2"
L["RESULT_TIMED"]          = "Geschafft"
L["RESULT_FAIL"]           = "Gescheitert"
L["TIME_AHEAD"]            = "|cff00ff00+%s voraus|r"
L["TIME_OVER"]             = "|cffff4444-%s Ueberschreitung|r"
L["TIME_LIMIT"]            = "|cffaaaaaa(Limit: %s)|r"
L["BOSS_HEADER_NONE"]      = "|cffaaaaaa  Bosse (keine erkannt)|r"
L["BOSS_HEADER_FMT"]       = "|cff99ccff  Bosse  (%d getoetet)|r"
L["DEATHS_RECAP_NONE"]     = "|cff00ff00Keine Tode|r"
L["DEATHS_RECAP_FMT"]      = "|cffff4444Tode: %d  (+%d Sek Strafe)|r"
L["BTN_CLOSE"]             = "Schliessen"
L["BTN_LOCK_RESULT"]       = "Position sperren"
L["BTN_UNLOCK_RESULT"]     = "Position entsperren"
L["OPT_BTN_RESULT_POS"]    = "Ergebnisfenster positionieren"
L["SLASH_RESULT_PREVIEW"]  = "|cff00aaffMythicTimer|r: Ergebnisfenster angezeigt. Ziehen zum Verschieben."
L["SLASH_RESULT_SHOWN"]    = "|cff00aaffMythicTimer|r: Ergebnisse des letzten Laufs angezeigt."
L["OPT_PROGRESS_LABEL"]    = "Trash-Anzeige:"
L["OPT_PROGRESS_BAR"]      = "Balken"
L["OPT_PROGRESS_TEXT"]     = "Nur Text"
L["SLASH_BARMODE_BAR"]     = "|cff00aaffMythicTimer|r: Trash-Anzeige -> |cffffff00Balken|r."
L["SLASH_BARMODE_TEXT"]    = "|cff00aaffMythicTimer|r: Trash-Anzeige -> |cffffff00Text|r."

L["OPT_TITLE"]             = "|cff00aaffMythic+|r Timer - Optionen"
L["OPT_LOCK"]              = "Fensterposition sperren"
L["OPT_HIDE_BLIZZ"]        = "Blizzard-Timer in Schluesseln ausblenden"
L["OPT_SEC_TIMER"]         = "Timer-Fenster"
L["OPT_SEC_DEATH"]         = "Todesbenachrichtigungen"
L["OPT_SEC_MISC"]          = "Fenster & Werkzeuge"
L["OPT_DEATH_SOUND"]       = "Sound bei Tod abspielen"
L["OPT_DEATH_ALERT"]       = "Textwarnung bei Tod anzeigen"
L["DEATH_ALERT_FMT"]       = "%s ist gestorben!"
L["DEATH_ALERT_UNKNOWN"]   = "Ein Gruppenmitglied ist gestorben!"
L["OPT_BTN_HISTORY"]       = "Laufverlauf anzeigen"
L["OPT_BTN_CLEAR"]         = "Verlauf loeschen"
L["OPT_BTN_CENTER"]        = "Timer-Fenster zentrieren"
L["OPT_SCALE"]             = "Fenstergroesse"
L["OPT_OPACITY"]           = "Hintergrund-Deckkraft"
L["OPT_MINIMAP"]           = "Minimap-Schaltflaeche anzeigen"
L["OPT_LOCK_RESULT"]       = "Ergebnisfenster sperren"
L["OPT_BTN_TEST"]          = "Testen"
L["OPT_BTN_TOGGLE_TIMER"]  = "Timer ein-/ausblenden"
L["OPT_BTN_FORCES"]        = "M+ Streitkraefte"
L["OPT_CONFIRM_CLEAR"]     = "Gesamten Laufverlauf loeschen?"
L["OPT_FOOTER_HINT"]       = "/myt fuer Befehle"
L["OPT_SETTINGS_DESC"]     = "Die Optionen oeffnen sich in einem eigenen Fenster."
L["OPT_BTN_OPEN"]          = "Optionen oeffnen"
L["OPT_FOOTER_CLEARED"]    = "|cff00aaffMythicTimer|r: Verlauf geloescht."
L["OPT_FOOTER_CENTERED"]   = "|cff00aaffMythicTimer|r: Position zurueckgesetzt."

L["SLASH_WINDOW_SHOWN"]    = "|cff00aaffMythicTimer|r: Fenster angezeigt."
L["SLASH_WINDOW_HIDDEN"]   = "|cff00aaffMythicTimer|r: Fenster ausgeblendet."
L["SLASH_LOCKED"]          = "|cff00aaffMythicTimer|r: Fenster gesperrt."
L["SLASH_UNLOCKED"]        = "|cff00aaffMythicTimer|r: Fenster entsperrt (ziehen zum Verschieben)."
L["SLASH_RESET"]           = "|cff00aaffMythicTimer|r: Position zurueckgesetzt."
L["SLASH_BLIZZ_HIDDEN"]    = "|cff00aaffMythicTimer|r: Blizzard-Timer waehrend Schluesseln |cffff4444ausgeblendet|r."
L["SLASH_BLIZZ_SHOWN"]     = "|cff00aaffMythicTimer|r: Blizzard-Timer |cff00ff00angezeigt|r."
L["HIST_TITLE"]            = "|cff00aaffMythic+|r Timer - Verlauf"
L["HIST_EMPTY"]            = "Noch keine Laeufe aufgezeichnet."
L["HIST_CHAR"]             = "Von: %s"
L["HIST_TIME"]             = "Zeit: %s"
L["HIST_DEATHS"]           = "Tode: %d"
L["HIST_NO_DEATHS"]        = "|cff00ff00Keine Tode|r"

L["SLASH_NO_HISTORY"]      = "|cff00aaffMythicTimer|r: Keine Laeufe aufgezeichnet."
L["SLASH_HISTORY_TITLE"]   = "|cff00aaffMythicTimer|r - |cffffff00Letzte 10 Laeufe:|r"
L["SLASH_HISTORY_ROW"]     = "  |cffaaaaaa%s|r |cffffff00+%d|r %s - %s - %d Tod(e) - %s"
L["SLASH_HISTORY_CLEARED"] = "|cff00aaffMythicTimer|r: Verlauf geloescht."
L["SLASH_MINIMAP"]         = "|cff00aaffMythicTimer|r: Minimap-Schaltflaeche neu positioniert."
L["SLASH_HELP"] = {
    "|cff00aaffMythicTimer|r - Verfuegbare Befehle:",
    "  |cffffff00/myt show|r         - Fenster anzeigen",
    "  |cffffff00/myt hide|r         - Fenster ausblenden",
    "  |cffffff00/myt lock|r         - Position sperren",
    "  |cffffff00/myt unlock|r       - Position entsperren",
    "  |cffffff00/myt reset|r        - Fenster zentrieren",
    "  |cffffff00/myt default|r      - Blizzard-Timer umschalten",
    "  |cffffff00/myt history|r      - Letzte 10 Laeufe anzeigen",
    "  |cffffff00/myt clearhistory|r - Verlauf loeschen",
    "  |cffffff00/myt result|r       - Ergebnisfenster anzeigen",
    "  |cffffff00/myt barmode|r      - Balken/Text umschalten (Trash)",
}
L["COUNTDOWN_FMT"]         = "|cffffff00Startet in %ds|r"
L["MINIMAP_TOOLTIP"]       = "|cff00aaffMythicTimer|r"
L["MINIMAP_TOOLTIP_L"]     = "|cffffffffLinksklick|r zum Oeffnen der Optionen"
L["MINIMAP_TOOLTIP_R"]     = "|cffffffffRechtsklick|r zum Ein-/Ausblenden des Fensters"
L["MINIMAP_TOOLTIP_M"]     = "|cffffffffMittelklick|r zum Ein-/Ausblenden der M+ Streitkraefte"

end -- deDE
