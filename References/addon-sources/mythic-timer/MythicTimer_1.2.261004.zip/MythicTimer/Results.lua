-- ============================================================
-- MythicTimer - Fenetre de resultats (fin de cle)
-- Affiche un popup avec tous les resultats apres CHALLENGE_MODE_COMPLETED.
-- ============================================================
local MT = MythicTimerAddon
local T  = MT.Theme
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

local rf = nil  -- frame unique, creee une seule fois et reutilisee

local function BuildResultsFrame()
    if rf then return end

    rf = CreateFrame("Frame", "MythicTimerResultsFrame", UIParent, "BackdropTemplate")
    rf:SetSize(290, 400)  -- taille provisoire, recalculee a chaque affichage
    rf:SetPoint("CENTER", UIParent, "CENTER", 0, 50)
    T.ApplyBackdrop(rf, 0.94)
    rf:SetFrameStrata("DIALOG")
    rf:SetClampedToScreen(true)
    T.CloseOnEscape("MythicTimerResultsFrame")
    rf:SetMovable(true)
    rf:EnableMouse(true)
    rf:RegisterForDrag("LeftButton")
    rf:SetScript("OnDragStart", function(self)
        if not MythicTimerDB.lockedResult then self:StartMoving() end
    end)
    rf:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        -- StartMoving() change l'ancre interne vers BOTTOMLEFT pendant le drag,
        -- donc GetPoint() retournerait des coordonnees incorrectes.
        -- On calcule l'offset CENTER depuis la position ecran reelle.
        local x = self:GetLeft() + self:GetWidth()  / 2 - UIParent:GetWidth()  / 2
        local y = self:GetTop()  - self:GetHeight() / 2 - UIParent:GetHeight() / 2
        MythicTimerDB.posXResult = x
        MythicTimerDB.posYResult = y
    end)

    -- Bandeau titre (illustration du donjon + liseré a la couleur du resultat)
    T.CreateHeader(rf, MT.L["RESULT_TITLE"], function() rf:Hide() end)

    -- Grand texte resultat (+2 / +3 / Echec) + temps final
    rf.resultTitle = rf:CreateFontString(nil, "OVERLAY")
    rf.resultTitle:SetFont(T.FONT, 24, "OUTLINE")
    rf.resultTitle:SetShadowOffset(1, -1)

    -- Nom du donjon
    rf.dungeon = rf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    rf.dungeon:SetWidth(270)
    rf.dungeon:SetJustifyH("CENTER")

    -- Ligne temps (avance / depassement)
    rf.timeLine = rf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

    -- Seuils +2 / +3
    rf.threshLine = rf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

    -- Separateur 1 (avant boss)
    rf.sep1 = T.CreateSeparator(rf)

    -- En-tete boss
    rf.bossHeader = rf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    rf.bossHeader:SetTextColor(0.6, 0.8, 1)

    -- Labels boss (pre-alloues, MAX_BOSSES slots)
    rf.bossLabels = {}
    for i = 1, MT.MAX_BOSSES do
        local lbl = rf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetWidth(270)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        lbl:SetNonSpaceWrap(false)
        rf.bossLabels[i] = lbl
    end

    -- Separateur 2 (avant morts)
    rf.sep2 = T.CreateSeparator(rf)

    -- Ligne recap morts
    rf.deathLine = rf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    rf.deathLine:SetWidth(270)
    rf.deathLine:SetJustifyH("LEFT")

    -- Zone de scroll pour le log de mort
    rf.deathScroll = CreateFrame("ScrollFrame", nil, rf)
    rf.deathScroll:EnableMouseWheel(true)
    rf.deathScroll:SetScript("OnMouseWheel", function(self, delta)
        local cur = self:GetVerticalScroll()
        local max = self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(max, cur - delta * 13)))
    end)

    rf.deathScrollChild = CreateFrame("Frame", nil, rf.deathScroll)
    rf.deathScrollChild:SetWidth(260)
    rf.deathScrollChild:SetHeight(130)
    rf.deathScroll:SetScrollChild(rf.deathScrollChild)

    rf.deathLogLabels = {}
    for i = 1, 50 do
        local lbl = rf.deathScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetWidth(256)
        lbl:SetJustifyH("LEFT")
        lbl:SetPoint("TOPLEFT", rf.deathScrollChild, "TOPLEFT", 0, -(i-1)*13)
        lbl:Hide()
        rf.deathLogLabels[i] = lbl
    end

    -- Bas de fenetre : [Verrouiller] [Fermer], le bloc est centre (Fermer decale de +48)
    rf.closeBtn = T.CreateButton(rf, MT.L["BTN_CLOSE"], 90, 22, function() rf:Hide() end)

    rf.lockBtn = T.CreateButton(rf, "", 90, 22, function()
        MythicTimerDB.lockedResult = not MythicTimerDB.lockedResult
        MT.UpdateResultsLockButton()
    end)
    rf.lockBtn:SetPoint("RIGHT", rf.closeBtn, "LEFT", -6, 0)

    MT.resultsFrame = rf
    rf:Hide()
end

-- Le bouton affiche l'ACTION possible (pas l'etat actuel)
function MT.UpdateResultsLockButton()
    if not rf then return end
    rf.lockBtn:SetText(MythicTimerDB.lockedResult and MT.L["BTN_UNLOCK_RESULT"] or MT.L["BTN_LOCK_RESULT"])
end

-- ---- Affichage du popup ----
-- Appelé depuis Events.lua via C_Timer.After(0.5, MT.ShowResultsPopup)
-- MT.completedElapsed doit etre defini avant l'appel.
function MT.ShowResultsPopup()
    BuildResultsFrame()

    local elapsed   = MT.completedElapsed or 0
    local resultText, rR, rG, rB

    if elapsed <= MT.level3Time then
        resultText = MT.L["RESULT_P3"]
        rR, rG, rB = T.rgb(T.C.good)
    elseif elapsed <= MT.level2Time then
        resultText = MT.L["RESULT_P2"]
        rR, rG, rB = T.rgb(T.C.gold)
    elseif elapsed <= MT.timeLimit then
        resultText = MT.L["RESULT_TIMED"]
        rR, rG, rB = T.rgb(T.C.cyan)
    else
        resultText = MT.L["RESULT_FAIL"]
        rR, rG, rB = T.rgb(T.C.bad)
    end
    T.SetHeaderDungeon(rf.header, MT.currentMapID)
    T.SetAccent(rf.header, { rR, rG, rB })

    local saved = MT.timeLimit - elapsed
    local timeExtra
    if saved >= 0 then
        timeExtra = L("TIME_AHEAD", MT.FormatTime(saved))
    else
        timeExtra = L("TIME_OVER", MT.FormatTime(-saved))
    end

    -- ---- Mise en page avec curseur Y ----
    local y = -(T.HEADER_H + 10)

    rf.resultTitle:ClearAllPoints()
    rf.resultTitle:SetPoint("TOP", rf, "TOP", 0, y)
    rf.resultTitle:SetText(resultText .. "   " .. MT.FormatTime(elapsed))
    rf.resultTitle:SetTextColor(rR, rG, rB)
    y = y - 30

    rf.dungeon:ClearAllPoints()
    rf.dungeon:SetPoint("TOP", rf, "TOP", 0, y)
    rf.dungeon:SetText(string.format("|cffffd100+%d|r  %s", MT.keystoneLevel, MT.currentDungeonName))
    y = y - 18

    rf.timeLine:ClearAllPoints()
    rf.timeLine:SetPoint("TOP", rf, "TOP", 0, y)
    rf.timeLine:SetText(timeExtra .. "  " .. L("TIME_LIMIT", MT.FormatTime(MT.timeLimit)))
    y = y - 15

    rf.threshLine:ClearAllPoints()
    rf.threshLine:SetPoint("TOP", rf, "TOP", 0, y)
    rf.threshLine:SetText(string.format("|cffaaaaaa+2 : %s      +3 : %s|r",
        MT.FormatTime(MT.timeLimit - MT.level2Time), MT.FormatTime(MT.timeLimit - MT.level3Time)))
    y = y - 16

    -- Separateur 1
    rf.sep1:ClearAllPoints()
    rf.sep1:SetPoint("TOPLEFT",  rf, "TOPLEFT",  10, y)
    rf.sep1:SetPoint("TOPRIGHT", rf, "TOPRIGHT", -10, y)
    y = y - 8

    -- En-tete boss
    rf.bossHeader:ClearAllPoints()
    rf.bossHeader:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, y)
    y = y - 16

    -- Boss : utilise MT.bossLog (alimente par ENCOUNTER_END, ordonné, sans lookup par nom)
    local bossCount = #MT.bossLog
    if bossCount == 0 then
        rf.bossHeader:SetText(MT.L["BOSS_HEADER_NONE"])
    else
        rf.bossHeader:SetText(L("BOSS_HEADER_FMT", bossCount))
    end

    local MAX_NAME = 19
    for i = 1, math.min(bossCount, MT.MAX_BOSSES) do
        local boss = MT.bossLog[i]
        local lbl  = rf.bossLabels[i]
        local shortName = MT.ShortName(boss.name, MAX_NAME)
        lbl:ClearAllPoints()
        lbl:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, y)
        local wipeStr = (boss.wipes and boss.wipes > 0)
            and string.format("  |cffff4444W:%d|r", boss.wipes) or ""
        lbl:SetText(string.format(
            "|cff00ff00%s|r  |cffffff00%s|r  |cffaaaaaa(%s)|r%s",
            shortName,
            MT.FormatTime(boss.killTime),
            MT.FormatTime(boss.fightDuration),
            wipeStr
        ))
        lbl:Show()
        y = y - 15
    end

    -- Masque les slots non utilises
    for i = math.min(bossCount, MT.MAX_BOSSES) + 1, MT.MAX_BOSSES do
        rf.bossLabels[i]:Hide()
    end

    -- Separateur 2
    y = y - 2
    rf.sep2:ClearAllPoints()
    rf.sep2:SetPoint("TOPLEFT",  rf, "TOPLEFT",  10, y)
    rf.sep2:SetPoint("TOPRIGHT", rf, "TOPRIGHT", -10, y)
    y = y - 8

    -- Ligne morts
    rf.deathLine:ClearAllPoints()
    rf.deathLine:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, y)
    local penalty = MT.GetDeathTimeLost()
    if MT.deathCount > 0 then
        rf.deathLine:SetText(L("DEATHS_RECAP_FMT", MT.deathCount, penalty))
    else
        rf.deathLine:SetText(MT.L["DEATHS_RECAP_NONE"])
    end
    y = y - 15

    -- Log de mort complet (scroll a la molette si > 10 morts)
    local totalDeaths = #MT.deathLog
    if totalDeaths > 0 then
        local visibleRows = math.min(totalDeaths, 10)
        local scrollH = visibleRows * 13
        rf.deathScroll:SetSize(260, scrollH)
        rf.deathScroll:ClearAllPoints()
        rf.deathScroll:SetPoint("TOPLEFT", rf, "TOPLEFT", 22, y)
        rf.deathScroll:SetVerticalScroll(0)
        rf.deathScroll:Show()

        local shown = math.min(totalDeaths, 50)
        for i = 1, shown do
            local entry = MT.deathLog[i]
            rf.deathLogLabels[i]:SetText(string.format(
                "|cffffff00%s|r  |cffaaaaaa@ %s|r",
                entry.name, MT.FormatTime(entry.elapsed)
            ))
            rf.deathLogLabels[i]:Show()
        end
        for i = shown + 1, 50 do
            rf.deathLogLabels[i]:Hide()
        end
        rf.deathScrollChild:SetHeight(shown * 13)

        y = y - scrollH
    else
        rf.deathScroll:Hide()
    end

    -- Bouton fermer
    y = y - 8
    rf.closeBtn:ClearAllPoints()
    rf.closeBtn:SetPoint("TOP", rf, "TOP", 48, y)

    -- Hauteur dynamique de la frame
    local totalH = math.abs(y) + 22 + 12
    rf:SetSize(290, totalH)

    -- Position : restaure la derniere position connue, sinon defaut droite de l'ecran
    rf:ClearAllPoints()
    local px = MythicTimerDB.posXResult or MT.DEFAULT_SETTINGS.posXResult
    local py = MythicTimerDB.posYResult or MT.DEFAULT_SETTINGS.posYResult
    rf:SetPoint("CENTER", UIParent, "CENTER", px, py)

    MT.UpdateResultsLockButton()

    rf:Show()
    rf:Raise()
end

-- ---- Apercu hors donjon (pour positionner la fenetre de resultats) ----
-- Appelable via /myt result ou depuis le panneau Options.
function MT.PreviewResultsFrame()
    BuildResultsFrame()
    rf:ClearAllPoints()
    local px = MythicTimerDB.posXResult or MT.DEFAULT_SETTINGS.posXResult
    local py = MythicTimerDB.posYResult or MT.DEFAULT_SETTINGS.posYResult
    rf:SetPoint("CENTER", UIParent, "CENTER", px, py)
    -- Positionne le bouton fermer (dynamique dans ShowResultsPopup, fixe ici)
    rf.closeBtn:ClearAllPoints()
    rf.closeBtn:SetPoint("BOTTOM", rf, "BOTTOM", 48, 10)
    MT.UpdateResultsLockButton()
    rf:Show()
    rf:Raise()
end
