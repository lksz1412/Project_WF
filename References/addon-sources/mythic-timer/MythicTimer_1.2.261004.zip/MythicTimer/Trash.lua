-- ============================================================
-- MythicTimer - Barre de progression des trash (Enemy Forces)
-- ============================================================
local MT = MythicTimerAddon
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

-- Applique le bon mode d'affichage (bar / text) sans recalculer le %.
-- Appelee apres changement d'option pour rafraichir immediatement.
function MT.ApplyProgressMode()
    local frame = MT.frame
    if not frame then return end
    local mode = (MythicTimerDB and MythicTimerDB.progressMode) or "bar"
    if mode == "text" then
        frame.progressBg:Hide()
        frame.progressBar:Hide()
        frame.progressText:Hide()
        frame.progressTextLarge:Show()
    else
        frame.progressBg:Show()
        frame.progressBar:Show()
        frame.progressText:Show()
        frame.progressTextLarge:Hide()
    end
end

function MT.UpdateEnemyForces()
    if not MT.frame or not MT.frame.progressText then return end

    local mode = (MythicTimerDB and MythicTimerDB.progressMode) or "bar"
    MT.ApplyProgressMode()

    local numCriteria = select(3, C_Scenario.GetStepInfo())
    if not numCriteria or numCriteria == 0 then
        MT.frame.progressText:SetText(MT.L["TRASH_NA"])
        MT.frame.progressTextLarge:SetText(MT.L["TRASH_NA"])
        MT.frame.progressTextLarge:SetTextColor(0.6, 0.6, 0.6)
        return
    end

    -- Le critere Enemy Forces a isWeightedProgress = true
    for i = 1, numCriteria do
        local info = C_ScenarioInfo.GetCriteriaInfo(i)
        if info and info.isWeightedProgress then
            -- En Midnight, quantityString est plus fiable que quantity
            local qs = info.quantityString
            local current = (qs and tonumber(qs:match("%d+"))) or info.quantity or 0
            local total   = info.totalQuantity or 1
            if total == 0 then total = 1 end
            local pctRaw = (current / total) * 100
            local pct = math.min(pctRaw, 100)
            MT.currentProgress = pct

            -- Couleur selon le seuil (vives pour lisibilite instantanee)
            local r, g, b
            if pct >= 100 then
                r, g, b = 0.2, 1.0, 0.2      -- vert vif : complet
            elseif pct >= 80 then
                r, g, b = 0.0, 0.85, 1.0     -- cyan vif : presque
            else
                r, g, b = 1.0, 0.82, 0.0     -- jaune vif : en cours
            end

            -- Texte commun aux deux modes
            local txtSmall, txtLarge
            if pct >= 100 then
                local overflow = pctRaw - 100
                if overflow >= 0.1 then
                    txtSmall = L("TRASH_FULL_OVER", overflow)
                    txtLarge = L("TRASH_FULL_OVER", overflow)
                else
                    txtSmall = MT.L["TRASH_FULL"]
                    txtLarge = MT.L["TRASH_FULL"]
                end
            else
                txtSmall = L("TRASH_PCT", pct)
                txtLarge = L("TRASH_PCT", pct)
            end

            -- Mode barre
            MT.frame.progressBar:SetValue(pct / 100)
            MT.frame.progressBar:SetStatusBarColor(r, g, b)
            MT.frame.progressText:SetText(txtSmall)
            MT.frame.progressText:SetTextColor(1, 1, 1)  -- blanc OUTLINE sur la barre

            -- Mode texte
            MT.frame.progressTextLarge:SetText(txtLarge)
            MT.frame.progressTextLarge:SetTextColor(r, g, b)

            -- ETA fin du trash (uniquement si timer en cours, pct entre 20 et 100)
            if MT.timerRunning and pct >= 20 and pct < 100 then
                local elapsedSec = GetTime() - MT.startTime
                if elapsedSec > 0 then
                    local speed = pct / elapsedSec   -- % par seconde
                    local eta_sec = math.floor((100 - pct) / speed)
                    MT.frame.trashETA:SetText(L("TRASH_ETA", MT.FormatTime(eta_sec)))
                    MT.frame.trashETA:Show()
                else
                    MT.frame.trashETA:Hide()
                end
            else
                MT.frame.trashETA:Hide()
            end
            return
        end
    end

    MT.frame.progressText:SetText(MT.L["TRASH_NA"])
    MT.frame.progressTextLarge:SetText(MT.L["TRASH_NA"])
    MT.frame.progressTextLarge:SetTextColor(0.6, 0.6, 0.6)
    MT.frame.trashETA:Hide()
end
