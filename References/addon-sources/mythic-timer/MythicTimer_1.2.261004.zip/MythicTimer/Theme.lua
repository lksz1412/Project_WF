-- ============================================================
-- MythicTimer - Theme
-- Palette et fabriques de widgets partagees par toutes les fenetres.
-- Style : fond sombre plat, liseres fins, accents bleu Mythic+ et or WoW.
-- Les polices et textures restent celles du jeu (Friz Quadrata, barres de statut).
-- Doit etre charge apres Locales.lua et avant UI.lua dans le .toc.
-- ============================================================
local MT = MythicTimerAddon
local T = {}
MT.Theme = T

T.FLAT     = "Interface\\Buttons\\WHITE8X8"
T.BAR      = "Interface\\TargetingFrame\\UI-StatusBar"
T.FONT     = "Fonts\\FRIZQT__.TTF"
T.ICON     = "Interface\\Icons\\Ability_Mage_TimeWarp"
T.SKULL    = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_8"
T.CHECK    = "Interface\\Buttons\\UI-CheckBox-Check"
T.HEADER_H = 24

T.C = {
    bg     = { 0.035, 0.040, 0.055 },
    header = { 0.090, 0.100, 0.130 },
    button = { 0.100, 0.110, 0.140 },
    hover  = { 0.140, 0.160, 0.200 },
    border = { 0.200, 0.220, 0.270 },
    accent = { 0.000, 0.670, 1.000 },  -- bleu Mythic+ (|cff00aaff)
    gold   = { 1.000, 0.820, 0.000 },  -- or WoW
    text   = { 0.920, 0.920, 0.940 },
    dim    = { 0.580, 0.600, 0.650 },
    good   = { 0.350, 0.950, 0.400 },
    warn   = { 1.000, 0.620, 0.150 },
    bad    = { 1.000, 0.280, 0.280 },
    cyan   = { 0.200, 0.820, 1.000 },
}

local function rgb(c, a) return c[1], c[2], c[3], a or 1 end
T.rgb = rgb

local function color(c, a) return CreateColor(c[1], c[2], c[3], a or 1) end

local function PlayClick()
    if SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
    end
end

-- Fond plat + bordure 1px
function T.ApplyBackdrop(frame, alpha)
    frame:SetBackdrop({ bgFile = T.FLAT, edgeFile = T.FLAT, edgeSize = 1 })
    frame:SetBackdropColor(rgb(T.C.bg, alpha or 0.92))
    frame:SetBackdropBorderColor(rgb(T.C.border))
end

-- Ajoute la fenetre a la liste des frames fermees par Echap
function T.CloseOnEscape(frameName)
    for _, name in ipairs(UISpecialFrames) do
        if name == frameName then return end
    end
    tinsert(UISpecialFrames, frameName)
end

-- Bande horizontale qui s'estompe aux deux extremites (separateurs, bandeaux).
-- Renvoie un Frame : SetPoint / Show / Hide / ClearAllPoints s'utilisent comme sur une texture.
function T.CreateFadeBand(parent, c, alpha, height)
    local f = CreateFrame("Frame", nil, parent)
    f:SetHeight(height or 1)
    local left = f:CreateTexture(nil, "ARTWORK")
    left:SetTexture(T.FLAT)
    left:SetPoint("TOPLEFT")
    left:SetPoint("BOTTOMRIGHT", f, "BOTTOM")
    left:SetGradient("HORIZONTAL", color(c, 0), color(c, alpha))
    local right = f:CreateTexture(nil, "ARTWORK")
    right:SetTexture(T.FLAT)
    right:SetPoint("TOPLEFT", f, "TOP")
    right:SetPoint("BOTTOMRIGHT")
    right:SetGradient("HORIZONTAL", color(c, alpha), color(c, 0))
    return f
end

function T.CreateSeparator(parent)
    return T.CreateFadeBand(parent, { 1, 1, 1 }, 0.18, 1)
end

-- Croix de fermeture dessinee avec deux traits (pas de dependance a une texture Blizzard)
function T.CreateCloseButton(parent, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(18, 18)
    local strokes = {}
    for i, rot in ipairs({ math.pi / 4, -math.pi / 4 }) do
        local s = b:CreateTexture(nil, "ARTWORK")
        s:SetTexture(T.FLAT)
        s:SetSize(12, 2)
        s:SetPoint("CENTER")
        s:SetRotation(rot)
        s:SetVertexColor(rgb(T.C.dim))
        strokes[i] = s
    end
    local function tint(c) for _, s in ipairs(strokes) do s:SetVertexColor(rgb(c)) end end
    b:SetScript("OnEnter", function() tint(T.C.bad) end)
    b:SetScript("OnLeave", function() tint(T.C.dim) end)
    b:SetScript("OnClick", onClick)
    return b
end

-- Bandeau de titre : icone, titre, illustration du donjon estompee, liseré d'accent
function T.CreateHeader(frame, title, onClose)
    local h = CreateFrame("Frame", nil, frame)
    h:SetPoint("TOPLEFT", 1, -1)
    h:SetPoint("TOPRIGHT", -1, -1)
    h:SetHeight(T.HEADER_H)

    local bg = h:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(rgb(T.C.header, 0.95))

    local art = h:CreateTexture(nil, "BORDER")
    art:SetAllPoints()
    art:SetAlpha(0.45)
    art:Hide()
    h.art = art

    -- Degrade sombre a gauche : garde le titre lisible par-dessus l'illustration
    local fade = h:CreateTexture(nil, "ARTWORK", nil, -1)
    fade:SetAllPoints()
    fade:SetTexture(T.FLAT)
    fade:SetGradient("HORIZONTAL", CreateColor(0, 0, 0, 0.7), CreateColor(0, 0, 0, 0.1))

    local line = h:CreateTexture(nil, "ARTWORK")
    line:SetTexture(T.FLAT)
    line:SetHeight(1)
    line:SetPoint("BOTTOMLEFT")
    line:SetPoint("BOTTOMRIGHT")
    h.line = line

    local icon = h:CreateTexture(nil, "ARTWORK")
    icon:SetSize(16, 16)
    icon:SetPoint("LEFT", 5, 0)
    icon:SetTexture(T.ICON)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    h.icon = icon

    local fs = h:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("LEFT", icon, "RIGHT", 6, 0)
    fs:SetPoint("RIGHT", h, "RIGHT", -26, 0)
    fs:SetJustifyH("LEFT")
    fs:SetWordWrap(false)
    fs:SetShadowOffset(1, -1)
    fs:SetText(title)
    h.title = fs

    if onClose then
        h.close = T.CreateCloseButton(h, onClose)
        h.close:SetPoint("RIGHT", -3, 0)
    end

    frame.header = h
    T.SetAccent(h, T.C.accent)
    return h
end

function T.SetAccent(header, c)
    header.line:SetGradient("HORIZONTAL", color(c, 0.95), color(c, 0.05))
end

-- Icone et illustration du donjon (mapChallengeModeID). nil -> visuel par defaut.
function T.SetHeaderDungeon(header, mapID)
    local icon, art
    if mapID and C_ChallengeMode and C_ChallengeMode.GetMapUIInfo then
        local _, _, _, tex, bgTex = C_ChallengeMode.GetMapUIInfo(mapID)
        icon, art = tex, bgTex
    end
    header.icon:SetTexture((icon and icon ~= 0) and icon or T.ICON)
    if art and art ~= 0 then
        header.art:SetTexture(art)
        header.art:SetTexCoord(0, 1, 0.38, 0.62)  -- bande centrale de l'illustration
        header.art:Show()
    else
        header.art:Hide()
    end
end

-- Bouton plat : texte blanc, dore au survol, bordure bleue
function T.CreateButton(parent, text, width, height, onClick)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height or 22)
    b:SetBackdrop({ bgFile = T.FLAT, edgeFile = T.FLAT, edgeSize = 1 })
    b:SetBackdropColor(rgb(T.C.button))
    b:SetBackdropBorderColor(rgb(T.C.border))

    local fs = b:CreateFontString(nil, "OVERLAY")
    fs:SetPoint("LEFT", 4, 0)
    fs:SetPoint("RIGHT", -4, 0)
    fs:SetWordWrap(false)
    b:SetFontString(fs)
    b:SetNormalFontObject(GameFontHighlightSmall)
    b:SetHighlightFontObject(GameFontNormalSmall)
    b:SetDisabledFontObject(GameFontDisableSmall)
    b:SetText(text)

    b:SetScript("OnEnter", function(self)
        if not self:IsEnabled() then return end
        self:SetBackdropColor(rgb(T.C.hover))
        self:SetBackdropBorderColor(rgb(T.C.accent))
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropColor(rgb(T.C.button))
        self:SetBackdropBorderColor(rgb(T.C.border))
    end)
    if onClick then b:SetScript("OnClick", onClick) end
    return b
end

-- Case a cocher : toute la ligne est cliquable. getter/setter lisent et ecrivent la valeur.
-- :Refresh() relit la valeur (utile si elle change ailleurs, ex. via /myt lock).
function T.CreateCheckbox(parent, label, getter, setter)
    local cb = CreateFrame("Button", nil, parent)
    cb:SetHeight(20)

    local box = CreateFrame("Frame", nil, cb, "BackdropTemplate")
    box:SetSize(16, 16)
    box:SetPoint("LEFT")
    box:SetBackdrop({ bgFile = T.FLAT, edgeFile = T.FLAT, edgeSize = 1 })
    box:SetBackdropColor(0.06, 0.07, 0.09, 1)

    local check = box:CreateTexture(nil, "OVERLAY")
    check:SetTexture(T.CHECK)
    check:SetSize(22, 22)
    check:SetPoint("CENTER", 1, 1)

    local fs = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    fs:SetPoint("LEFT", box, "RIGHT", 8, 0)
    fs:SetPoint("RIGHT")
    fs:SetJustifyH("LEFT")
    fs:SetWordWrap(false)
    fs:SetText(label)

    local hovered = false
    local function paint()
        local on = getter() and true or false
        check:SetShown(on)
        box:SetBackdropBorderColor(rgb((on or hovered) and T.C.accent or T.C.border))
    end
    cb.Refresh = paint

    cb:SetScript("OnClick", function()
        setter(not getter())
        PlayClick()
        paint()
    end)
    cb:SetScript("OnEnter", function() hovered = true;  fs:SetTextColor(rgb(T.C.gold)); paint() end)
    cb:SetScript("OnLeave", function() hovered = false; fs:SetTextColor(rgb(T.C.text)); paint() end)
    fs:SetTextColor(rgb(T.C.text))
    paint()
    return cb
end

-- Curseur plat : piste sombre, remplissage bleu, poignee doree, valeur affichee a droite.
function T.CreateSlider(parent, minV, maxV, step, fmtValue, getter, setter)
    local s = CreateFrame("Slider", nil, parent)
    s:SetOrientation("HORIZONTAL")
    s:SetHeight(16)
    s:SetMinMaxValues(minV, maxV)
    s:SetValueStep(step)
    s:SetObeyStepOnDrag(true)
    s:EnableMouseWheel(true)

    local track = s:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0.14, 0.15, 0.19, 1)
    track:SetHeight(4)
    track:SetPoint("LEFT")
    track:SetPoint("RIGHT")

    local thumb = s:CreateTexture(nil, "OVERLAY")
    thumb:SetColorTexture(rgb(T.C.gold))
    thumb:SetSize(8, 14)
    s:SetThumbTexture(thumb)

    local fill = s:CreateTexture(nil, "ARTWORK")
    fill:SetColorTexture(rgb(T.C.accent))
    fill:SetHeight(4)
    fill:SetPoint("LEFT", track, "LEFT")
    fill:SetPoint("RIGHT", thumb, "CENTER")

    local valueText = s:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    valueText:SetPoint("BOTTOMRIGHT", s, "TOPRIGHT", 0, 4)
    s.valueText = valueText

    local refreshing = false
    local function snap(v) return math.floor(v / step + 0.5) * step end

    s:SetScript("OnValueChanged", function(self, v)
        v = snap(v)
        valueText:SetText(fmtValue(v))
        if not refreshing then setter(v) end
    end)
    s:SetScript("OnMouseWheel", function(self, delta)
        self:SetValue(math.max(minV, math.min(maxV, snap(self:GetValue()) + delta * step)))
    end)

    function s:Refresh()
        refreshing = true
        local v = getter()
        self:SetValue(v)
        valueText:SetText(fmtValue(snap(v)))
        refreshing = false
    end
    s:Refresh()
    return s
end

-- Choix exclusif en boutons accoles. items = { { value = ..., label = ... }, ... }
function T.CreateSegmented(parent, items, width, getter, setter)
    local seg = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    seg:SetSize(width, 22)
    seg:SetBackdrop({ bgFile = T.FLAT, edgeFile = T.FLAT, edgeSize = 1 })
    seg:SetBackdropColor(0.06, 0.07, 0.09, 1)
    seg:SetBackdropBorderColor(rgb(T.C.border))

    local n = #items
    local bw = (width - 2) / n
    local buttons = {}

    function seg:Refresh()
        local cur = getter()
        for _, b in ipairs(buttons) do
            local active = (b.value == cur)
            b.bg:SetShown(active)
            b.fs:SetTextColor(rgb(active and T.C.gold or T.C.dim))
        end
    end

    for i, it in ipairs(items) do
        local b = CreateFrame("Button", nil, seg)
        b:SetSize(bw, 20)
        b:SetPoint("LEFT", seg, "LEFT", 1 + (i - 1) * bw, 0)
        b.value = it.value

        local bg = b:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(T.C.accent[1], T.C.accent[2], T.C.accent[3], 0.28)
        b.bg = bg

        local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("CENTER")
        fs:SetText(it.label)
        b.fs = fs

        b:SetScript("OnClick", function()
            setter(it.value)
            PlayClick()
            seg:Refresh()
        end)
        b:SetScript("OnEnter", function() if b.value ~= getter() then fs:SetTextColor(rgb(T.C.text)) end end)
        b:SetScript("OnLeave", function() seg:Refresh() end)
        buttons[i] = b
    end

    seg:Refresh()
    return seg
end

-- Titre de section dore suivi d'un trait qui s'estompe jusqu'au bord droit
function T.CreateSection(parent, text, rightPad)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetText(text)
    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetTexture(T.FLAT)
    line:SetHeight(1)
    line:SetPoint("LEFT", fs, "RIGHT", 8, 0)
    line:SetPoint("RIGHT", parent, "RIGHT", -(rightPad or 16), 0)
    line:SetGradient("HORIZONTAL", color(T.C.gold, 0.5), color(T.C.gold, 0))
    return fs
end

-- Barre de statut avec cadre sombre. Renvoie le cadre ; la StatusBar est dans .bar
function T.CreateBar(parent, height)
    local holder = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    holder:SetHeight(height)
    holder:SetBackdrop({ bgFile = T.FLAT, edgeFile = T.FLAT, edgeSize = 1 })
    holder:SetBackdropColor(0, 0, 0, 0.55)
    holder:SetBackdropBorderColor(0, 0, 0, 1)

    local bar = CreateFrame("StatusBar", nil, holder)
    bar:SetPoint("TOPLEFT", 1, -1)
    bar:SetPoint("BOTTOMRIGHT", -1, 1)
    bar:SetStatusBarTexture(T.BAR)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    holder.bar = bar
    return holder
end
