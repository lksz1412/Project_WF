-- ============================================================
-- MythicTimer - Commandes slash  (/myt  /mythictimer)
-- ============================================================
local MT = MythicTimerAddon
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

SLASH_MYTHICTIMER1 = "/myt"
SLASH_MYTHICTIMER2 = "/mythictimer"

SlashCmdList["MYTHICTIMER"] = function(msg)
    local cmd = msg:lower():trim()

    if cmd == "show" then
        MT.frame:Show()
        print(MT.L["SLASH_WINDOW_SHOWN"])

    elseif cmd == "hide" then
        MT.frame:Hide()
        print(MT.L["SLASH_WINDOW_HIDDEN"])

    elseif cmd == "lock" then
        MythicTimerDB.locked = true
        print(MT.L["SLASH_LOCKED"])

    elseif cmd == "unlock" then
        MythicTimerDB.locked = false
        print(MT.L["SLASH_UNLOCKED"])

    elseif cmd == "reset" then
        MythicTimerDB.posX = MT.DEFAULT_SETTINGS.posX
        MythicTimerDB.posY = MT.DEFAULT_SETTINGS.posY
        MT.frame:ClearAllPoints()
        MT.frame:SetPoint("CENTER", UIParent, "CENTER",
            MythicTimerDB.posX, MythicTimerDB.posY)
        print(MT.L["SLASH_RESET"])

    elseif cmd == "default" then
        MythicTimerDB.hideDefault = not MythicTimerDB.hideDefault
        if MythicTimerDB.hideDefault then
            print(MT.L["SLASH_BLIZZ_HIDDEN"])
            if MT.timerRunning then MT.HideDefaultTimer() end
        else
            print(MT.L["SLASH_BLIZZ_SHOWN"])
            MT.ShowDefaultTimer()
        end

    elseif cmd == "history" or cmd == "hist" then
        MT.ShowHistoryFrame()

    elseif cmd == "barmode" then
        local cur = MythicTimerDB.progressMode or "bar"
        MythicTimerDB.progressMode = (cur == "bar") and "text" or "bar"
        MT.UpdateEnemyForces()
        if MythicTimerDB.progressMode == "bar" then
            print(MT.L["SLASH_BARMODE_BAR"])
        else
            print(MT.L["SLASH_BARMODE_TEXT"])
        end

    elseif cmd == "result" or cmd == "results" then
        if MT.completedElapsed then
            MT.ShowResultsPopup()
            print(MT.L["SLASH_RESULT_SHOWN"])
        else
            MT.PreviewResultsFrame()
            print(MT.L["SLASH_RESULT_PREVIEW"])
        end

    elseif cmd == "clearhistory" then
        MythicTimerDB.history = {}
        print(MT.L["SLASH_HISTORY_CLEARED"])

    elseif cmd == "debug" then
        MT.debugDeaths = not MT.debugDeaths
        print("|cff00ccff[MythicTimer]|r debug morts : " .. (MT.debugDeaths and "ON" or "OFF"))

    elseif cmd == "minimap" then
        if MT.minimapLDB then
            MythicTimerDB.minimap.hide = false
            local icon = LibStub("LibDBIcon-1.0")
            icon:Refresh("MythicTimer", MythicTimerDB.minimap)
            icon:Show("MythicTimer")
            print(MT.L["SLASH_MINIMAP"])
        end

    else
        for _, line in ipairs(MT.L["SLASH_HELP"]) do print(line) end
    end
end
