-- ============================================================
-- MythicTimer - Gestion des evenements
-- Regle Midnight : SetScript AVANT RegisterEvent (toplevel uniquement).
-- ============================================================
local MT = MythicTimerAddon
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

local eventFrame = CreateFrame("Frame")

-- ---- Handlers prives ----

local function OnChallengeModeStart()
    local mapID = C_ChallengeMode.GetActiveChallengeMapID()
    local level, affixes = C_ChallengeMode.GetActiveKeystoneInfo()
    if not mapID or not level then return end
    MT.keystoneActive = true
    MythicTimerDB.lastResetTime = nil

    -- Temps limite de la cle
    local _, _, rawTime = C_ChallengeMode.GetMapUIInfo(mapID)
    if rawTime and rawTime > 0 then
        if rawTime > 10000 then rawTime = math.floor(rawTime / 1000) end
        MT.timeLimit  = rawTime
        MT.level2Time = math.floor(rawTime * 0.8)
        MT.level3Time = math.floor(rawTime * 0.6)
    end

    MT.startTime          = GetTime()
    MT.deathCount         = 0
    MT.deathTimeLost      = 0
    MT.deathsFrozen       = false
    MT.completedElapsed   = nil
    MT.localDeathCount    = 0
    MT.keystoneLevel      = level
    MT.timerRunning       = false
    MT.prepPhase          = true
    MT.prepEndTime        = GetTime() + 10
    MT.keystoneCompleted  = false

    -- Timer effectif apres les 10s de preparation
    C_Timer.After(10, function()
        if not MT.prepPhase then return end
        MT.prepPhase    = false
        MT.startTime    = GetTime()
        MT.timerRunning = true
        -- Affine le timeLimit avec l'API native
        if C_ChallengeMode.GetTimeRemainingSeconds then
            local r = C_ChallengeMode.GetTimeRemainingSeconds()
            if r and r > 60 then
                MT.timeLimit  = math.ceil(r)
                MT.level2Time = math.floor(MT.timeLimit * 0.8)
                MT.level3Time = math.floor(MT.timeLimit * 0.6)
                MT.frame.thresh2:SetText("+2 : " .. MT.FormatTime(MT.timeLimit - MT.level2Time))
                MT.frame.thresh3:SetText("+3 : " .. MT.FormatTime(MT.timeLimit - MT.level3Time))
            end
        end
        MT.UpdateEnemyForces()
        MT.UpdateBosses()
    end)

    local dungeonName = C_ChallengeMode.GetMapUIInfo(mapID) or "Donjon inconnu"
    MT.currentDungeonName = dungeonName
    MT.currentMapID       = mapID
    MT.deathLog = {}

    MT.SetupKeyDisplay(mapID, level, affixes, dungeonName)
    wipe(MT.bossEncounterStart)
    wipe(MT.bossKillData)
    wipe(MT.bossLog)
    wipe(MT.bossWipes)
    wipe(MT.knownDeadGUIDs)
    MT.lastServerDeathCount = nil
    MT.CacheGroupNames()
    MT.frame:Show()

    MT.HideDefaultTimer()
    MT.UpdateEnemyForces()
    C_Timer.After(0.3, MT.UpdateBosses)
    MT.StartDeathTracker()
    print(L("KEY_STARTED", level, dungeonName))
end

local function OnChallengeModeCompleted()
    MT.timerRunning = false
    MT.ShowDefaultTimer()

    -- Calcul elapsed : priorite a GetTimeRemainingSeconds (source officielle WoW).
    -- CHALLENGE_MODE_COMPLETED peut arriver avant le dernier ENCOUNTER_END (race condition),
    -- donc on attend 0.5s avant d'afficher, mais on capture elapsed MAINTENANT
    -- pendant que l'API retourne encore la valeur correcte.
    local elapsed
    local r = C_ChallengeMode.GetTimeRemainingSeconds and C_ChallengeMode.GetTimeRemainingSeconds()
    -- r > 0 strict : une fois le timer depasse, l'API renvoie 0 (elapsed vaudrait timeLimit)
    if r and r > 0 and MT.timeLimit > 0 then
        -- MT.timeLimit = GetTimeRemainingSeconds mesure au demarrage effectif (T+10).
        -- elapsed depuis notre startTime = timeLimit - remaining_maintenant.
        elapsed = math.max(0, MT.timeLimit - math.floor(r))
    else
        elapsed = math.floor(GetTime() - MT.startTime) + MT.GetDeathTimeLost()
    end
    MT.completedElapsed = elapsed
    MT.deathsFrozen     = true   -- plus aucune mort comptee apres la fin de la cle

    -- Fige l'etat apres 0.5s pour laisser le dernier ENCOUNTER_END arriver.
    C_Timer.After(0.5, function()
        MT.keystoneCompleted = true
        MT.frame:Hide()
        MT.ShowResultsPopup()
    end)
    local result
    if elapsed <= MT.level3Time then
        result = MT.L["RESULT_P3"]
    elseif elapsed <= MT.level2Time then
        result = MT.L["RESULT_P2"]
    elseif elapsed <= MT.timeLimit then
        result = MT.L["RESULT_TIMED"]
    else
        result = MT.L["RESULT_FAIL"]
    end

    if not MythicTimerDB.history then MythicTimerDB.history = {} end
    table.insert(MythicTimerDB.history, 1, {
        dungeon    = MT.currentDungeonName,
        mapID      = MT.currentMapID,      -- icone/illustration du donjon dans l'historique
        level      = MT.keystoneLevel,
        time       = elapsed,
        timeLimit  = MT.timeLimit,
        level2Time = MT.level2Time,
        level3Time = MT.level3Time,
        deaths     = MT.deathCount,
        deathTimeLost = MT.GetDeathTimeLost(),
        result     = result,
        date       = date("%d/%m/%y %H:%M"),
        char       = UnitName("player") or "?",
        bossLog    = CopyTable(MT.bossLog),    -- copie profonde { name, killTime, fightDuration, wipes }
        deathLog   = CopyTable(MT.deathLog),   -- copie profonde { name, elapsed }
    })
    if #MythicTimerDB.history > 50 then
        MythicTimerDB.history[51] = nil
    end

    print(L("KEY_FINISHED", result, MT.FormatTime(elapsed)))
end

local function StopDeathTracker()
    if MT.deathTicker then
        MT.deathTicker:Cancel()
        MT.deathTicker = nil
    end
end

local GROUP_TOKENS = {"player","party1","party2","party3","party4"}
local SPIRIT_OF_REDEMPTION = 27827

-- Pretre sacre en forme Esprit de redemption : UnitIsDeadOrGhost renvoie false,
-- il faut tester le buff. pcall : l'API d'auras peut etre restreinte en combat.
local function HasSpiritOfRedemption(token)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataBySpellID) then return false end
    local ok, aura = pcall(C_UnitAuras.GetAuraDataBySpellID, token, SPIRIT_OF_REDEMPTION, "HELPFUL")
    return ok and aura ~= nil
end

local function IsUnitDead(token)
    return UnitIsDeadOrGhost(token) or HasSpiritOfRedemption(token)
end

local UNKNOWN_NAME   = "Inconnu"  -- marqueur interne (deja present dans l'historique sauvegarde)
local NAME_WAIT_TIME = 1.5        -- delai max pour recuperer le nom avant l'alerte texte

-- Dernier nom lisible connu par GUID : UnitName renvoie UNKNOWNOBJECT ("Inconnu")
-- pour un joueur hors de portee / fantome, ou une valeur secrete (Midnight).
local groupNames = {}

local function IsUsableName(name)
    if type(name) ~= "string" then return false end
    if issecretvalue and issecretvalue(name) then return false end
    return name ~= "" and name ~= UNKNOWN_NAME and name ~= UNKNOWNOBJECT and name ~= UNKNOWN
end

-- Nom du joueur : UnitName si lisible, sinon le cache, sinon nil
local function ResolveName(token, guid)
    local name = UnitName(token)
    if IsUsableName(name) then
        groupNames[guid] = name
        return name
    end
    return groupNames[guid]
end

-- Retrouve le token actuel d'un GUID (l'ordre party1..4 peut changer)
local function TokenForGUID(guid)
    for _, token in ipairs(GROUP_TOKENS) do
        if UnitGUID(token) == guid then return token end
    end
end

-- Remplit le cache des noms hors combat (entree dans le groupe, debut de cle),
-- avant qu'une mort / forme d'ange rende le nom illisible.
function MT.CacheGroupNames()
    for _, token in ipairs(GROUP_TOKENS) do
        local guid = UnitGUID(token)
        if guid and UnitIsPlayer(token) then ResolveName(token, guid) end
    end
end

-- Diagnostic (/myt debug) : etat brut renvoye par le jeu pour chaque membre
local function DebugValue(v)
    if issecretvalue and issecretvalue(v) then return "<secret>" end
    return tostring(v)
end

local function DebugDeathState(reason)
    if not MT.debugDeaths then return end
    print("|cff00ccff[MythicTimer debug]|r " .. reason .. " - serveur: "
        .. DebugValue((C_ChallengeMode.GetDeathCount())) .. ", local: " .. tostring(MT.localDeathCount)
        .. ", total: " .. tostring(MT.deathCount))
    for _, token in ipairs(GROUP_TOKENS) do
        local guid = UnitGUID(token)
        if guid then
            local ok, aura = pcall(C_UnitAuras.GetAuraDataBySpellID, token, SPIRIT_OF_REDEMPTION, "HELPFUL")
            print(string.format("  %s: nom=%s cache=%s joueur=%s mort=%s ange=%s",
                token, DebugValue(UnitName(token)), tostring(groupNames[guid]),
                DebugValue(UnitIsPlayer(token)), DebugValue(UnitIsDeadOrGhost(token)),
                ok and DebugValue(aura ~= nil) or "erreur"))
        end
    end
end

local function AddDeathEntry(name, silent, guid)
    MT.deathCount = MT.deathCount + 1
    local elapsed = MT.timerRunning and math.floor(GetTime() - MT.startTime) or 0
    local entry = { name = name, elapsed = elapsed, guid = guid }
    table.insert(MT.deathLog, entry)
    if silent then return entry end
    if name == UNKNOWN_NAME then
        -- Le serveur a compte la mort avant que la detection locale ait vu qui est mort :
        -- son immediat, texte differe jusqu'a ce que le nom arrive (voir MT.SyncDeaths).
        MT.PlayDeathSound()
        entry.pendingAlert = GetTime()
    else
        MT.ShowDeathAlert(name)
    end
    return entry
end

-- Met a jour la penalite totale (secondes) depuis le 2e retour de GetDeathCount(),
-- la valeur officielle du serveur. Si notre detection locale a vu plus de morts que
-- le serveur, on extrapole avec la penalite moyenne par mort.
-- Valeur mise en cache : apres la fin de la cle, l'API peut revenir a 0.
local function UpdateDeathTimeLost(serverCount, serverTimeLost)
    local timeLost = serverTimeLost or 0
    local extra = MT.deathCount - serverCount
    if extra > 0 then
        local perDeath = serverCount > 0 and (timeLost / serverCount) or MT.GetDeathPenalty()
        timeLost = timeLost + extra * perDeath
    end
    timeLost = math.floor(timeLost)
    -- Timer a 0 : le jeu n'ajoute plus de penalite pour les morts suivantes.
    -- On fige donc la penalite appliquee (la mort qui fait passer sous 0 compte encore).
    local current = MT.deathTimeLost or 0
    if timeLost > current and MT.timerRunning and MT.timeLimit > 0
        and (GetTime() - MT.startTime) + current >= MT.timeLimit then
        return
    end
    MT.deathTimeLost = timeLost
end

local function RefreshDeathText()
    if MT.deathCount > 0 then
        MT.frame.deaths:SetText(L("DEATHS_FMT", MT.deathCount, MT.GetDeathTimeLost()))
    else
        MT.frame.deaths:SetText(MT.L["DEATHS_NONE"])
    end
end

-- Apres un /reload en cle : reprend le compteur serveur sans alerte ni son
-- (sinon chaque mort deja passee declencherait une alerte d'un coup).
function MT.RestoreDeathsSilently()
    local serverCount, serverTimeLost = C_ChallengeMode.GetDeathCount()
    serverCount = serverCount or 0
    MT.deathCount, MT.localDeathCount, MT.deathLog = 0, 0, {}
    wipe(MT.knownDeadGUIDs)
    for _ = 1, serverCount do AddDeathEntry("?", true) end
    -- Les joueurs deja morts au moment du reload ne doivent pas etre recomptes
    for _, token in ipairs(GROUP_TOKENS) do
        local guid = UnitGUID(token)
        if guid and UnitIsPlayer(token) and IsUnitDead(token) then
            MT.knownDeadGUIDs[guid] = true
        end
    end
    MT.localDeathCount = serverCount
    UpdateDeathTimeLost(serverCount, serverTimeLost)
    RefreshDeathText()
end

-- Synchronise le compteur de morts.
-- Deux sources : le compteur serveur (C_ChallengeMode.GetDeathCount) et notre propre
-- detection (mort / Esprit de redemption). On garde le max des deux : une mort vue
-- par une seule des sources est comptee, une mort vue par les deux ne l'est qu'une fois.
function MT.SyncDeaths()
    -- Fige apres CHALLENGE_MODE_COMPLETED : une mort hors cle ne doit plus compter
    if not MT.keystoneActive or MT.deathsFrozen then return end

    -- 1) Detection locale : nouveaux morts depuis le dernier passage
    local newDeaths = {}   -- { name, guid }
    for _, token in ipairs(GROUP_TOKENS) do
        local guid = UnitGUID(token)
        if guid and UnitIsPlayer(token) then
            local name = ResolveName(token, guid)   -- alimente aussi le cache tant que le joueur est vivant
            if IsUnitDead(token) then
                if not MT.knownDeadGUIDs[guid] then
                    MT.knownDeadGUIDs[guid] = true
                    MT.localDeathCount = (MT.localDeathCount or 0) + 1
                    table.insert(newDeaths, { name = name or UNKNOWN_NAME, guid = guid })
                end
            elseif MT.knownDeadGUIDs[guid] then
                -- Ressuscite : pourra etre recompte s'il meurt a nouveau
                MT.knownDeadGUIDs[guid] = nil
            end
        end
    end

    -- 2) Compteur officiel
    local serverCount, serverTimeLost = C_ChallengeMode.GetDeathCount()
    serverCount = serverCount or 0
    local target = math.max(serverCount, MT.localDeathCount or 0)
    if #newDeaths > 0 or serverCount ~= MT.lastServerDeathCount then
        MT.lastServerDeathCount = serverCount
        DebugDeathState(#newDeaths > 0 and "mort detectee" or "compteur serveur")
    end

    -- 3) Noms detectes pour des morts que le serveur avait deja comptees
    --    (entrees "Inconnu") : on renomme les plus recentes et on affiche leur alerte differee.
    local toAdd = math.max(0, target - MT.deathCount)
    local alreadyCounted = math.max(0, #newDeaths - toAdd)
    local idx = 1
    for i = #MT.deathLog, 1, -1 do
        if idx > alreadyCounted then break end
        local entry = MT.deathLog[i]
        if entry.name == UNKNOWN_NAME then
            entry.name = newDeaths[idx].name
            entry.guid = newDeaths[idx].guid
            if entry.pendingAlert and entry.name ~= UNKNOWN_NAME then
                entry.pendingAlert = nil
                MT.ShowDeathText(entry.name)
            end
            idx = idx + 1
        end
    end
    idx = alreadyCounted + 1

    -- 4) Ajouter les morts manquantes
    while MT.deathCount < target do
        local d = newDeaths[idx]
        AddDeathEntry(d and d.name or UNKNOWN_NAME, false, d and d.guid)
        idx = idx + 1
    end

    -- 5) Entrees sans nom : nouvel essai via le GUID a chaque passage (pas seulement pendant
    --    l'attente de l'alerte), pour que la liste des morts finisse avec le bon nom.
    local now = GetTime()
    for _, entry in ipairs(MT.deathLog) do
        if entry.name == UNKNOWN_NAME and entry.guid then
            local token = TokenForGUID(entry.guid)
            local name = token and ResolveName(token, entry.guid) or groupNames[entry.guid]
            if name then
                entry.name = name
                if entry.pendingAlert then
                    entry.pendingAlert = nil
                    MT.ShowDeathText(name)
                end
            end
        end
        if entry.pendingAlert and now - entry.pendingAlert >= NAME_WAIT_TIME then
            entry.pendingAlert = nil
            MT.ShowDeathText(nil)
        end
    end

    -- Toujours rafraichir l'affichage depuis l'etat (evite tout desync)
    UpdateDeathTimeLost(serverCount, serverTimeLost)
    RefreshDeathText()
end

function MT.StartDeathTracker()
    StopDeathTracker()
    MT.deathTicker = C_Timer.NewTicker(0.5, function()
        if not MT.keystoneActive then StopDeathTracker() return end
        MT.SyncDeaths()
    end)
end

local function OnChallengeModeReset()
    MT.timerRunning      = false
    MT.prepPhase         = false
    MT.keystoneActive    = false
    MT.keystoneCompleted = false
    MT.completedElapsed  = nil
    StopDeathTracker()
    MT.frame:Hide()
    if MT.resultsFrame then MT.resultsFrame:Hide() end
    MT.ShowDefaultTimer()
    wipe(MT.bossWipes)
end

-- ---- Dispatcher principal ----

local function OnEventSafe(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == MT.addonName then
            if not MythicTimerDB then
                MythicTimerDB = CopyTable(MT.DEFAULT_SETTINGS)
            end
            for k, v in pairs(MT.DEFAULT_SETTINGS) do
                if MythicTimerDB[k] == nil then
                    MythicTimerDB[k] = v
                end
            end
            MT.BuildUI()
            MT.BuildOptionsPanel()
            MT.BuildMinimapButton()

            -- Frame fantome : ObjectiveTrackerFrame y est re-parente pour
            -- le cacher (SetParent est bloque en combat, voir HideDefaultTimer).
            MT.hiddenTrackerFrame = CreateFrame("Frame")
            MT.hiddenTrackerFrame:Hide()

            print(MT.L["ADDON_LOADED"])
        end

    elseif event == "ENCOUNTER_START" then
        local encounterID, encounterName = ...
        if encounterID then
            MT.bossEncounterStart[encounterID] = GetTime()
            -- Stockage par nom : fallback si info.assetID != encounterID
            if type(encounterName) == "string" then
                MT.bossEncounterStart[encounterName] = GetTime()
            end
        end

    elseif event == "ENCOUNTER_END" then
        local encounterID, encounterName, _, _, success = ...
        -- Garde keystoneActive (pas timerRunning) : CHALLENGE_MODE_COMPLETED peut arriver
        -- avant ENCOUNTER_END pour le dernier boss (race condition Midnight).
        -- keystoneActive reste true jusqu'a CHALLENGE_MODE_RESET.
        if success == 0 and MT.keystoneActive and encounterID then
            -- Wipe / reset du boss : on efface le pullTime, on incremente le compteur de wipes
            MT.bossEncounterStart[encounterID] = nil
            MT.bossWipes[encounterID] = (MT.bossWipes[encounterID] or 0) + 1
            C_Timer.After(0.1, MT.UpdateBosses)
        end
        if success == 1 and MT.keystoneActive and encounterID then
            local pullTime = MT.bossEncounterStart[encounterID]
            -- killTime sur l'echelle officielle WoW (penalites de mort incluses),
            -- identique a completedElapsed dans OnChallengeModeCompleted.
            -- Evite la discordance entre le kill time et le temps final affiche.
            local killTime
            local rem = C_ChallengeMode.GetTimeRemainingSeconds and C_ChallengeMode.GetTimeRemainingSeconds()
            if rem and rem > 0 and MT.timeLimit > 0 then   -- 0 = timer depasse
                killTime = math.max(0, MT.timeLimit - math.floor(rem))
            else
                killTime = math.floor(GetTime() - MT.startTime) + MT.GetDeathTimeLost()
            end
            -- fightDuration : duree reelle du combat (horloge murale, pas de penalites)
            local fightDuration = pullTime and math.floor(GetTime() - pullTime) or 0
            local entry = { killTime = killTime, fightDuration = fightDuration }
            MT.bossKillData[encounterID] = entry
            if type(encounterName) == "string" then
                MT.bossKillData[encounterName] = entry
            end
            -- bossLog : liste ordonnee pour le popup (pas de lookup par nom)
            table.insert(MT.bossLog, {
                name          = (type(encounterName) == "string" and encounterName) or "Inconnu",
                killTime      = killTime,
                fightDuration = fightDuration,
                wipes         = MT.bossWipes[encounterID] or 0,
            })
            C_Timer.After(0.1, MT.UpdateBosses)
        end

    elseif event == "CHALLENGE_MODE_START" then
        OnChallengeModeStart()

    elseif event == "CHALLENGE_MODE_DEATH_COUNT_UPDATED" then
        MT.SyncDeaths()

    elseif event == "CHALLENGE_MODE_COMPLETED" then
        MT.SyncDeaths()
        OnChallengeModeCompleted()

    elseif event == "CHALLENGE_MODE_RESET" then
        MythicTimerDB.lastResetTime = time()   -- voir PLAYER_ENTERING_WORLD (abandon puis /reload)
        OnChallengeModeReset()

    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Attendre 1s que les APIs ChallengeMode soient initialisees apres le reload
        C_Timer.After(1, function()
            MT.CacheGroupNames()
            local mapID = C_ChallengeMode.GetActiveChallengeMapID()
            local level, affixes = C_ChallengeMode.GetActiveKeystoneInfo()

            if mapID and mapID ~= 0 and level and level > 0 then
                -- Cle en cours detectee apres reload : on reconstruit l'etat
                if not MT.keystoneActive then
                    -- Cas piege : CHALLENGE_MODE_RESET vient de tirer (abandon), mais
                    -- GetActiveChallengeMapID() retourne encore l'ancien mapID pendant
                    -- quelques instants -> on ne doit PAS recreer l'etat dans ce cas.
                    -- On ne se fie plus au temps restant (0 aussi pour une cle hors temps) :
                    -- reset recent memorise dans la DB (survit au /reload).
                    if MythicTimerDB.lastResetTime and time() - MythicTimerDB.lastResetTime < 120 then
                        return
                    end

                    -- Temps limite (necessaire a GetOfficialElapsed)
                    local _, _, rawTime = C_ChallengeMode.GetMapUIInfo(mapID)
                    if rawTime and rawTime > 0 then
                        if rawTime > 10000 then rawTime = math.floor(rawTime / 1000) end
                        MT.timeLimit  = rawTime
                        MT.level2Time = math.floor(rawTime * 0.8)
                        MT.level3Time = math.floor(rawTime * 0.6)
                    end

                    -- Aucun timer de cle (ni temps restant, ni timer de monde) : rien a reprendre
                    local official = MT.GetOfficialElapsed()
                    if not official then return end

                    MT.keystoneActive    = true
                    MT.keystoneCompleted = false
                    MT.keystoneLevel     = level
                    MT.timerRunning      = false   -- les morts sont restaurees avant de relancer
                    MT.prepPhase         = false

                    local dungeonName = C_ChallengeMode.GetMapUIInfo(mapID) or "?"
                    MT.currentDungeonName = dungeonName
                    MT.currentMapID       = mapID

                    MT.SetupKeyDisplay(mapID, level, affixes, dungeonName, " |cff888888(reload)|r")
                    wipe(MT.bossEncounterStart)
                    wipe(MT.bossKillData)
                    wipe(MT.bossLog)
                    wipe(MT.bossWipes)
                    wipe(MT.knownDeadGUIDs)
                    MT.frame:Show()

                    MT.HideDefaultTimer()
                    MT.UpdateEnemyForces()
                    C_Timer.After(0.3, MT.UpdateBosses)
                    MT.deathsFrozen = false
                    MT.RestoreDeathsSilently()
                    -- startTime = horloge reelle (sans penalites) : le temps officiel les inclut deja
                    MT.startTime    = GetTime() - (official - MT.GetDeathTimeLost())
                    MT.timerRunning = true
                    MT.StartDeathTracker()
                else
                    -- Retour dans le donjon apres sortie temporaire (ex: changement de talents).
                    -- La cle est deja active : recalibrer startTime avec le temps officiel.
                    -- Si le vote d'abandon a ete accepte, PLAYER_ENTERING_WORLD peut tirer avant
                    -- CHALLENGE_MODE_RESET : sans timer de cle on reset, sinon RESET suivra.
                    local official = MT.GetOfficialElapsed()
                    if not official then
                        OnChallengeModeReset()
                        return
                    end
                    if MT.timeLimit > 0 and not MT.keystoneCompleted then
                        MT.startTime    = GetTime() - (official - MT.GetDeathTimeLost())
                        MT.timerRunning = true
                    end
                    MT.HideDefaultTimer()
                    if not MT.frame:IsShown() then
                        MT.frame:Show()
                    end
                end
            elseif MT.keystoneActive then
                -- Plus de mapID actif apres PLAYER_ENTERING_WORLD.
                -- Si keystoneActive est true mais plus de mapID valide, la cle est terminee
                -- (completion ou abandon). Dans les deux cas on remet l'etat a zero.
                -- Note : un retour temporaire (changement de talents) conserve toujours un
                -- mapID valide -> il ne passe jamais dans cette branche.
                OnChallengeModeReset()
            end
        end)

    elseif event == "GROUP_ROSTER_UPDATE" then
        MT.CacheGroupNames()

    elseif event == "PLAYER_REGEN_ENABLED" then
        -- Fin du combat : SetParent etait peut-etre bloque, on refait HideDefaultTimer proprement.
        if MT.keystoneActive and MythicTimerDB and MythicTimerDB.hideDefault then
            MT.HideDefaultTimer()
        end

    elseif event == "SCENARIO_CRITERIA_UPDATE" then
        if not MT.keystoneActive then return end
        MT.UpdateEnemyForces()
        -- Ignorer apres completion : le scenario reinitialise ses criteres (completed=false)
        -- ce qui rendrait les noms de boss gris sans leurs timers.
        if not MT.keystoneCompleted then
            MT.UpdateBosses()
        end
    end
end

-- SetScript AVANT RegisterEvent (obligatoire en Midnight)
eventFrame:SetScript("OnEvent", OnEventSafe)
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("ENCOUNTER_START")
eventFrame:RegisterEvent("ENCOUNTER_END")
eventFrame:RegisterEvent("CHALLENGE_MODE_START")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:RegisterEvent("CHALLENGE_MODE_DEATH_COUNT_UPDATED")
eventFrame:RegisterEvent("CHALLENGE_MODE_RESET")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("SCENARIO_CRITERIA_UPDATE")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
