-- ============================================================
-- MythicTimer - Panneau Options & Bouton Minimap
-- ============================================================
local MT = MythicTimerAddon
local T  = MT.Theme

local PANEL_W = 400
local PAD     = 16
local GAP     = 10
local COL_W   = (PANEL_W - PAD * 2 - GAP) / 2
local ROW_W   = PANEL_W - PAD * 2

StaticPopupDialogs["MYTHICTIMER_CLEAR_HISTORY"] = {
    text         = MT.L["OPT_CONFIRM_CLEAR"],
    button1      = YES,
    button2      = NO,
    OnAccept     = function()
        MythicTimerDB.history = {}
        print(MT.L["OPT_FOOTER_CLEARED"])
        if MT.historyFrame and MT.historyFrame:IsShown() then MT.RefreshHistoryFrame() end
    end,
    timeout      = 0,
    whileDead    = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

local function pct(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end

local function RecenterTimer()
    MythicTimerDB.posX = MT.DEFAULT_SETTINGS.posX
    MythicTimerDB.posY = MT.DEFAULT_SETTINGS.posY
    MT.frame:ClearAllPoints()
    MT.frame:SetPoint("CENTER", UIParent, "CENTER", MythicTimerDB.posX, MythicTimerDB.posY)
    print(MT.L["OPT_FOOTER_CENTERED"])
end

function MT.BuildOptionsPanel()
    if MT.optionsPanel then return end
    local p = CreateFrame("Frame", "MythicTimerOptions", UIParent, "BackdropTemplate")
    MT.optionsPanel = p

    p:SetWidth(PANEL_W)
    p:SetPoint("CENTER")
    T.ApplyBackdrop(p, 0.96)
    p:SetMovable(true)
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", function(self) self:StartMoving() end)
    p:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
    p:SetFrameStrata("DIALOG")
    p:SetToplevel(true)
    p:Hide()
    T.CloseOnEscape("MythicTimerOptions")

    T.CreateHeader(p, MT.L["OPT_TITLE"], function() p:Hide() end)

    -- Tous les widgets ont un :Refresh(), rappele a chaque ouverture :
    -- les valeurs peuvent changer ailleurs (commandes /myt, bouton verrou des resultats...).
    local widgets = {}
    local y = -(T.HEADER_H + 14)

    local function Section(text)
        local fs = T.CreateSection(p, text, PAD)
        fs:SetPoint("TOPLEFT", PAD, y)
        y = y - 24
    end

    local function Checkbox(label, getter, setter, width)
        local cb = T.CreateCheckbox(p, label, getter, setter)
        cb:SetPoint("TOPLEFT", PAD, y)
        cb:SetWidth(width or ROW_W)
        widgets[#widgets + 1] = cb
        y = y - 24
        return cb
    end

    local function Slider(label, minV, maxV, step, getter, setter)
        local fs = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        fs:SetPoint("TOPLEFT", PAD, y)
        fs:SetText(label)
        local s = T.CreateSlider(p, minV, maxV, step, pct, getter, setter)
        s:SetPoint("TOPLEFT", PAD, y - 18)
        s:SetWidth(ROW_W)
        widgets[#widgets + 1] = s
        y = y - 44
    end

    -- ---- Fenetre du timer ----
    Section(MT.L["OPT_SEC_TIMER"])

    Checkbox(MT.L["OPT_LOCK"],
        function() return MythicTimerDB.locked end,
        function(v) MythicTimerDB.locked = v end)

    Checkbox(MT.L["OPT_HIDE_BLIZZ"],
        function() return MythicTimerDB.hideDefault end,
        function(v)
            MythicTimerDB.hideDefault = v
            if v then
                if MT.keystoneActive then MT.HideDefaultTimer() end
            else
                MT.ShowDefaultTimer()
            end
        end)

    local progLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    progLabel:SetPoint("TOPLEFT", PAD, y - 4)
    progLabel:SetText(MT.L["OPT_PROGRESS_LABEL"])
    local seg = T.CreateSegmented(p, {
            { value = "bar",  label = MT.L["OPT_PROGRESS_BAR"]  },
            { value = "text", label = MT.L["OPT_PROGRESS_TEXT"] },
        }, 180,
        function() return MythicTimerDB.progressMode or "bar" end,
        function(v)
            MythicTimerDB.progressMode = v
            MT.UpdateEnemyForces()
        end)
    seg:SetPoint("TOPRIGHT", -PAD, y)
    widgets[#widgets + 1] = seg
    y = y - 34

    Slider(MT.L["OPT_SCALE"], 0.8, 2.0, 0.05,
        function() return MythicTimerDB.scale or 1.0 end,
        function(v)
            MythicTimerDB.scale = v
            MT.frame:SetScale(v)
        end)

    Slider(MT.L["OPT_OPACITY"], 0, 1, 0.05,
        function() return MythicTimerDB.bgAlpha or MT.DEFAULT_SETTINGS.bgAlpha end,
        function(v)
            MythicTimerDB.bgAlpha = v
            MT.ApplyMainAlpha()
        end)

    -- ---- Alertes de mort ----
    y = y - 4
    Section(MT.L["OPT_SEC_DEATH"])

    Checkbox(MT.L["OPT_DEATH_SOUND"],
        function() return MythicTimerDB.deathSound ~= false end,
        function(v) MythicTimerDB.deathSound = v end)

    -- Ligne raccourcie pour laisser la place au bouton "Tester" a droite
    local alertCb = Checkbox(MT.L["OPT_DEATH_ALERT"],
        function() return MythicTimerDB.deathAlert ~= false end,
        function(v) MythicTimerDB.deathAlert = v end,
        ROW_W - 90)
    local testBtn = T.CreateButton(p, MT.L["OPT_BTN_TEST"], 80, 20, function()
        MT.ShowDeathAlert(UnitName("player") or "?")
    end)
    testBtn:SetPoint("LEFT", alertCb, "RIGHT", 10, 0)

    -- ---- Fenetres & outils ----
    y = y - 4
    Section(MT.L["OPT_SEC_MISC"])

    Checkbox(MT.L["OPT_MINIMAP"],
        function() return not (MythicTimerDB.minimap and MythicTimerDB.minimap.hide) end,
        function(v)
            MythicTimerDB.minimap.hide = not v
            local icon = LibStub("LibDBIcon-1.0")
            if v then icon:Show("MythicTimer") else icon:Hide("MythicTimer") end
        end)

    Checkbox(MT.L["OPT_LOCK_RESULT"],
        function() return MythicTimerDB.lockedResult end,
        function(v)
            MythicTimerDB.lockedResult = v
            MT.UpdateResultsLockButton()
        end)

    y = y - 6
    local actions = {
        { MT.L["OPT_BTN_TOGGLE_TIMER"], function() MT.frame:SetShown(not MT.frame:IsShown()) end },
        { MT.L["OPT_BTN_CENTER"],       RecenterTimer },
        { MT.L["OPT_BTN_HISTORY"],      function() p:Hide(); MT.ShowHistoryFrame() end },
        { MT.L["OPT_BTN_CLEAR"],        function() StaticPopup_Show("MYTHICTIMER_CLEAR_HISTORY") end },
        { MT.L["OPT_BTN_RESULT_POS"],   function() p:Hide(); MT.PreviewResultsFrame() end },
        { MT.L["OPT_BTN_FORCES"],       function() SlashCmdList["MTEFDBG"]("") end },
    }
    for i, def in ipairs(actions) do
        local col = (i - 1) % 2
        local row = math.floor((i - 1) / 2)
        local b = T.CreateButton(p, def[1], COL_W, 24, def[2])
        b:SetPoint("TOPLEFT", PAD + col * (COL_W + GAP), y - row * 30)
    end
    y = y - math.ceil(#actions / 2) * 30 - 6

    -- ---- Pied de page ----
    local footSep = T.CreateSeparator(p)
    footSep:SetPoint("TOPLEFT",  p, "TOPLEFT",  PAD, y)
    footSep:SetPoint("TOPRIGHT", p, "TOPRIGHT", -PAD, y)

    local version = C_AddOns.GetAddOnMetadata("MythicTimer", "Version") or "?"
    local author  = C_AddOns.GetAddOnMetadata("MythicTimer", "Author")  or "Vulca"
    local footer = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    footer:SetPoint("TOPLEFT", PAD, y - 10)
    footer:SetText(string.format("v%s  -  %s", version, author))

    local hint = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPRIGHT", -PAD, y - 10)
    hint:SetText(MT.L["OPT_FOOTER_HINT"])

    p:SetHeight(-y + 30)
    p:SetScript("OnShow", function()
        for _, w in ipairs(widgets) do w:Refresh() end
    end)

    MT.RegisterBlizzardSettings()
end

-- Entree dans Echap > Options > AddOns : renvoie vers notre propre fenetre.
function MT.RegisterBlizzardSettings()
    if MT.settingsCategory then return end
    if not (Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory) then return end

    local canvas = CreateFrame("Frame")

    local title = canvas:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("|cff00aaffMythic+|r Timer")

    local desc = canvas:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    desc:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    desc:SetText(MT.L["OPT_SETTINGS_DESC"])

    local open = T.CreateButton(canvas, MT.L["OPT_BTN_OPEN"], 200, 26, function()
        if SettingsPanel and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
        MT.optionsPanel:Show()
    end)
    open:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -14)

    local category = Settings.RegisterCanvasLayoutCategory(canvas, "Mythic+ Timer")
    Settings.RegisterAddOnCategory(category)
    MT.settingsCategory = category
end

function MT.BuildMinimapButton()
    if MT.minimapLDB then return end
    if not MythicTimerDB.minimap then
        MythicTimerDB.minimap = { hide = false, minimapPos = 220 }
    end

    -- Data object LibDataBroker : c'est ce que les gestionnaires de boutons minimap
    -- (ElvUI, Bartender4, Titan Panel, etc.) savent detecter et gerer automatiquement.
    MT.minimapLDB = LibStub("LibDataBroker-1.1"):NewDataObject("MythicTimer", {
        type = "launcher",
        text = "MythicTimer",
        icon = T.ICON,
        OnClick = function(self, btn)
            if btn == "RightButton" then
                if MT.frame:IsShown() then MT.frame:Hide() else MT.frame:Show() end
            elseif btn == "MiddleButton" then
                if MTEFPanel and MTEFPanel:IsShown() then
                    MTEFPanel:Hide()
                else
                    SlashCmdList["MTEFDBG"]("")  -- meme logique que /mtef
                end
            else
                if MT.optionsPanel:IsShown() then MT.optionsPanel:Hide() else MT.optionsPanel:Show() end
            end
        end,
        OnTooltipShow = function(tooltip)
            tooltip:AddLine(MT.L["MINIMAP_TOOLTIP"], 1, 1, 1)
            tooltip:AddLine(MT.L["MINIMAP_TOOLTIP_L"], 0.8, 0.8, 0.8)
            tooltip:AddLine(MT.L["MINIMAP_TOOLTIP_R"], 0.8, 0.8, 0.8)
            tooltip:AddLine(MT.L["MINIMAP_TOOLTIP_M"], 0.8, 0.8, 0.8)
        end,
    })

    -- LibDBIcon gere le placement autour de la minimap, le drag, et surtout
    -- l'integration avec les addons tiers qui savent recuperer les icones LDB.
    LibStub("LibDBIcon-1.0"):Register("MythicTimer", MT.minimapLDB, MythicTimerDB.minimap)
end
