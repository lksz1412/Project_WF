﻿-- ============================================================
-- MythicTimer - Core
-- Table module partagee entre tous les fichiers de l'addon.
-- Ce fichier DOIT etre liste en premier dans le .toc.
-- ============================================================

-- Table module globale (accessible depuis tous les fichiers via local MT = MythicTimerAddon)
MythicTimerAddon = MythicTimerAddon or {}
local MT = MythicTimerAddon

-- ---- Configuration par defaut ----
MT.DEFAULT_SETTINGS = {
    posX = 0,
    posY = 200,
    locked = false,
    hideDefault = true,
    scale = 1.0,
    bgAlpha = 0.85,        -- opacite du fond de la fenetre du timer
    minimap = { hide = false, minimapPos = 220 },
    posXResult = 200,
    posYResult = 50,
    lockedResult = false,
    progressMode = "bar",  -- "bar" ou "text"
    posXHistory = 0,
    posYHistory = 80,
    deathSound = true,     -- jouer le son a chaque mort
    deathAlert = true,     -- afficher le texte a l'ecran a chaque mort
}

-- ---- Etat partage ----
MT.addonName          = "MythicTimer"
MT.frame              = nil     -- fenetre principale (cree dans UI.lua)
MT.optionsPanel       = nil     -- panneau options (cree dans Options.lua)
MT.minimapLDB         = nil     -- data object LibDataBroker du bouton minimap (cree dans Options.lua)
MT.timerRunning       = false
MT.startTime          = 0
MT.timeLimit          = 0       -- temps total de la cle (secondes)
MT.level2Time         = 0       -- seuil +2
MT.level3Time         = 0       -- seuil +3
MT.deathCount         = 0
MT.deathTimeLost      = 0       -- penalite totale (secondes), source serveur
MT.deathsFrozen       = false   -- true apres CHALLENGE_MODE_COMPLETED
MT.deathLog           = {}      -- { name, elapsed } par mort
MT.knownDeadGUIDs     = {}      -- GUID -> true si le joueur est mort (evite le double-comptage)
MT.bossEncounterStart = {}      -- encounterID -> GetTime() au pull
MT.bossKillData       = {}      -- encounterID/name -> { killTime, fightDuration } (pour Bosses.lua)
MT.bossLog            = {}      -- liste ordonnee { name, killTime, fightDuration, wipes } pour le popup
MT.bossWipes          = {}      -- encounterID -> nombre de wipes sur ce boss
MT.keystoneLevel      = 0
MT.currentProgress    = 0       -- pourcentage trash (0-100)
MT.currentDungeonName = ""
MT.MAX_BOSSES         = 8       -- slots boss pre-alloues dans l'UI
MT.prepPhase          = false   -- compte a rebours 10s avant le vrai demarrage
MT.prepEndTime        = 0       -- timestamp fin du compte a rebours
MT.keystoneActive     = false   -- true entre CHALLENGE_MODE_START et CHALLENGE_MODE_RESET
MT.keystoneCompleted  = false   -- true apres CHALLENGE_MODE_COMPLETED, fige l'affichage boss

-- ============================================================
-- UTILITAIRES (utilises dans tous les fichiers)
-- ============================================================

-- Penalite totale de mort en secondes (mise a jour par MT.SyncDeaths depuis le serveur).
function MT.GetDeathTimeLost()
    return MT.deathTimeLost or 0
end

-- Temps officiel ecoule (penalites incluses), ou nil si aucune cle ne tourne.
-- GetTimeRemainingSeconds tombe a 0 une fois le timer depasse : on passe alors par
-- le timer de monde "challenge mode" (celui du tracker Blizzard), qui continue au-dela.
function MT.GetOfficialElapsed()
    local r = C_ChallengeMode.GetTimeRemainingSeconds and C_ChallengeMode.GetTimeRemainingSeconds()
    if r and r > 0 and MT.timeLimit > 0 then
        return MT.timeLimit - r
    end
    if GetWorldElapsedTimers and GetWorldElapsedTime then
        local challengeType = (Enum.WorldElapsedTimerTypes and Enum.WorldElapsedTimerTypes.ChallengeMode)
            or LE_WORLD_ELAPSED_TIMER_TYPE_CHALLENGE_MODE
        for _, id in ipairs({ GetWorldElapsedTimers() }) do
            local _, elapsed, timerType = GetWorldElapsedTime(id)
            if timerType == challengeType and elapsed and elapsed > 0 then
                return elapsed
            end
        end
    end
end

-- Estimation par mort, utilisee seulement si le serveur n'a encore rien compte.
function MT.GetDeathPenalty()
    if MT.keystoneLevel >= 12 then
        return 15
    elseif MT.keystoneLevel >= 6 then
        return 5
    else
        return 0
    end
end

-- Tronque un nom a maxLen octets sans couper un caractere UTF-8 en deux
-- (les accents francais prennent 2 octets : sub() seul peut afficher un glyphe casse).
function MT.ShortName(name, maxLen)
    if #name <= maxLen then return name end
    local cut = maxLen - 1
    -- Recule tant que l'octet suivant est un octet de continuation (10xxxxxx)
    while cut > 0 do
        local b = name:byte(cut + 1)
        if not b or b < 0x80 or b >= 0xC0 then break end
        cut = cut - 1
    end
    return name:sub(1, cut) .. "."
end

function MT.FormatTime(seconds)
    if seconds < 0 then seconds = 0 end
    local m = math.floor(seconds / 60)
    local s = seconds % 60
    return string.format("%02d:%02d", m, s)
end

-- Helper : remonte jusqu'au parent direct de UIParent (meme logique que MythicPlusTimer).
-- Gere le cas ou un autre addon a imbrique l'ObjectiveTracker dans un container.
function MT.GetTrackerRoot()
    local frame = ObjectiveTrackerFrame
    if not frame then return nil end
    local current = frame
    while true do
        local p = current:GetParent()
        if not p or p == UIParent or p == MT.hiddenTrackerFrame then
            return current
        end
        current = p
    end
end

-- Masque le tracker natif M+ (ObjectiveTrackerFrame).
-- Re-parentage vers un frame fantome invisible : WoW ne peut plus appeler Show().
-- En combat (InCombatLockdown), SetParent est bloque -> fallback SetAlpha dans OnUpdate.
-- PLAYER_REGEN_ENABLED rappelle HideDefaultTimer pour faire le SetParent des que le combat se termine.
function MT.HideDefaultTimer()
    if not MythicTimerDB.hideDefault then return end
    if not MT.hiddenTrackerFrame then return end
    local root = MT.GetTrackerRoot()
    if not root then return end
    if InCombatLockdown() then
        root:SetAlpha(0)   -- fallback combat
    else
        root:SetParent(MT.hiddenTrackerFrame)
    end
end

function MT.ShowDefaultTimer()
    if not MT.hiddenTrackerFrame then
        if ObjectiveTrackerFrame then ObjectiveTrackerFrame:SetAlpha(1) end
        return
    end
    local root = MT.GetTrackerRoot()
    if not root then return end
    root:SetAlpha(1)
    if not InCombatLockdown() then
        if root:GetParent() == MT.hiddenTrackerFrame then
            root:SetParent(UIParent)
        end
    end
end
