local MT = MythicTimerAddon

-- ============================================================
-- EnemyForces.lua - Panel statique M+ Forces
-- Approche : pas d'identification runtime des mobs (impossible
-- en Midnight 12.x - toutes les APIs retournent des secret
-- strings en instance). On affiche la liste complete des mobs
-- du donjon courant avec leurs forces %.
-- Detection : C_Map.GetBestMapForUnit("player") ->
-- MDT.zoneIdToDungeonIdx -> MDT.dungeonEnemies[dungeonIdx]
-- ============================================================

-- ============================================================
-- Cache par donjon
-- dungeonCache[dungeonIdx] = {
--   totalCount = N,
--   mobs = { {name, count, pct, npcID}, ... } tries par pct desc
-- }
-- ============================================================
local dungeonCache = {}

local function buildDungeonCache(dungeonIdx)
    if dungeonCache[dungeonIdx] then return dungeonCache[dungeonIdx] end
    if not MDT or not MDT.dungeonEnemies then return nil end

    local enemies  = MDT.dungeonEnemies[dungeonIdx]
    local totalInfo = MDT.dungeonTotalCount and MDT.dungeonTotalCount[dungeonIdx]
    if not enemies or not totalInfo then return nil end

    local total = totalInfo.normal or 0
    if total <= 0 then return nil end

    local seen = {}
    local mobs = {}
    local L = MDT.L  -- table plate : L["English key"] = "Nom traduit" (selon locale chargee)
    for _, enemy in pairs(enemies) do
        if enemy.id and enemy.count and enemy.count > 0 and not seen[enemy.id] then
            seen[enemy.id] = true
            -- MDT.L contient les traductions de la locale active du client
            -- Si la cle n'existe pas dans L, on retombe sur enemy.name (anglais)
            local name = (L and enemy.name and L[enemy.name]) or enemy.name or ("NPC #" .. enemy.id)
            mobs[#mobs + 1] = {
                name  = name,
                count = enemy.count,
                pct   = (enemy.count / total) * 100,
                npcID = enemy.id,
            }
        end
    end

    table.sort(mobs, function(a, b) return a.pct > b.pct end)

    dungeonCache[dungeonIdx] = { totalCount = total, mobs = mobs }
    return dungeonCache[dungeonIdx]
end

-- ============================================================
-- Detection du donjon courant via MDT.zoneIdToDungeonIdx
-- Remonte la hierarchie de cartes : GetBestMapForUnit retourne
-- l'ID de sous-zone (etage), pas l'ID racine indexe par MDT.
-- ============================================================
local function getCurrentDungeonIdx()
    if not MDT or not MDT.zoneIdToDungeonIdx then return nil end

    -- Remontee hierarchique depuis la position courante du joueur
    local mapID = C_Map.GetBestMapForUnit("player")
    local cur = mapID
    while cur do
        local idx = MDT.zoneIdToDungeonIdx[cur]
        if idx then return idx end
        local info = C_Map.GetMapInfo(cur)
        if not info or not info.parentMapID or info.parentMapID == cur then break end
        cur = info.parentMapID
    end

    -- Fallback : le challenge map ID est souvent identique au UI map ID du donjon
    if C_ChallengeMode and C_ChallengeMode.GetActiveChallengeMapID then
        local cmapID = C_ChallengeMode.GetActiveChallengeMapID()
        if cmapID then
            local idx = MDT.zoneIdToDungeonIdx[cmapID]
            if idx then return idx end
        end
    end

    return nil
end

-- ============================================================
-- Panel UI
-- ============================================================
local T = MT.Theme
local panel = CreateFrame("Frame", "MTEFPanel", UIParent, "BackdropTemplate")
panel:SetSize(260, 400)
panel:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -200, -200)
T.ApplyBackdrop(panel, 0.9)
panel:SetMovable(true)
panel:SetClampedToScreen(true)
panel:EnableMouse(true)
panel:RegisterForDrag("LeftButton")
panel:SetScript("OnDragStart", panel.StartMoving)
panel:SetScript("OnDragStop",  panel.StopMovingOrSizing)
panel:Hide()
T.CloseOnEscape("MTEFPanel")

local header = T.CreateHeader(panel, "|cff00ccffM+ Forces|r", function() panel:Hide() end)
local titleText = header.title
titleText:SetFontObject("GameFontNormalSmall")

local scrollFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT",     panel, "TOPLEFT",   6, -(T.HEADER_H + 6))
scrollFrame:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -24, 6)

local content = CreateFrame("Frame", nil, scrollFrame)
content:SetSize(230, 10)
scrollFrame:SetScrollChild(content)

local linePool = {}
local function getLine(i)
    if not linePool[i] then
        local fs = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", content, "TOPLEFT", 4, -((i - 1) * 14))
        fs:SetWidth(218)
        fs:SetJustifyH("LEFT")
        linePool[i] = fs
    end
    return linePool[i]
end

local function clearLines(from)
    for i = from, #linePool do linePool[i]:SetText("") end
end

local function populatePanel(dungeonIdx)
    local data = buildDungeonCache(dungeonIdx)
    if not data then
        titleText:SetText("|cff00ccffM+ Forces|r  |cffff4444(MDT absent)|r")
        clearLines(1)
        panel:SetHeight(66)
        return
    end

    local dungeonName = MDT.dungeonList and MDT.dungeonList[dungeonIdx] or ("Donjon #" .. dungeonIdx)
    titleText:SetText(string.format("|cff00ccffM+ Forces|r  |cffffcc00%s|r  |cffaaaaaa(/%d)|r",
        tostring(dungeonName), data.totalCount))

    local lineIdx = 1
    for _, mob in ipairs(data.mobs) do
        local color
        if mob.pct >= 1.0     then color = "|cff44ff44"
        elseif mob.pct >= 0.3 then color = "|cffffd700"
        else                       color = "|cffff9999" end

        getLine(lineIdx):SetText(string.format(
            "%s%.2f%%|r  |cffdddddd%s|r  |cffaaaaaa(%d)|r",
            color, mob.pct, mob.name, mob.count
        ))
        lineIdx = lineIdx + 1
    end
    clearLines(lineIdx)

    content:SetHeight(lineIdx * 14 + 4)
    panel:SetHeight(math.min(400, 36 + lineIdx * 14))
end

-- ============================================================
-- Mise a jour automatique au changement de zone
-- ============================================================
local function refresh()
    if not panel:IsShown() then return end
    dungeonCache = {}
    local dungeonIdx = getCurrentDungeonIdx()
    if dungeonIdx then
        populatePanel(dungeonIdx)
    else
        titleText:SetText("|cff00ccffM+ Forces|r  |cffaaaaaa(hors donjon)|r")
        clearLines(1)
        content:SetHeight(20)
        panel:SetHeight(66)
    end
end

local efFrame = CreateFrame("Frame")
efFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
efFrame:RegisterEvent("CHALLENGE_MODE_START")
efFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
efFrame:SetScript("OnEvent", function() C_Timer.After(1.5, refresh) end)

-- ============================================================
-- /mtefdbg  -> diagnostic console (mapID, MDT tables, dungeonIdx)
-- ============================================================
SLASH_MTEFINFO1 = "/mtefdbg"
SlashCmdList["MTEFINFO"] = function()
    print("|cff00ccff[MTEFdbg]|r ---- diagnostic ----")
    local mapID = C_Map.GetBestMapForUnit("player")
    print("  GetBestMapForUnit('player') = " .. tostring(mapID))
    if mapID then
        local info = C_Map.GetMapInfo(mapID)
        print("  MapInfo : name=" .. tostring(info and info.name) .. "  parent=" .. tostring(info and info.parentMapID))
    end
    if C_ChallengeMode then
        local cmapID = C_ChallengeMode.GetActiveChallengeMapID and C_ChallengeMode.GetActiveChallengeMapID()
        print("  GetActiveChallengeMapID() = " .. tostring(cmapID))
    end
    if not MDT then
        print("  MDT = nil (addon absent ou pas encore charge)")
    else
        print("  MDT present, zoneIdToDungeonIdx = " .. (MDT.zoneIdToDungeonIdx and "OK" or "NIL"))
        print("  MDT.dungeonEnemies = " .. (MDT.dungeonEnemies and "OK" or "NIL"))
        print("  MDT.dungeonTotalCount = " .. (MDT.dungeonTotalCount and "OK" or "NIL"))
    end
    local dungeonIdx = getCurrentDungeonIdx()
    print("  getCurrentDungeonIdx() = " .. tostring(dungeonIdx))
    if dungeonIdx and MDT.dungeonList then
        print("  dungeonList[" .. dungeonIdx .. "] = " .. tostring(MDT.dungeonList[dungeonIdx]))
    end
end

-- ============================================================
-- /mtef  -> toggle panel
-- ============================================================
SLASH_MTEFDBG1 = "/mtef"
SlashCmdList["MTEFDBG"] = function(msg)
    if panel:IsShown() then
        panel:Hide()
        return
    end

    dungeonCache = {}
    local dungeonIdx = getCurrentDungeonIdx()

    if dungeonIdx then
        populatePanel(dungeonIdx)
    else
        titleText:SetText("|cff00ccffM+ Forces|r  |cffaaaaaa(hors donjon M+)|r")
        clearLines(1)
        content:SetHeight(20)
        panel:SetHeight(66)
    end
    panel:Show()
end
