-- ============================================================
-- MythicTimer - Interface principale
-- Fenetre principale, labels, barres, OnUpdate
-- ============================================================
local MT = MythicTimerAddon
local T  = MT.Theme
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

-- ---- Geometrie de la fenetre principale ----
local FRAME_W   = 250
local BOSS_TOP  = -74   -- haut de la zone boss (sous les affixes)
local BOSS_STEP = 15    -- hauteur d'une ligne de boss
local BOTTOM_H  = 152   -- bloc timer (78) + marge + bloc trash/morts ancre en bas (68)

function MT.ApplyMainAlpha()
    if not MT.frame then return end
    MT.frame:SetBackdropColor(T.rgb(T.C.bg, MythicTimerDB.bgAlpha or MT.DEFAULT_SETTINGS.bgAlpha))
end

-- Place le bloc timer sous la liste des boss et ajuste la hauteur de la fenetre.
-- Seul endroit qui connait la mise en page verticale (Events.lua et Bosses.lua l'appellent).
function MT.LayoutMainFrame(bossCount)
    local frame = MT.frame
    if not frame then return end
    bossCount = math.min(bossCount or 0, MT.MAX_BOSSES)
    local timerTop = BOSS_TOP
    if bossCount > 0 then
        timerTop = BOSS_TOP - 12 - bossCount * BOSS_STEP
    end
    frame.bossSep:SetShown(bossCount > 0)
    frame.timer:ClearAllPoints()
    frame.timer:SetPoint("TOP", frame, "TOP", 0, timerTop)
    frame:SetSize(FRAME_W, -timerTop + BOTTOM_H)
end

-- Remet la fenetre a zero pour une nouvelle cle : donjon, affixes, seuils, barres.
-- Appele au CHALLENGE_MODE_START et a la reprise apres un /reload en cle.
function MT.SetupKeyDisplay(mapID, level, affixes, dungeonName, suffix)
    local frame = MT.frame
    frame.dungeon:SetText(string.format("|cffffd100+%d|r  %s%s", level, dungeonName, suffix or ""))
    frame.thresh2:SetText("+2 : " .. MT.FormatTime(MT.timeLimit - MT.level2Time))
    frame.thresh3:SetText("+3 : " .. MT.FormatTime(MT.timeLimit - MT.level3Time))
    frame.deaths:SetText(MT.L["DEATHS_NONE"])
    T.SetHeaderDungeon(frame.header, mapID)

    for i = 1, 4 do frame.affixIcons[i]:Hide() end
    if affixes then
        local iconSize, gap = 20, 4
        local totalW = #affixes * iconSize + (#affixes - 1) * gap
        local startX = -(totalW / 2) + iconSize / 2
        for i, affixID in ipairs(affixes) do
            local _, _, fileDataID = C_ChallengeMode.GetAffixInfo(affixID)
            local icon = frame.affixIcons[i]
            if fileDataID and icon then
                icon.tex:SetTexture(fileDataID)
                icon.affixID = affixID
                icon:ClearAllPoints()
                icon:SetPoint("TOP", frame, "TOP", startX + (i - 1) * (iconSize + gap), -50)
                icon:Show()
            end
        end
    end

    frame.progressBar:SetValue(0)
    frame.progressBar:SetStatusBarColor(T.rgb(T.C.gold))
    frame.progressText:SetText(L("TRASH_PCT", 0))
    frame.elapsed:SetText("")
    frame.timeBar.bar:SetValue(0)
    frame.tickLimit = nil
    for _, tick in ipairs(frame.timeTicks) do tick:Hide() end
    for i = 1, MT.MAX_BOSSES do frame.bossLabels[i]:Hide() end
    MT.LayoutMainFrame(0)
end

-- Reperes +3 / +2 sur la barre de temps (recalcules seulement si la limite change)
local function UpdateTimeTicks(frame)
    if MT.timeLimit <= 0 or frame.tickLimit == MT.timeLimit then return end
    frame.tickLimit = MT.timeLimit
    local w = frame.timeBar:GetWidth() - 2
    for i, t in ipairs({ MT.level3Time, MT.level2Time }) do
        local tick = frame.timeTicks[i]
        tick:ClearAllPoints()
        tick:SetPoint("CENTER", frame.timeBar, "LEFT", 1 + w * (t / MT.timeLimit), 0)
        tick:Show()
    end
end

function MT.BuildUI()
    if MT.frame then return end  -- protection contre double appel (reload)
    MT.frame = CreateFrame("Frame", "MythicTimerFrame", UIParent, "BackdropTemplate")
    local frame = MT.frame

    frame:SetSize(FRAME_W, -BOSS_TOP + BOTTOM_H)
    frame:SetPoint("CENTER", UIParent, "CENTER", MythicTimerDB.posX, MythicTimerDB.posY)
    frame:SetScale(MythicTimerDB.scale or 1.0)
    T.ApplyBackdrop(frame)
    MT.ApplyMainAlpha()
    frame:SetFrameStrata("HIGH")
    frame:SetClampedToScreen(true)

    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        if not MythicTimerDB.locked then self:StartMoving() end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x = self:GetLeft() + self:GetWidth()  / 2 - UIParent:GetWidth()  / 2
        local y = self:GetTop()  - self:GetHeight() / 2 - UIParent:GetHeight() / 2
        MythicTimerDB.posX = x
        MythicTimerDB.posY = y
    end)

    -- Bandeau titre (icone + illustration du donjon une fois la cle lancee) et croix
    local header = T.CreateHeader(frame, "|cff00aaffMythic+|r Timer", function() frame:Hide() end)
    frame.title = header.title

    -- Niveau + nom du donjon
    frame.dungeon = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.dungeon:SetPoint("TOP", frame, "TOP", 0, -32)
    frame.dungeon:SetWidth(FRAME_W - 20)
    frame.dungeon:SetWordWrap(false)
    frame.dungeon:SetTextColor(T.rgb(T.C.text))
    frame.dungeon:SetText(MT.L["WAITING_KEY"])

    -- Icones des affixes (max 4), positionnees par MT.SetupKeyDisplay
    frame.affixIcons = {}
    for i = 1, 4 do
        local btn = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        btn:SetSize(20, 20)
        btn:SetBackdrop({ edgeFile = T.FLAT, edgeSize = 1 })
        btn:SetBackdropBorderColor(0, 0, 0, 1)
        btn:EnableMouse(true)
        local tex = btn:CreateTexture(nil, "ARTWORK")
        tex:SetPoint("TOPLEFT", 1, -1)
        tex:SetPoint("BOTTOMRIGHT", -1, 1)
        tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        btn.tex = tex
        btn:SetScript("OnEnter", function(self)
            if not self.affixID then return end
            local name, desc = C_ChallengeMode.GetAffixInfo(self.affixID)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(name or "?", 1, 0.8, 0)
            if desc and desc ~= "" then
                GameTooltip:AddLine(desc, 1, 1, 1, true)
            end
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        btn:Hide()
        frame.affixIcons[i] = btn
    end

    -- Separateur avant les boss
    frame.bossSep = T.CreateSeparator(frame)
    frame.bossSep:SetPoint("TOPLEFT",  frame, "TOPLEFT",  12, BOSS_TOP)
    frame.bossSep:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, BOSS_TOP)
    frame.bossSep:Hide()

    -- Labels des boss (pre-alloues)
    frame.bossLabels = {}
    for i = 1, MT.MAX_BOSSES do
        local lbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, BOSS_TOP - 6 - (i - 1) * BOSS_STEP)
        lbl:SetWidth(FRAME_W - 24)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        lbl:SetNonSpaceWrap(false)
        lbl:Hide()
        frame.bossLabels[i] = lbl
    end

    -- ---- Bloc timer (ancre sur frame.timer, deplace en bloc par LayoutMainFrame) ----
    frame.timer = frame:CreateFontString(nil, "OVERLAY")
    frame.timer:SetFont(T.FONT, 30, "OUTLINE")
    frame.timer:SetShadowOffset(1, -1)
    frame.timer:SetShadowColor(0, 0, 0, 0.9)
    frame.timer:SetText("--:--")

    frame.elapsed = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.elapsed:SetPoint("TOP", frame.timer, "TOP", 0, -34)
    frame.elapsed:SetTextColor(T.rgb(T.C.cyan))
    frame.elapsed:SetText("")

    -- Barre de temps ecoule, avec reperes aux seuils +3 et +2
    frame.timeBar = T.CreateBar(frame, 8)
    frame.timeBar:SetWidth(FRAME_W - 24)
    frame.timeBar:SetPoint("TOP", frame.timer, "TOP", 0, -52)
    frame.timeBar.bar:SetStatusBarColor(T.rgb(T.C.good))
    frame.timeTicks = {}
    for i = 1, 2 do
        local tick = frame.timeBar.bar:CreateTexture(nil, "OVERLAY")
        tick:SetColorTexture(1, 1, 1, 1)
        tick:SetSize(2, 12)
        tick:Hide()
        frame.timeTicks[i] = tick
    end

    -- Seuils : +3 a gauche, +2 a droite (meme ordre que les reperes sur la barre)
    frame.thresh3 = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.thresh3:SetPoint("TOPLEFT", frame.timeBar, "BOTTOMLEFT", 0, -4)
    frame.thresh3:SetText("+3 : --:--")

    frame.thresh2 = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.thresh2:SetPoint("TOPRIGHT", frame.timeBar, "BOTTOMRIGHT", 0, -4)
    frame.thresh2:SetText("+2 : --:--")

    -- ---- Bloc bas (ancre au bas de la fenetre) ----
    frame.forcesSep = T.CreateSeparator(frame)
    frame.forcesSep:SetPoint("BOTTOMLEFT",  frame, "BOTTOMLEFT",  12, 68)
    frame.forcesSep:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 68)

    -- Mode "bar" : barre de statut du jeu, texte centre par-dessus
    frame.progressBg = T.CreateBar(frame, 18)
    frame.progressBg:SetWidth(FRAME_W - 24)
    frame.progressBg:SetPoint("BOTTOM", frame, "BOTTOM", 0, 42)
    frame.progressBar = frame.progressBg.bar
    frame.progressBar:SetStatusBarColor(T.rgb(T.C.gold))

    frame.progressText = frame.progressBar:CreateFontString(nil, "OVERLAY")
    frame.progressText:SetFont(T.FONT, 13, "OUTLINE")
    frame.progressText:SetShadowOffset(1, -1)
    frame.progressText:SetPoint("CENTER", frame.progressBg, "CENTER", 0, 0)
    frame.progressText:SetText(L("TRASH_PCT", 0))

    -- Mode "text" : pourcentage seul, en grand
    frame.progressTextLarge = frame:CreateFontString(nil, "OVERLAY")
    frame.progressTextLarge:SetFont(T.FONT, 22, "OUTLINE")
    frame.progressTextLarge:SetShadowOffset(1, -1)
    frame.progressTextLarge:SetPoint("BOTTOM", frame, "BOTTOM", 0, 40)
    frame.progressTextLarge:SetText("")
    frame.progressTextLarge:Hide()

    -- ETA fin du trash (visible > 20%, cache a 100% ou avant le seuil)
    frame.trashETA = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.trashETA:SetPoint("BOTTOM", frame, "BOTTOM", 0, 26)
    frame.trashETA:SetTextColor(T.rgb(T.C.cyan))
    frame.trashETA:SetText("")
    frame.trashETA:Hide()

    -- Compteur de morts (zone cliquable) avec icone tete de mort
    frame.deathsHitbox = CreateFrame("Frame", nil, frame)
    frame.deathsHitbox:SetSize(FRAME_W - 20, 18)
    frame.deathsHitbox:SetPoint("BOTTOM", frame, "BOTTOM", 0, 5)
    frame.deathsHitbox:EnableMouse(true)
    frame.deathsHitbox:SetScript("OnEnter", function(self)
        if MT.deathCount == 0 then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(MT.L["DEATHS_TOOLTIP_TITLE"], 1, 1, 1)
        GameTooltip:AddLine(" ")
        for _, entry in ipairs(MT.deathLog) do
            GameTooltip:AddDoubleLine(
                "|cffffff00" .. entry.name .. "|r",
                "|cffaaaaaa" .. MT.FormatTime(entry.elapsed) .. "|r",
                1, 1, 1, 1, 1, 1
            )
        end
        GameTooltip:Show()
    end)
    frame.deathsHitbox:SetScript("OnLeave", function() GameTooltip:Hide() end)

    frame.deaths = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.deaths:SetPoint("BOTTOM", frame, "BOTTOM", 8, 8)
    frame.deaths:SetText(MT.L["DEATHS_NONE"])

    frame.deathIcon = frame:CreateTexture(nil, "OVERLAY")
    frame.deathIcon:SetTexture(T.SKULL)
    frame.deathIcon:SetSize(14, 14)
    frame.deathIcon:SetPoint("RIGHT", frame.deaths, "LEFT", -4, 0)

    MT.LayoutMainFrame(0)

    -- ---- OnUpdate ----
    local prepFont = false  -- police reduite pendant le compte a rebours (texte plus long)
    local function SetPrepFont(on)
        if prepFont == on then return end
        prepFont = on
        frame.timer:SetFont(T.FONT, on and 20 or 30, "OUTLINE")
    end

    local function OnUpdateSafe(self, elapsed)
        -- ---- Fallback masquage timer Blizzard (combat uniquement) ----
        -- Si la keystone est active et que le tracker n'a pas pu etre re-parente
        -- (InCombatLockdown au moment du start), SetAlpha sert de dernier recours.
        -- Des que le combat se termine, PLAYER_REGEN_ENABLED fait le vrai SetParent.
        if MT.keystoneActive and MythicTimerDB and MythicTimerDB.hideDefault then
            local root = MT.GetTrackerRoot and MT.GetTrackerRoot()
            if root and MT.hiddenTrackerFrame and root:GetParent() ~= MT.hiddenTrackerFrame then
                local t = GetTime()
                if t - (MT.lastHideCheck or 0) >= 0.2 then
                    MT.lastHideCheck = t
                    root:SetAlpha(0)
                end
            end
        end

        if MT.prepPhase then
            local countdown = math.floor(MT.prepEndTime - GetTime())
            if countdown <= 0 then countdown = 0 end
            SetPrepFont(true)
            frame.timer:SetTextColor(T.rgb(T.C.gold))
            frame.timer:SetText(L("COUNTDOWN_FMT", countdown))
            frame.elapsed:SetText("")
            return
        end
        SetPrepFont(false)

        -- (suivi des morts gere par MT.StartDeathTracker dans Events.lua)

        if not MT.timerRunning then return end

        local remaining
        if C_ChallengeMode.GetTimeRemainingSeconds then
            remaining = C_ChallengeMode.GetTimeRemainingSeconds()
        end
        if not remaining or remaining == 0 then
            local now = GetTime()
            local elapsedTotal = (now - MT.startTime) + MT.GetDeathTimeLost()
            remaining = MT.timeLimit - elapsedTotal
        end

        local ratio = 1 - (remaining / MT.timeLimit)
        local c
        if remaining <= 0 then
            c = T.C.bad
        elseif ratio >= 0.85 then
            c = T.C.warn
        else
            c = T.C.good
        end
        frame.timer:SetTextColor(T.rgb(c))
        frame.timeBar.bar:SetStatusBarColor(T.rgb(c))
        frame.timeBar.bar:SetValue(math.max(0, math.min(1, ratio)))
        UpdateTimeTicks(frame)

        if remaining <= 0 then
            frame.timer:SetText("+" .. MT.FormatTime(math.abs(remaining)))
        else
            frame.timer:SetText(MT.FormatTime(remaining))
        end

        local elapsedSec = math.floor(GetTime() - MT.startTime)
        frame.elapsed:SetText(L("ELAPSED", MT.FormatTime(elapsedSec)))

        -- Seuils : vert tant qu'atteignable, rouge une fois perdu (repere grise sur la barre)
        local ok3 = remaining >= MT.timeLimit - MT.level3Time
        local ok2 = remaining >= MT.timeLimit - MT.level2Time
        frame.thresh3:SetTextColor(T.rgb(ok3 and T.C.good or T.C.bad))
        frame.thresh2:SetTextColor(T.rgb(ok2 and T.C.good or T.C.bad))
        frame.timeTicks[1]:SetVertexColor(1, 1, 1, ok3 and 0.95 or 0.35)
        frame.timeTicks[2]:SetVertexColor(1, 1, 1, ok2 and 0.95 or 0.35)

        -- Mise a jour live des boss en combat (toutes les secondes)
        -- Permet d'afficher la duree du combat qui s'ecoule en temps reel.
        -- Apres completion, le scenario reinitialise info.completed=false pour tous les criteres :
        -- on arrete la mise a jour pour eviter d'afficher le mode "en combat" sur des boss tues.
        if next(MT.bossEncounterStart) and not MT.keystoneCompleted then
            local now = GetTime()
            if now - (MT.lastBossLiveUpdate or 0) >= 1.0 then
                MT.lastBossLiveUpdate = now
                MT.UpdateBosses()
            end
        end
    end

    -- Pas de pcall : WoW affiche les erreurs nativement (popup rouge avec numero de ligne)
    frame:SetScript("OnUpdate", OnUpdateSafe)

    MT.BuildDeathAlert()
    frame:Hide()
end

-- ============================================================
-- ALERTE MORT
-- Bandeau sombre en haut de l'ecran, texte rouge encadre de tetes de mort,
-- apparition rapide puis fondu.
-- Joue le son Interface\AddOns\MythicTimer\sounds\death.ogg
-- ============================================================

function MT.BuildDeathAlert()
    if MT.deathAlertFrame then return end

    local f = CreateFrame("Frame", "MythicTimerDeathAlert", UIParent)
    f:SetSize(700, 70)
    -- Tiers superieur de l'ecran (visible sans masquer le combat)
    f:SetPoint("TOP", UIParent, "TOP", 0, -200)
    f:SetFrameStrata("TOOLTIP")   -- au-dessus de tout, meme les barres de boss
    f:SetFrameLevel(100)
    f:SetAlpha(0)
    f:Hide()

    -- Bandeau degrade + liserés rouges : lisible sur n'importe quel decor
    local band = T.CreateFadeBand(f, { 0, 0, 0 }, 0.7, 50)
    band:SetPoint("LEFT")
    band:SetPoint("RIGHT")
    local top = T.CreateFadeBand(f, T.C.bad, 0.9, 1)
    top:SetPoint("BOTTOMLEFT",  band, "TOPLEFT")
    top:SetPoint("BOTTOMRIGHT", band, "TOPRIGHT")
    local bottom = T.CreateFadeBand(f, T.C.bad, 0.9, 1)
    bottom:SetPoint("TOPLEFT",  band, "BOTTOMLEFT")
    bottom:SetPoint("TOPRIGHT", band, "BOTTOMRIGHT")

    -- Le texte vit sur un frame au-dessus des bandes (les frames enfants couvrent les regions du parent)
    local textHolder = CreateFrame("Frame", nil, f)
    textHolder:SetAllPoints()
    textHolder:SetFrameLevel(f:GetFrameLevel() + 10)

    local lbl = textHolder:CreateFontString(nil, "OVERLAY")
    lbl:SetFont(T.FONT, 30, "OUTLINE")
    lbl:SetShadowOffset(2, -2)
    lbl:SetShadowColor(0, 0, 0, 1)
    lbl:SetPoint("CENTER")
    lbl:SetTextColor(1, 0.2, 0.2)
    f.lbl = lbl

    -- Apparition 0.15s, pleine opacite 3s, puis fondu sur 1.5s
    f:SetScript("OnUpdate", function(self)
        if not self.fadeStart then return end
        local age      = GetTime() - self.fadeStart
        local fadeIn   = 0.15
        local holdTime = 3.0
        local fadeTime = 1.5
        if age >= holdTime + fadeTime then
            self:SetAlpha(0)
            self:Hide()
            self.fadeStart = nil
            return
        end
        if age < fadeIn then
            self:SetAlpha(age / fadeIn)
        else
            self:SetAlpha(1 - math.max(0, age - holdTime) / fadeTime)
        end
    end)

    MT.deathAlertFrame = f
end

-- Son (si active dans les options)
function MT.PlayDeathSound()
    if MythicTimerDB.deathSound ~= false then
        PlaySoundFile("Interface\\AddOns\\MythicTimer\\sounds\\death.ogg", "Master")
    end
end

-- Texte a l'ecran (si active dans les options). playerName nil -> message generique.
function MT.ShowDeathText(playerName)
    local f = MT.deathAlertFrame
    if not f or MythicTimerDB.deathAlert == false then return end
    local txt = playerName and string.format(MT.L["DEATH_ALERT_FMT"], playerName)
        or MT.L["DEATH_ALERT_UNKNOWN"]
    local skull = "|T" .. T.SKULL .. ":26|t"
    f.lbl:SetText(skull .. "  " .. txt .. "  " .. skull)
    f.fadeStart = GetTime()
    f:SetAlpha(0)
    f:Show()
end

function MT.ShowDeathAlert(playerName)
    MT.PlayDeathSound()
    MT.ShowDeathText(playerName)
end
