# MythicTimer — Changelog

---

## [1.2] — 2026-10-03

### Bug Fixes
- **Death alert showing "Inconnu"** — When the server death count (`CHALLENGE_MODE_DEATH_COUNT_UPDATED`) arrived before the local dead-unit scan, the entry was created as "Inconnu" and the alert fired at once; the name was only fixed in the log on the next tick. The sound now plays immediately, but the text alert waits up to 1.5 s for the name (shown when the entry is renamed in `MT.SyncDeaths`). If no name is found, a localized generic message is shown (`DEATH_ALERT_UNKNOWN`).
- **Death alert still showing "Inconnu"** — `UnitName()` itself returns the game's `UNKNOWNOBJECT` ("Inconnu" on frFR) or a secret value for a dead player out of range / released, and that string was used as a real name. Names are now validated (`IsUsableName`), the last readable name of each group member is cached by GUID, and pending alerts retry the name through the GUID each tick before falling back to the generic message.
- **"Inconnu" left in the death list (Spirit of Redemption)** — An entry whose name could not be read within 1.5 s stayed "Inconnu" for good. Unnamed entries now keep retrying through the GUID on every tick (the alert still falls back to the generic text after 1.5 s), and group names are cached out of combat (`GROUP_ROSTER_UPDATE`, key start, zoning) via `MT.CacheGroupNames`.
- **Death penalty after the timer ran out** — Once a key is over time, the game no longer adds time for deaths, but the addon kept adding the penalty, so the overtime shown drifted further from the real one with each death. The applied penalty is now frozen once the timer hits 0 (the death that pushes it under 0 still counts).
- **Final / boss kill time on depleted keys** — `GetTimeRemainingSeconds()` returns 0 once the timer is over; the `>= 0` check then gave an elapsed time of exactly the time limit. Now `> 0`, falling back to the local clock + penalty (end of key, boss kill time, live boss pull time).
- **Depleted key lost after /reload or re-entering** — A remaining time of 0 was taken as "key abandoned": after a `/reload` the key was not resumed, and leaving / re-entering the dungeon reset the addon. The key state now comes from `MT.GetOfficialElapsed()` (remaining time, or the Blizzard challenge-mode world timer once over time), and an abandon is recognised by a `CHALLENGE_MODE_RESET` timestamp saved in `MythicTimerDB.lastResetTime` (survives `/reload`). `startTime` is rebuilt without the death penalties, which were otherwise counted twice once over time.
- **`/myt debug`** — Toggles a chat dump of the raw unit state (name, dead, Spirit of Redemption aura, secret values) on each detected death or server death-count change.

### Visual overhaul
- **New shared theme** (`Theme.lua`) — Flat dark windows with thin borders, Mythic+ blue and WoW gold accents. Game font (Friz Quadrata) and game status-bar textures are kept.
- **Title bar on every window** — Icon, title, accent line and a flat close button. Once a key starts, the timer and results windows show the dungeon icon and a faded strip of the dungeon artwork.
- **Timer window** — New elapsed-time bar with +3 / +2 markers (dimmed once a threshold is lost). +3 is now on the left and +2 on the right, matching the markers. Trash progress uses a real status bar. Skull icon next to the death counter. Smaller countdown font so "Starting in Xs" fits.
- **Results / History** — Accent line uses the result color (+3 green, +2 gold, timed blue, failed red). History shows the run counter between the arrows and supports the mouse wheel to change run.
- **Death alert** — Dark faded band with red edges, raid skull icons, quick fade-in.
- **All windows** — Close with Escape, kept on screen.

### Options panel
- Grouped into sections: Timer window / Death alerts / Windows & tools.
- Modern checkboxes, segmented Bar/Text choice, sliders that show their value.
- **New:** background opacity, show/hide minimap button, lock results window, "Test" button for the death alert, show/hide timer and M+ Forces shortcuts.
- Confirmation popup before clearing history.
- Values are re-read each time the panel opens (stays in sync with `/myt lock`, etc.).
- Entry in Esc > Options > AddOns that opens the panel.

### Internal
- Main window layout moved into `MT.LayoutMainFrame` / `MT.SetupKeyDisplay` (removed duplicate code from `Events.lua` and `Bosses.lua`).
- History entries now store `mapID`.

---

## [Unreleased] — 2026-04-29

### New Features

#### Enemy Forces Panel (MDT)
- **Static panel** — New `/mtef` command (and middle-click on minimap button) opens a scrollable panel listing all mobs of the current dungeon with their forces % and point count, sorted by weight descending.
- **Localized mob names** — Mob names are pulled from `MDT.L` (the active locale table), so they display in the client language automatically (frFR, deDE, esES, etc.) with English fallback.
- **Color coding** — Same color scheme as before: bright green ≥ 1%, gold ≥ 0.3%, light red below.
- **Auto-refresh** — The panel rebuilds its cache on `PLAYER_ENTERING_WORLD`, `CHALLENGE_MODE_START`, and `ZONE_CHANGED_NEW_AREA`.
- **Draggable & scrollable** — Standard WoW backdrop frame with UIPanelScrollFrame. Close button or second `/mtef` to dismiss.
- **Note on runtime identification** — Individual mob identification inside a Mythic+ instance is not feasible in Midnight 12.x: `UnitGUID`, `UnitName`, `UnitDisplayID` and all equivalent APIs return secret strings or nil in instance context. `C_Unit` namespace is absent. Plater itself skips npcID storage for the same reason. The static panel is the only viable approach.

#### Minimap Button
- **Middle-click** — Registers `MiddleButtonUp` and toggles the M+ Forces panel.
- **Tooltip line added** — Third tooltip line shows the middle-click action in English and French.

---

## [Unreleased] — 2026-04-27

### Bug Fixes

- **Objective Tracker not hiding** — The addon was targeting `UIWidgetTopCenterContainerFrame` (the boss HUD widget at the top center) instead of `ObjectiveTrackerFrame` (the quest/M+ tracker panel on the side). The Blizzard M+ timer is now correctly hidden when the option is enabled.
- **Objective Tracker reappearing on death** — Replaced the `SetAlpha(0)` approach (which WoW's widget system could override between ticks) with a `SetParent` reparenting technique: the tracker is moved to a hidden phantom frame, making it impossible for WoW to show it again regardless of widget updates.
- **Objective Tracker not rehiding after combat** — Added `PLAYER_REGEN_ENABLED` event listener: if `SetParent` was blocked by combat lockdown at key start, it is now properly applied as soon as combat ends.
- **Window position not saving correctly after drag** — `OnDragStop` was calling `GetPoint()` after `StartMoving()`, which changes the internal anchor to `BOTTOMLEFT`, causing incorrect coordinates to be saved. Fixed on both the main timer window and the results window by computing the true CENTER offset from screen pixel position (`GetLeft() + Width/2 - ScreenWidth/2`).
- **Results window always appearing in wrong position** — Consequence of the drag position bug above. The saved coordinates are now reliable and the window reappears where it was left.
- **Lock/Unlock button label inverted on results window** — The button was showing the current state instead of the available action. It now correctly shows "Lock" when the window is movable and "Unlock" when it is locked.
- **Close button missing in results preview mode** — When opening the results window via `/myt result` or the Options panel outside of a dungeon, the Close button had no position set and was invisible. It is now anchored to the bottom of the frame in preview mode.
- **MDT enemy forces not showing in tooltips** — The tooltip hook was using internal MDT data tables directly and required an active challenge key (`GetActiveChallengeMapID`). It now uses the official MDT public API `MDT:GetEnemyForces(npcId)`, which works in all contexts and handles caching internally.

---

### New Features

#### Results Window
- **Persistent positioning** — The results window now remembers its position between sessions. Drag it once and it will always reopen there, including after a `/reload`.
- **Lock / Unlock button** — A small button on the results window allows toggling between movable and locked states without opening the Options panel.
- **Preview outside dungeons** — New command `/myt result` and new button "Position results window" in the Options panel allow opening the results window at any time to reposition it.

#### Progress Bar (Trash %)
- **Two display modes** — A new option allows choosing between:
  - **Bar** (default): the progress bar with the percentage text overlaid on it.
  - **Text only**: the percentage displayed as a large standalone number, no bar.
- Toggle via the Options panel (radio buttons) or `/myt barmode`.
- **Improved bar mode readability** — Bar height increased from 14 to 20 px. Font changed to 14 pt `THICKOUTLINE` in white, readable regardless of bar fill level.
- **Improved text mode readability** — Font size increased to 24 pt `THICKOUTLINE`.
- **More vivid color coding** — Colors updated for instant readability:
  - Yellow-gold (< 80%) → Cyan (80–99%) → Bright green (100%+)

#### Enemy Forces Tooltip (MDT)
- **Color-coded percentage** — The M+ forces value in unit tooltips is now color-coded by mob weight:
  - Bright green (≥ 1.0%) — high-value mob
  - Gold/yellow (0.3–1.0%) — medium mob
  - Light red (< 0.3%) — low-value mob
- **Visual separator** — A blank line is inserted before the forces line to visually separate it from the rest of the tooltip.

#### UI Improvements
- **Close button on main timer window** — A standard `×` close button (WoW `UIPanelCloseButton`) has been added to the top-right corner of the main timer window.
- **Minimap tooltip** — The minimap button tooltip now shows both available clicks:
  - Left-click: open options
  - Right-click: show/hide window

---

### Removed / Replaced

- Removed the `OnShow` hook on `UIWidgetTopCenterContainerFrame` (was a fragile workaround for the wrong frame).
- Removed the blind `SetAlpha(0)` polling in `OnUpdate` (now only active as a combat fallback when `SetParent` is blocked).
- Removed the internal MDT data table access in `EnemyForces.lua` in favor of the public `MDT:GetEnemyForces()` API.
