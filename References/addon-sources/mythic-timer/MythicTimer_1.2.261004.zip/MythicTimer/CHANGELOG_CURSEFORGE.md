## MythicTimer — Version 1.2 (2026-10-03)

### Compatibility
- Ready for patch 12.1.5 (still compatible with 12.1.0)

### Bug Fixes
- Fixed the death alert sometimes showing "Inconnu died!" instead of the player's name. The sound still plays right away; the text now waits a moment for the name. If the name can't be found, a generic "A party member died!" is shown in your client language

### New look
- **Brand-new modern design** for every window, keeping the WoW feel: dark flat panels, thin borders, gold titles and the game's own font and bar textures
- **Title bar** on every window with an icon and close button. During a key, the timer and results windows show the dungeon icon and its artwork
- **Timer window**
  - New time bar with markers for the +3 and +2 thresholds. A marker fades out once that upgrade is lost
  - +3 is now shown on the left and +2 on the right, in the same order as the markers
  - Trash progress now uses a real in-game status bar
  - Skull icon next to the death counter
  - The "Starting in Xs" countdown now fits in the window
- **Results & History windows** — The colored line under the title matches the result (green +3, gold +2, blue timed, red failed)
- **History window** — Run counter between the arrows, and the mouse wheel now switches between runs
- **Death alert** — New dark banner with red edges and skull icons, with a quick fade-in
- All windows can now be closed with **Escape** and can no longer be dragged off screen

### Redesigned Options panel
- Organized into three sections: Timer window, Death alerts, Windows & tools
- Modern checkboxes, Bar / Text toggle and sliders that show their value
- **New options:**
  - Background opacity of the timer window
  - Show / hide the minimap button
  - Lock the results window position
  - **Test** button to preview the death alert
  - Shortcuts: show/hide the timer, open the M+ Forces panel
- Clearing the history now asks for confirmation
- Options always reflect current settings, even if changed with `/myt` commands
- MythicTimer now appears in **Esc > Options > AddOns**, with a button that opens its options

---

## MythicTimer — Update 2026-05-05

### New Features

**German localization (deDE)**
- Added full German (`deDE`) translation for all addon strings
- Covers the main timer window, results window, history window, options panel, minimap tooltip, slash command help, and all in-game alerts
- Special characters (ä, ö, ü, ß) replaced with ASCII equivalents (ae, oe, ue, ss) to avoid silent encoding bugs in Lua

---

## MythicTimer — Update 2026-05-01

Minor bug fixed


## MythicTimer — Update 2026-04-30 (2)

### New Features

**History window — full rewrite**
- The history window now uses the same layout and content as the results window
- Dynamic height: the window resizes automatically based on the number of bosses and deaths recorded
- Boss log: displays each boss with their kill time, fight duration, and wipe count
- Death log: full per-death breakdown with player name and timestamp, scrollable with the mouse wheel
- Added time ahead/over and dungeon time limit display
- Added +2 / +3 key upgrade threshold display
- Result label is color-coded (green for +3, yellow for +2, cyan for timed, red for failed), same as the results window
- Older history entries (recorded before this update) display gracefully with no boss/death details

---

## MythicTimer — Update 2026-04-30

### New Features

**Death alerts**
- A sound now plays whenever a party member dies during a Mythic+ run (`sounds/death.ogg`)
- A large red text alert is displayed on screen (top-center) with a drop shadow for readability on any background
- The alert holds for 3 seconds then fades out over 1.5 seconds
- Both alerts are independent and can be toggled separately in the Options panel

**Options panel**
- New section "Death alerts" with two checkboxes: "Play sound on death" and "Show text alert on death"
- Both are enabled by default

---

## MythicTimer — Update 2026-04-29

### New Features

**Enemy Forces panel (requires MythicDungeonTools)**
- New `/mtef` command and middle-click on the minimap button to open/close the M+ Forces panel
- The panel lists all mobs of the current dungeon with their forces percentage and point value, sorted from highest to lowest
- Mob names are automatically translated to the client language (frFR, deDE, esES, etc.) using MDT localizations
- Color-coded values: green for high-value mobs (≥ 1%), gold for medium (≥ 0.3%), red for low weight
- The panel is scrollable, draggable, and updates automatically when entering a dungeon
- Note: individual mob identification in a Mythic+ instance is not possible in Midnight 12.x due to Blizzard API restrictions (secret strings). The panel uses a static list approach instead.

**Minimap button**
- Middle-click now opens/closes the M+ Forces panel
- Tooltip updated to show all three click actions

---

## MythicTimer — Update 2026-04-27

### Bug Fixes
- Fixed the Blizzard M+ objective tracker not hiding at the start of a key
- Fixed the Blizzard M+ objective tracker reappearing every time a player died
- Fixed the timer window and results window not saving their position correctly after being moved
- Fixed the MDT enemy forces percentage not showing in unit tooltips
- Fixed the Lock/Unlock button on the results window showing the wrong label

### New Features

**Results window**
- The results window now remembers its position between sessions
- Added a Lock / Unlock button directly on the results window
- New command `/myt result` to open and reposition the results window at any time (outside of a dungeon)
- New button in the Options panel to do the same

**Trash progress display**
- New option to choose between two display modes: progress bar or large text only
- Toggle in the Options panel or with `/myt barmode`
- Bar is now taller and the text larger for better readability at a glance
- Color coding: yellow while progressing, cyan near 100%, bright green when full

**Enemy Forces tooltip (requires MythicDungeonTools)** 
- The M+ forces percentage shown in unit tooltips is now color-coded by mob weight: green for high-value mobs, gold for medium, red for low
- Added a visual separator to make the line stand out from the rest of the tooltip

**General UI**
- Added a close button (×) to the top-right corner of the main timer window
- The minimap button tooltip now shows both left-click and right-click actions
