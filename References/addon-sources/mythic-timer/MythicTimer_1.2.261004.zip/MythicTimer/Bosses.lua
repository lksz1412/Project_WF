-- ============================================================
-- MythicTimer - Suivi des boss (kill timers)
-- ENCOUNTER_START / ENCOUNTER_END sont traites dans Events.lua
-- ============================================================
local MT = MythicTimerAddon

function MT.UpdateBosses()
    if not MT.frame or not MT.frame.bossLabels then return end
    -- Autorise l'affichage si le timer tourne OU si on a des kills a afficher
    if not MT.timerRunning and not next(MT.bossKillData) then return end

    local numCriteria = select(3, C_Scenario.GetStepInfo())
    if not numCriteria or numCriteria == 0 then return end

    -- Longueur max du nom avant troncature (laisse de la place pour les timers)
    local MAX_NAME = 22

    local bossIdx = 0
    for i = 1, numCriteria do
        local info = C_ScenarioInfo.GetCriteriaInfo(i)
        if info and not info.isWeightedProgress and info.description then
            bossIdx = bossIdx + 1
            if bossIdx <= MT.MAX_BOSSES then
                local lbl = MT.frame.bossLabels[bossIdx]
                local shortName = MT.ShortName(info.description, MAX_NAME)
                if info.completed then
                    -- Priorite : lookup par assetID (== encounterID pour les boss M+).
                    -- Fallback : scan lineaire du bossLog par nom (cas ou assetID ne matche pas).
                    -- Note : info.description peut inclure " vaincu"/" defeated" apres le nom,
                    -- on accepte donc une correspondance si la description COMMENCE par le nom.
                    local kd = MT.bossKillData[info.assetID]
                    if not kd then
                        local descLow = info.description:lower()
                        for _, entry in ipairs(MT.bossLog) do
                            local nameLow = entry.name:lower()
                            if descLow:find(nameLow, 1, true) == 1 then
                                kd = entry
                                break
                            end
                        end
                    end
                    if kd then
                        lbl:SetText(string.format("|cff00ff00%s|r |cffffff00%s|r |cffaaaaaa(%s)|r",
                            shortName,
                            MT.FormatTime(kd.killTime),
                            MT.FormatTime(kd.fightDuration)
                        ))
                    else
                        lbl:SetText("|cff00ff00" .. shortName .. "|r")
                    end
                else
                    -- info.completed peut etre false pour un boss deja tue :
                    -- WoW reinitialise les criteres du scenario apres CHALLENGE_MODE_COMPLETED.
                    -- On consulte bossKillData en priorite avant de supposer que le boss est en combat.
                    local kd = MT.bossKillData[info.assetID]
                    if not kd then
                        local descLow = info.description:lower()
                        for _, entry in ipairs(MT.bossLog) do
                            local nameLow = entry.name:lower()
                            if descLow:find(nameLow, 1, true) == 1 then
                                kd = entry
                                break
                            end
                        end
                    end
                    if kd then
                        -- Boss deja tue : affichage identique a la branche info.completed
                        local wipeStr = (kd.wipes and kd.wipes > 0)
                            and string.format("  |cffff4444W:%d|r", kd.wipes) or ""
                        lbl:SetText(string.format("|cff00ff00%s|r |cffffff00%s|r |cffaaaaaa(%s)|r%s",
                            shortName,
                            MT.FormatTime(kd.killTime),
                            MT.FormatTime(kd.fightDuration),
                            wipeStr
                        ))
                    else
                        -- Boss non encore tue : verifier s'il est actuellement en combat
                        local pullTime = MT.bossEncounterStart[info.assetID]
                        if not pullTime then
                            -- Fallback par nom si assetID != encounterID
                            local descLow = info.description:lower()
                            for k, t in pairs(MT.bossEncounterStart) do
                                if type(k) == "string" and descLow:find(k:lower(), 1, true) == 1 then
                                    pullTime = t
                                    break
                                end
                            end
                        end
                        if pullTime then
                            -- Affichage live : temps au pull sur l'echelle officielle WoW
                            -- (penalites de mort incluses, meme echelle que le timer affiche).
                            local rem = C_ChallengeMode.GetTimeRemainingSeconds and C_ChallengeMode.GetTimeRemainingSeconds()
                            local keyElapsedAtPull
                            if rem and rem > 0 and MT.timeLimit > 0 then   -- 0 = timer depasse
                                -- timeLimit - rem = elapsed officiel maintenant
                                -- on soustrait la duree ecoulee depuis le pull
                                local nowOfficial = MT.timeLimit - math.floor(rem)
                                local fightSoFar = math.floor(GetTime() - pullTime)
                                keyElapsedAtPull = math.max(0, nowOfficial - fightSoFar)
                            else
                                keyElapsedAtPull = math.floor(pullTime - MT.startTime)
                                    + MT.GetDeathTimeLost()
                            end
                            local fightLive = math.floor(GetTime() - pullTime)
                            local wipes = MT.bossWipes[info.assetID] or 0
                            local wipeSuffix = wipes > 0 and string.format(" |cffff4444W:%d|r", wipes) or ""
                            lbl:SetText(string.format("|cffff9900%s|r |cffffff00@%s|r |cff00ffff(%s)|r%s",
                                shortName,
                                MT.FormatTime(keyElapsedAtPull),
                                MT.FormatTime(fightLive),
                                wipeSuffix
                            ))
                        else
                            lbl:SetText("|cffaaaaaa" .. shortName .. "|r")
                        end
                    end
                end  -- if info.completed
                lbl:Show()
            end
        end
    end

    -- Cache les slots inutilises
    for i = bossIdx + 1, MT.MAX_BOSSES do
        MT.frame.bossLabels[i]:Hide()
    end

    -- Redimensionne la fenetre selon le nombre de boss reels
    if bossIdx > 0 then
        MT.LayoutMainFrame(bossIdx)
    end
end
