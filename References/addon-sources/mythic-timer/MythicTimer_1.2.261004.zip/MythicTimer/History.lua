-- ============================================================
-- MythicTimer - Fenetre Historique
-- Meme style que la fenetre de resultats, avec navigation gauche/droite.
-- ============================================================
local MT = MythicTimerAddon
local T  = MT.Theme
local function L(k, ...) return select('#', ...) > 0 and string.format(MT.L[k], ...) or MT.L[k] end

local hf      = nil   -- frame unique, creee une fois, reutilisee
local current = 1     -- index du run affiche (1 = le plus recent)

-- ---- Construction de la frame (une seule fois) ----
local function BuildHistoryFrame()
    if hf then return end

    hf = CreateFrame("Frame", "MythicTimerHistoryFrame", UIParent, "BackdropTemplate")
    hf:SetSize(290, 400)  -- hauteur dynamique, recalculee a chaque affichage
    hf:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
    T.ApplyBackdrop(hf, 0.94)
    hf:SetFrameStrata("DIALOG")
    hf:SetClampedToScreen(true)
    T.CloseOnEscape("MythicTimerHistoryFrame")
    hf:SetMovable(true)
    hf:EnableMouse(true)
    hf:RegisterForDrag("LeftButton")
    hf:SetScript("OnDragStart", function(self) self:StartMoving() end)
    hf:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x = self:GetLeft() + self:GetWidth()  / 2 - UIParent:GetWidth()  / 2
        local y = self:GetTop()  - self:GetHeight() / 2 - UIParent:GetHeight() / 2
        MythicTimerDB.posXHistory = x
        MythicTimerDB.posYHistory = y
    end)

    -- Bandeau titre (illustration du donjon + liseré a la couleur du resultat) et croix
    T.CreateHeader(hf, MT.L["HIST_TITLE"], function() hf:Hide() end)

    -- Compteur "X / Y", en bas entre les fleches
    hf.counter = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hf.counter:SetPoint("BOTTOM", hf, "BOTTOM", 0, 16)
    hf.counter:SetTextColor(T.rgb(T.C.dim))

    -- Grand texte resultat (+2 / +3 / Echec) + temps final
    hf.resultTitle = hf:CreateFontString(nil, "OVERLAY")
    hf.resultTitle:SetFont(T.FONT, 24, "OUTLINE")
    hf.resultTitle:SetShadowOffset(1, -1)

    -- Nom du donjon
    hf.dungeon = hf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hf.dungeon:SetWidth(270)
    hf.dungeon:SetJustifyH("CENTER")

    -- Personnage
    hf.runChar = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hf.runChar:SetTextColor(0.6, 0.85, 1)

    -- Date
    hf.runDate = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hf.runDate:SetTextColor(0.5, 0.5, 0.5)

    -- Ligne temps (avance / depassement)
    hf.timeLine = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

    -- Seuils +2 / +3
    hf.threshLine = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

    -- Separateur 1 (avant boss)
    hf.sep1 = T.CreateSeparator(hf)

    -- En-tete boss
    hf.bossHeader = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hf.bossHeader:SetTextColor(0.6, 0.8, 1)

    -- Labels boss (pre-alloues, MAX_BOSSES slots)
    hf.bossLabels = {}
    for i = 1, MT.MAX_BOSSES do
        local lbl = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetWidth(270)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        hf.bossLabels[i] = lbl
    end

    -- Separateur 2 (avant morts)
    hf.sep2 = T.CreateSeparator(hf)

    -- Ligne recap morts
    hf.deathLine = hf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hf.deathLine:SetWidth(270)
    hf.deathLine:SetJustifyH("LEFT")

    -- Zone de scroll pour le log de mort (molette)
    hf.deathScroll = CreateFrame("ScrollFrame", nil, hf)
    hf.deathScroll:SetSize(260, 1)  -- taille initiale minimale, recalculee a chaque refresh
    hf.deathScroll:EnableMouseWheel(true)
    hf.deathScroll:SetScript("OnMouseWheel", function(self, delta)
        local cur = self:GetVerticalScroll()
        local max = self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(max, cur - delta * 13)))
    end)
    hf.deathScrollChild = CreateFrame("Frame", nil, hf.deathScroll)
    hf.deathScrollChild:SetWidth(260)
    hf.deathScrollChild:SetHeight(130)
    hf.deathScroll:SetScrollChild(hf.deathScrollChild)

    hf.deathLogLabels = {}
    for i = 1, 50 do
        local lbl = hf.deathScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetWidth(256)
        lbl:SetJustifyH("LEFT")
        lbl:SetPoint("TOPLEFT", hf.deathScrollChild, "TOPLEFT", 0, -(i-1)*13)
        lbl:Hide()
        hf.deathLogLabels[i] = lbl
    end

    -- Boutons navigation
    hf.prevBtn = T.CreateButton(hf, "<", 40, 22, function()
        local total = MythicTimerDB.history and #MythicTimerDB.history or 0
        if current < total then
            current = current + 1
            MT.RefreshHistoryFrame()
        end
    end)
    hf.prevBtn:SetPoint("BOTTOMLEFT", hf, "BOTTOMLEFT", 10, 10)

    hf.nextBtn = T.CreateButton(hf, ">", 40, 22, function()
        if current > 1 then
            current = current - 1
            MT.RefreshHistoryFrame()
        end
    end)
    hf.nextBtn:SetPoint("BOTTOMRIGHT", hf, "BOTTOMRIGHT", -10, 10)

    -- Molette sur la fenetre = run precedent / suivant
    hf:EnableMouseWheel(true)
    hf:SetScript("OnMouseWheel", function(_, delta)
        local total = MythicTimerDB.history and #MythicTimerDB.history or 0
        local target = current - delta
        if target >= 1 and target <= total then
            current = target
            MT.RefreshHistoryFrame()
        end
    end)

    -- Label vide
    hf.emptyLabel = hf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hf.emptyLabel:SetPoint("CENTER", hf, "CENTER", 0, 10)
    hf.emptyLabel:SetTextColor(T.rgb(T.C.dim))
    hf.emptyLabel:SetText(MT.L["HIST_EMPTY"])

    MT.historyFrame = hf
    hf:Hide()
end

-- ---- Rafraichissement du contenu ----
function MT.RefreshHistoryFrame()
    if not hf then return end

    local history = MythicTimerDB.history
    local total   = history and #history or 0

    if total == 0 then
        hf.emptyLabel:Show()
        hf.counter:SetText("")
        hf.resultTitle:SetText("")
        hf.dungeon:SetText("")
        hf.runChar:SetText("")
        hf.runDate:SetText("")
        hf.timeLine:SetText("")
        hf.threshLine:SetText("")
        hf.bossHeader:SetText("")
        for i = 1, MT.MAX_BOSSES do hf.bossLabels[i]:Hide() end
        hf.deathLine:SetText("")
        hf.deathScroll:Hide()
        hf.prevBtn:SetEnabled(false)
        hf.nextBtn:SetEnabled(false)
        T.SetHeaderDungeon(hf.header, nil)
        T.SetAccent(hf.header, T.C.accent)
        hf:SetSize(290, 200)
        return
    end

    hf.emptyLabel:Hide()
    current = math.max(1, math.min(current, total))
    local r = history[current]

    -- Recupere les seuils (anciens runs sans ces champs : fallback estimatif)
    local timeLimit  = r.timeLimit  or r.time
    local level2Time = r.level2Time or math.floor(timeLimit * 0.8)
    local level3Time = r.level3Time or math.floor(timeLimit * 0.6)

    -- ---- Mise en page avec curseur Y (meme technique que Results.lua) ----
    local y = -(T.HEADER_H + 10)

    hf.counter:SetText(string.format("%d / %d", current, total))

    -- Resultat colore
    local rR, rG, rB
    if r.result == MT.L["RESULT_P3"] then
        rR, rG, rB = T.rgb(T.C.good)
    elseif r.result == MT.L["RESULT_P2"] then
        rR, rG, rB = T.rgb(T.C.gold)
    elseif r.result == MT.L["RESULT_TIMED"] then
        rR, rG, rB = T.rgb(T.C.cyan)
    else
        rR, rG, rB = T.rgb(T.C.bad)
    end
    T.SetHeaderDungeon(hf.header, r.mapID)  -- nil pour les anciens runs -> visuel par defaut
    T.SetAccent(hf.header, { rR, rG, rB })
    hf.resultTitle:ClearAllPoints()
    hf.resultTitle:SetPoint("TOP", hf, "TOP", 0, y)
    hf.resultTitle:SetText(r.result .. "   " .. MT.FormatTime(r.time))
    hf.resultTitle:SetTextColor(rR, rG, rB)
    y = y - 30

    -- Donjon + niveau
    hf.dungeon:ClearAllPoints()
    hf.dungeon:SetPoint("TOP", hf, "TOP", 0, y)
    hf.dungeon:SetText(string.format("|cffffd100+%d|r  %s", r.level, r.dungeon))
    y = y - 18

    -- Personnage
    hf.runChar:ClearAllPoints()
    hf.runChar:SetPoint("TOP", hf, "TOP", 0, y)
    hf.runChar:SetText(L("HIST_CHAR", r.char or "?"))
    y = y - 14

    -- Date
    hf.runDate:ClearAllPoints()
    hf.runDate:SetPoint("TOP", hf, "TOP", 0, y)
    hf.runDate:SetText(r.date or "")
    y = y - 14

    -- Temps avance/depassement + limite
    local saved = timeLimit - r.time
    local timeExtra
    if saved >= 0 then
        timeExtra = L("TIME_AHEAD", MT.FormatTime(saved))
    else
        timeExtra = L("TIME_OVER",  MT.FormatTime(-saved))
    end
    hf.timeLine:ClearAllPoints()
    hf.timeLine:SetPoint("TOP", hf, "TOP", 0, y)
    hf.timeLine:SetText(timeExtra .. "  " .. L("TIME_LIMIT", MT.FormatTime(timeLimit)))
    y = y - 15

    -- Seuils +2 / +3
    hf.threshLine:ClearAllPoints()
    hf.threshLine:SetPoint("TOP", hf, "TOP", 0, y)
    hf.threshLine:SetText(string.format("|cffaaaaaa+2 : %s      +3 : %s|r",
        MT.FormatTime(timeLimit - level2Time), MT.FormatTime(timeLimit - level3Time)))
    y = y - 16

    -- Separateur 1
    hf.sep1:ClearAllPoints()
    hf.sep1:SetPoint("TOPLEFT",  hf, "TOPLEFT",  10, y)
    hf.sep1:SetPoint("TOPRIGHT", hf, "TOPRIGHT", -10, y)
    y = y - 8

    -- En-tete boss
    hf.bossHeader:ClearAllPoints()
    hf.bossHeader:SetPoint("TOPLEFT", hf, "TOPLEFT", 10, y)
    y = y - 16

    local bossLog   = r.bossLog or {}
    local bossCount = #bossLog
    if bossCount == 0 then
        hf.bossHeader:SetText(MT.L["BOSS_HEADER_NONE"])
    else
        hf.bossHeader:SetText(L("BOSS_HEADER_FMT", bossCount))
    end

    local MAX_NAME = 19
    for i = 1, math.min(bossCount, MT.MAX_BOSSES) do
        local boss = bossLog[i]
        local lbl  = hf.bossLabels[i]
        local shortName = MT.ShortName(boss.name, MAX_NAME)
        lbl:ClearAllPoints()
        lbl:SetPoint("TOPLEFT", hf, "TOPLEFT", 10, y)
        local wipeStr = (boss.wipes and boss.wipes > 0)
            and string.format("  |cffff4444W:%d|r", boss.wipes) or ""
        lbl:SetText(string.format(
            "|cff00ff00%s|r  |cffffff00%s|r  |cffaaaaaa(%s)|r%s",
            shortName, MT.FormatTime(boss.killTime),
            MT.FormatTime(boss.fightDuration), wipeStr))
        lbl:Show()
        y = y - 15
    end
    for i = math.min(bossCount, MT.MAX_BOSSES) + 1, MT.MAX_BOSSES do
        hf.bossLabels[i]:Hide()
    end

    -- Separateur 2
    y = y - 2
    hf.sep2:ClearAllPoints()
    hf.sep2:SetPoint("TOPLEFT",  hf, "TOPLEFT",  10, y)
    hf.sep2:SetPoint("TOPRIGHT", hf, "TOPRIGHT", -10, y)
    y = y - 8

    -- Ligne recap morts
    hf.deathLine:ClearAllPoints()
    hf.deathLine:SetPoint("TOPLEFT", hf, "TOPLEFT", 10, y)
    if r.deaths and r.deaths > 0 then
        if r.deathTimeLost then
            hf.deathLine:SetText(L("DEATHS_RECAP_FMT", r.deaths, r.deathTimeLost))
        else
            -- Anciens runs : penalite non enregistree
            hf.deathLine:SetText("|cffff4444" .. L("HIST_DEATHS", r.deaths) .. "|r")
        end
    else
        hf.deathLine:SetText(MT.L["DEATHS_RECAP_NONE"])
    end
    y = y - 15

    -- Log de mort (scroll si > 10)
    local deathLog   = r.deathLog or {}
    local totalDeaths = #deathLog
    if totalDeaths > 0 then
        local visibleRows = math.min(totalDeaths, 10)
        local scrollH = visibleRows * 13
        hf.deathScroll:SetSize(260, scrollH)
        hf.deathScroll:ClearAllPoints()
        hf.deathScroll:SetPoint("TOPLEFT", hf, "TOPLEFT", 22, y)
        hf.deathScroll:SetVerticalScroll(0)
        hf.deathScroll:Show()
        local shown = math.min(totalDeaths, 50)
        for i = 1, shown do
            local entry = deathLog[i]
            hf.deathLogLabels[i]:SetText(string.format(
                "|cffffff00%s|r  |cffaaaaaa@ %s|r",
                entry.name, MT.FormatTime(entry.elapsed)))
            hf.deathLogLabels[i]:Show()
        end
        for i = shown + 1, 50 do hf.deathLogLabels[i]:Hide() end
        hf.deathScrollChild:SetHeight(shown * 13)
        y = y - scrollH
    else
        hf.deathScroll:Hide()
    end

    -- Hauteur dynamique (boutons de navigation ancres en bas)
    y = y - 8
    hf:SetSize(290, math.abs(y) + 36)

    -- Navigation
    hf.prevBtn:SetEnabled(current < total)
    hf.nextBtn:SetEnabled(current > 1)
end

-- ---- Point d'entree public ----
function MT.ShowHistoryFrame()
    BuildHistoryFrame()
    current = 1
    MT.RefreshHistoryFrame()

    hf:ClearAllPoints()
    local px = MythicTimerDB.posXHistory or 0
    local py = MythicTimerDB.posYHistory or 80
    hf:SetPoint("CENTER", UIParent, "CENTER", px, py)
    hf:Show()
    hf:Raise()
end
