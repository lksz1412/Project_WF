# kgPanels

## [1.4.7](https://github.com/Stanzilla/kgPanels/tree/1.4.7) (2026-02-10)
[Full Changelog](https://github.com/Stanzilla/kgPanels/compare/1.4.6...1.4.7) [Previous Releases](https://github.com/Stanzilla/kgPanels/releases)

- chore: update toc  
- fix: also checking for C\_AddOns beforehand  
- fix: localization key missmatch  
- Adding fallbacks for Classic as well  
- Fixed issue with `IsAddOnLoaded` and `LoadAddOn`  
