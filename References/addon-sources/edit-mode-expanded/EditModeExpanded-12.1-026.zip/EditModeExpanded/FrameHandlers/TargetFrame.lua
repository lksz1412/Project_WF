local addonName, addon = ...
local lib = LibStub:GetLibrary("EditModeExpanded-1.0")
local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

function addon:initTargetFrame()
    local db = addon.db.global
    if db.EMEOptions.targetFrame then
        addon:registerSecureFrameHideable(TargetFrame)
        local targetFrameWasHidden
        lib:RegisterCustomCheckbox(TargetFrame, "Hide Name",
            function()
                TargetFrame.name:Hide()
                targetFrameWasHidden = true
            end,
            function()
                if targetFrameWasHidden then
                    TargetFrame.name:Show()
                end
                targetFrameWasHidden = false
            end,
            "HideName"
        )
        
        if db.EMEOptions.targetFrameResize then
            lib:RegisterResizable(TargetFrame)
        end
    end
    
    if db.EMEOptions.targetCast then
        -- As of 12.1, target cast bar and buffs have forbidden aspects, preventing us from getting their coordinates, even after a dragstop
        -- Now have to use a fake frame with the cast bar / buffs anchored to it, instead
        
        local fakeFrame = CreateFrame("Frame", "EMETargetFrameCastbar", TargetFrame)
        fakeFrame:SetPoint("TOPLEFT", TargetFrame, "BOTTOMLEFT", 5, -40)
        fakeFrame:SetSize(150, 30)
        lib:SetDontResize(fakeFrame)
        addon:registerFrame(fakeFrame, L["TARGET_CAST_BAR"], db.TargetSpellBar, TargetFrame, "TOPLEFT")
        
        local realFrame = TargetFrameSpellBar
        
        addon:registerSecureFrameHideable(fakeFrame)
        
        local width, height
        local defaultWidth, defaultHeight = realFrame:GetSize()
        lib:RegisterSlider(fakeFrame, HUD_EDIT_MODE_SETTING_CHAT_FRAME_WIDTH, "Width",
            function(newValue)
                width = newValue
                realFrame:SetWidth(newValue)
                realFrame:Show()
            end,
            10, 300, 1,
            function()
                realFrame:SetWidth(defaultWidth)
            end)
        lib:RegisterSlider(fakeFrame, HUD_EDIT_MODE_SETTING_CHAT_FRAME_HEIGHT, "Height",
            function(newValue)
                height = newValue
                realFrame:SetHeight(newValue)
                realFrame:Show()
            end,
            1, 50, 1,
            function()
                realFrame:SetHeight(defaultHeight)
            end)
        
        hooksecurefunc(realFrame, "AdjustPosition", function(self)
            realFrame:ClearAllPoints()
            realFrame:SetPoint("TOPLEFT", fakeFrame, "TOPLEFT")
            if EditModeManagerFrame.editModeActive then
                realFrame:Show()
            end
            if width then
                realFrame:SetWidth(width)
            end
        end)
        realFrame:HookScript("OnShow", function(self)
            realFrame:ClearAllPoints()
            realFrame:SetPoint("TOPLEFT", fakeFrame, "TOPLEFT")
            if height then
                realFrame:SetHeight(height)
            end
        end)
    end
    
    if db.EMEOptions.targetFrameBuffs then
        local fakeFrame = CreateFrame("Frame", "EMETargetFrameBuffs", TargetFrame)
        fakeFrame:SetPoint("TOPLEFT", TargetFrame, "BOTTOMLEFT", 5, -10)
        fakeFrame:SetSize(100, 70)
        addon:registerFrame(fakeFrame, "Target Buffs", db.TargetBuffs, TargetFrame, "TOPLEFT")
        
        local realFrame = TargetFrame:GetAuraContainer()
        realFrame:ClearAllPoints()
        realFrame:SetPoint("TOPLEFT", fakeFrame, "TOPLEFT")
        
        hooksecurefunc(TargetFrame, "AnchorAuraContainer", function()
            realFrame:ClearAllPoints()
            realFrame:SetPoint("TOPLEFT", fakeFrame, "TOPLEFT")
        end)
        
        addon:registerSecureFrameHideable(fakeFrame)
    end
end
