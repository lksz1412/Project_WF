﻿local _, addon = ...
local L = addon.L

-- Lua
local _G = getfenv(0)

if GetLocale() ~= "ptBR" then return end

L["ANCHOR_FRAMES"] = "Quadros de Âncora"
L["ANCHOR_RESET_DESC"] = "|cffffffffShift clique|r para redefinir a posição."
L["BORDER"] = "Borda"
L["CHANGELOG"] = "Registro de Alterações"
L["CHANGELOG_FULL"] = "Completo"
L["COORDS"] = "Coordenadas"
L["COPPER_THRESHOLD"] = "Limite de Cobre"
L["COPPER_THRESHOLD_DESC"] = "Quantidade mínima de cobre para criar um brinde."
L["DEFAULT_VALUE"] = "Valor padrão: |cffffd200%s|r"
L["DND"] = "Não Perturbe"
L["DND_DESC"] = "Brindes no modo Não Perturbe não serão exibidos em combate, mas serão enfileirados no sistema. Uma vez que você saia do combate, eles começarão a aparecer."
L["DOWNLOADS"] = "Downloads"
L["EXPORT"] = "Exportar"
L["FADE_OUT_DELAY"] = "Atraso do Desaparecimento"
L["FLUSH_QUEUE"] = "Limpar Fila"
L["FONTS"] = "Fontes"
L["GROWTH_DIR"] = "Direção de Crescimento"
L["ICON_BORDER"] = "Borda do Ícone"
L["ITEM_FILTERS_DESC"] = "Estes itens ignoram o limite de qualidade do saque."
L["OFFSET_X"] = "Deslocamento X"
L["OFFSET_Y"] = "Deslocamento Y"
L["RARITY_THRESHOLD"] = "Limite de Raridade"
L["SCALE"] = "Escala"
L["SKIN"] = "Tema"
L["STRATA"] = "Estrato"
L["TEST"] = "Teste"
L["TEST_ALL"] = "Testar Todos"
L["TOAST_NUM"] = "Número de Brindes"
L["TOAST_TYPES"] = "Tipos de Brinde"
L["TOGGLE_ANCHORS"] = "Alternar Âncoras"
L["TRACK_LOSS"] = "Rastrear Perda"
L["TRACK_LOSS_DESC"] = "Esta opção ignora o limite de cobre definido."
L["TYPE_LOOT_GOLD"] = "Saque (Ouro)"
L["YOU_LOST"] = "Você Perdeu"
L["YOU_RECEIVED"] = "Você Recebeu"
