# Skada

## [v2.6.7](https://github.com/zarnivoop/skada/tree/v2.6.7) (2026-11-14)
[Full Changelog](https://github.com/zarnivoop/skada/compare/v2.6.6...v2.6.7) [Previous Releases](https://github.com/zarnivoop/skada/releases)

- fix: keep per-player sources on player bars  
    Player rows carried isLocalPlayer=false, but the bar assignment used  
    'false or win.\_drillIsLocalPlayer', so after clicking yourself every other  
    player inherited the local flag and their spell view queried  
    UnitGUID("player"). Player and enemy bars now own their source, GUID, and  
    local flag; only detail rows inherit the drill context.  
