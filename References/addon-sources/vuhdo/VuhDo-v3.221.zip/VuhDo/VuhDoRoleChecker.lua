VUHDO_MANUAL_ROLES = { };

local VUHDO_FIX_ROLES = { };
local VUHDO_INSPECTED_ROLES = { };
local VUHDO_DF_TOOL_ROLES = { };
local VUHDO_ROLE_BY_SPEC = {
	-- [<unit name>] = <VUHDO_ID_MELEE_TANK|VUHDO_ID_MELEE_DAMAGE|VUHDO_ID_RANGED_DAMAGE|VUHDO_ID_RANGED_HEAL>,
};

local VUHDO_INSPECT_TIMEOUT = 5;

--local tPoints1, tPoints2, tPoints3, tRank;
VUHDO_NEXT_INSPECT_UNIT = nil;
VUHDO_NEXT_INSPECT_TIME_OUT = nil;


--------------------------------------------------------------
local NotifyInspect = NotifyInspect;
local GetSpecialization = C_SpecializationInfo.GetSpecialization;
local GetSpecializationInfo = C_SpecializationInfo.GetSpecializationInfo;
local GetInspectSpecialization = GetInspectSpecialization;
local GetSpecializationRoleByID = GetSpecializationRoleByID;
local ClearInspectPlayer = ClearInspectPlayer;
local GetTime = GetTime;
local CanInspect = CanInspect;
local UnitIsPlayer = UnitIsPlayer;
local UnitStat = UnitStat;
local UnitGroupRolesAssigned = UnitGroupRolesAssigned;
local UnitPowerType = UnitPowerType;
local UnitPowerMax = UnitPowerMax;
local issecretvalue = issecretvalue;
local VUHDO_isUnitInModel;
local VUHDO_checkInteractDistance;
local pairs = pairs;
local _;

local VUHDO_MANUAL_ROLES;
local VUHDO_RAID_NAMES;
local VUHDO_RAID_FULL_NAMES;
local VUHDO_RAID;
local VUHDO_getUnitIdentityKey;
local VUHDO_resolveUnitByName;

local sSecretsEnabled = VUHDO_SECRETS_ENABLED;

function VUHDO_roleCheckerInitLocalOverrides()
	VUHDO_MANUAL_ROLES = _G["VUHDO_MANUAL_ROLES"];
	VUHDO_RAID_NAMES = _G["VUHDO_RAID_NAMES"];
	VUHDO_RAID_FULL_NAMES = _G["VUHDO_RAID_FULL_NAMES"];
	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_getUnitIdentityKey = _G["VUHDO_getUnitIdentityKey"];
	VUHDO_resolveUnitByName = _G["VUHDO_resolveUnitByName"];
	VUHDO_isUnitInModel = _G["VUHDO_isUnitInModel"];
	VUHDO_checkInteractDistance = _G["VUHDO_checkInteractDistance"];
end
--------------------------------------------------------------



-- Reset if spec changed or slash command
local tName;
function VUHDO_resetTalentScan(aUnit)

	if VUHDO_PLAYER_RAID_ID == aUnit then
		aUnit = "player";
	end

	local tInfo = VUHDO_RAID[aUnit];

	if tInfo then
		tName = VUHDO_getUnitIdentityKey(tInfo);

		if tName then
			VUHDO_INSPECTED_ROLES[tName] = nil;
			VUHDO_FIX_ROLES[tName] = nil;
			VUHDO_DF_TOOL_ROLES[tName] = nil;
			VUHDO_ROLE_BY_SPEC[tName] = nil;
		end
	end

end



--
function VUHDO_trimInspected()
	for tName, _ in pairs(VUHDO_INSPECTED_ROLES) do
		if not VUHDO_RAID_FULL_NAMES[tName] then
			VUHDO_INSPECTED_ROLES[tName] = nil;
			VUHDO_FIX_ROLES[tName] = nil;
		end
	end
end



-- If timeout after talent tree server request
function VUHDO_setRoleUndefined(aUnit)
	local tInfo = VUHDO_RAID[aUnit];
	if tInfo then
		tName = VUHDO_getUnitIdentityKey(tInfo);

		if tName then
			VUHDO_INSPECTED_ROLES[tName] = nil;
		end
	end
end



local VUHDO_CLASS_ROLES = {
	[VUHDO_ID_ROGUES] = VUHDO_ID_MELEE_DAMAGE,
	[VUHDO_ID_MAGES] = VUHDO_ID_RANGED_DAMAGE,
	[VUHDO_ID_WARLOCKS] = VUHDO_ID_RANGED_DAMAGE,
};



--
local tInfo;
local tName;
function VUHDO_needsRoleInspect(aUnit)

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		return false;
	end

	tInfo = VUHDO_RAID[aUnit];

	if not tInfo then
		return false;
	end

	tName = VUHDO_getUnitIdentityKey(tInfo);

	if not tName or tInfo["isPet"] or tInfo["hasSecretIdentity"] then
		return false;
	end

	if VUHDO_CLASS_ROLES[tInfo["classId"]] then
		return false;
	end

	if VUHDO_MANUAL_ROLES[tName] or VUHDO_ROLE_BY_SPEC[tName] then
		return false;
	end

	if VUHDO_DF_TOOL_ROLES[tName] == 60 or VUHDO_DF_TOOL_ROLES[tName] == 63 then -- VUHDO_ID_MELEE_TANK -- VUHDO_ID_RANGED_HEAL
		return false;
	end

	if (VUHDO_INSPECTED_ROLES[tName] or VUHDO_ID_UNDEFINED) ~= VUHDO_ID_UNDEFINED then
		return false;
	end

	return true;

end



--
local function VUHDO_shouldBeInspected(aUnit)

	if "focus" == aUnit or "target" == aUnit then
		return false;
	end

	tInfo = VUHDO_RAID[aUnit];

	if tInfo["isPet"] or not tInfo["connected"] then
		return false;
	end

	-- Determined by role or can't tell by talent trees (dk)?
	if VUHDO_CLASS_ROLES[tInfo["classId"]] then -- VUHDO_ID_DEATH_KNIGHT, hat zwar keine feste Rolle, Talentbï¿½ume bringen aber auch nichts
		return false;
	end

	if tInfo["hasSecretIdentity"] then
		return false;
	end

	-- Already inspected or manually overridden?
	-- or assigned tank or heal via dungeon finder? (in case of DPS inspect anyway)
	tName = VUHDO_getUnitIdentityKey(tInfo);
	if VUHDO_INSPECTED_ROLES[tName] or VUHDO_MANUAL_ROLES[tName] or VUHDO_ROLE_BY_SPEC[tName]
		or VUHDO_DF_TOOL_ROLES[tName] == 60 or VUHDO_DF_TOOL_ROLES[tName] == 63 then -- VUHDO_ID_MELEE_TANK -- VUHDO_ID_RANGED_HEAL
		return false;
	end

	-- In inspect range?
	return VUHDO_checkInteractDistance(aUnit, 1);

end



--
function VUHDO_tryInspectNext()

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		return;
	end

	for tUnit, _ in pairs(VUHDO_RAID) do
		if VUHDO_shouldBeInspected(tUnit) then
			VUHDO_NEXT_INSPECT_TIME_OUT = GetTime() + VUHDO_INSPECT_TIMEOUT;
			VUHDO_NEXT_INSPECT_UNIT = tUnit;

			if "player" == tUnit then
				VUHDO_inspectLockRole();
			else
				NotifyInspect(tUnit);
			end

			return;
		end
	end

	return;

end



--
function VUHDO_cancelPendingTargetFocusInspect(aUnit)

	if "target" ~= aUnit and "focus" ~= aUnit then
		return;
	end

	if VUHDO_NEXT_INSPECT_UNIT ~= aUnit then
		return;
	end

	VUHDO_NEXT_INSPECT_UNIT = nil;
	VUHDO_NEXT_INSPECT_TIME_OUT = nil;

	ClearInspectPlayer();

	return;

end



--
function VUHDO_requestTargetFocusInspect(aUnit)

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		return;
	end

	if "target" ~= aUnit and "focus" ~= aUnit then
		return;
	end

	if VUHDO_NEXT_INSPECT_UNIT then
		return;
	end

	if not UnitIsPlayer(aUnit) or not CanInspect(aUnit) or not VUHDO_checkInteractDistance(aUnit, 1) then
		return;
	end

	VUHDO_NEXT_INSPECT_TIME_OUT = GetTime() + VUHDO_INSPECT_TIMEOUT;
	VUHDO_NEXT_INSPECT_UNIT = aUnit;

	NotifyInspect(aUnit);

	return;

end



--
local tActiveTree;
local tInfo;
local tClassId;
local tRole;
local tTreeId;
function VUHDO_inspectRole(aUnit)

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		return VUHDO_ID_UNDEFINED;
	end

	tInfo = VUHDO_RAID[aUnit];

	if not tInfo then 
		return VUHDO_ID_UNDEFINED;
	end

	if "player" == aUnit then
		tActiveTree = GetSpecialization();

		if not tActiveTree then
			return VUHDO_ID_UNDEFINED;
		end

		tTreeId, _, _, _, tRole = GetSpecializationInfo(tActiveTree, false, false);
	else
		tTreeId = GetInspectSpecialization(aUnit);

		if sSecretsEnabled and issecretvalue(tTreeId) then
			return VUHDO_ID_UNDEFINED;
		end

		if (tTreeId or 0) == 0 then
			return VUHDO_ID_UNDEFINED;
		end

		tRole = GetSpecializationRoleByID(tTreeId);
	end

	if (tTreeId or 0) == 0 then
		return VUHDO_ID_UNDEFINED;
	end

	if "HEALER" == tRole then
		return VUHDO_ID_RANGED_HEAL;
	elseif "TANK" == tRole then
		return VUHDO_ID_MELEE_TANK;
	elseif "DAMAGER" == tRole then
		tClassId = tInfo["classId"];

		if VUHDO_ID_WARRIORS == tClassId
			or VUHDO_ID_ROGUES == tClassId
			or VUHDO_ID_PALADINS == tClassId
			or VUHDO_ID_MONKS == tClassId
			or VUHDO_ID_DEATH_KNIGHT == tClassId then
			return VUHDO_ID_MELEE_DAMAGE;
		elseif VUHDO_ID_DEMON_HUNTERS == tClassId then
			if 1480 == tTreeId then -- Devourer
				return VUHDO_ID_RANGED_DAMAGE;
			else
				return VUHDO_ID_MELEE_DAMAGE;
			end
		elseif VUHDO_ID_SHAMANS == tClassId then
			if 263 == tTreeId then -- Enhancement
				return VUHDO_ID_MELEE_DAMAGE;
			else -- 2
				return VUHDO_ID_RANGED_DAMAGE;
			end
		elseif VUHDO_ID_DRUIDS == tClassId then
			if 103 == tTreeId then -- Feral
				return VUHDO_ID_MELEE_DAMAGE;
			else -- 2
				return VUHDO_ID_RANGED_DAMAGE;
			end
		elseif VUHDO_ID_HUNTERS == tClassId then
			if 255 == tTreeId then -- Survival
				return VUHDO_ID_MELEE_DAMAGE;
			else
				return VUHDO_ID_RANGED_DAMAGE;
			end
		else -- e.g. Evoker Devastation
			return VUHDO_ID_RANGED_DAMAGE;
		end
	else
		return VUHDO_ID_UNDEFINED;
	end

end



--
local tActiveTree;
local tInfo;
local tTreeId;
function VUHDO_inspectLockRole()

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		VUHDO_NEXT_INSPECT_UNIT = nil;

		return;
	end

	tInfo = VUHDO_RAID[VUHDO_NEXT_INSPECT_UNIT];

	if not tInfo then
		VUHDO_NEXT_INSPECT_UNIT = nil;

		return;
	end

	if "player" == VUHDO_NEXT_INSPECT_UNIT then
		tActiveTree = GetSpecialization();

		if not tActiveTree then
			tName = VUHDO_getUnitIdentityKey(tInfo);

			if tName then
				VUHDO_INSPECTED_ROLES[tName] = VUHDO_ID_UNDEFINED;
			end

			VUHDO_NEXT_INSPECT_UNIT = nil;

			return;
		end

		tTreeId = GetSpecializationInfo(tActiveTree, false, false);
	else
		tTreeId = GetInspectSpecialization(VUHDO_NEXT_INSPECT_UNIT);
	end

	if sSecretsEnabled and issecretvalue(tTreeId) then
		ClearInspectPlayer();

		VUHDO_NEXT_INSPECT_UNIT = nil;
		tName = VUHDO_getUnitIdentityKey(tInfo);

		if tName then
			VUHDO_INSPECTED_ROLES[tName] = VUHDO_ID_UNDEFINED;
		end

		return;
	end

	if (tTreeId or 0) == 0 then
		ClearInspectPlayer();

		VUHDO_NEXT_INSPECT_UNIT = nil;
		tName = VUHDO_getUnitIdentityKey(tInfo);

		if tName then
			VUHDO_INSPECTED_ROLES[tName] = VUHDO_ID_UNDEFINED;
		end

		return;
	end

	--VUHDO_xMsg(VUHDO_NEXT_INSPECT_UNIT, tTreeId);

	tName = VUHDO_getUnitIdentityKey(tInfo);

	if tName then
		VUHDO_INSPECTED_ROLES[tName] = VUHDO_inspectRole(VUHDO_NEXT_INSPECT_UNIT);
	end

	ClearInspectPlayer();

	VUHDO_NEXT_INSPECT_UNIT = nil;
	VUHDO_normalRaidReload();

	return;

end



--
local tDfRole, tOldRole, tReturnRole, tName;
local function VUHDO_determineDfToolRole(anInfo)

	tName = VUHDO_getUnitIdentityKey(anInfo);

	if not tName then
		return nil;
	end

	tOldRole = VUHDO_DF_TOOL_ROLES[tName];
	tDfRole = UnitGroupRolesAssigned(anInfo["unit"]);

	if sSecretsEnabled and issecretvalue(tDfRole) then
		return nil;
	end

	if "NONE" == tDfRole then
		VUHDO_DF_TOOL_ROLES[tName] = nil;
		tReturnRole = nil;
	elseif "TANK" == tDfRole then
		VUHDO_DF_TOOL_ROLES[tName] = 60; -- VUHDO_ID_MELEE_TANK
		tReturnRole = 60; -- VUHDO_ID_MELEE_TANK
	elseif "HEALER" == tDfRole then
		VUHDO_DF_TOOL_ROLES[tName] = 63; -- VUHDO_ID_RANGED_HEAL
		tReturnRole = 63; -- VUHDO_ID_RANGED_HEAL
	elseif "DAMAGER" == tDfRole then
		if anInfo["classId"] == VUHDO_ID_WARRIORS
			or anInfo["classId"] == VUHDO_ID_PALADINS
			or anInfo["classId"] == VUHDO_ID_DEATH_KNIGHT
			or anInfo["classId"] == VUHDO_ID_MONKS 
			or anInfo["classId"] == VUHDO_ID_ROGUES 
			or (anInfo["classId"] == VUHDO_ID_DRUIDS
				and not UnitPowerType(anInfo["unit"]) == VUHDO_UNIT_POWER_LUNAR_POWER) then
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_MELEE_DAMAGE;
			tReturnRole = VUHDO_ID_MELEE_DAMAGE;
		elseif anInfo["classId"] == VUHDO_ID_PRIESTS 
			or anInfo["classId"] == VUHDO_ID_WARLOCKS 
			or anInfo["classId"] == VUHDO_ID_MAGES 
			or anInfo["classId"] == VUHDO_ID_EVOKERS
			or (anInfo["classId"] == VUHDO_ID_DRUIDS
				and UnitPowerType(anInfo["unit"]) == VUHDO_UNIT_POWER_LUNAR_POWER) then
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_RANGED_DAMAGE;
			tReturnRole = VUHDO_ID_RANGED_DAMAGE;
		elseif anInfo["classId"] == VUHDO_ID_DRUIDS then
			-- Feral since neither Restoration or Moonkin has previously matched
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_MELEE_DAMAGE;
			tReturnRole = VUHDO_ID_MELEE_DAMAGE;
		elseif anInfo["classId"] == VUHDO_ID_HUNTERS then
			-- Hunters default to ranged but require inspect to determine spec ID so no return
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_RANGED_DAMAGE;
			tReturnRole = nil;
		elseif anInfo["classId"] == VUHDO_ID_DEMON_HUNTERS then
			-- Demon Hunters default to melee but require inspect to distinguish Devourer (ranged) so no return
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_MELEE_DAMAGE;
			tReturnRole = nil;
		else
			-- Shaman default to melee but require inspect to determine spec ID so no return
			VUHDO_DF_TOOL_ROLES[tName] = VUHDO_ID_MELEE_DAMAGE;
			tReturnRole = nil;
		end
	end

	if tOldRole ~= VUHDO_DF_TOOL_ROLES[tName] then
		VUHDO_normalRaidReload();
	end

	return tReturnRole;

end



--
local tForeverBuffTexture;
local tForeverClassId;
local tForeverIdentityKey;
local function VUHDO_determineHeuristicRole(aUnit, anInfo)

	tForeverClassId = anInfo["classId"];

	if VUHDO_ID_HUNTERS == tForeverClassId then
		tForeverIdentityKey = VUHDO_getUnitIdentityKey(anInfo);

		if tForeverIdentityKey then
			VUHDO_FIX_ROLES[tForeverIdentityKey] = VUHDO_ID_RANGED_DAMAGE;
		end

		return VUHDO_ID_RANGED_DAMAGE;
	elseif VUHDO_ID_PRIESTS == tForeverClassId then
		_, tForeverBuffTexture = VUHDO_unitBuffAllowSecret(aUnit, VUHDO_SPELL_ID.SHADOWFORM);

		if tForeverBuffTexture then
			return VUHDO_ID_RANGED_DAMAGE;
		end

		return VUHDO_ID_RANGED_HEAL;
	elseif VUHDO_ID_DRUIDS == tForeverClassId then
		_, tForeverBuffTexture = VUHDO_unitBuffAllowSecret(aUnit, VUHDO_SPELL_ID.MOONKIN_FORM);

		if tForeverBuffTexture then
			return VUHDO_ID_RANGED_DAMAGE;
		end
	elseif VUHDO_ID_SHAMANS == tForeverClassId then
		_, tForeverBuffTexture = VUHDO_unitBuffAllowSecret(aUnit, VUHDO_SPELL_ID.BUFF_ELEMENTAL_FOCUS);

		if tForeverBuffTexture then
			return VUHDO_ID_RANGED_DAMAGE;
		end
	end

	return nil;

end



--
local tInfo;
local tPowerType;
local tFixRole;
local tIntellect, tStrength, tAgility;
local tClassId, tClassRole, tName;
local tRole;
local tDfRole;
local tMaxPower;
function VUHDO_determineRole(aUnit)

	tInfo = VUHDO_RAID[aUnit];

	if not tInfo or tInfo["isPet"] then
		return nil;
	end

	if tInfo["hasSecretIdentity"] then
		tDfRole = UnitGroupRolesAssigned(tInfo["unit"]);

		if sSecretsEnabled and issecretvalue(tDfRole) then
			return nil;
		end

		if "TANK" == tDfRole then
			return 60;
		elseif "HEALER" == tDfRole then
			return 63;
		elseif "DAMAGER" == tDfRole then
			tClassId = tInfo["classId"];

			if tClassId == VUHDO_ID_WARRIORS
				or tClassId == VUHDO_ID_PALADINS
				or tClassId == VUHDO_ID_DEATH_KNIGHT
				or tClassId == VUHDO_ID_MONKS
				or tClassId == VUHDO_ID_ROGUES then
				return 61;
			elseif tClassId == VUHDO_ID_PRIESTS
				or tClassId == VUHDO_ID_WARLOCKS
				or tClassId == VUHDO_ID_MAGES
				or tClassId == VUHDO_ID_EVOKERS then
				return 62;
			elseif tClassId == VUHDO_ID_HUNTERS
				or tClassId == VUHDO_ID_SHAMANS then
				return 62;
			elseif tClassId == VUHDO_ID_DEMON_HUNTERS then
				tIntellect = UnitStat(tInfo["unit"], 4);
				tAgility = UnitStat(tInfo["unit"], 2);

				if sSecretsEnabled and (issecretvalue(tIntellect) or issecretvalue(tAgility)) then
					return 61;
				elseif tIntellect > tAgility then
					return 62;
				else
					return 61;
				end
			elseif tClassId == VUHDO_ID_DRUIDS then
				if UnitPowerType(tInfo["unit"]) == VUHDO_UNIT_POWER_LUNAR_POWER then
					return 62;
				else
					return 61;
				end
			end
		end

		return nil;
	end

	tName = VUHDO_getUnitIdentityKey(tInfo);

	if not tName then
		return nil;
	end

	-- Manual role override oder dungeon finder role?
	tFixRole = VUHDO_MANUAL_ROLES[tName] or VUHDO_determineDfToolRole(tInfo);

	if tFixRole then
		return tFixRole;
	end

	-- Assigned for MT?
	if VUHDO_isUnitInModel(aUnit, 41) then -- VUHDO_ID_MAINTANKS
		return 60; -- VUHDO_ID_MELEE_TANK
	end

	-- Role determined by non-hybrid class?
	tClassId = tInfo["classId"];
	tClassRole = VUHDO_CLASS_ROLES[tClassId];

	if tClassRole then
		return tClassRole;
	end

	tFixRole = VUHDO_ROLE_BY_SPEC[tName];

	if tFixRole then
		return tFixRole;
	end

	-- Talent tree inspected?
	if (VUHDO_INSPECTED_ROLES[tName] or VUHDO_ID_UNDEFINED) ~= VUHDO_ID_UNDEFINED then
		return VUHDO_INSPECTED_ROLES[tName];
	end

	-- Talent tree immediately inspectable?
	tRole = VUHDO_inspectRole(aUnit);

	if (tRole or VUHDO_ID_UNDEFINED) ~= VUHDO_ID_UNDEFINED then
		return tRole;
	end

	-- Estimated role fixed?
	if VUHDO_FIX_ROLES[tName] then
		return VUHDO_FIX_ROLES[tName];
	end

	if VUHDO_FLAVOR_SPEC_TALENT_GROUPS == VUHDO_getFlavorSpecModel() then
		tRole = VUHDO_determineHeuristicRole(aUnit, tInfo);

		if tRole then
			return tRole;
		end
	end

	if sSecretsEnabled and tInfo["hasSecretPower"] then
		tDfRole = UnitGroupRolesAssigned(aUnit);

		if issecretvalue(tDfRole) then
			return nil;
		end

		if "TANK" == tDfRole then
			return 60;
		elseif "HEALER" == tDfRole then
			return 63;
		elseif "DAMAGER" == tDfRole then
			if tClassId == VUHDO_ID_WARRIORS
				or tClassId == VUHDO_ID_PALADINS
				or tClassId == VUHDO_ID_DEATH_KNIGHT
				or tClassId == VUHDO_ID_MONKS
				or tClassId == VUHDO_ID_ROGUES then
				return 61;
			elseif tClassId == VUHDO_ID_PRIESTS
				or tClassId == VUHDO_ID_WARLOCKS
				or tClassId == VUHDO_ID_MAGES
				or tClassId == VUHDO_ID_EVOKERS then
				return 62;
			elseif tClassId == VUHDO_ID_HUNTERS
				or tClassId == VUHDO_ID_SHAMANS then
				return 62;
			elseif tClassId == VUHDO_ID_DEMON_HUNTERS then
				tIntellect = UnitStat(aUnit, 4);
				tAgility = UnitStat(aUnit, 2);

				if issecretvalue(tIntellect) or issecretvalue(tAgility) then
					return 61;
				elseif tIntellect > tAgility then
					return 62;
				else
					return 61;
				end
			elseif tClassId == VUHDO_ID_DRUIDS then
				return 61;
			end
		end
	end

	if 29 == tClassId then -- VUHDO_ID_DEATH_KNIGHT
		VUHDO_FIX_ROLES[tName] = 61; -- VUHDO_ID_MELEE_DAMAGE
		return 61; -- VUHDO_ID_MELEE_DAMAGE

	elseif 28 == tClassId then -- VUHDO_ID_PRIESTS
		tPowerType = UnitPowerType(aUnit);

		if VUHDO_UNIT_POWER_INSANITY == tPowerType then
			VUHDO_FIX_ROLES[tName] = 62; -- VUHDO_ID_RANGED_DAMAGE
			return 62; -- VUHDO_ID_RANGED_DAMAGE
		else
			return 63; -- VUHDO_ID_RANGED_HEAL
		end

	elseif 20 == tClassId then -- VUHDO_ID_WARRIORS
		VUHDO_FIX_ROLES[tName] = 61; -- VUHDO_ID_MELEE_DAMAGE
		return 61; -- VUHDO_ID_MELEE_DAMAGE

	elseif 27 == tClassId then -- VUHDO_ID_DRUIDS
		tPowerType = UnitPowerType(aUnit);

		if VUHDO_UNIT_POWER_MANA == tPowerType then
			return 63; -- VUHDO_ID_RANGED_HEAL
		elseif VUHDO_UNIT_POWER_LUNAR_POWER == tPowerType then
			VUHDO_FIX_ROLES[tName] = 62; --	VUHDO_ID_RANGED_DAMAGE
			return 62; -- VUHDO_ID_RANGED_DAMAGE
		elseif VUHDO_UNIT_POWER_RAGE == tPowerType then
			VUHDO_FIX_ROLES[tName] = 60; -- VUHDO_ID_MELEE_TANK
			return 60; -- VUHDO_ID_MELEE_TANK
		elseif VUHDO_UNIT_POWER_ENERGY == tPowerType then
			VUHDO_FIX_ROLES[tName] = 61; -- VUHDO_ID_MELEE_DAMAGE
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		end

	elseif 23 == tClassId then -- VUHDO_ID_PALADINS
		tIntellect = UnitStat(aUnit, 4);
		tStrength = UnitStat(aUnit, 1);

		if sSecretsEnabled and (issecretvalue(tIntellect) or issecretvalue(tStrength)) then
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		elseif tIntellect > tStrength then
			return 63; -- VUHDO_ID_RANGED_HEAL
		else
			VUHDO_FIX_ROLES[tName] = 61; -- VUHDO_ID_MELEE_DAMAGE
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		end

	elseif 26 == tClassId then -- VUHDO_ID_SHAMANS
		tIntellect = UnitStat(aUnit, 4);
		tAgility = UnitStat(aUnit, 2);

		if sSecretsEnabled and (issecretvalue(tIntellect) or issecretvalue(tAgility)) then
			tPowerType = UnitPowerType(aUnit);

			if VUHDO_UNIT_POWER_MANA == tPowerType then
				return 63; -- VUHDO_ID_RANGED_HEAL
			else
				return 62; -- VUHDO_ID_RANGED_DAMAGE
			end
		elseif tAgility > tIntellect then
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		else
			tPowerType = UnitPowerType(aUnit);

			if VUHDO_UNIT_POWER_MAELSTROM == tPowerType then -- VUHDO_ID_RANGED_DAMAGE
				return 62; -- VUHDO_ID_RANGED_DAMAGE
			else
				return 63; -- VUHDO_ID_RANGED_HEAL
			end
		end

	elseif 31 == tClassId then -- VUHDO_ID_DEMON_HUNTERS
		tPowerType = UnitPowerType(aUnit);
		tIntellect = UnitStat(aUnit, 4);
		tAgility = UnitStat(aUnit, 2);

		if VUHDO_UNIT_POWER_PAIN == tPowerType then
			return 60; -- VUHDO_ID_MELEE_TANK
		elseif sSecretsEnabled and (issecretvalue(tIntellect) or issecretvalue(tAgility)) then
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		elseif tIntellect > tAgility then
			return 62; -- VUHDO_ID_RANGED_DAMAGE
		else
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		end

	elseif 22 == tClassId then -- VUHDO_ID_HUNTERS
		tMaxPower = UnitPowerMax(aUnit);

		if sSecretsEnabled and issecretvalue(tMaxPower) then
			return 62; -- VUHDO_ID_RANGED_DAMAGE
		elseif tMaxPower == 100 then -- Survival
			return 61; -- VUHDO_ID_MELEE_DAMAGE
		else
			return 62; -- VUHDO_ID_RANGED_DAMAGE
		end

	elseif 30 == tClassId then -- VUHDO_ID_MONKS
		tPowerType = UnitPowerType(aUnit);

		if VUHDO_UNIT_POWER_MANA == tPowerType then
			return 63; -- VUHDO_ID_RANGED_HEAL
		elseif VUHDO_UNIT_POWER_ENERGY == tPowerType then
			tMaxPower = UnitPowerMax(aUnit, VUHDO_UNIT_POWER_CHI);

			if sSecretsEnabled and issecretvalue(tMaxPower) then
				return 61; -- VUHDO_ID_MELEE_DAMAGE
			elseif tMaxPower > 4 then -- WW Monks have 5 Chi (6 w/ Ascension)
				return 61; -- VUHDO_ID_MELEE_DAMAGE
			else
				return 60; -- VUHDO_ID_MELEE_TANK
			end
		end

	elseif 32 == tClassId then -- VUHDO_ID_EVOKERS
		VUHDO_FIX_ROLES[tName] = 62; -- VUHDO_ID_RANGED_DAMAGE
		return 62; -- VUHDO_ID_RANGED_DAMAGE

	end

	return nil;

end



--
local tName;
local tUnit;
local tInfo;
local tRole;
local tOldRole;
function VUHDO_updateRoleBySpecialization(aSpecId, aRole, aPosition, aSender, aTalentString)

	if VUHDO_FLAVOR_SPEC_SPECIALIZATIONS ~= VUHDO_getFlavorSpecModel() then
		return;
	end

	if not aRole or not aPosition or not aSender then
		return;
	end

	tUnit = VUHDO_resolveUnitByName(aSender);

	if not tUnit then
		return;
	end

	tInfo = VUHDO_RAID[tUnit];

	if tInfo and VUHDO_determineDfToolRole(tInfo) then
		return;
	end

	tName = VUHDO_getUnitIdentityKey(tInfo);

	if not tName then
		return;
	end

	if aRole == "TANK" then
		tRole = VUHDO_ID_MELEE_TANK;
	elseif aRole == "DAMAGER" then
		if aPosition == "RANGED" then
			tRole = VUHDO_ID_RANGED_DAMAGE;
		else
			tRole = VUHDO_ID_MELEE_DAMAGE;
		end
	else
		tRole = VUHDO_ID_RANGED_HEAL;
	end

	tOldRole = VUHDO_ROLE_BY_SPEC[tName];
	VUHDO_ROLE_BY_SPEC[tName] = tRole;

	if tUnit and tInfo and tOldRole ~= tRole then
		VUHDO_normalRaidReload();
	end

end
