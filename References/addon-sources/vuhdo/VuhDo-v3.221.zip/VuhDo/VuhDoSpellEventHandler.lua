local _;
--
local smatch = string.match;

local InCombatLockdown = InCombatLockdown;
local GetSpellName = C_Spell and C_Spell.GetSpellName;
local SendChatMessage = C_ChatInfo and C_ChatInfo.SendChatMessage;
local issecretvalue = issecretvalue;

local VUHDO_initGcd;
local VUHDO_strempty;

local VUHDO_RAID;
local VUHDO_RAID_NAMES;
local VUHDO_resolveUnitByName;
local VUHDO_getUnitIdentityKey;
local VUHDO_GROUPS;
local VUHDO_CONFIG = { };

local sIsShowGcd;
local sUniqueSpells = { };
local sFirstRes, sSecondRes, sThirdRes;
local sEmpty = { };
local sSecretsEnabled = VUHDO_SECRETS_ENABLED;



--
function VUHDO_spellEventHandlerInitLocalOverrides()
	VUHDO_initGcd = _G["VUHDO_initGcd"];
	VUHDO_strempty = _G["VUHDO_strempty"];

	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_RAID_NAMES = _G["VUHDO_RAID_NAMES"];
	VUHDO_resolveUnitByName = _G["VUHDO_resolveUnitByName"];
	VUHDO_getUnitIdentityKey = _G["VUHDO_getUnitIdentityKey"];
	VUHDO_GROUPS = _G["VUHDO_GROUPS"];
	VUHDO_CONFIG = _G["VUHDO_CONFIG"];

	sIsShowGcd = VUHDO_isShowGcd();

	table.wipe(sUniqueSpells);
	local tUnique, tUniqueCategs = VUHDO_getAllUniqueSpells();
	for _, tSpellName in pairs(tUnique) do
		sUniqueSpells[tSpellName] = tUniqueCategs[tSpellName];
	end

	sFirstRes, sSecondRes, sThirdRes = VUHDO_getResurrectionSpells();
end



--
function VUHDO_activateSpellForSpec(aSpecId)
	local tName = VUHDO_SPEC_LAYOUTS[aSpecId];
	if not VUHDO_strempty(tName) then
		if VUHDO_SPELL_LAYOUTS[tName] then VUHDO_activateLayout(tName);
		else VUHDO_Msg(format(VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST, tName), 1, 0.4, 0.4); end
	end
end



--
function VUHDO_activateSpecc(aSpecNum)
	local tProfile = VUHDO_getBestProfileAfterSpecChange();
	if tProfile then VUHDO_loadProfile(tProfile); end
	VUHDO_activateSpellForSpec(aSpecNum);
	VUHDO_aoeUpdateTalents();
end



--
local tTargetUnit;
local tCateg;
local tSpellName;
local tCastRoleId;
local tIsCastTargetInRole;
function VUHDO_spellcastSent(aUnit, aTargetName, aSpellId)

	if "player" ~= aUnit then
		return;
	end

	if sIsShowGcd then
		VUHDO_initGcd();
	end

	if aSpellId then
		tSpellName = GetSpellName(aSpellId);
	end

	if not tSpellName then
		return;
	end

	-- Resurrection?
	if not sSecretsEnabled and (tSpellName == sFirstRes or tSpellName == sSecondRes or tSpellName == sThirdRes) then
		if aTargetName and not VUHDO_strempty(aTargetName) then
			if not VUHDO_resolveUnitByName(aTargetName) then
				return;
			end
		end

		if VUHDO_CONFIG["RES_IS_SHOW_TEXT"] then
			local tChannel = (UnitInBattleground("player") or HasLFGRestrictions()) and "INSTANCE_CHAT"
				or IsInRaid() and "RAID" or IsInGroup() and "PARTY" or nil;

			if tChannel then
				SendChatMessage((gsub(VUHDO_strempty(aTargetName) and VUHDO_CONFIG["RES_ANNOUNCE_MASS_TEXT"] or VUHDO_CONFIG["RES_ANNOUNCE_TEXT"], "[Vv][Uu][Hh][Dd][Oo]", aTargetName or "")), tChannel);
			end
		end

		return;
	end

	if not aTargetName then
		return;
	end

	if sSecretsEnabled and issecretvalue(aTargetName) then
		return;
	end

	tTargetUnit = VUHDO_resolveUnitByName(aTargetName);

	if not tTargetUnit then
		return;
	end

	aTargetName = VUHDO_getUnitIdentityKey(VUHDO_RAID[tTargetUnit]);

	if not aTargetName then
		return;
	end

	tCateg = sUniqueSpells[tSpellName];

	if tCateg and not InCombatLockdown() and (VUHDO_BUFF_SETTINGS or sEmpty)[tCateg] then
		tCastRoleId = tonumber(VUHDO_BUFF_SETTINGS[tCateg]["targetMode"]);

		if tCastRoleId then
			tIsCastTargetInRole = false;

			for _, tRoleUnit in pairs((VUHDO_GROUPS or sEmpty)[tCastRoleId] or sEmpty) do
				if tRoleUnit == tTargetUnit then
					tIsCastTargetInRole = true;

					break;
				end
			end

			if tIsCastTargetInRole and aTargetName ~= VUHDO_BUFF_SETTINGS[tCateg]["name"] then
				VUHDO_BUFF_SETTINGS[tCateg]["name"] = aTargetName;

				VUHDO_reloadBuffPanel();
			end
		elseif (not VUHDO_BUFF_SETTINGS[tCateg]["targetMode"] or VUHDO_BUFF_SETTINGS[tCateg]["targetMode"] == "name")
			and aTargetName ~= VUHDO_BUFF_SETTINGS[tCateg]["name"] then
			VUHDO_BUFF_SETTINGS[tCateg]["name"] = aTargetName;

			VUHDO_reloadBuffPanel();
		end
	end

	return;

end
