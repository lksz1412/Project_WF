VUHDO_VERSION = C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata("VuhDo", "Version");

if not VUHDO_VERSION and GetAddOnMetadata then
	VUHDO_VERSION = GetAddOnMetadata("VuhDo", "Version");
end

VUHDO_COMMS_PREFIX = "VUHDO";

VUHDO_YES = 1;
VUHDO_NO = 2;

VUHDO_MAX_PANELS = 10;
VUHDO_REFRESH_TARGETS_SECS = 0.51;
VUHDO_BAR_AURA_ANCHOR_HOST = 24;
VUHDO_BAR_MANA_OFFSET = 25;
VUHDO_MAX_BOSS_FRAMES = 8;
VUHDO_MAX_PRIVATE_AURAS = 6;

VUHDO_PRIVATE_AURA_ANCHOR_FACTORS = {
	["TOPLEFT"] = { 0, 0 },
	["TOP"] = { 0.5, 0 },
	["TOPRIGHT"] = { 1, 0 },
	["LEFT"] = { 0, 0.5 },
	["CENTER"] = { 0.5, 0.5 },
	["RIGHT"] = { 1, 0.5 },
	["BOTTOMLEFT"] = { 0, 1 },
	["BOTTOM"] = { 0.5, 1 },
	["BOTTOMRIGHT"] = { 1, 1 },
};

--VUHDO_MAX_GROUPS_PER_PANEL = 15; -- Maximum number of Models (Groups) per Panel

--VUHDO_MAX_MTS = 8;

-- Heal panel operation modes
VUHDO_MODE_NEUTRAL = 1;  -- bar colors are gradient
VUHDO_MODE_EMERGENCY_PERC = 2; -- Top emergency mode, least life percent left (standard raid healing)
VUHDO_MODE_EMERGENCY_MOST_MISSING = 3; -- Top emergency mode, least most life missing (for spamming greater heals, MTs preffered)
VUHDO_MODE_EMERGENCY_LEAST_LEFT = 4; -- Top emergency mode, least life left (for raid healing when cyclic ae damage on whole raid)

-- Group model types
VUHDO_ID_TYPE_UNDEFINED = 0;
VUHDO_ID_TYPE_CLASS = 1;
VUHDO_ID_TYPE_GROUP = 2;
VUHDO_ID_TYPE_SPECIAL = 3;

VUHDO_UNIT_WATCH_TYPE_HEAL = 1;
VUHDO_UNIT_WATCH_TYPE_TARGET = 2;
VUHDO_UNIT_WATCH_TYPE_TOT = 3;


-- Group Model IDs
VUHDO_ID_UNDEFINED = 0;

VUHDO_ID_GROUP_1 = 1;
VUHDO_ID_GROUP_2 = 2;
VUHDO_ID_GROUP_3 = 3;
VUHDO_ID_GROUP_4 = 4;
VUHDO_ID_GROUP_5 = 5;
VUHDO_ID_GROUP_6 = 6;
VUHDO_ID_GROUP_7 = 7;
VUHDO_ID_GROUP_8 = 8;

VUHDO_ID_GROUP_OWN = 10;

VUHDO_ID_WARRIORS = 20;
VUHDO_ID_ROGUES = 21;
VUHDO_ID_HUNTERS = 22;
VUHDO_ID_PALADINS = 23;
VUHDO_ID_MAGES = 24;
VUHDO_ID_WARLOCKS = 25;
VUHDO_ID_SHAMANS = 26;
VUHDO_ID_DRUIDS = 27;
VUHDO_ID_PRIESTS = 28;
VUHDO_ID_DEATH_KNIGHT = 29;
VUHDO_ID_MONKS = 30;
VUHDO_ID_DEMON_HUNTERS = 31;
VUHDO_ID_EVOKERS = 32;

VUHDO_ID_PETS = 40;
VUHDO_ID_MAINTANKS = 41;
VUHDO_ID_PRIVATE_TANKS = 42;
VUHDO_ID_MAIN_ASSISTS = 43;
VUHDO_ID_BOSSES = 44;

VUHDO_ID_MELEE = 50;
VUHDO_ID_RANGED = 51;

VUHDO_ID_MELEE_TANK = 60;
VUHDO_ID_MELEE_DAMAGE = 61;
VUHDO_ID_RANGED_DAMAGE = 62;
VUHDO_ID_RANGED_HEAL = 63;

VUHDO_ID_VEHICLES = 70;

VUHDO_ID_SELF = 80;
VUHDO_ID_SELF_PET = 81;
VUHDO_ID_TARGET = 82;
VUHDO_ID_FOCUS = 83

VUHDO_ID_ALL = 999;



VUHDO_I18N_AURA_GROUP_NAMES = {
	["MY_HOTS"] = VUHDO_I18N_AURA_GROUP_MY_HOTS,
	["ALL_HOTS"] = VUHDO_I18N_AURA_GROUP_ALL_HOTS,
	["DISPELLABLE"] = VUHDO_I18N_AURA_GROUP_DISPELLABLE,
	["ALL_DISPELLABLE"] = VUHDO_I18N_AURA_GROUP_ALL_DISPELLABLE,
	["PURGEABLE_BUFFS"] = VUHDO_I18N_AURA_GROUP_PURGEABLE_BUFFS,
	["ALL_PURGEABLE_BUFFS"] = VUHDO_I18N_AURA_GROUP_ALL_PURGEABLE_BUFFS,
	["CC_EFFECTS"] = VUHDO_I18N_AURA_GROUP_CC,
	["BIG_DEFENSIVES"] = VUHDO_I18N_AURA_GROUP_BIG_DEF,
	["EXTERNAL_DEFENSIVES"] = VUHDO_I18N_AURA_GROUP_EXTERNAL_DEF,
	["ALL_DEBUFFS"] = VUHDO_I18N_AURA_GROUP_ALL_DEBUFFS,
	["ALL_BUFFS"] = VUHDO_I18N_AURA_GROUP_ALL_BUFFS,
	["RELEVANT_DEBUFFS"] = VUHDO_I18N_AURA_GROUP_RELEVANT_DEBUFFS,
	["RELEVANT_BUFFS"] = VUHDO_I18N_AURA_GROUP_RELEVANT_BUFFS,
	["MY_DEBUFFS"] = VUHDO_I18N_AURA_GROUP_MY_DEBUFFS,
	["PRESERVATION_EVOKER_HOTS"] = VUHDO_I18N_AURA_GROUP_PRESERVATION_EVOKER_HOTS,
	["AUGMENTATION_EVOKER_BUFFS"] = VUHDO_I18N_AURA_GROUP_AUGMENTATION_EVOKER_BUFFS,
	["RESTORATION_DRUID_HOTS"] = VUHDO_I18N_AURA_GROUP_RESTORATION_DRUID_HOTS,
	["FERAL_DRUID_BUFFS"] = VUHDO_I18N_AURA_GROUP_FERAL_DRUID_BUFFS,
	["DISCIPLINE_PRIEST_HOTS"] = VUHDO_I18N_AURA_GROUP_DISCIPLINE_PRIEST_HOTS,
	["HOLY_PRIEST_HOTS"] = VUHDO_I18N_AURA_GROUP_HOLY_PRIEST_HOTS,
	["MISTWEAVER_MONK_HOTS"] = VUHDO_I18N_AURA_GROUP_MISTWEAVER_MONK_HOTS,
	["RESTORATION_SHAMAN_HOTS"] = VUHDO_I18N_AURA_GROUP_RESTORATION_SHAMAN_HOTS,
	["HOLY_PALADIN_HOTS"] = VUHDO_I18N_AURA_GROUP_HOLY_PALADIN_HOTS,
	["RAID_BUFFS"] = VUHDO_I18N_AURA_GROUP_RAID_BUFFS,
	["BLESSING_OF_BRONZE"] = VUHDO_I18N_AURA_GROUP_BLESSING_OF_BRONZE,
	["ROGUE_POISONS"] = VUHDO_I18N_AURA_GROUP_ROGUE_POISONS,
	["SHAMAN_WEAPON_IMBUEMENTS"] = VUHDO_I18N_AURA_GROUP_SHAMAN_WEAPON_IMBUEMENTS,
	["PALADIN_WEAPON_IMBUEMENTS"] = VUHDO_I18N_AURA_GROUP_PALADIN_WEAPON_IMBUEMENTS,
	["ENHANCEMENT_SHAMAN_BUFFS"] = VUHDO_I18N_AURA_GROUP_ENHANCEMENT_SHAMAN_BUFFS,
	["BREWMASTER_MONK_BUFFS"] = VUHDO_I18N_AURA_GROUP_BREWMASTER_MONK_BUFFS,
	["WARLOCK_METAMORPHOSIS"] = VUHDO_I18N_AURA_GROUP_WARLOCK_METAMORPHOSIS,
	["PRIEST_WEAKENED_SOUL"] = VUHDO_I18N_AURA_GROUP_PRIEST_WEAKENED_SOUL,
};



-- Group types
VUHDO_GROUP_TYPE_SOLO = 0;
VUHDO_GROUP_TYPE_PARTY = 1;
VUHDO_GROUP_TYPE_RAID = 2;



--
-- Members of member types
--
VUHDO_ID_TYPE_MEMBERS = {

	[VUHDO_ID_TYPE_UNDEFINED] = {
		VUHDO_ID_UNDEFINED
	},

	[VUHDO_ID_TYPE_GROUP] = {
		VUHDO_ID_GROUP_1,
		VUHDO_ID_GROUP_2,
		VUHDO_ID_GROUP_3,
		VUHDO_ID_GROUP_4,
		VUHDO_ID_GROUP_5,
		VUHDO_ID_GROUP_6,
		VUHDO_ID_GROUP_7,
		VUHDO_ID_GROUP_8,
		VUHDO_ID_GROUP_OWN
	},

	[VUHDO_ID_TYPE_CLASS] = {
		VUHDO_ID_WARRIORS,
		VUHDO_ID_ROGUES,
		VUHDO_ID_HUNTERS,
		VUHDO_ID_PALADINS,
		VUHDO_ID_MAGES,
		VUHDO_ID_WARLOCKS,
		VUHDO_ID_SHAMANS,
		VUHDO_ID_DRUIDS,
		VUHDO_ID_PRIESTS,
		VUHDO_ID_DEATH_KNIGHT,
		VUHDO_ID_MONKS,
		VUHDO_ID_DEMON_HUNTERS,
		VUHDO_ID_EVOKERS,
	},

	[VUHDO_ID_TYPE_SPECIAL] = {
		VUHDO_ID_MAINTANKS,
		VUHDO_ID_MAIN_ASSISTS,
		VUHDO_ID_PRIVATE_TANKS,
		VUHDO_ID_PETS,
		VUHDO_ID_VEHICLES,
		VUHDO_ID_BOSSES, 
		VUHDO_ID_MELEE,
		VUHDO_ID_RANGED,
		VUHDO_ID_MELEE_TANK,
		VUHDO_ID_MELEE_DAMAGE,
		VUHDO_ID_RANGED_DAMAGE,
		VUHDO_ID_RANGED_HEAL,
		VUHDO_ID_SELF,
		VUHDO_ID_SELF_PET,
		VUHDO_ID_TARGET,
		VUHDO_ID_FOCUS,
	},

	[VUHDO_ID_ALL] = {
	},
};




VUHDO_ID_MEMBER_TYPES = {
	[VUHDO_ID_UNDEFINED] = VUHDO_ID_TYPE_UNDEFINED,

	[VUHDO_ID_GROUP_1] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_2] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_3] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_4] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_5] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_6] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_7] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_8] = VUHDO_ID_TYPE_GROUP,
	[VUHDO_ID_GROUP_OWN] = VUHDO_ID_TYPE_GROUP,

	[VUHDO_ID_WARRIORS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_ROGUES] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_HUNTERS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_PALADINS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_MAGES] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_WARLOCKS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_SHAMANS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_DRUIDS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_PRIESTS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_DEATH_KNIGHT] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_MONKS] =  VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_DEMON_HUNTERS] = VUHDO_ID_TYPE_CLASS,
	[VUHDO_ID_EVOKERS] = VUHDO_ID_TYPE_CLASS,
};



-- Flags for panel ordering type
VUHDO_ORDERING_STRICT = 0;
VUHDO_ORDERING_LOOSE = 1;



-- sorting criterions within panel
VUHDO_SORT_RAID_UNITID = 0;
VUHDO_SORT_RAID_NAME = 1;
VUHDO_SORT_RAID_CLASS = 2;
VUHDO_SORT_RAID_MAX_HP = 3;
VUHDO_SORT_RAID_MODELS = 4;
VUHDO_SORT_TA_DD_HL = 5;
VUHDO_SORT_TA_HL_DD = 6;
VUHDO_SORT_HL_TA_DD = 7;
VUHDO_SORT_TA_MD_RD_HL = 8;
VUHDO_SORT_TA_HL_MD_RD = 9;


-- Class IDs by class name
VUHDO_CLASS_IDS = {
	["WARRIOR"] = VUHDO_ID_WARRIORS,
	["ROGUE"] = VUHDO_ID_ROGUES,
	["HUNTER"] = VUHDO_ID_HUNTERS,
	["PALADIN"] = VUHDO_ID_PALADINS,
	["MAGE"] = VUHDO_ID_MAGES,
	["WARLOCK"] = VUHDO_ID_WARLOCKS,
	["SHAMAN"] = VUHDO_ID_SHAMANS,
	["DRUID"] = VUHDO_ID_DRUIDS,
	["PRIEST"] = VUHDO_ID_PRIESTS,
	["DEATHKNIGHT"] = VUHDO_ID_DEATH_KNIGHT,
	["MONK"] =  VUHDO_ID_MONKS,
	["DEMONHUNTER"] = VUHDO_ID_DEMON_HUNTERS,
	["EVOKER"] = VUHDO_ID_EVOKERS,
};



-- Class names by class ID
VUHDO_ID_CLASSES = {
	[VUHDO_ID_WARRIORS] = "WARRIOR",
	[VUHDO_ID_ROGUES] = "ROGUE",
	[VUHDO_ID_HUNTERS] = "HUNTER",
	[VUHDO_ID_PALADINS] = "PALADIN",
	[VUHDO_ID_MAGES] = "MAGE",
	[VUHDO_ID_WARLOCKS] = "WARLOCK",
	[VUHDO_ID_SHAMANS] = "SHAMAN",
	[VUHDO_ID_DRUIDS] = "DRUID",
	[VUHDO_ID_PRIESTS] = "PRIEST",
	[VUHDO_ID_DEATH_KNIGHT] = "DEATHKNIGHT",
	[VUHDO_ID_MONKS] = "MONK",
	[VUHDO_ID_DEMON_HUNTERS] = "DEMONHUNTER",
	[VUHDO_ID_EVOKERS] = "EVOKER",
};



-- Action button assignent constant values
VUHDO_SPELL_KEY_ASSIST = "assist";
VUHDO_SPELL_KEY_FOCUS = "focus";
VUHDO_SPELL_KEY_TARGET = "target";
VUHDO_SPELL_KEY_EXTRAACTIONBUTTON = "extraactionbutton";
VUHDO_SPELL_KEY_MENU = "menu";
VUHDO_SPELL_KEY_TELL = "tell";
VUHDO_SPELL_KEY_DROPDOWN = "dropdown";
VUHDO_SPELL_KEY_MOUSELOOK = "mouselook";
VUHDO_SPELL_KEY_PING = "ping";



-- Types of updating unit status by event
VUHDO_UPDATE_ALL = 1;
VUHDO_UPDATE_HEALTH = 2;
VUHDO_UPDATE_HEALTH_MAX = 3;
VUHDO_UPDATE_DEBUFF = 4;
VUHDO_UPDATE_RANGE = 5;
VUHDO_UPDATE_AFK = 6;
VUHDO_UPDATE_AGGRO = 7;
VUHDO_UPDATE_TARGET = 8;
VUHDO_UPDATE_INC = 9;
VUHDO_UPDATE_ALIVE = 10;
VUHDO_UPDATE_EMERGENCY = 11;
VUHDO_UPDATE_MANA = 13;
VUHDO_UPDATE_THREAT_PERC = 14;
VUHDO_UPDATE_MOUSEOVER = 15;
VUHDO_UPDATE_NUM_CLUSTER = 16;
VUHDO_UPDATE_THREAT_LEVEL = 17;
VUHDO_UPDATE_MOUSEOVER_CLUSTER = 18;
VUHDO_UPDATE_DC = 19;
VUHDO_UPDATE_MOUSEOVER_GROUP = 20;
VUHDO_UPDATE_OTHER_POWERS = 21;
VUHDO_UPDATE_UNIT_TARGET = 22;
VUHDO_UPDATE_PLAYER_FOCUS = 23;
VUHDO_UPDATE_RAID_TARGET = 24;
VUHDO_UPDATE_RESURRECTION = 25;
VUHDO_UPDATE_PETS = 26;
VUHDO_UPDATE_PLAYER_TARGET = 27;
VUHDO_UPDATE_ROLE = 28;
VUHDO_UPDATE_CUSTOM_DEBUFF = 29;
VUHDO_UPDATE_ALT_POWER = 30;
VUHDO_UPDATE_OWN_HOLY_POWER = 31;
VUHDO_UPDATE_AOE_ADVICE = 32;
VUHDO_UPDATE_RAID_ROSTER = 33;
VUHDO_UPDATE_MINOR_FLAGS = 34;
VUHDO_UPDATE_CHI = 35;
VUHDO_UPDATE_SHIELD = 36;
VUHDO_UPDATE_SPELL_TRACE = 37;
VUHDO_UPDATE_SUMMON = 38;
VUHDO_UPDATE_PHASE = 39;
VUHDO_UPDATE_COMBO_POINTS = 40;
VUHDO_UPDATE_SOUL_SHARDS = 41;
VUHDO_UPDATE_RUNES = 42;
VUHDO_UPDATE_ARCANE_CHARGES = 43;
VUHDO_UPDATE_HEALTH_LOSS = 44;
VUHDO_UPDATE_AURA_INFERENCE = 50;
VUHDO_UPDATE_BOUQUET_RESET = -1;



-- Unit power types (== Blizzard defined types)
VUHDO_UNIT_POWER_MANA = Enum.PowerType.Mana;
VUHDO_UNIT_POWER_RAGE = Enum.PowerType.Rage;
VUHDO_UNIT_POWER_FOCUS = Enum.PowerType.Focus;
VUHDO_UNIT_POWER_ENERGY = Enum.PowerType.Energy;
VUHDO_UNIT_POWER_COMBO_POINTS = Enum.PowerType.ComboPoints;
VUHDO_UNIT_POWER_RUNIC_POWER = Enum.PowerType.RunicPower;
VUHDO_UNIT_POWER_LUNAR_POWER = Enum.PowerType.LunarPower;
VUHDO_UNIT_POWER_MAELSTROM = Enum.PowerType.Maelstrom;
VUHDO_UNIT_POWER_INSANITY = Enum.PowerType.Insanity;
VUHDO_UNIT_POWER_FURY = Enum.PowerType.Fury;
VUHDO_UNIT_POWER_PAIN = Enum.PowerType.Pain;
VUHDO_UNIT_POWER_CHI = Enum.PowerType.Chi;
VUHDO_UNIT_POWER_HOLY_POWER = Enum.PowerType.HolyPower;
VUHDO_UNIT_POWER_SOUL_SHARDS = Enum.PowerType.SoulShards;
VUHDO_UNIT_POWER_RUNES = Enum.PowerType.Runes;
VUHDO_UNIT_POWER_ARCANE_CHARGES = Enum.PowerType.ArcaneCharges;
VUHDO_UNIT_POWER_ESSENCE = Enum.PowerType.Essence;



local ipairs = ipairs;

VUHDO_BATTLE_REZ_ITEM_LOOKUP = { };

for _, tItemID in ipairs(VUHDO_BATTLE_REZ_ITEM_IDS) do
	VUHDO_BATTLE_REZ_ITEM_LOOKUP[tItemID] = true;
end



VUHDO_LT_MODE_PERCENT = 1;
VUHDO_LT_MODE_LEFT = 2;
VUHDO_LT_MODE_MISSING = 3;



VUHDO_LT_POS_RIGHT = 1;
VUHDO_LT_POS_LEFT = 2;
VUHDO_LT_POS_ABOVE = 3;
VUHDO_LT_POS_BELOW = 4;


VUHDO_HEALING_HOTS = {
-- Priest
	[VUHDO_SPELL_ID.RENEW] = true,
	[VUHDO_SPELL_ID.POWERWORD_SHIELD] = true,
	[VUHDO_SPELL_ID.PRAYER_OF_MENDING] = true,
	[VUHDO_SPELL_ID.ECHO_OF_LIGHT] = true,
	[VUHDO_SPELL_ID.ATONEMENT] = true,
	[VUHDO_SPELL_ID.DIVINE_AEGIS] = true,
	[VUHDO_SPELL_ID.LUMINOUS_BARRIER] = true,
	[VUHDO_SPELL_ID.PREMONITION_OF_SOLACE] = true,
-- Druid
	[VUHDO_SPELL_ID.REJUVENATION] = true,
	[VUHDO_SPELL_ID.REGROWTH] = true,
	[VUHDO_SPELL_ID.LIFEBLOOM] = true,
	[VUHDO_SPELL_ID.WILD_GROWTH] = true,
	[VUHDO_SPELL_ID.CENARION_WARD] = true,
	[VUHDO_SPELL_ID.GERMINATION] = true,
	[VUHDO_SPELL_ID.SPRING_BLOSSOMS] = true,
	[VUHDO_SPELL_ID.ADAPTIVE_SWARM] = true,
	[VUHDO_SPELL_ID.EFFLORESCENCE] = true,
	[VUHDO_SPELL_ID.GROVE_TENDING] = true,
	[VUHDO_SPELL_ID.SYMBIOTIC_BLOOMS] = true,
	[VUHDO_SPELL_ID.MINOR_CENARION_WARD] = true,
-- Shaman
	[VUHDO_SPELL_ID.RIPTIDE] = true,
	[VUHDO_SPELL_ID.GIFT_OF_THE_NAARU] = true,
	[VUHDO_SPELL_ID.BUFF_EARTH_SHIELD] = true,
	[VUHDO_SPELL_ID.EARTHLIVING_WEAPON] = true,
	[VUHDO_SPELL_ID.HYDROBUBBLE] = true,
-- Paladin
	[VUHDO_SPELL_ID.BUFF_BEACON_OF_FAITH] = true,
	[VUHDO_SPELL_ID.BUFF_BEACON_OF_LIGHT] = true,
	[VUHDO_SPELL_ID.BUFF_BEACON_OF_VIRTUE] = true,
	[VUHDO_SPELL_ID.ETERNAL_FLAME] = true,
	[VUHDO_SPELL_ID.GLIMMER_OF_LIGHT] = true,
	[VUHDO_SPELL_ID.OVERFLOWING_LIGHT] = true,
	[VUHDO_SPELL_ID.DAWNLIGHT] = true,
	[VUHDO_SPELL_ID.TYRS_DELIVERANCE] = true,
-- Hunter
	[VUHDO_SPELL_ID.MEND_PET] = true,
-- Monk
	[VUHDO_SPELL_ID.SOOTHING_MIST] = true,
	[VUHDO_SPELL_ID.ENVELOPING_MIST] = true,
	[VUHDO_SPELL_ID.RENEWING_MIST] = true,
	[VUHDO_SPELL_ID.ZEN_SPHERE] = true,
	[VUHDO_SPELL_ID.ENVELOPING_BREATH] = true,
	[VUHDO_SPELL_ID.CHI_COCOON] = true,
	[VUHDO_SPELL_ID.ASPECT_OF_HARMONY] = true,
	[VUHDO_SPELL_ID.PURIFIED_SPIRIT] = true,
-- Evoker
	[VUHDO_SPELL_ID.DREAM_BREATH] = true,
	[VUHDO_SPELL_ID.DREAM_FLIGHT] = true,
	[VUHDO_SPELL_ID.ECHO] = true,
	[VUHDO_SPELL_ID.LIFEBIND] = true,
	[VUHDO_SPELL_ID.REVERSION] = true,
	[VUHDO_SPELL_ID.REWIND] = true,
	[VUHDO_SPELL_ID.TIME_DILATION] = true,
	[VUHDO_SPELL_ID.TEMPORAL_ANOMALY] = true,
	[VUHDO_SPELL_ID.ENKINDLE] = true,
	[VUHDO_SPELL_ID.SPIRITBLOOM] = true,
};



--
VUHDO_EXCLUSIVE_HOTS = {
	[VUHDO_SPELL_ID.PRAYER_OF_MENDING] = true,
	[VUHDO_SPELL_ID.POWERWORD_SHIELD] = true,
	[VUHDO_SPELL_ID.BUFF_EARTH_SHIELD] = true,
	[VUHDO_SPELL_ID.GUARDIAN_SPIRIT] = true,
	[VUHDO_SPELL_ID.PAIN_SUPPRESSION] = true,
	[VUHDO_SPELL_ID.LUMINOUS_BARRIER] = true,
};



VUHDO_BUFF_REMOVAL_SPELLS = { };



VUHDO_NUM_MOUSE_BUTTONS = 16;
VUHDO_NUM_KEYBOARD_KEYS = 16;

VUHDO_MODIFIER_KEYS = {
	[""] = "",
	["alt"] = "ALT-",
	["ctrl"] = "CTRL-",
	["shift"] = "SHIFT-",
	["altctrl"] = "ALT-CTRL-",
	["altshift"] = "ALT-SHIFT-",
	["ctrlshift"] = "CTRL-SHIFT-",
	["altctrlshift"] = "ALT-CTRL-SHIFT-",
};


VUHDO_KEYS_MODIFIER = {
	[""] = "",
	["ALT-"] = "alt",
	["CTRL-"] = "ctrl",
	["SHIFT-"] = "shift",
	["ALT-CTRL-"] = "altctrl",
	["ALT-SHIFT-"] = "altshift",
	["CTRL-SHIFT-"] = "ctrlshift",
	["ALT-CTRL-SHIFT-"] = "altctrlshift",
};


VUHDO_MOUSE_BUTTONS = {
	VUHDO_I18N_TT_LEFT,
	VUHDO_I18N_TT_RIGHT,
	VUHDO_I18N_TT_MIDDLE,
	VUHDO_I18N_TT_BTN_4,
	VUHDO_I18N_TT_BTN_5,
	VUHDO_I18N_TT_WHEEL_UP,
	VUHDO_I18N_TT_WHEEL_DOWN,
};



VUHDO_WHEEL_BINDINGS = {
	"MOUSEWHEELUP",
	"MOUSEWHEELDOWN",
	"ALT-MOUSEWHEELUP",
	"ALT-MOUSEWHEELDOWN",
	"CTRL-MOUSEWHEELUP",
	"CTRL-MOUSEWHEELDOWN",
	"SHIFT-MOUSEWHEELUP",
	"SHIFT-MOUSEWHEELDOWN",
	"ALT-CTRL-MOUSEWHEELUP",
	"ALT-CTRL-MOUSEWHEELDOWN",
	"ALT-SHIFT-MOUSEWHEELUP",
	"ALT-SHIFT-MOUSEWHEELDOWN",
	"CTRL-SHIFT-MOUSEWHEELUP",
	"CTRL-SHIFT-MOUSEWHEELDOWN",
	"ALT-CTRL-SHIFT-MOUSEWHEELUP",
	"ALT-CTRL-SHIFT-MOUSEWHEELDOWN",
};


VUHDO_WHEEL_INDEX_BINDING = {
	"1",
	"2",
	"alt1",
	"alt2",
	"ctrl1",
	"ctrl2",
	"shift1",
	"shift2",
	"altctrl1",
	"altctrl2",
	"altshift1",
	"altshift2",
	"ctrlshift1",
	"ctrlshift2",
	"altctrlshift1",
	"altctrlshift2",
}


VUHDO_ASSIGNMENT_SPELL = 1;
VUHDO_ASSIGNMENT_MACRO_TEXT = 2;
VUHDO_ASSIGNMENT_MACRO_ID = 3;


VUHDO_PET_2_OWNER = {
	["pet"] = "player",

	["partypet1"] = "party1",
	["partypet2"] = "party2",
	["partypet3"] = "party3",
	["partypet4"] = "party4",
	["partypet5"] = "party5",

	["raidpet1"] = "raid1",
	["raidpet2"] = "raid2",
	["raidpet3"] = "raid3",
	["raidpet4"] = "raid4",
	["raidpet5"] = "raid5",
	["raidpet6"] = "raid6",
	["raidpet7"] = "raid7",
	["raidpet8"] = "raid8",
	["raidpet9"] = "raid9",
	["raidpet10"] = "raid10",

	["raidpet11"] = "raid11",
	["raidpet12"] = "raid12",
	["raidpet13"] = "raid13",
	["raidpet14"] = "raid14",
	["raidpet15"] = "raid15",
	["raidpet16"] = "raid16",
	["raidpet17"] = "raid17",
	["raidpet18"] = "raid18",
	["raidpet19"] = "raid19",
	["raidpet20"] = "raid20",

	["raidpet21"] = "raid21",
	["raidpet22"] = "raid22",
	["raidpet23"] = "raid23",
	["raidpet24"] = "raid24",
	["raidpet25"] = "raid25",
	["raidpet26"] = "raid26",
	["raidpet27"] = "raid27",
	["raidpet28"] = "raid28",
	["raidpet29"] = "raid29",
	["raidpet30"] = "raid30",

	["raidpet31"] = "raid31",
	["raidpet32"] = "raid32",
	["raidpet33"] = "raid33",
	["raidpet34"] = "raid34",
	["raidpet35"] = "raid35",
	["raidpet36"] = "raid36",
	["raidpet37"] = "raid37",
	["raidpet38"] = "raid38",
	["raidpet39"] = "raid39",
	["raidpet40"] = "raid40",
};



VUHDO_OWNER_2_PET = {
	["player"] = "pet",

	["party1"] = "partypet1",
	["party2"] = "partypet2",
	["party3"] = "partypet3",
	["party4"] = "partypet4",
	["party5"] = "partypet5",

	["raid1"] = "raidpet1",
	["raid2"] = "raidpet2",
	["raid3"] = "raidpet3",
	["raid4"] = "raidpet4",
	["raid5"] = "raidpet5",
	["raid6"] = "raidpet6",
	["raid7"] = "raidpet7",
	["raid8"] = "raidpet8",
	["raid9"] = "raidpet9",
	["raid10"] = "raidpet10",

	["raid11"] = "raidpet11",
	["raid12"] = "raidpet12",
	["raid13"] = "raidpet13",
	["raid14"] = "raidpet14",
	["raid15"] = "raidpet15",
	["raid16"] = "raidpet16",
	["raid17"] = "raidpet17",
	["raid18"] = "raidpet18",
	["raid19"] = "raidpet19",
	["raid20"] = "raidpet20",

	["raid21"] = "raidpet21",
	["raid22"] = "raidpet22",
	["raid23"] = "raidpet23",
	["raid24"] = "raidpet24",
	["raid25"] = "raidpet25",
	["raid26"] = "raidpet26",
	["raid27"] = "raidpet27",
	["raid28"] = "raidpet28",
	["raid29"] = "raidpet29",
	["raid30"] = "raidpet30",

	["raid31"] = "raidpet31",
	["raid32"] = "raidpet32",
	["raid33"] = "raidpet33",
	["raid34"] = "raidpet34",
	["raid35"] = "raidpet35",
	["raid36"] = "raidpet36",
	["raid37"] = "raidpet37",
	["raid38"] = "raidpet38",
	["raid39"] = "raidpet39",
	["raid40"] = "raidpet40",
};

VUHDO_CUSTOM_GLOW_CUDE_FRAME_KEY = "_CuDe_Frame";
VUHDO_CUSTOM_GLOW_CUDE_ICON_KEY = "_CuDe_Icon";
VUHDO_CUSTOM_GLOW_SWIFTMEND_FRAME_KEY = "_SwMe_Frame";
VUHDO_CUSTOM_GLOW_SWIFTMEND_ICON_KEY = "_SwMe_Icon";
VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY = "_AuGr_Frame";
VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY = "_AuGr_Active";
VUHDO_DEFAULT_AURA_GLOW_STYLE = "vuhdopixel";

VUHDO_BOUQUET_CUSTOM_TYPE_PERCENT = 1;
VUHDO_BOUQUET_CUSTOM_TYPE_PLAYERS = 2;
VUHDO_BOUQUET_CUSTOM_TYPE_STATUSBAR = 3;
VUHDO_BOUQUET_CUSTOM_TYPE_BRIGHTNESS = 4;
VUHDO_BOUQUET_CUSTOM_TYPE_HEALTH = 5;
VUHDO_BOUQUET_CUSTOM_TYPE_HOLY_POWER = 6;
VUHDO_BOUQUET_CUSTOM_TYPE_SECONDS = 7;
VUHDO_BOUQUET_CUSTOM_TYPE_STACKS = 8;
VUHDO_BOUQUET_CUSTOM_TYPE_CUSTOM_FLAG = 9;
VUHDO_BOUQUET_CUSTOM_TYPE_SPELL_TRACE = 10;
VUHDO_BOUQUET_CUSTOM_TYPE_AURA_GROUP = 11;

VUHDO_BOUQUET_VALUE_TYPE_NONE = 0;
VUHDO_BOUQUET_VALUE_TYPE_AURA = 1;
VUHDO_BOUQUET_VALUE_TYPE_STATUS = 2;
VUHDO_BOUQUET_VALUE_TYPE_FLAG = 3;

VUHDO_BOUQUET_STATUS_TYPE_HEALTH = 1;
VUHDO_BOUQUET_STATUS_TYPE_MANA = 2;
VUHDO_BOUQUET_STATUS_TYPE_POWER = 3;
VUHDO_BOUQUET_STATUS_TYPE_ALTPOWER = 4;
VUHDO_BOUQUET_STATUS_TYPE_INCOMING = 5;
VUHDO_BOUQUET_STATUS_TYPE_ABSORB = 6;
VUHDO_BOUQUET_STATUS_TYPE_HEAL_ABSORB = 7;
VUHDO_BOUQUET_STATUS_TYPE_THREAT = 8;
VUHDO_BOUQUET_STATUS_TYPE_FULL = 9;

VUHDO_SECRET_TYPE_NONE = 0;
VUHDO_SECRET_TYPE_BOOLEAN = 1;
VUHDO_MAX_ALPHA_CHAIN_STEPS = 3;
VUHDO_SECRET_TYPE_HEALTH_PERCENT = 2;
VUHDO_SECRET_TYPE_POWER_PERCENT = 3;
VUHDO_SECRET_TYPE_DISPEL = 4;
VUHDO_SECRET_TYPE_DURATION = 5;
VUHDO_SECRET_TYPE_SPRITE_CELL = 6;
VUHDO_SECRET_TYPE_VALUES = 7;

VUHDO_BOUQUET_LAYER_TYPE_NONSECRET = 1;
VUHDO_BOUQUET_LAYER_TYPE_CURVE = 2;
VUHDO_BOUQUET_LAYER_TYPE_DISPEL = 3;
VUHDO_BOUQUET_LAYER_TYPE_AURA = 4;
VUHDO_BOUQUET_LAYER_TYPE_SPRITECELL = 5;
VUHDO_BOUQUET_LAYER_TYPE_BOOLEAN = 6;

VUHDO_UNIT_AURA_SOURCE_MINE = 1;
VUHDO_UNIT_AURA_SOURCE_OTHERS = 2;
VUHDO_UNIT_AURA_SOURCE_BOTH = 3;

VUHDO_FORCE_SECRETS_ENABLED = false;
VUHDO_SECRETS_ENABLED = VUHDO_FORCE_SECRETS_ENABLED or (issecretvalue ~= nil);

VUHDO_FORCE_AURA_DATA_RESTRICTED = false;
VUHDO_AURA_DATA_RESTRICTED = false;

VUHDO_FORCE_AURA_MODE = nil;

local tAuraModeTemplateInfo = C_XMLUtil.GetTemplateInfo("CustomAuraContainerTemplate");
VUHDO_AURA_MODE_CAPABILITY = tAuraModeTemplateInfo ~= nil;
VUHDO_AURA_MODE_CONTAINERS = false;

local tCharacterNameSeparatorConsts = Constants and Constants.CharacterNameSeparatorConsts;

VUHDO_SURNAME_SEPARATOR = tCharacterNameSeparatorConsts and tCharacterNameSeparatorConsts["CHARACTERNAME_SURNAME_SEPARATOR"];
VUHDO_SURNAME_CAPABILITY = VUHDO_SURNAME_SEPARATOR ~= nil;
VUHDO_NAME_SUFFIX_SEPARATOR = VUHDO_SURNAME_SEPARATOR or "-";

VUHDO_AURA_ANCHOR_PLAYER_ICONS = 999;

VUHDO_AURA_GROUP_TYPE_FILTER = 1;
VUHDO_AURA_GROUP_TYPE_LIST = 2;

VUHDO_AURA_MAX_MATCH_ANY = 5;

VUHDO_AURA_IDENTITY_GATE_HELPFUL = 1;
VUHDO_AURA_IDENTITY_GATE_HARMFUL = 2;

VUHDO_AURA_VOLATILE_PASS_KEEP = 1;
VUHDO_AURA_VOLATILE_PASS_DEFER = 2;
VUHDO_AURA_VOLATILE_PASS_REBUILD = 3;

VUHDO_AURA_LIST_ENTRY_SPELL = 1;
VUHDO_AURA_LIST_ENTRY_BOUQUET = 2;
VUHDO_AURA_LIST_ENTRY_EMPTY = 3;

VUHDO_AURA_LIST_LAYOUT_INDEX_STRIDE = 100;
VUHDO_MIXED_BOUQUET_FRAME_LEVEL_STRIDE = 3;

VUHDO_AURA_MATCH_ANY_ENTRY_BOOLEAN = 1;
VUHDO_AURA_MATCH_ANY_ENTRY_FILTER_TOKEN = 2;

VUHDO_BOUQUET_RESTRICTED_NON_AURA = 1;
VUHDO_BOUQUET_RESTRICTED_AURA_CONTAINER = 2;
VUHDO_BOUQUET_RESTRICTED_UNSUPPORTED = 3;
VUHDO_BOUQUET_RESTRICTED_MIXED = 4;

VUHDO_SPELL_DURATION_MODE_THRESHOLD = 0;
VUHDO_SPELL_DURATION_MODE_FULL = 1;
VUHDO_SPELL_DURATION_MODE_ALIVE = 2;

VUHDO_STATUSBAR_LEFT_TO_RIGHT = 1;
VUHDO_STATUSBAR_RIGHT_TO_LEFT = 2;
VUHDO_STATUSBAR_BOTTOM_TO_TOP = 3;
VUHDO_STATUSBAR_TOP_TO_BOTTOM = 4;

VUHDO_AURA_CONDITION_BOOLEAN_KEYS = {
	"isBossOrRoleAura",
	"isBossAura",
	"isRoleAura",
	"isPriorityAura",
	"isStealable",
	"isFromPlayerOrPlayerPet",
	"canApplyAura",
	"nameplateShowAll",
	"nameplateShowPersonal",
};

VUHDO_AURA_CONDITION_FILTER_TOKEN_KEYS = {
	"PLAYER",
	"RAID",
	"RAID_IN_COMBAT",
	"CANCELABLE",
	"INCLUDE_NAME_PLATE_ONLY",
	"MAW",
	"EXTERNAL_DEFENSIVE",
	"CROWD_CONTROL",
	"RAID_PLAYER_DISPELLABLE",
	"BIG_DEFENSIVE",
	"IMPORTANT",
	"DISPELLABLE",
};

VUHDO_AURA_MATCH_ANY_BOOLEAN_KEYS = {
	"isBossOrRoleAura",
	"isBossAura",
	"isRoleAura",
	"isPriorityAura",
	"isStealable",
};

VUHDO_AURA_MATCH_ANY_FILTER_TOKENS = {
	["DISPELLABLE"] = true,
	["RAID_PLAYER_DISPELLABLE"] = true,
	["IMPORTANT"] = true,
	["RAID"] = true,
	["CROWD_CONTROL"] = true,
	["CANCELABLE"] = true,
	["PLAYER"] = true,
	["RAID_IN_COMBAT"] = true,
	["EXTERNAL_DEFENSIVE"] = true,
	["BIG_DEFENSIVE"] = true,
};

VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER = {
	"DISPELLABLE",
	"RAID_PLAYER_DISPELLABLE",
	"IMPORTANT",
	"RAID",
	"CROWD_CONTROL",
	"CANCELABLE",
	"PLAYER",
	"RAID_IN_COMBAT",
	"EXTERNAL_DEFENSIVE",
	"BIG_DEFENSIVE",
};

VUHDO_AURA_CONDITION_BUCKET_MATCH_ALL = "matchAll";
VUHDO_AURA_CONDITION_BUCKET_MATCH_ANY = "matchAny";
VUHDO_AURA_CONDITION_BUCKET_NEVER_SHOW = "neverShow";

VUHDO_AURA_CONDITION_STORAGE_BOOLEAN = "boolean";
VUHDO_AURA_CONDITION_STORAGE_FILTER_TOKEN = "filterToken";

VUHDO_AURA_GROUP_CONDITIONS_VERSION = 1;

VUHDO_AURA_CONDITION_CAPABILITIES = {
	["isBossOrRoleAura"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["isBossAura"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["isRoleAura"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["isPriorityAura"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["isStealable"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["isFromPlayerOrPlayerPet"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["canApplyAura"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["nameplateShowAll"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["nameplateShowPersonal"] = {
		["storage"] = "boolean",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["PLAYER"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["RAID"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["RAID_IN_COMBAT"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["CANCELABLE"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["INCLUDE_NAME_PLATE_ONLY"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
	},
	["MAW"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
	},
	["EXTERNAL_DEFENSIVE"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["CROWD_CONTROL"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["RAID_PLAYER_DISPELLABLE"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["BIG_DEFENSIVE"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["IMPORTANT"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
	["DISPELLABLE"] = {
		["storage"] = "filterToken",
		["matchAll"] = true,
		["matchAny"] = true,
		["neverShow"] = true,
	},
};

VUHDO_AURA_DURATION_COMBO_NONE = -1;
VUHDO_AURA_DURATION_COMBO_HAS = 0;
VUHDO_AURA_DURATION_COMBO_VALUES = {
	VUHDO_AURA_DURATION_COMBO_NONE,
	VUHDO_AURA_DURATION_COMBO_HAS,
	5,
	10,
	15,
	20,
	30,
	60,
	120,
	300,
	600,
	1800,
	3600,
};