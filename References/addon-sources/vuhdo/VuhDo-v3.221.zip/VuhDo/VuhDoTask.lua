local _;

local GetTime = GetTime;
local pairs = pairs;
local string = string;
local xpcall = xpcall;
local unpack = unpack;
local debugprofilestop = debugprofilestop;
local MeasureCall = C_AddOnProfiler and C_AddOnProfiler.MeasureCall;
local format = string.format;
local tinsert = table.insert;
local tcreate = table.create or VUHDO_tableCreate;
local tremove = table.remove;
local twipe = table.wipe;
local max = math.max;
local min = math.min;
local floor = math.floor;
local abs = math.abs;
local InCombatLockdown = InCombatLockdown;

VUHDO_DEFERRED_TASK_PRIORITY_LOW = 1;
VUHDO_DEFERRED_TASK_PRIORITY_NORMAL = 2;
VUHDO_DEFERRED_TASK_PRIORITY_HIGH = 3;
VUHDO_DEFERRED_TASK_PRIORITY_CRITICAL = 4;

VUHDO_DEFER_UPDATE_HEALTH = 1;
VUHDO_DEFER_UPDATE_HEALTH_BARS_FOR = 2;
VUHDO_DEFER_SET_HEALTH = 3;
VUHDO_DEFER_UPDATE_SHIELD_BAR = 4;
VUHDO_DEFER_UPDATE_HEAL_ABSORB_BAR = 5;
VUHDO_DEFER_UPDATE_MANA_BARS = 6;
VUHDO_DEFER_UPDATE_UNIT_HOTS = 7;
VUHDO_DEFER_INIT_ALL_EVENT_BOUQUETS = 8;
VUHDO_DEFER_UPDATE_BOUQUETS_FOR_EVENT = 9;
VUHDO_DEFER_UPDATE_UNIT_CYCLIC_BOUQUET = 10;
VUHDO_DEFER_UPDATE_UNIT_DEBUFF_ICONS = 11;
VUHDO_DEFER_UPDATE_UNIT_AGGRO = 12;
VUHDO_DEFER_UPDATE_UNIT_RANGE = 13;
VUHDO_DEFER_UPDATE_ALL_CLUSTERS = 14;
VUHDO_DEFER_UPDATE_CLUSTER_HIGHLIGHTS = 15;
VUHDO_DEFER_AOE_UPDATE_ALL = 16;
VUHDO_DEFER_UPDATE_SPELL_TRACE = 17;
VUHDO_DEFER_UPDATE_ALL_RAID_BARS = 18;
VUHDO_DEFER_UPDATE_PANEL_BUTTONS = 19;
VUHDO_DEFER_HANDLE_SCALE_CHANGE = 20;
VUHDO_DEFER_INIT_HEAL_BUTTON = 21;
VUHDO_DEFER_POSITION_HEAL_BUTTON = 22;
VUHDO_DEFER_REDRAW_PANEL_COMPLETE = 23;
VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE = 24;
VUHDO_DEFER_POSITION_CONFIG_PANELS = 25;
VUHDO_DEFER_REDRAW_PANEL = 26;
VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE = 27;
VUHDO_DEFER_PREWARM_AURA_POOLS = 28;
VUHDO_DEFER_UPDATE_AURA_DISPLAYS_FOR_UNIT = 29;
VUHDO_DEFER_REFRESH_PRIVATE_AURAS = 30;
VUHDO_DEFER_UPDATE_UNIT_VISIBILITY_CHARM_RANGE = 33;
VUHDO_DEFER_REFRESH_PANEL = 34;
VUHDO_DEFER_REFRESH_UI_COMPLETE = 35;
VUHDO_DEFER_REFRESH_PANEL_COMPLETE = 36;
VUHDO_DEFER_INIT_AURA_CONTAINERS_FOR_BUTTON = 37;
VUHDO_DEFER_SYNC_AURA_CONTAINERS_FOR_UNIT = 38;
VUHDO_DEFER_SYNC_OVERLAYS_FOR_UNIT = 39;
VUHDO_DEFER_DEGRADE_AURA_CACHE_FOR_UNIT = 40;
VUHDO_DEFER_REFRESH_UNIT_AURAS = 41;
VUHDO_DEFER_ACQUIRE_OVERLAY_CONTAINER = 42;
VUHDO_DEFER_FLUSH_PENDING_OVERLAY_REBUILD = 43;
VUHDO_DEFER_VOLATILE_PASS_FOR_BUTTON = 44;
VUHDO_DEFER_SYNC_SWIFTMEND_OVERLAY_GATES = 45;

local VUHDO_DEFERRED_TASK_TYPES = {
	VUHDO_DEFER_UPDATE_HEALTH,
	VUHDO_DEFER_UPDATE_HEALTH_BARS_FOR,
	VUHDO_DEFER_SET_HEALTH,
	VUHDO_DEFER_UPDATE_SHIELD_BAR,
	VUHDO_DEFER_UPDATE_HEAL_ABSORB_BAR,
	VUHDO_DEFER_UPDATE_MANA_BARS,
	VUHDO_DEFER_UPDATE_UNIT_HOTS,
	VUHDO_DEFER_INIT_ALL_EVENT_BOUQUETS,
	VUHDO_DEFER_UPDATE_BOUQUETS_FOR_EVENT,
	VUHDO_DEFER_UPDATE_UNIT_CYCLIC_BOUQUET,
	VUHDO_DEFER_UPDATE_UNIT_DEBUFF_ICONS,
	VUHDO_DEFER_UPDATE_UNIT_AGGRO,
	VUHDO_DEFER_UPDATE_UNIT_RANGE,
	VUHDO_DEFER_UPDATE_ALL_CLUSTERS,
	VUHDO_DEFER_UPDATE_CLUSTER_HIGHLIGHTS,
	VUHDO_DEFER_AOE_UPDATE_ALL,
	VUHDO_DEFER_UPDATE_SPELL_TRACE,
	VUHDO_DEFER_UPDATE_ALL_RAID_BARS,
	VUHDO_DEFER_UPDATE_PANEL_BUTTONS,
	VUHDO_DEFER_HANDLE_SCALE_CHANGE,
	VUHDO_DEFER_INIT_HEAL_BUTTON,
	VUHDO_DEFER_POSITION_HEAL_BUTTON,
	VUHDO_DEFER_REDRAW_PANEL_COMPLETE,
	VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE,
	VUHDO_DEFER_POSITION_CONFIG_PANELS,
	VUHDO_DEFER_REDRAW_PANEL,
	VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE,
	VUHDO_DEFER_PREWARM_AURA_POOLS,
	VUHDO_DEFER_UPDATE_AURA_DISPLAYS_FOR_UNIT,
	VUHDO_DEFER_REFRESH_PRIVATE_AURAS,
	VUHDO_DEFER_UPDATE_UNIT_VISIBILITY_CHARM_RANGE,
	VUHDO_DEFER_REFRESH_PANEL,
	VUHDO_DEFER_REFRESH_UI_COMPLETE,
	VUHDO_DEFER_REFRESH_PANEL_COMPLETE,
	VUHDO_DEFER_INIT_AURA_CONTAINERS_FOR_BUTTON,
	VUHDO_DEFER_SYNC_AURA_CONTAINERS_FOR_UNIT,
	VUHDO_DEFER_SYNC_OVERLAYS_FOR_UNIT,
	VUHDO_DEFER_DEGRADE_AURA_CACHE_FOR_UNIT,
	VUHDO_DEFER_REFRESH_UNIT_AURAS,
	VUHDO_DEFER_ACQUIRE_OVERLAY_CONTAINER,
	VUHDO_DEFER_FLUSH_PENDING_OVERLAY_REBUILD,
	VUHDO_DEFER_VOLATILE_PASS_FOR_BUTTON,
	VUHDO_DEFER_SYNC_SWIFTMEND_OVERLAY_GATES,
};

local VUHDO_COMBAT_UNSAFE_TASKS = {
	[VUHDO_DEFER_INIT_HEAL_BUTTON] = true,
	[VUHDO_DEFER_POSITION_HEAL_BUTTON] = true,
	[VUHDO_DEFER_REDRAW_PANEL_COMPLETE] = true,
	[VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE] = true,
	[VUHDO_DEFER_POSITION_CONFIG_PANELS] = true,
	[VUHDO_DEFER_REDRAW_PANEL] = true,
	[VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE] = true,
	[VUHDO_DEFER_UPDATE_PANEL_BUTTONS] = true,
	[VUHDO_DEFER_UPDATE_ALL_RAID_BARS] = true,
	[VUHDO_DEFER_PREWARM_AURA_POOLS] = true,
	[VUHDO_DEFER_REFRESH_PRIVATE_AURAS] = true,
	[VUHDO_DEFER_REFRESH_PANEL] = true,
	[VUHDO_DEFER_REFRESH_UI_COMPLETE] = true,
	[VUHDO_DEFER_REFRESH_PANEL_COMPLETE] = true,
	[VUHDO_DEFER_INIT_AURA_CONTAINERS_FOR_BUTTON] = true,
};

local VUHDO_COMBAT_HELD_TASKS = {
	[VUHDO_DEFER_REFRESH_PRIVATE_AURAS] = true,
	[VUHDO_DEFER_ACQUIRE_OVERLAY_CONTAINER] = true,
	[VUHDO_DEFER_FLUSH_PENDING_OVERLAY_REBUILD] = true,
};

local sDeferredTaskDelegates;
local sNextTaskEnqueueOrder = 0;
local sCombatHeldTasks = { };
local sCombatHeldTaskMap = { };
local sSortedCostHistory = { };
local sSkippedHighPriorityTasks = { };
local sIsStarvationTaskDue = false;

local VUHDO_DEFERRED_TASK_PROFILING_ENABLED = false;

local VUHDO_DEFERRED_TASK_CONFIG = {
	["TARGET_EXEC_TIME_US"] = 50000,
	["MAX_EXEC_TIME_US"] = 75000,
	["MIN_TASKS_PER_FRAME"] = 1,
	["INITIAL_TASKS_PER_FRAME"] = 250,
	["MAX_TASKS_PER_FRAME"] = 500,
	["ADJUST_INTERVAL_SECS"] = 1.5,
	["IDLE_TASK_INC_THRESHOLD_US"] = 50,
	["CHUNK_SNAPSHOT_LIMIT"] = 5,
};

local VUHDO_TASK_TYPE_DEFAULT_COSTS = {
	[1] = 600,
	[2] = 600,
	[3] = 177,
	[4] = 170,
	[5] = 36,
	[6] = 230,
	[7] = 2,
	[8] = 18000,
	[9] = 320,
	[10] = 16,
	[11] = 2,
	[12] = 8,
	[13] = 37,
	[17] = 2,
	[18] = 5000,
	[19] = 5000,
	[21] = 50000,
	[22] = 5000,
	[23] = 22000,
	[24] = 4400,
	[25] = 205,
	[26] = 900,
	[27] = 32000,
	[29] = 350,
	[30] = 200,
	[33] = 10,
	[34] = 350,
	[35] = 57000,
	[36] = 33000,
	[37] = 50000,
	[38] = 110,
	[39] = 1100,
	[40] = 35,
	[41] = 200,
	[42] = 16000,
	[43] = 5000,
};

local VUHDO_DEFERRED_TASK_STATE = {
	["isInit"] = false,
	["maxTasksPerFrame"] = VUHDO_DEFERRED_TASK_CONFIG["INITIAL_TASKS_PER_FRAME"],
	["currentFrameBudgetUs"] = 0,
	["lastAdjustTime"] = 0,
	["invocationCountByType"] = nil,
	["avgCostUsByType"] = nil,
	["peakCostUsByType"] = nil,
	["costHistoryByType"] = nil,
	["individualCostsByType"] = nil,
	["queueTimeUsByType"] = nil,
	["budgetStatsByType"] = nil,

	["metrics"] = {
		["sessionStartTime"] = 0,
		["totalTasksEnqueued"] = 0,
		["totalTasksDeduped"] = 0,
		["totalTasksProcessedSession"] = 0,
		["totalProcessingTimeUsSession"] = 0,
		["chunksExecutedSuccessfully"] = 0,
		["minQueueLength"] = 999999,
		["maxQueueLength"] = 0,
		["sumQueueLength"] = 0,
		["queueLengthSamples"] = 0,
		["tasksInChunkTailMeanTracker"] = nil,
		["chunkTimeTailMeanTracker"] = nil,
		["hardStopsHit"] = 0,
		["unsafeTasksProcessed"] = 0,
		["tasksEnqueuedByType"] = { },
		["tasksProcessedByTypeSession"] = { },
		["totalTimeUsByTypeSession"] = { },
		["queueTimeUsByTypeSession"] = { },
		["minTaskTimeUsByTypeSession"] = { },
		["maxTaskTimeUsByTypeSession"] = { },
		["maxTaskTimeUsContextByTypeSession"] = { },
	},
};

local VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS = {
	-- {
	-- {
	--	["totalChunkTimeUs" = <total time>,
	--	["numTasksInChunk"] = <total tasks>,
	--	["tasks"] = {
	--		{
	--			["type"] = <task type>,
	--			["unit"] = <unit>,
	--			["mode"] = <mode>,
	--			["durationUs"] = <microsecond duration>,
	--		},
	--		["timestamp"] = <task timestamp>,
	--	},
	-- },
};

local VUHDO_DEFERRED_TASK_POOL;
local VUHDO_DEFERRED_TASK_POOL_MAX_SIZE = 1500;

local VUHDO_TASK_PRIORITY_QUEUE = { };
local VUHDO_TASK_QUEUE_MAP = { };

local VUHDO_processPendingAuraContainerBuilds;
local VUHDO_processPendingNativeAuraSounds;

local VUHDO_argToString = VUHDO_argToString;



do
	--
	local tEmptyTailMeans;
	function VUHDO_getEmptyTailMeans()

		if not tEmptyTailMeans then
			tEmptyTailMeans = { };

			for _, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
				tEmptyTailMeans[tTailMeanKey] = 0;
			end
		end

		return tEmptyTailMeans;

	end



	--
	local tTailMeanLabels;
	local tTailMeanFormat;
	function VUHDO_getTailMeanFormats()

		if not tTailMeanLabels then
			tTailMeanLabels = "";
			tTailMeanFormat = "";

			for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
				if tIndex > 1 then
					tTailMeanLabels = tTailMeanLabels .. ", ";
					tTailMeanFormat = tTailMeanFormat .. ", ";
				end

				tTailMeanLabels = tTailMeanLabels .. tTailMeanKey;
				tTailMeanFormat = tTailMeanFormat .. tTailMeanKey .. ": %s";
			end
		end

		return tTailMeanLabels, tTailMeanFormat;

	end
end



--
function VUHDO_getDeferredTaskConfig()

	return VUHDO_DEFERRED_TASK_CONFIG;

end



--
function VUHDO_getDeferredTaskState()

	return VUHDO_DEFERRED_TASK_STATE;

end



--
function VUHDO_deferUpdateHealth(aUnit, aMode, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_HEALTH, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_CRITICAL, aUnit, aMode);

	return;

end



--
function VUHDO_deferUpdateBouquetsForEvent(aUnit, aMode, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_BOUQUETS_FOR_EVENT, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aUnit, aMode);

	return;

end



--
function VUHDO_deferUpdateShieldBar(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_SHIELD_BAR, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit, 1);

	return;

end



--
function VUHDO_deferUpdateHealAbsorbBar(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_HEAL_ABSORB_BAR, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit, 1);

	return;

end



--
function VUHDO_deferUpdateHealthBarsFor(aUnit, aMode, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_HEALTH_BARS_FOR, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit, aMode);

	return;

end



--
function VUHDO_deferUpdateAllClusters(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_ALL_CLUSTERS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL);

	return;

end



--
function VUHDO_deferAoeUpdateAll(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_AOE_UPDATE_ALL, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL);

	return;

end



--
function VUHDO_deferUpdateSpellTrace(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_SPELL_TRACE, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL);

	return;

end



--
function VUHDO_deferUpdateAllRaidBars(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_ALL_RAID_BARS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH);

	return;

end



--
function VUHDO_deferUpdatePanelButtons(aPanelNum, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_PANEL_BUTTONS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum);

	return;

end



--
function VUHDO_deferUpdateManaBars(aUnit, aMode, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_MANA_BARS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit, aMode);

	return;

end



--
function VUHDO_deferSetHealth(aUnit, aMode, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_SET_HEALTH, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_CRITICAL, aUnit, aMode);

	return;

end



--
function VUHDO_deferUpdateClusterHighlights(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_CLUSTER_HIGHLIGHTS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL);

	return;

end



--
function VUHDO_deferHandleScaleChange(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_HANDLE_SCALE_CHANGE, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH);

	return;

end



--
function VUHDO_deferPrewarmAuraPools(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_PREWARM_AURA_POOLS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_LOW);

	return;

end



--
function VUHDO_deferUpdateAuraDisplaysForUnit(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_UPDATE_AURA_DISPLAYS_FOR_UNIT, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit);

	return;

end



--
function VUHDO_deferInitAuraContainersForButton(aButton, aPanelNum, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_INIT_AURA_CONTAINERS_FOR_BUTTON, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aButton, aPanelNum);

	return;

end



--
function VUHDO_deferSyncAuraContainersForUnit(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_SYNC_AURA_CONTAINERS_FOR_UNIT, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aUnit);

	return;

end



--
function VUHDO_deferSyncOverlaysForUnit(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_SYNC_OVERLAYS_FOR_UNIT, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aUnit);

	return;

end



--
function VUHDO_deferSyncSwiftmendOverlayGates(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_SYNC_SWIFTMEND_OVERLAY_GATES, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_HIGH);

	return;

end



--
function VUHDO_deferDegradeAuraCacheForUnit(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_DEGRADE_AURA_CACHE_FOR_UNIT, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aUnit);

	return;

end



--
function VUHDO_deferRefreshUnitAuras(aUnit, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_REFRESH_UNIT_AURAS, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aUnit);

	return;

end



--
function VUHDO_deferAcquireOverlayContainer(aButton, anIndicatorKey, anEntryKey, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_ACQUIRE_OVERLAY_CONTAINER, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aButton, anIndicatorKey, anEntryKey);

	return;

end



--
function VUHDO_deferFlushPendingOverlayRebuild(aPriority)

	VUHDO_deferTask(VUHDO_DEFER_FLUSH_PENDING_OVERLAY_REBUILD, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL);

	return;

end



--
function VUHDO_deferVolatilePassForButton(aButton, aPriority)

	VUHDO_deferTask(VUHDO_DEFER_VOLATILE_PASS_FOR_BUTTON, aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, aButton);

	return;

end



--
local tNewTask;
local function VUHDO_createDeferredTaskDelegate()

	tNewTask = {
		["args"] = { },
		["delegate"] = nil,
		["type"] = nil,
		["priority"] = VUHDO_DEFERRED_TASK_PRIORITY_NORMAL,
		["enqueueOrder"] = 0,
		["heapIndex"] = 0,
		["taskKey"] = nil,
	};

	return tNewTask;

end



--
local tCleanupTask;
local function VUHDO_cleanupDeferredTaskDelegate(aTask)

	tCleanupTask = aTask;

	twipe(tCleanupTask["args"]);
	tCleanupTask["delegate"] = nil;
	tCleanupTask["type"] = nil;
	tCleanupTask["priority"] = VUHDO_DEFERRED_TASK_PRIORITY_NORMAL;
	tCleanupTask["enqueueOrder"] = 0;
	tCleanupTask["heapIndex"] = 0;
	tCleanupTask["taskKey"] = nil;

	return;

end



do
	--
	local sTaskDedupNilSentinel = { };
	local sTaskDedupRoots = { };
	local sTaskDedupNoArgLeaves = { };
	local tDedupNode;
	local tDedupArg;
	local function VUHDO_getTaskKey(aType, aArgs)

		if #aArgs == 0 then
			tDedupNode = sTaskDedupNoArgLeaves[aType];

			if not tDedupNode then
				tDedupNode = { ["isLeaf"] = true };
				sTaskDedupNoArgLeaves[aType] = tDedupNode;
			end

			return tDedupNode;
		end

		tDedupNode = sTaskDedupRoots[aType];

		if not tDedupNode then
			tDedupNode = { };
			sTaskDedupRoots[aType] = tDedupNode;
		end

		for tArgCnt = 1, #aArgs do
			tDedupArg = aArgs[tArgCnt];

			if tDedupArg == nil then
				tDedupArg = sTaskDedupNilSentinel;
			end

			if not tDedupNode[tDedupArg] then
				if tArgCnt == #aArgs then
					tDedupNode[tDedupArg] = { ["isLeaf"] = true };
				else
					tDedupNode[tDedupArg] = { };
				end
			end

			tDedupNode = tDedupNode[tDedupArg];
		end

		return tDedupNode;

	end



	--
	local function VUHDO_heapCompare(aTaskA, aTaskB)

		if aTaskA["priority"] ~= aTaskB["priority"] then
			return aTaskA["priority"] > aTaskB["priority"];
		end

		if aTaskA["enqueueOrder"] ~= aTaskB["enqueueOrder"] then
			return aTaskA["enqueueOrder"] < aTaskB["enqueueOrder"];
		end

		return aTaskA["heapIndex"] < aTaskB["heapIndex"];

	end



	--
	local tTaskA;
	local tTaskB;
	local function VUHDO_heapSwap(aHeap, anIndexA, anIndexB)

		tTaskA = aHeap[anIndexA];
		tTaskB = aHeap[anIndexB];

		aHeap[anIndexA] = tTaskB;
		aHeap[anIndexB] = tTaskA;

		tTaskA["heapIndex"] = anIndexB;
		tTaskB["heapIndex"] = anIndexA;

		return;

	end



	--
	local tChildIndex;
	local tParentIndex;
	local function VUHDO_heapSiftUp(aHeap, anIndex)

		tChildIndex = anIndex;
		tParentIndex = floor(tChildIndex / 2);

		while tChildIndex > 1 and VUHDO_heapCompare(aHeap[tChildIndex], aHeap[tParentIndex]) do
			VUHDO_heapSwap(aHeap, tChildIndex, tParentIndex);

			tChildIndex = tParentIndex;
			tParentIndex = floor(tChildIndex / 2);
		end

		return;

	end



	--
	local tParentIndex;
	local tLeftChildIndex;
	local tRightChildIndex;
	local tSwapIndex;
	local function VUHDO_heapSiftDown(aHeap, anIndex, aNumElements)

		tParentIndex = anIndex;

		while true do
			tLeftChildIndex = tParentIndex * 2;
			tRightChildIndex = tLeftChildIndex + 1;

			tSwapIndex = tParentIndex;

			if tLeftChildIndex <= aNumElements and VUHDO_heapCompare(aHeap[tLeftChildIndex], aHeap[tSwapIndex]) then
				tSwapIndex = tLeftChildIndex;
			end

			if tRightChildIndex <= aNumElements and VUHDO_heapCompare(aHeap[tRightChildIndex], aHeap[tSwapIndex]) then
				tSwapIndex = tRightChildIndex;
			end

			if tSwapIndex == tParentIndex then
				break;
			end

			VUHDO_heapSwap(aHeap, tParentIndex, tSwapIndex);

			tParentIndex = tSwapIndex;
		end

		return;

	end



	--
	local tNewIndex;
	function VUHDO_heapInsert(aHeap, aTask, aTaskMap)

		sNextTaskEnqueueOrder = sNextTaskEnqueueOrder + 1;
		aTask["enqueueOrder"] = sNextTaskEnqueueOrder;

		tNewIndex = #aHeap + 1;
		aHeap[tNewIndex] = aTask;
		aTask["heapIndex"] = tNewIndex;

		aTaskMap[aTask["taskKey"]] = aTask;

		VUHDO_heapSiftUp(aHeap, tNewIndex);

		return;

	end



	--
	local tHeapSize;
	local tTopTask;
	local tTopTaskKey;
	function VUHDO_heapExtractTop(aHeap, aTaskMap)

		tHeapSize = #aHeap;
		if tHeapSize == 0 then
			return nil;
		end

		tTopTask = aHeap[1];

		tTopTaskKey = tTopTask["taskKey"];
		aTaskMap[tTopTaskKey] = nil;

		if tHeapSize == 1 then
			aHeap[1] = nil;
		else
			aHeap[1] = aHeap[tHeapSize];
			aHeap[tHeapSize] = nil;
			aHeap[1]["heapIndex"] = 1;

			VUHDO_heapSiftDown(aHeap, 1, tHeapSize - 1);
		end

		tTopTask["heapIndex"] = 0;

		return tTopTask;

	end



	--
	local tOldPriority;
	local function VUHDO_heapUpdateTask(aHeap, aTask, aNewPriority)

		tOldPriority = aTask["priority"];

		if aNewPriority <= tOldPriority then
			return;
		end

		aTask["priority"] = aNewPriority;

		VUHDO_heapSiftUp(aHeap, aTask["heapIndex"]);

		return;

	end



	--
	local tTaskChunkSnapshots;
	local tNewSnapshot;
	local tIsDuplicate;
	local tCompositionKey;
	local tTaskTypes;
	local function VUHDO_addChunkSnapshot(aTotalChunkTimeUs, aNumTasksInChunk, aTasksDetailTable)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED or aTotalChunkTimeUs < (VUHDO_DEFERRED_TASK_CONFIG["MAX_EXEC_TIME_US"] or 50000) then
			return;
		end

		tTaskChunkSnapshots = VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS;
		tIsDuplicate = false;

		if aNumTasksInChunk > 0 and aTasksDetailTable and #aTasksDetailTable > 0 then
			tTaskTypes = { };

			for _, tTaskDetail in ipairs(aTasksDetailTable) do
				tinsert(tTaskTypes, tostring(tTaskDetail["type"]));
			end

			tCompositionKey = table.concat(tTaskTypes, ",");

			for _, tExistingSnapshot in ipairs(tTaskChunkSnapshots) do
				if not tExistingSnapshot["compositionKey"] then
					tTaskTypes = { };

					if tExistingSnapshot["tasks"] then
						for _, tTaskDetail in ipairs(tExistingSnapshot["tasks"]) do
							tinsert(tTaskTypes, tostring(tTaskDetail["type"]));
						end
					end

					tExistingSnapshot["compositionKey"] = table.concat(tTaskTypes, ",");
				end

				if tExistingSnapshot["compositionKey"] == tCompositionKey then
					tExistingSnapshot["dedupedCount"] = (tExistingSnapshot["dedupedCount"] or 1) + 1;

					if aTotalChunkTimeUs > tExistingSnapshot["totalChunkTimeUs"] then
						tExistingSnapshot["totalChunkTimeUs"] = aTotalChunkTimeUs;
						tExistingSnapshot["timestamp"] = time();

						twipe(tExistingSnapshot["tasks"]);

						for _, tTaskDetailSnapshot in ipairs(aTasksDetailTable) do
							tinsert(tExistingSnapshot["tasks"], {
								["type"] = tTaskDetailSnapshot["type"],
								["args"] = tTaskDetailSnapshot["args"],
								["argCount"] = tTaskDetailSnapshot["argCount"],
								["durationUs"] = tTaskDetailSnapshot["durationUs"],
							});
						end
					end

					tIsDuplicate = true;

					break;
				end
			end
		end

		if not tIsDuplicate then
			tNewSnapshot = {
				["totalChunkTimeUs"] = aTotalChunkTimeUs,
				["numTasksInChunk"] = aNumTasksInChunk,
				["tasks"] = { },
				["timestamp"] = time(),
				["dedupedCount"] = 1,
			};

			if aTasksDetailTable and #aTasksDetailTable > 0 then
				tTaskTypes = { };

				for _, tTaskDetailSnapshot in ipairs(aTasksDetailTable) do
					tinsert(tNewSnapshot["tasks"], {
						["type"] = tTaskDetailSnapshot["type"],
						["args"] = tTaskDetailSnapshot["args"],
						["argCount"] = tTaskDetailSnapshot["argCount"],
						["durationUs"] = tTaskDetailSnapshot["durationUs"],
					});

					tinsert(tTaskTypes, tostring(tTaskDetailSnapshot["type"]));
				end

				tNewSnapshot["compositionKey"] = table.concat(tTaskTypes, ",");
			else
				tNewSnapshot["compositionKey"] = "";
			end

			tinsert(tTaskChunkSnapshots, tNewSnapshot);
		end

		table.sort(tTaskChunkSnapshots, function(a, b) return a.totalChunkTimeUs > b.totalChunkTimeUs; end);

		while #tTaskChunkSnapshots > VUHDO_DEFERRED_TASK_CONFIG["CHUNK_SNAPSHOT_LIMIT"] do
			tremove(tTaskChunkSnapshots);
		end

		return;

	end



	--
	local tMetrics;
	local function VUHDO_sampleDeferredTaskQueueLength(aCurrentQueueLen)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED or not aCurrentQueueLen or aCurrentQueueLen <= 0 then
			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];

		tMetrics["minQueueLength"] = min(tMetrics["minQueueLength"], aCurrentQueueLen);
		tMetrics["maxQueueLength"] = max(tMetrics["maxQueueLength"], aCurrentQueueLen);
		tMetrics["sumQueueLength"] = tMetrics["sumQueueLength"] + aCurrentQueueLen;
		tMetrics["queueLengthSamples"] = tMetrics["queueLengthSamples"] + 1;

		return;

	end



	--
	local tMetrics;
	local function VUHDO_incrementDeferredTaskHardStops()

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];
		tMetrics["hardStopsHit"] = (tMetrics["hardStopsHit"] or 0) + 1;

		return;

	end



	--
	local tMetrics;
	local function VUHDO_recordTasksPerChunkSample(aTasksCompletedInChunk)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED or not aTasksCompletedInChunk or aTasksCompletedInChunk <= 0 then
			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];

		if not tMetrics["tasksInChunkTailMeanTracker"] then
			tMetrics["tasksInChunkTailMeanTracker"] = VUHDO_createTailMeanTracker();
		end

		tMetrics["tasksInChunkTailMeanTracker"]:update(aTasksCompletedInChunk);

		return;

	end



	--
	local tMetrics;
	local function VUHDO_updateDeferredTaskIndividualMetrics(aTaskType, aTaskDurationUs, aArgsSummary, aArgCount, aQueueTimeUs)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];

		if not tMetrics["tasksProcessedByTypeSession"][aTaskType] then
			tMetrics["tasksProcessedByTypeSession"][aTaskType] = 0;

			if tMetrics["totalTimeUsByTypeSession"][aTaskType] == nil then
				tMetrics["totalTimeUsByTypeSession"][aTaskType] = 0;
			end

			if tMetrics["queueTimeUsByTypeSession"][aTaskType] == nil then
				tMetrics["queueTimeUsByTypeSession"][aTaskType] = 0;
			end

			if tMetrics["minTaskTimeUsByTypeSession"][aTaskType] == nil then
				tMetrics["minTaskTimeUsByTypeSession"][aTaskType] = 9999999;
			end

			if tMetrics["maxTaskTimeUsByTypeSession"][aTaskType] == nil then
				tMetrics["maxTaskTimeUsByTypeSession"][aTaskType] = 0;
			end

			if tMetrics["maxTaskTimeUsContextByTypeSession"][aTaskType] == nil then
				tMetrics["maxTaskTimeUsContextByTypeSession"][aTaskType] = nil;
			end
		end

		tMetrics["tasksProcessedByTypeSession"][aTaskType] = tMetrics["tasksProcessedByTypeSession"][aTaskType] + 1;
		tMetrics["totalTimeUsByTypeSession"][aTaskType] = tMetrics["totalTimeUsByTypeSession"][aTaskType] + aTaskDurationUs;
		tMetrics["queueTimeUsByTypeSession"][aTaskType] = tMetrics["queueTimeUsByTypeSession"][aTaskType] + (aQueueTimeUs or 0);

		if aQueueTimeUs and aQueueTimeUs > 0 then
			if not tMetrics["queueTimeTailMeanTrackerByType"] then
				tMetrics["queueTimeTailMeanTrackerByType"] = { };
			end

			if not tMetrics["queueTimeTailMeanTrackerByType"][aTaskType] then
				tMetrics["queueTimeTailMeanTrackerByType"][aTaskType] = VUHDO_createTailMeanTracker();
			end

			tMetrics["queueTimeTailMeanTrackerByType"][aTaskType]:update(aQueueTimeUs);
		end

		tMetrics["minTaskTimeUsByTypeSession"][aTaskType] = min(tMetrics["minTaskTimeUsByTypeSession"][aTaskType], aTaskDurationUs);

		if not tMetrics["taskDurationTailMeanTrackerByType"] then
			tMetrics["taskDurationTailMeanTrackerByType"] = { };
		end

		if not tMetrics["taskDurationTailMeanTrackerByType"][aTaskType] then
			tMetrics["taskDurationTailMeanTrackerByType"][aTaskType] = VUHDO_createTailMeanTracker();
		end

		tMetrics["taskDurationTailMeanTrackerByType"][aTaskType]:update(aTaskDurationUs);

		if aTaskDurationUs > (tMetrics["maxTaskTimeUsByTypeSession"][aTaskType] or -1) then
			tMetrics["maxTaskTimeUsByTypeSession"][aTaskType] = aTaskDurationUs;

			tMetrics["maxTaskTimeUsContextByTypeSession"][aTaskType] = {
				["args"] = aArgsSummary,
				["argCount"] = aArgCount,
			};
		end

		return;

	end



	--
	local tMetrics;
	local function VUHDO_updateDeferredTaskChunkMetrics(aChunkElapsedTime, aNumTasksProcessed)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED or not aNumTasksProcessed or aNumTasksProcessed <= 0 then
			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];

		tMetrics["chunksExecutedSuccessfully"] = (tMetrics["chunksExecutedSuccessfully"] or 0) + 1;
		tMetrics["totalTasksProcessedSession"] = (tMetrics["totalTasksProcessedSession"] or 0) + aNumTasksProcessed;
		tMetrics["totalProcessingTimeUsSession"] = (tMetrics["totalProcessingTimeUsSession"] or 0) + aChunkElapsedTime;

		if not tMetrics["chunkTimeTailMeanTracker"] then
			tMetrics["chunkTimeTailMeanTracker"] = VUHDO_createTailMeanTracker();
		end

		tMetrics["chunkTimeTailMeanTracker"]:update(aChunkElapsedTime);

		return;

	end



	--
	local tDelegate;
	local tTaskKey;
	local tTask;
	local tNewTask;
	local tMetrics;
	local tCurrentPriority;
	function VUHDO_enqueueDeferredTask(aType, aPriority, ...)

		if not aType then
			return false;
		end

		if not sDeferredTaskDelegates then
			return false;
		end

		if not VUHDO_DEFERRED_TASK_POOL then
			return false;
		end

		tCurrentPriority = aPriority or VUHDO_DEFERRED_TASK_PRIORITY_NORMAL;

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];
		end

		tDelegate = sDeferredTaskDelegates[aType];

		if tDelegate then
			if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
				tMetrics["totalTasksEnqueued"] = tMetrics["totalTasksEnqueued"] + 1;

				if not tMetrics["tasksEnqueuedByType"][aType] then
					tMetrics["tasksEnqueuedByType"][aType] = 0;
				end

				tMetrics["tasksEnqueuedByType"][aType] = tMetrics["tasksEnqueuedByType"][aType] + 1;
			end

			tNewTask = VUHDO_DEFERRED_TASK_POOL:get();

			for tArgCnt = 1, select("#", ...) do
				tNewTask["args"][tArgCnt] = select(tArgCnt, ...);
			end

			tNewTask["delegate"] = tDelegate;
			tNewTask["type"] = aType;
			tNewTask["priority"] = tCurrentPriority;
			tNewTask["taskKey"] = VUHDO_getTaskKey(aType, tNewTask["args"]);

			if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
				tNewTask["enqueueTime"] = GetTime();
			end

			tTaskKey = tNewTask["taskKey"];
			tTask = VUHDO_TASK_QUEUE_MAP[tTaskKey];

			if not tTask then
				tTask = sCombatHeldTaskMap[tTaskKey];
			end

			if tTask then
				if tTask["heapIndex"] and tTask["heapIndex"] > 0 then
					VUHDO_heapUpdateTask(VUHDO_TASK_PRIORITY_QUEUE, tTask, tCurrentPriority);
				else
					if tCurrentPriority > tTask["priority"] then
						tTask["priority"] = tCurrentPriority;
					end
				end

				tTask["delegate"] = tDelegate;

				VUHDO_DEFERRED_TASK_POOL:release(tNewTask);

				if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
					tMetrics["totalTasksDeduped"] = tMetrics["totalTasksDeduped"] + 1;
				end

				return true;
			else
				VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, tNewTask, VUHDO_TASK_QUEUE_MAP);

				return true;
			end
		end

		return false;

	end



	--
	local tTaskState;
	local tTaskConfig;
	function VUHDO_updateFrameBudget(aTimeDelta)

		tTaskState = VUHDO_DEFERRED_TASK_STATE;
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		tTaskState["currentFrameBudgetUs"] = tTaskConfig["MAX_EXEC_TIME_US"];

		return;

	end



	--
	local tPriorCost;
	function VUHDO_recordTaskCostSample(aTaskType, aDurationUs)

		if not aTaskType or not aDurationUs or aDurationUs <= 0 then
			return;
		end

		tTaskState = VUHDO_DEFERRED_TASK_STATE;

		if not tTaskState["avgCostUsByType"] then
			tTaskState["avgCostUsByType"] = { };
		end

		tPriorCost = tTaskState["avgCostUsByType"][aTaskType];

		if tPriorCost then
			tTaskState["avgCostUsByType"][aTaskType] = tPriorCost * 0.85 + aDurationUs * 0.15;
		else
			tTaskState["avgCostUsByType"][aTaskType] = aDurationUs;
		end

		return;

	end



	--
	local tPriorPeak;
	local function VUHDO_recordTaskPeakCost(aTaskType, aDurationUs)

		if not aTaskType or not aDurationUs or aDurationUs <= 0 then
			return;
		end

		tTaskState = VUHDO_DEFERRED_TASK_STATE;

		if not tTaskState["peakCostUsByType"] then
			tTaskState["peakCostUsByType"] = { };
		end

		tPriorPeak = tTaskState["peakCostUsByType"][aTaskType] or 0;

		tTaskState["peakCostUsByType"][aTaskType] = max(aDurationUs, tPriorPeak * 0.9);

		return;

	end



	--
	local function VUHDO_getTaskCostEstimate(aTaskType)

		tTaskState = VUHDO_DEFERRED_TASK_STATE;
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		if tTaskState["avgCostUsByType"] and tTaskState["avgCostUsByType"][aTaskType] then
			return tTaskState["avgCostUsByType"][aTaskType];
		end

		if VUHDO_TASK_TYPE_DEFAULT_COSTS[aTaskType] then
			return VUHDO_TASK_TYPE_DEFAULT_COSTS[aTaskType];
		end

		return (tTaskConfig["TARGET_EXEC_TIME_US"] / max(1, tTaskConfig["INITIAL_TASKS_PER_FRAME"])) * 1.2;

	end



	--
	local tPeakCost;
	local function VUHDO_getTaskBudgetEstimate(aTaskType)

		tTaskState = VUHDO_DEFERRED_TASK_STATE;

		tPeakCost = tTaskState["peakCostUsByType"] and tTaskState["peakCostUsByType"][aTaskType];

		if tPeakCost then
			return max(tPeakCost, VUHDO_TASK_TYPE_DEFAULT_COSTS[aTaskType] or 0);
		end

		return VUHDO_getTaskCostEstimate(aTaskType);

	end



	--
	local tMaxTasksPerFrame;
	local tInvocationCount;
	local tTaskState;
	local tTaskConfig;
	local tCostHistory;
	local tIndividualCosts;
	local tCostEstimate;
	local tSum;
	local tTrimCount;
	local tStartIndex;
	local tEndIndex;
	local tCount;
	local tDefaultCost;
	local tCostHistoryCount;
	function VUHDO_adjustDynamicDeferTasks()

		tTaskState = VUHDO_DEFERRED_TASK_STATE;
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		tMaxTasksPerFrame = tTaskState["maxTasksPerFrame"];

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED and VUHDO_DEFERRED_TASK_TYPES then
			for _, tTaskType in pairs(VUHDO_DEFERRED_TASK_TYPES) do
				tInvocationCount = tTaskState["invocationCountByType"][tTaskType] or 0;

				if tInvocationCount > 0 then
					if not tTaskState["costHistoryByType"] then
						tTaskState["costHistoryByType"] = { };
					end

					if not tTaskState["costHistoryByType"][tTaskType] then
						tTaskState["costHistoryByType"][tTaskType] = { };
					end

					tCostHistory = tTaskState["costHistoryByType"][tTaskType];
					tIndividualCosts = tTaskState["individualCostsByType"] and tTaskState["individualCostsByType"][tTaskType] or { };

					for _, tCost in pairs(tIndividualCosts) do
						tinsert(tCostHistory, tCost);
					end

					while #tCostHistory > 20 do
						tremove(tCostHistory, 1);
					end

					tCostEstimate = 0;

					twipe(sSortedCostHistory);

					for tCnt = 1, #tCostHistory do
						sSortedCostHistory[tCnt] = tCostHistory[tCnt];
					end

					table.sort(sSortedCostHistory);

					tCostHistoryCount = #sSortedCostHistory;

					if tCostHistoryCount >= 5 then
						tTrimCount = max(1, floor(tCostHistoryCount * 0.1));
						tStartIndex = tTrimCount + 1;
						tEndIndex = tCostHistoryCount - tTrimCount;

						if tStartIndex <= tEndIndex then
							tSum = 0;
							tCount = 0;

							for tCnt = tStartIndex, tEndIndex do
								tSum = tSum + sSortedCostHistory[tCnt];

								tCount = tCount + 1;
							end

							tCostEstimate = tSum / tCount;
						else
							tSum = 0;

							for tCnt = 1, tCostHistoryCount do
								tSum = tSum + sSortedCostHistory[tCnt];
							end

							tCostEstimate = tSum / tCostHistoryCount;
						end
					else
						tSum = 0;

						for tCnt = 1, tCostHistoryCount do
							tSum = tSum + sSortedCostHistory[tCnt];
						end

						tCostEstimate = tCostHistoryCount > 0 and (tSum / tCostHistoryCount) or 0;
					end

					tDefaultCost = VUHDO_TASK_TYPE_DEFAULT_COSTS[tTaskType] or (tTaskConfig["TARGET_EXEC_TIME_US"] / max(1, tTaskConfig["MAX_TASKS_PER_FRAME"])) * 1.2;

					if tCostEstimate <= 0 then
						tCostEstimate = tDefaultCost;
					end

					tTaskState["avgCostUsByType"][tTaskType] = tCostEstimate;

					if tTaskState["individualCostsByType"] then
						tTaskState["individualCostsByType"][tTaskType] = { };
					end
				elseif tTaskState["avgCostUsByType"][tTaskType] == nil then
					tTaskState["avgCostUsByType"][tTaskType] = VUHDO_TASK_TYPE_DEFAULT_COSTS[tTaskType] or
						(tTaskConfig["TARGET_EXEC_TIME_US"] / max(1, tTaskConfig["MAX_TASKS_PER_FRAME"])) * 1.2;

					tTaskState["invocationCountByType"][tTaskType] = 0;
				end
			end
		end

		tTaskState["maxTasksPerFrame"] = floor(max(tTaskConfig["MIN_TASKS_PER_FRAME"], min(tMaxTasksPerFrame, tTaskConfig["MAX_TASKS_PER_FRAME"])));

		return;

	end



	--
	local tStack;
	local function VUHDO_deferredTaskErrorHandler(anError)

		-- debugstack(start, count1, count2): count1 frames from the top, count2 from the bottom (WoW API; does not skip levels).
		tStack = debugstack(1, 20, 3);

		return tostring(anError) .. "\nStacktrace:\n" .. tStack;

	end



	--
	local function VUHDO_xpcallTaskDelegate(aTask)

		return xpcall(aTask["delegate"], VUHDO_deferredTaskErrorHandler, unpack(aTask["args"]));

	end



	--
	local tTask;
	local tTaskType;
	local tDelegateSuccess;
	local tDelegateResult;
	local tTaskDurationUs;
	local tTaskStartTime;
	local tArgsSummary;
	local tProfilerResult;
	local tQueueTimeUs;
	function VUHDO_executeSingleTask(aTask)

		tTask = aTask;
		tTaskType = tTask["type"];

		if not tTask["delegate"] then
			return false, "No delegate function", 0;
		end

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			tTaskDurationUs = 0;

			if MeasureCall then
				tProfilerResult, tDelegateSuccess, tDelegateResult = MeasureCall(VUHDO_xpcallTaskDelegate, tTask);

				if tProfilerResult and tProfilerResult.elapsedMilliseconds then
					tTaskDurationUs = tProfilerResult.elapsedMilliseconds * 1000;
				end
			else
				tTaskStartTime = debugprofilestop();

				tDelegateSuccess, tDelegateResult = VUHDO_xpcallTaskDelegate(tTask);

				tTaskDurationUs = (debugprofilestop() - tTaskStartTime) * 1000;
			end
		else
			tTaskStartTime = debugprofilestop();

			tDelegateSuccess, tDelegateResult = VUHDO_xpcallTaskDelegate(tTask);

			tTaskDurationUs = (debugprofilestop() - tTaskStartTime) * 1000;

			VUHDO_recordTaskCostSample(tTaskType, tTaskDurationUs);
		end

		VUHDO_recordTaskPeakCost(tTaskType, tTaskDurationUs);

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			tQueueTimeUs = 0;

			if tTask["enqueueTime"] then
				tQueueTimeUs = (GetTime() - tTask["enqueueTime"]) * 1000000;
			end

			VUHDO_DEFERRED_TASK_STATE["invocationCountByType"][tTaskType] = (VUHDO_DEFERRED_TASK_STATE["invocationCountByType"][tTaskType] or 0) + 1;

			if not VUHDO_DEFERRED_TASK_STATE["individualCostsByType"] then
				VUHDO_DEFERRED_TASK_STATE["individualCostsByType"] = { };
			end

			if not VUHDO_DEFERRED_TASK_STATE["individualCostsByType"][tTaskType] then
				VUHDO_DEFERRED_TASK_STATE["individualCostsByType"][tTaskType] = { };
			end

			tinsert(VUHDO_DEFERRED_TASK_STATE["individualCostsByType"][tTaskType], tTaskDurationUs);

			if not VUHDO_DEFERRED_TASK_STATE["queueTimeUsByType"] then
				VUHDO_DEFERRED_TASK_STATE["queueTimeUsByType"] = { };
			end

			VUHDO_DEFERRED_TASK_STATE["queueTimeUsByType"][tTaskType] = (VUHDO_DEFERRED_TASK_STATE["queueTimeUsByType"][tTaskType] or 0) + tQueueTimeUs;
		end

		if not tDelegateSuccess then
			tArgsSummary = "";

			if tTask["args"] and #tTask["args"] > 0 then
				for tCnt = 1, #tTask["args"] do
					if tCnt > 1 then
						tArgsSummary = tArgsSummary .. ",";
					end

					tArgsSummary = tArgsSummary .. VUHDO_argToString(tTask["args"][tCnt]);
				end
			else
				tArgsSummary = "none";
			end

			VUHDO_Msg(format("Task Execution Failure: [ Args: %s Type: %s Prio: %s ]\nError: %s",
				tArgsSummary, tostring(tTaskType), tostring(tTask["priority"]),
				tostring(tDelegateResult)
			));
		end

		return tDelegateSuccess, tDelegateResult, tTaskDurationUs;

	end



	--
	local tTask;
	local tStarvationTask;
	local function VUHDO_extractStarvationTask()

		tStarvationTask = nil;

		twipe(sSkippedHighPriorityTasks);

		while #VUHDO_TASK_PRIORITY_QUEUE > 0 and not tStarvationTask do
			tTask = VUHDO_heapExtractTop(VUHDO_TASK_PRIORITY_QUEUE, VUHDO_TASK_QUEUE_MAP);

			if tTask["priority"] < VUHDO_DEFERRED_TASK_PRIORITY_HIGH then
				tStarvationTask = tTask;
			else
				tinsert(sSkippedHighPriorityTasks, tTask);
			end
		end

		for tSkippedIndex = 1, #sSkippedHighPriorityTasks do
			VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, sSkippedHighPriorityTasks[tSkippedIndex], VUHDO_TASK_QUEUE_MAP);
		end

		return tStarvationTask;

	end



	--
	local tTaskState;
	local tArgsSummary;
	local tQueueTimeUs;
	local tBudgetStats;
	local tOverrunUs;
	local function VUHDO_recordExecutedTaskMetrics(aTask, aTaskType, aTaskDurationUs, aBudgetUs, aSnapshotTasks)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			return;
		end

		tTaskState = VUHDO_DEFERRED_TASK_STATE;

		tArgsSummary = "";

		if aTask["args"] and #aTask["args"] > 0 then
			for tCnt = 1, #aTask["args"] do
				if tCnt > 1 then
					tArgsSummary = tArgsSummary .. ",";
				end

				tArgsSummary = tArgsSummary .. VUHDO_argToString(aTask["args"][tCnt]);
			end
		else
			tArgsSummary = "none";
		end

		tQueueTimeUs = 0;

		if aTask["enqueueTime"] then
			tQueueTimeUs = (GetTime() - aTask["enqueueTime"]) * 1000000;
		end

		VUHDO_updateDeferredTaskIndividualMetrics(aTaskType, aTaskDurationUs, tArgsSummary, #aTask["args"] or 0, tQueueTimeUs);

		if aSnapshotTasks then
			tinsert(aSnapshotTasks, {
				["type"] = aTaskType,
				["args"] = tArgsSummary,
				["argCount"] = #aTask["args"] or 0,
				["durationUs"] = aTaskDurationUs,
			});
		end

		if not tTaskState["budgetStatsByType"] then
			tTaskState["budgetStatsByType"] = { };
		end

		if not tTaskState["budgetStatsByType"][aTaskType] then
			tTaskState["budgetStatsByType"][aTaskType] = {
				["count"] = 0,
				["overrunCount"] = 0,
				["maxOverrunUs"] = 0,
				["budgetAtMaxOverrunUs"] = 0,
			};
		end

		tBudgetStats = tTaskState["budgetStatsByType"][aTaskType];

		tBudgetStats["count"] = tBudgetStats["count"] + 1;
		tOverrunUs = aTaskDurationUs - aBudgetUs;

		if tOverrunUs > 0 then
			tBudgetStats["overrunCount"] = tBudgetStats["overrunCount"] + 1;

			if tOverrunUs > tBudgetStats["maxOverrunUs"] then
				tBudgetStats["maxOverrunUs"] = tOverrunUs;
				tBudgetStats["budgetAtMaxOverrunUs"] = aBudgetUs;
			end
		end

		return;

	end



	--
	local tTaskState;
	local tTaskConfig;
	local tTasksCompleted;
	local tHardStopTime;
	local tSoftStopTime;
	local tNowUs;
	local tTask;
	local tTaskType;
	local tTaskDurationUs;
	local tCurrentQueueLen;
	local tTaskMetricsForSnapshot = { };
	local tShouldProcessTask;
	local tBudgetUs;
	local tIsInCombatLockdown;
	local tHeldTaskKey;
	local tBelowHighProcessed;
	local tStarvationTask;
	function VUHDO_executeDeferredTaskChunk()

		tTaskState = VUHDO_DEFERRED_TASK_STATE;
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		tIsInCombatLockdown = InCombatLockdown();

		if not tIsInCombatLockdown and #sCombatHeldTasks > 0 then
			for tCnt = 1, #sCombatHeldTasks do
				VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, sCombatHeldTasks[tCnt], VUHDO_TASK_QUEUE_MAP);
			end

			twipe(sCombatHeldTasks);
			twipe(sCombatHeldTaskMap);
		end

		tTasksCompleted = 0;
		tBelowHighProcessed = false;
		tHardStopTime = (debugprofilestop() * 1000) + tTaskConfig["MAX_EXEC_TIME_US"] + 100;
		tSoftStopTime = (debugprofilestop() * 1000) + tTaskConfig["TARGET_EXEC_TIME_US"];

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			tCurrentQueueLen = #VUHDO_TASK_PRIORITY_QUEUE;

			VUHDO_sampleDeferredTaskQueueLength(tCurrentQueueLen);

			twipe(tTaskMetricsForSnapshot);
		end

		if sIsStarvationTaskDue and not InCombatLockdown() and #VUHDO_TASK_PRIORITY_QUEUE > 0 then
			tStarvationTask = VUHDO_extractStarvationTask();

			if tStarvationTask and tStarvationTask["delegate"] and tStarvationTask["type"] then
				tTaskType = tStarvationTask["type"];

				if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
					tBudgetUs = VUHDO_getTaskBudgetEstimate(tTaskType);
				end

				_, _, tTaskDurationUs = VUHDO_executeSingleTask(tStarvationTask);

				VUHDO_recordExecutedTaskMetrics(tStarvationTask, tTaskType, tTaskDurationUs, tBudgetUs, tTaskMetricsForSnapshot);

				tTasksCompleted = tTasksCompleted + 1;
				tBelowHighProcessed = true;

				VUHDO_DEFERRED_TASK_POOL:release(tStarvationTask);
			end

			sIsStarvationTaskDue = false;
		end

		for tTaskCount = 1, tTaskState["maxTasksPerFrame"] do
			if #VUHDO_TASK_PRIORITY_QUEUE == 0 then
				break;
			end

			if (debugprofilestop() * 1000) > tHardStopTime and tTasksCompleted >= tTaskConfig["MIN_TASKS_PER_FRAME"] then
				VUHDO_incrementDeferredTaskHardStops();

				break;
			end

			tIsInCombatLockdown = InCombatLockdown();

			tTask = VUHDO_TASK_PRIORITY_QUEUE[1];

			tTaskType = tTask["type"];

			if tIsInCombatLockdown and VUHDO_COMBAT_HELD_TASKS[tTaskType] then
				tTask = VUHDO_heapExtractTop(VUHDO_TASK_PRIORITY_QUEUE, VUHDO_TASK_QUEUE_MAP);

				tHeldTaskKey = tTask["taskKey"];

				sCombatHeldTaskMap[tHeldTaskKey] = tTask;
				tinsert(sCombatHeldTasks, tTask);
			else
				if tTasksCompleted >= tTaskConfig["MIN_TASKS_PER_FRAME"] then
					tNowUs = debugprofilestop() * 1000;

					if tNowUs > tSoftStopTime or tNowUs + VUHDO_getTaskBudgetEstimate(tTaskType) > tHardStopTime then
						break;
					end
				end

				tShouldProcessTask = (tTasksCompleted < tTaskConfig["MIN_TASKS_PER_FRAME"]) or
					(tTasksCompleted < tTaskState["maxTasksPerFrame"]);

				if tShouldProcessTask then
					tTask = VUHDO_heapExtractTop(VUHDO_TASK_PRIORITY_QUEUE, VUHDO_TASK_QUEUE_MAP);

					if tTask["delegate"] and tTaskType then
						if tTask["priority"] < VUHDO_DEFERRED_TASK_PRIORITY_HIGH then
							tBelowHighProcessed = true;
						end

						if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
							tBudgetUs = VUHDO_getTaskBudgetEstimate(tTaskType);
						end

						_, _, tTaskDurationUs = VUHDO_executeSingleTask(tTask);

						VUHDO_recordExecutedTaskMetrics(tTask, tTaskType, tTaskDurationUs, tBudgetUs, tTaskMetricsForSnapshot);

						tTasksCompleted = tTasksCompleted + 1;

						VUHDO_DEFERRED_TASK_POOL:release(tTask);

						tTask = nil;
					end
				end
			end
		end

		if not tBelowHighProcessed and #VUHDO_TASK_PRIORITY_QUEUE > 0 and not InCombatLockdown() then
			tStarvationTask = VUHDO_extractStarvationTask();

			if tStarvationTask and tStarvationTask["delegate"] and tStarvationTask["type"] then
				tTaskType = tStarvationTask["type"];
				tNowUs = debugprofilestop() * 1000;
				tBudgetUs = VUHDO_getTaskBudgetEstimate(tTaskType);

				if tNowUs + tBudgetUs <= tHardStopTime then
					_, _, tTaskDurationUs = VUHDO_executeSingleTask(tStarvationTask);

					VUHDO_recordExecutedTaskMetrics(tStarvationTask, tTaskType, tTaskDurationUs, tBudgetUs, tTaskMetricsForSnapshot);

					tTasksCompleted = tTasksCompleted + 1;

					VUHDO_DEFERRED_TASK_POOL:release(tStarvationTask);
				else
					VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, tStarvationTask, VUHDO_TASK_QUEUE_MAP);

					sIsStarvationTaskDue = true;
				end
			end
		end

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED and tTasksCompleted > 0 then
			VUHDO_recordTasksPerChunkSample(tTasksCompleted);
		end

		return tTasksCompleted, tTaskMetricsForSnapshot;

	end



	--
	local tTaskState;
	local tTaskConfig;
	local tNumTasksProcessed;
	local tChunkElapsedTime;
	local tProfilerResult;
	local tChunkStartTime;
	local tChunkTaskMetrics;
	local tDrainSuccess;
	local tDrainError;
	function VUHDO_processDeferredTaskQueue(aTimeDelta)

		VUHDO_checkAllSemaphoreTimeouts();

		tTaskState = VUHDO_DEFERRED_TASK_STATE;
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		VUHDO_updateFrameBudget(aTimeDelta);

		tNumTasksProcessed = 0;

		if not VUHDO_DEFERRED_TASK_POOL then
			return;
		end

		if #VUHDO_TASK_PRIORITY_QUEUE > 0 or #sCombatHeldTasks > 0 then
			if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
				if MeasureCall then
					tProfilerResult, tNumTasksProcessed, tChunkTaskMetrics = MeasureCall(VUHDO_executeDeferredTaskChunk);

					if tProfilerResult and tProfilerResult.elapsedMilliseconds then
						tChunkElapsedTime = tProfilerResult.elapsedMilliseconds * 1000;
					end
				else
					tChunkStartTime = debugprofilestop();

					tNumTasksProcessed, tChunkTaskMetrics = VUHDO_executeDeferredTaskChunk();

					tChunkElapsedTime = (debugprofilestop() - tChunkStartTime) * 1000;
				end

				if tNumTasksProcessed and tNumTasksProcessed > 0 then
					VUHDO_updateDeferredTaskChunkMetrics(tChunkElapsedTime, tNumTasksProcessed);

					if tChunkTaskMetrics then
						VUHDO_addChunkSnapshot(tChunkElapsedTime, tNumTasksProcessed, tChunkTaskMetrics);
					end
				end
			else
				tNumTasksProcessed = VUHDO_executeDeferredTaskChunk();
			end
		end

		if GetTime() - tTaskState["lastAdjustTime"] >= tTaskConfig["ADJUST_INTERVAL_SECS"] then
			VUHDO_adjustDynamicDeferTasks();

			tTaskState["lastAdjustTime"] = GetTime();
		end

		tDrainSuccess, tDrainError = xpcall(VUHDO_processPendingAuraContainerBuilds, VUHDO_deferredTaskErrorHandler);

		if not tDrainSuccess then
			VUHDO_Msg(format("Aura container build drain failure:\nError: %s", tostring(tDrainError)));
		end

		tDrainSuccess, tDrainError = xpcall(VUHDO_processPendingNativeAuraSounds, VUHDO_deferredTaskErrorHandler);

		if not tDrainSuccess then
			VUHDO_Msg(format("Native aura sound drain failure:\nError: %s", tostring(tDrainError)));
		end

		return;

	end



	--
	function VUHDO_deferTask(aType, aPriority, ...)

		return VUHDO_enqueueDeferredTask(aType, aPriority, ...);

	end



	--
	function VUHDO_setDeferredTaskProfiling(anIsEnabled)

		VUHDO_DEFERRED_TASK_PROFILING_ENABLED = anIsEnabled;

		if anIsEnabled then
			VUHDO_Msg("Task profiling is enabled.");
		else
			VUHDO_Msg("Task Profiling is disabled.");
		end

		return;

	end



	--
	function VUHDO_isDeferredTaskProfilingEnabled()

		return VUHDO_DEFERRED_TASK_PROFILING_ENABLED;

	end



	--
	local tMetricsReset;
	function VUHDO_resetDeferredTaskMetrics()

		sIsStarvationTaskDue = false;

		tMetricsReset = VUHDO_DEFERRED_TASK_STATE["metrics"];

		tMetricsReset["sessionStartTime"] = GetTime();
		tMetricsReset["totalTasksEnqueued"] = 0;
		tMetricsReset["totalTasksDeduped"] = 0;
		tMetricsReset["totalTasksProcessedSession"] = 0;
		tMetricsReset["totalProcessingTimeUsSession"] = 0;
		tMetricsReset["chunksExecutedSuccessfully"] = 0;

		tMetricsReset["minQueueLength"] = 999999;
		tMetricsReset["maxQueueLength"] = 0;
		tMetricsReset["sumQueueLength"] = 0;
		tMetricsReset["queueLengthSamples"] = 0;

		if tMetricsReset["tasksInChunkTailMeanTracker"] then
			tMetricsReset["tasksInChunkTailMeanTracker"]:reset();
		else
			tMetricsReset["tasksInChunkTailMeanTracker"] = nil;
		end

		if tMetricsReset["chunkTimeTailMeanTracker"] then
			tMetricsReset["chunkTimeTailMeanTracker"]:reset();
		else
			tMetricsReset["chunkTimeTailMeanTracker"] = nil;
		end

		tMetricsReset["hardStopsHit"] = 0;
		tMetricsReset["unsafeTasksProcessed"] = 0;

		twipe(tMetricsReset["tasksEnqueuedByType"]);
		twipe(tMetricsReset["tasksProcessedByTypeSession"]);
		twipe(tMetricsReset["totalTimeUsByTypeSession"]);
		twipe(tMetricsReset["queueTimeUsByTypeSession"]);

		if tMetricsReset["minTaskTimeUsByTypeSession"] then
			twipe(tMetricsReset["minTaskTimeUsByTypeSession"]);
		else
			tMetricsReset["minTaskTimeUsByTypeSession"] = { };
		end

		if tMetricsReset["maxTaskTimeUsByTypeSession"] then
			twipe(tMetricsReset["maxTaskTimeUsByTypeSession"]);
		else
			tMetricsReset["maxTaskTimeUsByTypeSession"] = { };
		end

		if tMetricsReset["maxTaskTimeUsContextByTypeSession"] then
			twipe(tMetricsReset["maxTaskTimeUsContextByTypeSession"]);
		else
			tMetricsReset["maxTaskTimeUsContextByTypeSession"] = { };
		end

		if tMetricsReset["taskDurationTailMeanTrackerByType"] then
			twipe(tMetricsReset["taskDurationTailMeanTrackerByType"]);
		else
			tMetricsReset["taskDurationTailMeanTrackerByType"] = { };
		end

		if tMetricsReset["queueTimeTailMeanTrackerByType"] then
			twipe(tMetricsReset["queueTimeTailMeanTrackerByType"]);
		else
			tMetricsReset["queueTimeTailMeanTrackerByType"] = { };
		end

		twipe(VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS);

		if VUHDO_DEFERRED_TASK_STATE["budgetStatsByType"] then
			twipe(VUHDO_DEFERRED_TASK_STATE["budgetStatsByType"]);
		end

		if VUHDO_DEFERRED_TASK_POOL and VUHDO_DEFERRED_TASK_POOL.resetMetrics then
			VUHDO_DEFERRED_TASK_POOL:resetMetrics();
		end

		if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			VUHDO_Msg("Deferred task metrics reset.");
		end

		return;

	end



	--
	local tMetrics;
	local tTaskConfig;
	local tEnqueued;
	local tProcessed;
	local tPoolMetrics;
	local tMaxTaskContextArgs;
	local tDedupedText;
	local tTailMeans;
	local tArgsSummary;
	local tTotalTasksProcessed;
	local tSessionDuration;
	local tTasksPerSecond;
	local tTasksPerCentumMs;
	local tTotalQueueTimeUsForType;
	local tQueueTailMeans;
	local tBudgetStats;
	local tBudgetNowUs;
	local tMaxOverrunText;
	local tTailMeanLabels;
	local tTailMeanFormat;
	local tTailMeanValues;
	local tQueueTailMeanValues;
	local tTasksTailMeanValues;
	local tTimeTailMeanValues;
	local tDurationTracker;
	local tQueueTracker;
	local tTaskTypeFormatArgs;
	local tQueueFormatArgs;
	function VUHDO_printDeferredTaskMetrics(anIsReset)

		if not VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
			VUHDO_Msg("Task profiling is currently disabled.");

			return;
		end

		tMetrics = VUHDO_DEFERRED_TASK_STATE["metrics"];
		tTaskConfig = VUHDO_DEFERRED_TASK_CONFIG;

		tSessionDuration = GetTime() - (tMetrics["sessionStartTime"] or GetTime());

		if tSessionDuration < 0 then
			tSessionDuration = 0;
		end

		VUHDO_Msg("|cffFFD100--- Deferred Task Queue Metrics (Session: " .. format("%.2f sec", tSessionDuration) .. ") ---|r");

		VUHDO_Msg(format("|cffFFA500** Overall Tasks:|r Enqueued: %d, Deduped: %d, Processed: %d, Unsafe: %d",
			(tMetrics["totalTasksEnqueued"] or 0), (tMetrics["totalTasksDeduped"] or 0), (tMetrics["totalTasksProcessedSession"] or 0), (tMetrics["unsafeTasksProcessed"] or 0)));
		VUHDO_Msg(format("|cffFFA500** Overall Time:|r Total: %s, Chunks Executed: %d",
			VUHDO_formatTime(tMetrics["totalProcessingTimeUsSession"]), (tMetrics["chunksExecutedSuccessfully"] or 0)));

		VUHDO_Msg("|cffFFA500** Queue Length:|r Current: " .. #VUHDO_TASK_PRIORITY_QUEUE);

		if (tMetrics["queueLengthSamples"] or 0) > 0 then
			VUHDO_Msg(format("  |cff98FB98Samples:|r Min: %d, Max: %d, Avg: %.2f",
				(tMetrics["minQueueLength"] == 999999 and 0 or (tMetrics["minQueueLength"] or 0)),
				(tMetrics["maxQueueLength"] or 0),
				((tMetrics["sumQueueLength"] or 0) / tMetrics["queueLengthSamples"])));
		else
			VUHDO_Msg("  |cff98FB98Samples:|r No queue length samples recorded (empty or reset).");
		end

		tTailMeanLabels, tTailMeanFormat = VUHDO_getTailMeanFormats();

		VUHDO_Msg("|cffFFA500** Chunk Performance (for " .. (tMetrics["chunksExecutedSuccessfully"] or 0) .. " successful chunks):|r");

		if (tMetrics["chunksExecutedSuccessfully"] or 0) > 0 then
			tTailMeans = tMetrics["tasksInChunkTailMeanTracker"] and tMetrics["tasksInChunkTailMeanTracker"]:getTailMeans() or VUHDO_getEmptyTailMeans();
			tTasksTailMeanValues = { };

			for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
				tTasksTailMeanValues[tIndex] = format("%.1f", tTailMeans[tTailMeanKey] or 0);
			end

			VUHDO_Msg(format("  |cffB0E0E6Tasks/Chunk:|r " .. tTailMeanFormat,
				unpack(tTasksTailMeanValues)));

			tTailMeans = tMetrics["chunkTimeTailMeanTracker"] and tMetrics["chunkTimeTailMeanTracker"]:getTailMeans() or VUHDO_getEmptyTailMeans();
			tTimeTailMeanValues = { };

			for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
				tTimeTailMeanValues[tIndex] = VUHDO_formatTime(tTailMeans[tTailMeanKey] or 0) or "0 us";
			end

			VUHDO_Msg(format("  |cffB0E0E6Time/Chunk:|r " .. tTailMeanFormat,
				unpack(tTimeTailMeanValues)));
		else
			VUHDO_Msg("  |cff98FB98No chunks processed tasks or metrics reset.|r");
		end

		VUHDO_Msg(format("  |cff98FB98Stops:|r Hard (Time Limit): %d", (tMetrics["hardStopsHit"] or 0)));

		tTotalTasksProcessed = tMetrics["totalTasksProcessedSession"] or 0;
		tSessionDuration = GetTime() - (tMetrics["sessionStartTime"] or GetTime());

		if tSessionDuration > 0 then
			tTasksPerSecond = tTotalTasksProcessed / tSessionDuration;
			tTasksPerCentumMs = tTasksPerSecond * 0.1;

			VUHDO_Msg(format("|cffFFA500** Task Throughput:|r %.2f tasks/sec (%.2f tasks/100ms)", tTasksPerSecond, tTasksPerCentumMs));
		end

		VUHDO_Msg("|cffFFA500** Per-Task Type (Enqueued, Processed, " .. tTailMeanLabels .. " [Args]): **|r");
		VUHDO_Msg("|cffFFA500** Queue Time Statistics (Total Queue Time, Avg Queue Time per Task): **|r");
		VUHDO_Msg("|cffFFA500** Task Budget (Now = next admission budget; Recent Avg = last 20 runs): **|r");

		if VUHDO_DEFERRED_TASK_TYPES then
			for _, tTaskType in ipairs(VUHDO_DEFERRED_TASK_TYPES) do
				tEnqueued = (tMetrics["tasksEnqueuedByType"] and tMetrics["tasksEnqueuedByType"][tTaskType]) or 0;
				tProcessed = (tMetrics["tasksProcessedByTypeSession"] and tMetrics["tasksProcessedByTypeSession"][tTaskType]) or 0;
				tTotalQueueTimeUsForType = (tMetrics["queueTimeUsByTypeSession"] and tMetrics["queueTimeUsByTypeSession"][tTaskType]) or 0;

				tMaxTaskContextArgs = "-";

				if tMetrics["maxTaskTimeUsContextByTypeSession"] and tMetrics["maxTaskTimeUsContextByTypeSession"][tTaskType] then
					tMaxTaskContextArgs = tostring(tMetrics["maxTaskTimeUsContextByTypeSession"][tTaskType]["args"] or "-");
				end

				tDurationTracker = tMetrics["taskDurationTailMeanTrackerByType"] and tMetrics["taskDurationTailMeanTrackerByType"][tTaskType];
				tTailMeans = tDurationTracker and tDurationTracker:getTailMeans() or VUHDO_getEmptyTailMeans();

				tTailMeanValues = { };

				for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
					tTailMeanValues[tIndex] = VUHDO_formatTime(tTailMeans[tTailMeanKey] or 0) or "0 us";
				end

				tTaskTypeFormatArgs = { tostring(tTaskType), tEnqueued, tProcessed };

				for tIndex = 1, #tTailMeanValues do
					tinsert(tTaskTypeFormatArgs, tTailMeanValues[tIndex]);
				end

				tinsert(tTaskTypeFormatArgs, tMaxTaskContextArgs);

				VUHDO_Msg(format("  |cffB0E0E6Type[%s]:|r E=%d, P=%d, " .. tTailMeanFormat .. " [%s]", unpack(tTaskTypeFormatArgs)));

				tQueueTracker = tMetrics["queueTimeTailMeanTrackerByType"] and tMetrics["queueTimeTailMeanTrackerByType"][tTaskType];
				tQueueTailMeans = tQueueTracker and tQueueTracker:getTailMeans() or VUHDO_getEmptyTailMeans();

				tQueueTailMeanValues = { };

				for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
					tQueueTailMeanValues[tIndex] = VUHDO_formatTime(tQueueTailMeans[tTailMeanKey] or 0) or "0 us";
				end

				tQueueFormatArgs = { VUHDO_formatTime(tTotalQueueTimeUsForType) };

				for tIndex = 1, #tQueueTailMeanValues do
					tinsert(tQueueFormatArgs, tQueueTailMeanValues[tIndex]);
				end

				VUHDO_Msg(format("    |cff98FB98Queue:|r Total=%s, " .. tTailMeanFormat, unpack(tQueueFormatArgs)));

				tBudgetStats = VUHDO_DEFERRED_TASK_STATE["budgetStatsByType"] and VUHDO_DEFERRED_TASK_STATE["budgetStatsByType"][tTaskType];

				if tBudgetStats and tBudgetStats["count"] > 0 then
					tBudgetNowUs = VUHDO_getTaskBudgetEstimate(tTaskType);

					if tBudgetStats["overrunCount"] > 0 then
						tMaxOverrunText = format("%s (budget %s)",
							VUHDO_formatTime(tBudgetStats["maxOverrunUs"]),
							VUHDO_formatTime(tBudgetStats["budgetAtMaxOverrunUs"]));
					else
						tMaxOverrunText = "-";
					end

					VUHDO_Msg(format("    |cff98FB98Budget:|r Now=%s, Overruns=%d/%d, MaxOver=%s, Recent Avg=%s",
						VUHDO_formatTime(tBudgetNowUs),
						tBudgetStats["overrunCount"], tBudgetStats["count"],
						tMaxOverrunText,
						VUHDO_formatTime(VUHDO_DEFERRED_TASK_STATE["avgCostUsByType"] and VUHDO_DEFERRED_TASK_STATE["avgCostUsByType"][tTaskType] or 0)));
				else
					VUHDO_Msg("    |cff98FB98Budget:|r No data available");
				end
			end
		else
			VUHDO_Msg("  (VUHDO_DEFERRED_TASK_TYPES not found for detailed stats)");
		end

		VUHDO_Msg("|cffFFA500** Dynamic Config:|r");

		VUHDO_Msg(format("  |cffB0E0E6Target Time/Chunk:|r %s, |cffB0E0E6Max Time/Chunk:|r %s",
			VUHDO_formatTime(tTaskConfig["TARGET_EXEC_TIME_US"]), VUHDO_formatTime(tTaskConfig["MAX_EXEC_TIME_US"])));
		VUHDO_Msg(format("  |cffB0E0E6Max Tasks/Frame:|r %d, |cffB0E0E6Idle Inc Threshold:|r %s",
			(VUHDO_DEFERRED_TASK_STATE["maxTasksPerFrame"] or 0), VUHDO_formatTime(tTaskConfig["IDLE_TASK_INC_THRESHOLD_US"])));

		VUHDO_Msg("|cffFFA500** Pool Stats (Size, Idle, PeakIdle, Hits, Misses, RejectedReleases): **|r");

		if VUHDO_DEFERRED_TASK_POOL and VUHDO_DEFERRED_TASK_POOL.getMetrics then
			tPoolMetrics = VUHDO_DEFERRED_TASK_POOL:getMetrics();

			VUHDO_Msg(format("  |cffB0E0E6Tasks Pool:|r %d, %d, %d, %d, %d, %d",
				(tPoolMetrics["maxSize"] or 0), (tPoolMetrics["currentIdle"] or 0), (tPoolMetrics["peakIdleCount"] or 0),
				(tPoolMetrics["hits"] or 0), (tPoolMetrics["misses"] or 0), (tPoolMetrics["rejectedReleases"] or 0)
			));
		else
			VUHDO_Msg("  |cffB0E0E6Tasks Pool:|r Metrics unavailable.");
		end

		if #VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS > 0 then
			VUHDO_Msg("|cffFFA500** Top " .. #VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS .. " Expensive Deferred Task Chunks (|cffB0E0E6Threshold:|r >" .. (VUHDO_formatTime(VUHDO_DEFERRED_TASK_CONFIG["MAX_EXEC_TIME_US"])) .. "): **|r");

			for tSnapshotCnt, tSnapshot in ipairs(VUHDO_DEFERRED_TASK_CHUNK_SNAPSHOTS) do
				tDedupedText = "";

				if (tSnapshot["dedupedCount"] or 0) > 1 then
					tDedupedText = format(" (|cff98FB98deduped|r %d times)", tSnapshot["dedupedCount"]);
				end

				VUHDO_Msg(format("  #%d: |cffB0E0E6ChunkTotalTime:|r %s, |cffB0E0E6NumTasks:|r %d, |cffB0E0E6Timestamp:|r %s%s",
					tSnapshotCnt,
					VUHDO_formatTime(tSnapshot["totalChunkTimeUs"]),
					tSnapshot["numTasksInChunk"],
					date("%m/%d/%y %H:%M:%S", tSnapshot["timestamp"]),
					tDedupedText
				));

				if tSnapshot["tasks"] then
					for tCnt, tTask in ipairs(tSnapshot["tasks"]) do
						tArgsSummary = tTask["args"] or "none";

						VUHDO_Msg(format("    T%d: |cffB0E0E6Type[%s]|r %s (|cff98FB98Args:|r%s)",
							tCnt,
							tostring(tTask["type"]),
							VUHDO_formatTime(tTask["durationUs"]),
							tArgsSummary
						));
					end
				end
			end
		else
			VUHDO_Msg("|cffFFA500** No expensive deferred task chunks captured. **|r");
		end

		VUHDO_Msg("|cffFFD100--- End of Metrics ---|r");

		if anIsReset then
			VUHDO_resetDeferredTaskMetrics();
		end

		return;

	end
end



--
local tTask;
local tTasksToReinsert;
local function VUHDO_extractAllTasksFromQueue()

	tTasksToReinsert = {};

	while #VUHDO_TASK_PRIORITY_QUEUE > 0 do
		tTask = VUHDO_heapExtractTop(VUHDO_TASK_PRIORITY_QUEUE, VUHDO_TASK_QUEUE_MAP);

		tinsert(tTasksToReinsert, tTask);
	end

	twipe(VUHDO_TASK_QUEUE_MAP);

	return tTasksToReinsert;

end



--
function VUHDO_reinsertTasksToQueue(aTasksToReinsert)

	for _, tTask in ipairs(aTasksToReinsert) do
		VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, tTask, VUHDO_TASK_QUEUE_MAP);
	end

	return;

end



--
local tSuccess;
local tIterationCount;
local tTotalTasksProcessed;
local tCurrentTask;
local tTasksProcessedThisIteration;
local tCombatSafeTasks;
local tCombatUnsafeTasks;
function VUHDO_processCombatUnsafeTasksBeforeLockdown()

	if not VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
		return;
	end

	tTotalTasksProcessed = 0;
	tIterationCount = 0;

	repeat
		tTasksProcessedThisIteration = 0;
		tCombatSafeTasks = { };
		tCombatUnsafeTasks = { };

		while #VUHDO_TASK_PRIORITY_QUEUE > 0 do
			tCurrentTask = VUHDO_heapExtractTop(VUHDO_TASK_PRIORITY_QUEUE, VUHDO_TASK_QUEUE_MAP);

			if VUHDO_COMBAT_UNSAFE_TASKS[tCurrentTask["type"]] then
				tinsert(tCombatUnsafeTasks, tCurrentTask);
			else
				tinsert(tCombatSafeTasks, tCurrentTask);
			end
		end

		for _, tTask in ipairs(tCombatUnsafeTasks) do
			tSuccess, _ = VUHDO_executeSingleTask(tTask);

			if tSuccess then
				tTasksProcessedThisIteration = tTasksProcessedThisIteration + 1;
				tTotalTasksProcessed = tTotalTasksProcessed + 1;
			end

			VUHDO_DEFERRED_TASK_POOL:release(tTask);
		end

		for _, tTask in ipairs(tCombatSafeTasks) do
			VUHDO_heapInsert(VUHDO_TASK_PRIORITY_QUEUE, tTask, VUHDO_TASK_QUEUE_MAP);
		end

		tIterationCount = tIterationCount + 1;
		VUHDO_checkAllSemaphoreTimeouts();

	until tTasksProcessedThisIteration == 0 or tIterationCount > 10;

	if VUHDO_DEFERRED_TASK_PROFILING_ENABLED then
		VUHDO_Msg("WARNING: Processed " .. tTotalTasksProcessed .. " combat-unsafe tasks in " .. tIterationCount .. " iterations before combat lockdown.");
	end

	if tTotalTasksProcessed > 0 then
		VUHDO_DEFERRED_TASK_STATE["metrics"]["unsafeTasksProcessed"] = (VUHDO_DEFERRED_TASK_STATE["metrics"]["unsafeTasksProcessed"] or 0) + tTotalTasksProcessed;
	end

	return;

end



--
local tTaskTypeCount;
local tTasksToReinsert;
function VUHDO_initTaskSystem()

	if not VUHDO_DEFERRED_TASK_STATE["isInit"] then
		sDeferredTaskDelegates = {
			[VUHDO_DEFER_UPDATE_HEALTH] = _G["VUHDO_updateHealth"],
			[VUHDO_DEFER_UPDATE_HEALTH_BARS_FOR] = _G["VUHDO_updateHealthBarsFor"],
			[VUHDO_DEFER_SET_HEALTH] = _G["VUHDO_setHealth"],
			[VUHDO_DEFER_UPDATE_SHIELD_BAR] = _G["VUHDO_updateShieldBar"],
			[VUHDO_DEFER_UPDATE_HEAL_ABSORB_BAR] = _G["VUHDO_updateHealAbsorbBar"],
			[VUHDO_DEFER_UPDATE_MANA_BARS] = _G["VUHDO_updateManaBars"],
			[VUHDO_DEFER_UPDATE_UNIT_HOTS] = _G["VUHDO_updateUnitHoTs"],
			[VUHDO_DEFER_INIT_ALL_EVENT_BOUQUETS] = _G["VUHDO_deferInitAllEventBouquetsDelegate"],
			[VUHDO_DEFER_UPDATE_BOUQUETS_FOR_EVENT] = _G["VUHDO_updateBouquetsForEvent"],
			[VUHDO_DEFER_UPDATE_UNIT_CYCLIC_BOUQUET] = _G["VUHDO_updateUnitCyclicBouquet"],
			[VUHDO_DEFER_UPDATE_UNIT_DEBUFF_ICONS] = _G["VUHDO_updateUnitDebuffIcons"],
			[VUHDO_DEFER_UPDATE_UNIT_AGGRO] = _G["VUHDO_updateUnitAggro"],
			[VUHDO_DEFER_UPDATE_UNIT_RANGE] = _G["VUHDO_updateUnitRange"],
			[VUHDO_DEFER_UPDATE_ALL_CLUSTERS] = _G["VUHDO_updateAllClusters"],
			[VUHDO_DEFER_UPDATE_CLUSTER_HIGHLIGHTS] = _G["VUHDO_updateClusterHighlights"],
			[VUHDO_DEFER_AOE_UPDATE_ALL] = _G["VUHDO_aoeUpdateAll"],
			[VUHDO_DEFER_UPDATE_SPELL_TRACE] = _G["VUHDO_updateSpellTrace"],
			[VUHDO_DEFER_UPDATE_ALL_RAID_BARS] = _G["VUHDO_deferUpdateAllRaidBarsDelegate"],
			[VUHDO_DEFER_UPDATE_PANEL_BUTTONS] = _G["VUHDO_updatePanelButtons"],
			[VUHDO_DEFER_HANDLE_SCALE_CHANGE] = _G["VUHDO_handleScaleChange"],
			[VUHDO_DEFER_INIT_HEAL_BUTTON] = _G["VUHDO_deferInitHealButtonDelegate"],
			[VUHDO_DEFER_POSITION_HEAL_BUTTON] = _G["VUHDO_deferPositionHealButtonDelegate"],
			[VUHDO_DEFER_REDRAW_PANEL_COMPLETE] = _G["VUHDO_deferRedrawPanelCompleteDelegate"],
			[VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE] = _G["VUHDO_deferInitAllHealButtonsCompleteDelegate"],
			[VUHDO_DEFER_POSITION_CONFIG_PANELS] = _G["VUHDO_deferPositionConfigPanelsDelegate"],
			[VUHDO_DEFER_REDRAW_PANEL] = _G["VUHDO_deferRedrawPanelDelegate"],
			[VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE] = _G["VUHDO_deferRedrawAllPanelsCompleteDelegate"],
			[VUHDO_DEFER_PREWARM_AURA_POOLS] = _G["VUHDO_prewarmAuraFramePoolsChunk"],
			[VUHDO_DEFER_UPDATE_AURA_DISPLAYS_FOR_UNIT] = _G["VUHDO_updateAuraDisplaysForUnit"],
			[VUHDO_DEFER_REFRESH_PRIVATE_AURAS] = _G["VUHDO_refreshPrivateAuras"],
			[VUHDO_DEFER_UPDATE_UNIT_VISIBILITY_CHARM_RANGE] = _G["VUHDO_updateUnitVisibilityCharmRange"],
			[VUHDO_DEFER_REFRESH_PANEL] = _G["VUHDO_deferRefreshPanelDelegate"],
			[VUHDO_DEFER_REFRESH_UI_COMPLETE] = _G["VUHDO_deferRefreshUiCompleteDelegate"],
			[VUHDO_DEFER_REFRESH_PANEL_COMPLETE] = _G["VUHDO_deferRefreshPanelCompleteDelegate"],
			[VUHDO_DEFER_INIT_AURA_CONTAINERS_FOR_BUTTON] = _G["VUHDO_initAuraContainersForButton"],
			[VUHDO_DEFER_SYNC_AURA_CONTAINERS_FOR_UNIT] = _G["VUHDO_syncAuraContainersForUnit"],
			[VUHDO_DEFER_SYNC_OVERLAYS_FOR_UNIT] = _G["VUHDO_syncOverlaysForUnit"],
			[VUHDO_DEFER_DEGRADE_AURA_CACHE_FOR_UNIT] = _G["VUHDO_degradeAuraCacheForUnit"],
			[VUHDO_DEFER_REFRESH_UNIT_AURAS] = _G["VUHDO_fullAuraRefresh"],
			[VUHDO_DEFER_ACQUIRE_OVERLAY_CONTAINER] = _G["VUHDO_acquireOverlayContainerForEntry"],
			[VUHDO_DEFER_FLUSH_PENDING_OVERLAY_REBUILD] = _G["VUHDO_flushPendingOverlayRebuild"],
			[VUHDO_DEFER_VOLATILE_PASS_FOR_BUTTON] = _G["VUHDO_applyVolatilePassForButton"],
			[VUHDO_DEFER_SYNC_SWIFTMEND_OVERLAY_GATES] = _G["VUHDO_syncSwiftmendOverlayGates"],
		};

		tTaskTypeCount = 0;

		if VUHDO_DEFERRED_TASK_TYPES then
			tTaskTypeCount = #VUHDO_DEFERRED_TASK_TYPES;
		end

		VUHDO_DEFERRED_TASK_STATE["invocationCountByType"] = tcreate(0, tTaskTypeCount);
		VUHDO_DEFERRED_TASK_STATE["avgCostUsByType"] = tcreate(0, tTaskTypeCount);
		VUHDO_DEFERRED_TASK_STATE["peakCostUsByType"] = tcreate(0, tTaskTypeCount);

		VUHDO_DEFERRED_TASK_STATE["costHistoryByType"] = { };
		VUHDO_DEFERRED_TASK_STATE["individualCostsByType"] = { };
		VUHDO_DEFERRED_TASK_STATE["budgetStatsByType"] = { };

		VUHDO_resetDeferredTaskMetrics();

		VUHDO_DEFERRED_TASK_POOL = VUHDO_createTablePool(
			"DeferredTask",
			VUHDO_DEFERRED_TASK_POOL_MAX_SIZE,
			VUHDO_createDeferredTaskDelegate,
			VUHDO_cleanupDeferredTaskDelegate
		);

		tTasksToReinsert = VUHDO_extractAllTasksFromQueue();

		for _, tTask in ipairs(tTasksToReinsert) do
			VUHDO_DEFERRED_TASK_POOL:release(tTask);
		end

		sNextTaskEnqueueOrder = 0;

		VUHDO_DEFERRED_TASK_STATE["lastAdjustTime"] = GetTime();
		VUHDO_DEFERRED_TASK_STATE["maxTasksPerFrame"] = VUHDO_DEFERRED_TASK_CONFIG["INITIAL_TASKS_PER_FRAME"];

		VUHDO_processPendingAuraContainerBuilds = _G["VUHDO_processPendingAuraContainerBuilds"];
		VUHDO_processPendingNativeAuraSounds = _G["VUHDO_processPendingNativeAuraSounds"];

		VUHDO_DEFERRED_TASK_STATE["isInit"] = true;
	end

	return;

end