local _;

local pairs = pairs;
local ipairs = ipairs;
local next = next;
local strfind = string.find;
local tostring = tostring;
local twipe = table.wipe;
local format = string.format;
local min = math.min;
local max = math.max;

local sBorderCoordStart = 0.0625;

local InCombatLockdown = InCombatLockdown;
local issecretvalue = issecretvalue;

VUHDO_OVERLAYS_REBUILD_PENDING = false;

local VUHDO_OVERLAY_CONTAINERS = VUHDO_OVERLAY_CONTAINERS;
local VUHDO_OVERLAY_SLOT_HOSTS = VUHDO_OVERLAY_SLOT_HOSTS;
local VUHDO_INDICATOR_OVERLAY_TARGETS = VUHDO_INDICATOR_OVERLAY_TARGETS;
local VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE = "VuhDoAuraButtonOverlayTemplate";
local VUHDO_AURA_BUTTON_ICON_TEMPLATE = "VuhDoAuraButtonIconTemplate";

local VUHDO_PANEL_SETUP;
local VUHDO_BOUQUETS;
local VUHDO_RAID;
local VUHDO_CONFIG;
local VUHDO_INDICATOR_CONFIG;
local VUHDO_BUTTON_CACHE;
local VUHDO_UNIT_BUTTONS;
local VUHDO_BOUQUET_BUFFS_SPECIAL;
local VUHDO_SECRET_TYPE_DISPEL;
local VUHDO_BOUQUET_CUSTOM_TYPE_AURA_GROUP;
local VUHDO_BOUQUET_VALUE_TYPE_NONE;
local VUHDO_BOUQUET_VALUE_TYPE_AURA;
local VUHDO_BOUQUET_VALUE_TYPE_STATUS;
local VUHDO_BOUQUET_VALUE_TYPE_FLAG;
local VUHDO_BOUQUET_STATUS_TYPE_FULL;
local VUHDO_AURA_GROUP_COLOR_OFF;
local VUHDO_AURA_GROUP_COLOR_DISPEL;
local VUHDO_AURA_GROUP_COLOR_ALL_DISPEL;
local VUHDO_AURA_GROUP_COLOR_CUSTOM;
local VUHDO_AURA_GROUP_TYPE_LIST;
local VUHDO_AURA_LIST_ENTRY_SPELL;
local VUHDO_CUSTOM_ICONS;
local VUHDO_AURA_GROUP_TYPE_FILTER;
local VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY;
local VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY;
local VUHDO_MISSING_BUFF_CONTAINERS;
local VUHDO_STATUSBAR_LEFT_TO_RIGHT;
local VUHDO_STATUSBAR_RIGHT_TO_LEFT;
local VUHDO_STATUSBAR_BOTTOM_TO_TOP;
local VUHDO_STATUSBAR_TOP_TO_BOTTOM;

local VUHDO_PixelUtil;

local VUHDO_getUnitButtonsSafe;
local VUHDO_getHealthBar;
local VUHDO_getSideBarWidthLeft;
local VUHDO_getSideBarWidthRight;
local VUHDO_getAuraGroup;
local VUHDO_getAuraGroupEffectiveUnitScope;
local VUHDO_isAuraGroupScopeFriendly;
local VUHDO_isAuraGroupScopeHostile;
local VUHDO_applyAuraGroupScopeFlags;
local VUHDO_getAuraGroupResolvedFilters;
local VUHDO_getCanColorBarGroups;
local VUHDO_getAllDispelTypeNames;
local VUHDO_getPlayerDispelTypeNames;
local VUHDO_getBackgroundDispelTypeNames;
local VUHDO_getAllDispelBarColorTypeNames;
local VUHDO_getPlayerDispelBarColorTypeNames;
local VUHDO_getPlayerPurgeBarColorTypeNames;
local VUHDO_getAllDispelGlowTypeNames;
local VUHDO_getPlayerDispelGlowTypeNames;
local VUHDO_getPlayerPurgeGlowTypeNames;
local VUHDO_copyOverlayCandidateFilters;
local VUHDO_resolveAuraContainerSpellId;
local VUHDO_addResolvedAuraContainerSpellIds;
local VUHDO_getStatusbarOrientationNumber;
local VUHDO_decompressIfCompressed;
local VUHDO_isAuraDataRestricted;
local VUHDO_isAuraModeContainers;
local VUHDO_stopUnitButtonAuraGroupGlow;
local VUHDO_releaseAuraButtonGlowState;
local VUHDO_acquireAuraContainer;
local VUHDO_retireAuraContainer;
local VUHDO_refreshAuraContainer;
local VUHDO_clearOverlaySlotHostUnit;
local VUHDO_clearAuraContainerBinding;
local VUHDO_getAuraContainerBuildSignature;
local VUHDO_getAuraContainerFilterSignature;
local VUHDO_getAuraButtonSetupBuildSignature;
local VUHDO_getAuraButtonSetupVolatileSignature;
local VUHDO_getCandidateFiltersSignature;
local VUHDO_getOverlayHostFrame;
local VUHDO_deferAcquireOverlayContainer;
local VUHDO_deferVolatilePassForButton;
local VUHDO_applyAuraContainerFilterPass;
local VUHDO_reconcileAuraContainerVolatilePass;
local VUHDO_reapplyAuraSlotVolatileSetup;
local VUHDO_updateOverlaySuppressedSlotMetrics;
local VUHDO_deferSyncOverlaysForUnit;
local VUHDO_isSwiftmendReady;
local VUHDO_applyStoredChainBaselineColor;
local VUHDO_showOverlayFillChainBackgroundForData;
local VUHDO_hideOverlayFillChainBackgroundForData;
local VUHDO_getTemplateIdentityGate;
local VUHDO_isCompoundFilterStringTemplate;
local VUHDO_rewriteAuraContainerGateState;
local VUHDO_isAuraDisplaySuppressed;
local VUHDO_reconcileMissingBuffContainersForButton;
local VUHDO_syncMissingBuffContainersForButton;
local VUHDO_clearMissingBuffBuildKey;

local sEmpty = { };
local sInvalidateRemappedButtonNameToUnit = { };
local sOverlayConfigKeys = { };
local sOverlayConfigGeneration = 0;
local sOverlayEntryPrototypeCache = { };
local sOverlayZeroPlanCount = 0;
local sOverlayZeroPlanLastReason = nil;
local sOverlayFilterFlagsCache = { };
local sPendingOverlayBuilds = { };
local sPendingOverlaySlotPlans = { };
local sOverlayContainerPlans = { };
local sHasAnyOverlays = false;
local sSwiftmendGateResyncedUnits = { };

local sOverlayBuild = {
	["fillEntries"] = { },
	["nonFillEntries"] = { },
	["groupOverlayEntries"] = { },
	["canColorGroupEntries"] = { },
	["auraGroupEntries"] = { },
	["overlayClaims"] = { },
	["overlayFilteredEntries"] = { },
	["barGlowFilterEntries"] = { },
	["stampedEntries"] = { },
	["plannedSlotSpecs"] = { },
	["plannedSlotOrder"] = { },
	["plannedSlotSet"] = { },
	["plannedContainerSpecs"] = { },
	["plannedContainerOrder"] = { },
	["plannedContainerSet"] = { },
	["chainGroupKeySet"] = { },
	["sublevelAllocByKey"] = { },
};

local sDispelNameHostile = {
	["Enrage"] = true,
};



--
function VUHDO_isDispelNameHostile(aDispelName)

	return sDispelNameHostile[aDispelName] == true;

end



local sDebuffTypeDispelName = {
	[VUHDO_DEBUFF_TYPE_MAGIC] = "Magic",
	[VUHDO_DEBUFF_TYPE_CURSE] = "Curse",
	[VUHDO_DEBUFF_TYPE_DISEASE] = "Disease",
	[VUHDO_DEBUFF_TYPE_POISON] = "Poison",
	[VUHDO_DEBUFF_TYPE_BLEED] = "Bleed",
	[VUHDO_DEBUFF_TYPE_ENRAGE] = "Enrage",
};

local sOverlaySublevelAllocators = { };
local sOverlaySublevelWarned = { };
local sOverlaySublevelSlots;
local sOverlaySublevelTotal;



do
	--
	local tSlot;
	sOverlaySublevelSlots = { };

	for tSublevel = 2, 7 do
		tSlot = {
			["layer"] = "ARTWORK",
			["sublevel"] = tSublevel,
		};

		sOverlaySublevelSlots[#sOverlaySublevelSlots + 1] = tSlot;
	end

	for tSublevel = -8, 5 do
		tSlot = {
			["layer"] = "OVERLAY",
			["sublevel"] = tSublevel,
		};

		sOverlaySublevelSlots[#sOverlaySublevelSlots + 1] = tSlot;
	end

	sOverlaySublevelTotal = #sOverlaySublevelSlots;
end



--
function VUHDO_auraContainerOverlaysInitLocalOverrides()

	VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];
	VUHDO_BOUQUETS = _G["VUHDO_BOUQUETS"];
	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_INDICATOR_CONFIG = _G["VUHDO_INDICATOR_CONFIG"];
	VUHDO_BUTTON_CACHE = _G["VUHDO_BUTTON_CACHE"];
	VUHDO_UNIT_BUTTONS = _G["VUHDO_UNIT_BUTTONS"];
	VUHDO_BOUQUET_BUFFS_SPECIAL = _G["VUHDO_BOUQUET_BUFFS_SPECIAL"];
	VUHDO_SECRET_TYPE_DISPEL = _G["VUHDO_SECRET_TYPE_DISPEL"];
	VUHDO_BOUQUET_CUSTOM_TYPE_AURA_GROUP = _G["VUHDO_BOUQUET_CUSTOM_TYPE_AURA_GROUP"];
	VUHDO_BOUQUET_VALUE_TYPE_NONE = _G["VUHDO_BOUQUET_VALUE_TYPE_NONE"];
	VUHDO_BOUQUET_VALUE_TYPE_AURA = _G["VUHDO_BOUQUET_VALUE_TYPE_AURA"];
	VUHDO_BOUQUET_VALUE_TYPE_STATUS = _G["VUHDO_BOUQUET_VALUE_TYPE_STATUS"];
	VUHDO_BOUQUET_VALUE_TYPE_FLAG = _G["VUHDO_BOUQUET_VALUE_TYPE_FLAG"];
	VUHDO_BOUQUET_STATUS_TYPE_FULL = _G["VUHDO_BOUQUET_STATUS_TYPE_FULL"];
	VUHDO_AURA_GROUP_COLOR_OFF = _G["VUHDO_AURA_GROUP_COLOR_OFF"];
	VUHDO_AURA_GROUP_COLOR_DISPEL = _G["VUHDO_AURA_GROUP_COLOR_DISPEL"];
	VUHDO_AURA_GROUP_COLOR_ALL_DISPEL = _G["VUHDO_AURA_GROUP_COLOR_ALL_DISPEL"];
	VUHDO_AURA_GROUP_COLOR_CUSTOM = _G["VUHDO_AURA_GROUP_COLOR_CUSTOM"];
	VUHDO_AURA_GROUP_TYPE_LIST = _G["VUHDO_AURA_GROUP_TYPE_LIST"];
	VUHDO_AURA_LIST_ENTRY_SPELL = _G["VUHDO_AURA_LIST_ENTRY_SPELL"];
	VUHDO_CUSTOM_ICONS = _G["VUHDO_CUSTOM_ICONS"];
	VUHDO_AURA_GROUP_TYPE_FILTER = _G["VUHDO_AURA_GROUP_TYPE_FILTER"];
	VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY = _G["VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY"];
	VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY = _G["VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY"];
	VUHDO_MISSING_BUFF_CONTAINERS = _G["VUHDO_MISSING_BUFF_CONTAINERS"];
	VUHDO_STATUSBAR_LEFT_TO_RIGHT = _G["VUHDO_STATUSBAR_LEFT_TO_RIGHT"];
	VUHDO_STATUSBAR_RIGHT_TO_LEFT = _G["VUHDO_STATUSBAR_RIGHT_TO_LEFT"];
	VUHDO_STATUSBAR_BOTTOM_TO_TOP = _G["VUHDO_STATUSBAR_BOTTOM_TO_TOP"];
	VUHDO_STATUSBAR_TOP_TO_BOTTOM = _G["VUHDO_STATUSBAR_TOP_TO_BOTTOM"];

	VUHDO_PixelUtil = _G["VUHDO_PixelUtil"];

	VUHDO_auraContainerOverlaysInitFunctionOverrides();

	return;

end



--
function VUHDO_auraContainerOverlaysInitFunctionOverrides()

	VUHDO_getUnitButtonsSafe = _G["VUHDO_getUnitButtonsSafe"];
	VUHDO_getHealthBar = _G["VUHDO_getHealthBar"];
	VUHDO_getSideBarWidthLeft = _G["VUHDO_getSideBarWidthLeft"];
	VUHDO_getSideBarWidthRight = _G["VUHDO_getSideBarWidthRight"];
	VUHDO_getAuraGroup = _G["VUHDO_getAuraGroup"];
	VUHDO_getAuraGroupEffectiveUnitScope = _G["VUHDO_getAuraGroupEffectiveUnitScope"];
	VUHDO_isAuraGroupScopeFriendly = _G["VUHDO_isAuraGroupScopeFriendly"];
	VUHDO_isAuraGroupScopeHostile = _G["VUHDO_isAuraGroupScopeHostile"];
	VUHDO_applyAuraGroupScopeFlags = _G["VUHDO_applyAuraGroupScopeFlags"];
	VUHDO_getAuraGroupResolvedFilters = _G["VUHDO_getAuraGroupResolvedFilters"];
	VUHDO_getCanColorBarGroups = _G["VUHDO_getCanColorBarGroups"];
	VUHDO_getAllDispelTypeNames = _G["VUHDO_getAllDispelTypeNames"];
	VUHDO_getPlayerDispelTypeNames = _G["VUHDO_getPlayerDispelTypeNames"];
	VUHDO_getBackgroundDispelTypeNames = _G["VUHDO_getBackgroundDispelTypeNames"];
	VUHDO_getAllDispelBarColorTypeNames = _G["VUHDO_getAllDispelBarColorTypeNames"];
	VUHDO_getPlayerDispelBarColorTypeNames = _G["VUHDO_getPlayerDispelBarColorTypeNames"];
	VUHDO_getPlayerPurgeBarColorTypeNames = _G["VUHDO_getPlayerPurgeBarColorTypeNames"];
	VUHDO_getAllDispelGlowTypeNames = _G["VUHDO_getAllDispelGlowTypeNames"];
	VUHDO_getPlayerDispelGlowTypeNames = _G["VUHDO_getPlayerDispelGlowTypeNames"];
	VUHDO_getPlayerPurgeGlowTypeNames = _G["VUHDO_getPlayerPurgeGlowTypeNames"];
	VUHDO_copyOverlayCandidateFilters = _G["VUHDO_copyOverlayCandidateFilters"];
	VUHDO_resolveAuraContainerSpellId = _G["VUHDO_resolveAuraContainerSpellId"];
	VUHDO_addResolvedAuraContainerSpellIds = _G["VUHDO_addResolvedAuraContainerSpellIds"];
	VUHDO_getStatusbarOrientationNumber = _G["VUHDO_getStatusbarOrientationNumber"];
	VUHDO_decompressIfCompressed = _G["VUHDO_decompressIfCompressed"];
	VUHDO_isAuraDataRestricted = _G["VUHDO_isAuraDataRestricted"];
	VUHDO_isAuraModeContainers = _G["VUHDO_isAuraModeContainers"];
	VUHDO_stopUnitButtonAuraGroupGlow = _G["VUHDO_stopUnitButtonAuraGroupGlow"];
	VUHDO_releaseAuraButtonGlowState = _G["VUHDO_releaseAuraButtonGlowState"];
	VUHDO_acquireAuraContainer = _G["VUHDO_acquireAuraContainer"];
	VUHDO_retireAuraContainer = _G["VUHDO_retireAuraContainer"];
	VUHDO_refreshAuraContainer = _G["VUHDO_refreshAuraContainer"];
	VUHDO_clearOverlaySlotHostUnit = _G["VUHDO_clearOverlaySlotHostUnit"];
	VUHDO_clearAuraContainerBinding = _G["VUHDO_clearAuraContainerBinding"];
	VUHDO_getAuraContainerBuildSignature = _G["VUHDO_getAuraContainerBuildSignature"];
	VUHDO_getAuraContainerFilterSignature = _G["VUHDO_getAuraContainerFilterSignature"];
	VUHDO_getAuraButtonSetupBuildSignature = _G["VUHDO_getAuraButtonSetupBuildSignature"];
	VUHDO_getAuraButtonSetupVolatileSignature = _G["VUHDO_getAuraButtonSetupVolatileSignature"];
	VUHDO_getCandidateFiltersSignature = _G["VUHDO_getCandidateFiltersSignature"];
	VUHDO_getOverlayHostFrame = _G["VUHDO_getOverlayHostFrame"];
	VUHDO_deferAcquireOverlayContainer = _G["VUHDO_deferAcquireOverlayContainer"];
	VUHDO_deferVolatilePassForButton = _G["VUHDO_deferVolatilePassForButton"];
	VUHDO_applyAuraContainerFilterPass = _G["VUHDO_applyAuraContainerFilterPass"];
	VUHDO_reconcileAuraContainerVolatilePass = _G["VUHDO_reconcileAuraContainerVolatilePass"];
	VUHDO_reapplyAuraSlotVolatileSetup = _G["VUHDO_reapplyAuraSlotVolatileSetup"];
	VUHDO_updateOverlaySuppressedSlotMetrics = _G["VUHDO_updateOverlaySuppressedSlotMetrics"];
	VUHDO_deferSyncOverlaysForUnit = _G["VUHDO_deferSyncOverlaysForUnit"];
	VUHDO_applyStoredChainBaselineColor = _G["VUHDO_applyStoredChainBaselineColor"];
	VUHDO_showOverlayFillChainBackgroundForData = _G["VUHDO_showOverlayFillChainBackgroundForData"];
	VUHDO_hideOverlayFillChainBackgroundForData = _G["VUHDO_hideOverlayFillChainBackgroundForData"];
	VUHDO_getTemplateIdentityGate = _G["VUHDO_getTemplateIdentityGate"];
	VUHDO_isCompoundFilterStringTemplate = _G["VUHDO_isCompoundFilterStringTemplate"];
	VUHDO_rewriteAuraContainerGateState = _G["VUHDO_rewriteAuraContainerGateState"];
	VUHDO_isAuraDisplaySuppressed = _G["VUHDO_isAuraDisplaySuppressed"];
	VUHDO_reconcileMissingBuffContainersForButton = _G["VUHDO_reconcileMissingBuffContainersForButton"];
	VUHDO_syncMissingBuffContainersForButton = _G["VUHDO_syncMissingBuffContainersForButton"];
	VUHDO_clearMissingBuffBuildKey = _G["VUHDO_clearMissingBuffBuildKey"];
	VUHDO_isSwiftmendReady = _G["VUHDO_isSwiftmendReady"];

	return;

end



do
	--
	local tFilterString;
	function VUHDO_applyOverlayGateFlags(anEntry)

		if not anEntry then
			return;
		end

		tFilterString = anEntry["filterString"];

		anEntry["isHarmful"] = tFilterString and strfind(tFilterString, "HARMFUL", 1, true) ~= nil or false;
		anEntry["identityGate"] = VUHDO_getTemplateIdentityGate(anEntry);
		anEntry["isCompoundFilterString"] = VUHDO_isCompoundFilterStringTemplate(anEntry);

		return;

	end
end



do
	--
	function VUHDO_resetOverlaySublevelAllocator(aTargetFrame)

		if not aTargetFrame then
			return;
		end

		sOverlaySublevelAllocators[aTargetFrame] = 1;

		return;

	end



	--
	local tAllocator;
	local tSlots;
	local tSlotsNeeded;
	local tRemaining;
	local tSlotIndex;
	local tSlot;
	local tWarnKey;
	function VUHDO_allocateOverlaySublevels(aTargetFrame, aSlotCount, anIndicatorKey, aPanelNum)

		tSlots = { };

		if not aTargetFrame or not aSlotCount or aSlotCount <= 0 then
			return tSlots;
		end

		tAllocator = sOverlaySublevelAllocators[aTargetFrame] or 1;
		tSlotsNeeded = aSlotCount;

		if tAllocator + tSlotsNeeded - 1 > sOverlaySublevelTotal then
			tRemaining = sOverlaySublevelTotal - tAllocator + 1;

			if tRemaining < tSlotsNeeded then
				if anIndicatorKey and aPanelNum and not sOverlaySublevelWarned[anIndicatorKey .. ":" .. aPanelNum] then
					tWarnKey = anIndicatorKey .. ":" .. aPanelNum;
					sOverlaySublevelWarned[tWarnKey] = true;

					VUHDO_Msg(format("WARNING: Overlay sublevel budget exhausted for indicator %s on panel %d (%d requested, %d of %d remaining).", anIndicatorKey, aPanelNum, aSlotCount, tRemaining, sOverlaySublevelTotal));
				end

				tSlotsNeeded = tRemaining;

				if tSlotsNeeded <= 0 then
					return tSlots;
				end
			end
		end

		for tCnt = 1, tSlotsNeeded do
			tSlotIndex = tAllocator + tCnt - 1;

			tSlot = sOverlaySublevelSlots[tSlotIndex];

			tSlots[#tSlots + 1] = tSlot;
		end

		sOverlaySublevelAllocators[aTargetFrame] = tAllocator + tSlotsNeeded;

		return tSlots;

	end



	--
	local tCustomSetup;
	local tBarTexture;
	local tOrientation;
	local tBgBar;
	local tOcclusionR;
	local tOcclusionG;
	local tOcclusionB;
	local tOcclusionO;
	local tThreatHeight;
	local tBarButtonSetup;
	local tFillMaskInset;
	function VUHDO_getOverlayBarButtonSetup(aPanelNum, anIndicatorKey, aTargetFrame, aButton)

		tCustomSetup = VUHDO_INDICATOR_CONFIG[aPanelNum] and VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorKey];
		tBarTexture = (tCustomSetup and tCustomSetup["TEXTURE"]) or ((VUHDO_PANEL_SETUP[aPanelNum] or sEmpty)["PANEL_COLOR"] or sEmpty)["barTexture"];
		tOrientation = VUHDO_getStatusbarOrientationNumber(anIndicatorKey, aPanelNum);

		tFillMaskInset = VUHDO_PixelUtil.RoundToPixel(1, 1);

		tBgBar = VUHDO_getHealthBar(aButton, 3);
		tOcclusionR, tOcclusionG, tOcclusionB, tOcclusionO = 0, 0, 0, 1;

		if tBgBar then
			tOcclusionR, tOcclusionG, tOcclusionB, tOcclusionO = tBgBar:GetStatusBarColor();
		end

		tBarButtonSetup = {
			["barTexture"] = tBarTexture,
			["barOrientation"] = tOrientation,
			["barInverted"] = tCustomSetup and tCustomSetup["invertGrowth"],
			["fillMaskTopLeftX"] = (VUHDO_STATUSBAR_LEFT_TO_RIGHT == tOrientation) and -tFillMaskInset or 0,
			["fillMaskTopLeftY"] = (VUHDO_STATUSBAR_TOP_TO_BOTTOM == tOrientation) and tFillMaskInset or 0,
			["fillMaskBottomRightX"] = (VUHDO_STATUSBAR_RIGHT_TO_LEFT == tOrientation) and tFillMaskInset or 0,
			["fillMaskBottomRightY"] = (VUHDO_STATUSBAR_BOTTOM_TO_TOP == tOrientation) and -tFillMaskInset or 0,
			["occlusionColor"] = {
				["R"] = tOcclusionR,
				["G"] = tOcclusionG,
				["B"] = tOcclusionB,
				["O"] = 1,
			},
		};

		if "THREAT_BAR" == anIndicatorKey and aTargetFrame then
			tThreatHeight = (tCustomSetup and tCustomSetup["HEIGHT"]) or aTargetFrame:GetHeight();

			tBarButtonSetup["height"] = tThreatHeight;

			if not InCombatLockdown() then
				VUHDO_PixelUtil.SetHeight(aTargetFrame, tThreatHeight, 1);
			end
		end

		return tBarButtonSetup;

	end



	--
	local tBorderCustomSetup;
	local tBorderButtonSetup;
	function VUHDO_getOverlayBorderButtonSetup(aPanelNum, anIndicatorKey)

		tBorderCustomSetup = VUHDO_INDICATOR_CONFIG[aPanelNum] and VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorKey];

		tBorderButtonSetup = {
			["borderWidth"] = (tBorderCustomSetup and tBorderCustomSetup["WIDTH"]) or 1,
			["borderFile"] = (tBorderCustomSetup and tBorderCustomSetup["FILE"]) or "Interface\\AddOns\\VuhDo\\Images\\white_square_16_16",
		};

		return tBorderButtonSetup;

	end
end



do
	--
	local tModeItemSpecial;
	local function VUHDO_getBouquetItemValueType(aItem)

		tModeItemSpecial = VUHDO_BOUQUET_BUFFS_SPECIAL[aItem["name"]];

		if not tModeItemSpecial then
			return VUHDO_BOUQUET_VALUE_TYPE_AURA;
		end

		return tModeItemSpecial["valueType"] or VUHDO_BOUQUET_VALUE_TYPE_NONE;

	end



	--
	local tModeItem;
	local tModeItemValueType;
	local tValueItem;
	local tValueSpecial;
	local tHasHigherStatusItem;
	local tHasCoverContributor;
	local tGateValidators;
	local tGateIdx;
	local tItemShadowValueMode;
	function VUHDO_resolveOverlayShadowValueMode(aBouquet, aItemIdx, anOverlayTarget)

		tModeItem = aBouquet[aItemIdx];
		tModeItemValueType = VUHDO_getBouquetItemValueType(tModeItem);
		tItemShadowValueMode = tModeItemValueType == VUHDO_BOUQUET_VALUE_TYPE_FLAG and "cover" or "duration";

		if anOverlayTarget and anOverlayTarget["barValue"] == "binary" then

			if tModeItemValueType == VUHDO_BOUQUET_VALUE_TYPE_NONE then
				return "mirror";
			end

			return "cover";
		end

		if anOverlayTarget and anOverlayTarget["barValue"] == "bouquet" then

			if tModeItemValueType == VUHDO_BOUQUET_VALUE_TYPE_NONE then
				return "mirror";
			end

			if tModeItemValueType == VUHDO_BOUQUET_VALUE_TYPE_AURA or tModeItemValueType == VUHDO_BOUQUET_VALUE_TYPE_FLAG then
				tHasHigherStatusItem = false;
				tHasCoverContributor = false;
				tGateValidators = nil;
				tGateIdx = 0;

				for tScan = 1, aItemIdx - 1 do
					tValueItem = aBouquet[tScan];
					tValueSpecial = VUHDO_BOUQUET_BUFFS_SPECIAL[tValueItem["name"]];

					if tValueSpecial and tValueSpecial["valueType"] == VUHDO_BOUQUET_VALUE_TYPE_STATUS then
						if tValueSpecial["isSecretInactive"] then
						elseif tValueSpecial["isActiveOnly"] then
							if tValueSpecial["statusType"] and VUHDO_BOUQUET_STATUS_TYPE_FULL ~= tValueSpecial["statusType"] then
								return "mirror";
							end

							tHasHigherStatusItem = true;
							tHasCoverContributor = true;
						elseif tValueSpecial["gateValidator"] then
							tHasHigherStatusItem = true;

							if not tGateValidators then
								tGateValidators = { };
							end

							tGateIdx = tGateIdx + 1;
							tGateValidators[tGateIdx] = tValueSpecial["gateValidator"];
						else
							return "mirror";
						end
					end
				end

				if not tHasHigherStatusItem then
					return tItemShadowValueMode;
				end

				if tGateValidators then
					if tHasCoverContributor then
						return "cover", tGateValidators;
					end

					return tItemShadowValueMode, tGateValidators;
				end

				if tHasCoverContributor then
					return "cover";
				end

				return "mirror";
			end

			return "cover";
		end

		return "cover";

	end



	--
	local tFallbackEntry;
	local function VUHDO_shallowCopyOverlayEntry(anEntry)

		tFallbackEntry = { };

		for tCopyKey, tCopyValue in pairs(anEntry) do
			tFallbackEntry[tCopyKey] = tCopyValue;
		end

		return tFallbackEntry;

	end



	--
	local tFallbackEntry;
	local tActiveEntry;
	function VUHDO_appendOverlayEntryWithVariants(aDest, anEntry, aFallbackMode, aGateValidators)

		if not aGateValidators then
			if aFallbackMode then
				anEntry["shadowValueMode"] = aFallbackMode;
			end

			aDest[#aDest + 1] = anEntry;

			return;
		end

		tFallbackEntry = VUHDO_shallowCopyOverlayEntry(anEntry);

		tFallbackEntry["shadowValueMode"] = aFallbackMode;
		tFallbackEntry["valueGates"] = aGateValidators;
		tFallbackEntry["entryKey"] = anEntry["entryKey"] .. ":gatefallback";

		tActiveEntry = VUHDO_shallowCopyOverlayEntry(anEntry);

		tActiveEntry["shadowValueMode"] = "mirror";
		tActiveEntry["valueGates"] = aGateValidators;
		tActiveEntry["isValueGateActiveVariant"] = true;
		tActiveEntry["entryKey"] = anEntry["entryKey"] .. ":gateactive";

		aDest[#aDest + 1] = tFallbackEntry;
		aDest[#aDest + 1] = tActiveEntry;

		return;

	end



	--
	local tGateDelegate;
	function VUHDO_isAnyOverlayValueGateActive(aGates, anInfo)

		if not aGates or not anInfo then
			return false;
		end

		for tCnt = 1, #aGates do
			tGateDelegate = aGates[tCnt];

			if tGateDelegate(anInfo) then
				return true;
			end
		end

		return false;

	end
end



do
	--
	local tBaseOpacityItem;
	local tBaseOpacityColor;
	local tBaseOpacityProduct;
	function VUHDO_computeOverlayBaseOpacityProduct(aBouquet)

		tBaseOpacityProduct = nil;

		for tCnt = #aBouquet, 1, -1 do
			tBaseOpacityItem = aBouquet[tCnt];

			if tBaseOpacityItem["name"] == "ALWAYS" then
				tBaseOpacityColor = tBaseOpacityItem["color"];

				if tBaseOpacityColor then
					if tBaseOpacityColor["useOpacity"] and tBaseOpacityColor["O"] ~= nil then
						tBaseOpacityProduct = (tBaseOpacityProduct or 1) * tBaseOpacityColor["O"];
					elseif tBaseOpacityColor["useBackground"] and tBaseOpacityColor["O"] ~= nil then
						tBaseOpacityProduct = tBaseOpacityColor["O"];
					end
				end
			end
		end

		if not tBaseOpacityProduct or tBaseOpacityProduct >= 1 then
			return nil;
		end

		return tBaseOpacityProduct;

	end



	--
	local tEntryOpacity;
	local function VUHDO_getOverlayEntryOpacity(aItem, aColorO, aBaseProduct)

		if not (aItem and aItem["color"] and aItem["color"]["useOpacity"]) then
			return nil;
		end

		tEntryOpacity = aBaseProduct or 1;

		if aColorO ~= nil then
			tEntryOpacity = tEntryOpacity * aColorO;
		end

		if tEntryOpacity >= 1 then
			return nil;
		end

		return tEntryOpacity;

	end



	--
	local tBrightFactor;
	function VUHDO_getOverlayItemDispelBright(aItem)

		tBrightFactor = aItem and aItem["custom"] and aItem["custom"]["bright"];

		if tBrightFactor and tBrightFactor < 1 then
			return tBrightFactor;
		end

		return nil;

	end



	--
	function VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct)

		return VUHDO_getOverlayEntryOpacity(aItem, aItem and aItem["color"] and aItem["color"]["O"], aBaseProduct);

	end



	--
	local tDerivedColor;
	local tBrightFactor;
	local tEntryOpacity;
	function VUHDO_applyOverlayStaticColorBright(aStaticColor, aItem, aBaseProduct)

		if not aStaticColor then
			return nil;
		end

		tBrightFactor = aItem and aItem["custom"] and aItem["custom"]["bright"];

		tEntryOpacity = aStaticColor["useOpacity"] and VUHDO_getOverlayEntryOpacity(aItem, aStaticColor["O"], aBaseProduct) or nil;

		if (not tBrightFactor or tBrightFactor >= 1) and not tEntryOpacity then
			return aStaticColor;
		end

		tDerivedColor = {
			["R"] = aStaticColor["R"] or 0,
			["G"] = aStaticColor["G"] or 0,
			["B"] = aStaticColor["B"] or 0,
			["O"] = tEntryOpacity or aStaticColor["O"] or 1,
			["TR"] = aStaticColor["TR"],
			["TG"] = aStaticColor["TG"],
			["TB"] = aStaticColor["TB"],
			["TO"] = aStaticColor["TO"],
			["useBackground"] = aStaticColor["useBackground"],
			["useText"] = aStaticColor["useText"],
			["useOpacity"] = aStaticColor["useOpacity"],
			["useBorder"] = aStaticColor["useBorder"],
			["isManuallySet"] = aStaticColor["isManuallySet"],
		};

		if tBrightFactor and tBrightFactor < 1 then
			tDerivedColor["R"] = tDerivedColor["R"] * tBrightFactor;
			tDerivedColor["G"] = tDerivedColor["G"] * tBrightFactor;
			tDerivedColor["B"] = tDerivedColor["B"] * tBrightFactor;
		end

		return tDerivedColor;

	end



	--
	function VUHDO_applyOverlayShapePrototypeFields(anOverlayEntry, anOverlayTarget)

		if anOverlayTarget["shape"] == "bar" then
			anOverlayEntry["shadowBar"] = true;
		elseif anOverlayTarget["shape"] == "border" then
			if anOverlayEntry["staticColor"] and not anOverlayEntry["dispelBorder"] then
				anOverlayEntry["border"] = true;
			end
		end

		return;

	end



	--
	function VUHDO_stampOverlayEntryShapeFields(anOverlayEntry, anOverlayTarget, aBarButtonSetup, aBorderButtonSetup)

		if anOverlayTarget["shape"] == "bar" and anOverlayEntry["shadowBar"] and aBarButtonSetup then
			for tKey, tValue in pairs(aBarButtonSetup) do
				anOverlayEntry[tKey] = tValue;
			end
		elseif anOverlayTarget["shape"] == "border" and (anOverlayEntry["border"] or anOverlayEntry["dispelBorder"]) and aBorderButtonSetup then
			for tKey, tValue in pairs(aBorderButtonSetup) do
				anOverlayEntry[tKey] = tValue;
			end
		end

		return;

	end



	--
	function VUHDO_applyOverlayDotIconFields(anOverlayEntry, anItem, anIconColor, anOverlayTarget)

		if anOverlayTarget and anOverlayTarget["staticIcon"] then
			anOverlayEntry["staticIcon"] = anOverlayTarget["staticIcon"];

			if anIconColor then
				anOverlayEntry["staticColor"] = anIconColor;
			end

			return;
		end

		if anItem["icon"] and anItem["icon"] ~= 1 then
			anOverlayEntry["staticIcon"] = VUHDO_CUSTOM_ICONS[anItem["icon"]][2];

			if anIconColor then
				anOverlayEntry["staticColor"] = anIconColor;
			end
		else
			anOverlayEntry["staticColor"] = nil;
			anOverlayEntry["templateName"] = VUHDO_AURA_BUTTON_ICON_TEMPLATE;

			if anIconColor then
				anOverlayEntry["iconColor"] = anIconColor;
			end
		end

		return;

	end
end



do
	--
	local tHostileDispelEntry;
	function VUHDO_buildHostileDispelEntry(aDispelTypeNames, aFilterString, aCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, anSetEntryKey, anIsGlowFilterSpec)

		if not aDispelTypeNames or next(aDispelTypeNames) == nil then
			return nil;
		end

		if anIsGlowFilterSpec then
			return {
				["filterString"] = aFilterString or "HELPFUL",
				["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(aCandidateFilters, aDispelTypeNames),
				["hostileOnly"] = true,
				["entryKeySuffix"] = ":hostile",
			};
		end

		tHostileDispelEntry = {
			["filterString"] = aFilterString or "HELPFUL",
			["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(aCandidateFilters, aDispelTypeNames),
			["shape"] = aOverlayTarget["shape"],
			["bouquetIdx"] = aBouquetIdx,
			["groupKey"] = aGroupKey,
			["shadowValueMode"] = aShadowValueMode,
			["hostileOnly"] = true,
		};

		if anSetEntryKey then
			tHostileDispelEntry["entryKey"] = aBouquetIdx .. ":hostile";
		end

		if aOverlayTarget["shape"] == "bar" then
			tHostileDispelEntry["dispelFill"] = true;
		elseif aOverlayTarget["shape"] == "border" then
			tHostileDispelEntry["dispelBorder"] = true;
		elseif aOverlayTarget["shape"] == "dot" then
			tHostileDispelEntry["dispelIcon"] = true;

			VUHDO_applyOverlayDotIconFields(tHostileDispelEntry, aItem, nil, aOverlayTarget);
		end

		tHostileDispelEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
		tHostileDispelEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

		VUHDO_applyOverlayShapePrototypeFields(tHostileDispelEntry, aOverlayTarget);

		return tHostileDispelEntry;

	end



	--
	local tResolved;
	local tFilterString;
	local tCandidateFilters;
	local tCandidateBranches;
	local tBranchFilterStrings;
	local tOverlayEntry;
	local tItemColor;
	local tHostileEntry;
	local tDispelTypeNames;
	local tBranchEntryStart;
	local tUnitScope;
	local function VUHDO_buildAuraGroupOverlayEntries(aGroup, aGroupKey, aEffectiveColorType, aCustomColor, aItem, aOverlayTarget, aBouquetIdx, aShadowValueMode, aBaseProduct)

		twipe(sOverlayBuild["groupOverlayEntries"]);

		tResolved = VUHDO_getAuraGroupResolvedFilters(aGroup);

		if not tResolved then
			return sOverlayBuild["groupOverlayEntries"];
		end

		tUnitScope = VUHDO_getAuraGroupEffectiveUnitScope(aGroup);

		tFilterString = tResolved["filterString"];

		tCandidateBranches = tResolved["candidateBranches"];
		tBranchFilterStrings = tResolved["candidateBranchFilterStrings"];

		if not tCandidateBranches or #tCandidateBranches == 0 then
			tCandidateBranches = { tResolved["candidateFilters"] };
		end

		for tBranchIdx = 1, #tCandidateBranches do
			tBranchEntryStart = #sOverlayBuild["groupOverlayEntries"] + 1;

			tCandidateFilters = VUHDO_copyOverlayCandidateFilters(tCandidateBranches[tBranchIdx], nil);
			tFilterString = (tBranchFilterStrings and tBranchFilterStrings[tBranchIdx]) or tResolved["filterString"];

			if aOverlayTarget["shape"] == "bar" then
				if aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM and aCustomColor then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = tCandidateFilters,
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = aGroupKey,
						["shadowValueMode"] = aShadowValueMode,
						["staticColor"] = VUHDO_applyOverlayStaticColorBright(aCustomColor, aItem, aBaseProduct),
					};

					VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

					VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);

					sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF then
					tItemColor = aItem["color"];

					if tItemColor and tItemColor["useBackground"] then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = tCandidateFilters,
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["staticColor"] = VUHDO_applyOverlayStaticColorBright(tItemColor, aItem, aBaseProduct),
						};

						VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

						VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
					tDispelTypeNames = VUHDO_getPlayerDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelFill"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getPlayerPurgeBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
					tDispelTypeNames = VUHDO_getAllDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelFill"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getAllDispelBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				end
			elseif aOverlayTarget["shape"] == "border" then
				if aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM and aCustomColor then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = tCandidateFilters,
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = aGroupKey,
						["shadowValueMode"] = aShadowValueMode,
						["staticColor"] = VUHDO_applyOverlayStaticColorBright(aCustomColor, aItem, aBaseProduct),
						["border"] = true,
					};

					VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);

					sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF then
					tItemColor = aItem["color"];

					if tItemColor and tItemColor["useBackground"] then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = tCandidateFilters,
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["staticColor"] = VUHDO_applyOverlayStaticColorBright(tItemColor, aItem, aBaseProduct),
							["border"] = true,
						};

						VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
					tDispelTypeNames = VUHDO_getPlayerDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelBorder"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getPlayerPurgeBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
					tDispelTypeNames = VUHDO_getAllDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelBorder"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getAllDispelBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				end
			elseif aOverlayTarget["shape"] == "dot" then
				tOverlayEntry = nil;
				tItemColor = aItem["color"];

				if aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM and aCustomColor then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = tCandidateFilters,
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = aGroupKey,
						["shadowValueMode"] = aShadowValueMode,
						["staticColor"] = VUHDO_applyOverlayStaticColorBright(aCustomColor, aItem, aBaseProduct),
					};

					VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);
				elseif tItemColor and tItemColor["useBackground"] then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = tCandidateFilters,
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = aGroupKey,
						["shadowValueMode"] = aShadowValueMode,
						["staticColor"] = VUHDO_applyOverlayStaticColorBright(tItemColor, aItem, aBaseProduct),
					};
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
					tDispelTypeNames = VUHDO_getPlayerDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelIcon"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						VUHDO_applyOverlayDotIconFields(tOverlayEntry, aItem, nil, aOverlayTarget);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getPlayerPurgeBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
					tDispelTypeNames = VUHDO_getAllDispelBarColorTypeNames();

					if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
						tOverlayEntry = {
							["filterString"] = tFilterString,
							["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
							["shape"] = aOverlayTarget["shape"],
							["bouquetIdx"] = aBouquetIdx,
							["groupKey"] = aGroupKey,
							["shadowValueMode"] = aShadowValueMode,
							["dispelIcon"] = true,
							["friendlyOnly"] = true,
						};

						tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
						tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

						VUHDO_applyOverlayDotIconFields(tOverlayEntry, aItem, nil, aOverlayTarget);

						sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
					end

					if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
						tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getAllDispelBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, aGroupKey, aShadowValueMode, aItem, aBaseProduct, false, false);

						if tHostileEntry then
							sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tHostileEntry;
						end
					end
				end

				if tOverlayEntry and not tOverlayEntry["dispelIcon"] then
					VUHDO_applyOverlayDotIconFields(tOverlayEntry, aItem, tOverlayEntry["staticColor"], aOverlayTarget);

					if aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM and aCustomColor then
						VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);
					elseif aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF then
						VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, aGroup);
					end

					sOverlayBuild["groupOverlayEntries"][#sOverlayBuild["groupOverlayEntries"] + 1] = tOverlayEntry;
				end
			end

			for tBranchStampIdx = tBranchEntryStart, #sOverlayBuild["groupOverlayEntries"] do
				sOverlayBuild["groupOverlayEntries"][tBranchStampIdx]["branchIdx"] = tBranchIdx;
			end
		end

		return sOverlayBuild["groupOverlayEntries"];

	end



	--
	local tGroupId;
	local tGroup;
	local tEffectiveColorType;
	local tResolved;
	local tFilterString;
	local tCandidateFilters;
	local tCandidateBranches;
	local tBranchFilterStrings;
	local tOverlayEntry;
	local tHostileEntry;
	local tDispelTypeNames;
	function VUHDO_buildCanColorBarGroupOverlayEntries(aCanColorGroup, aItem, aOverlayTarget, aBouquetIdx, aShadowValueMode, aBaseProduct)

		twipe(sOverlayBuild["canColorGroupEntries"]);

		if not aCanColorGroup["canColorBar"] then
			return sOverlayBuild["canColorGroupEntries"];
		end

		tGroupId = aCanColorGroup["groupId"];
		tGroup = VUHDO_getAuraGroup(tGroupId);

		if not tGroup then
			return sOverlayBuild["canColorGroupEntries"];
		end

		tUnitScope = aCanColorGroup["unitScope"] or VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

		tEffectiveColorType = aCanColorGroup["colorType"] or VUHDO_AURA_GROUP_COLOR_DISPEL;

		tResolved = VUHDO_getAuraGroupResolvedFilters(tGroup);

		if not tResolved then
			return sOverlayBuild["canColorGroupEntries"];
		end

		if not tResolved["expressible"] then
			if not (tResolved["candidateFilters"] and tResolved["candidateFilters"]["includeSpellIDs"]) then
				return sOverlayBuild["canColorGroupEntries"];
			end
		end

		tFilterString = tResolved["filterString"];

		tCandidateBranches = tResolved["candidateBranches"];
		tBranchFilterStrings = tResolved["candidateBranchFilterStrings"];

		if not tCandidateBranches or #tCandidateBranches == 0 then
			tCandidateBranches = { tResolved["candidateFilters"] };
		end

		for tBranchIdx = 1, #tCandidateBranches do
			tBranchEntryStart = #sOverlayBuild["canColorGroupEntries"] + 1;

			tCandidateFilters = VUHDO_copyOverlayCandidateFilters(tCandidateBranches[tBranchIdx], nil);
			tFilterString = (tBranchFilterStrings and tBranchFilterStrings[tBranchIdx]) or tResolved["filterString"];

			if tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM and aCanColorGroup["customColor"] then
				tOverlayEntry = {
					["filterString"] = tFilterString,
					["candidateFilters"] = tCandidateFilters,
					["shape"] = aOverlayTarget["shape"],
					["bouquetIdx"] = aBouquetIdx,
					["groupKey"] = tGroupId,
					["shadowValueMode"] = aShadowValueMode,
					["staticColor"] = VUHDO_applyOverlayStaticColorBright(aCanColorGroup["customColor"], aItem, aBaseProduct),
				};

				VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

				VUHDO_applyAuraGroupScopeFlags(tOverlayEntry, tGroup);

				sOverlayBuild["canColorGroupEntries"][#sOverlayBuild["canColorGroupEntries"] + 1] = tOverlayEntry;
			elseif tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
				tDispelTypeNames = VUHDO_getPlayerDispelBarColorTypeNames();

				if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = tGroupId,
						["shadowValueMode"] = aShadowValueMode,
						["friendlyOnly"] = true,
					};

					if aOverlayTarget["shape"] == "bar" then
						tOverlayEntry["dispelFill"] = true;
					elseif aOverlayTarget["shape"] == "border" then
						tOverlayEntry["dispelBorder"] = true;
					elseif aOverlayTarget["shape"] == "dot" then
						tOverlayEntry["dispelIcon"] = true;

						VUHDO_applyOverlayDotIconFields(tOverlayEntry, aItem, nil, aOverlayTarget);
					end

					tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
					tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

					VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

					sOverlayBuild["canColorGroupEntries"][#sOverlayBuild["canColorGroupEntries"] + 1] = tOverlayEntry;
				end

				if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
					tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getPlayerPurgeBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, tGroupId, aShadowValueMode, aItem, aBaseProduct, true, false);

					if tHostileEntry then
						sOverlayBuild["canColorGroupEntries"][#sOverlayBuild["canColorGroupEntries"] + 1] = tHostileEntry;
					end
				end
			elseif tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
				tDispelTypeNames = VUHDO_getAllDispelBarColorTypeNames();

				if VUHDO_isAuraGroupScopeFriendly(tUnitScope) and next(tDispelTypeNames) ~= nil then
					tOverlayEntry = {
						["filterString"] = tFilterString,
						["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tCandidateFilters, tDispelTypeNames),
						["shape"] = aOverlayTarget["shape"],
						["bouquetIdx"] = aBouquetIdx,
						["groupKey"] = tGroupId,
						["shadowValueMode"] = aShadowValueMode,
						["friendlyOnly"] = true,
					};

					if aOverlayTarget["shape"] == "bar" then
						tOverlayEntry["dispelFill"] = true;
					elseif aOverlayTarget["shape"] == "border" then
						tOverlayEntry["dispelBorder"] = true;
					elseif aOverlayTarget["shape"] == "dot" then
						tOverlayEntry["dispelIcon"] = true;

						VUHDO_applyOverlayDotIconFields(tOverlayEntry, aItem, nil, aOverlayTarget);
					end

					tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(aItem);
					tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(aItem, aBaseProduct);

					VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, aOverlayTarget);

					sOverlayBuild["canColorGroupEntries"][#sOverlayBuild["canColorGroupEntries"] + 1] = tOverlayEntry;
				end

				if VUHDO_isAuraGroupScopeHostile(tUnitScope) then
					tHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getAllDispelBarColorTypeNames(), tFilterString, tCandidateFilters, aOverlayTarget, aBouquetIdx, tGroupId, aShadowValueMode, aItem, aBaseProduct, true, false);

					if tHostileEntry then
						sOverlayBuild["canColorGroupEntries"][#sOverlayBuild["canColorGroupEntries"] + 1] = tHostileEntry;
					end
				end
			end

			for tBranchStampIdx = tBranchEntryStart, #sOverlayBuild["canColorGroupEntries"] do
				sOverlayBuild["canColorGroupEntries"][tBranchStampIdx]["branchIdx"] = tBranchIdx;
			end
		end

		return sOverlayBuild["canColorGroupEntries"];

	end



	--
	local tAuraGroupId;
	local tAuraGroup;
	local tResolved;
	local tEffectiveColorType;
	function VUHDO_buildAuraGroupActiveOverlayEntries(aItem, aOverlayTarget, aBouquetIdx, aShadowValueMode, aBaseProduct)

		twipe(sOverlayBuild["auraGroupEntries"]);

		tAuraGroupId = aItem["custom"] and aItem["custom"]["auraGroupId"];
		tAuraGroup = VUHDO_getAuraGroup(tAuraGroupId);

		tResolved = VUHDO_getAuraGroupResolvedFilters(tAuraGroup);

		if not tAuraGroup or not tResolved or not tResolved["expressible"] then
			return sOverlayBuild["auraGroupEntries"];
		end

		tEffectiveColorType = tAuraGroup["colorType"] or VUHDO_AURA_GROUP_COLOR_OFF;

		return VUHDO_buildAuraGroupOverlayEntries(tAuraGroup, tAuraGroupId, tEffectiveColorType, tAuraGroup["customColor"], aItem, aOverlayTarget, aBouquetIdx, aShadowValueMode, aBaseProduct);

	end



	--
	local tBarColors;
	function VUHDO_isBarColorsDispelOverlayConfigured()

		tBarColors = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"];

		return tBarColors and tBarColors["showDispelOverlay"] and (tBarColors["dispelIndicatorType"] or 1) > 0;

	end



	--
	local tBarColors;
	local tDispelIndicatorType;
	local tFilterString;
	local tCandidateFilters;
	local tDispelTypeNames;
	function VUHDO_buildBarColorsDispelOverlayEntry()

		tBarColors = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"];

		if not tBarColors or not tBarColors["showDispelOverlay"] then
			return nil;
		end

		tDispelIndicatorType = tBarColors["dispelIndicatorType"] or 1;

		if tDispelIndicatorType <= 0 then
			return nil;
		end

		if tDispelIndicatorType == 2 then
			tFilterString = "HARMFUL|DISPELLABLE";
			tDispelTypeNames = VUHDO_getAllDispelTypeNames();
		else
			tFilterString = "HARMFUL|DISPELLABLE";
			tDispelTypeNames = VUHDO_getPlayerDispelTypeNames();
		end

		tCandidateFilters = VUHDO_copyOverlayCandidateFilters(nil, tDispelTypeNames);

		return {
			["filterString"] = tFilterString,
			["candidateFilters"] = tCandidateFilters,
			["shape"] = "bar",
			["entryKey"] = "barColorsDispelOverlay",
			["frameLevelOffset"] = 8,
			["friendlyOnly"] = true,
			["dispelOverlayChrome"] = true,
			["templateName"] = VUHDO_AURA_BUTTON_DISPEL_OVERLAY_TEMPLATE,
		};

	end



	--
	local tHostilePurgeTypeNames;
	function VUHDO_buildBarColorsHostilePurgeOverlayEntry()

		tBarColors = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"];

		if not tBarColors or not tBarColors["showDispelOverlay"] then
			return nil;
		end

		tDispelIndicatorType = tBarColors["dispelIndicatorType"] or 1;

		if tDispelIndicatorType <= 0 then
			return nil;
		end

		if tDispelIndicatorType == 2 then
			tHostilePurgeTypeNames = {
				["Magic"] = true,
				["Enrage"] = true,
			};
		else
			tHostilePurgeTypeNames = VUHDO_getPlayerPurgeDispelTypeNames();
		end

		if next(tHostilePurgeTypeNames) == nil then
			return nil;
		end

		tFilterString = "HELPFUL|DISPELLABLE";
		tCandidateFilters = VUHDO_copyOverlayCandidateFilters(nil, tHostilePurgeTypeNames);

		return {
			["filterString"] = tFilterString,
			["candidateFilters"] = tCandidateFilters,
			["shape"] = "bar",
			["entryKey"] = "barColorsHostilePurgeOverlay",
			["frameLevelOffset"] = 8,
			["hostileOnly"] = true,
			["dispelOverlayChrome"] = true,
			["templateName"] = VUHDO_AURA_BUTTON_DISPEL_OVERLAY_TEMPLATE,
		};

	end



	--
	local tOverlayTarget;
	local tGetter;
	function VUHDO_resolveOverlayTarget(aButton, anIndicatorKey)

		tOverlayTarget = VUHDO_INDICATOR_OVERLAY_TARGETS[anIndicatorKey];

		if not tOverlayTarget then
			return nil;
		end

		tGetter = _G[tOverlayTarget["getter"]];

		if tOverlayTarget["isBarRelative"] then
			return tGetter(VUHDO_getHealthBar(aButton, tOverlayTarget["barIndex"]));
		elseif tOverlayTarget["barIndex"] then
			return tGetter(aButton, tOverlayTarget["barIndex"]);
		elseif tOverlayTarget["iconIndex"] then
			return tGetter(aButton, tOverlayTarget["iconIndex"]);
		end

		return tGetter(aButton);

	end
end



do
	--
	local tOverlayClaimFlags;
	local function VUHDO_getOverlayFilterFlags(aFilterString)

		if not aFilterString then
			return nil;
		end

		tOverlayClaimFlags = sOverlayFilterFlagsCache[aFilterString];

		if tOverlayClaimFlags then
			return tOverlayClaimFlags;
		end

		tOverlayClaimFlags = { };

		for tOverlayClaimFlag in string.gmatch(aFilterString, "[^|]+") do
			tOverlayClaimFlags[tOverlayClaimFlag] = true;
		end

		sOverlayFilterFlagsCache[aFilterString] = tOverlayClaimFlags;

		return tOverlayClaimFlags;

	end



	--
	local tOverlayClaimFlags;
	local tOverlayEntryFlags;
	local function VUHDO_isOverlayFilterSubset(aClaimFilterString, anEntryFilterString)

		tOverlayClaimFlags = VUHDO_getOverlayFilterFlags(aClaimFilterString);
		tOverlayEntryFlags = VUHDO_getOverlayFilterFlags(anEntryFilterString);

		if not tOverlayClaimFlags or not tOverlayEntryFlags then
			return false;
		end

		for tOverlayClaimFlag in pairs(tOverlayClaimFlags) do
			if not tOverlayEntryFlags[tOverlayClaimFlag] then
				return false;
			end
		end

		return true;

	end



	--
	local function VUHDO_isOverlayEntryClaimCompatible(aClaim, anEntry)

		if not VUHDO_isOverlayFilterSubset(aClaim["filterString"], anEntry["filterString"]) then
			return false;
		end

		if aClaim["hostileOnly"] and not anEntry["hostileOnly"] then
			return false;
		end

		if aClaim["friendlyOnly"] and not anEntry["friendlyOnly"] then
			return false;
		end

		return true;

	end



	--
	local tOverlayClaims;
	local tOverlayFilteredEntries;
	local tOverlayCandidateFilters;
	local tOverlayClaim;
	local tOverlayEntrySpellIds;
	local tOverlayIsFullyCovered;
	local tOverlayEntry;
	local tSuppressResult;
	local function VUHDO_suppressOverlayEntriesClaimedByHigherPriority(anOverlayEntries)

		if not anOverlayEntries or #anOverlayEntries <= 1 then
			return anOverlayEntries;
		end

		twipe(sOverlayBuild["overlayClaims"]);
		twipe(sOverlayBuild["overlayFilteredEntries"]);

		tOverlayClaims = sOverlayBuild["overlayClaims"];
		tOverlayFilteredEntries = sOverlayBuild["overlayFilteredEntries"];

		for tCnt = 1, #anOverlayEntries do
			tOverlayEntry = anOverlayEntries[tCnt];
			tOverlayCandidateFilters = tOverlayEntry["candidateFilters"];
			tOverlayEntrySpellIds = tOverlayCandidateFilters and tOverlayCandidateFilters["includeSpellIDs"];

			tOverlayIsFullyCovered = false;

			if tOverlayEntrySpellIds then
				tOverlayIsFullyCovered = true;

				for tOverlaySpellId in pairs(tOverlayEntrySpellIds) do
					tOverlayClaim = nil;

					for tOverlayClaimCnt = 1, #tOverlayClaims do
						if tOverlayClaims[tOverlayClaimCnt]["spellIds"][tOverlaySpellId] and VUHDO_isOverlayEntryClaimCompatible(tOverlayClaims[tOverlayClaimCnt], tOverlayEntry) then
							tOverlayClaim = tOverlayClaims[tOverlayClaimCnt];

							break;
						end
					end

					if not tOverlayClaim then
						tOverlayIsFullyCovered = false;

						break;
					end
				end
			end

			if not tOverlayIsFullyCovered then
				tOverlayFilteredEntries[#tOverlayFilteredEntries + 1] = tOverlayEntry;

				if tOverlayEntrySpellIds then
					tOverlayClaims[#tOverlayClaims + 1] = {
						["filterString"] = tOverlayEntry["filterString"],
						["hostileOnly"] = tOverlayEntry["hostileOnly"],
						["friendlyOnly"] = tOverlayEntry["friendlyOnly"],
						["spellIds"] = tOverlayEntrySpellIds,
					};
				end
			end
		end

		if #tOverlayFilteredEntries == 0 then
			return nil;
		end

		if #tOverlayFilteredEntries == #anOverlayEntries then
			return anOverlayEntries;
		end

		tSuppressResult = { };

		for tCnt = 1, #tOverlayFilteredEntries do
			tSuppressResult[tCnt] = tOverlayFilteredEntries[tCnt];
		end

		return tSuppressResult;

	end



	--
	local function VUHDO_getOverlaySpellFilterString(aItem)

		if aItem["mine"] ~= false and aItem["others"] ~= true then
			return "HELPFUL|PLAYER";
		end

		if aItem["others"] == true and aItem["mine"] == false then
			return "HELPFUL|!PLAYER";
		end

		return "HELPFUL";

	end



	--
	local function VUHDO_finalizeOverlayBranchEntryKey(anEntry)

		anEntry["sublevelKey"] = anEntry["entryKey"];

		if (anEntry["branchIdx"] or 1) > 1 then
			anEntry["entryKey"] = format("%s:b%d", anEntry["entryKey"], anEntry["branchIdx"]);
		end

		return;

	end



	--
	local tBouquet;
	local tGroupEntries;
	local tItem;
	local tSpecial;
	local tShadowValueMode;
	local tGateValidators;
	local tSecretType;
	local tCanColorBarGroups;
	local tDispelName;
	local tSpellId;
	local tIncludeSpellIds;
	local tColor;
	local tBaseOpacityProduct;
	local tPrototypeCacheKey;
	local tHadDebuffBarColorEmptyGroups;
	local tOverlayTarget;
	local tOverlayEntries;
	local tOverlayEntry;
	local tAuraSpellIds;
	local tIsDotShape;
	local tHasBackgroundColor;
	function VUHDO_buildOverlayEntryPrototypes(aPanelNum, anIndicatorKey, aBouquetName)

		if not aBouquetName or aBouquetName == "" then
			return nil;
		end

		tPrototypeCacheKey = aPanelNum .. ":" .. anIndicatorKey .. ":" .. aBouquetName;

		if sOverlayEntryPrototypeCache[tPrototypeCacheKey] and sOverlayEntryPrototypeCache[tPrototypeCacheKey]["generation"] == sOverlayConfigGeneration then
			return sOverlayEntryPrototypeCache[tPrototypeCacheKey]["prototypes"];
		end

		tOverlayTarget = VUHDO_INDICATOR_OVERLAY_TARGETS[anIndicatorKey];

		if not tOverlayTarget then
			return nil;
		end

		tIsDotShape = tOverlayTarget["shape"] == "dot";

		tBouquet = VUHDO_BOUQUETS["STORED"][aBouquetName];

		if not tBouquet then
			return nil;
		end

		tBouquet = VUHDO_decompressIfCompressed(tBouquet);
		VUHDO_BOUQUETS["STORED"][aBouquetName] = tBouquet;

		tBaseOpacityProduct = VUHDO_computeOverlayBaseOpacityProduct(tBouquet);

		tOverlayEntries = nil;
		tHadDebuffBarColorEmptyGroups = false;

		for tCnt = 1, #tBouquet do
			tItem = tBouquet[tCnt];
			tSpecial = VUHDO_BOUQUET_BUFFS_SPECIAL[tItem["name"]];
			tOverlayEntry = nil;

			tShadowValueMode, tGateValidators = VUHDO_resolveOverlayShadowValueMode(tBouquet, tCnt, tOverlayTarget);

			if tSpecial then
				tSecretType = tSpecial["secretType"] or 0;

				if tSpecial["custom_type"] == VUHDO_BOUQUET_CUSTOM_TYPE_AURA_GROUP then
					tGroupEntries = VUHDO_buildAuraGroupActiveOverlayEntries(tItem, tOverlayTarget, tCnt, tShadowValueMode, tBaseOpacityProduct);

					for _, tOverlayEntry in ipairs(tGroupEntries) do
						if not tOverlayEntries then
							tOverlayEntries = { };
						end

						tOverlayEntry["entryKey"] = tCnt .. ":group:" .. (tOverlayEntry["groupKey"] or "aura");

						if tOverlayEntry["hostileOnly"] then
							tOverlayEntry["entryKey"] = tOverlayEntry["entryKey"] .. ":hostile";
						elseif tOverlayEntry["friendlyOnly"] then
							tOverlayEntry["entryKey"] = tOverlayEntry["entryKey"] .. ":friendly";
						end

						VUHDO_finalizeOverlayBranchEntryKey(tOverlayEntry);

						VUHDO_appendOverlayEntryWithVariants(tOverlayEntries, tOverlayEntry, tShadowValueMode, tGateValidators);
					end

					tOverlayEntry = nil;
				elseif tItem["name"] == "DEBUFF_BAR_COLOR" then
					tCanColorBarGroups = VUHDO_getCanColorBarGroups();

					if #tCanColorBarGroups == 0 then
						tHadDebuffBarColorEmptyGroups = true;
					end

					for tGroupCnt = 1, #tCanColorBarGroups do
						tGroupEntries = VUHDO_buildCanColorBarGroupOverlayEntries(tCanColorBarGroups[tGroupCnt], tItem, tOverlayTarget, tCnt, tShadowValueMode, tBaseOpacityProduct);

						for _, tOverlayEntry in ipairs(tGroupEntries) do
							if not tOverlayEntries then
								tOverlayEntries = { };
							end

							tOverlayEntry["entryKey"] = tCnt .. ":group:" .. (tOverlayEntry["groupKey"] or tGroupCnt);

							if tOverlayEntry["hostileOnly"] then
								tOverlayEntry["entryKey"] = tOverlayEntry["entryKey"] .. ":hostile";
							elseif tOverlayEntry["friendlyOnly"] then
								tOverlayEntry["entryKey"] = tOverlayEntry["entryKey"] .. ":friendly";
							end

							VUHDO_finalizeOverlayBranchEntryKey(tOverlayEntry);

							VUHDO_appendOverlayEntryWithVariants(tOverlayEntries, tOverlayEntry, tShadowValueMode, tGateValidators);
						end
					end

					tOverlayEntry = nil;
				elseif tSpecial["auraSpellIds"] then
					tAuraSpellIds = tSpecial["auraSpellIds"];
					tIncludeSpellIds = { };

					for tHotCnt = 1, #tAuraSpellIds do
						tIncludeSpellIds[tAuraSpellIds[tHotCnt]] = true;
					end

					tColor = tItem["color"];
					tHasBackgroundColor = tColor and tColor["useBackground"];

					if next(tIncludeSpellIds) and (tIsDotShape or tHasBackgroundColor) then
						tOverlayEntry = {
							["filterString"] = tSpecial["auraFilterString"] or "HELPFUL|PLAYER",
							["candidateFilters"] = {
								["includeSpellIDs"] = tIncludeSpellIds,
							},
							["shape"] = tOverlayTarget["shape"],
							["bouquetIdx"] = tCnt,
							["shadowValueMode"] = tShadowValueMode,
							["friendlyOnly"] = true,
							["overlayGate"] = tSpecial["overlayGate"],
							["entryKey"] = tCnt .. ":special:" .. tItem["name"] .. ":friendly",
						};

						if tHasBackgroundColor then
							tOverlayEntry["staticColor"] = VUHDO_applyOverlayStaticColorBright(tColor, tItem, tBaseOpacityProduct);
						end

						if tOverlayTarget["shape"] == "bar" then
							VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, tOverlayTarget);
						elseif tOverlayTarget["shape"] == "dot" then
							VUHDO_applyOverlayDotIconFields(tOverlayEntry, tItem, tOverlayEntry["staticColor"], tOverlayTarget);
						elseif tOverlayTarget["shape"] == "border" then
							tOverlayEntry["border"] = true;
						end
					end
				elseif tSecretType == VUHDO_SECRET_TYPE_DISPEL then
					if tSpecial["debuffType"] then
						tDispelName = sDebuffTypeDispelName[tSpecial["debuffType"]];

						if tDispelName and (tIsDotShape or VUHDO_getBackgroundDispelTypeNames()[tDispelName]) then
							tOverlayEntry = {
								["filterString"] = VUHDO_isDispelNameHostile(tDispelName) and "HELPFUL" or "HARMFUL",
								["candidateFilters"] = {
									["includeDispelTypes"] = {
										[tDispelName] = true,
									},
								},
								["shape"] = tOverlayTarget["shape"],
								["bouquetIdx"] = tCnt,
								["shadowValueMode"] = tShadowValueMode,
								["entryKey"] = tCnt .. ":dispel:" .. tDispelName,
							};

							if VUHDO_isDispelNameHostile(tDispelName) then
								tOverlayEntry["hostileOnly"] = true;
							else
								tOverlayEntry["friendlyOnly"] = true;
							end

							if tOverlayTarget["shape"] == "bar" then
								tOverlayEntry["dispelFill"] = true;

								VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, tOverlayTarget);
							elseif tOverlayTarget["shape"] == "border" then
								tOverlayEntry["dispelBorder"] = true;
							elseif tOverlayTarget["shape"] == "dot" then
								VUHDO_applyOverlayDotIconFields(tOverlayEntry, tItem, VUHDO_applyOverlayStaticColorBright(tItem["color"], tItem, tBaseOpacityProduct), tOverlayTarget);
							end

							tOverlayEntry["dispelBright"] = VUHDO_getOverlayItemDispelBright(tItem);
							tOverlayEntry["dispelOpacity"] = VUHDO_getOverlayItemDispelOpacity(tItem, tBaseOpacityProduct);
						end
					end
				end
			else
				tIncludeSpellIds = { };

				VUHDO_addResolvedAuraContainerSpellIds(tIncludeSpellIds, tItem["name"]);
				tColor = tItem["color"];
				tHasBackgroundColor = tColor and tColor["useBackground"];

				if next(tIncludeSpellIds) and (tIsDotShape or tHasBackgroundColor) then
					tSpellId = VUHDO_resolveAuraContainerSpellId(tItem["name"]);

					tOverlayEntry = {
						["filterString"] = VUHDO_getOverlaySpellFilterString(tItem),
						["candidateFilters"] = {
							["includeSpellIDs"] = tIncludeSpellIds,
						},
						["shape"] = tOverlayTarget["shape"],
						["bouquetIdx"] = tCnt,
						["shadowValueMode"] = tShadowValueMode,
						["friendlyOnly"] = true,
						["entryKey"] = tCnt .. ":spell:" .. tostring(tSpellId or tItem["name"]) .. ":friendly",
					};

					if tHasBackgroundColor then
						tOverlayEntry["staticColor"] = VUHDO_applyOverlayStaticColorBright(tColor, tItem, tBaseOpacityProduct);
					end

					if tOverlayTarget["shape"] == "bar" then
						VUHDO_applyOverlayShapePrototypeFields(tOverlayEntry, tOverlayTarget);
					elseif tOverlayTarget["shape"] == "dot" then
						VUHDO_applyOverlayDotIconFields(tOverlayEntry, tItem, tOverlayEntry["staticColor"], tOverlayTarget);
					elseif tOverlayTarget["shape"] == "border" then
						tOverlayEntry["border"] = true;
					end
				end
			end

			if tOverlayEntry then
				if not tOverlayEntries then
					tOverlayEntries = { };
				end

				if not tOverlayEntry["entryKey"] then
					tOverlayEntry["entryKey"] = tCnt .. ":item";
				end

				VUHDO_appendOverlayEntryWithVariants(tOverlayEntries, tOverlayEntry, tShadowValueMode, tGateValidators);
			end
		end

		if not tOverlayEntries then
			if not tHadDebuffBarColorEmptyGroups then
				sOverlayEntryPrototypeCache[tPrototypeCacheKey] = {
					["generation"] = sOverlayConfigGeneration,
					["prototypes"] = nil,
				};
			end

			return nil;
		end

		tOverlayEntries = VUHDO_suppressOverlayEntriesClaimedByHigherPriority(tOverlayEntries);

		if not tOverlayEntries then
			if not tHadDebuffBarColorEmptyGroups then
				sOverlayEntryPrototypeCache[tPrototypeCacheKey] = {
					["generation"] = sOverlayConfigGeneration,
					["prototypes"] = nil,
				};
			end

			return nil;
		end

		for tCnt = #tOverlayEntries, 1, -1 do
			tOverlayEntry = tOverlayEntries[tCnt];

			if tOverlayEntry["shape"] ~= "bar" then
				tOverlayEntry["frameLevelOffset"] = (tOverlayTarget["addLevel"] or 1) + (#tOverlayEntries - tCnt);
			end
		end

		sOverlayEntryPrototypeCache[tPrototypeCacheKey] = {
			["generation"] = sOverlayConfigGeneration,
			["prototypes"] = tOverlayEntries,
		};

		return tOverlayEntries;

	end



	--
	local tOverlayTarget;
	local tOverlayEntries;
	local tOverlayEntry;
	local tBarButtonSetup;
	local tBorderButtonSetup;
	local tSlotCount;
	local tSublevelKey;
	local tCachedSublevels;
	function VUHDO_stampOverlayEntriesFromPrototypes(aPrototypes, aPanelNum, anIndicatorKey, aButton, aTargetFrame)

		if not aPrototypes or not aTargetFrame then
			return nil;
		end

		tOverlayTarget = VUHDO_INDICATOR_OVERLAY_TARGETS[anIndicatorKey];

		if not tOverlayTarget then
			return nil;
		end

		VUHDO_resetOverlaySublevelAllocator(aTargetFrame);

		tBarButtonSetup = nil;
		tBorderButtonSetup = nil;

		if tOverlayTarget["shape"] == "bar" then
			tBarButtonSetup = VUHDO_getOverlayBarButtonSetup(aPanelNum, anIndicatorKey, aTargetFrame, aButton);
		elseif tOverlayTarget["shape"] == "border" then
			tBorderButtonSetup = VUHDO_getOverlayBorderButtonSetup(aPanelNum, anIndicatorKey);
		end

		twipe(sOverlayBuild["stampedEntries"]);
		twipe(sOverlayBuild["sublevelAllocByKey"]);

		for tCnt = 1, #aPrototypes do
			tOverlayEntry = { };

			for tCopyKey, tCopyValue in pairs(aPrototypes[tCnt]) do
				tOverlayEntry[tCopyKey] = tCopyValue;
			end

			VUHDO_stampOverlayEntryShapeFields(tOverlayEntry, tOverlayTarget, tBarButtonSetup, tBorderButtonSetup);

			if tOverlayEntry["shape"] == "bar" and tOverlayEntry["shadowBar"] then
				tSlotCount = 2;
			else
				tSlotCount = 1;
			end

			tSublevelKey = tOverlayEntry["sublevelKey"] or tOverlayEntry["entryKey"];
			tCachedSublevels = sOverlayBuild["sublevelAllocByKey"][tSublevelKey];

			if tCachedSublevels then
				tOverlayEntry["sublevelSlots"] = tCachedSublevels;
			else
				tOverlayEntry["sublevelSlots"] = VUHDO_allocateOverlaySublevels(aTargetFrame, tSlotCount, anIndicatorKey, aPanelNum);
				sOverlayBuild["sublevelAllocByKey"][tSublevelKey] = tOverlayEntry["sublevelSlots"];
			end

			if tOverlayEntry["auraGroupBarGlow"] then
				tOverlayEntry["unitButton"] = aButton;
			end

			sOverlayBuild["stampedEntries"][#sOverlayBuild["stampedEntries"] + 1] = tOverlayEntry;
		end

		return sOverlayBuild["stampedEntries"];

	end



	--
	function VUHDO_buildOverlayEntries(aPanelNum, anIndicatorKey, aBouquetName, aButton, aTargetFrame)

		tOverlayEntries = VUHDO_buildOverlayEntryPrototypes(aPanelNum, anIndicatorKey, aBouquetName);

		if not tOverlayEntries then
			return nil;
		end

		return VUHDO_stampOverlayEntriesFromPrototypes(tOverlayEntries, aPanelNum, anIndicatorKey, aButton, aTargetFrame);

	end

end



do
	--
	local function VUHDO_resolveOverlayLevelFrame(aTargetFrame)

		if aTargetFrame:IsObjectType("Frame") then
			return aTargetFrame;
		end

		return aTargetFrame:GetParent();

	end



	--
	local tLevelFrame;
	local tTargetWidth;
	local tTargetHeight;
	local tSquareSize;
	local tBorderEdgeSize;
	local tBorderScale;
	local tBorderRepeatX;
	local tBorderRepeatY;
	local tPanelNum;
	local tScaling;
	local tButtonSetup;
	function VUHDO_buildOverlayButtonSetup(aButton, aTargetFrame, anOverlayEntry)

		tLevelFrame = VUHDO_resolveOverlayLevelFrame(aTargetFrame);

		if aButton then
			tPanelNum = VUHDO_BUTTON_CACHE[aButton];
			tScaling = tPanelNum and VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["SCALING"];

			if aTargetFrame == VUHDO_getHealthBar(aButton, 1) then
				if tScaling then
					tTargetWidth = tScaling["barWidth"];
					tTargetHeight = anOverlayEntry["height"] or tScaling["barHeight"];
				else
					tTargetWidth = aTargetFrame:GetWidth();
					tTargetHeight = anOverlayEntry["height"] or aTargetFrame:GetHeight();
				end
			elseif aTargetFrame == VUHDO_getHealthBar(aButton, 17) then
				if tScaling then
					tTargetWidth = VUHDO_getSideBarWidthLeft(tPanelNum);
					tTargetHeight = anOverlayEntry["height"] or tScaling["barHeight"];
				else
					tTargetWidth = aTargetFrame:GetWidth();
					tTargetHeight = anOverlayEntry["height"] or aTargetFrame:GetHeight();
				end
			elseif aTargetFrame == VUHDO_getHealthBar(aButton, 18) then
				if tScaling then
					tTargetWidth = VUHDO_getSideBarWidthRight(tPanelNum);
					tTargetHeight = anOverlayEntry["height"] or tScaling["barHeight"];
				else
					tTargetWidth = aTargetFrame:GetWidth();
					tTargetHeight = anOverlayEntry["height"] or aTargetFrame:GetHeight();
				end
			else
				tTargetWidth = aTargetFrame:GetWidth();
				tTargetHeight = anOverlayEntry["height"] or aTargetFrame:GetHeight();
			end
		else
			tTargetWidth = aTargetFrame:GetWidth();
			tTargetHeight = anOverlayEntry["height"] or aTargetFrame:GetHeight();
		end

		if (anOverlayEntry["templateName"] or VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE) == VUHDO_AURA_BUTTON_ICON_TEMPLATE then
			tSquareSize = min(tTargetWidth, tTargetHeight);

			tTargetWidth = tSquareSize;
			tTargetHeight = tSquareSize;
		end

		tButtonSetup = {
			["staticColor"] = anOverlayEntry["staticColor"],
			["iconColor"] = anOverlayEntry["iconColor"],
			["dispelBorder"] = anOverlayEntry["dispelBorder"],
			["shadowBar"] = anOverlayEntry["shadowBar"],
			["dispelFill"] = anOverlayEntry["dispelFill"],
			["dispelIcon"] = anOverlayEntry["dispelIcon"],
			["dispelBright"] = anOverlayEntry["dispelBright"],
			["dispelOpacity"] = anOverlayEntry["dispelOpacity"],
			["shadowValueMode"] = anOverlayEntry["shadowValueMode"],
			["barTexture"] = anOverlayEntry["barTexture"],
			["barOrientation"] = anOverlayEntry["barOrientation"],
			["barInverted"] = anOverlayEntry["barInverted"],
			["fillMaskTopLeftX"] = anOverlayEntry["fillMaskTopLeftX"],
			["fillMaskTopLeftY"] = anOverlayEntry["fillMaskTopLeftY"],
			["fillMaskBottomRightX"] = anOverlayEntry["fillMaskBottomRightX"],
			["fillMaskBottomRightY"] = anOverlayEntry["fillMaskBottomRightY"],
			["occlusionColor"] = anOverlayEntry["occlusionColor"],
			["sublevelSlots"] = anOverlayEntry["sublevelSlots"],
			["border"] = anOverlayEntry["border"],
			["borderWidth"] = anOverlayEntry["borderWidth"],
			["borderFile"] = anOverlayEntry["borderFile"],
			["staticIcon"] = anOverlayEntry["staticIcon"],
			["iconTexCoords"] = anOverlayEntry["iconTexCoords"],
			["targetBar"] = aTargetFrame,
			["targetFrameLevel"] = tLevelFrame:GetFrameLevel(),
			["hideIcon"] = not anOverlayEntry["dispelOverlayChrome"] and (anOverlayEntry["hideIcon"] or anOverlayEntry["glowIcon"] or anOverlayEntry["shape"] == "bar" or anOverlayEntry["shape"] == "glow"),
			["disableMouse"] = true,
			["glowIcon"] = anOverlayEntry["glowIcon"],
			["glowColor"] = anOverlayEntry["glowColor"],
			["glowStyle"] = anOverlayEntry["glowStyle"],
			["glowColorType"] = anOverlayEntry["glowColorType"],
			["auraGroupBarGlow"] = anOverlayEntry["auraGroupBarGlow"],
			["specialDotBarGlow"] = anOverlayEntry["specialDotBarGlow"],
			["unitButton"] = anOverlayEntry["unitButton"],
			["dispelOverlayChrome"] = anOverlayEntry["dispelOverlayChrome"],
			["width"] = tTargetWidth,
			["height"] = tTargetHeight,
		};

		if anOverlayEntry["border"] then
			tBorderEdgeSize = VUHDO_PixelUtil.RoundToPixel(anOverlayEntry["borderWidth"] or 1, 1);
			tBorderScale = aTargetFrame:GetEffectiveScale();
			tBorderRepeatX = max(0, (tTargetWidth / tBorderEdgeSize) * tBorderScale - 2 - sBorderCoordStart);
			tBorderRepeatY = max(0, (tTargetHeight / tBorderEdgeSize) * tBorderScale - 2 - sBorderCoordStart);

			tButtonSetup["borderEdgeSize"] = tBorderEdgeSize;
			tButtonSetup["borderRepeatX"] = tBorderRepeatX;
			tButtonSetup["borderRepeatY"] = tBorderRepeatY;
		end

		return tButtonSetup;

	end



	--
	local tResolveContainerParent;
	local tResolveOverlayHostFrame;
	local tResolveFrameLevelOffset;
	local tResolveLevelFrame;
	function VUHDO_resolveOverlayContainerAnchorFields(aButton, aTargetFrame, aFrameLevelOffsetAddend)

		tResolveLevelFrame = VUHDO_resolveOverlayLevelFrame(aTargetFrame);

		tResolveOverlayHostFrame = VUHDO_getOverlayHostFrame(aTargetFrame);

		tResolveContainerParent = (tResolveOverlayHostFrame and tResolveOverlayHostFrame:GetName() and tResolveOverlayHostFrame) or (((aTargetFrame and aTargetFrame:GetName()) and aTargetFrame) or aButton);
		tResolveFrameLevelOffset = (tResolveLevelFrame["addLevel"] or 0) + (aFrameLevelOffsetAddend or 1);

		return tResolveContainerParent, tResolveOverlayHostFrame, tResolveFrameLevelOffset;

	end



	--
	local tButtonSetup;
	local tGroupTemplate;
	local tContainerParent;
	local tFrameLevelOffset;
	local tOverlayHostFrame;
	function VUHDO_buildOverlayContainerTemplate(aButton, aTargetFrame, anOverlayEntry, anOverlayKey)

		tButtonSetup = VUHDO_buildOverlayButtonSetup(aButton, aTargetFrame, anOverlayEntry);

		tGroupTemplate = {
			["key"] = anOverlayKey or "overlay",
			["filterString"] = anOverlayEntry["filterString"],
			["candidateFilters"] = anOverlayEntry["candidateFilters"],
			["templateName"] = anOverlayEntry["templateName"] or VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE,
			["buttonSetup"] = tButtonSetup,
			["maxFrameCount"] = 1,
			["layout"] = {
				["elementWidth"] = tButtonSetup["width"],
				["elementHeight"] = tButtonSetup["height"],
				["elementSpacing"] = 0,
				["lineSpacing"] = 0,
			},
		};

		tContainerParent, tOverlayHostFrame, tFrameLevelOffset = VUHDO_resolveOverlayContainerAnchorFields(aButton, aTargetFrame, anOverlayEntry["frameLevelOffset"] or 1);

		return {
			["parent"] = tContainerParent,
			["anchor"] = {
				["mode"] = "cover",
				["target"] = tOverlayHostFrame or aTargetFrame,
				["levelBase"] = aButton,
				["frameLevelOffset"] = tFrameLevelOffset,
			},
			["isOverlay"] = true,
			["overlayTargetBar"] = aTargetFrame,
			["overlayHostFrame"] = tOverlayHostFrame,
			["groups"] = { tGroupTemplate },
		};

	end



	--
	local tSlotButtonSetup;
	local tSlotFrameLevelOffset;
	local tOverlayHostFrame;
	local tContainerParent;
	local tPlanSlotKey;
	local tSlotBuildSignature;
	local tSlotFamilyKey;
	local tSlotVolatileSignature;
	local tSlotCandidateSignature;
	local tSlotTemplateName;
	local function VUHDO_buildOverlaySlotSpec(aButton, aTargetFrame, anOverlayEntry, anIndicatorKey, anEntryKey)

		tSlotButtonSetup = VUHDO_buildOverlayButtonSetup(aButton, aTargetFrame, anOverlayEntry);

		tContainerParent, tOverlayHostFrame, tSlotFrameLevelOffset = VUHDO_resolveOverlayContainerAnchorFields(aButton, aTargetFrame, anOverlayEntry["frameLevelOffset"] or 1);

		tSlotButtonSetup["frameLevelOffset"] = tSlotFrameLevelOffset;

		VUHDO_applyOverlayGateFlags(anOverlayEntry);

		tPlanSlotKey = anIndicatorKey .. ":" .. anEntryKey;

		tSlotBuildSignature = VUHDO_getAuraButtonSetupBuildSignature(tSlotButtonSetup);

		tSlotTemplateName = anOverlayEntry["templateName"] or VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE;

		tSlotFamilyKey = format("%s:%s:%s#%s", anIndicatorKey, anEntryKey, tSlotTemplateName, tSlotBuildSignature);

		tSlotVolatileSignature = VUHDO_getAuraButtonSetupVolatileSignature(tSlotButtonSetup);

		tSlotCandidateSignature = VUHDO_getCandidateFiltersSignature(anOverlayEntry["candidateFilters"]);

		return {
			["key"] = tPlanSlotKey,
			["planSlotKey"] = tPlanSlotKey,
			["slotFamilyKey"] = tSlotFamilyKey,
			["volatileSignature"] = tSlotVolatileSignature,
			["candidateSignature"] = tSlotCandidateSignature,
			["filterString"] = anOverlayEntry["filterString"],
			["candidateFilters"] = anOverlayEntry["candidateFilters"],
			["templateName"] = anOverlayEntry["templateName"] or VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE,
			["buttonSetup"] = tSlotButtonSetup,
			["anchorFrame"] = tOverlayHostFrame or aTargetFrame,
			["anchorMode"] = "cover",
			["width"] = tSlotButtonSetup["width"],
			["height"] = tSlotButtonSetup["height"],
			["frameLevelOffset"] = tSlotFrameLevelOffset,
			["indicatorKey"] = anIndicatorKey,
			["entryKey"] = anEntryKey,
			["friendlyOnly"] = anOverlayEntry["friendlyOnly"] or nil,
			["hostileOnly"] = anOverlayEntry["hostileOnly"] or nil,
			["identityGate"] = anOverlayEntry["identityGate"] or nil,
			["isCompoundFilterString"] = anOverlayEntry["isCompoundFilterString"] or nil,
			["alwaysEnabled"] = anOverlayEntry["alwaysEnabled"] or nil,
			["valueGates"] = anOverlayEntry["valueGates"] or nil,
			["isValueGateActiveVariant"] = anOverlayEntry["isValueGateActiveVariant"] or nil,
			["auraGroupBarGlow"] = anOverlayEntry["auraGroupBarGlow"] or nil,
			["specialDotBarGlow"] = anOverlayEntry["specialDotBarGlow"] or nil,
			["glowGroupId"] = anOverlayEntry["glowGroupId"] or nil,
			["glowStyle"] = anOverlayEntry["glowStyle"] or nil,
			["glowColorType"] = anOverlayEntry["glowColorType"] or nil,
			["glowColor"] = anOverlayEntry["glowColor"] or nil,
			["unitButton"] = anOverlayEntry["unitButton"] or aButton,
			["bouquetIdx"] = anOverlayEntry["bouquetIdx"],
			["overlayGate"] = anOverlayEntry["overlayGate"] or nil,
		};

	end



	--
	local tSlotSpec;
	function VUHDO_planOverlaySlot(aButton, anIndicatorKey, anEntryKey, aTargetFrame, anOverlayEntry)

		tSlotSpec = VUHDO_buildOverlaySlotSpec(aButton, aTargetFrame, anOverlayEntry, anIndicatorKey, anEntryKey);

		sOverlayBuild["plannedSlotSpecs"][tSlotSpec["key"]] = tSlotSpec;
		sOverlayBuild["plannedSlotOrder"][#sOverlayBuild["plannedSlotOrder"] + 1] = tSlotSpec["key"];

		return tSlotSpec;

	end



	--
	function VUHDO_copyOverlaySlotRecordFromSpec(aSlotRecord, aSlotSpec)

		aSlotRecord["filterString"] = aSlotSpec["filterString"];
		aSlotRecord["candidateFilters"] = aSlotSpec["candidateFilters"];
		aSlotRecord["friendlyOnly"] = aSlotSpec["friendlyOnly"];
		aSlotRecord["hostileOnly"] = aSlotSpec["hostileOnly"];
		aSlotRecord["identityGate"] = aSlotSpec["identityGate"];
		aSlotRecord["isCompoundFilterString"] = aSlotSpec["isCompoundFilterString"];
		aSlotRecord["alwaysEnabled"] = aSlotSpec["alwaysEnabled"];
		aSlotRecord["valueGates"] = aSlotSpec["valueGates"];
		aSlotRecord["isValueGateActiveVariant"] = aSlotSpec["isValueGateActiveVariant"];
		aSlotRecord["auraGroupBarGlow"] = aSlotSpec["auraGroupBarGlow"];
		aSlotRecord["specialDotBarGlow"] = aSlotSpec["specialDotBarGlow"];
		aSlotRecord["glowGroupId"] = aSlotSpec["glowGroupId"];
		aSlotRecord["glowStyle"] = aSlotSpec["glowStyle"];
		aSlotRecord["glowColorType"] = aSlotSpec["glowColorType"];
		aSlotRecord["glowColor"] = aSlotSpec["glowColor"];
		aSlotRecord["unitButton"] = aSlotSpec["unitButton"];
		aSlotRecord["indicatorKey"] = aSlotSpec["indicatorKey"];
		aSlotRecord["entryKey"] = aSlotSpec["entryKey"];
		aSlotRecord["bouquetIdx"] = aSlotSpec["bouquetIdx"];
		aSlotRecord["buttonSetup"] = aSlotSpec["buttonSetup"];
		aSlotRecord["planSlotKey"] = aSlotSpec["planSlotKey"] or aSlotSpec["key"];
		aSlotRecord["slotFamilyKey"] = aSlotSpec["slotFamilyKey"];
		aSlotRecord["durationSetupPending"] = ((aSlotSpec["buttonSetup"] or sEmpty)["shadowValueMode"] == "duration") or nil;
		aSlotRecord["overlayGate"] = aSlotSpec["overlayGate"];

		return;

	end
end



do
	--
	local tFilterChanged;
	local tCandidateChanged;
	local tDesiredFilterString;
	function VUHDO_syncOverlaySlotRecordFilters(aHostData, aSlotEngineKey, aSlotRecord, aSlotSpec)

		tFilterChanged = aSlotRecord["appliedFilterString"] ~= (aSlotSpec["filterString"] or "HELPFUL");
		tCandidateChanged = aSlotRecord["appliedCandidateSignature"] ~= aSlotSpec["candidateSignature"];

		if aSlotRecord["appliedSuppress"] then
			if aSlotRecord["appliedFilterString"] ~= "" then
				aHostData["container"]:SetAuraSlotFilterString(aSlotEngineKey, "");

				aSlotRecord["appliedFilterString"] = "";
			end

			if aHostData["lastSyncedSlotEnabled"] then
				aHostData["lastSyncedSlotEnabled"][aSlotEngineKey] = nil;
			end

			return;
		end

		tDesiredFilterString = aSlotSpec["filterString"] or "HELPFUL";

		if tFilterChanged then
			aHostData["container"]:SetAuraSlotFilterString(aSlotEngineKey, tDesiredFilterString);

			aSlotRecord["appliedFilterString"] = tDesiredFilterString;
		end

		if tCandidateChanged then
			aHostData["container"]:SetAuraSlotCandidateFilters(aSlotEngineKey, aSlotSpec["candidateFilters"]);

			aSlotRecord["appliedCandidateSignature"] = aSlotSpec["candidateSignature"];
		end

		if tFilterChanged or tCandidateChanged then
			if aHostData["lastSyncedSlotEnabled"] then
				aHostData["lastSyncedSlotEnabled"][aSlotEngineKey] = nil;
			end
		end

		return;

	end
end



do
	--
	local tEngineKeys;
	function VUHDO_registerOverlaySlotFamilyEngineKey(aHostData, aSlotFamilyKey, aSlotEngineKey)

		if not aHostData["slotRecordsByFamily"] then
			aHostData["slotRecordsByFamily"] = { };
		end

		tEngineKeys = aHostData["slotRecordsByFamily"][aSlotFamilyKey];

		if not tEngineKeys then
			tEngineKeys = { };

			aHostData["slotRecordsByFamily"][aSlotFamilyKey] = tEngineKeys;
		end

		for tFamilyCnt = 1, #tEngineKeys do
			if tEngineKeys[tFamilyCnt] == aSlotEngineKey then
				return;
			end
		end

		tEngineKeys[#tEngineKeys + 1] = aSlotEngineKey;

		return;

	end
end



do
	--
	local tEngineKeys;
	local tNextIndex;
	function VUHDO_getNextOverlaySlotEngineKey(aHostData, aSlotFamilyKey)

		if not aHostData["slotRecordsByFamily"] then
			aHostData["slotRecordsByFamily"] = { };
		end

		tEngineKeys = aHostData["slotRecordsByFamily"][aSlotFamilyKey];

		if not tEngineKeys then
			tEngineKeys = { };

			aHostData["slotRecordsByFamily"][aSlotFamilyKey] = tEngineKeys;
		end

		tNextIndex = #tEngineKeys + 1;

		return format("%s#%d", aSlotFamilyKey, tNextIndex);

	end
end



do
	--
	local tContainer;
	local tSlotTable;
	local tAuraFrame;
	local tSlotRecord;
	function VUHDO_addOverlaySlotEngineFromSpec(aHostData, aSlotSpec, aSlotEngineKey)

		tContainer = aHostData["container"];

		if InCombatLockdown() then
			return false;
		end

		tSlotTable = {
			["key"] = aSlotEngineKey,
			["filterString"] = aSlotSpec["filterString"],
			["candidateFilters"] = aSlotSpec["candidateFilters"],
			["templateName"] = aSlotSpec["templateName"],
			["buttonSetup"] = aSlotSpec["buttonSetup"],
			["anchorFrame"] = aSlotSpec["anchorFrame"],
			["anchorMode"] = aSlotSpec["anchorMode"],
			["width"] = aSlotSpec["width"],
			["height"] = aSlotSpec["height"],
			["frameLevelOffset"] = aSlotSpec["frameLevelOffset"],
		};

		if not aHostData["slotFrames"] then
			aHostData["slotFrames"] = { };
		end

		tAuraFrame = VUHDO_addOverlaySlotToHost(tContainer, tSlotTable, "TOPLEFT", aHostData["slotOrder"], aHostData["slotFrames"], nil);

		tSlotRecord = { };

		VUHDO_copyOverlaySlotRecordFromSpec(tSlotRecord, aSlotSpec);

		tSlotRecord["slotEngineKey"] = aSlotEngineKey;
		tSlotRecord["slotFrame"] = tAuraFrame;
		tSlotRecord["appliedFilterString"] = aSlotSpec["filterString"] or "HELPFUL";
		tSlotRecord["appliedSuppress"] = false;
		tSlotRecord["appliedVolatileSignature"] = aSlotSpec["volatileSignature"];
		tSlotRecord["appliedCandidateSignature"] = aSlotSpec["candidateSignature"];

		aHostData["slotRecords"][aSlotEngineKey] = tSlotRecord;

		VUHDO_registerOverlaySlotFamilyEngineKey(aHostData, aSlotSpec["slotFamilyKey"], aSlotEngineKey);

		VUHDO_AURA_CONTAINER_METRICS["builds"]["overlaySlot"] = (VUHDO_AURA_CONTAINER_METRICS["builds"]["overlaySlot"] or 0) + 1;

		return true;

	end
end



do
	--
	local tContainer;
	local tEngineKey;
	local tRecord;
	local tSlotFrame;
	local tEngineKeys;
	local tFilterString;
	function VUHDO_reconcileOverlaySlotFromSpec(aHostData, aSlotSpec)

		if not aHostData or not aSlotSpec then
			return nil;
		end

		tContainer = aHostData["container"];

		if not tContainer then
			return nil;
		end

		for tSlotEngineKey, tSlotRecord in pairs(aHostData["slotRecords"] or sEmpty) do
			if not tSlotRecord["appliedSuppress"]
				and tSlotRecord["slotFamilyKey"] == aSlotSpec["slotFamilyKey"]
				and (tSlotRecord["planSlotKey"] == aSlotSpec["planSlotKey"] or tSlotEngineKey == aSlotSpec["planSlotKey"]) then
				if tSlotRecord["appliedVolatileSignature"] == aSlotSpec["volatileSignature"] then
					VUHDO_copyOverlaySlotRecordFromSpec(tSlotRecord, aSlotSpec);

					tSlotRecord["planSlotKey"] = aSlotSpec["planSlotKey"];
					tSlotRecord["slotEngineKey"] = tSlotEngineKey;
					tSlotRecord["slotFamilyKey"] = aSlotSpec["slotFamilyKey"];

					VUHDO_syncOverlaySlotRecordFilters(aHostData, tSlotEngineKey, tSlotRecord, aSlotSpec);

					VUHDO_registerOverlaySlotFamilyEngineKey(aHostData, aSlotSpec["slotFamilyKey"], tSlotEngineKey);

					return tSlotEngineKey;
				end

				tSlotFrame = tSlotRecord["slotFrame"];

				if tSlotFrame and tSlotFrame:CanBeAccessedInContext() then
					VUHDO_copyOverlaySlotRecordFromSpec(tSlotRecord, aSlotSpec);

					tSlotRecord["planSlotKey"] = aSlotSpec["planSlotKey"];
					tSlotRecord["slotEngineKey"] = tSlotEngineKey;
					tSlotRecord["slotFamilyKey"] = aSlotSpec["slotFamilyKey"];

					VUHDO_reapplyAuraSlotVolatileSetup(tContainer, aSlotSpec["buttonSetup"], tSlotFrame);

					tSlotRecord["appliedVolatileSignature"] = aSlotSpec["volatileSignature"];

					VUHDO_syncOverlaySlotRecordFilters(aHostData, tSlotEngineKey, tSlotRecord, aSlotSpec);

					VUHDO_registerOverlaySlotFamilyEngineKey(aHostData, aSlotSpec["slotFamilyKey"], tSlotEngineKey);

					return tSlotEngineKey;
				end
			end
		end

		tEngineKeys = aHostData["slotRecordsByFamily"] and aHostData["slotRecordsByFamily"][aSlotSpec["slotFamilyKey"]];

		if tEngineKeys then
			for tFamilyCnt = 1, #tEngineKeys do
				tEngineKey = tEngineKeys[tFamilyCnt];
				tRecord = aHostData["slotRecords"][tEngineKey];

				if tRecord and tRecord["appliedSuppress"]
					and tRecord["appliedVolatileSignature"] == aSlotSpec["volatileSignature"] then

					tFilterString = aSlotSpec["filterString"] or "HELPFUL";

					tContainer:SetAuraSlotFilterString(tEngineKey, tFilterString);

					tRecord["appliedFilterString"] = tFilterString;
					tRecord["appliedSuppress"] = false;

					if aHostData["suppressedSlotCount"] and aHostData["suppressedSlotCount"] > 0 then
						aHostData["suppressedSlotCount"] = aHostData["suppressedSlotCount"] - 1;
					end

					if aHostData["lastSyncedSlotEnabled"] then
						aHostData["lastSyncedSlotEnabled"][tEngineKey] = nil;
					end

					VUHDO_copyOverlaySlotRecordFromSpec(tRecord, aSlotSpec);
					VUHDO_syncOverlaySlotRecordFilters(aHostData, tEngineKey, tRecord, aSlotSpec);

					VUHDO_updateOverlaySuppressedSlotMetrics();

					return tEngineKey;
				end
			end
		end

		tEngineKey = VUHDO_getNextOverlaySlotEngineKey(aHostData, aSlotSpec["slotFamilyKey"]);

		if not VUHDO_addOverlaySlotEngineFromSpec(aHostData, aSlotSpec, tEngineKey) then
			return nil;
		end

		return tEngineKey;

	end
end



do
	--
	local tHostData;
	local tPlannedKey;
	local tPlannedOrder;
	local tPlannedSpecs;
	local tSlotKey;
	local tDeferredAdd;
	local tSuppressedAny;
	local tContainer;
	local tWasHostShown;
	local tEngineKey;
	local tSlotRecord;
	function VUHDO_reconcileOverlaySlotsForButton(aButton, aButtonName)

		tPlannedOrder = sOverlayBuild["plannedSlotOrder"];
		tPlannedSpecs = sOverlayBuild["plannedSlotSpecs"];

		if #tPlannedOrder == 0 then
			VUHDO_disableOverlaySlotHost(aButtonName);

			sPendingOverlaySlotPlans[aButton] = nil;

			return;
		end

		tHostData = VUHDO_getOrCreateOverlaySlotHost(aButton, aButtonName);

		if not tHostData then
			sPendingOverlaySlotPlans[aButton] = {
				["generation"] = sOverlayConfigGeneration,
				["plannedOrder"] = { },
				["plannedSpecs"] = { },
			};

			for tOrderCnt = 1, #tPlannedOrder do
				tPlannedKey = tPlannedOrder[tOrderCnt];

				sPendingOverlaySlotPlans[aButton]["plannedOrder"][#sPendingOverlaySlotPlans[aButton]["plannedOrder"] + 1] = tPlannedKey;
				sPendingOverlaySlotPlans[aButton]["plannedSpecs"][tPlannedKey] = tPlannedSpecs[tPlannedKey];
			end

			return;
		end

		if not tHostData["plannedSlots"] then
			tHostData["plannedSlots"] = { };
		end

		twipe(tHostData["plannedSlots"]);

		twipe(sOverlayBuild["plannedSlotSet"]);

		tDeferredAdd = false;

		for tOrderCnt = 1, #tPlannedOrder do
			tPlannedKey = tPlannedOrder[tOrderCnt];

			tEngineKey = VUHDO_reconcileOverlaySlotFromSpec(tHostData, tPlannedSpecs[tPlannedKey]);

			if tEngineKey then
				sOverlayBuild["plannedSlotSet"][tEngineKey] = true;
				tHostData["plannedSlots"][tEngineKey] = true;
			else
				tDeferredAdd = true;
			end
		end

		tSuppressedAny = false;

		for tOrderCnt = 1, #tHostData["slotOrder"] do
			tSlotKey = tHostData["slotOrder"][tOrderCnt];

			if not sOverlayBuild["plannedSlotSet"][tSlotKey] then
				VUHDO_suppressOverlaySlotHostSlot(tHostData, tSlotKey);

				tSuppressedAny = true;
			end
		end

		if tDeferredAdd then
			sPendingOverlaySlotPlans[aButton] = {
				["generation"] = sOverlayConfigGeneration,
				["plannedOrder"] = { },
				["plannedSpecs"] = { },
			};

			for tOrderCnt = 1, #tPlannedOrder do
				tPlannedKey = tPlannedOrder[tOrderCnt];

				sPendingOverlaySlotPlans[aButton]["plannedOrder"][#sPendingOverlaySlotPlans[aButton]["plannedOrder"] + 1] = tPlannedKey;
				sPendingOverlaySlotPlans[aButton]["plannedSpecs"][tPlannedKey] = tPlannedSpecs[tPlannedKey];
			end
		else
			sPendingOverlaySlotPlans[aButton] = nil;
		end

		if not tHostData["overlayGateKeys"] then
			tHostData["overlayGateKeys"] = { };
		end

		twipe(tHostData["overlayGateKeys"]);

		for tEngineKey, _ in pairs(tHostData["plannedSlots"]) do
			tSlotRecord = tHostData["slotRecords"][tEngineKey];

			if tSlotRecord and tSlotRecord["overlayGate"] then
				tHostData["overlayGateKeys"][#tHostData["overlayGateKeys"] + 1] = tEngineKey;
			end
		end

		tContainer = tHostData["container"];

		if not tHostData["lastHostGated"] then
			tWasHostShown = tContainer:IsShown();

			tContainer:SetEnabled(true);
			tContainer:SetShown(true);

			if tSuppressedAny or not tWasHostShown then
				VUHDO_refreshAuraContainer(tContainer);
			end
		end

		return;

	end



	--
	local tPlannedKey;
	function VUHDO_flushPendingOverlaySlotPlans()

		if InCombatLockdown() then
			return;
		end

		for tFlushButton, tPendingPlan in pairs(sPendingOverlaySlotPlans) do
			if tPendingPlan["generation"] == sOverlayConfigGeneration then
				twipe(sOverlayBuild["plannedSlotSpecs"]);
				twipe(sOverlayBuild["plannedSlotOrder"]);

				for tOrderCnt = 1, #(tPendingPlan["plannedOrder"] or sEmpty) do
					tPlannedKey = tPendingPlan["plannedOrder"][tOrderCnt];

					sOverlayBuild["plannedSlotSpecs"][tPlannedKey] = tPendingPlan["plannedSpecs"][tPlannedKey];
					sOverlayBuild["plannedSlotOrder"][#sOverlayBuild["plannedSlotOrder"] + 1] = tPlannedKey;
				end

				VUHDO_reconcileOverlaySlotsForButton(tFlushButton, tFlushButton:GetName());
			end
		end

		return;

	end



	--
	local tChainGroups;
	local tChainGroupMeta;
	local tChainFillEntry;
	local tChainEntryKey;
	local tChainGroupTemplate;
	local tChainButtonSetup;
	local tChainLayoutIndex;
	local tContainerParent;
	local tFrameLevelOffset;
	local tOverlayHostFrame;
	local tChainGroupKeyBase;
	local tChainGroupKey;
	function VUHDO_buildOverlayChainContainerTemplate(aButton, aTargetFrame, aFillEntries, anIndicatorKey)

		tChainGroups = { };
		tChainGroupMeta = { };

		twipe(sOverlayBuild["chainGroupKeySet"]);

		for tChainIdx = 1, #aFillEntries do
			tChainFillEntry = aFillEntries[tChainIdx];
			tChainEntryKey = tChainFillEntry["entryKey"] or tChainFillEntry["bouquetIdx"] or tChainIdx;

			tChainButtonSetup = VUHDO_buildOverlayButtonSetup(aButton, aTargetFrame, tChainFillEntry);
			tChainLayoutIndex = #tChainGroups + 1;

			tChainGroupKeyBase = "chain_" .. tChainEntryKey;
			tChainGroupKey = tChainGroupKeyBase;

			if sOverlayBuild["chainGroupKeySet"][tChainGroupKey] then
				tChainGroupKey = format("%s:d%d", tChainGroupKeyBase, tChainIdx);
			end

			sOverlayBuild["chainGroupKeySet"][tChainGroupKey] = true;

			tChainGroupTemplate = {
				["key"] = tChainGroupKey,
				["filterString"] = tChainFillEntry["filterString"],
				["candidateFilters"] = tChainFillEntry["candidateFilters"],
				["templateName"] = tChainFillEntry["templateName"] or VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE,
				["buttonSetup"] = tChainButtonSetup,
				["maxFrameCount"] = 1,
				["layout"] = {
					["elementWidth"] = tChainButtonSetup["width"],
					["elementHeight"] = tChainButtonSetup["height"],
					["elementSpacing"] = 0,
					["lineSpacing"] = 0,
					["forceNewLine"] = true,
					["layoutIndex"] = tChainLayoutIndex,
				},
			};

			tChainGroups[#tChainGroups + 1] = tChainGroupTemplate;

			tChainGroupMeta[#tChainGroupMeta + 1] = {
				["entryKey"] = tChainEntryKey,
				["filterString"] = tChainFillEntry["filterString"],
				["candidateFilters"] = tChainFillEntry["candidateFilters"],
				["friendlyOnly"] = tChainFillEntry["friendlyOnly"],
				["hostileOnly"] = tChainFillEntry["hostileOnly"],
				["alwaysEnabled"] = tChainFillEntry["alwaysEnabled"],
				["staticColor"] = tChainFillEntry["staticColor"],
				["bouquetIdx"] = tChainFillEntry["bouquetIdx"],
				["overlayGate"] = tChainFillEntry["overlayGate"],
			};

			VUHDO_applyOverlayGateFlags(tChainGroupMeta[#tChainGroupMeta]);
		end

		tContainerParent, tOverlayHostFrame, tFrameLevelOffset = VUHDO_resolveOverlayContainerAnchorFields(aButton, aTargetFrame, 1);

		return {
			["parent"] = tContainerParent,
			["anchor"] = {
				["mode"] = "topEdge",
				["target"] = tOverlayHostFrame or aTargetFrame,
				["levelBase"] = aButton,
				["frameLevelOffset"] = tFrameLevelOffset,
			},
			["isOverlay"] = true,
			["isFillChain"] = true,
			["chainHasBaseline"] = anIndicatorKey == "BACKGROUND_BAR",
			["overlayTargetBar"] = aTargetFrame,
			["overlayHostFrame"] = tOverlayHostFrame,
			["groups"] = tChainGroups,
		}, tChainGroupMeta;

	end




	--
	local tPendingKey;
	function VUHDO_enqueueOverlayContainerBuild(aButton, anIndicatorKey, anEntryKey, aContainerTemplate, anOverlayEntry, aChainGroupMeta)

		if not sPendingOverlayBuilds[aButton] then
			sPendingOverlayBuilds[aButton] = {
				["generation"] = sOverlayConfigGeneration,
				["pendingCount"] = 0,
				["entries"] = { },
			};
		end

		tPendingKey = anIndicatorKey .. ":" .. anEntryKey;

		if not sPendingOverlayBuilds[aButton]["entries"][tPendingKey] then
			sPendingOverlayBuilds[aButton]["pendingCount"] = sPendingOverlayBuilds[aButton]["pendingCount"] + 1;
		end

		sPendingOverlayBuilds[aButton]["entries"][tPendingKey] = {
			["indicatorKey"] = anIndicatorKey,
			["entryKey"] = anEntryKey,
			["containerTemplate"] = aContainerTemplate,
			["overlayEntry"] = anOverlayEntry,
			["chainGroupMeta"] = aChainGroupMeta,
		};

		VUHDO_deferAcquireOverlayContainer(aButton, anIndicatorKey, anEntryKey);

		return;

	end



	--
	local tElementHeight;
	local tButtonSetup;
	local tGroupTemplate;
	local tContainerParent;
	local tOverlayHostFrame;
	local tFrameLevelOffset;
	function VUHDO_buildMissingBuffContainerTemplate(aButton, aTargetFrame, aCategName, aSpellIdMap, aBarWidth, aBarHeight, aFrameLevelOffset, aMissingBuffSublevel, aSlotIndex)

		tElementHeight = aBarHeight + VUHDO_PixelUtil.RoundToPixel(1, 1) + 1;

		tButtonSetup = {
			["width"] = aBarWidth,
			["height"] = tElementHeight,
			["targetBar"] = aTargetFrame,
			["shadowValueMode"] = "cover",
			["templateName"] = VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE,
			["disableMouse"] = true,
		};

		tGroupTemplate = {
			["key"] = "missingBuff_" .. aCategName,
			["filterString"] = "HELPFUL",
			["candidateFilters"] = {
				["includeSpellIDs"] = aSpellIdMap,
			},
			["templateName"] = VUHDO_AURA_BUTTON_OVERLAY_TEMPLATE,
			["buttonSetup"] = tButtonSetup,
			["maxFrameCount"] = 1,
			["layout"] = {
				["elementWidth"] = aBarWidth,
				["elementHeight"] = tElementHeight,
				["elementSpacing"] = 0,
				["lineSpacing"] = 0,
				["forceNewLine"] = true,
				["layoutIndex"] = 1,
			},
		};

		tContainerParent, tOverlayHostFrame, tFrameLevelOffset = VUHDO_resolveOverlayContainerAnchorFields(aButton, aTargetFrame, aFrameLevelOffset or 1);

		return {
			["parent"] = tContainerParent,
			["anchor"] = {
				["mode"] = "topEdge",
				["target"] = tOverlayHostFrame or aTargetFrame,
				["levelBase"] = aButton,
				["frameLevelOffset"] = tFrameLevelOffset,
			},
			["isOverlay"] = true,
			["isMissingBuff"] = true,
			["overlayTargetBar"] = aTargetFrame,
			["overlayHostFrame"] = tOverlayHostFrame,
			["missingBuffCategName"] = aCategName,
			["missingBuffSublevel"] = aMissingBuffSublevel or 0,
			["missingBuffSlotIndex"] = aSlotIndex,
			["groups"] = {
				tGroupTemplate,
			},
			["alwaysEnabled"] = true,
		};

	end
end




do
	--
	function VUHDO_markOverlayRebuildPendingInCombat()

		if VUHDO_OVERLAYS_REBUILD_PENDING then
			return;
		end


		VUHDO_OVERLAYS_REBUILD_PENDING = true;

		sOverlayConfigGeneration = sOverlayConfigGeneration + 1;

		return;

	end



	--
	local tStampChainGroupMetaEntry;
	local function VUHDO_stampOverlayContainerMetadata(aButtonName, aContainerData, aChainGroupMeta, anIndicatorKey)

		if not aContainerData then
			return;
		end

		aContainerData["hasOverlayGate"] = nil;

		if aChainGroupMeta then
			aContainerData["chainGroupMeta"] = aChainGroupMeta;
			aContainerData["alwaysEnabled"] = nil;

			for tStampChainGroupIdx = 1, #aChainGroupMeta do
				tStampChainGroupMetaEntry = aChainGroupMeta[tStampChainGroupIdx];

				if tStampChainGroupMetaEntry["alwaysEnabled"] then
					aContainerData["alwaysEnabled"] = true;
				end

				if tStampChainGroupMetaEntry["overlayGate"] then
					aContainerData["hasOverlayGate"] = true;
				end

				if aContainerData["groupKeys"] and aContainerData["groupKeys"][tStampChainGroupIdx] then
					tStampChainGroupMetaEntry["groupKey"] = aContainerData["groupKeys"][tStampChainGroupIdx];
				end
			end
		end

		if aContainerData["chainBaselineTexture"] then
			VUHDO_applyStoredChainBaselineColor(aButtonName, aContainerData);
		end

		if anIndicatorKey and anIndicatorKey ~= "DISPEL_OVERLAY" then
			sHasAnyOverlays = true;
		end

		return;

	end



	--
	local tReconcilePlannedOrder;
	local tReconcilePlannedSpecs;
	local tReconcilePlannedKey;
	local tReconcilePlannedSpec;
	local tReconcileIndicatorKey;
	local tReconcileEntryKey;
	local tReconcileExistingOverlays;
	local tReconcileExistingContainer;
	local tContainerTemplate;
	local tFilterContainer;
	local tFilterSignature;
	local tVolatileAction;
	local tFreshContainer;
	function VUHDO_reconcileOverlayContainersForButton(aButton, aButtonName)

		tReconcilePlannedOrder = sOverlayBuild["plannedContainerOrder"];
		tReconcilePlannedSpecs = sOverlayBuild["plannedContainerSpecs"];

		if not sOverlayContainerPlans[aButtonName] then
			sOverlayContainerPlans[aButtonName] = { ["plannedEntries"] = { } };
		end

		twipe(sOverlayContainerPlans[aButtonName]["plannedEntries"]);

		if #tReconcilePlannedOrder == 0 then
			tReconcileExistingOverlays = VUHDO_OVERLAY_CONTAINERS[aButtonName];

			if tReconcileExistingOverlays then
				for tReconcileRetireIndicatorKey, tReconcileRetireIndicatorEntry in pairs(tReconcileExistingOverlays) do
					for _, tReconcileRetireContainerData in pairs(tReconcileRetireIndicatorEntry) do
						VUHDO_retireAuraContainer(aButton, tReconcileRetireContainerData);
					end
				end

				VUHDO_OVERLAY_CONTAINERS[aButtonName] = nil;
			end

			return;
		end

		if not VUHDO_OVERLAY_CONTAINERS[aButtonName] then
			VUHDO_OVERLAY_CONTAINERS[aButtonName] = { };
		end

		tReconcileExistingOverlays = VUHDO_OVERLAY_CONTAINERS[aButtonName];

		twipe(sOverlayBuild["plannedContainerSet"]);

		for tReconcileOrderCnt = 1, #tReconcilePlannedOrder do
			tReconcilePlannedKey = tReconcilePlannedOrder[tReconcileOrderCnt];
			sOverlayBuild["plannedContainerSet"][tReconcilePlannedKey] = true;
			sOverlayContainerPlans[aButtonName]["plannedEntries"][tReconcilePlannedKey] = true;
		end

		for tReconcileRetireIndicatorKey, tReconcileRetireIndicatorEntry in pairs(tReconcileExistingOverlays) do
			for tReconcileRetireEntryKey, tReconcileRetireContainerData in pairs(tReconcileRetireIndicatorEntry) do
				tReconcilePlannedKey = tReconcileRetireIndicatorKey .. ":" .. tReconcileRetireEntryKey;

				if not sOverlayBuild["plannedContainerSet"][tReconcilePlannedKey] then
					VUHDO_retireAuraContainer(aButton, tReconcileRetireContainerData);
					tReconcileRetireIndicatorEntry[tReconcileRetireEntryKey] = nil;
				else
					tReconcilePlannedSpec = tReconcilePlannedSpecs[tReconcilePlannedKey];

					if tReconcilePlannedSpec and tReconcileRetireContainerData["buildSignature"] ~= tReconcilePlannedSpec["buildSignature"] then
						VUHDO_retireAuraContainer(aButton, tReconcileRetireContainerData);
						tReconcileRetireIndicatorEntry[tReconcileRetireEntryKey] = nil;
					end
				end
			end

			if not next(tReconcileRetireIndicatorEntry) then
				tReconcileExistingOverlays[tReconcileRetireIndicatorKey] = nil;
			end
		end

		for tReconcileOrderCnt = 1, #tReconcilePlannedOrder do
			tReconcilePlannedKey = tReconcilePlannedOrder[tReconcileOrderCnt];
			tReconcilePlannedSpec = tReconcilePlannedSpecs[tReconcilePlannedKey];

			if tReconcilePlannedSpec then
				tReconcileIndicatorKey = tReconcilePlannedSpec["indicatorKey"];
				tReconcileEntryKey = tReconcilePlannedSpec["entryKey"];
				tReconcileExistingContainer = tReconcileExistingOverlays[tReconcileIndicatorKey]
					and tReconcileExistingOverlays[tReconcileIndicatorKey][tReconcileEntryKey];

				if tReconcileExistingContainer then
					tContainerTemplate = tReconcilePlannedSpec["containerTemplate"];

					tReconcileExistingContainer["containerTemplate"] = tContainerTemplate;

					VUHDO_stampOverlayContainerMetadata(aButtonName, tReconcileExistingContainer, tReconcilePlannedSpec["chainGroupMeta"], tReconcileIndicatorKey);

					tFilterContainer = tReconcileExistingContainer["container"];
					tFilterSignature = VUHDO_getAuraContainerFilterSignature(tContainerTemplate);

					if tFilterContainer and tReconcileExistingContainer["filterSignature"] ~= tFilterSignature then
						VUHDO_applyAuraContainerFilterPass(tFilterContainer, tReconcileExistingContainer, tContainerTemplate);

						tReconcileExistingContainer["filterSignature"] = tFilterSignature;
					end

					tVolatileAction = VUHDO_reconcileAuraContainerVolatilePass(tFilterContainer, tReconcileExistingContainer, tContainerTemplate);

					if VUHDO_AURA_VOLATILE_PASS_REBUILD == tVolatileAction then
						VUHDO_retireAuraContainer(aButton, tReconcileExistingContainer);

						tFreshContainer = VUHDO_acquireAuraContainer(aButton, tContainerTemplate, "overlayVolatile");

						if tFreshContainer then
							if not tReconcileExistingOverlays[tReconcileIndicatorKey] then
								tReconcileExistingOverlays[tReconcileIndicatorKey] = { };
							end

							tReconcileExistingOverlays[tReconcileIndicatorKey][tReconcileEntryKey] = tFreshContainer;

							VUHDO_stampOverlayContainerMetadata(aButtonName, tFreshContainer, tReconcilePlannedSpec["chainGroupMeta"], tReconcileIndicatorKey);
						end
					elseif VUHDO_AURA_VOLATILE_PASS_DEFER == tVolatileAction then
						VUHDO_deferVolatilePassForButton(aButton);
					end
				else
					VUHDO_enqueueOverlayContainerBuild(aButton, tReconcileIndicatorKey, tReconcileEntryKey,
						tReconcilePlannedSpec["containerTemplate"], nil, tReconcilePlannedSpec["chainGroupMeta"]);
				end
			end
		end

		return;

	end



	--
	local tButtonName;
	local tPendingBuild;
	local tPendingKey;
	local tPendingEntry;
	local tContainerTemplate;
	local tContainerData;
	local tUnit;
	local tChainGroupMeta;
	function VUHDO_acquireOverlayContainerForEntry(aButton, anIndicatorKey, anEntryKey)

		if not aButton or not anIndicatorKey or not anEntryKey then
			return;
		end

		tButtonName = aButton:GetName();

		if not tButtonName then
			return;
		end

		tPendingBuild = sPendingOverlayBuilds[aButton];

		if not tPendingBuild then
			return;
		end

		tPendingKey = anIndicatorKey .. ":" .. anEntryKey;
		tPendingEntry = tPendingBuild["entries"][tPendingKey];

		if not tPendingEntry then
			return;
		end

		if InCombatLockdown() then
			VUHDO_deferAcquireOverlayContainer(aButton, anIndicatorKey, anEntryKey);

			return;
		end

		tPendingBuild["entries"][tPendingKey] = nil;
		tPendingBuild["pendingCount"] = tPendingBuild["pendingCount"] - 1;

		if tPendingBuild["generation"] ~= sOverlayConfigGeneration then
			if tPendingBuild["pendingCount"] <= 0 then
				sPendingOverlayBuilds[aButton] = nil;
			end

			return;
		end

		tContainerTemplate = tPendingEntry["containerTemplate"];
		tChainGroupMeta = tPendingEntry["chainGroupMeta"];

		tContainerData = VUHDO_acquireAuraContainer(aButton, tContainerTemplate, "overlayNew");

		if tContainerData then
			if not VUHDO_OVERLAY_CONTAINERS[tButtonName] then
				VUHDO_OVERLAY_CONTAINERS[tButtonName] = { };
			end

			if not VUHDO_OVERLAY_CONTAINERS[tButtonName][anIndicatorKey] then
				VUHDO_OVERLAY_CONTAINERS[tButtonName][anIndicatorKey] = { };
			end

			VUHDO_stampOverlayContainerMetadata(tButtonName, tContainerData, tChainGroupMeta, anIndicatorKey);

			VUHDO_OVERLAY_CONTAINERS[tButtonName][anIndicatorKey][anEntryKey] = tContainerData;
		end

		if tPendingBuild["pendingCount"] <= 0 then
			sPendingOverlayBuilds[aButton] = nil;

			tUnit = aButton["raidid"] or aButton:GetAttribute("unit");

			if tUnit then
				VUHDO_deferSyncOverlaysForUnit(tUnit);
			end
		end

		return;

	end



	--
	local tPlannedCount;
	function VUHDO_getPendingOverlayBuildCount()

		tPlannedCount = 0;

		for _, tPendingBuild in pairs(sPendingOverlayBuilds) do
			tPlannedCount = tPlannedCount + (tPendingBuild["pendingCount"] or 0);
		end

		return tPlannedCount;

	end



	--
	function VUHDO_getOverlayBuildGateState()

		return sHasAnyOverlays, VUHDO_isAuraModeContainers(), VUHDO_isAuraDataRestricted(), VUHDO_isBarColorsDispelOverlayConfigured();

	end



	--
	function VUHDO_getOverlayConfigGeneration()

		return sOverlayConfigGeneration;

	end



	--
	function VUHDO_getOverlayBuildKeyForButton(aButtonName)

		return sOverlayConfigKeys[aButtonName];

	end



	--
	function VUHDO_invalidateOverlayBuildKeys()


		twipe(sOverlayConfigKeys);
		twipe(sOverlayEntryPrototypeCache);

		return;

	end



	--
	function VUHDO_getOverlayZeroPlanDiagnostics()

		return sOverlayZeroPlanCount, sOverlayZeroPlanLastReason;

	end



	--
	local tPrototypeCacheEntry;
	function VUHDO_getOverlayPrototypeCacheDiagnostics(aPanelNum, anIndicatorKey, aBouquetName)

		if not aPanelNum or not anIndicatorKey or not aBouquetName or aBouquetName == "" then
			return nil, nil;
		end

		tPrototypeCacheEntry = sOverlayEntryPrototypeCache[aPanelNum .. ":" .. anIndicatorKey .. ":" .. aBouquetName];

		if not tPrototypeCacheEntry then
			return nil, nil;
		end

		if tPrototypeCacheEntry["prototypes"] then
			return tPrototypeCacheEntry["generation"], #tPrototypeCacheEntry["prototypes"];
		end

		return tPrototypeCacheEntry["generation"], nil;

	end



	--
	local tButtonName;
	function VUHDO_releaseOverlaysForButton(aButton)

		if not aButton then
			return;
		end


		if InCombatLockdown() then
			VUHDO_markOverlayRebuildPendingInCombat();

			return;
		end

		tButtonName = aButton:GetName();

		sPendingOverlayBuilds[aButton] = nil;

		VUHDO_disableOverlaySlotHost(tButtonName);

		sPendingOverlaySlotPlans[aButton] = nil;

		if tButtonName and VUHDO_OVERLAY_CONTAINERS[tButtonName] then
			for _, tIndicatorEntry in pairs(VUHDO_OVERLAY_CONTAINERS[tButtonName]) do
				for _, tContainerData in pairs(tIndicatorEntry) do
					VUHDO_retireAuraContainer(aButton, tContainerData);
				end
			end

			VUHDO_OVERLAY_CONTAINERS[tButtonName] = nil;
		end

		if tButtonName and VUHDO_MISSING_BUFF_CONTAINERS[tButtonName] then
			for _, tContainerData in pairs(VUHDO_MISSING_BUFF_CONTAINERS[tButtonName]) do
				VUHDO_retireAuraContainer(aButton, tContainerData);
			end

			VUHDO_MISSING_BUFF_CONTAINERS[tButtonName] = nil;

			VUHDO_clearMissingBuffBuildKey(tButtonName);
		end

		if tButtonName then
			sOverlayConfigKeys[tButtonName] = nil;
		end

		return;

	end



	--
	function VUHDO_invalidateAllOverlayPlans()

		if InCombatLockdown() then
			VUHDO_markOverlayRebuildPendingInCombat();

			return;
		end

		twipe(sOverlayConfigKeys);
		twipe(sOverlayEntryPrototypeCache);
		twipe(sPendingOverlayBuilds);
		twipe(sPendingOverlaySlotPlans);
		twipe(sOverlayContainerPlans);

		sOverlayConfigGeneration = sOverlayConfigGeneration + 1;

		return;

	end



	--
	function VUHDO_releaseAllOverlays()

		if InCombatLockdown() then
			VUHDO_markOverlayRebuildPendingInCombat();

			return;
		end


		for _, tIndicatorEntries in pairs(VUHDO_OVERLAY_CONTAINERS) do
			for _, tIndicatorEntry in pairs(tIndicatorEntries) do
				for _, tContainerData in pairs(tIndicatorEntry) do
					VUHDO_retireAuraContainer(nil, tContainerData);
				end
			end
		end

		for tReleaseAllMissingButtonName, tMissingBuffEntry in pairs(VUHDO_MISSING_BUFF_CONTAINERS) do
			for _, tContainerData in pairs(tMissingBuffEntry) do
				VUHDO_retireAuraContainer(nil, tContainerData);
			end

			VUHDO_clearMissingBuffBuildKey(tReleaseAllMissingButtonName);
		end

		twipe(VUHDO_MISSING_BUFF_CONTAINERS);
		twipe(VUHDO_OVERLAY_CONTAINERS);
		twipe(sOverlayContainerPlans);
		twipe(sOverlayConfigKeys);
		twipe(sPendingOverlayBuilds);
		twipe(sPendingOverlaySlotPlans);

		for tReleaseButtonName, _ in pairs(VUHDO_OVERLAY_SLOT_HOSTS) do
			VUHDO_disableOverlaySlotHost(tReleaseButtonName);
		end

		twipe(sOverlaySublevelAllocators);
		twipe(sOverlayEntryPrototypeCache);

		sOverlayConfigGeneration = sOverlayConfigGeneration + 1;
		sHasAnyOverlays = false;

		return;

	end



	--
	function VUHDO_flushPendingOverlayRebuild()

		if not VUHDO_OVERLAYS_REBUILD_PENDING then
			return;
		end

		if InCombatLockdown() then
			return;
		end

		VUHDO_OVERLAYS_REBUILD_PENDING = false;

		VUHDO_releaseAllOverlays();

		VUHDO_resyncAuraDisplayMode(false);

		return;

	end



	--
	function VUHDO_flushPendingOverlayAcquires()

		if InCombatLockdown() then
			return;
		end

		for tFlushButton, tFlushPendingBuild in pairs(sPendingOverlayBuilds) do
			for tFlushPendingKey, tFlushPendingEntry in pairs(tFlushPendingBuild["entries"] or sEmpty) do
				VUHDO_deferAcquireOverlayContainer(tFlushButton, tFlushPendingEntry["indicatorKey"], tFlushPendingEntry["entryKey"]);
			end
		end

		VUHDO_flushPendingOverlaySlotPlans();

		return;

	end



	--
	local tBarGlowFilterEntry;
	local tBarGlowFilterString;
	local tBarGlowHostileEntry;
	local tDispelTypeNames;
	local tScopeGroup;
	local function VUHDO_buildAuraGroupBarGlowFilterEntries(aGroupId, aColorType, aFilterString, aCandidateFilters, aUnitScope)

		twipe(sOverlayBuild["barGlowFilterEntries"]);

		if aColorType == VUHDO_AURA_GROUP_COLOR_CUSTOM then
			tBarGlowFilterEntry = {
				["filterString"] = aFilterString,
				["candidateFilters"] = aCandidateFilters,
				["entryKeySuffix"] = "",
			};

			tScopeGroup = {
				["unitScope"] = aUnitScope,
			};

			VUHDO_applyAuraGroupScopeFlags(tBarGlowFilterEntry, tScopeGroup);

			sOverlayBuild["barGlowFilterEntries"][1] = tBarGlowFilterEntry;
		elseif aColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
			tBarGlowFilterString = aFilterString;

			tDispelTypeNames = VUHDO_getPlayerDispelGlowTypeNames();

			if VUHDO_isAuraGroupScopeFriendly(aUnitScope) and next(tDispelTypeNames) ~= nil then
				tBarGlowFilterEntry = {
					["filterString"] = tBarGlowFilterString,
					["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(aCandidateFilters, tDispelTypeNames),
					["friendlyOnly"] = true,
					["entryKeySuffix"] = ":friendly",
				};

				sOverlayBuild["barGlowFilterEntries"][#sOverlayBuild["barGlowFilterEntries"] + 1] = tBarGlowFilterEntry;
			end

			if VUHDO_isAuraGroupScopeHostile(aUnitScope) then
				tBarGlowHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getPlayerPurgeGlowTypeNames(), aFilterString, aCandidateFilters, nil, nil, aGroupId, nil, nil, nil, false, true);

				if tBarGlowHostileEntry then
					sOverlayBuild["barGlowFilterEntries"][#sOverlayBuild["barGlowFilterEntries"] + 1] = tBarGlowHostileEntry;
				end
			end
		elseif aColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
			tDispelTypeNames = VUHDO_getAllDispelGlowTypeNames();

			if VUHDO_isAuraGroupScopeFriendly(aUnitScope) and next(tDispelTypeNames) ~= nil then
				tBarGlowFilterEntry = {
					["filterString"] = aFilterString,
					["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(aCandidateFilters, tDispelTypeNames),
					["friendlyOnly"] = true,
					["entryKeySuffix"] = ":friendly",
				};

				sOverlayBuild["barGlowFilterEntries"][#sOverlayBuild["barGlowFilterEntries"] + 1] = tBarGlowFilterEntry;
			end

			if VUHDO_isAuraGroupScopeHostile(aUnitScope) then
				tBarGlowHostileEntry = VUHDO_buildHostileDispelEntry(VUHDO_getAllDispelGlowTypeNames(), aFilterString, aCandidateFilters, nil, nil, aGroupId, nil, nil, nil, false, true);

				if tBarGlowHostileEntry then
					sOverlayBuild["barGlowFilterEntries"][#sOverlayBuild["barGlowFilterEntries"] + 1] = tBarGlowHostileEntry;
				end
			end
		end

		return sOverlayBuild["barGlowFilterEntries"];

	end



	--
	local tBarGlowFilterSpecs;
	local tBarGlowFilterSpec;
	local tBarGlowColorType;
	local tBarGlowCandidateFilters;
	local tBarGlowCandidateBranches;
	local tBranchFilterStrings;
	local tBarGlowCanColorBarGroups;
	local tBarGlowGroup;
	local tBarGlowGroupId;
	local tBarGlowGroupData;
	local tBarGlowResolved;
	local tBarGlowColor;
	local tBarGlowDefaultColor;
	local tBarGlowEntry;
	local tBarGlowPlannedCount;
	local tBarGlowCanBuild;
	local function VUHDO_buildAuraGroupBarGlowOverlaysForButton(aButton, aPanelNum)

		tBarGlowPlannedCount = 0;

		tBarGlowCanColorBarGroups = VUHDO_getCanColorBarGroups();

		for tGroupCnt = #tBarGlowCanColorBarGroups, 1, -1 do
			tBarGlowGroup = tBarGlowCanColorBarGroups[tGroupCnt];

			if tBarGlowGroup["canGlowBar"] then
				tBarGlowGroupId = tBarGlowGroup["groupId"];
				tBarGlowGroupData = VUHDO_getAuraGroup(tBarGlowGroupId);

				tBarGlowResolved = VUHDO_getAuraGroupResolvedFilters(tBarGlowGroupData);

				if tBarGlowGroupData and tBarGlowResolved then
					tBarGlowCanBuild = tBarGlowResolved["expressible"];

					if not tBarGlowCanBuild then
						tBarGlowCanBuild = tBarGlowResolved["candidateFilters"] and tBarGlowResolved["candidateFilters"]["includeSpellIDs"];
					end

					if tBarGlowCanBuild then
						tBarGlowColorType = tBarGlowGroup["colorType"] or VUHDO_AURA_GROUP_COLOR_DISPEL;

						tBarGlowCandidateBranches = tBarGlowResolved["candidateBranches"];
						tBranchFilterStrings = tBarGlowResolved["candidateBranchFilterStrings"];

						if not tBarGlowCandidateBranches or #tBarGlowCandidateBranches == 0 then
							tBarGlowCandidateBranches = { tBarGlowResolved["candidateFilters"] };
						end

						for tBarGlowBranchIdx = 1, #tBarGlowCandidateBranches do
							tBarGlowCandidateFilters = VUHDO_copyOverlayCandidateFilters(tBarGlowCandidateBranches[tBarGlowBranchIdx], nil);

							tBarGlowFilterSpecs = VUHDO_buildAuraGroupBarGlowFilterEntries(tBarGlowGroupId, tBarGlowColorType, (tBranchFilterStrings and tBranchFilterStrings[tBarGlowBranchIdx]) or tBarGlowResolved["filterString"], tBarGlowCandidateFilters, tBarGlowGroup["unitScope"]);

							for tBarGlowFilterIdx = 1, #tBarGlowFilterSpecs do
								tBarGlowFilterSpec = tBarGlowFilterSpecs[tBarGlowFilterIdx];

								tBarGlowEntry = {
									["filterString"] = tBarGlowFilterSpec["filterString"],
									["candidateFilters"] = tBarGlowFilterSpec["candidateFilters"],
									["friendlyOnly"] = tBarGlowFilterSpec["friendlyOnly"],
									["hostileOnly"] = tBarGlowFilterSpec["hostileOnly"],
									["shape"] = "glow",
									["glowIcon"] = false,
									["glowStyle"] = tBarGlowGroup["glowBarStyle"] or VUHDO_DEFAULT_AURA_GLOW_STYLE,
									["glowColorType"] = tBarGlowColorType,
									["auraGroupBarGlow"] = true,
									["glowGroupId"] = tBarGlowGroupId,
									["unitButton"] = aButton,
									["hideIcon"] = true,
									["entryKey"] = "glow:" .. tBarGlowGroupId .. tBarGlowFilterSpec["entryKeySuffix"],
									["frameLevelOffset"] = 8 + (#tBarGlowCanColorBarGroups - tGroupCnt),
								};

								if tBarGlowBranchIdx > 1 then
									tBarGlowEntry["entryKey"] = format("%s:b%d", tBarGlowEntry["entryKey"], tBarGlowBranchIdx);
								end

								if tBarGlowEntry["glowColorType"] == VUHDO_AURA_GROUP_COLOR_CUSTOM then
									tBarGlowColor = tBarGlowGroup["glowBarColor"];

									if not tBarGlowColor or not tBarGlowColor["R"] then
										tBarGlowDefaultColor = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"] and VUHDO_PANEL_SETUP["BAR_COLORS"]["DEBUFF_BAR_GLOW"];
										tBarGlowColor = tBarGlowDefaultColor;
									end

									tBarGlowEntry["glowColor"] = tBarGlowColor;
								end

								tBarGlowEntry["sublevelSlots"] = VUHDO_allocateOverlaySublevels(aButton, 1, "AURA_GROUP_BAR_GLOW", aPanelNum);

								VUHDO_planOverlaySlot(aButton, "AURA_GROUP_BAR_GLOW", tBarGlowEntry["entryKey"], aButton, tBarGlowEntry);

								tBarGlowPlannedCount = tBarGlowPlannedCount + 1;
							end
						end
					end
				end
			end
		end

		return tBarGlowPlannedCount;

	end



	--
	local function VUHDO_buildSwiftmendBarGlowOverlaysForButton(aButton, aPanelNum)

		tBarGlowPlannedCount = 0;

		if not VUHDO_INDICATOR_CONFIG[aPanelNum] then
			return tBarGlowPlannedCount;
		end

		tBarGlowGroup = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["SWIFTMEND_INDICATOR"];

		if not tBarGlowGroup or not tBarGlowGroup["barGlowStyle"] or tBarGlowGroup["barGlowStyle"] == "none" then
			return tBarGlowPlannedCount;
		end

		tBarGlowGroupId = VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"]["SWIFTMEND_INDICATOR"];

		if not tBarGlowGroupId or tBarGlowGroupId == "" then
			return tBarGlowPlannedCount;
		end

		tBarGlowResolved = VUHDO_buildOverlayEntryPrototypes(aPanelNum, "SWIFTMEND_INDICATOR", tBarGlowGroupId);

		if not tBarGlowResolved then
			return tBarGlowPlannedCount;
		end

		tBarGlowDefaultColor = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"] and VUHDO_PANEL_SETUP["BAR_COLORS"]["DEBUFF_BAR_GLOW"];

		for tBarGlowBranchIdx = 1, #tBarGlowResolved do
			tBarGlowGroupData = tBarGlowResolved[tBarGlowBranchIdx];

			if not (tBarGlowGroupData["shadowBar"] and tBarGlowGroupData["shadowValueMode"] ~= "duration") then
				tBarGlowEntry = {
					["filterString"] = tBarGlowGroupData["filterString"],
					["candidateFilters"] = VUHDO_copyOverlayCandidateFilters(tBarGlowGroupData["candidateFilters"], nil),
					["friendlyOnly"] = tBarGlowGroupData["friendlyOnly"],
					["hostileOnly"] = tBarGlowGroupData["hostileOnly"],
					["identityGate"] = tBarGlowGroupData["identityGate"],
					["isCompoundFilterString"] = tBarGlowGroupData["isCompoundFilterString"],
					["alwaysEnabled"] = tBarGlowGroupData["alwaysEnabled"],
					["valueGates"] = tBarGlowGroupData["valueGates"],
					["isValueGateActiveVariant"] = tBarGlowGroupData["isValueGateActiveVariant"],
					["overlayGate"] = tBarGlowGroupData["overlayGate"],
					["bouquetIdx"] = tBarGlowGroupData["bouquetIdx"],
					["shape"] = "glow",
					["glowIcon"] = false,
					["hideIcon"] = true,
					["auraGroupBarGlow"] = true,
					["specialDotBarGlow"] = true,
					["unitButton"] = aButton,
					["glowStyle"] = tBarGlowGroup["barGlowStyle"],
					["glowColorType"] = VUHDO_AURA_GROUP_COLOR_CUSTOM,
					["frameLevelOffset"] = 8,
				};

				if tBarGlowDefaultColor then
					tBarGlowEntry["glowColor"] = {
						["R"] = tBarGlowDefaultColor["R"],
						["G"] = tBarGlowDefaultColor["G"],
						["B"] = tBarGlowDefaultColor["B"],
						["O"] = tBarGlowDefaultColor["O"],
					};
				end

				tBarGlowEntry["entryKey"] = "swiftmendGlow:" .. (tBarGlowGroupData["entryKey"] or tBarGlowBranchIdx);

				tBarGlowEntry["sublevelSlots"] = VUHDO_allocateOverlaySublevels(aButton, 1, "SWIFTMEND_BAR_GLOW", aPanelNum);

				VUHDO_planOverlaySlot(aButton, "SWIFTMEND_BAR_GLOW", tBarGlowEntry["entryKey"], aButton, tBarGlowEntry);

				tBarGlowPlannedCount = tBarGlowPlannedCount + 1;
			end
		end

		return tBarGlowPlannedCount;

	end



	--
	local tExpectsCanColorBarGroups;
	local function VUHDO_areOverlayPlanInputsUsable(aPanelNum, anBuildBouquetOverlays)

		if anBuildBouquetOverlays and not VUHDO_INDICATOR_CONFIG[aPanelNum] then
			return false;
		end

		if anBuildBouquetOverlays then
			tExpectsCanColorBarGroups = false;

			for _, tGroup in pairs(VUHDO_CONFIG["AURA_GROUPS"] or sEmpty) do
				if tGroup["enabled"] ~= false and (tGroup["canColorBar"] or tGroup["canGlowBar"]) then
					tExpectsCanColorBarGroups = true;

					break;
				end
			end

			if tExpectsCanColorBarGroups and #VUHDO_getCanColorBarGroups() == 0 then
				return false;
			end
		end

		return true;

	end



	--
	local tPendingBuild;
	local tPlannedCount;
	local tPlannedBouquetCount;
	local tBarGlowPlannedCount;
	local tBouquetName;
	local tTargetFrame;
	local tOverlayEntries;
	local tEntryKey;
	local tContainerTemplate;
	local tDispelOverlayEntry;
	local tOverlayPrototypes;
	local tChainGroupMeta;
	local tPlannedContainerKey;
	local tBuildBouquetOverlays;
	function VUHDO_buildOverlaysForButton(aButton, aButtonName, aPanelNum, aUnit)

		if sOverlayConfigKeys[aButtonName] == sOverlayConfigGeneration then
			return;
		end


		tPendingBuild = sPendingOverlayBuilds[aButton];

		if tPendingBuild and tPendingBuild["generation"] == sOverlayConfigGeneration then
			return;
		end

		if InCombatLockdown() then
			if VUHDO_OVERLAY_CONTAINERS[aButtonName] or VUHDO_OVERLAY_SLOT_HOSTS[aButtonName] then
				return;
			end

			VUHDO_markOverlayRebuildPendingInCombat();

			return;
		end

		twipe(sOverlayBuild["plannedSlotSpecs"]);
		twipe(sOverlayBuild["plannedSlotOrder"]);
		twipe(sOverlayBuild["plannedContainerSpecs"]);
		twipe(sOverlayBuild["plannedContainerOrder"]);

		VUHDO_resetOverlaySublevelAllocator(aButton);
		VUHDO_resetOverlaySublevelAllocator(VUHDO_getHealthBar(aButton, 3));

		tBuildBouquetOverlays = VUHDO_isAuraModeContainers() or VUHDO_isAuraDataRestricted() or sHasAnyOverlays;

		if not VUHDO_areOverlayPlanInputsUsable(aPanelNum, tBuildBouquetOverlays) then
			return;
		end

		tPlannedCount = 0;
		tPlannedBouquetCount = 0;

		if tBuildBouquetOverlays and VUHDO_INDICATOR_CONFIG[aPanelNum] then
			for tIndicatorKey, _ in pairs(VUHDO_INDICATOR_OVERLAY_TARGETS) do
				tBouquetName = VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"][tIndicatorKey];

				if tBouquetName and tBouquetName ~= "" then
					tTargetFrame = VUHDO_resolveOverlayTarget(aButton, tIndicatorKey);

					if tTargetFrame then
						tOverlayPrototypes = VUHDO_buildOverlayEntryPrototypes(aPanelNum, tIndicatorKey, tBouquetName);
						tOverlayEntries = VUHDO_stampOverlayEntriesFromPrototypes(tOverlayPrototypes, aPanelNum, tIndicatorKey, aButton, tTargetFrame);

						twipe(sOverlayBuild["fillEntries"]);
						twipe(sOverlayBuild["nonFillEntries"]);

						for _, tOverlayEntry in ipairs(tOverlayEntries or sEmpty) do
							if tOverlayEntry["shadowBar"] and tOverlayEntry["shadowValueMode"] ~= "duration" then
								sOverlayBuild["fillEntries"][#sOverlayBuild["fillEntries"] + 1] = tOverlayEntry;
							else
								sOverlayBuild["nonFillEntries"][#sOverlayBuild["nonFillEntries"] + 1] = tOverlayEntry;
							end
						end

						if #sOverlayBuild["fillEntries"] > 0 and (VUHDO_isAuraModeContainers() or VUHDO_isAuraDataRestricted()) then
							tContainerTemplate, tChainGroupMeta = VUHDO_buildOverlayChainContainerTemplate(aButton, tTargetFrame, sOverlayBuild["fillEntries"], tIndicatorKey);

							tPlannedContainerKey = tIndicatorKey .. ":fillChain";
							sOverlayBuild["plannedContainerSpecs"][tPlannedContainerKey] = {
								["indicatorKey"] = tIndicatorKey,
								["entryKey"] = "fillChain",
								["buildSignature"] = VUHDO_getAuraContainerBuildSignature(tContainerTemplate),
								["containerTemplate"] = tContainerTemplate,
								["chainGroupMeta"] = tChainGroupMeta,
							};
							sOverlayBuild["plannedContainerOrder"][#sOverlayBuild["plannedContainerOrder"] + 1] = tPlannedContainerKey;

							tPlannedCount = tPlannedCount + 1;
							tPlannedBouquetCount = tPlannedBouquetCount + 1;
						end

						for _, tOverlayEntry in ipairs(sOverlayBuild["nonFillEntries"]) do
							tEntryKey = tOverlayEntry["entryKey"] or tOverlayEntry["bouquetIdx"];

							VUHDO_planOverlaySlot(aButton, tIndicatorKey, tEntryKey, tTargetFrame, tOverlayEntry);

							tPlannedCount = tPlannedCount + 1;
							tPlannedBouquetCount = tPlannedBouquetCount + 1;
						end
					end
				end
			end
		end

		tDispelOverlayEntry = VUHDO_buildBarColorsDispelOverlayEntry();

		if tDispelOverlayEntry then
			tTargetFrame = VUHDO_getHealthBar(aButton, 3);

			if tTargetFrame then
				tDispelOverlayEntry["sublevelSlots"] = VUHDO_allocateOverlaySublevels(tTargetFrame, tDispelOverlayEntry["shadowBar"] and 2 or 1, "DISPEL_OVERLAY", aPanelNum);

				tDispelOverlayEntry["alwaysEnabled"] = true;

				VUHDO_planOverlaySlot(aButton, "DISPEL_OVERLAY", "barColorsDispelOverlay", tTargetFrame, tDispelOverlayEntry);

				tPlannedCount = tPlannedCount + 1;
			end
		end

		tDispelOverlayEntry = VUHDO_buildBarColorsHostilePurgeOverlayEntry();

		if tDispelOverlayEntry then
			tTargetFrame = VUHDO_getHealthBar(aButton, 3);

			if tTargetFrame then
				tDispelOverlayEntry["sublevelSlots"] = VUHDO_allocateOverlaySublevels(tTargetFrame, tDispelOverlayEntry["shadowBar"] and 2 or 1, "DISPEL_OVERLAY", aPanelNum);

				tDispelOverlayEntry["alwaysEnabled"] = true;

				VUHDO_planOverlaySlot(aButton, "DISPEL_OVERLAY", "barColorsHostilePurgeOverlay", tTargetFrame, tDispelOverlayEntry);

				tPlannedCount = tPlannedCount + 1;
			end
		end

		if tBuildBouquetOverlays and VUHDO_INDICATOR_CONFIG[aPanelNum] then
			tBarGlowPlannedCount = VUHDO_buildAuraGroupBarGlowOverlaysForButton(aButton, aPanelNum);

			tPlannedCount = tPlannedCount + tBarGlowPlannedCount;
			tPlannedBouquetCount = tPlannedBouquetCount + tBarGlowPlannedCount;

			tBarGlowPlannedCount = VUHDO_buildSwiftmendBarGlowOverlaysForButton(aButton, aPanelNum);

			tPlannedCount = tPlannedCount + tBarGlowPlannedCount;
			tPlannedBouquetCount = tPlannedBouquetCount + tBarGlowPlannedCount;
		end

		if tPlannedCount == 0 then
			sPendingOverlayBuilds[aButton] = nil;
			sPendingOverlaySlotPlans[aButton] = nil;

			VUHDO_disableOverlaySlotHost(aButtonName);
			VUHDO_reconcileOverlayContainersForButton(aButton, aButtonName);

			sOverlayConfigKeys[aButtonName] = sOverlayConfigGeneration;

			sOverlayZeroPlanCount = sOverlayZeroPlanCount + 1;
			sOverlayZeroPlanLastReason = "plannedZero";
		else
			VUHDO_reconcileOverlayContainersForButton(aButton, aButtonName);
			VUHDO_reconcileOverlaySlotsForButton(aButton, aButtonName);

			sOverlayConfigKeys[aButtonName] = sOverlayConfigGeneration;

			if tPlannedBouquetCount > 0 then
				sHasAnyOverlays = true;
			end
		end

		return;

	end
end



--
local tThreatMarkFlashTexture;
function VUHDO_stopOverlayThreatMarkFlashForSlotRecord(aSlotRecord)

	if not aSlotRecord or aSlotRecord["indicatorKey"] ~= "THREAT_MARK" then
		return;
	end

	tThreatMarkFlashTexture = aSlotRecord["slotFrame"] and aSlotRecord["slotFrame"]["FillTexture"];

	if tThreatMarkFlashTexture then
		VUHDO_stopThreatMarkTextureFlash(tThreatMarkFlashTexture);
	end

	return;

end



--
function VUHDO_syncOverlayThreatMarkFlashForSlotRecord(aSlotRecord, anIsEnabled)

	if not aSlotRecord or aSlotRecord["indicatorKey"] ~= "THREAT_MARK" then
		return;
	end

	tThreatMarkFlashTexture = aSlotRecord["slotFrame"] and aSlotRecord["slotFrame"]["FillTexture"];

	if not tThreatMarkFlashTexture then
		return;
	end

	if anIsEnabled then
		VUHDO_startThreatMarkTextureFlash(tThreatMarkFlashTexture);
	else
		VUHDO_stopThreatMarkTextureFlash(tThreatMarkFlashTexture);
	end

	return;

end



--
local tGateContainer;
local tGateSlotFrame;
local sOnUpdateModeRunOnce = Enum.OnUpdateMode.RunOnce;
function VUHDO_gateOverlaySlotHost(aHostData, aButton)

	if not aHostData or not aHostData["container"] then
		return;
	end

	tGateContainer = aHostData["container"];

	if aHostData["lastHostGated"] and not tGateContainer:IsEnabled() and not tGateContainer:IsShown() then
		return;
	end

	for tGateSlotKey, tGateSlotRecord in pairs(aHostData["slotRecords"] or sEmpty) do
		VUHDO_stopOverlayThreatMarkFlashForSlotRecord(tGateSlotRecord);

		tGateSlotFrame = tGateSlotRecord["slotFrame"];

		if tGateSlotFrame then
			VUHDO_releaseAuraButtonGlowState(tGateSlotFrame);
		end
	end

	if aButton then
		if aButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] then
			VUHDO_stopUnitButtonAuraGroupGlow(aButton, VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY);

			aButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] = nil;
		elseif aButton["hasAuraGroupBarGlow"] then
			VUHDO_stopUnitButtonAuraGroupGlow(aButton, VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY);
		end
	end


	if tGateContainer:IsEnabled() then
		tGateContainer:SetEnabled(false);
	end

	if tGateContainer:IsShown() then
		tGateContainer:SetShown(false);
	end

	if tGateContainer:GetUnit() ~= "none" then
		tGateContainer:SetUnit("none");
	end

	tGateContainer:SetOnUpdateMode(sOnUpdateModeRunOnce);

	aHostData["lastSyncedUnit"] = nil;
	aHostData["lastSyncedGuid"] = nil;

	if aHostData["lastSyncedSlotEnabled"] then
		twipe(aHostData["lastSyncedSlotEnabled"]);
	end

	aHostData["lastHostGated"] = true;

	return;

end



do
	--
	function VUHDO_syncAuraGroupBarGlowOverlay(aButton, aContainerData, anIsEnabled)

		if anIsEnabled then
			if aButton["hasAuraGroupBarGlow"] then
				VUHDO_stopUnitButtonAuraGroupGlow(aButton, VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY);
			end

			aButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] = true;

			return true;
		end

		if aButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] then
			VUHDO_stopUnitButtonAuraGroupGlow(aButton, VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY);

			aButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] = nil;
		end

		return false;

	end



	--
	local tButtonName;
	local tCurrentUnit;
	local tLastSyncedUnit;
	function VUHDO_invalidateRemappedOverlayUnitBindings()

		twipe(sInvalidateRemappedButtonNameToUnit);

		for tInvalidateUnit, tButtons in pairs(VUHDO_UNIT_BUTTONS or sEmpty) do
			for _, tButton in pairs(tButtons) do
				tButtonName = tButton:GetName();

				if tButtonName then
					sInvalidateRemappedButtonNameToUnit[tButtonName] = tInvalidateUnit;
				end
			end
		end

		for tButtonName, tSlotHostData in pairs(VUHDO_OVERLAY_SLOT_HOSTS) do
			tCurrentUnit = sInvalidateRemappedButtonNameToUnit[tButtonName];
			tLastSyncedUnit = tSlotHostData["lastSyncedUnit"];

			if tLastSyncedUnit and tLastSyncedUnit ~= tCurrentUnit then
				VUHDO_clearOverlaySlotHostUnit(tSlotHostData);
			end
		end

		for tButtonName, tIndicatorEntries in pairs(VUHDO_OVERLAY_CONTAINERS) do
			tCurrentUnit = sInvalidateRemappedButtonNameToUnit[tButtonName];

			for _, tIndicatorEntry in pairs(tIndicatorEntries) do
				for _, tContainerData in pairs(tIndicatorEntry) do
					tLastSyncedUnit = tContainerData["lastSyncedUnit"];

					if tLastSyncedUnit and tLastSyncedUnit ~= tCurrentUnit then
						VUHDO_clearAuraContainerBinding(tContainerData);
					end
				end
			end
		end

		return;

	end



	--
	local tButtonName;
	local tSlotHostData;
	function VUHDO_resetOverlaysForUnit(aUnit)

		if not aUnit then
			return;
		end

		for _, tButton in pairs(VUHDO_getUnitButtonsSafe(aUnit)) do
			tButtonName = tButton:GetName();

			if tButtonName then
				tSlotHostData = VUHDO_OVERLAY_SLOT_HOSTS[tButtonName];

				if tSlotHostData then
					tSlotHostData["lastSyncedUnit"] = nil;
					tSlotHostData["lastSyncedGuid"] = nil;

					if not tSlotHostData["lastSyncedSlotEnabled"] then
						tSlotHostData["lastSyncedSlotEnabled"] = { };
					else
						twipe(tSlotHostData["lastSyncedSlotEnabled"]);
					end

					for _, tSlotRecord in pairs(tSlotHostData["slotRecords"] or sEmpty) do
						tSlotRecord["bouquetGated"] = nil;
					end
				end
			end

			for _, tIndicatorEntry in pairs(tButtonName and VUHDO_OVERLAY_CONTAINERS[tButtonName] or sEmpty) do
				for _, tContainerData in pairs(tIndicatorEntry) do
					tContainerData["lastSyncedUnit"] = nil;
					tContainerData["lastSyncedGuid"] = nil;
					tContainerData["lastSyncedEnabled"] = nil;
					tContainerData["lastSyncedGroupEnabled"] = nil;

					if tContainerData["bouquetGatedGroups"] then
						twipe(tContainerData["bouquetGatedGroups"]);
					end
				end
			end
		end

		return;

	end



	--
	function VUHDO_clearOverlaysForUnit(aUnit)

		if not aUnit then
			return;
		end

		for _, tButton in pairs(VUHDO_getUnitButtonsSafe(aUnit)) do
			tButtonName = tButton:GetName();

			if tButtonName then
				tSlotHostData = VUHDO_OVERLAY_SLOT_HOSTS[tButtonName];

				if tSlotHostData then
					VUHDO_clearOverlaySlotHostUnit(tSlotHostData);
				end

				for _, tIndicatorEntry in pairs(VUHDO_OVERLAY_CONTAINERS[tButtonName] or sEmpty) do
					for _, tContainerData in pairs(tIndicatorEntry) do
						VUHDO_clearAuraContainerBinding(tContainerData);
					end
				end
			end
		end

		return;

	end
end



--
local function VUHDO_isOverlayGateOpen(anOverlayGate)

	if "SWIFTMEND" == anOverlayGate then
		return VUHDO_isSwiftmendReady() == true;
	end

	return true;

end



do
	--
	local tSlotEnabled;
	local tShouldSuppress;
	local tGateActive;
	function VUHDO_evaluateOverlaySlotEnabled(aSlotHostData, aSlotKey, aSlotRecord, anIsAuraDataRestricted, anIsAuraModeContainers, aCanAttack, aGateInfo)

		tSlotEnabled = aSlotHostData["plannedSlots"] and aSlotHostData["plannedSlots"][aSlotKey] and (aSlotRecord["alwaysEnabled"] or anIsAuraDataRestricted or anIsAuraModeContainers);

		if tSlotEnabled then
			if aSlotRecord["friendlyOnly"] and aCanAttack then
				tSlotEnabled = false;
			end

			if aSlotRecord["hostileOnly"] and not aCanAttack then
				tSlotEnabled = false;
			end
		end

		tShouldSuppress = VUHDO_isAuraDisplaySuppressed(aSlotRecord);

		if tSlotEnabled and tShouldSuppress then
			tSlotEnabled = false;
		end

		if tSlotEnabled and aSlotRecord["bouquetGated"] then
			tSlotEnabled = false;
		end

		if tSlotEnabled and aSlotRecord["valueGates"] then
			tGateActive = VUHDO_isAnyOverlayValueGateActive(aSlotRecord["valueGates"], aGateInfo);

			if tGateActive ~= (aSlotRecord["isValueGateActiveVariant"] or false) then
				tSlotEnabled = false;
			end
		end

		if tSlotEnabled and not VUHDO_isOverlayGateOpen(aSlotRecord["overlayGate"]) then
			tSlotEnabled = false;
		end

		return tSlotEnabled and true or false;

	end
end



do
	--
	local tIsAuraDataRestricted;
	local tIsAuraModeContainers;
	local tIsBarColorsDispelOverlayConfigured;
	local tCanAttack;
	local tButtonName;
	local tPanelNum;
	local tContainer;
	local tIsEnabled;
	local tChainGroupMeta;
	local tChainGroupMetaEntry;
	local tGroupEnabled;
	local tGroupKey;
	local tLastSyncedGroupEnabled;
	local tUnitGlowApplied;
	local tGateInfo;
	local tGateActive;
	local tEnabledChanged;
	local tGroupEnabledChanged;
	local tUnitRebound;
	local tOccupantGuid;
	local tLastSyncedGuid;
	local tIsDisconnected;
	local tShouldSuppress;
	local tSlotHostData;
	local tSlotEnabled;
	local tSlotEnabledChanged;
	local tLastSyncedSlotEnabled;
	local tHostNeedsUnit;
	local tDeferHostEnable;
	local tNeedsHostRefresh;
	local tDesiredFilterString;
	function VUHDO_syncOverlaysForUnit(aUnit)

		if not aUnit then
			return;
		end

		tIsAuraModeContainers = VUHDO_isAuraModeContainers();
		tIsBarColorsDispelOverlayConfigured = VUHDO_isBarColorsDispelOverlayConfigured();
		tIsAuraDataRestricted = VUHDO_isAuraDataRestricted();

		if not tIsAuraModeContainers and not tIsAuraDataRestricted and not sHasAnyOverlays and not tIsBarColorsDispelOverlayConfigured then
			return;
		end

		VUHDO_rewriteAuraContainerGateState(aUnit);

		tGateInfo = VUHDO_RAID and VUHDO_RAID[aUnit];
		tCanAttack = VUHDO_AURA_CONTAINER_GATE_STATE["canAttack"];
		tIsDisconnected = VUHDO_AURA_CONTAINER_GATE_STATE["isDisconnected"];

		for _, tButton in pairs(VUHDO_getUnitButtonsSafe(aUnit)) do
			tButtonName = tButton:GetName();

			if tButtonName then
				tPanelNum = VUHDO_BUTTON_CACHE[tButton];

				if tPanelNum and (tIsAuraModeContainers or tIsAuraDataRestricted or sHasAnyOverlays or tIsBarColorsDispelOverlayConfigured) then
					VUHDO_buildOverlaysForButton(tButton, tButtonName, tPanelNum, aUnit);
				end

				if tPanelNum and tIsAuraModeContainers then
					VUHDO_reconcileMissingBuffContainersForButton(tButton, tButtonName, tPanelNum);
				end

				VUHDO_syncMissingBuffContainersForButton(tButton, aUnit);

				tUnitGlowApplied = false;

				tSlotHostData = VUHDO_OVERLAY_SLOT_HOSTS[tButtonName];

				if tSlotHostData and tSlotHostData["container"] then
					tContainer = tSlotHostData["container"];
					tSlotEnabledChanged = false;
					tHostNeedsUnit = false;
					tDeferHostEnable = false;

					if tIsDisconnected then
						VUHDO_gateOverlaySlotHost(tSlotHostData, tButton);
					else
						if tSlotHostData["lastHostGated"] then
							tDeferHostEnable = true;

							tSlotHostData["lastHostGated"] = nil;

							if tSlotHostData["lastSyncedSlotEnabled"] then
								twipe(tSlotHostData["lastSyncedSlotEnabled"]);
							end
						end

						if not tSlotHostData["lastSyncedSlotEnabled"] then
							tSlotHostData["lastSyncedSlotEnabled"] = { };
						end

						tLastSyncedSlotEnabled = tSlotHostData["lastSyncedSlotEnabled"];

						for tSlotKey, tSlotRecord in pairs(tSlotHostData["slotRecords"]) do
							tSlotEnabled = VUHDO_evaluateOverlaySlotEnabled(tSlotHostData, tSlotKey, tSlotRecord, tIsAuraDataRestricted, tIsAuraModeContainers, tCanAttack, tGateInfo);

							if tLastSyncedSlotEnabled[tSlotKey] ~= tSlotEnabled then
								tDesiredFilterString = tSlotEnabled and (tSlotRecord["filterString"] or "HELPFUL") or "";

								if tSlotRecord["appliedFilterString"] ~= tDesiredFilterString or tSlotRecord["appliedSuppress"] ~= (not tSlotEnabled) then
									if tSlotEnabled then
										tContainer:SetAuraSlotFilterString(tSlotKey, tSlotRecord["filterString"] or "HELPFUL");
										tContainer:SetAuraSlotCandidateFilters(tSlotKey, tSlotRecord["candidateFilters"]);

										tSlotRecord["appliedFilterString"] = tSlotRecord["filterString"] or "HELPFUL";
										tSlotRecord["appliedCandidateSignature"] = VUHDO_getCandidateFiltersSignature(tSlotRecord["candidateFilters"]);
										tSlotRecord["appliedSuppress"] = false;
									else
										tContainer:SetAuraSlotFilterString(tSlotKey, "");

										tSlotRecord["appliedFilterString"] = "";
										tSlotRecord["appliedSuppress"] = true;
									end

									tSlotEnabledChanged = true;
								end

								tLastSyncedSlotEnabled[tSlotKey] = tSlotEnabled;

								VUHDO_syncOverlayThreatMarkFlashForSlotRecord(tSlotRecord, tSlotEnabled);
							end

							if tSlotEnabled then
								tHostNeedsUnit = true;

								if tSlotRecord["durationSetupPending"] and tSlotRecord["slotFrame"] then
									VUHDO_reapplyOverlayDurationSlotSetup(tSlotRecord["slotFrame"], tSlotRecord["buttonSetup"]);

									tSlotRecord["durationSetupPending"] = nil;
								end
							end

							if tSlotRecord["auraGroupBarGlow"] and not tSlotRecord["specialDotBarGlow"] then
								if VUHDO_syncAuraGroupBarGlowOverlay(tSlotRecord["unitButton"] or tButton, tSlotRecord, tSlotEnabled) then
									tUnitGlowApplied = true;
								end
							end
						end

						if tHostNeedsUnit then
							tOccupantGuid = tGateInfo and tGateInfo["guid"];
							tUnitRebound = tSlotHostData["lastSyncedUnit"] ~= aUnit;

							if not tUnitRebound then
								tLastSyncedGuid = tSlotHostData["lastSyncedGuid"];

								if not tOccupantGuid or issecretvalue(tOccupantGuid) then
									tUnitRebound = true;
								elseif not tLastSyncedGuid or issecretvalue(tLastSyncedGuid) then
									tUnitRebound = true;
								elseif tLastSyncedGuid ~= tOccupantGuid then
									tUnitRebound = true;
								end
							end

							if tUnitRebound then
								if tContainer:GetUnit() ~= aUnit then
									tContainer:SetUnit(aUnit);
								end

								if tOccupantGuid and issecretvalue(tOccupantGuid) then
									tOccupantGuid = nil;
								end

								tSlotHostData["lastSyncedUnit"] = aUnit;
								tSlotHostData["lastSyncedGuid"] = tOccupantGuid;
							end

							if tDeferHostEnable then
								tContainer:SetEnabled(true);
								tContainer:SetShown(true);

								tDeferHostEnable = false;
								tNeedsHostRefresh = true;
							else
								tNeedsHostRefresh = false;
							end

							if tUnitRebound or tSlotEnabledChanged or tNeedsHostRefresh then
								VUHDO_refreshAuraContainer(tContainer);
							end
						elseif tSlotHostData["lastSyncedUnit"] or tSlotEnabledChanged then
							VUHDO_clearOverlaySlotHostUnit(tSlotHostData);
						end

						if not tHostNeedsUnit and tDeferHostEnable then
							tSlotHostData["lastHostGated"] = true;
						end
					end
				end

				for _, tIndicatorEntry in pairs(VUHDO_OVERLAY_CONTAINERS[tButtonName] or sEmpty) do
					for _, tContainerData in pairs(tIndicatorEntry) do
						tContainer = tContainerData and tContainerData["container"];

						if tContainer then
							tChainGroupMeta = tContainerData["chainGroupMeta"];
							tGroupEnabledChanged = false;

							if tChainGroupMeta then
								tIsEnabled = false;

								if not tContainerData["lastSyncedGroupEnabled"] then
									tContainerData["lastSyncedGroupEnabled"] = { };
								end

								tLastSyncedGroupEnabled = tContainerData["lastSyncedGroupEnabled"];

								for tChainGroupIdx = 1, #tChainGroupMeta do
									tChainGroupMetaEntry = tChainGroupMeta[tChainGroupIdx];
									tGroupEnabled = tChainGroupMetaEntry["alwaysEnabled"] or tIsAuraDataRestricted or tIsAuraModeContainers;

									if tGroupEnabled and tChainGroupMetaEntry["friendlyOnly"] and tCanAttack then
										tGroupEnabled = false;
									end

									if tGroupEnabled and tChainGroupMetaEntry["hostileOnly"] and not tCanAttack then
										tGroupEnabled = false;
									end

									tShouldSuppress = VUHDO_isAuraDisplaySuppressed(tChainGroupMetaEntry);

									if tGroupEnabled and tShouldSuppress then
										tGroupEnabled = false;
									end

									if tGroupEnabled and (tContainerData["bouquetGatedGroups"] or sEmpty)[tChainGroupMetaEntry["groupKey"]] then
										tGroupEnabled = false;
									end

									if tGroupEnabled and not VUHDO_isOverlayGateOpen(tChainGroupMetaEntry["overlayGate"]) then
										tGroupEnabled = false;
									end

									if tGroupEnabled then
										tIsEnabled = true;
									end

									tGroupKey = tChainGroupMetaEntry["groupKey"];

									if tGroupKey and tLastSyncedGroupEnabled[tGroupKey] ~= tGroupEnabled then
										if tGroupEnabled then
											tContainer:SetAuraGroupMaxFrameCount(tGroupKey, 1);
											tContainer:SetAuraGroupFilterString(tGroupKey, tChainGroupMetaEntry["filterString"] or "HELPFUL");
											tContainer:SetAuraGroupCandidateFilters(tGroupKey, tChainGroupMetaEntry["candidateFilters"]);
										else
											tContainer:SetAuraGroupMaxFrameCount(tGroupKey, 0);
										end

										tLastSyncedGroupEnabled[tGroupKey] = tGroupEnabled;
										tGroupEnabledChanged = true;
									end
								end
							else
								tIsEnabled = tContainerData["alwaysEnabled"] or tIsAuraDataRestricted or tIsAuraModeContainers;

								if tIsEnabled then
									if tContainerData["friendlyOnly"] and tCanAttack then
										tIsEnabled = false;
									end

									if tContainerData["hostileOnly"] and not tCanAttack then
										tIsEnabled = false;
									end
								end

								tShouldSuppress = VUHDO_isAuraDisplaySuppressed(tContainerData);

								if tIsEnabled and tShouldSuppress then
									tIsEnabled = false;
								end
							end

							if tIsEnabled and tContainerData["valueGates"] then
								tGateActive = VUHDO_isAnyOverlayValueGateActive(tContainerData["valueGates"], tGateInfo);

								if tGateActive ~= (tContainerData["isValueGateActiveVariant"] or false) then
									tIsEnabled = false;
								end
							end

							tUnitRebound = false;

							if tIsEnabled then
								tOccupantGuid = tGateInfo and tGateInfo["guid"];
								tUnitRebound = tContainerData["lastSyncedUnit"] ~= aUnit;

								if not tUnitRebound then
									tLastSyncedGuid = tContainerData["lastSyncedGuid"];

									if not tOccupantGuid or issecretvalue(tOccupantGuid) then
										tUnitRebound = true;
									elseif not tLastSyncedGuid or issecretvalue(tLastSyncedGuid) then
										tUnitRebound = true;
									elseif tLastSyncedGuid ~= tOccupantGuid then
										tUnitRebound = true;
									end
								end

								if tUnitRebound then
									tContainer:SetUnit(aUnit);

									if tOccupantGuid and issecretvalue(tOccupantGuid) then
										tOccupantGuid = nil;
									end

									tContainerData["lastSyncedUnit"] = aUnit;
									tContainerData["lastSyncedGuid"] = tOccupantGuid;
								end
							end

							if tIsEnabled ~= tContainerData["lastSyncedEnabled"] then
								tEnabledChanged = true;

								tContainer:SetEnabled(tIsEnabled);
								tContainer:SetShown(tIsEnabled);

								tContainerData["lastSyncedEnabled"] = tIsEnabled;

								if tContainerData["ownsBackgroundFill"] then
									if tIsEnabled then
										if tButtonName then
											VUHDO_applyStoredChainBaselineColor(tButtonName, tContainerData);
										end

										VUHDO_hideOverlayFillChainBackgroundForData(tContainerData);
									else
										VUHDO_showOverlayFillChainBackgroundForData(tContainerData);
									end
								end
							else
								tEnabledChanged = false;
							end

							if tIsEnabled then
								if tUnitRebound or tEnabledChanged or tGroupEnabledChanged then
									VUHDO_refreshAuraContainer(tContainer);
								end
							end

						end
					end
				end

				if tUnitGlowApplied then
					tButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] = true;
				elseif tButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] then
					VUHDO_stopUnitButtonAuraGroupGlow(tButton, VUHDO_CUSTOM_GLOW_AURA_GROUP_KEY);

					tButton[VUHDO_AURA_GROUP_GLOW_ACTIVE_KEY] = nil;
				end
			end
		end

		return;

	end
end



do
	--
	local tUnit;
	local tSlotKey;
	local tSlotRecord;
	local tButton;
	local tOwnerButton;
	function VUHDO_syncSwiftmendOverlayGates()

		twipe(sSwiftmendGateResyncedUnits);

		for _, tSlotHostData in pairs(VUHDO_OVERLAY_SLOT_HOSTS) do
			if tSlotHostData["container"] and tSlotHostData["overlayGateKeys"] and #tSlotHostData["overlayGateKeys"] > 0 then
				tSlotKey = tSlotHostData["overlayGateKeys"][1];
				tSlotRecord = tSlotHostData["slotRecords"][tSlotKey];
				tButton = tSlotRecord and tSlotRecord["unitButton"];
				tUnit = tButton and (tButton["raidid"] or tButton:GetAttribute("unit"));

				if tUnit and not sSwiftmendGateResyncedUnits[tUnit] then
					sSwiftmendGateResyncedUnits[tUnit] = true;

					VUHDO_deferSyncOverlaysForUnit(tUnit);
				end
			end
		end

		for _, tIndicatorEntries in pairs(VUHDO_OVERLAY_CONTAINERS) do
			for _, tIndicatorEntry in pairs(tIndicatorEntries) do
				for _, tContainerData in pairs(tIndicatorEntry) do
					if tContainerData["hasOverlayGate"] then
						tOwnerButton = tContainerData["ownerButton"];
						tUnit = tOwnerButton and (tOwnerButton["raidid"] or tOwnerButton:GetAttribute("unit"));

						if tUnit and not sSwiftmendGateResyncedUnits[tUnit] then
							sSwiftmendGateResyncedUnits[tUnit] = true;

							VUHDO_deferSyncOverlaysForUnit(tUnit);
						end
					end
				end
			end
		end

		return;

	end
end