local _;

local format = format;

local UnitHealth = UnitHealth;
local UnitHealthMax = UnitHealthMax;
local UnitHealthMissing = UnitHealthMissing;
local UnitHealthPercent = UnitHealthPercent;
local AbbreviateNumbers = AbbreviateNumbers;
local CreateColorCurve =C_CurveUtil and C_CurveUtil.CreateColorCurve;
local CreateCurve = C_CurveUtil and C_CurveUtil.CreateCurve;
local CreateColor = CreateColor;
local TruncateWhenZero = C_StringUtil and C_StringUtil.TruncateWhenZero;
local WrapString = C_StringUtil and C_StringUtil.WrapString;
local UnitGetDetailedHealPrediction = UnitGetDetailedHealPrediction;
local CreateUnitHealPredictionCalculator = CreateUnitHealPredictionCalculator;
local UnitIsGhost = UnitIsGhost;

local VUHDO_getHealthBar;
local VUHDO_getBarText;
local VUHDO_getBarTextSolo;
local VUHDO_getLifeText;
local VUHDO_getUnitHealthPercent;
local VUHDO_getUnitHealthModiPercent;
local VUHDO_getColoredString;
local VUHDO_getBarIconFrame;
local VUHDO_utf8Cut;
local VUHDO_getDisplayUnit;
local VUHDO_isBossUnit;
local VUHDO_getIncHealOnUnit;
local VUHDO_getUnitOverallShieldRemain;
local VUHDO_UIFrameFlash;

local VUHDO_PANEL_SETUP;
local VUHDO_BUTTON_CACHE;
local VUHDO_RAID;
local VUHDO_CONFIG;
local VUHDO_BAR_COLOR;
local VUHDO_THREAT_CFG;
local VUHDO_KILO_OPTIONS;
local VUHDO_NAME_TEXTS;
local VUHDO_RAID_NAME_COUNTS;
local VUHDO_NAME_SUFFIX_SEPARATOR;

local sSecretsEnabled = VUHDO_SECRETS_ENABLED;
local sIsOverhealText;
local sIsAggroText;
local sLifeColor;
local sIsNoRangeFade;
local sHealthTextCalculator;
local sHideIrrelevantCurve;
local sHideMissingZeroCurve;
local sShowWhenFullCurve;
local sShowWhenIrrelevantCurve;
local sScaleTo100CeilCurve;



--
local tThresholdDecimal;
local tCurve;
local function VUHDO_buildHideIrrelevantCurve()

	if not sSecretsEnabled then
		return nil;
	end

	tCurve = CreateColorCurve();
	tCurve:SetType(Enum.LuaCurveType.Step);

	-- FIXME: operation modes other than neutral with 100% trigger are bugged
	--tThresholdDecimal = VUHDO_CONFIG["EMERGENCY_TRIGGER"] / 100;
	tThresholdDecimal = 1;

	tCurve:AddPoint(0.0, CreateColor(1, 1, 1, 1));
	tCurve:AddPoint(tThresholdDecimal, CreateColor(1, 1, 1, 0));
	tCurve:AddPoint(1.0, CreateColor(1, 1, 1, 0));

	return tCurve;

end



--
local function VUHDO_buildHideMissingZeroCurve()

	if not sSecretsEnabled then
		return nil;
	end

	tCurve = CreateColorCurve();
	tCurve:SetType(Enum.LuaCurveType.Step);

	tCurve:AddPoint(0.0, CreateColor(1, 1, 1, 1));
	tCurve:AddPoint(1.0, CreateColor(1, 1, 1, 0));

	return tCurve;

end



--
local function VUHDO_buildShowWhenFullCurve()

	if not sSecretsEnabled then
		return nil;
	end

	tCurve = CreateColorCurve();
	tCurve:SetType(Enum.LuaCurveType.Step);

	tCurve:AddPoint(0.0, CreateColor(1, 1, 1, 0));
	tCurve:AddPoint(1.0, CreateColor(1, 1, 1, 1));

	return tCurve;

end



--
local function VUHDO_buildShowWhenIrrelevantCurve()

	if not sSecretsEnabled then
		return nil;
	end

	tCurve = CreateColorCurve();
	tCurve:SetType(Enum.LuaCurveType.Step);

	-- FIXME: operation modes other than neutral with 100% trigger are bugged
	--tThresholdDecimal = VUHDO_CONFIG["EMERGENCY_TRIGGER"] / 100;
	tThresholdDecimal = 1;

	tCurve:AddPoint(0.0, CreateColor(1, 1, 1, 0));
	tCurve:AddPoint(tThresholdDecimal, CreateColor(1, 1, 1, 1));
	tCurve:AddPoint(1.0, CreateColor(1, 1, 1, 1));

	return tCurve;

end



--
function VUHDO_customHealthTextInitLocalOverrides()

	VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];
	VUHDO_BUTTON_CACHE = _G["VUHDO_BUTTON_CACHE"];
	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_BAR_COLOR = VUHDO_PANEL_SETUP["BAR_COLORS"];
	VUHDO_THREAT_CFG = VUHDO_CONFIG["THREAT"];
	VUHDO_KILO_OPTIONS = _G["VUHDO_KILO_OPTIONS"];
	VUHDO_NAME_TEXTS = _G["VUHDO_NAME_TEXTS"];
	VUHDO_RAID_NAME_COUNTS = _G["VUHDO_RAID_NAME_COUNTS"];
	VUHDO_NAME_SUFFIX_SEPARATOR = _G["VUHDO_NAME_SUFFIX_SEPARATOR"];

	VUHDO_getHealthBar = _G["VUHDO_getHealthBar"];
	VUHDO_getBarText = _G["VUHDO_getBarText"];
	VUHDO_getBarTextSolo = _G["VUHDO_getBarTextSolo"];
	VUHDO_getLifeText = _G["VUHDO_getLifeText"];
	VUHDO_getUnitHealthPercent = _G["VUHDO_getUnitHealthPercent"];
	VUHDO_getUnitHealthModiPercent = _G["VUHDO_getUnitHealthModiPercent"];
	VUHDO_getColoredString = _G["VUHDO_getColoredString"];
	VUHDO_getBarIconFrame = _G["VUHDO_getBarIconFrame"];
	VUHDO_utf8Cut = _G["VUHDO_utf8Cut"];
	VUHDO_getDisplayUnit = _G["VUHDO_getDisplayUnit"];
	VUHDO_isBossUnit = _G["VUHDO_isBossUnit"];
	VUHDO_getIncHealOnUnit = _G["VUHDO_getIncHealOnUnit"];
	VUHDO_getUnitOverallShieldRemain = _G["VUHDO_getUnitOverallShieldRemain"];
	VUHDO_UIFrameFlash = _G["VUHDO_UIFrameFlash"];

	sIsOverhealText = VUHDO_CONFIG["SHOW_TEXT_OVERHEAL"];
	sIsAggroText = VUHDO_CONFIG["THREAT"]["AGGRO_USE_TEXT"];
	sLifeColor = VUHDO_PANEL_SETUP["PANEL_COLOR"]["HEALTH_TEXT"];
	sIsNoRangeFade = VUHDO_CONFIG["CUSTOM_DEBUFF"]["isNoRangeFade"];

	sHealthTextCalculator = nil;

	if sSecretsEnabled then
		sHealthTextCalculator = CreateUnitHealPredictionCalculator();

		if sHealthTextCalculator then
			sHealthTextCalculator:SetDamageAbsorbClampMode(Enum.UnitDamageAbsorbClampMode.MaximumHealth);
			sHealthTextCalculator:SetHealAbsorbClampMode(Enum.UnitHealAbsorbClampMode.MaximumHealth);
			sHealthTextCalculator:SetIncomingHealClampMode(Enum.UnitIncomingHealClampMode.MaximumHealth);
			sHealthTextCalculator:SetHealAbsorbMode(Enum.UnitHealAbsorbMode.Total);
			sHealthTextCalculator:SetIncomingHealOverflowPercent(1.0);
			sHealthTextCalculator:SetMaximumHealthMode(Enum.UnitMaximumHealthMode.Default);
		end

		sScaleTo100CeilCurve = CreateCurve and CreateCurve();

		if sScaleTo100CeilCurve then
			sScaleTo100CeilCurve:SetType(Enum.LuaCurveType.Linear);

			sScaleTo100CeilCurve:AddPoint(0.0, 0.99999);
			sScaleTo100CeilCurve:AddPoint(1.0, 100.99999);
		end
	end

	sHideIrrelevantCurve = VUHDO_buildHideIrrelevantCurve();
	sHideMissingZeroCurve = VUHDO_buildHideMissingZeroCurve();
	sShowWhenFullCurve = VUHDO_buildShowWhenFullCurve();
	sShowWhenIrrelevantCurve = VUHDO_buildShowWhenIrrelevantCurve();

	return;

end



--
local function VUHDO_getKiloText(aNumber, aMaxNumber, aSetup)

	return aSetup["LIFE_TEXT"]["verbose"] and aNumber 
		or (aNumber >= 1000000 or aNumber <= -1000000) and format("%.1fM", aNumber * 0.000001)
		or aMaxNumber > 100000 and format("%.0fk", aNumber * 0.001)
		or aMaxNumber > 10000 and format("%.1fk", aNumber * 0.001)
		or aNumber;

end



--
local function VUHDO_getTagText(anInfo)

	if not anInfo["connected"] then
		return VUHDO_I18N_DC;
	elseif anInfo["dead"] then
		return UnitIsGhost(anInfo["unit"]) and format("|cffff0000%s|r", VUHDO_I18N_GHOST) or VUHDO_I18N_RIP;
	elseif anInfo["afk"] then
		return "afk";
	end

	return "";

end



--
local tOwnerInfo;
local tNickname;
local tDisplayName;
local tMaxChars;
local tIndex;
local tNameText;
local tIdTextConfig;
local tIsShowNickname;
local tIsShowNameSuffix;
local tNameCount;
local function VUHDO_buildNameText(aUnit, anInfo, aSetup, aPanelNum, anIsTarget)

	tOwnerInfo = VUHDO_RAID[anInfo["ownerUnit"]];
	tIndex = (VUHDO_getUnitIdentityKey(anInfo) or anInfo["name"] or "") .. (anInfo["ownerUnit"] or "") .. aPanelNum;
	tIdTextConfig = aSetup["ID_TEXT"];

	tIsShowNickname = not sSecretsEnabled and VUHDO_LibNickTag and tIdTextConfig["showNickname"];

	if tIsShowNickname then
		tNickname = VUHDO_LibNickTag:GetNickname(anInfo["name"]) or anInfo["name"];
	else
		tNickname = anInfo["name"];
	end

	tDisplayName = tNickname;

	if tIdTextConfig["showName"] and tIdTextConfig["showNameSuffix"] and anInfo["nameSuffix"] and not anInfo["isPet"] and not tIsShowNickname
		and not (tOwnerInfo and tIdTextConfig["showPetOwners"]) then

		tIsShowNameSuffix = true;

		if tIdTextConfig["showNameSuffixOnlyDuplicates"] then
			if anInfo["hasSecretIdentity"] then
				tIsShowNameSuffix = false;
			else
				tNameCount = VUHDO_RAID_NAME_COUNTS[anInfo["name"]] or 0;

				tIsShowNameSuffix = tNameCount > 1;
			end
		end

		if tIsShowNameSuffix then
			tDisplayName = format("%s%s%s", tNickname, VUHDO_NAME_SUFFIX_SEPARATOR, anInfo["nameSuffix"]);
		end
	end

	if anInfo["hasSecretName"] or anInfo["hasSecretIdentity"] or not VUHDO_NAME_TEXTS[tIndex] or anInfo["name"] ~= tNickname then
		if tIdTextConfig["showName"] then
			tNameText = (tIdTextConfig["showClass"] and not anInfo["isPet"] and anInfo["className"]) and anInfo["className"] .. ": " or "";

			tNameText = tNameText .. ((not tOwnerInfo or not tIdTextConfig["showPetOwners"]) and tDisplayName or tOwnerInfo["name"] .. ": " .. tNickname);
		else
			tNameText = (tIdTextConfig["showClass"] and not anInfo["isPet"]) and anInfo["className"] or "";

			if tOwnerInfo and tIdTextConfig["showPetOwners"] then
				tNameText = tNameText .. tOwnerInfo["name"];
			end
		end

		tMaxChars = aSetup["PANEL_COLOR"]["TEXT"]["maxChars"];

		if tMaxChars > 0 then
			if anInfo["hasSecretName"] or anInfo["hasSecretIdentity"] then
				tNameText = format("%." .. tMaxChars .. "s", tNameText);
			elseif #tNameText > tMaxChars then
				tNameText = VUHDO_utf8Cut(tNameText, tMaxChars);
			end
		end

		if not anInfo["hasSecretName"] and not anInfo["hasSecretIdentity"] then
			VUHDO_NAME_TEXTS[tIndex] = tNameText;
		end
	else
		tNameText = VUHDO_NAME_TEXTS[tIndex];
	end

	if aSetup["ID_TEXT"]["showTags"] and not anIsTarget then
		if "focus" == aUnit then 
			tNameText = format("|cffff0000%s|r-%s", VUHDO_I18N_FOC, tNameText);
		elseif "target" == aUnit then 
			tNameText = format("|cffff0000%s|r-%s", VUHDO_I18N_TAR, tNameText);
		elseif tOwnerInfo and tOwnerInfo["isVehicle"] then 
			tNameText = format("|cffff0000%s|r-%s", VUHDO_I18N_VEHICLE, tNameText);
		end
	end

	return tNameText;

end



--
local function VUHDO_getKiloTextSecret(aNumber, anIsVerbose)

	return anIsVerbose and format("%d", aNumber) or AbbreviateNumbers(aNumber, VUHDO_KILO_OPTIONS);

end



--
local function VUHDO_getMissingHealthTextSecret(aMissingHealth, anIsVerbose, aSuffix)

	return anIsVerbose and WrapString(TruncateWhenZero(aMissingHealth), "-", aSuffix) or "-" .. AbbreviateNumbers(aMissingHealth, VUHDO_KILO_OPTIONS) .. (aSuffix or "");

end



--
local tHealth;
local tHealthMax;
local tMissingHealth;
local tLifeStr;
local tIsVerbose;
local function VUHDO_buildLifeTextSecret(aUnit, aLifeConfig, anIsTarget)

	tIsVerbose = aLifeConfig["verbose"];

	if 1 == aLifeConfig["mode"] or anIsTarget then
		return format("%d%%", UnitHealthPercent(aUnit, true, sScaleTo100CeilCurve)), true;
	end

	if sHealthTextCalculator then
		sHealthTextCalculator:ResetPredictedValues();
		UnitGetDetailedHealPrediction(aUnit, "player", sHealthTextCalculator);

		tHealth = sHealthTextCalculator:GetCurrentHealth();
		tHealthMax = sHealthTextCalculator:GetMaximumHealth();
		tMissingHealth = sHealthTextCalculator:GetMissingHealth();
	else
		tHealth = UnitHealth(aUnit);
		tHealthMax = UnitHealthMax(aUnit);
		tMissingHealth = UnitHealthMissing(aUnit);
	end

	if 3 == aLifeConfig["mode"] then
		tLifeStr = VUHDO_getMissingHealthTextSecret(tMissingHealth, tIsVerbose, aLifeConfig["showTotalHp"] and " / " or nil);

		if aLifeConfig["showTotalHp"] then
			tLifeStr = tLifeStr .. VUHDO_getKiloTextSecret(tHealthMax, tIsVerbose);
		end

		return tLifeStr, true;
	else
		tLifeStr = VUHDO_getKiloTextSecret(tHealth, tIsVerbose);

		if aLifeConfig["showTotalHp"] then
			tLifeStr = tLifeStr .. " / " .. VUHDO_getKiloTextSecret(tHealthMax, tIsVerbose);
		end

		return tLifeStr, true;
	end

end



--
local tMissLife;
local tLifeAmount;
local tShieldLeft;
local tClassicLifeStr;
local function VUHDO_buildLifeTextClassic(aUnit, anInfo, aSetup, aLifeConfig, anIsTarget)

	tLifeAmount = anInfo["health"];

	if aLifeConfig["showEffectiveHp"] then
		tShieldLeft = VUHDO_getUnitOverallShieldRemain(anInfo["unit"]);
		tLifeAmount = tLifeAmount + tShieldLeft;
	else
		tShieldLeft = 0;
	end

	if sIsOverhealText then
		tLifeAmount = tLifeAmount + VUHDO_getIncHealOnUnit(aUnit);
	end

	if 1 == aLifeConfig["mode"] or anIsTarget then
		return format("%d%%", VUHDO_getUnitHealthModiPercent(anInfo, tLifeAmount - anInfo["health"]) * 100), true;
	elseif 3 == aLifeConfig["mode"] then
		tMissLife = tLifeAmount - anInfo["healthmax"];

		if tMissLife < -10 then
			if aLifeConfig["showTotalHp"] then
				tClassicLifeStr = format("%s / %s",
					VUHDO_getKiloText(tMissLife, anInfo["healthmax"], aSetup),
					VUHDO_getKiloText(anInfo["healthmax"], anInfo["healthmax"], aSetup)
				);
			else
				tClassicLifeStr = VUHDO_getKiloText(tMissLife, anInfo["healthmax"], aSetup);
			end

			return tClassicLifeStr, true;
		else
			if aLifeConfig["showTotalHp"] then
				if aLifeConfig["showEffectiveHp"] then
					tClassicLifeStr = VUHDO_getKiloText(anInfo["healthmax"] + tShieldLeft, anInfo["healthmax"] + tShieldLeft, aSetup);
				else
					tClassicLifeStr = VUHDO_getKiloText(anInfo["healthmax"], anInfo["healthmax"], aSetup);
				end

				return tClassicLifeStr, true;
			else
				return "", false;
			end
		end
	else
		if aLifeConfig["showTotalHp"] then
			tClassicLifeStr = format("%s / %s",
				VUHDO_getKiloText(tLifeAmount, anInfo["healthmax"], aSetup),
				VUHDO_getKiloText(anInfo["healthmax"], anInfo["healthmax"], aSetup)
			);
		else
			tClassicLifeStr = format("%s", VUHDO_getKiloText(tLifeAmount, anInfo["healthmax"], aSetup));
		end

		return tClassicLifeStr, (tClassicLifeStr ~= "");
	end

end



--
local function VUHDO_setLifeTextAlpha(aFontString, anAlpha)

	aFontString["vuhdoLifeTextAlpha"] = anAlpha;

	aFontString:SetAlpha(anAlpha);

	return;

end



--
local tAlphaColor;
local tSoloAlphaColor;
local function VUHDO_applyLifeTextAlpha(aHealthBar, aUnit, aInfo, aLifeConfig)

	if not sSecretsEnabled then
		VUHDO_setLifeTextAlpha(VUHDO_getLifeText(aHealthBar), 1);
		VUHDO_setLifeTextAlpha(VUHDO_getBarText(aHealthBar), 1);
		VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(aHealthBar), 0);

		return;
	end

	tAlphaColor = nil;
	tSoloAlphaColor = nil;

	if aLifeConfig["hideIrrelevant"] and aInfo["hasSecretHealth"] and sHideIrrelevantCurve then
		tAlphaColor = UnitHealthPercent(aUnit, true, sHideIrrelevantCurve);
		tSoloAlphaColor = sShowWhenIrrelevantCurve and UnitHealthPercent(aUnit, true, sShowWhenIrrelevantCurve);
	elseif 3 == aLifeConfig["mode"] and not aLifeConfig["verbose"] and sHideMissingZeroCurve then
		tAlphaColor = UnitHealthPercent(aUnit, true, sHideMissingZeroCurve);
		tSoloAlphaColor = sShowWhenFullCurve and UnitHealthPercent(aUnit, true, sShowWhenFullCurve);
	end

	if tAlphaColor then
		if 1 == aLifeConfig["position"] or 2 == aLifeConfig["position"] then
			VUHDO_setLifeTextAlpha(VUHDO_getBarText(aHealthBar), tAlphaColor["a"] or 1);
			VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(aHealthBar), tSoloAlphaColor and tSoloAlphaColor["a"] or 1);
		else
			VUHDO_setLifeTextAlpha(VUHDO_getLifeText(aHealthBar), tAlphaColor["a"] or 1);
			VUHDO_setLifeTextAlpha(VUHDO_getBarText(aHealthBar), 1);
			VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(aHealthBar), 0);
		end
	else
		VUHDO_setLifeTextAlpha(VUHDO_getLifeText(aHealthBar), 1);
		VUHDO_setLifeTextAlpha(VUHDO_getBarText(aHealthBar), 1);
		VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(aHealthBar), 0);
	end

	return;

end



--
local tFontString;
function VUHDO_restoreLifeTextAlpha(aBar)

	tFontString = VUHDO_getLifeText(aBar);

	if tFontString and tFontString["vuhdoLifeTextAlpha"] ~= nil then
		tFontString:SetAlpha(tFontString["vuhdoLifeTextAlpha"]);
	end

	tFontString = VUHDO_getBarText(aBar);

	if tFontString and tFontString["vuhdoLifeTextAlpha"] ~= nil then
		tFontString:SetAlpha(tFontString["vuhdoLifeTextAlpha"]);
	end

	tFontString = VUHDO_getBarTextSolo(aBar);

	if tFontString and tFontString["vuhdoLifeTextAlpha"] ~= nil then
		tFontString:SetAlpha(tFontString["vuhdoLifeTextAlpha"]);
	end

	return;

end



--
local tIsName;
local tIsLife;
local tIsLifeInName;
local tTextString;
local tHealthBar;
local tSetup;
local tLifeConfig;
local tLifeString;
local tHasLifeText;
local tUnit, tInfo;
local tIsShowLife;
local tIsHideIrrel;
local tTagText;
local tIsLifeLeftOrRight;
local tPanelNum;
local tIsLifeTextAlpha;
local tIsLifeTextSeparate;
local tNameWithTag;
local tSoloPart;
local tDisplayLifeForSplit;
function VUHDO_customizeText(aButton, aMode, anIsTarget)

	tUnit, tInfo = VUHDO_getDisplayUnit(aButton);
	tHealthBar = VUHDO_getHealthBar(aButton, 1);

	if not tInfo or not tInfo["name"] then
		tTextString = (tUnit and "focus" == tUnit) and VUHDO_I18N_NO_FOCUS
			or (tUnit and "target" == tUnit) and VUHDO_I18N_NO_TARGET
			or (tUnit and VUHDO_isBossUnit(tUnit)) and VUHDO_I18N_NO_BOSS
			or VUHDO_I18N_NOT_AVAILABLE;

		VUHDO_getBarText(tHealthBar):SetText("");
		VUHDO_setLifeTextAlpha(VUHDO_getBarText(tHealthBar), 0);
		VUHDO_getBarTextSolo(tHealthBar):SetText(tTextString);
		VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(tHealthBar), 1);
		VUHDO_getLifeText(tHealthBar):SetText("");
		VUHDO_setLifeTextAlpha(VUHDO_getLifeText(tHealthBar), 0);

		return;
	end

	tPanelNum = VUHDO_BUTTON_CACHE[aButton];
	tSetup = VUHDO_PANEL_SETUP[tPanelNum];
	tLifeConfig = tSetup["LIFE_TEXT"];

	if sSecretsEnabled and tInfo["hasSecretHealth"] and tLifeConfig["hideIrrelevant"] then
		tIsHideIrrel = false;
	else
		-- FIXME: operation modes other than neutral with 100% trigger are bugged
		--tIsHideIrrel = tLifeConfig["hideIrrelevant"] and VUHDO_getUnitHealthPercent(tInfo) >= VUHDO_CONFIG["EMERGENCY_TRIGGER"];
		tIsHideIrrel = tLifeConfig["hideIrrelevant"] and VUHDO_getUnitHealthPercent(tInfo) >= 100;
	end

	tIsShowLife = tLifeConfig["show"] and not tIsHideIrrel;

	tIsLifeLeftOrRight =
		1 == tLifeConfig["position"]
		or 2 == tLifeConfig["position"];

	tIsLifeInName = tLifeConfig["show"] and tIsLifeLeftOrRight;

	tIsLifeTextAlpha = sSecretsEnabled and ((tInfo["hasSecretHealth"] and tLifeConfig["hideIrrelevant"]) or (3 == tLifeConfig["mode"] and not tLifeConfig["verbose"]));
	tIsLifeTextSeparate = not tIsLifeLeftOrRight or tIsLifeTextAlpha;

	tIsName = aMode ~= 2 or tIsLifeInName;
	tIsLife = aMode ~= 7 or tIsLifeInName;

	tTextString = "";

	if tIsName then
		tTextString = VUHDO_buildNameText(tUnit, tInfo, tSetup, tPanelNum, anIsTarget);
	end

	tTagText = (tSetup["ID_TEXT"]["showTags"] and not anIsTarget)
		and VUHDO_getTagText(tInfo) or "";

	if tIsLife and tIsShowLife then
		if tTagText ~= "" or tIsHideIrrel then
			tLifeString = "";
			tHasLifeText = false;
		else
			if sSecretsEnabled then
				tLifeString, tHasLifeText = VUHDO_buildLifeTextSecret(tUnit, tLifeConfig, anIsTarget);
			else
				tLifeString, tHasLifeText = VUHDO_buildLifeTextClassic(tUnit, tInfo, tSetup, tLifeConfig, anIsTarget);
			end
		end

		tLifeString = VUHDO_getColoredString(tLifeString, sLifeColor);

		if tIsLifeTextSeparate then
			if not tIsLifeLeftOrRight then
				VUHDO_getLifeText(tHealthBar):SetText(tTagText ~= "" and tTagText or tLifeString);
				VUHDO_applyLifeTextAlpha(tHealthBar, tUnit, tInfo, tLifeConfig);
			end
		else
			if tTagText ~= "" then tTagText = tTagText .. "-"; end

			if 2 == tLifeConfig["position"] then
				tTextString = tHasLifeText
					and format("%s%s %s", tTagText, tLifeString, tTextString)
					or format("%s%s", tTagText, tTextString);
			else
				tTextString = format("%s%s %s", tTagText, tTextString, tLifeString);
			end

			VUHDO_getLifeText(tHealthBar):SetText("");
			VUHDO_setLifeTextAlpha(VUHDO_getLifeText(tHealthBar), 1);
		end
	elseif tIsLife then
		if tIsLifeLeftOrRight then
			if not tIsLifeTextSeparate and tTagText ~= "" then
				tTextString = tTagText .. "-" .. tTextString;
			end

			VUHDO_getLifeText(tHealthBar):SetText("");
		else
			VUHDO_getLifeText(tHealthBar):SetText(tTagText);
		end
	end

	if tIsName then
		if tIsLifeTextSeparate and tIsLifeLeftOrRight then
			tNameWithTag = (tTagText ~= "" and tTagText .. "-" .. tTextString or tTextString);
			tDisplayLifeForSplit = (tIsLife and tIsShowLife) and (tLifeString or "") or "";

			tTextString = tNameWithTag .. " " .. tDisplayLifeForSplit;

			if tInfo["aggro"] and sIsAggroText then
				tTextString = format("|cffff2020%s|r%s|cffff2020%s|r",
					VUHDO_THREAT_CFG["AGGRO_TEXT_LEFT"], tTextString, VUHDO_THREAT_CFG["AGGRO_TEXT_RIGHT"]);
				tSoloPart = format("|cffff2020%s|r%s|cffff2020%s|r", VUHDO_THREAT_CFG["AGGRO_TEXT_LEFT"], tNameWithTag, VUHDO_THREAT_CFG["AGGRO_TEXT_RIGHT"]);
			else
				tSoloPart = tNameWithTag;
			end

			VUHDO_getBarText(tHealthBar):SetText(tTextString);
			VUHDO_getBarTextSolo(tHealthBar):SetText(tSoloPart);

			VUHDO_applyLifeTextAlpha(tHealthBar, tUnit, tInfo, tLifeConfig);
		else
			if tInfo["aggro"] and sIsAggroText then
				tTextString = format("|cffff2020%s|r%s|cffff2020%s|r",
					VUHDO_THREAT_CFG["AGGRO_TEXT_LEFT"], tTextString, VUHDO_THREAT_CFG["AGGRO_TEXT_RIGHT"]);
			end

			VUHDO_getBarText(tHealthBar):SetText(tTextString);
			VUHDO_setLifeTextAlpha(VUHDO_getBarText(tHealthBar), 1);

			VUHDO_getBarTextSolo(tHealthBar):SetText(tTextString);
			VUHDO_setLifeTextAlpha(VUHDO_getBarTextSolo(tHealthBar), 0);
		end
	end

	return;

end



--
local tScaling;
function VUHDO_customizeDamageFlash(aButton, anInfo)

	if sSecretsEnabled then
		return;
	end

	tScaling = VUHDO_PANEL_SETUP[VUHDO_BUTTON_CACHE[aButton]]["SCALING"];

	if tScaling["isDamFlash"] and tScaling["damFlashFactor"] >= (anInfo["lifeLossPerc"] or -1) then
		VUHDO_UIFrameFlash(_G[aButton:GetName() .. "BgBarFlBar"], 0.05, 0.15, 0.25, false, 0.05, 0);
	end

	return;

end



--
local tRangeInfo;
local tAlpha;
local tIcon;
local tOutrangedAlpha;
local tIconAlpha;
function VUHDO_customizeDebuffIconsRange(aButton)

	if sIsNoRangeFade then
		return;
	end

	_, tRangeInfo = VUHDO_getDisplayUnit(aButton);

	if tRangeInfo then
		tOutrangedAlpha = VUHDO_BAR_COLOR["OUTRANGED"]["O"];

		for tCnt = 40, 44 do
			tIcon = VUHDO_getBarIconFrame(aButton, tCnt);

			if tIcon then
				tIconAlpha = tIcon:GetAlpha();

				if issecretvalue(tIconAlpha) or tIconAlpha > 0 then
					if tRangeInfo["hasSecretRange"] then
						tIcon:SetAlphaFromBoolean(tRangeInfo["range"], 1, tOutrangedAlpha);
					else
						tAlpha = tRangeInfo["range"] and 1 or tOutrangedAlpha;
						tIcon:SetAlpha(tAlpha);
					end
				end
			end
		end
	end

	return;

end
