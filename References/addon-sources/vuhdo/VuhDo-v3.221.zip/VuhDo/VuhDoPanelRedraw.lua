local _;

local ipairs = ipairs;
local pairs = pairs;
local strfind = strfind;
local twipe = table.wipe;
local tinsert = table.insert;
local floor = math.floor;
local ceil = math.ceil;
local min = math.min;
local max = math.max;
local xpcall = xpcall;

local InCombatLockdown = InCombatLockdown;
local issecretvalue = issecretvalue;
local RemovePrivateAuraAnchor = C_UnitAuras and C_UnitAuras.RemovePrivateAuraAnchor;

local VUHDO_getFont;
local VUHDO_getHealthBar;
local VUHDO_updateAuraAnchorHost;
local VUHDO_layoutHealthBarGeometry;
local VUHDO_hasManaOffsetBar;
local VUHDO_getPixelPerfectBorderEdgeSize;
local VUHDO_getPixelPerfectBorderInsets;
local VUHDO_getDynamicModelArray;
local VUHDO_getGroupMembersSorted;
local VUHDO_getGroupMembers;
local VUHDO_redrawPanel;
local VUHDO_redrawAllPanels;
local VUHDO_refreshAllUnitAuras;
local VUHDO_redisplayAllUnitAuras;
local VUHDO_updateAllPanelBars;
local VUHDO_calculateDerivedOrientation;
local VUHDO_updateToggledUnitEvents;
local VUHDO_buildAllIndicatorAlphaChains;
local VUHDO_buildBooleanOverlaysForButton;
local VUHDO_buildTargetIndicatorAlphaChains;
local VUHDO_resetButtonVisuals;

local VUHDO_STD_BACKDROP = nil;
local VUHDO_DESIGN_BACKDROP = nil;
local VUHDO_CONFIG;
local VUHDO_INDICATOR_CONFIG;

local VUHDO_STATUSBAR_LEFT_TO_RIGHT;
local VUHDO_STATUSBAR_RIGHT_TO_LEFT;
local VUHDO_STATUSBAR_BOTTOM_TO_TOP;
local VUHDO_STATUSBAR_TOP_TO_BOTTOM;

local VUHDO_PRIVATE_AURA_ANCHOR_FACTORS = VUHDO_PRIVATE_AURA_ANCHOR_FACTORS;

local sPanelConfig = { };
local sButtonInitSemaphores = { };
local sButtonPositionSemaphores = { };
local sRedrawAllPanelsSemaphore;
local sRedrawPanelSemaphores = { };
local sPanelCompletionTracker;
local sWaitingAllPanelsRedraws = { };
local sWaitingIndividualRedraws = { };
local sQueuedAllPanelsRequests = { };
local sQueuedIndividualRequests = { };
local sIsManaBouquet = { };
local sPanelInitRevision = { };

local sSecretsEnabled = VUHDO_SECRETS_ENABLED;

local VUHDO_SEMAPHORE_CONFIG = {
	["BUTTON_INIT_TIME_US"] = 1200,
	["BUTTON_POSITION_TIME_MS"] = 7,
	["BUTTON_INIT_SAFETY_FACTOR"] = 2.0,
	["BUTTON_POSITION_SAFETY_FACTOR"] = 1.5,
	["PANEL_REDRAW_SAFETY_FACTOR"] = 4.0,

	["MIN_TIMEOUT_MS"] = 250,

	["PARTY_THRESHOLD"] = 5,
	["SMALL_RAID_THRESHOLD"] = 15,
	["MEDIUM_RAID_THRESHOLD"] = 25,

	["SOLO_INIT_SAFETY"] = 1.0,
	["SOLO_POSITION_SAFETY"] = 1.0,
	["SOLO_PANEL_SAFETY"] = 1.05,
	["PARTY_INIT_SAFETY"] = 1.05, -- -- party (2-5)
	["PARTY_POSITION_SAFETY"] = 1.02,
	["PARTY_PANEL_SAFETY"] = 1.1,
	["SMALL_RAID_INIT_SAFETY"] = 1.1, -- small raid (6-15)
	["SMALL_RAID_POSITION_SAFETY"] = 1.03,
	["SMALL_RAID_PANEL_SAFETY"] = 1.15,
	["MEDIUM_RAID_INIT_SAFETY"] = 1.15, -- medium raid (16-25)
	["MEDIUM_RAID_POSITION_SAFETY"] = 1.05,
	["MEDIUM_RAID_PANEL_SAFETY"] = 1.25,
	["LARGE_RAID_PANEL_MULTIPLIER"] = 1.3, -- large raid (26+) multiplier
};
local sButtonInitTimeouts = { };
local sButtonPositionTimeouts = { };
local sPanelRedrawTimeout = 0;



--
local tReleaseSemaphoreName;
local function VUHDO_releaseStoredSemaphore(aSemaphore)

	if not aSemaphore then
		return;
	end

	tReleaseSemaphoreName = aSemaphore["name"];

	if tReleaseSemaphoreName then
		VUHDO_releaseSemaphore(tReleaseSemaphoreName);
	end

	return;

end



local sGrowthOffsets = {
	["LEFT"] = { -1, 0 },
	["RIGHT"] = { 1, 0 },
	["UP"] = { 0, 1 },
	["DOWN"] = { 0, -1 },
};



--
function VUHDO_panelRedrawInitLocalOverrides()

	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_INDICATOR_CONFIG = _G["VUHDO_INDICATOR_CONFIG"];

	VUHDO_STATUSBAR_LEFT_TO_RIGHT = _G["VUHDO_STATUSBAR_LEFT_TO_RIGHT"];
	VUHDO_STATUSBAR_RIGHT_TO_LEFT = _G["VUHDO_STATUSBAR_RIGHT_TO_LEFT"];
	VUHDO_STATUSBAR_BOTTOM_TO_TOP = _G["VUHDO_STATUSBAR_BOTTOM_TO_TOP"];
	VUHDO_STATUSBAR_TOP_TO_BOTTOM = _G["VUHDO_STATUSBAR_TOP_TO_BOTTOM"];

	VUHDO_getFont = _G["VUHDO_getFont"];
	VUHDO_getHealthBar = _G["VUHDO_getHealthBar"];
	VUHDO_updateAuraAnchorHost = _G["VUHDO_updateAuraAnchorHost"];
	VUHDO_layoutHealthBarGeometry = _G["VUHDO_layoutHealthBarGeometry"];
	VUHDO_hasManaOffsetBar = _G["VUHDO_hasManaOffsetBar"];
	VUHDO_getPixelPerfectBorderEdgeSize = _G["VUHDO_getPixelPerfectBorderEdgeSize"];
	VUHDO_getPixelPerfectBorderInsets = _G["VUHDO_getPixelPerfectBorderInsets"];
	VUHDO_getDynamicModelArray = _G["VUHDO_getDynamicModelArray"];
	VUHDO_getGroupMembersSorted = _G["VUHDO_getGroupMembersSorted"];
	VUHDO_getGroupMembers = _G["VUHDO_getGroupMembers"];
	VUHDO_refreshAllUnitAuras = _G["VUHDO_refreshAllUnitAuras"];
	VUHDO_redisplayAllUnitAuras = _G["VUHDO_redisplayAllUnitAuras"];
	VUHDO_updateAllPanelBars = _G["VUHDO_updateAllPanelBars"];
	VUHDO_calculateDerivedOrientation = _G["VUHDO_calculateDerivedOrientation"];
	VUHDO_updateToggledUnitEvents = _G["VUHDO_updateToggledUnitEvents"];
	VUHDO_buildAllIndicatorAlphaChains = _G["VUHDO_buildAllIndicatorAlphaChains"];
	VUHDO_buildBooleanOverlaysForButton = _G["VUHDO_buildBooleanOverlaysForButton"];
	VUHDO_buildTargetIndicatorAlphaChains = _G["VUHDO_buildTargetIndicatorAlphaChains"];
	VUHDO_resetButtonVisuals = _G["VUHDO_resetButtonVisuals"];

	VUHDO_panelRedrawCustomDebuffsInitLocalOverrides();
	VUHDO_panelRedrawHeadersInitLocalOverrides();
	VUHDO_panelRedrawHotsInitLocalOverrides();

	if VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
		VUHDO_redrawPanel = _G["VUHDO_deferRedrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_deferRedrawAllPanels"];
	else
		VUHDO_redrawPanel = _G["VUHDO_redrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_redrawAllPanels"];
	end

	for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
		sIsManaBouquet[tPanelNum] = VUHDO_INDICATOR_CONFIG[tPanelNum]["BOUQUETS"]["MANA_BAR"] ~= "";
	end

	return;

end



--
function VUHDO_invalidatePanelButtonInits(aPanelNum)

	if aPanelNum then
		sPanelInitRevision[aPanelNum] = (sPanelInitRevision[aPanelNum] or 0) + 1;
	else
		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			sPanelInitRevision[tPanelNum] = (sPanelInitRevision[tPanelNum] or 0) + 1;
		end
	end

	return;

end



--
function VUHDO_getPanelButtonInitRev(aPanelNum)

	return sPanelInitRevision[aPanelNum] or 0;

end



do
	--
	function VUHDO_getSemaphoreConfig()

		return VUHDO_SEMAPHORE_CONFIG;

	end



	--
	function VUHDO_invalidateSemaphoreTimeouts()

		twipe(sButtonInitTimeouts);
		twipe(sButtonPositionTimeouts);
		sPanelRedrawTimeout = 0;

		VUHDO_calculateSemaphoreTimeouts();

		return;

	end



	--
	local tModelArray;
	local tMemberNum;
	function VUHDO_getNumButtonsPanel(aPanelNum)

		tModelArray = VUHDO_getDynamicModelArray(aPanelNum);
		tMemberNum = 0;

		for tModelIndex, tModelId in pairs(tModelArray)  do
			tMemberNum = tMemberNum + #VUHDO_getGroupMembers(tModelId, aPanelNum, tModelIndex);
		end

		return tMemberNum;

	end



	--
	local tConfig;
	local tNumButtons;
	local tTotalPositionButtons;
	local tGroupArray;
	local tInitSafetyFactor;
	local tPositionSafetyFactor;
	local tTotalExpectedTime;
	local tTotalButtons;
	local tPanelRedrawSafetyFactor;
	local tIsForceEmpty;
	local tVisibleButtons;
	local tIsSolo;
	local tVisibleUnits;
	function VUHDO_calculateSemaphoreTimeouts()

		tConfig = VUHDO_getSemaphoreConfig();

		tVisibleButtons = 0;
		tVisibleUnits = 0;
		tIsSolo = true;

		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			if VUHDO_isPanelPopulated(tPanelNum) then
				if not sPanelConfig[tPanelNum] then
					VUHDO_initLocalVars(tPanelNum);
				end

				tNumButtons = VUHDO_getNumButtonsPanel(tPanelNum);
				tTotalPositionButtons = 0;
				tModelArray = VUHDO_getDynamicModelArray(tPanelNum);

				for tModelIndex, tModelId in ipairs(tModelArray) do
					tGroupArray = VUHDO_getGroupMembersSorted(tModelId, sPanelConfig[tPanelNum]["sortCriterion"], tPanelNum, tModelIndex);
					tTotalPositionButtons = tTotalPositionButtons + #tGroupArray;
				end

				if tNumButtons <= 1 then
					tInitSafetyFactor = tConfig["SOLO_INIT_SAFETY"];
				elseif tNumButtons <= tConfig["PARTY_THRESHOLD"] then
					tInitSafetyFactor = tConfig["PARTY_INIT_SAFETY"];
				elseif tNumButtons <= tConfig["SMALL_RAID_THRESHOLD"] then
					tInitSafetyFactor = tConfig["SMALL_RAID_INIT_SAFETY"];
				elseif tNumButtons <= tConfig["MEDIUM_RAID_THRESHOLD"] then
					tInitSafetyFactor = tConfig["MEDIUM_RAID_INIT_SAFETY"];
				else
					tInitSafetyFactor = tConfig["BUTTON_INIT_SAFETY_FACTOR"];
				end

				if tTotalPositionButtons <= 1 then
					tPositionSafetyFactor = tConfig["SOLO_POSITION_SAFETY"];
				elseif tTotalPositionButtons <= tConfig["PARTY_THRESHOLD"] then
					tPositionSafetyFactor = tConfig["PARTY_POSITION_SAFETY"];
				elseif tTotalPositionButtons <= tConfig["SMALL_RAID_THRESHOLD"] then
					tPositionSafetyFactor = tConfig["SMALL_RAID_POSITION_SAFETY"];
				elseif tTotalPositionButtons <= tConfig["MEDIUM_RAID_THRESHOLD"] then
					tPositionSafetyFactor = tConfig["MEDIUM_RAID_POSITION_SAFETY"];
				else
					tPositionSafetyFactor = tConfig["BUTTON_POSITION_SAFETY_FACTOR"];
				end

				sButtonInitTimeouts[tPanelNum] = max(tConfig["MIN_TIMEOUT_MS"], ceil(tNumButtons * tConfig["BUTTON_INIT_TIME_US"] * tInitSafetyFactor / 1000));
				sButtonPositionTimeouts[tPanelNum] = max(tConfig["MIN_TIMEOUT_MS"], ceil(tTotalPositionButtons * tConfig["BUTTON_POSITION_TIME_MS"] * tPositionSafetyFactor));

				if VUHDO_isPanelVisible(tPanelNum) then
					tIsForceEmpty = VUHDO_CONFIG["HIDE_EMPTY_PANELS"] and not VUHDO_isConfigPanelShowing() and #VUHDO_PANEL_UNITS[tPanelNum] == 0;

					if not tIsForceEmpty then
						tVisibleButtons = tVisibleButtons + tNumButtons;
						tVisibleUnits = tVisibleUnits + #VUHDO_PANEL_UNITS[tPanelNum];
					end
				end

				if tNumButtons > 5 then
					tIsSolo = false;
				end
			else
				sButtonInitTimeouts[tPanelNum] = tConfig["MIN_TIMEOUT_MS"];
				sButtonPositionTimeouts[tPanelNum] = tConfig["MIN_TIMEOUT_MS"];
			end
		end

		tTotalExpectedTime = 0;
		tTotalButtons = 0;

		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			tTotalExpectedTime = tTotalExpectedTime + sButtonInitTimeouts[tPanelNum] + sButtonPositionTimeouts[tPanelNum];
		end

		tTotalButtons = tVisibleButtons;

		if tIsSolo and tVisibleButtons <= 5 and tVisibleUnits <= 3 then
			tPanelRedrawSafetyFactor = tConfig["SOLO_PANEL_SAFETY"];
		elseif tTotalButtons <= 1 then
			tPanelRedrawSafetyFactor = tConfig["SOLO_PANEL_SAFETY"];
		elseif tTotalButtons <= tConfig["PARTY_THRESHOLD"] then
			tPanelRedrawSafetyFactor = tConfig["PARTY_PANEL_SAFETY"];
		elseif tTotalButtons <= tConfig["SMALL_RAID_THRESHOLD"] then
			tPanelRedrawSafetyFactor = tConfig["SMALL_RAID_PANEL_SAFETY"];
		elseif tTotalButtons <= tConfig["MEDIUM_RAID_THRESHOLD"] then
			tPanelRedrawSafetyFactor = tConfig["MEDIUM_RAID_PANEL_SAFETY"];
		else
			tPanelRedrawSafetyFactor = tConfig["PANEL_REDRAW_SAFETY_FACTOR"] * tConfig["LARGE_RAID_PANEL_MULTIPLIER"];
		end

		sPanelRedrawTimeout = max(1, ceil(tTotalExpectedTime * tPanelRedrawSafetyFactor));

		return;

	end
end



--
local sHealthBar;
local tBar;



--
local tPanelSetup;
local tIconSize;
local tIconSizePercent;
local tBarHeight;
local tSpacing;
local tPrivateAura;
function VUHDO_initLocalVars(aPanelNum)

	if not VUHDO_PANEL_SETUP or not VUHDO_PANEL_SETUP[aPanelNum] then
		return;
	end

	--VUHDO_panelRedrwawHeadersInitLocalVars(aPanelNum);
	VUHDO_panelRedrwawHotsInitLocalVars(aPanelNum);
	VUHDO_panelRedrawCustomDebuffsInitLocalVars(aPanelNum);

	tPanelSetup = VUHDO_PANEL_SETUP[aPanelNum];

	sPanelConfig[aPanelNum] = {
		["panelSetup"] = tPanelSetup,
		["barScaling"] = tPanelSetup["SCALING"],
		["raidIcon"] = tPanelSetup["RAID_ICON"],
		["overhealText"] = tPanelSetup["OVERHEAL_TEXT"],
		["sortCriterion"] = tPanelSetup["MODEL"]["sort"],
		["mainFont"] = VUHDO_getFont(tPanelSetup["PANEL_COLOR"]["TEXT"]["font"]),
		["statusTexture"] = VUHDO_LibSharedMedia:Fetch('statusbar', tPanelSetup["PANEL_COLOR"]["barTexture"]),
		["textAnchors"] = VUHDO_splitString(tPanelSetup["ID_TEXT"]["position"], "+"),
		["lifeText"] = tPanelSetup["LIFE_TEXT"],
		["mainFontHeight"] = tPanelSetup["PANEL_COLOR"]["TEXT"]["textSize"],
		["lifeFontHeight"] = tPanelSetup["PANEL_COLOR"]["TEXT"]["textSizeLife"],
		["outlineText"] = tPanelSetup["PANEL_COLOR"]["TEXT"]["outline"] and "OUTLINE|" or "",
		["shadowAlpha"] = tPanelSetup["PANEL_COLOR"]["TEXT"]["USE_SHADOW"] and 1 or 0,
		["barHeight"] = VUHDO_getHealthBarHeight(aPanelNum),
		["barWidth"] = VUHDO_getHealthBarWidth(aPanelNum),
		["manaBarHeight"] = VUHDO_getManaBarHeight(aPanelNum),
		["sideBarLeftWidth"] = VUHDO_getSideBarWidthLeft(aPanelNum),
		["sideBarRightWidth"] = VUHDO_getSideBarWidthRight(aPanelNum),
		["indicatorConfig"] = VUHDO_INDICATOR_CONFIG[aPanelNum],
		["privateAura"] = tPanelSetup["PRIVATE_AURA"],
	};

	if (tPanelSetup["PANEL_COLOR"]["TEXT"]["USE_MONO"]) then
		sPanelConfig[aPanelNum]["outlineText"] = sPanelConfig[aPanelNum]["outlineText"] .. "OUTLINEMONOCHROME";
	end

	if (sPanelConfig[aPanelNum]["manaBarHeight"] == 0) then
		sPanelConfig[aPanelNum]["manaBarHeight"] = 0.001;
	end

	sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"] = sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["SWIFTMEND_INDICATOR"];

	if sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["anchor"] == nil then
		sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["anchor"] = "TOPLEFT";
	end

	if sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["xAdjust"] == nil or sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["yAdjust"] == nil then
		sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["xAdjust"] = 5.5;
		sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["yAdjust"] = -14;
	end

	tPrivateAura = sPanelConfig[aPanelNum]["privateAura"];

	if tPrivateAura and tPrivateAura["numAuras"] == nil then
		tPrivateAura["numAuras"] = 3;
		tPrivateAura["orientation"] = "HORIZONTAL";
		tPrivateAura["spacing"] = 0;
		tPrivateAura["showCooldown"] = true;
		tPrivateAura["showCooldownNumbers"] = true;
		tPrivateAura["showDuration"] = false;
		tPrivateAura["durationPosition"] = "BOTTOM";
		tPrivateAura["durationOffsetX"] = 0;
		tPrivateAura["durationOffsetY"] = 0;
		tPrivateAura["showBorder"] = false;
		tPrivateAura["iconSize"] = 40;
		tPrivateAura["frameLevel"] = 13;
		tPrivateAura["growthDir"] = "RIGHT";
		tPrivateAura["wrapDir"] = "DOWN";
		tPrivateAura["maxColumns"] = 3;
		tPrivateAura["maxRows"] = 2;
		tPrivateAura["showTooltip"] = false;
	end

	tIconSizePercent = sPanelConfig[aPanelNum]["privateAura"]["iconSize"] or 40;
	tBarHeight = sPanelConfig[aPanelNum]["barScaling"]["barHeight"];

	if tIconSizePercent > 100 then
		tIconSize = min(tBarHeight, tIconSizePercent);
	else
		tIconSize = tBarHeight * (tIconSizePercent == 0 and 100 or tIconSizePercent) * 0.01;
	end

	sPanelConfig[aPanelNum]["privateAuraHeight"] = tIconSize;

	tSpacing = sPanelConfig[aPanelNum]["privateAura"]["spacing"] or 0;
	sPanelConfig[aPanelNum]["privateAuraStep"] = sPanelConfig[aPanelNum]["privateAuraHeight"] + tSpacing;

	sPanelConfig[aPanelNum]["privateAuraXOffset"] = sPanelConfig[aPanelNum]["privateAura"]["xAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barWidth"] * 0.01;
	sPanelConfig[aPanelNum]["privateAuraYOffset"] = -sPanelConfig[aPanelNum]["privateAura"]["yAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * 0.01;

	return;

end



--
function VUHDO_isPanelVisible(aPanelNum)

	if not VUHDO_CONFIG["SHOW_PANELS"] or not VUHDO_PANEL_MODELS[aPanelNum] or not VUHDO_IS_SHOWN_BY_GROUP then
		return false;
	end

	if VUHDO_isModelInPanel(aPanelNum, 42) -- VUHDO_ID_PRIVATE_TANKS
		and (not VUHDO_CONFIG["OMIT_TARGET"] or not VUHDO_CONFIG["OMIT_FOCUS"]) then
		return true;
	end

	if VUHDO_isModelInPanel(aPanelNum, 82) then -- VUHDO_ID_TARGET
		return true;
	end

	if VUHDO_isModelInPanel(aPanelNum, 83) then -- VUHDO_ID_FOCUS
		return true;
	end

	if VUHDO_isModelInPanel(aPanelNum, 44) then -- VUHDO_ID_BOSSES
		return true;
	end

	if VUHDO_CONFIG["HIDE_EMPTY_PANELS"] and not VUHDO_isConfigPanelShowing() and #VUHDO_PANEL_UNITS[aPanelNum] == 0 then
		return false;
	end

	return true;

end



--
function VUHDO_isPanelPopulated(aPanelNum)

	return VUHDO_CONFIG["SHOW_PANELS"] and VUHDO_PANEL_MODELS[aPanelNum] and VUHDO_IS_SHOWN_BY_GROUP;

end



do
	--
	local tBackdrop;
	local tWidth;
	local tGap;
	local function VUHDO_initPlayerTargetBorder(aButton, aBorderFrame, anIsNoIndicator, aPanelNum)

		if not aBorderFrame then
			return;
		end

		if VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"]["BAR_BORDER"] == "" then
			VUHDO_PixelUtil.Hide(aBorderFrame);
			VUHDO_PixelUtil.ClearAllPoints(aBorderFrame);

			return;
		end

		tWidth = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["BAR_BORDER"]["WIDTH"];
		tGap = tWidth + VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["BAR_BORDER"]["ADJUST"];
		VUHDO_PixelUtil.SetPoint(aBorderFrame, "TOPLEFT", aButton:GetName(), "TOPLEFT", -tGap, tGap);
		VUHDO_PixelUtil.SetPoint(aBorderFrame, "BOTTOMRIGHT", aButton:GetName(), "BOTTOMRIGHT", tGap, -tGap);

		tBackdrop = aBorderFrame:GetBackdrop() or {};
		tBackdrop["edgeSize"] = tWidth;
		tBackdrop["edgeFile"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["BAR_BORDER"]["FILE"];
		tBackdrop["insets"] = tBackdrop["insets"] or {};
		tBackdrop["insets"]["left"] = tWidth;
		tBackdrop["insets"]["right"] = tWidth;
		tBackdrop["insets"]["top"] = tWidth;
		tBackdrop["insets"]["bottom"] = tWidth;

		aBorderFrame.backdropInfo = tBackdrop;
		VUHDO_PixelUtil.ApplyBackdrop(aBorderFrame, tBackdrop);

		aBorderFrame.backdropBorderColor = VUHDO_getOrCreateCachedColor(0, 0, 0);
		aBorderFrame.backdropBorderColorAlpha = 1;
		aBorderFrame:SetBackdropBorderColor(0, 0, 0, 1);

		aBorderFrame:SetShown(anIsNoIndicator);

		return;

	end



	--
	local tBackdropCluster;
	local tClusterFrame;
	local function VUHDO_initClusterBorder(aButton, aPanelNum)

		tClusterFrame = VUHDO_getClusterBorderFrame(aButton);

		if not tClusterFrame then
			return;
		end

		VUHDO_PixelUtil.Hide(tClusterFrame);

		if VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"]["CLUSTER_BORDER"] == "" then
			tClusterFrame:ClearAllPoints();

			return;
		end

		tClusterFrame:ClearAllPoints();

		VUHDO_PixelUtil.SetPoint(tClusterFrame, "TOPLEFT", aButton:GetName(), "TOPLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tClusterFrame, "BOTTOMRIGHT", aButton:GetName(), "BOTTOMRIGHT", 0, 0);

		tBackdropCluster = tClusterFrame:GetBackdrop() or {};

		tBackdropCluster["edgeSize"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["CLUSTER_BORDER"]["WIDTH"];
		tBackdropCluster["edgeFile"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["CLUSTER_BORDER"]["FILE"];
		tBackdropCluster["insets"] = tBackdropCluster["insets"] or {};
		tBackdropCluster["insets"]["left"] = 0;
		tBackdropCluster["insets"]["right"] = 0;
		tBackdropCluster["insets"]["top"] = 0;
		tBackdropCluster["insets"]["bottom"] = 0;

		tClusterFrame.backdropInfo = tBackdropCluster;
		VUHDO_PixelUtil.ApplyBackdrop(tClusterFrame, tBackdropCluster);

		tClusterFrame.backdropBorderColor = VUHDO_getOrCreateCachedColor(0, 0, 0);
		tClusterFrame.backdropBorderColorAlpha = 0;
		tClusterFrame:SetBackdropBorderColor(0, 0, 0, 0);

		return;

	end



	--
	function VUHDO_positionHealButton(aButton, aPanelNum, aBarScaling)

		VUHDO_PixelUtil.SetWidth(aButton, (aBarScaling or sPanelConfig[aPanelNum]["barScaling"])["barWidth"]);
		VUHDO_PixelUtil.SetHeight(aButton, (aBarScaling or sPanelConfig[aPanelNum]["barScaling"])["barHeight"]);

		VUHDO_initPlayerTargetBorder(aButton, VUHDO_getPlayerTargetFrame(aButton), false, aPanelNum);
		VUHDO_initPlayerTargetBorder(VUHDO_getTargetButton(aButton), VUHDO_getPlayerTargetFrameTarget(aButton), true, aPanelNum);
		VUHDO_initPlayerTargetBorder(VUHDO_getTotButton(aButton), VUHDO_getPlayerTargetFrameToT(aButton), true, aPanelNum);

		VUHDO_initClusterBorder(aButton, aPanelNum);

		return;

	end
end



do
	--
	function VUHDO_initHealthBar(aButton, aPanelNum)

		return;

	end



	--
	local tFrame;
	local function VUHDO_registerFacadeIcon(aButton, aNum, aGroup)
		tFrame = VUHDO_getBarIconFrame(aButton, aNum);
		if tFrame then
			VUHDO_getBarIcon(aButton, aNum):SetTexCoord(0, 1, 0, 1);
			VUHDO_LibButtonFacade:Group("VuhDo", aGroup):AddButton(tFrame, {
				["Icon"] = VUHDO_getBarIcon(aButton, aNum),
			});
		end
	end



	--
	local tLeft;
	local tRight;
	local tTop;
	local tBottom;
	local tIcon;
	function VUHDO_initButtonButtonFacade(aButton)

		for tCnt = 1, 5 do
			VUHDO_registerFacadeIcon(aButton, tCnt, VUHDO_I18N_HOTS);
		end

		for tCnt = 9, 12 do -- VUHDO_MAX_HOTS
			VUHDO_registerFacadeIcon(aButton, tCnt, VUHDO_I18N_HOTS);
		end

		tIcon = VUHDO_getBarIcon(aButton, 1);

		if tIcon then
			tLeft, tTop, _, _, _, _, tRight, tBottom = tIcon:GetTexCoord();

			VUHDO_hotsSetClippings(tLeft, tRight, tTop, tBottom);
		end

		return;

	end



	--
	local tXPos;
	local tYPos;
	local tHealButton;
	local tGroupArray;
	local tColumnIndex;
	local tButtonIndex;
	local tModelArray;
	local tPanelName;
	function VUHDO_positionAllHealButtons(aPanel, aPanelNum)

		tModelArray = VUHDO_getDynamicModelArray(aPanelNum);
		tPanelName  = aPanel:GetName();

		tColumnIndex = 1;
		tButtonIndex = 1;

		for tModelIndex,  tModelId  in ipairs(tModelArray)  do
			tGroupArray = VUHDO_getGroupMembersSorted(tModelId, sPanelConfig[aPanelNum]["sortCriterion"], aPanelNum, tModelIndex);

			for tGroupIndex, tUnit  in ipairs(tGroupArray)  do
				tHealButton = VUHDO_getHealButton(tButtonIndex, aPanelNum);

				tButtonIndex = tButtonIndex  + 1;
				VUHDO_positionHealButton(tHealButton, aPanelNum);

				VUHDO_setupAllHealButtonAttributes(tHealButton, tUnit, false, 70 == tModelId, false, false); -- VUHDO_ID_VEHICLES

				if VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showTarget"] then
					VUHDO_setupAllTargetButtonAttributes(VUHDO_getTargetButton(tHealButton), tUnit);
				end

				if VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showTot"] then
					VUHDO_setupAllTotButtonAttributes(VUHDO_getTotButton(tHealButton), tUnit);
				end

				tXPos, tYPos = VUHDO_getHealButtonPos(tColumnIndex, tGroupIndex, aPanelNum);

				if VUHDO_isDifferentButtonPoint(tHealButton, tXPos, -tYPos) then
					VUHDO_PixelUtil.Hide(tHealButton);
					VUHDO_PixelUtil.ClearAllPoints(tHealButton);
					VUHDO_PixelUtil.SetPoint(tHealButton, "TOPLEFT", tPanelName, "TOPLEFT", tXPos, -tYPos);
				end

				VUHDO_addUnitButton(tHealButton, aPanelNum);

				if not tHealButton:IsShown() then
					VUHDO_PixelUtil.Show(tHealButton);
				end
			end

			tColumnIndex = tColumnIndex + 1;
		end

		return;

	end
end



--
function VUHDO_deferRedrawAllPanelsComplete(anIsFixAllFrameLevels)

	VUHDO_deferTask(VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_NORMAL, anIsFixAllFrameLevels);

	return;

end



do
	--
	local tAggroTexture;
	local tAggroHostFrame;
	function VUHDO_initAggroTexture(aButton, aHealthBar)

		tAggroTexture = VUHDO_getAggroTexture(aHealthBar);
		tAggroHostFrame = VUHDO_getOverlayHostFrame(tAggroTexture);

		VUHDO_PixelUtil.ClearAllPoints(tAggroHostFrame);

		VUHDO_PixelUtil.SetPoint(tAggroHostFrame, "TOPLEFT", aButton, "TOPLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tAggroHostFrame, "TOPRIGHT", aButton, "TOPRIGHT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tAggroHostFrame, "BOTTOMLEFT", aButton, "BOTTOMLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tAggroHostFrame, "BOTTOMRIGHT", aButton, "BOTTOMRIGHT", 0, 0);

		VUHDO_PixelUtil.Show(tAggroHostFrame);
		VUHDO_PixelUtil.Hide(tAggroTexture);

		return;

	end



	--
	local tUnit;
	local tInfo;
	local tManaHeight;
	local tIsManaBouquet;
	local tIsManaLayoutActive;
	local tManaLayoutHeight;
	function VUHDO_initManaBar(aButton, aManaBar, aWidth, anIsForceBar, aPanelNum)

		tIsManaBouquet = sIsManaBouquet[aPanelNum];

		VUHDO_PixelUtil.SetPoint(aManaBar, "BOTTOMLEFT", aButton:GetName(), "BOTTOMLEFT", 0, 0);
		VUHDO_setLlcStatusBarTexture(aManaBar, VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["MANA_BAR"]["TEXTURE"]);

		tUnit = aButton["raidid"];
		tInfo = VUHDO_RAID[tUnit];

		tManaHeight = (anIsForceBar or not tInfo or tIsManaBouquet) and sPanelConfig[aPanelNum]["manaBarHeight"] or 0;

		VUHDO_PixelUtil.SetWidth(aManaBar, aWidth);

		aButton["regularHeight"] = sPanelConfig[aPanelNum]["barScaling"]["barHeight"];

		tIsManaLayoutActive = aButton["manaBarLayoutHeight"] == nil or aButton["manaBarLayoutHeight"] > 0;
		tManaLayoutHeight = (tIsManaBouquet and tIsManaLayoutActive) and sPanelConfig[aPanelNum]["barScaling"]["manaBarHeight"] or 0;

		aButton["manaBarLayoutHeight"] = tManaLayoutHeight;

		if VUHDO_hasManaOffsetBar(aButton) then
			if tIsManaBouquet then
				if not tInfo then
					aManaBar:SetMinMaxValues(0, 1, Enum.StatusBarInterpolation.Immediate);
					aManaBar:SetValue(aManaBar["isInverted"] and 1 or 0);
				end
			else
				aButton["manaBarLayoutHeight"] = 0;
			end
		else
			VUHDO_updateAuraAnchorHost(aButton);

			if tIsManaBouquet then
				if not tInfo or tIsManaLayoutActive then
					VUHDO_PixelUtil.Show(aManaBar);
					VUHDO_PixelUtil.SetHeight(aManaBar, tManaHeight);
				else
					VUHDO_PixelUtil.Hide(aManaBar);
				end

				if not tInfo then
					aManaBar:SetMinMaxValues(0, 1, Enum.StatusBarInterpolation.Immediate);
					aManaBar:SetValue(aManaBar["isInverted"] and 1 or 0);
				end

				if anIsForceBar then
					if VUHDO_getHealthBar(aButton, 1):GetHeight() == 0 then
						VUHDO_PixelUtil.SetHeight(VUHDO_getHealthBar(aButton, 1), sPanelConfig[aPanelNum]["barHeight"]);
					end
				end
			else
				VUHDO_PixelUtil.Hide(aManaBar);
				VUHDO_PixelUtil.SetHeight(VUHDO_getHealthBar(aButton, 1), sPanelConfig[aPanelNum]["barHeight"] + sPanelConfig[aPanelNum]["manaBarHeight"]);
			end
		end

		if not anIsForceBar then
			VUHDO_customizeIconText(aManaBar, 32, VUHDO_getHealthBarText(aButton, 2),
				VUHDO_INDICATOR_CONFIG[aPanelNum]["TEXT_INDICATORS"]["MANA_BAR"]["TEXT"]);
		end

		return;

	end



	--
	function VUHDO_initBackgroundBar(aBgBar, aPanelNum)

		VUHDO_setLlcStatusBarTexture(aBgBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["BACKGROUND_BAR"]["TEXTURE"]);

		VUHDO_PixelUtil.SetHeight(aBgBar, sPanelConfig[aPanelNum]["barScaling"]["barHeight"]);
		aBgBar:SetValue(1);
		aBgBar:SetStatusBarColor(0, 0, 0, 0);

		VUHDO_PixelUtil.Show(aBgBar);

		return;

	end
end



do
	--
	function VUHDO_initIncomingOrShieldBar(aButton, aBarNum, aPanelNum)

		VUHDO_invalidateShieldMaskAnchors(aButton);

		tBar = VUHDO_getHealthBar(aButton, aBarNum);

		if not tBar then
			return;
		end

		VUHDO_PixelUtil.SetSize(tBar, sPanelConfig[aPanelNum]["barWidth"], sPanelConfig[aPanelNum]["barHeight"]);
		tBar:SetMinMaxValues(0, 1);
		tBar:SetValue(0);

		return;

	end



	--
	local tThreatBar;
	function VUHDO_initThreatBar(aButton, aPanelNum)

		tThreatBar = VUHDO_getHealthBar(aButton, 7);

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["THREAT_BAR"] == "" then
			VUHDO_PixelUtil.Hide(tThreatBar);
		else
			VUHDO_PixelUtil.Show(tThreatBar);

			VUHDO_setLlcStatusBarTexture(tThreatBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["THREAT_BAR"]["TEXTURE"]);

			tThreatBar:SetStatusBarColor(0, 0, 0, 0);
			VUHDO_PixelUtil.SetHeight(tThreatBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["THREAT_BAR"]["HEIGHT"]);
		end

		VUHDO_customizeIconText(tThreatBar, 32, VUHDO_getHealthBarText(aButton, 7),
		sPanelConfig[aPanelNum]["indicatorConfig"]["TEXT_INDICATORS"]["THREAT_BAR"]["TEXT"]);

		return;

	end



	--
	local tTextPanel;
	local tNameText;
	local tLifeText;
	local tAddHeight;
	local tAnchorObject;
	local tIsLifeHorizontal;
	local tIsLifeHidden;
	local tNameTextSolo;
	function VUHDO_initBarTexts(aButton, aHealthBar, aWidth, aPanelNum)

		tTextPanel  = VUHDO_getTextPanel(aHealthBar);
		tNameText = VUHDO_getBarText(aHealthBar);
		tNameTextSolo = VUHDO_getBarTextSolo(aHealthBar);
		tLifeText = VUHDO_getLifeText(aHealthBar);

		VUHDO_PixelUtil.SetWidth(tNameText, aWidth);
		VUHDO_PixelUtil.SetHeight(tNameText, sPanelConfig[aPanelNum]["mainFontHeight"]);

		tNameText:SetFont(sPanelConfig[aPanelNum]["mainFont"], sPanelConfig[aPanelNum]["mainFontHeight"], sPanelConfig[aPanelNum]["outlineText"] or "");
		tNameText:SetShadowColor(0, 0, 0, sPanelConfig[aPanelNum]["shadowAlpha"]);

		tNameTextSolo:SetFont(sPanelConfig[aPanelNum]["mainFont"], sPanelConfig[aPanelNum]["mainFontHeight"], sPanelConfig[aPanelNum]["outlineText"] or "");
		tNameTextSolo:SetShadowColor(0, 0, 0, sPanelConfig[aPanelNum]["shadowAlpha"]);
		tNameTextSolo:SetText("");

		tLifeText:SetFont(sPanelConfig[aPanelNum]["mainFont"], sPanelConfig[aPanelNum]["lifeFontHeight"], sPanelConfig[aPanelNum]["outlineText"] or "");
		tLifeText:SetShadowColor(0, 0, 0, sPanelConfig[aPanelNum]["shadowAlpha"]);
		tLifeText:SetText("");

		VUHDO_PixelUtil.ClearAllPoints(tNameText);
		VUHDO_PixelUtil.ClearAllPoints(tNameTextSolo);

		tAddHeight = 0;

		tIsLifeHorizontal = VUHDO_LT_POS_RIGHT == sPanelConfig[aPanelNum]["lifeText"]["position"]
			or VUHDO_LT_POS_LEFT == sPanelConfig[aPanelNum]["lifeText"]["position"];

		tIsLifeHidden = not sPanelConfig[aPanelNum]["lifeText"]["show"]
			and not sPanelConfig[aPanelNum]["panelSetup"]["ID_TEXT"]["showTags"];

		if tIsLifeHidden then
			VUHDO_PixelUtil.SetWidth(tLifeText, 0);
			VUHDO_PixelUtil.SetHeight(tLifeText, 0);
			VUHDO_PixelUtil.Hide(tLifeText);

			VUHDO_PixelUtil.SetPoint(tNameText, "CENTER", tTextPanel:GetName(), "CENTER", 0, 0);
			VUHDO_PixelUtil.Show(tNameText);

			VUHDO_PixelUtil.SetWidth(tNameTextSolo, 0);
			VUHDO_PixelUtil.SetHeight(tNameTextSolo, 0);
			VUHDO_PixelUtil.Hide(tNameTextSolo);
		elseif tIsLifeHorizontal then
			VUHDO_PixelUtil.SetWidth(tLifeText, 0);
			VUHDO_PixelUtil.SetHeight(tLifeText, 0);
			VUHDO_PixelUtil.Hide(tLifeText);

			VUHDO_PixelUtil.SetWidth(tNameText, aWidth);
			VUHDO_PixelUtil.SetHeight(tNameText, sPanelConfig[aPanelNum]["mainFontHeight"]);
			VUHDO_PixelUtil.ClearAllPoints(tNameText);
			VUHDO_PixelUtil.SetPoint(tNameText, "CENTER", tTextPanel:GetName(), "CENTER", 0, 0);
			VUHDO_PixelUtil.Show(tNameText);
			tNameText:SetAlpha(1);

			tNameText["vuhdoLifeTextAlpha"] = nil;

			VUHDO_PixelUtil.SetWidth(tNameTextSolo, aWidth);
			VUHDO_PixelUtil.SetHeight(tNameTextSolo, sPanelConfig[aPanelNum]["mainFontHeight"]);
			VUHDO_PixelUtil.ClearAllPoints(tNameTextSolo);
			VUHDO_PixelUtil.SetPoint(tNameTextSolo, "CENTER", tTextPanel:GetName(), "CENTER", 0, 0);
			VUHDO_PixelUtil.Show(tNameTextSolo);
			tNameTextSolo:SetAlpha(0);

			tNameTextSolo["vuhdoLifeTextAlpha"] = nil;
		else
			VUHDO_PixelUtil.ClearAllPoints(tLifeText);
			VUHDO_PixelUtil.SetWidth(tLifeText, aWidth);
			VUHDO_PixelUtil.SetHeight(tLifeText, sPanelConfig[aPanelNum]["lifeFontHeight"]);

			tAddHeight = sPanelConfig[aPanelNum]["lifeFontHeight"];

			VUHDO_PixelUtil.Show(tNameText);
			VUHDO_PixelUtil.Show(tLifeText);

			if (VUHDO_LT_POS_BELOW == sPanelConfig[aPanelNum]["lifeText"]["position"]) then
				VUHDO_PixelUtil.SetPoint(tNameText, "TOP", tTextPanel:GetName(), "TOP", 0, 0);
				VUHDO_PixelUtil.SetPoint(tLifeText, "TOP", tNameText:GetName(), "BOTTOM", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tNameText, "BOTTOM", tTextPanel:GetName(), "BOTTOM", 0, 0);
				VUHDO_PixelUtil.SetPoint(tLifeText, "BOTTOM", tNameText:GetName(), "TOP", 0, 0);
			end

			VUHDO_PixelUtil.SetWidth(tNameTextSolo, 0);
			VUHDO_PixelUtil.SetHeight(tNameTextSolo, 0);
			VUHDO_PixelUtil.Hide(tNameTextSolo);

			VUHDO_PixelUtil.Show(tLifeText);
		end

		VUHDO_PixelUtil.SetHeight(tTextPanel, sPanelConfig[aPanelNum]["mainFontHeight"] + tAddHeight);
		VUHDO_PixelUtil.SetWidth(tTextPanel, aWidth);

		sPanelConfig[aPanelNum]["panelSetup"]["ID_TEXT"]["_spacing"] = tTextPanel:GetHeight(); -- internal marker

		if tIsLifeHorizontal then
			if strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "LEFT", 1, true) then
				tNameText:SetJustifyH("LEFT");
				tNameTextSolo:SetJustifyH("LEFT");
			elseif strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "RIGHT", 1, true) then
				tNameText:SetJustifyH("RIGHT");
				tNameTextSolo:SetJustifyH("RIGHT");
			else
				tNameText:SetJustifyH("CENTER");
				tNameTextSolo:SetJustifyH("CENTER");
			end
		elseif strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "LEFT", 1, true) then
			tNameText:SetJustifyH("LEFT");
			tLifeText:SetJustifyH("LEFT");
		elseif strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "RIGHT", 1, true) then
			tNameText:SetJustifyH("RIGHT");
			tLifeText:SetJustifyH("RIGHT");
		else
			tNameText:SetJustifyH("CENTER");
			tLifeText:SetJustifyH("CENTER");
		end

		if strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "BOTTOM", 1, true) and strfind(sPanelConfig[aPanelNum]["textAnchors"][2], "TOP", 1, true) -- �ber Button
			and sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["THREAT_BAR"] ~= "" then
			tAnchorObject = VUHDO_getHealthBar(aButton, 7) or aButton; -- Target und Tot hat keinen Threat bar
		elseif strfind(sPanelConfig[aPanelNum]["textAnchors"][2], "BOTTOM", 1, true) and strfind(sPanelConfig[aPanelNum]["textAnchors"][1], "TOP", 1, true) then
			tAnchorObject = aButton;
		else
			tAnchorObject = VUHDO_getHealthBar(aButton, 3) or aHealthBar;
		end

		VUHDO_PixelUtil.ClearAllPoints(tTextPanel);

		VUHDO_PixelUtil.SetPoint(tTextPanel, sPanelConfig[aPanelNum]["textAnchors"][1], tAnchorObject:GetName(), sPanelConfig[aPanelNum]["textAnchors"][2], sPanelConfig[aPanelNum]["panelSetup"]["ID_TEXT"]["xAdjust"], -sPanelConfig[aPanelNum]["panelSetup"]["ID_TEXT"]["yAdjust"]);

		return;

	end
end



do
	--
	local tOvhColor;
	local tOvhText;
	local tOvhPanel;
	local tX;
	local tY;
	function VUHDO_initOverhealText(aHealthBar, aWidth, aPanelNum)

		tOvhText = VUHDO_getOverhealText(aHealthBar);

		VUHDO_PixelUtil.SetWidth(tOvhText, 400);
		VUHDO_PixelUtil.SetHeight(tOvhText, sPanelConfig[aPanelNum]["mainFontHeight"]);

		if not sPanelConfig[aPanelNum] then
			return;
		end

		if not sPanelConfig[aPanelNum]["panelSetup"] then
			return;
		end

		tOvhColor = VUHDO_PANEL_SETUP["BAR_COLORS"]["OVERHEAL_TEXT"];

		tOvhText:SetTextColor(tOvhColor["TR"], tOvhColor["TG"], tOvhColor["TB"], tOvhColor["TO"]);
		tOvhText:SetFont(sPanelConfig[aPanelNum]["mainFont"], sPanelConfig[aPanelNum]["mainFontHeight"], "");
		tOvhText:SetJustifyH("CENTER");
		tOvhText:SetText("");

		tOvhPanel = VUHDO_getOverhealPanel(aHealthBar);

		VUHDO_PixelUtil.SetSize(tOvhPanel, 1, 1);
		VUHDO_PixelUtil.SetScale(tOvhPanel, 1);

		tX = sPanelConfig[aPanelNum]["overhealText"]["xAdjust"] * aWidth * 0.01;
		tY = -sPanelConfig[aPanelNum]["overhealText"]["yAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * 0.01;
		tOvhPanel:ClearAllPoints();
		VUHDO_PixelUtil.SetPoint(tOvhPanel, sPanelConfig[aPanelNum]["overhealText"]["point"], aHealthBar:GetName(), sPanelConfig[aPanelNum]["overhealText"]["point"], tX, tY);

		return;

	end



	--
	local tAggroBar;
	function VUHDO_initAggroBar(aButton, aHealthBar, aPanelNum)

		tAggroBar = VUHDO_getHealthBar(aButton, 4);

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["AGGRO_BAR"] == "" then
			VUHDO_PixelUtil.ClearAllPoints(tAggroBar);
			VUHDO_PixelUtil.Hide(tAggroBar);

			return;
		end

		VUHDO_setLlcStatusBarTexture(tAggroBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["AGGRO_BAR"]["TEXTURE"]);

		VUHDO_PixelUtil.SetPoint(tAggroBar, "BOTTOM", aHealthBar:GetName(), "TOP", 0, 0);
		VUHDO_PixelUtil.SetSize(tAggroBar, sPanelConfig[aPanelNum]["barScaling"]["barWidth"], sPanelConfig[aPanelNum]["barScaling"]["rowSpacing"]);

		VUHDO_PixelUtil.Show(tAggroBar);

		tAggroBar:SetValue(0);

		return;

	end



	--
	local tPrivateAura;
	local tPrivateAuraContainer;
	local tDurationFrame;
	local tNumAuras;
	local tFrameLevel;
	local tGrowthDir;
	local tWrapDir;
	local tMaxCols;
	local tCol;
	local tRow;
	local tStep;
	local tGridX;
	local tGridY;
	local tVisualSize;
	local tPoint;
	local tFactors;
	local tHalfX;
	local tHalfY;
	local tTextScale;
	local tEffectiveScale;
	local function VUHDO_initPrivateAura(aHealthBar, aButton, anAuraIndex, aPanelNum)

		tTextScale = (sPanelConfig[aPanelNum]["privateAura"]["textScale"] or 100) * 0.01;

		tPrivateAura = VUHDO_getPrivateAuraIcon(aButton, anAuraIndex);

		if not tPrivateAura then
			return;
		end

		tDurationFrame = VUHDO_getPrivateAuraDuration(aButton, anAuraIndex);

		if not tPrivateAura["anchorId"] then
			VUHDO_PixelUtil.Hide(tPrivateAura);
		end

		VUHDO_PixelUtil.ClearAllPoints(tPrivateAura);
		VUHDO_PixelUtil.SetFrameStrata(tPrivateAura, aHealthBar:GetFrameStrata());

		tFrameLevel = sPanelConfig[aPanelNum]["privateAura"]["frameLevel"] or 13;
		tPrivateAura["addLevel"] = tFrameLevel;
		VUHDO_PixelUtil.SetFrameLevel(tPrivateAura, tPrivateAuraContainer:GetFrameLevel() + 1 + tPrivateAura["addLevel"]);

		tGrowthDir = sGrowthOffsets[sPanelConfig[aPanelNum]["privateAura"]["growthDir"]] or sGrowthOffsets["RIGHT"];
		tWrapDir = sGrowthOffsets[sPanelConfig[aPanelNum]["privateAura"]["wrapDir"]] or sGrowthOffsets["DOWN"];
		tMaxCols = sPanelConfig[aPanelNum]["privateAura"]["maxColumns"] or 3;

		tStep = sPanelConfig[aPanelNum]["privateAuraStep"];
		tVisualSize = sPanelConfig[aPanelNum]["privateAuraHeight"];
		tPoint = sPanelConfig[aPanelNum]["privateAura"]["point"] or "TOPLEFT";
		tEffectiveScale = (tVisualSize / 32) * tTextScale;

		tCol = (anAuraIndex - 1) % tMaxCols;
		tRow = floor((anAuraIndex - 1) / tMaxCols);

		tGridX = tCol * tStep * tGrowthDir[1] + tRow * tStep * tWrapDir[1];
		tGridY = tCol * tStep * tGrowthDir[2] + tRow * tStep * tWrapDir[2];

		if sPanelConfig[aPanelNum]["privateAura"]["showTooltip"] then
			VUHDO_PixelUtil.SetSize(tPrivateAura, 32 / tTextScale, 32 / tTextScale);
			VUHDO_PixelUtil.SetScale(tPrivateAura, tEffectiveScale);

			if not InCombatLockdown() then
				VUHDO_PixelUtil.SetPoint(tPrivateAura, tPoint, tPrivateAuraContainer, tPoint, tGridX / tEffectiveScale, tGridY / tEffectiveScale);
			end

			if tDurationFrame then
				VUHDO_PixelUtil.Hide(tDurationFrame);
			end
		else
			tPrivateAura:SetSize(0.001, 0.001);
			VUHDO_PixelUtil.SetScale(tPrivateAura, tEffectiveScale);

			tFactors = VUHDO_PRIVATE_AURA_ANCHOR_FACTORS[tPoint] or VUHDO_PRIVATE_AURA_ANCHOR_FACTORS["TOPLEFT"];
			tHalfX = -(tFactors[1] - 0.5) * tVisualSize;
			tHalfY = (tFactors[2] - 0.5) * tVisualSize;

			if not InCombatLockdown() then
				tPrivateAura:SetPoint(tPoint, tPrivateAuraContainer, tPoint, (tGridX + tHalfX) / tEffectiveScale, (tGridY + tHalfY) / tEffectiveScale);
			end

			if tDurationFrame then
				tDurationFrame:ClearAllPoints();
				tDurationFrame:SetPoint(tPoint, tPrivateAuraContainer, tPoint, tGridX / tEffectiveScale, tGridY / tEffectiveScale);
				VUHDO_PixelUtil.SetSize(tDurationFrame, 32 / tTextScale, 32 / tTextScale);
				VUHDO_PixelUtil.Show(tDurationFrame);
			end
		end

		return;

	end



	--
	function VUHDO_initPrivateAuras(aHealthBar, aButton, aPanelNum)

		tNumAuras = sPanelConfig[aPanelNum]["privateAura"]["numAuras"] or 3;

		tPrivateAuraContainer = VUHDO_getPrivateAuraContainer(aButton);

		if not tPrivateAuraContainer then
			return;
		end

		if tNumAuras <= 0 then
			VUHDO_PixelUtil.Hide(tPrivateAuraContainer);

			for tAuraIndex = 1, VUHDO_MAX_PRIVATE_AURAS do
				tPrivateAura = VUHDO_getPrivateAuraIcon(aButton, tAuraIndex);

				if tPrivateAura then
					if tPrivateAura["anchorId"] then
						RemovePrivateAuraAnchor(tPrivateAura["anchorId"]);

						tPrivateAura["anchorId"] = nil;
					end

					VUHDO_PixelUtil.Hide(tPrivateAura);

					tDurationFrame = VUHDO_getPrivateAuraDuration(aButton, tAuraIndex);

					if tDurationFrame then
						VUHDO_PixelUtil.Hide(tDurationFrame);
					end
				end
			end

			return;
		end

		tVisualSize = sPanelConfig[aPanelNum]["privateAuraHeight"];
		tPoint = sPanelConfig[aPanelNum]["privateAura"]["point"] or "TOPLEFT";

		tFrameLevel = sPanelConfig[aPanelNum]["privateAura"]["frameLevel"] or 13;
		tPrivateAuraContainer["addLevel"] = tFrameLevel;

		VUHDO_PixelUtil.ClearAllPoints(tPrivateAuraContainer);
		VUHDO_PixelUtil.SetFrameStrata(tPrivateAuraContainer, aHealthBar:GetFrameStrata());
		VUHDO_PixelUtil.SetFrameLevel(tPrivateAuraContainer, aHealthBar:GetFrameLevel() + tFrameLevel);

		VUHDO_PixelUtil.SetSize(tPrivateAuraContainer, tVisualSize, tVisualSize);

		if not InCombatLockdown() then
			VUHDO_PixelUtil.SetPoint(tPrivateAuraContainer, tPoint, aHealthBar:GetName(), tPoint, sPanelConfig[aPanelNum]["privateAuraXOffset"], sPanelConfig[aPanelNum]["privateAuraYOffset"]);
		end

		VUHDO_PixelUtil.Show(tPrivateAuraContainer);

		for tAuraIndex = 1, tNumAuras do
			VUHDO_initPrivateAura(aHealthBar, aButton, tAuraIndex, aPanelNum);
		end

		for tAuraIndex = tNumAuras + 1, VUHDO_MAX_PRIVATE_AURAS do
			tPrivateAura = VUHDO_getPrivateAuraIcon(aButton, tAuraIndex);

			if tPrivateAura then
				if tPrivateAura["anchorId"] then
					RemovePrivateAuraAnchor(tPrivateAura["anchorId"]);

					tPrivateAura["anchorId"] = nil;
				end

				VUHDO_PixelUtil.Hide(tPrivateAura);

				tDurationFrame = VUHDO_getPrivateAuraDuration(aButton, tAuraIndex);

				if tDurationFrame then
					VUHDO_PixelUtil.Hide(tDurationFrame);
				end
			end
		end

		return;

	end



	--
	local tX;
	local tY;
	function VUHDO_initRaidIcon(aHealthBar, anIcon, aWidth, aPanelNum)

		tX = sPanelConfig[aPanelNum]["raidIcon"]["xAdjust"] * aWidth * 0.01;
		tY = -sPanelConfig[aPanelNum]["raidIcon"]["yAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * 0.01;

		VUHDO_PixelUtil.Hide(anIcon);
		VUHDO_PixelUtil.ClearAllPoints(anIcon);

		VUHDO_PixelUtil.SetPoint(anIcon, sPanelConfig[aPanelNum]["raidIcon"]["point"], aHealthBar:GetName(), sPanelConfig[aPanelNum]["raidIcon"]["point"], tX, tY);
		VUHDO_PixelUtil.SetSize(anIcon, sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * sPanelConfig[aPanelNum]["raidIcon"]["scale"] / 1.5, sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * sPanelConfig[aPanelNum]["raidIcon"]["scale"] / 1.5);

		return;

	end



	--
	local tIcon;
	local tX;
	local tY;
	local tHeight;
	local tBackgroundBar;
	function VUHDO_initSwiftmendIndicator(aButton, aHealthBar, aPanelNum)

		tIcon = VUHDO_getBarRoleIcon(aButton, 51);

		VUHDO_PixelUtil.ClearAllPoints(tIcon);
		VUHDO_PixelUtil.Hide(tIcon);

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["SWIFTMEND_INDICATOR"] == "" then
			return;
		end

		tX = sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["xAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barWidth"] * 0.01;
		tY = -sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["yAdjust"] * sPanelConfig[aPanelNum]["barScaling"]["barHeight"] * 0.01;

		tBackgroundBar = VUHDO_getHealthBar(aButton, 3);
		VUHDO_PixelUtil.SetPoint(tIcon, sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["anchor"], tBackgroundBar:GetName(), sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["anchor"], tX, tY);

		tHeight = 50 * sPanelConfig[aPanelNum]["swiftmendIndicatorSetup"]["SCALE"];
		VUHDO_PixelUtil.SetSizeFromPercentage(tIcon, sPanelConfig[aPanelNum]["barScaling"]["barHeight"], sPanelConfig[aPanelNum]["barScaling"]["barHeight"], tHeight, tHeight);

		return;

	end
end



do
	--
	local tTgButton;
	local tTgHealthBar;
	function VUHDO_initTargetBar(aButton, aPanelNum)

		if sPanelConfig[aPanelNum]["barScaling"]["showTarget"] then
			tTgButton = VUHDO_getTargetButton(aButton);

			tTgButton:SetAlpha(0);
			tTgButton:ClearAllPoints();

			if sPanelConfig[aPanelNum]["barScaling"]["targetOrientation"] == 1 then
				VUHDO_PixelUtil.SetPoint(tTgButton, "TOPLEFT", aButton:GetName(), "TOPRIGHT", sPanelConfig[aPanelNum]["barScaling"]["targetSpacing"], 0);
			else
				VUHDO_PixelUtil.SetPoint(tTgButton, "TOPRIGHT", aButton:GetName(), "TOPLEFT", -sPanelConfig[aPanelNum]["barScaling"]["targetSpacing"], 0);
			end

			VUHDO_PixelUtil.SetSize(tTgButton, sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], sPanelConfig[aPanelNum]["barScaling"]["barHeight"]);

			VUHDO_PixelUtil.Show(tTgButton);

			tTgHealthBar = VUHDO_getHealthBar(aButton, 5);

			tTgHealthBar:SetValue(tTgHealthBar["isInverted"] and 0 or 1);

			VUHDO_PixelUtil.SetSize(tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], sPanelConfig[aPanelNum]["barHeight"]);

			VUHDO_initBackgroundBar(VUHDO_getHealthBar(aButton, 12), aPanelNum);
			VUHDO_initManaBar(tTgButton, VUHDO_getHealthBar(aButton, 13), sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], true, aPanelNum);
			VUHDO_initRaidIcon(tTgHealthBar, VUHDO_getTargetBarRoleIcon(tTgButton, 50), sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], aPanelNum);
			VUHDO_initBarTexts(tTgButton, tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], aPanelNum);
			VUHDO_initOverhealText(tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["targetWidth"], aPanelNum);

			if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["BACKGROUND_BAR"] ~= "" then
				VUHDO_getHealthBar(tTgButton, 3):SetStatusBarColor(0, 0, 0, 0.4);
			else
				VUHDO_getHealthBar(tTgButton, 3):SetStatusBarColor(0, 0, 0, 0);
			end
		else
			VUHDO_PixelUtil.Hide(VUHDO_getTargetButton(aButton));
		end

		return;

	end



	--
	local tTotButton;
	function VUHDO_initTotBar(aButton, aHealthBar, aPanelNum)

		if sPanelConfig[aPanelNum]["barScaling"]["showTot"] then
			tTotButton  = VUHDO_getTotButton(aButton);

			tTotButton:SetAlpha(0);
			tTotButton:ClearAllPoints();

			if sPanelConfig[aPanelNum]["barScaling"]["targetOrientation"] == 1 then
				if sPanelConfig[aPanelNum]["barScaling"]["showTarget"] then
					tTgButton = VUHDO_getTargetButton(aButton);
					VUHDO_PixelUtil.SetPoint(tTotButton, "TOPLEFT", tTgButton:GetName(), "TOPRIGHT", sPanelConfig[aPanelNum]["barScaling"]["totSpacing"], 0);
				else
					VUHDO_PixelUtil.SetPoint(tTotButton, "TOPLEFT", aButton:GetName(), "TOPRIGHT", sPanelConfig[aPanelNum]["barScaling"]["totSpacing"], 0);
				end
			else
				if sPanelConfig[aPanelNum]["barScaling"]["showTarget"] then
					tTgButton = VUHDO_getTargetButton(aButton);
					VUHDO_PixelUtil.SetPoint(tTotButton, "TOPRIGHT", tTgButton:GetName(), "TOPLEFT", -sPanelConfig[aPanelNum]["barScaling"]["totSpacing"], 0);
				else
					VUHDO_PixelUtil.SetPoint(tTotButton, "TOPRIGHT", aButton:GetName(), "TOPLEFT", -sPanelConfig[aPanelNum]["barScaling"]["totSpacing"], 0);
				end
			end

			VUHDO_PixelUtil.SetSize(tTotButton, sPanelConfig[aPanelNum]["barScaling"]["totWidth"], sPanelConfig[aPanelNum]["barScaling"]["barHeight"]);

			VUHDO_PixelUtil.Show(tTotButton);

			tTgHealthBar = VUHDO_getHealthBar(aButton, 14);

			tTgHealthBar:SetValue(tTgHealthBar["isInverted"] and 0 or 1);

			VUHDO_PixelUtil.SetSize(tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["totWidth"], sPanelConfig[aPanelNum]["barHeight"]);

			VUHDO_initBackgroundBar(VUHDO_getHealthBar(aButton, 15), aPanelNum);
			VUHDO_initManaBar(tTotButton, VUHDO_getHealthBar(aButton, 16), sPanelConfig[aPanelNum]["barScaling"]["totWidth"], true, aPanelNum);
			VUHDO_initRaidIcon(tTgHealthBar, VUHDO_getTargetBarRoleIcon(tTotButton, 50), sPanelConfig[aPanelNum]["barScaling"]["totWidth"], aPanelNum);
			VUHDO_initBarTexts(tTotButton, tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["totWidth"], aPanelNum);
			VUHDO_initOverhealText(tTgHealthBar, sPanelConfig[aPanelNum]["barScaling"]["totWidth"], aPanelNum);

			if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["BACKGROUND_BAR"] ~= "" then
				VUHDO_getHealthBar(tTotButton, 3):SetStatusBarColor(0, 0, 0, 0.4);
			else
				VUHDO_getHealthBar(tTotButton, 3):SetStatusBarColor(0, 0, 0, 0);
			end
		else
			VUHDO_PixelUtil.Hide(VUHDO_getTotButton(aButton));
		end

		return;

	end
end



do
	--
	local tBar;
	function VUHDO_initFlashBar(aButton)

		tBar = _G[aButton:GetName() .. "BgBarFlBar"];

		tBar:SetStatusBarTexture("Interface\\AddOns\\VuhDo\\Images\\white_square_16_16");
		VUHDO_PixelUtil.ApplySettings(tBar:GetStatusBarTexture());

		tBar:SetStatusBarColor(1, 0.8, 0.8, 1);
		tBar:SetAlpha(0);

		return;

	end



	--
	function VUHDO_initReadyCheckIcon(aButton)

		VUHDO_PixelUtil.Hide(VUHDO_getBarRoleIcon(aButton, 20));

		return;

	end



	--
	function VUHDO_initHighlightBar(aButton, aPanelNum)

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["MOUSEOVER_HIGHLIGHT"] == "" then
			VUHDO_PixelUtil.Hide(VUHDO_getHealthBar(aButton, 8));
		else
			tBar = VUHDO_getHealthBar(aButton, 8);

			VUHDO_setLlcStatusBarTexture(tBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["MOUSEOVER_HIGHLIGHT"]["TEXTURE"]);
			tBar:SetAlpha(0);

			VUHDO_PixelUtil.Show(tBar);
		end

		return;

	end
end



--
function VUHDO_invalidateShieldMaskAnchors(aButton)

	VUHDO_getHealthBar(aButton, 19)["maskOrientation"] = nil;
	VUHDO_getHealthBar(aButton, 20)["maskOrientation"] = nil;

	return;

end



do
	--
	local tIncBar;
	local tShieldBar;
	local tOrientation;
	local tHealthHeight;
	local function VUHDO_layoutPredictionBarHeights(aButton, aPanelNum)

		if VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"] then
			return;
		end

		tOrientation = VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum);

		if "VERTICAL" ~= tOrientation and "VERTICAL_INV" ~= tOrientation then
			return;
		end

		tIncBar = VUHDO_getHealthBar(aButton, 6);
		tShieldBar = VUHDO_getHealthBar(aButton, 19);

		if not tIncBar or not tShieldBar then
			return;
		end

		tHealthHeight = (aButton["regularHeight"] or 0) - (aButton["manaBarLayoutHeight"] or 0);

		if tHealthHeight > 0 then
			VUHDO_PixelUtil.SetHeight(tIncBar, tHealthHeight);
			VUHDO_PixelUtil.SetHeight(tShieldBar, tHealthHeight);
		end

		return;

	end



	--
	function VUHDO_refreshShieldMaskAnchors(aButton, aPanelNum)

		if not VUHDO_hasManaOffsetBar(aButton) then
			return;
		end

		VUHDO_layoutPredictionBarHeights(aButton, aPanelNum);

		VUHDO_invalidateShieldMaskAnchors(aButton);
		VUHDO_updateIncShieldMaskAnchors(aButton, aPanelNum);
		VUHDO_updateOvershieldMaskAnchors(aButton, aPanelNum);

		return;

	end
end



do
	--
	local tHealthBar;
	local tIncBar;
	local tOvershieldBar;
	local tOffsetBar;
	local tShouldMirror;
	local tOrientation;
	local tIsInverted;
	local tOvershieldOrientation;
	local tIsFlipped;
	local tHealthTexture;
	local tOffsetTexture;
	local tClipFrame;
	local tUseIncExtension;
	local tHealthLevel;
	local tHealthWidth;
	local tHealthHeight;
	function VUHDO_updateOvershieldMaskAnchors(aButton, aPanelNum)

		if not sSecretsEnabled then
			return;
		end

		tHealthBar = VUHDO_getHealthBar(aButton, 1);
		tIncBar = VUHDO_getHealthBar(aButton, 6);
		tOvershieldBar = VUHDO_getHealthBar(aButton, 20);
		tOffsetBar = VUHDO_getHealthBar(aButton, 23);

		if not tHealthBar or not tIncBar or not tOvershieldBar or not tOffsetBar then
			return;
		end

		tClipFrame = tOvershieldBar:GetParent();

		tOrientation = VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum);
		tIsInverted = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"];

		tHealthTexture = tHealthBar:GetStatusBarTexture();

		tOvershieldOrientation = VUHDO_calculateDerivedOrientation(tOrientation, VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisOvershield"]);
		tShouldMirror = tOvershieldOrientation ~= tOrientation;

		tUseIncExtension = (VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"]) and tIncBar:IsShown();

		tHealthWidth = tHealthBar:GetWidth();
		tHealthHeight = tHealthBar:GetHeight();
		tHealthLevel = tHealthBar:GetFrameLevel();

		if not (sSecretsEnabled and (issecretvalue(tHealthWidth) or issecretvalue(tHealthHeight))) then
			if tOvershieldBar["maskOrientation"] == tOrientation and tOvershieldBar["maskIsInverted"] == tIsInverted
				and tOvershieldBar["maskIsMirrored"] == tShouldMirror and tOvershieldBar["maskIsIncoming"] == tUseIncExtension
				and tOvershieldBar["maskHealthWidth"] == tHealthWidth and tOvershieldBar["maskHealthHeight"] == tHealthHeight
				and tOvershieldBar["maskHealthLevel"] == tHealthLevel then
				return;
			end
		end

		tOvershieldBar["maskOrientation"] = tOrientation;
		tOvershieldBar["maskIsInverted"] = tIsInverted;
		tOvershieldBar["maskIsMirrored"] = tShouldMirror;
		tOvershieldBar["maskIsIncoming"] = tUseIncExtension;
		tOvershieldBar["maskHealthWidth"] = tHealthWidth;
		tOvershieldBar["maskHealthHeight"] = tHealthHeight;
		tOvershieldBar["maskHealthLevel"] = tHealthLevel;

		tClipFrame:ClearAllPoints();

		if tShouldMirror then
			tClipFrame:SetAllPoints(tHealthBar);
		elseif tIsInverted then
			if tOrientation == "HORIZONTAL" then
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPLEFT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMLEFT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
			elseif tOrientation == "HORIZONTAL_INV" then
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPRIGHT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMRIGHT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
			elseif tOrientation == "VERTICAL" then
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "TOPRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tClipFrame, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
			end
		else
			tClipFrame:SetAllPoints(tHealthTexture);
		end

		VUHDO_PixelUtil.SetFrameLevel(tClipFrame, tHealthLevel + 2);
		VUHDO_PixelUtil.SetFrameLevel(tOvershieldBar, tHealthLevel + 2);

		if tIsInverted then

			VUHDO_PixelUtil.SetFrameLevel(tClipFrame, tHealthLevel + 2);
			VUHDO_PixelUtil.SetFrameLevel(tOvershieldBar, tHealthLevel + 3);
		end

		if not tShouldMirror then
			tOffsetBar:ClearAllPoints();
			tOffsetBar:SetAllPoints(tHealthBar);
			tOffsetBar:SetOrientation(tOvershieldBar:GetOrientation());
			tOffsetBar:SetReverseFill(tOvershieldBar:GetReverseFill());
		end

		if tShouldMirror and not tIsInverted then
			tOffsetBar:ClearAllPoints();
			VUHDO_PixelUtil.SetSize(tOffsetBar, tHealthWidth, tHealthHeight);
			tOffsetBar:SetOrientation(tHealthBar:GetOrientation());
			tOffsetBar:SetReverseFill(tHealthBar:GetReverseFill());

			tOvershieldBar:ClearAllPoints();
			VUHDO_PixelUtil.SetSize(tOvershieldBar, tHealthWidth, tHealthHeight);
			tOvershieldBar:SetOrientation(tHealthBar:GetOrientation());
			tOvershieldBar:SetReverseFill(tHealthBar:GetReverseFill());

			if tOrientation == "HORIZONTAL" then
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPLEFT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
			elseif tOrientation == "HORIZONTAL_INV" then
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPRIGHT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMLEFT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
			elseif tOrientation == "VERTICAL" then
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "TOPRIGHT", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
			end
		elseif tShouldMirror then
			tOffsetBar:ClearAllPoints();
			VUHDO_PixelUtil.SetSize(tOffsetBar, tHealthWidth, tHealthHeight);
			tOffsetBar:SetOrientation(tHealthBar:GetOrientation());

			tOvershieldBar:ClearAllPoints();
			VUHDO_PixelUtil.SetSize(tOvershieldBar, tHealthWidth, tHealthHeight);
			tOvershieldBar:SetOrientation(tHealthBar:GetOrientation());

			if tOrientation == "HORIZONTAL" then
				tOffsetBar:SetReverseFill(true);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				tOvershieldBar:SetReverseFill(true);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
			elseif tOrientation == "HORIZONTAL_INV" then
				tOffsetBar:SetReverseFill(false);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				tOvershieldBar:SetReverseFill(false);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
			elseif tOrientation == "VERTICAL" then
				tOffsetBar:SetReverseFill(true);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				tOvershieldBar:SetReverseFill(true);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
			else
				tOffsetBar:SetReverseFill(false);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOffsetBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);

				tOffsetTexture = tOffsetBar:GetStatusBarTexture();

				tOvershieldBar:SetReverseFill(false);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "TOPRIGHT", 0, 0);
			end
		elseif not tUseIncExtension then
			tOvershieldBar:ClearAllPoints();
			tOvershieldBar:SetAllPoints(tHealthBar);
		else
			tOffsetTexture = tOffsetBar:GetStatusBarTexture();

			tIsFlipped = (tOvershieldOrientation == "HORIZONTAL_INV" or tOvershieldOrientation == "VERTICAL_INV") ~= tIsInverted;

			tOvershieldBar:ClearAllPoints();
			VUHDO_PixelUtil.SetSize(tOvershieldBar, tHealthWidth, tHealthHeight);

			if tOrientation == "HORIZONTAL" or tOrientation == "HORIZONTAL_INV" then
				if tIsFlipped then
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
				end
			else
				if tIsFlipped then
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMLEFT", tOffsetTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "BOTTOMRIGHT", tOffsetTexture, "TOPRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPLEFT", tOffsetTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tOvershieldBar, "TOPRIGHT", tOffsetTexture, "BOTTOMRIGHT", 0, 0);
				end
			end
		end

		return;

	end
end



do
	--
	local tHealthBar;
	local tIncBar;
	local tShieldBar;
	local tClipFrame;
	local tHealthTexture;
	local tOrientation;
	local tIsInverted;
	local tIsFlipped;
	local tIncTexture;
	local tHealthLevel;
	local tHealthWidth;
	local tHealthHeight;
	local tIsIncomingEnabled;
	function VUHDO_updateIncShieldMaskAnchors(aButton, aPanelNum)

		if not sSecretsEnabled then
			return;
		end

		tHealthBar = VUHDO_getHealthBar(aButton, 1);
		tIncBar = VUHDO_getHealthBar(aButton, 6);
		tShieldBar = VUHDO_getHealthBar(aButton, 19);

		if not tHealthBar or not tIncBar or not tShieldBar then
			return;
		end

		tClipFrame = tIncBar:GetParent();
		tHealthTexture = tHealthBar:GetStatusBarTexture();

		tOrientation = VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum);
		tIsInverted = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"];
		tIsIncomingEnabled = VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"];

		tHealthWidth = tHealthBar:GetWidth();
		tHealthHeight = tHealthBar:GetHeight();
		tHealthLevel = tHealthBar:GetFrameLevel();

		if not (sSecretsEnabled and (issecretvalue(tHealthWidth) or issecretvalue(tHealthHeight))) then
			if tShieldBar["maskOrientation"] == tOrientation and tShieldBar["maskIsInverted"] == tIsInverted
				and tShieldBar["maskIsIncoming"] == tIsIncomingEnabled
				and tShieldBar["maskHealthWidth"] == tHealthWidth and tShieldBar["maskHealthHeight"] == tHealthHeight
				and tShieldBar["maskHealthLevel"] == tHealthLevel then
				return;
			end
		end

		tShieldBar["maskOrientation"] = tOrientation;
		tShieldBar["maskIsInverted"] = tIsInverted;
		tShieldBar["maskIsIncoming"] = tIsIncomingEnabled;
		tShieldBar["maskHealthWidth"] = tHealthWidth;
		tShieldBar["maskHealthHeight"] = tHealthHeight;
		tShieldBar["maskHealthLevel"] = tHealthLevel;

		if not tIsInverted then
			if tClipFrame then
				tClipFrame:ClearAllPoints();
				tClipFrame:SetAllPoints(tHealthBar);
			end

			return;
		end

		if tClipFrame then
			tClipFrame:ClearAllPoints();
			tClipFrame:SetAllPoints(tHealthTexture);
		end

		tIsFlipped = (tOrientation == "HORIZONTAL_INV" or tOrientation == "VERTICAL_INV") ~= tIsInverted;

		tIncBar:ClearAllPoints();
		VUHDO_PixelUtil.SetSize(tIncBar, tHealthWidth, tHealthHeight);

		if tOrientation == "HORIZONTAL" then
			VUHDO_PixelUtil.SetPoint(tIncBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
		elseif tOrientation == "HORIZONTAL_INV" then
			VUHDO_PixelUtil.SetPoint(tIncBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
		elseif tOrientation == "VERTICAL" then
			VUHDO_PixelUtil.SetPoint(tIncBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tIncBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
		else
			VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
		end

		VUHDO_setStatusBarOrientation(tIncBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));
		tIncBar:SetReverseFill(tIsFlipped);

		tShieldBar:ClearAllPoints();
		VUHDO_PixelUtil.SetSize(tShieldBar, tHealthWidth, tHealthHeight);

		if tIsIncomingEnabled then
			tIncTexture = tIncBar:GetStatusBarTexture();

			if tOrientation == "HORIZONTAL" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tIncTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tIncTexture, "BOTTOMLEFT", 0, 0);
			elseif tOrientation == "HORIZONTAL_INV" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tIncTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tIncTexture, "BOTTOMRIGHT", 0, 0);
			elseif tOrientation == "VERTICAL" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tIncTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tIncTexture, "BOTTOMRIGHT", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tIncTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tIncTexture, "TOPRIGHT", 0, 0);
			end
		else
			if tOrientation == "HORIZONTAL" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
			elseif tOrientation == "HORIZONTAL_INV" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
			elseif tOrientation == "VERTICAL" then
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
			end
		end

		VUHDO_setStatusBarOrientation(tShieldBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));
		tShieldBar:SetReverseFill(tIsFlipped);

		if tClipFrame then
			VUHDO_PixelUtil.SetFrameLevel(tClipFrame, tHealthLevel + 2);
		end

		VUHDO_PixelUtil.SetFrameLevel(tIncBar, tHealthLevel + 3);
		VUHDO_PixelUtil.SetFrameLevel(tShieldBar, tHealthLevel + 3);

		return;

	end
end



do
	--
	local tHealthBar;
	local tIncBar;
	local tShieldBar;
	local tOvershieldBar;
	local tHealAbsorbBar;
	local tHealthLossBar;
	local tBgBar;
	local tOrientation;
	local tIsInverted;
	local tTurnAxisOvershield;
	local tTurnAxisHealAbsorb;
	local tTurnAxisHealthLoss;
	local tOvershieldOrientation;
	local tHealAbsorbOrientation;
	local tHealthTexture;
	local tHealthLossOrientation;
	local tBarWidth;
	local tBarHeight;
	local tIncTexture;
	function VUHDO_initPredictionBarAnchors(aButton, aPanelNum)

		VUHDO_invalidateShieldMaskAnchors(aButton);

		tHealthBar = VUHDO_getHealthBar(aButton, 1);
		tIncBar = VUHDO_getHealthBar(aButton, 6);
		tShieldBar = VUHDO_getHealthBar(aButton, 19);
		tOvershieldBar = VUHDO_getHealthBar(aButton, 20);
		tHealAbsorbBar = VUHDO_getHealthBar(aButton, 21);
		tHealthLossBar = VUHDO_getHealthBar(aButton, 22);
		tBgBar = VUHDO_getHealthBar(aButton, 3);

		if not tHealthBar or not tIncBar or not tShieldBar then
			return;
		end

		tOrientation = VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum);
		tIsInverted = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"];
		tTurnAxisOvershield = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisOvershield"];
		tTurnAxisHealAbsorb = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisHealAbsorb"];
		tTurnAxisHealthLoss = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisHealthLoss"];

		VUHDO_setStatusBarOrientation(tHealthBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));

		tBarWidth = sPanelConfig[aPanelNum]["barWidth"];
		tBarHeight = sPanelConfig[aPanelNum]["barHeight"];

		tIncBar:ClearAllPoints();
		tIncBar:SetMinMaxValues(0, 1);
		tIncBar:SetValue(0);
		VUHDO_setStatusBarOrientation(tIncBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));

		tShieldBar:ClearAllPoints();
		tShieldBar:SetMinMaxValues(0, 1);
		tShieldBar:SetValue(0);
		VUHDO_setStatusBarOrientation(tShieldBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));

		tHealthTexture = tHealthBar:GetStatusBarTexture();

		if not tIsInverted then
			if tOrientation == "HORIZONTAL" then
				VUHDO_PixelUtil.SetPoint(tIncBar, "TOPLEFT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				VUHDO_PixelUtil.SetWidth(tIncBar, tBarWidth);

				if VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"] then
					tIncTexture = tIncBar:GetStatusBarTexture();
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tIncTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tIncTexture, "BOTTOMRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tHealthTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				end

				VUHDO_PixelUtil.SetWidth(tShieldBar, tBarWidth);
			elseif tOrientation == "HORIZONTAL_INV" then
				VUHDO_PixelUtil.SetPoint(tIncBar, "TOPRIGHT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetWidth(tIncBar, tBarWidth);

				if VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"] then
					tIncTexture = tIncBar:GetStatusBarTexture();
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tIncTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tIncTexture, "BOTTOMLEFT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				end

				VUHDO_PixelUtil.SetWidth(tShieldBar, tBarWidth);
			elseif tOrientation == "VERTICAL" then
				VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMLEFT", tHealthTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tIncBar, "BOTTOMRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetHeight(tIncBar, tBarHeight);

				if VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"] then
					tIncTexture = tIncBar:GetStatusBarTexture();
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tIncTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tIncTexture, "BOTTOMRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "TOPRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				end

				VUHDO_PixelUtil.SetHeight(tShieldBar, tBarHeight);
			else
				VUHDO_PixelUtil.SetPoint(tIncBar, "TOPLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tIncBar, "TOPRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
				VUHDO_PixelUtil.SetHeight(tIncBar, tBarHeight);

				if VUHDO_CONFIG["SHOW_INCOMING"] or VUHDO_CONFIG["SHOW_OWN_INCOMING"] then
					tIncTexture = tIncBar:GetStatusBarTexture();
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tIncTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tIncTexture, "TOPRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMLEFT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tShieldBar, "BOTTOMRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
				end

				VUHDO_PixelUtil.SetHeight(tShieldBar, tBarHeight);
			end
		end

		VUHDO_updateIncShieldMaskAnchors(aButton, aPanelNum);

		if tOvershieldBar then
			tOvershieldOrientation = VUHDO_calculateDerivedOrientation(tOrientation, tTurnAxisOvershield);

			tOvershieldBar:ClearAllPoints();
			tOvershieldBar:SetAllPoints(tHealthBar);
			VUHDO_setStatusBarOrientation(tOvershieldBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));
			tOvershieldBar:SetReverseFill(tIsInverted == (tOvershieldOrientation == "HORIZONTAL_INV" or tOvershieldOrientation == "VERTICAL_INV"));

			VUHDO_updateOvershieldMaskAnchors(aButton, aPanelNum);
		end

		if tHealAbsorbBar then
			tHealAbsorbOrientation = VUHDO_calculateDerivedOrientation(tOrientation, tTurnAxisHealAbsorb);

			tHealAbsorbBar:ClearAllPoints();
			tHealthTexture = tHealthBar:GetStatusBarTexture();

			if tOrientation == "HORIZONTAL" then
				if tIsInverted then
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
				end
			elseif tOrientation == "HORIZONTAL_INV" then
				if tIsInverted then
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
				end
			elseif tOrientation == "VERTICAL" then
				if tIsInverted then
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthTexture, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthTexture, "TOPRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
				end
			else
				if tIsInverted then
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthBar, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthBar, "BOTTOMRIGHT", 0, 0);
				else
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMLEFT", tHealthTexture, "BOTTOMLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "BOTTOMRIGHT", tHealthTexture, "BOTTOMRIGHT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPLEFT", tHealthBar, "TOPLEFT", 0, 0);
					VUHDO_PixelUtil.SetPoint(tHealAbsorbBar, "TOPRIGHT", tHealthBar, "TOPRIGHT", 0, 0);
				end
			end

			VUHDO_setStatusBarOrientation(tHealAbsorbBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));
			tHealAbsorbBar:SetReverseFill(tIsInverted == (tHealAbsorbOrientation == "HORIZONTAL_INV" or tHealAbsorbOrientation == "VERTICAL_INV"));
		end

		if tHealthLossBar and tBgBar then
			tHealthLossOrientation = VUHDO_calculateDerivedOrientation(tOrientation, tTurnAxisHealthLoss);

			VUHDO_PixelUtil.ClearAllPoints(tHealthLossBar);
			tHealthLossBar:SetAllPoints(tBgBar);
			VUHDO_setStatusBarOrientation(tHealthLossBar, VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum));
			tHealthLossBar:SetReverseFill(tIsInverted == (tHealthLossOrientation == "HORIZONTAL_INV" or tHealthLossOrientation == "VERTICAL_INV"));
		end

		return;

	end
end


do
	--
	local tBar;
	function VUHDO_initSideBarLeft(aButton, aHealthBar, aPanelNum)

		tBar = VUHDO_getHealthBar(aButton, 17);

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["SIDE_LEFT"] == "" then
			VUHDO_PixelUtil.ClearAllPoints(tBar);
			VUHDO_PixelUtil.Hide(tBar);
		else
			VUHDO_setLlcStatusBarTexture(tBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["SIDE_LEFT"]["TEXTURE"]);

			VUHDO_PixelUtil.Show(tBar);
		end

		VUHDO_customizeIconText(tBar, 32, VUHDO_getHealthBarText(aButton, 17),
			sPanelConfig[aPanelNum]["indicatorConfig"]["TEXT_INDICATORS"]["SIDE_LEFT"]["TEXT"]);

		return;

	end



	--
	function VUHDO_initSideBarRight(aButton, aHealthBar, aPanelNum)

		tBar = VUHDO_getHealthBar(aButton, 18);

		if sPanelConfig[aPanelNum]["indicatorConfig"]["BOUQUETS"]["SIDE_RIGHT"] == "" then
			VUHDO_PixelUtil.ClearAllPoints(tBar);
			VUHDO_PixelUtil.Hide(tBar);
		else
			VUHDO_setLlcStatusBarTexture(tBar, sPanelConfig[aPanelNum]["indicatorConfig"]["CUSTOM"]["SIDE_RIGHT"]["TEXTURE"]);

			VUHDO_PixelUtil.Show(tBar);
		end

		VUHDO_customizeIconText(tBar, 32, VUHDO_getHealthBarText(aButton, 18),
			sPanelConfig[aPanelNum]["indicatorConfig"]["TEXT_INDICATORS"]["SIDE_RIGHT"]["TEXT"]);

		return;

	end
end



do
	--
	function VUHDO_initButtonStatics(aButton, aPanelNum)

		VUHDO_initButtonStaticsHots(aButton, aPanelNum);
		VUHDO_initButtonStaticsCustomDebuffs(aButton, aPanelNum);

		sHealthBar = VUHDO_getHealthBar(aButton, 1);

		return;

	end



	--
	function VUHDO_getStatusbarOrientationString(anIndicatorName, aPanelNum)

		if VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["vertical"] then
			return VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["turnAxis"]
				and "VERTICAL_INV" or "VERTICAL";
		else
			return VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["turnAxis"]
				and "HORIZONTAL_INV" or "HORIZONTAL";
		end

	end



	--
	function VUHDO_getStatusbarOrientationNumber(anIndicatorName, aPanelNum)

		if VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["vertical"] then
			return VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["turnAxis"]
				and VUHDO_STATUSBAR_TOP_TO_BOTTOM or VUHDO_STATUSBAR_BOTTOM_TO_TOP;
		else
			return VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"][anIndicatorName]["turnAxis"]
				and VUHDO_STATUSBAR_RIGHT_TO_LEFT or VUHDO_STATUSBAR_LEFT_TO_RIGHT;
		end

	end



	--
	local tBar;
	local tIsInverted;
	local tOrientation;
	local tClickPar;
	local tStatusTexture;
	function VUHDO_initHealButton(aButton, aPanelNum)

		aButton["healthBarGeometrySignature"] = nil;

		tClickPar = VUHDO_CONFIG["ON_MOUSE_UP"] and "AnyUp" or "AnyDown";
		aButton:RegisterForClicks(tClickPar);

		tStatusTexture = sPanelConfig[aPanelNum]["statusTexture"];

		for tCnt = 1, 22 do
			if 20 ~= tCnt and 21 ~= tCnt and 22 ~= tCnt then
				tBar = VUHDO_getHealthBar(aButton, tCnt);

				if tBar then
					tBar["forceImmediate"] = true;

					if tStatusTexture and tBar["statusTexturePath"] ~= tStatusTexture then
						tBar:SetStatusBarTexture(tStatusTexture);

						tBar["statusTexture"] = tBar:GetStatusBarTexture();
						tBar["statusTexturePath"] = tStatusTexture;

						tBar:SetToTargetValue();

						VUHDO_PixelUtil.ApplySettings(tBar["statusTexture"]);
					end
				end
			end
		end

		tIsInverted = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"];
		VUHDO_getHealthBar(aButton, 1)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 5)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 6)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 14)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 19)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 22)["isInverted"] = tIsInverted;

		tIsInverted = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["MANA_BAR"]["invertGrowth"];
		VUHDO_getHealthBar(aButton, 2)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 13)["isInverted"] = tIsInverted;
		VUHDO_getHealthBar(aButton, 16)["isInverted"] = tIsInverted;

		VUHDO_getHealthBar(aButton, 7)["isInverted"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["THREAT_BAR"]["invertGrowth"];
		VUHDO_getHealthBar(aButton, 17)["isInverted"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["SIDE_LEFT"]["invertGrowth"];
		VUHDO_getHealthBar(aButton, 18)["isInverted"] = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["SIDE_RIGHT"]["invertGrowth"];

		tOrientation = VUHDO_getStatusbarOrientationNumber("HEALTH_BAR", aPanelNum);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 1), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 5), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 6), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 14), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 19), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 22), tOrientation);

		tOrientation = VUHDO_getStatusbarOrientationNumber("MANA_BAR", aPanelNum);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 2), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 13), tOrientation);
		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 16), tOrientation);

		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 7), VUHDO_getStatusbarOrientationNumber("THREAT_BAR", aPanelNum));

		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 17), VUHDO_getStatusbarOrientationNumber("SIDE_LEFT", aPanelNum));

		VUHDO_setStatusBarOrientation(VUHDO_getHealthBar(aButton, 18), VUHDO_getStatusbarOrientationNumber("SIDE_RIGHT", aPanelNum));

		VUHDO_initButtonStatics(aButton, aPanelNum);

		VUHDO_initBackgroundBar(VUHDO_getHealthBar(aButton, 3), aPanelNum);
		VUHDO_initPredictionBarAnchors(aButton, aPanelNum);
		VUHDO_initIncomingOrShieldBar(aButton, 6, aPanelNum);
		VUHDO_initIncomingOrShieldBar(aButton, 19, aPanelNum);
		VUHDO_initHealthBar(aButton, aPanelNum);
		VUHDO_initAggroTexture(aButton, sHealthBar);
		VUHDO_initManaBar(aButton, VUHDO_getHealthBar(aButton,  2), sPanelConfig[aPanelNum]["barScaling"]["barWidth"], false, aPanelNum);
		VUHDO_initTargetBar(aButton, aPanelNum);
		VUHDO_initTotBar(aButton, sHealthBar, aPanelNum);
		VUHDO_initThreatBar(aButton, aPanelNum);
		VUHDO_initBarTexts(aButton, sHealthBar, sPanelConfig[aPanelNum]["barWidth"], aPanelNum);
		VUHDO_initOverhealText(sHealthBar, sPanelConfig[aPanelNum]["barScaling"]["barWidth"], aPanelNum);
		VUHDO_initHighlightBar(aButton, aPanelNum);
		VUHDO_initSideBarLeft(aButton, sHealthBar, aPanelNum);
		VUHDO_initSideBarRight(aButton, sHealthBar, aPanelNum);

		VUHDO_layoutHealthBarGeometry(aButton, aPanelNum, false);

		VUHDO_initAggroBar(aButton, sHealthBar, aPanelNum);

		if not sSecretsEnabled then
			VUHDO_initHotBars(aPanelNum);
			VUHDO_initAllHotIcons(aPanelNum);
			VUHDO_initCustomDebuffs(aPanelNum);
		end

		VUHDO_initAuraAnchorsForButton(aButton, aPanelNum);
		VUHDO_initPrivateAuras(sHealthBar, aButton, aPanelNum);
		VUHDO_initRaidIcon(sHealthBar, VUHDO_getBarRoleIcon(aButton, 50), sPanelConfig[aPanelNum]["barScaling"]["barWidth"], aPanelNum);
		VUHDO_initSwiftmendIndicator(aButton, sHealthBar, aPanelNum);
		VUHDO_initFlashBar(aButton);
		VUHDO_initReadyCheckIcon(aButton);

		if VUHDO_CONFIG["IS_CLIQUE_COMPAT_MODE"] then
			ClickCastFrames = ClickCastFrames or {};
			ClickCastFrames[aButton] = true;
			ClickCastFrames[_G[aButton:GetName() .. "Tg"]] = true;
			ClickCastFrames[_G[aButton:GetName() .. "Tot"]] = true;
		end

		if sSecretsEnabled then
			VUHDO_buildAllIndicatorAlphaChains(aButton, aPanelNum);
			VUHDO_buildBooleanOverlaysForButton(aButton, aPanelNum);
			VUHDO_buildTargetIndicatorAlphaChains(VUHDO_getTargetButton(aButton), aPanelNum);
			VUHDO_buildTargetIndicatorAlphaChains(VUHDO_getTotButton(aButton), aPanelNum);

			VUHDO_fixFrameLevels(true, aButton, aButton:GetFrameLevel(), aButton:GetChildren());
		end

		aButton["initRevision"] = sPanelInitRevision[aPanelNum] or 0;

		return;

	end



	--
	local tHealButton;
	local tGroupPanel;
	local tNumButtons;
	local tCnt;
	local tDebuffFrame;
	function VUHDO_initAllHealButtons(aPanel, aPanelNum)

		tNumButtons = VUHDO_getNumButtonsPanel(aPanelNum);

		for tCnt  = 1, tNumButtons do
			tHealButton = VUHDO_getOrCreateHealButton(tCnt, aPanelNum);

			if VUHDO_LibButtonFacade then
				VUHDO_initButtonButtonFacade(tHealButton);
			end

			VUHDO_initHealButton(tHealButton, aPanelNum);
		end

		tCnt = tNumButtons + 1;

		while true do
			tHealButton = VUHDO_getHealButton(tCnt, aPanelNum);

			if tHealButton then
				tHealButton["raidid"] = nil;
				VUHDO_safeSetAttribute(tHealButton, "unit", nil);

				for tDebuffCnt = 40, VUHDO_CONFIG["CUSTOM_DEBUFF"]["max_num"] + 39 do
					tDebuffFrame = VUHDO_getBarIconFrame(tHealButton, tDebuffCnt);

					if tDebuffFrame then
						VUHDO_safeSetAttribute(tDebuffFrame, "unit", nil);
						tDebuffFrame["raidid"] = nil;
					end
				end

				VUHDO_clearUnitAuraFrames(tHealButton);

				VUHDO_clearAuraContainersForButton(tHealButton);
				VUHDO_releaseOverlaysForButton(tHealButton);

				VUHDO_PixelUtil.ClearAllPoints(tHealButton);
				VUHDO_PixelUtil.Hide(tHealButton);
			else
				break;
			end

			tCnt = tCnt + 1;
		end

		if VUHDO_PANEL_MODELS[aPanelNum] then
			for tCnt = 1, #VUHDO_PANEL_MODELS[aPanelNum] do
				tGroupPanel = VUHDO_getGroupOrderPanel(aPanelNum, tCnt);

				if tGroupPanel then
					VUHDO_PixelUtil.Hide(tGroupPanel);
				end

				tGroupPanel = VUHDO_getGroupSelectPanel(aPanelNum,  tCnt);

				if tGroupPanel then
					VUHDO_PixelUtil.Hide(tGroupPanel);
				end
			end
		end

		return;

	end
end



--
VUHDO_PROHIBIT_REPOS = false;
do
	--
	local tSetup;
	local tPosition;
	local tPanelColor;
	local tLabel;
	local tGrowth;
	local tScale;
	local tFactor;
	local tX;
	local tY;
	local tBorderR;
	local tBorderG;
	local tBorderB;
	local tBorderO;
	function VUHDO_initPanel(aPanel, aPanelNum)

		tSetup  = VUHDO_PANEL_SETUP[aPanelNum];
		tPosition = tSetup["POSITION"];
		tPanelColor = tSetup["PANEL_COLOR"];

		tScale  = tSetup["SCALING"]["scale"];
		tFactor = tScale / aPanel:GetScale();

		tGrowth = tPosition["growth"];

		VUHDO_PixelUtil.ClearAllPoints(aPanel);
		VUHDO_PixelUtil.SetWidth(aPanel, tPosition["width"]);
		VUHDO_PixelUtil.SetHeight(aPanel, tPosition["height"]);
		VUHDO_PixelUtil.SetScale(aPanel, tScale);
		VUHDO_PixelUtil.SetPoint(aPanel, tPosition["orientation"],  "UIParent", tPosition["relativePoint"],  tPosition["x"],  tPosition["y"]);
		VUHDO_PixelUtil.EnableMouseWheel(aPanel, 1);
		VUHDO_PixelUtil.SetFrameStrata(aPanel, tSetup["frameStrata"] or "MEDIUM");

		if aPanel:IsShown() then
			tX, tY = VUHDO_getAnchorCoords(aPanel, tGrowth, tFactor);
			VUHDO_PixelUtil.ClearAllPoints(aPanel);

			if VUHDO_PROHIBIT_REPOS then
				VUHDO_PixelUtil.SetPoint(aPanel, tGrowth,  "UIParent", "BOTTOMLEFT", tX, tY);
			else
				VUHDO_PixelUtil.SetPoint(aPanel, tGrowth,  "UIParent", "BOTTOMLEFT", tX  * tFactor,  tY  * tFactor);
			end
		end

		VUHDO_PANEL_SETUP[aPanelNum]["POSITION"]["orientation"] = tGrowth;

		VUHDO_PixelUtil.SetWidth(aPanel, VUHDO_getHealPanelWidth(aPanelNum));
		VUHDO_PixelUtil.SetHeight(aPanel, VUHDO_getHealPanelHeight(aPanelNum));

		VUHDO_savePanelCoords(aPanel);

		tLabel = VUHDO_getPanelNumLabel(aPanel);

		VUHDO_STD_BACKDROP = aPanel:GetBackdrop();
		VUHDO_STD_BACKDROP["edgeFile"] = tPanelColor["BORDER"]["file"];
		VUHDO_STD_BACKDROP["edgeSize"] = VUHDO_getPixelPerfectBorderEdgeSize(aPanelNum);
		VUHDO_STD_BACKDROP["insets"]["left"] = VUHDO_getPixelPerfectBorderInsets(aPanelNum);
		VUHDO_STD_BACKDROP["insets"]["right"] = VUHDO_getPixelPerfectBorderInsets(aPanelNum);
		VUHDO_STD_BACKDROP["insets"]["top"] = VUHDO_getPixelPerfectBorderInsets(aPanelNum);
		VUHDO_STD_BACKDROP["insets"]["bottom"] = VUHDO_getPixelPerfectBorderInsets(aPanelNum);

		aPanel.backdropInfo = VUHDO_STD_BACKDROP;
		VUHDO_PixelUtil.ApplyBackdrop(aPanel, VUHDO_STD_BACKDROP);

		tBorderR, tBorderG, tBorderB, tBorderO = VUHDO_backColor(tPanelColor["BORDER"]);
		aPanel.backdropBorderColor = VUHDO_getOrCreateCachedColor(tBorderR, tBorderG, tBorderB, tBorderO);
		aPanel.backdropBorderColorAlpha = tBorderO or tPanelColor["BORDER"]["O"] or 0.46;
		aPanel:SetBackdropBorderColor(tBorderR, tBorderG, tBorderB, aPanel.backdropBorderColorAlpha);

		if VUHDO_IS_PANEL_CONFIG then
			tLabel:SetText("[PANEL "  .. aPanelNum .. "]");
			VUHDO_PixelUtil.SetPoint(tLabel:GetParent(), "BOTTOM", aPanel:GetName(), "TOP", 0, 3);
			VUHDO_PixelUtil.Show(tLabel:GetParent());

			if DESIGN_MISC_PANEL_NUM == aPanelNum and VuhDoNewOptionsPanelPanel and VuhDoNewOptionsPanelPanel:IsVisible() then
				VUHDO_DESIGN_BACKDROP = VUHDO_deepCopyTable(VUHDO_STD_BACKDROP);
				tLabel:SetTextColor(1, 1, 0, 1);
				VUHDO_UIFrameFlash(tLabel, 0.25, 0.5, 10000, true, 0.3, 0);

				aPanel.backdropInfo = VUHDO_DESIGN_BACKDROP;
				VUHDO_PixelUtil.ApplyBackdrop(aPanel, VUHDO_DESIGN_BACKDROP);

				aPanel.backdropBorderColor = VUHDO_getOrCreateCachedColor(1, 1, 1);
				aPanel.backdropBorderColorAlpha = 1;
				aPanel:SetBackdropBorderColor(VUHDO_backColor(tPanelColor["BORDER"]));
			else
				aPanel.backdropInfo = VUHDO_STD_BACKDROP;
				VUHDO_PixelUtil.ApplyBackdrop(aPanel, VUHDO_STD_BACKDROP);

				aPanel.backdropBorderColor = VUHDO_getOrCreateCachedColor(VUHDO_backColor(tPanelColor["BORDER"]));
				aPanel.backdropBorderColorAlpha = tPanelColor["BORDER"]["O"] or 1;
				aPanel:SetBackdropBorderColor(VUHDO_backColor(tPanelColor["BORDER"]));

				tLabel:SetTextColor(0.4,  0.4, 0.4, 1);
				VUHDO_UIFrameFlashStop(tLabel);			
			end

			if DESIGN_MISC_PANEL_NUM then
				VuhDoNewOptionsTabbedFramePanelNumLabelLabel:SetText(VUHDO_I18N_PANEL .. " #" .. DESIGN_MISC_PANEL_NUM);
				VUHDO_PixelUtil.Show(VuhDoNewOptionsTabbedFramePanelNumLabelLabel);
			else
				VUHDO_PixelUtil.Hide(VuhDoNewOptionsTabbedFramePanelNumLabelLabel);
			end

			_G[aPanel:GetName() .. "NewTxu"]:SetShown(not VUHDO_CONFIG_SHOW_RAID);
			_G[aPanel:GetName() .. "ClrTxu"]:SetShown(not VUHDO_CONFIG_SHOW_RAID);
		else
			VUHDO_PixelUtil.Hide(_G[aPanel:GetName() .. "NewTxu"]);
			VUHDO_PixelUtil.Hide(_G[aPanel:GetName() .. "ClrTxu"]);
			VUHDO_PixelUtil.Hide(tLabel:GetParent());

			if VuhDoNewOptionsTabbedFrame then
				VUHDO_PixelUtil.Hide(VuhDoNewOptionsTabbedFramePanelNumLabelLabel);
			end
		end

		aPanel:SetBackdropColor(VUHDO_backColor(tPanelColor["BACK"]));
		VUHDO_PixelUtil.EnableMouse(aPanel, not VUHDO_CONFIG["LOCK_CLICKS_THROUGH"]);

		VUHDO_PixelUtil.StopMovingOrSizing(aPanel);
		aPanel["isMoving"] = false;

		return;

	end
end



--
local tRedrawErrorStack;
local function VUHDO_deferredRedrawErrorHandler(anError)

	tRedrawErrorStack = debugstack(1, 20, 3);

	return tostring(anError) .. "\nStacktrace:\n" .. tRedrawErrorStack;

end



do
	--
	local tNumButtons;
	local tCycleId;
	function VUHDO_deferInitAllHealButtons(aPanel, aPanelNum, aCycleId)

		tNumButtons = VUHDO_getNumButtonsPanel(aPanelNum);

		tCycleId = VUHDO_generateCycleId(aCycleId, true);

		VUHDO_releaseStoredSemaphore(sButtonInitSemaphores[aPanelNum]);

		sButtonInitSemaphores[aPanelNum] = VUHDO_createSemaphore("InitAllHealButtons_" .. aPanelNum .. "_" .. tCycleId, 0, tNumButtons, sButtonInitTimeouts[aPanelNum]);

		if not sButtonInitSemaphores[aPanelNum] then
			return;
		end

		for tCnt = 1, tNumButtons do
			if VUHDO_deferTask(VUHDO_DEFER_INIT_HEAL_BUTTON, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum, tCnt) then
				sButtonInitSemaphores[aPanelNum]:increment();
			end
		end

		VUHDO_deferTask(VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum);

		return;

	end



	--
	local tModelArray;
	local tColumnIndex;
	local tButtonIndex;
	local tGroupArray;
	local tTotalButtons;
	local tCycleId;
	function VUHDO_deferPositionAllHealButtons(aPanel, aPanelNum, aCycleId)

		if not sButtonPositionTimeouts[aPanelNum] then
			VUHDO_calculateSemaphoreTimeouts();
		end

		tModelArray = VUHDO_getDynamicModelArray(aPanelNum);

		tColumnIndex = 1;
		tButtonIndex = 1;
		tTotalButtons = 0;

		for tModelIndex, tModelId in ipairs(tModelArray) do
			tGroupArray = VUHDO_getGroupMembersSorted(tModelId, sPanelConfig[aPanelNum]["sortCriterion"], aPanelNum, tModelIndex);

			tTotalButtons = tTotalButtons + #tGroupArray;
		end

		tCycleId = VUHDO_generateCycleId(aCycleId, true);

		VUHDO_releaseStoredSemaphore(sButtonPositionSemaphores[aPanelNum]);

		sButtonPositionSemaphores[aPanelNum] = VUHDO_createSemaphore("PositionAllHealButtons_" .. aPanelNum .. "_" .. tCycleId, 0, tTotalButtons, sButtonPositionTimeouts[aPanelNum]);

		if not sButtonPositionSemaphores[aPanelNum] then
			return;
		end

		tColumnIndex = 1;
		tButtonIndex = 1;

		for tModelIndex, tModelId in ipairs(tModelArray) do
			tGroupArray = VUHDO_getGroupMembersSorted(tModelId, sPanelConfig[aPanelNum]["sortCriterion"], aPanelNum, tModelIndex);

			for tGroupIndex, tUnit in ipairs(tGroupArray) do
				if VUHDO_deferTask(VUHDO_DEFER_POSITION_HEAL_BUTTON, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, tUnit, aPanelNum, tButtonIndex, tModelIndex, tModelId, tGroupIndex, tColumnIndex) then
					sButtonPositionSemaphores[aPanelNum]:increment();
				end

				tButtonIndex = tButtonIndex + 1;
			end

			tColumnIndex = tColumnIndex + 1;
		end

		return;

	end



	--
	local tHealButton;
	local function VUHDO_pcallInitHealButton(aPanelNum, aButtonIndex)

		tHealButton = VUHDO_getOrCreateHealButton(aButtonIndex, aPanelNum);

		sHealthBar = VUHDO_getHealthBar(tHealButton, 1);

		if VUHDO_LibButtonFacade then
			VUHDO_initButtonButtonFacade(tHealButton);
		end

		VUHDO_initHealButton(tHealButton, aPanelNum);

		return;

	end



	--
	local tInitHealButtonSuccess;
	local tInitHealButtonError;
	function VUHDO_deferInitHealButtonDelegate(aPanelNum, aButtonIndex)

		tInitHealButtonSuccess, tInitHealButtonError = xpcall(VUHDO_pcallInitHealButton, VUHDO_deferredRedrawErrorHandler, aPanelNum, aButtonIndex);

		if not tInitHealButtonSuccess then
			VUHDO_Msg("Deferred redraw error: " .. tostring(tInitHealButtonError));
		end

		if sButtonInitSemaphores[aPanelNum] then
			sButtonInitSemaphores[aPanelNum]:decrement();
		end

		return;

	end



	--
	local tCycleId;
	function VUHDO_startRefreshButtonInits(aPanelNum, aMaxCount)

		if not sButtonInitTimeouts[aPanelNum] then
			VUHDO_calculateSemaphoreTimeouts();
		end

		tCycleId = VUHDO_generateCycleId();

		VUHDO_releaseStoredSemaphore(sButtonInitSemaphores[aPanelNum]);

		sButtonInitSemaphores[aPanelNum] = VUHDO_createSemaphore("RefreshInitButtons_" .. aPanelNum .. "_" .. tCycleId, 0, aMaxCount, sButtonInitTimeouts[aPanelNum]);

		return sButtonInitSemaphores[aPanelNum];

	end



	--
	function VUHDO_enqueueRefreshButtonInit(aPanelNum, aButtonIndex)

		if VUHDO_deferTask(VUHDO_DEFER_INIT_HEAL_BUTTON, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum, aButtonIndex) and sButtonInitSemaphores[aPanelNum] then
			sButtonInitSemaphores[aPanelNum]:increment();
		end

		return;

	end



	--
	local tSemaphores;
	function VUHDO_waitRefreshButtonInits(aPanelNum, aTaskType, aPriority, ...)

		if not sButtonInitSemaphores[aPanelNum] then
			return true;
		end

		tSemaphores = { sButtonInitSemaphores[aPanelNum] };

		if VUHDO_waitForSemaphores(tSemaphores, aTaskType, aPriority, ...) then
			VUHDO_releaseStoredSemaphore(sButtonInitSemaphores[aPanelNum]);

			sButtonInitSemaphores[aPanelNum] = nil;

			return true;
		end

		return false;

	end
end



do
	--
	local tCurrentCycleId;
	local tTrackerKey;
	function VUHDO_deferRedrawPanelComplete(aPanelNum, anIsFixAllFrameLevels, aCycleId)

		if not sPanelCompletionTracker then
			sPanelCompletionTracker = { };
		end

		tCurrentCycleId = aCycleId or "UNKNOWN";
		tTrackerKey = tCurrentCycleId .. "_" .. aPanelNum;

		if sPanelCompletionTracker[tTrackerKey] then
			return;
		end

		sPanelCompletionTracker[tTrackerKey] = true;

		VUHDO_deferTask(VUHDO_DEFER_REDRAW_PANEL_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum, anIsFixAllFrameLevels, aCycleId);

		return;

	end



	--
	local tIsFullRedrawCycle;
	local tCurrentCycleId;
	local tIsPanelActive;
	local tWaitingRequest;
	local tCycleId;
	function VUHDO_deferRedrawPanel(aPanelNum, anIsFixAllFrameLevels, aCycleId)

		tIsFullRedrawCycle = (aCycleId ~= nil);
		tCurrentCycleId = aCycleId or "UNKNOWN";

		tIsPanelActive = false;

		if tIsFullRedrawCycle then
			if sRedrawPanelSemaphores[aPanelNum] and sRedrawPanelSemaphores[aPanelNum]["count"] > 0 then
				tIsPanelActive = true;
			end
		else
			if sRedrawPanelSemaphores[aPanelNum] and sRedrawPanelSemaphores[aPanelNum]["count"] > 0 then
				tIsPanelActive = true;
			elseif sRedrawAllPanelsSemaphore and sRedrawAllPanelsSemaphore["count"] > 0 then
				tIsPanelActive = true;
			end
		end

		if tIsPanelActive then
			if not sWaitingIndividualRedraws[aPanelNum] then
				sWaitingIndividualRedraws[aPanelNum] = { };
			end

			if not sQueuedIndividualRequests[aPanelNum] then
				sQueuedIndividualRequests[aPanelNum] = { };
			end

			if sQueuedIndividualRequests[aPanelNum][anIsFixAllFrameLevels] then
				return;
			end

			tWaitingRequest = {
				["isFixAllFrameLevels"] = anIsFixAllFrameLevels,
				["cycleId"] = aCycleId,
				["timestamp"] = GetTime()
			};

			sQueuedIndividualRequests[aPanelNum][anIsFixAllFrameLevels] = true;
			tinsert(sWaitingIndividualRedraws[aPanelNum], tWaitingRequest);

			return;
		end

		if not tIsFullRedrawCycle then
			tCycleId = VUHDO_generateCycleId();
			tCurrentCycleId = tCycleId;

			if not sRedrawPanelSemaphores[aPanelNum] then
				VUHDO_calculateSemaphoreTimeouts();

				sRedrawPanelSemaphores[aPanelNum] = VUHDO_createSemaphore("RedrawPanel_" .. aPanelNum .. "_" .. tCycleId, 0, 1, sPanelRedrawTimeout);

				if sRedrawPanelSemaphores[aPanelNum] then
					sPanelCompletionTracker = { };
				end
			end
		end

		if VUHDO_isPanelPopulated(aPanelNum) then
			if tIsFullRedrawCycle and sRedrawAllPanelsSemaphore then
				sRedrawAllPanelsSemaphore:increment();
			elseif not tIsFullRedrawCycle and sRedrawPanelSemaphores[aPanelNum] then
				sRedrawPanelSemaphores[aPanelNum]:increment();
			end

			VUHDO_invalidatePanelButtonInits(aPanelNum);

			VUHDO_deferTask(VUHDO_DEFER_REDRAW_PANEL, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum, anIsFixAllFrameLevels, tCurrentCycleId);
		else
			VUHDO_PixelUtil.Hide(VUHDO_getActionPanelOrStub(aPanelNum));

			if tIsFullRedrawCycle and aCycleId and sRedrawAllPanelsSemaphore and VUHDO_extractCycleIdFromSemaphoreName(sRedrawAllPanelsSemaphore["name"]) == aCycleId then
				if sRedrawAllPanelsSemaphore["count"] > 0 then
					sRedrawAllPanelsSemaphore:decrement();
				end
			end
		end

		return;

	end



	--
	local tHealButton;
	local tXPos;
	local tYPos;
	local tPanel;
	local function VUHDO_pcallPositionHealButton(aUnit, aPanelNum, aButtonIndex, aModelId, aGroupIndex, aColumnIndex)

		tHealButton = VUHDO_getOrCreateHealButton(aButtonIndex, aPanelNum);

		VUHDO_positionHealButton(tHealButton, aPanelNum);

		if aUnit and (tHealButton["raidid"] ~= aUnit or tHealButton:GetAttribute("unit") ~= aUnit) then
			VUHDO_resetButtonVisuals(tHealButton);
		end

		if aUnit then
			VUHDO_setupAllHealButtonAttributes(tHealButton, aUnit, false, 70 == aModelId, false, false); -- VUHDO_ID_VEHICLES
		end

		if VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showTarget"] then
			VUHDO_setupAllTargetButtonAttributes(VUHDO_getTargetButton(tHealButton), aUnit);
		end

		if VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showTot"] then
			VUHDO_setupAllTotButtonAttributes(VUHDO_getTotButton(tHealButton), aUnit);
		end

		tXPos, tYPos = VUHDO_getHealButtonPos(aColumnIndex, aGroupIndex, aPanelNum);

		if VUHDO_isDifferentButtonPoint(tHealButton, tXPos, -tYPos) then
			VUHDO_PixelUtil.Hide(tHealButton);
			VUHDO_PixelUtil.ClearAllPoints(tHealButton);

			tPanel = VUHDO_getOrCreateActionPanel(aPanelNum);
			VUHDO_PixelUtil.SetPoint(tHealButton, "TOPLEFT", tPanel:GetName(), "TOPLEFT", tXPos, -tYPos);
		end

		if tHealButton["raidid"] then
			VUHDO_addUnitButton(tHealButton, aPanelNum);
		end

		if not tHealButton:IsShown() then
			VUHDO_PixelUtil.Show(tHealButton);
		end

		return;

	end



	--
	local tPositionHealButtonSuccess;
	local tPositionHealButtonError;
	function VUHDO_deferPositionHealButtonDelegate(aUnit, aPanelNum, aButtonIndex, aModelIndex, aModelId, aGroupIndex, aColumnIndex)

		tPositionHealButtonSuccess, tPositionHealButtonError = xpcall(VUHDO_pcallPositionHealButton, VUHDO_deferredRedrawErrorHandler, aUnit, aPanelNum, aButtonIndex, aModelId, aGroupIndex, aColumnIndex);

		if not tPositionHealButtonSuccess then
			VUHDO_Msg("Deferred redraw error: " .. tostring(tPositionHealButtonError));
		end

		if sButtonPositionSemaphores[aPanelNum] then
			sButtonPositionSemaphores[aPanelNum]:decrement();
		end

		return;

	end



	--
	local tPanel;
	local function VUHDO_pcallRedrawPanelComplete(aPanelNum, anIsFixAllFrameLevels)

		tPanel = VUHDO_getOrCreateActionPanel(aPanelNum);

		VUHDO_positionTableHeaders(tPanel, aPanelNum);

		VUHDO_initPanel(tPanel, aPanelNum);

		if VUHDO_isPanelVisible(aPanelNum) then
			VUHDO_fixFrameLevels(anIsFixAllFrameLevels, tPanel, 2, tPanel:GetChildren());

			VUHDO_PixelUtil.Show(tPanel);
		else
			VUHDO_PixelUtil.Hide(tPanel);
		end

		VUHDO_updateAllPanelBars(aPanelNum);

		VUHDO_redisplayAllUnitAuras();

		return;

	end



	--
	local tCurrentCycleId;
	local tTrackerKey;
	local tNextRequest;
	local tButtonSemaphores;
	local tRedrawPanelCompleteSuccess;
	local tRedrawPanelCompleteError;
	function VUHDO_deferRedrawPanelCompleteDelegate(aPanelNum, anIsFixAllFrameLevels, aCycleId)

		if tButtonSemaphores then
			twipe(tButtonSemaphores);
		else
			tButtonSemaphores = { };
		end

		if sButtonInitSemaphores[aPanelNum] then
			tinsert(tButtonSemaphores, sButtonInitSemaphores[aPanelNum]);
		end

		if sButtonPositionSemaphores[aPanelNum] then
			tinsert(tButtonSemaphores, sButtonPositionSemaphores[aPanelNum]);
		end

		if #tButtonSemaphores > 0 then
			if not VUHDO_waitForSemaphores(tButtonSemaphores, VUHDO_DEFER_REDRAW_PANEL_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum, anIsFixAllFrameLevels, aCycleId) then
				return;
			end
		end

		tRedrawPanelCompleteSuccess, tRedrawPanelCompleteError = xpcall(VUHDO_pcallRedrawPanelComplete, VUHDO_deferredRedrawErrorHandler, aPanelNum, anIsFixAllFrameLevels);

		if not tRedrawPanelCompleteSuccess then
			VUHDO_Msg("Deferred redraw error: " .. tostring(tRedrawPanelCompleteError));
		end

		if aCycleId and sRedrawAllPanelsSemaphore and VUHDO_extractCycleIdFromSemaphoreName(sRedrawAllPanelsSemaphore["name"]) == aCycleId then
			if sRedrawAllPanelsSemaphore["count"] <= 0 then
				return;
			end

			sRedrawAllPanelsSemaphore:decrement();
		elseif sRedrawPanelSemaphores[aPanelNum] then
			if sRedrawPanelSemaphores[aPanelNum]["count"] <= 0 then
				return;
			end

			sRedrawPanelSemaphores[aPanelNum]:decrement();

			if sRedrawPanelSemaphores[aPanelNum]["count"] == 0 then
				VUHDO_releaseStoredSemaphore(sRedrawPanelSemaphores[aPanelNum]);

				sRedrawPanelSemaphores[aPanelNum] = nil;

				if sWaitingIndividualRedraws[aPanelNum] and #sWaitingIndividualRedraws[aPanelNum] > 0 then
					tNextRequest = tremove(sWaitingIndividualRedraws[aPanelNum], 1);

					if sQueuedIndividualRequests[aPanelNum] then
						sQueuedIndividualRequests[aPanelNum][tNextRequest["isFixAllFrameLevels"]] = nil;
					end

					VUHDO_deferRedrawPanel(aPanelNum, tNextRequest["isFixAllFrameLevels"], tNextRequest["cycleId"]);
				else
					if #sWaitingAllPanelsRedraws > 0 then
						tNextRequest = tremove(sWaitingAllPanelsRedraws, 1);

						sQueuedAllPanelsRequests[tNextRequest["isFixAllFrameLevels"]] = nil;

						VUHDO_deferRedrawAllPanels(tNextRequest["isFixAllFrameLevels"]);
					end
				end
			end
		end

		if sPanelCompletionTracker and aCycleId then
			tCurrentCycleId = aCycleId or "UNKNOWN";
			tTrackerKey = tCurrentCycleId .. "_" .. aPanelNum;

			sPanelCompletionTracker[tTrackerKey] = nil;
		end

		VUHDO_timeRefreshMissingBuffContainers(0.01);

		return;

	end



	--
	local tCnt;
	local tHealButton;
	local tGroupPanel;
	local tDebuffFrame;
	function VUHDO_deferInitAllHealButtonsCompleteDelegate(aPanelNum)

		if sButtonInitSemaphores[aPanelNum] and not sButtonInitSemaphores[aPanelNum]:waitFor(VUHDO_DEFER_INIT_ALL_HEAL_BUTTONS_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum) then
			return;
		end

		tCnt = VUHDO_getNumButtonsPanel(aPanelNum) + 1;

		while true do
			tHealButton = VUHDO_getHealButton(tCnt, aPanelNum);

			if tHealButton then
				tHealButton["raidid"] = nil;
				VUHDO_safeSetAttribute(tHealButton, "unit", nil);

				for tDebuffCnt = 40, VUHDO_CONFIG["CUSTOM_DEBUFF"]["max_num"] + 39 do
					tDebuffFrame = VUHDO_getBarIconFrame(tHealButton, tDebuffCnt);

					if tDebuffFrame then
						VUHDO_safeSetAttribute(tDebuffFrame, "unit", nil);
						tDebuffFrame["raidid"] = nil;
					end
				end

				VUHDO_clearUnitAuraFrames(tHealButton);

				VUHDO_clearAuraContainersForButton(tHealButton);
				VUHDO_releaseOverlaysForButton(tHealButton);

				VUHDO_PixelUtil.ClearAllPoints(tHealButton);
				VUHDO_PixelUtil.Hide(tHealButton);
			else
				break;
			end

			tCnt = tCnt + 1;
		end

		if VUHDO_PANEL_MODELS[aPanelNum] then
			for tCnt = 1, #VUHDO_PANEL_MODELS[aPanelNum] do
				tGroupPanel = VUHDO_getGroupOrderPanel(aPanelNum, tCnt);

				if tGroupPanel then
					VUHDO_PixelUtil.Hide(tGroupPanel);
				end

				tGroupPanel = VUHDO_getGroupSelectPanel(aPanelNum,  tCnt);

				if tGroupPanel then
					VUHDO_PixelUtil.Hide(tGroupPanel);
				end
			end
		end

		return;

	end



	--
	function VUHDO_deferPositionConfigPanels(aPanelNum)

		VUHDO_deferTask(VUHDO_DEFER_POSITION_CONFIG_PANELS, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, aPanelNum);

		return;

	end



	--
	function VUHDO_deferPositionConfigPanelsDelegate(aPanelNum)

		VUHDO_positionAllGroupConfigPanels(aPanelNum);

		return;

	end
end



do
	--
	local tPanel;
	function VUHDO_redrawPanel(aPanelNum, anIsFixAllFrameLevels)

		VUHDO_invalidatePanelButtonInits(aPanelNum);

		if VUHDO_isPanelPopulated(aPanelNum) then
			tPanel = VUHDO_getOrCreateActionPanel(aPanelNum);

			VUHDO_initLocalVars(aPanelNum);
			VUHDO_initAllHealButtons(tPanel, aPanelNum);

			if VUHDO_isConfigPanelShowing() then
				VUHDO_positionAllGroupConfigPanels(aPanelNum);
			else
				VUHDO_positionAllHealButtons(tPanel, aPanelNum);
			end

			VUHDO_positionTableHeaders(tPanel,  aPanelNum);

			VUHDO_initPanel(tPanel, aPanelNum);

			if VUHDO_isPanelVisible(aPanelNum) then
				VUHDO_fixFrameLevels(anIsFixAllFrameLevels, tPanel, 2, tPanel:GetChildren());

				VUHDO_PixelUtil.Show(tPanel);
			else
				VUHDO_PixelUtil.Hide(tPanel);
			end
		else
			VUHDO_PixelUtil.Hide(VUHDO_getActionPanelOrStub(aPanelNum));
		end

		return;

	end
	_G["VUHDO_redrawPanel"] = VUHDO_redrawPanel;



	--
	local tGcdCol;
	function VUHDO_redrawAllPanels(anIsFixAllFrameLevels)

		VUHDO_invalidatePanelButtonInits();

		VUHDO_resetMacroCaches();
		VUHDO_resetSizeCalcCaches();
		VUHDO_clearBackdropCache();
		VUHDO_clearCustomFlagCache();
		twipe(VUHDO_UNIT_BUTTONS);
		twipe(VUHDO_UNIT_BUTTONS_PANEL);

		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			_G["VUHDO_redrawPanel"](tPanelNum, anIsFixAllFrameLevels);
		end

		VUHDO_setupAllButtonsUnitWatch(VUHDO_CONFIG["HIDE_EMPTY_BUTTONS"] and not VUHDO_IS_PANEL_CONFIG and not VUHDO_isConfigDemoUsers());
		VUHDO_updateAllRaidBars();

		if VUHDO_isShowGcd() then
			tGcdCol = VUHDO_PANEL_SETUP["BAR_COLORS"]["GCD_BAR"];

			VUHDO_setStatusBarVuhDoColor(VuhDoGcdStatusBar, tGcdCol);
			VuhDoGcdStatusBar:SetStatusBarTexture("Interface\\AddOns\\VuhDo\\Images\\white_square_16_16");

			VUHDO_PixelUtil.ApplySettings(VuhDoGcdStatusBar:GetStatusBarTexture());

			VuhDoGcdStatusBar:SetMinMaxValues(0, 1);
			VuhDoGcdStatusBar:SetValue(0);
			VUHDO_PixelUtil.SetFrameStrata(VuhDoGcdStatusBar, "TOOLTIP");
		end

		VUHDO_PixelUtil.Hide(VuhDoGcdStatusBar);

		VUHDO_PixelUtil.ApplySettings(VuhDoDirectionFrameArrow);
		VuhDoDirectionFrameArrow:SetVertexColor(VUHDO_backColor(VUHDO_PANEL_SETUP["BAR_COLORS"]["DIRECTION"]));
		VUHDO_PixelUtil.SetPoint(VuhDoDirectionFrameText, "TOP", "VuhDoDirectionFrameArrow", "CENTER", 5,  -2);
		VuhDoDirectionFrameText:SetText("");
		VUHDO_PixelUtil.SetFrameStrata(VuhDoDirectionFrame, "TOOLTIP");

		VUHDO_initAllEventBouquets();

		VUHDO_updateToggledUnitEvents();

		return;

	end
	_G["VUHDO_redrawAllPanels"] = VUHDO_redrawAllPanels;
end



do
	--
	function VUHDO_reloadUI(anIsFixAllFrameLevels)

		if InCombatLockdown() then
			return;
		end

		VUHDO_IS_RELOADING = true;

		VUHDO_invalidatePanelButtonInits();

		VUHDO_clearBackdropCache();
		VUHDO_clearCustomFlagCache();
		VUHDO_initAllBurstCaches(); -- Wichtig f�r INTERNAL_TOGGLES=>Clusters
		VUHDO_reloadRaidMembers();
		VUHDO_resetNameTextCache();
		VUHDO_initDebuffs(); -- Talente scheinen recht sp�t zur Verf�gung zu stehen...

		if VUHDO_CONFIG["USE_DEFERRED_REDRAW"] and VUHDO_IN_COMBAT_RELOG then
			VUHDO_refreshRaidMembers();

			_G["VUHDO_redrawAllPanels"](anIsFixAllFrameLevels);
		else
			VUHDO_redrawAllPanels(anIsFixAllFrameLevels);
		end

		if not VUHDO_CONFIG["USE_DEFERRED_REDRAW"] or VUHDO_IN_COMBAT_RELOG then
			VUHDO_updateAllCustomDebuffs(true);
			VUHDO_refreshAllUnitAuras();
			VUHDO_rebuildTargets();
			VUHDO_updatePanelVisibility();
		end

		VUHDO_IS_RELOADING = false;

		VUHDO_timeRefreshMissingBuffContainers(0.05);

		VUHDO_reloadBuffPanel();

		return;

	end



	--
	function VUHDO_lnfReloadUI()

		if InCombatLockdown() then
			return;
		end

		VUHDO_IS_RELOADING = true;

		VUHDO_invalidatePanelButtonInits();

		VUHDO_clearBackdropCache();
		VUHDO_clearCustomFlagCache();
		VUHDO_initAllBurstCaches();
		VUHDO_reloadRaidMembers();
		VUHDO_updatePanelVisibility();

		VUHDO_buildGenericHealthBarBouquet();
		VUHDO_buildGenericTargetHealthBouquet();
		VUHDO_bouqetsChanged();

		_G["VUHDO_redrawAllPanels"](false);

		VUHDO_initAllBurstCaches();
		VUHDO_redisplayAllUnitAuras();

		VUHDO_IS_RELOADING = false;

		VUHDO_timeRefreshMissingBuffContainers(0.05);

		return;

	end



	--
	function VUHDO_isDeferredRedrawActive()

		if sRedrawAllPanelsSemaphore and sRedrawAllPanelsSemaphore["count"] > 0 then
			return true;
		end

		for tPanelNum = 1, 10 do
			if sRedrawPanelSemaphores[tPanelNum] and sRedrawPanelSemaphores[tPanelNum]["count"] > 0 then
				return true;
			end

			if sButtonInitSemaphores[tPanelNum] and sButtonInitSemaphores[tPanelNum]["count"] > 0 then
				return true;
			end

			if sButtonPositionSemaphores[tPanelNum] and sButtonPositionSemaphores[tPanelNum]["count"] > 0 then
				return true;
			end
		end

		return false;

	end



	--
	function VUHDO_isDeferredRedrawActiveForPanel(aPanelNum)

		if sRedrawPanelSemaphores[aPanelNum] and sRedrawPanelSemaphores[aPanelNum]["count"] > 0 then
			return true;
		end

		if sButtonInitSemaphores[aPanelNum] and sButtonInitSemaphores[aPanelNum]["count"] > 0 then
			return true;
		end

		if sButtonPositionSemaphores[aPanelNum] and sButtonPositionSemaphores[aPanelNum]["count"] > 0 then
			return true;
		end

		return false;

	end



	--
	local tWaitingRequest;
	local tHasIndividualRedraws;
	local tCycleId;
	function VUHDO_deferRedrawAllPanels(anIsFixAllFrameLevels)

		if InCombatLockdown() then
			VUHDO_Msg("WARNING: VUHDO_deferRedrawAllPanels called during combat! Stack:\n" .. debugstack(2, 5, 5));
		end

		if sRedrawAllPanelsSemaphore and sRedrawAllPanelsSemaphore["count"] > 0 then
			if sQueuedAllPanelsRequests[anIsFixAllFrameLevels] then
				return;
			end

			tWaitingRequest = {
				["isFixAllFrameLevels"] = anIsFixAllFrameLevels,
				["timestamp"] = GetTime()
			};

			sQueuedAllPanelsRequests[anIsFixAllFrameLevels] = true;
			tinsert(sWaitingAllPanelsRedraws, tWaitingRequest);

			return;
		end

		tHasIndividualRedraws = false;

		for tPanelNum = 1, 10 do
			if sRedrawPanelSemaphores[tPanelNum] and sRedrawPanelSemaphores[tPanelNum]["count"] > 0 then
				tHasIndividualRedraws = true;

				break;
			end
		end

		if tHasIndividualRedraws then
			if sQueuedAllPanelsRequests[anIsFixAllFrameLevels] then
				return;
			end

			tWaitingRequest = {
				["isFixAllFrameLevels"] = anIsFixAllFrameLevels,
				["timestamp"] = GetTime()
			};

			sQueuedAllPanelsRequests[anIsFixAllFrameLevels] = true;
			tinsert(sWaitingAllPanelsRedraws, tWaitingRequest);

			return;
		end

		if sRedrawAllPanelsSemaphore and sRedrawAllPanelsSemaphore["count"] > 0 then
			return;
		end

		tCycleId = VUHDO_generateCycleId();

		VUHDO_invalidatePanelButtonInits();

		VUHDO_resetMacroCaches();
		VUHDO_resetSizeCalcCaches();
		VUHDO_clearBackdropCache();
		twipe(VUHDO_UNIT_BUTTONS);
		twipe(VUHDO_UNIT_BUTTONS_PANEL);

		VUHDO_calculateSemaphoreTimeouts();

		if sRedrawAllPanelsSemaphore and sRedrawAllPanelsSemaphore["count"] > 0 then
			if sQueuedAllPanelsRequests[anIsFixAllFrameLevels] then
				return;
			end

			tWaitingRequest = {
				["isFixAllFrameLevels"] = anIsFixAllFrameLevels,
				["timestamp"] = GetTime()
			};

			sQueuedAllPanelsRequests[anIsFixAllFrameLevels] = true;
			tinsert(sWaitingAllPanelsRedraws, tWaitingRequest);

			return;
		end

		VUHDO_releaseStoredSemaphore(sRedrawAllPanelsSemaphore);

		sRedrawAllPanelsSemaphore = VUHDO_createSemaphore("RedrawAllPanels_" .. tCycleId, 0, 10, sPanelRedrawTimeout);

		if not sRedrawAllPanelsSemaphore then
			return;
		end

		sPanelCompletionTracker = { };

		for tPanelNum = 1, 10 do
			if sWaitingIndividualRedraws[tPanelNum] and #sWaitingIndividualRedraws[tPanelNum] > 0 then
				twipe(sWaitingIndividualRedraws[tPanelNum]);
			end

			if sQueuedIndividualRequests[tPanelNum] then
				twipe(sQueuedIndividualRequests[tPanelNum]);
			end

			if sButtonInitSemaphores[tPanelNum] then
				VUHDO_releaseStoredSemaphore(sButtonInitSemaphores[tPanelNum]);

				sButtonInitSemaphores[tPanelNum] = nil;
			end

			if sButtonPositionSemaphores[tPanelNum] then
				VUHDO_releaseStoredSemaphore(sButtonPositionSemaphores[tPanelNum]);

				sButtonPositionSemaphores[tPanelNum] = nil;
			end
		end

		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			VUHDO_deferRedrawPanel(tPanelNum, anIsFixAllFrameLevels, tCycleId);
		end

		VUHDO_deferRedrawAllPanelsComplete(anIsFixAllFrameLevels);

		return;

	end



	--
	local tPanel;
	local function VUHDO_pcallRedrawPanel(aPanelNum, aCycleId)

		tPanel = VUHDO_getOrCreateActionPanel(aPanelNum);

		VUHDO_initLocalVars(aPanelNum);

		VUHDO_deferInitAllHealButtons(tPanel, aPanelNum, aCycleId);

		if VUHDO_isConfigPanelShowing() then
			VUHDO_deferPositionConfigPanels(aPanelNum);
		else
			VUHDO_deferPositionAllHealButtons(tPanel, aPanelNum, aCycleId);
		end

		return;

	end



	--
	local tRedrawPanelSuccess;
	local tRedrawPanelError;
	function VUHDO_deferRedrawPanelDelegate(aPanelNum, anIsFixAllFrameLevels, aCycleId)

		tRedrawPanelSuccess, tRedrawPanelError = xpcall(VUHDO_pcallRedrawPanel, VUHDO_deferredRedrawErrorHandler, aPanelNum, aCycleId);

		if not tRedrawPanelSuccess then
			VUHDO_Msg("Deferred redraw error: " .. tostring(tRedrawPanelError));
		end

		VUHDO_deferRedrawPanelComplete(aPanelNum, anIsFixAllFrameLevels, aCycleId);

		return;

	end



	--
	local tGcdCol;
	local function VUHDO_pcallRedrawAllPanelsComplete()

		VUHDO_setupAllButtonsUnitWatch(VUHDO_CONFIG["HIDE_EMPTY_BUTTONS"] and not VUHDO_IS_PANEL_CONFIG and not VUHDO_isConfigDemoUsers());
		VUHDO_updateAllRaidBars();
		VUHDO_updateAllCustomDebuffs(true);
		VUHDO_refreshAllUnitAuras();
		VUHDO_rebuildTargets();
		VUHDO_updatePanelVisibility();

		if VUHDO_isShowGcd() then
			tGcdCol = VUHDO_PANEL_SETUP["BAR_COLORS"]["GCD_BAR"];

			VUHDO_setStatusBarVuhDoColor(VuhDoGcdStatusBar, tGcdCol);
			VuhDoGcdStatusBar:SetStatusBarTexture("Interface\\AddOns\\VuhDo\\Images\\white_square_16_16");

			VUHDO_PixelUtil.ApplySettings(VuhDoGcdStatusBar:GetStatusBarTexture());

			VuhDoGcdStatusBar:SetMinMaxValues(0, 1);
			VuhDoGcdStatusBar:SetValue(0);
			VUHDO_PixelUtil.SetFrameStrata(VuhDoGcdStatusBar, "TOOLTIP");
		end

		VUHDO_PixelUtil.Hide(VuhDoGcdStatusBar);

		VUHDO_PixelUtil.ApplySettings(VuhDoDirectionFrameArrow);
		VuhDoDirectionFrameArrow:SetVertexColor(VUHDO_backColor(VUHDO_PANEL_SETUP["BAR_COLORS"]["DIRECTION"]));
		VUHDO_PixelUtil.SetPoint(VuhDoDirectionFrameText, "TOP", "VuhDoDirectionFrameArrow", "CENTER", 5,  -2);
		VuhDoDirectionFrameText:SetText("");
		VUHDO_PixelUtil.SetFrameStrata(VuhDoDirectionFrame, "TOOLTIP");

		VUHDO_initAllEventBouquets();

		VUHDO_updateToggledUnitEvents();

		return;

	end



	--
	local tNextRequest;
	local tRedrawAllPanelsCompleteSuccess;
	local tRedrawAllPanelsCompleteError;
	function VUHDO_deferRedrawAllPanelsCompleteDelegate(anIsFixAllFrameLevels)

		if sRedrawAllPanelsSemaphore and
			not sRedrawAllPanelsSemaphore:waitFor(VUHDO_DEFER_REDRAW_ALL_PANELS_COMPLETE, VUHDO_DEFERRED_TASK_PRIORITY_HIGH, anIsFixAllFrameLevels) then
			return;
		end

		tRedrawAllPanelsCompleteSuccess, tRedrawAllPanelsCompleteError = xpcall(VUHDO_pcallRedrawAllPanelsComplete, VUHDO_deferredRedrawErrorHandler);

		if not tRedrawAllPanelsCompleteSuccess then
			VUHDO_Msg("Deferred redraw error: " .. tostring(tRedrawAllPanelsCompleteError));
		end

		VUHDO_releaseStoredSemaphore(sRedrawAllPanelsSemaphore);

		sRedrawAllPanelsSemaphore = nil;

		for tPanelNum = 1, 10 do
			if sRedrawPanelSemaphores[tPanelNum] then
				VUHDO_releaseStoredSemaphore(sRedrawPanelSemaphores[tPanelNum]);

				sRedrawPanelSemaphores[tPanelNum] = nil;
			end
		end

		if #sWaitingAllPanelsRedraws > 0 then
			tNextRequest = tremove(sWaitingAllPanelsRedraws, 1);

			sQueuedAllPanelsRequests[tNextRequest["isFixAllFrameLevels"]] = nil;

			VUHDO_deferRedrawAllPanels(tNextRequest["isFixAllFrameLevels"]);
		end

		VUHDO_timeRefreshMissingBuffContainers(0.01);

		return;

	end
end