local _;

VUHDO_COMBO_MAX_ENTRIES = 10000;

local floor = floor;
local max = math.max;
local tonumber = tonumber;
local strsub = strsub;
local pairs = pairs;
local format = format;
local GetLocale = GetLocale;
local InCombatLockdown = InCombatLockdown;
local UnitExists = UnitExists;
local hooksecurefunc = hooksecurefunc;
local CreateFrame = CreateFrame;
local tinsert = table.insert;
local twipe = table.wipe;
local pcall = pcall;
local GetClassColor = C_ClassColor and C_ClassColor.GetClassColor;
local CreateColor = CreateColor;
local issecretvalue = issecretvalue;

local VUHDO_IMMEDIATE = Enum.StatusBarInterpolation.Immediate;

local MEMBERS_PER_RAID_GROUP = MEMBERS_PER_RAID_GROUP or 5;

local VUHDO_RAID_TARGET_TEXTURE_ROWS = 4;
local VUHDO_RAID_TARGET_TEXTURE_COLUMNS = 4;

local sIsNotInChina = GetLocale() ~= "zhCN" and GetLocale() ~= "zhTW" and GetLocale() ~= "koKR";
local sCjkFontSize = 12;
local sIsManaBar = { };
local sIsSideBarLeft = { };
local sIsSideBarRight = { };
local sShowPanels;
local sIsHideEmptyAndClickThrough;
local sIsPartyFrameHooked;
local sEmpty = { };
local sParentHooked = { };
local sParentBlocked = { };
local sPendingReparentFrames = { };
local sIsUnregistering = false;
local sCompactUnitFrameHooked = false;
local sCompactPartyOnShowHooked = false;
local sBlizzRestoreNeedsReload = false;
local sFontTestRegion;
local sFontValidationCache = { };
local sPendingAuraHostUpdates = { };

local tEmptyColor = { };

local VUHDO_INDICATOR_CONFIG;

local VUHDO_LibSharedMedia;
local VUHDO_PixelUtil;

local VUHDO_getActionPanelOrStub;
local VUHDO_getPanelButtons;
local VUHDO_getHealthBarText;
local VUHDO_getUnitButtonsSafe;
local VUHDO_isModelInPanel;
local VUHDO_getResolvedTextProvider;
local VUHDO_getAuraAnchorHost;
local VUHDO_getHealthBar;
local VUHDO_getRealParent;
local VUHDO_getStatusbarOrientationString;
local VUHDO_calculateDerivedOrientation;
local VUHDO_setStatusBarOrientation;
local VUHDO_refreshShieldMaskAnchors;
local VUHDO_STATUSBAR_BOTTOM_TO_TOP;

-----------------------------------------------------------------------
--local VUHDO_getNumbersFromString;

local VUHDO_CONFIG = { };
local VUHDO_PANEL_SETUP = { };
local VUHDO_USER_CLASS_COLORS = { };
local VUHDO_ATLAS_TEXTURES = { };
function VUHDO_guiToolboxInitLocalOverrides()

	--VUHDO_getNumbersFromString = _G["VUHDO_getNumbersFromString"];

	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];
	VUHDO_USER_CLASS_COLORS = _G["VUHDO_USER_CLASS_COLORS"];
	VUHDO_ATLAS_TEXTURES = _G["VUHDO_ATLAS_TEXTURES"];
	VUHDO_INDICATOR_CONFIG = _G["VUHDO_INDICATOR_CONFIG"];

	VUHDO_LibSharedMedia = _G["VUHDO_LibSharedMedia"];
	VUHDO_PixelUtil = _G["VUHDO_PixelUtil"];

	VUHDO_getActionPanelOrStub = _G["VUHDO_getActionPanelOrStub"];
	VUHDO_getPanelButtons = _G["VUHDO_getPanelButtons"];
	VUHDO_getHealthBarText = _G["VUHDO_getHealthBarText"];
	VUHDO_getUnitButtonsSafe = _G["VUHDO_getUnitButtonsSafe"];
	VUHDO_isModelInPanel = _G["VUHDO_isModelInPanel"];
	VUHDO_getResolvedTextProvider = _G["VUHDO_getResolvedTextProvider"];
	VUHDO_getAuraAnchorHost = _G["VUHDO_getAuraAnchorHost"];
	VUHDO_getHealthBar = _G["VUHDO_getHealthBar"];
	VUHDO_getRealParent = _G["VUHDO_getRealParent"];
	VUHDO_getStatusbarOrientationString = _G["VUHDO_getStatusbarOrientationString"];
	VUHDO_calculateDerivedOrientation = _G["VUHDO_calculateDerivedOrientation"];
	VUHDO_setStatusBarOrientation = _G["VUHDO_setStatusBarOrientation"];
	VUHDO_refreshShieldMaskAnchors = _G["VUHDO_refreshShieldMaskAnchors"];
	VUHDO_STATUSBAR_BOTTOM_TO_TOP = _G["VUHDO_STATUSBAR_BOTTOM_TO_TOP"];

	for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
		sIsManaBar[tPanelNum] = VUHDO_INDICATOR_CONFIG[tPanelNum]["BOUQUETS"]["MANA_BAR"] ~= "";
		sIsSideBarLeft[tPanelNum] = VUHDO_INDICATOR_CONFIG[tPanelNum]["BOUQUETS"]["SIDE_LEFT"] ~= "";
		sIsSideBarRight[tPanelNum] = VUHDO_INDICATOR_CONFIG[tPanelNum]["BOUQUETS"]["SIDE_RIGHT"] ~= "";
	end

	sShowPanels = VUHDO_CONFIG["SHOW_PANELS"];
	sIsHideEmptyAndClickThrough = VUHDO_CONFIG["HIDE_EMPTY_BUTTONS"]
		and VUHDO_CONFIG["HIDE_EMPTY_PANELS"]
		and VUHDO_CONFIG["LOCK_CLICKS_THROUGH"];

end
------------------------------------------------------------------------



--
function VUHDO_isConfigPanelShowing()
	return VUHDO_IS_PANEL_CONFIG and not VUHDO_CONFIG_SHOW_RAID;
end
local VUHDO_isConfigPanelShowing = VUHDO_isConfigPanelShowing;



--
local tUnit;
local function VUHDO_hasPanelVisibleButtons(aPanelNum)
	if not sShowPanels or not VUHDO_IS_SHOWN_BY_GROUP then
		return false;

	elseif not sIsHideEmptyAndClickThrough or VUHDO_isConfigPanelShowing() or VUHDO_isConfigDemoUsers() then
		return true;

	else
		if VUHDO_isModelInPanel(aPanelNum, 42) and
			((not VUHDO_CONFIG["OMIT_TARGET"] and UnitExists("target")) or (not VUHDO_CONFIG["OMIT_FOCUS"] and UnitExists("focus"))) then
			return true;
		end

		if VUHDO_isModelInPanel(aPanelNum, 82) and UnitExists("target") then
			return true;
		end

		if VUHDO_isModelInPanel(aPanelNum, 83) and UnitExists("focus") then
			return true;
		end

		if VUHDO_isModelInPanel(aPanelNum, 44) then
			for tCnt = 1, 8 do
				if UnitExists("boss" .. tCnt) then
					return true;
				end
			end
		end

		for _, tButton in pairs(VUHDO_getPanelButtons(aPanelNum)) do
			tUnit = tButton:GetAttribute("unit");

			if tUnit and UnitExists(tUnit) then
				return true;
			end
		end

		return false;
	end
end



--
function VUHDO_updatePanelVisibility()
	for tCnt = 1, 10 do -- VUHDO_MAX_PANELS
		if #(VUHDO_PANEL_MODELS[tCnt] or sEmpty) > 0 then
			VUHDO_getActionPanelOrStub(tCnt):SetAlpha(VUHDO_hasPanelVisibleButtons(tCnt) and 1 or 0);
		end
	end
end



--
function VUHDO_mayMoveHealPanels()

	return not InCombatLockdown() and (VUHDO_IS_PANEL_CONFIG or not VUHDO_CONFIG["LOCK_PANELS"]);

end



--
function VUHDO_getComponentPanelNum(aComponent)
	return VUHDO_getNumbersFromString(aComponent:GetName(), 1)[1];
end



--
local tAnchorCoords = {
	TOPLEFT = function(aPanel) return aPanel:GetLeft(), aPanel:GetTop(); end,
	TOP = function(aPanel) return (aPanel:GetRight() + aPanel:GetLeft()) * 0.5, aPanel:GetTop(); end,
	BOTTOM = function(aPanel) return (aPanel:GetRight() + aPanel:GetLeft()) * 0.5, aPanel:GetBottom(); end,
	LEFT = function(aPanel) return aPanel:GetLeft(), (aPanel:GetBottom() + aPanel:GetTop()) * 0.5; end,
	RIGHT = function(aPanel) return aPanel:GetRight(), (aPanel:GetBottom() + aPanel:GetTop()) * 0.5; end,
	TOPRIGHT = function(aPanel) return aPanel:GetRight(), aPanel:GetTop(); end,
	BOTTOMLEFT = function(aPanel) return aPanel:GetLeft(), aPanel:GetBottom(); end,
	BOTTOMRIGHT = function(aPanel) return aPanel:GetRight(), aPanel:GetBottom(); end,
};
function VUHDO_getAnchorCoords(aPanel, anOrientation, aScaleDiff)
	local tX, tY = tAnchorCoords[anOrientation](aPanel);
	return (tX or 0) / aScaleDiff, (tY or 0) / aScaleDiff;
end



--
function VUHDO_isLooseOrderingShowing(aPanelNum)
	return VUHDO_PANEL_SETUP[aPanelNum]["MODEL"]["ordering"] ~= 0 -- VUHDO_ORDERING_STRICT
		and (not VUHDO_IS_PANEL_CONFIG or VUHDO_CONFIG_SHOW_RAID);
end
local VUHDO_isLooseOrderingShowing = VUHDO_isLooseOrderingShowing;



--
function VUHDO_isTableHeadersShowing(aPanelNum)
	return not VUHDO_isLooseOrderingShowing(aPanelNum)
		and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showHeaders"]
		and not VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["alignBottom"];
end



--
function VUHDO_isTableFootersShowing(aPanelNum)
	return not VUHDO_isLooseOrderingShowing(aPanelNum)
		and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showHeaders"]
		and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["alignBottom"];
end



--
function VUHDO_isTableHeaderOrFooter(aPanelNum)
	return not VUHDO_isLooseOrderingShowing(aPanelNum)
		and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["showHeaders"];
end



--
function VUHDO_getColoredString(aString, aColor)
	if aColor["useText"] then
		return format("|cff%02x%02x%02x%s|r", aColor["TR"] * 255, aColor["TG"] * 255, aColor["TB"] * 255, aString);
	else
		return aString;
	end
end


--
function VUHDO_toggleMenu(aPanel)
	aPanel:SetShown(not aPanel:IsShown());
end



--
function VUHDO_getPanelNum(aPanel)
	return tonumber(strsub(aPanel:GetName(), -2)) or tonumber(strsub(aPanel:GetName(), -1)) or 1;
end



--
local tColorMixin;
function VUHDO_getBlizzardClassColorMixin(aClassFile)

	if not aClassFile or not GetClassColor then
		return nil;
	end

	tColorMixin = GetClassColor(aClassFile);

	if not tColorMixin then
		return nil;
	end

	if tColorMixin.GetRGBA then
		return tColorMixin;
	end

	if tColorMixin["r"] and tColorMixin["g"] and tColorMixin["b"] then
		return CreateColor(tColorMixin["r"], tColorMixin["g"], tColorMixin["b"], tColorMixin["a"] or 1);
	end

	return nil;

end



--
function VUHDO_getClassColor(anInfo)

	if not VUHDO_USER_CLASS_COLORS then
		VUHDO_initClassColors();
	end

	if VUHDO_USER_CLASS_COLORS and VUHDO_USER_CLASS_COLORS[anInfo["classId"]] then
		return VUHDO_USER_CLASS_COLORS[anInfo["classId"]];
	elseif anInfo["hasSecretClass"] then
		return anInfo["blizzardClassColor"];
	else
		return nil;
	end

end



--
function VUHDO_getClassColorByModelId(aModelId)

	if not VUHDO_USER_CLASS_COLORS then
		VUHDO_initClassColors();
	end

	if VUHDO_USER_CLASS_COLORS and VUHDO_USER_CLASS_COLORS[aModelId] then
		return VUHDO_USER_CLASS_COLORS[aModelId];
	else
		return nil;
	end

end



--
function VUHDO_getManaBarHeight(aPanelNum)

	return sIsManaBar[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["manaBarHeight"] or 0;

end
local VUHDO_getManaBarHeight = VUHDO_getManaBarHeight;



--
function VUHDO_getHealthBarHeight(aPanelNum)

	return max(0, VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["barHeight"] - VUHDO_getManaBarHeight(aPanelNum));

end



--
function VUHDO_getSideBarWidthLeft(aPanelNum)

	return sIsSideBarLeft[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["sideLeftWidth"] or 0;

end



--
function VUHDO_getSideBarWidthRight(aPanelNum)

	return sIsSideBarRight[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["sideRightWidth"] or 0;

end



--
function VUHDO_getHealthBarWidth(aPanelNum)

	return max(0, VUHDO_PANEL_SETUP[aPanelNum]["SCALING"]["barWidth"] - VUHDO_getSideBarWidthLeft(aPanelNum) - VUHDO_getSideBarWidthRight(aPanelNum));

end



--
function VUHDO_getDiffColor(aBaseColor, aModColor)
	if aModColor["useText"] then
		aBaseColor["useText"] = true;
		aBaseColor["TR"], aBaseColor["TG"], aBaseColor["TB"], aBaseColor["TO"]
			= aModColor["TR"], aModColor["TG"], aModColor["TB"], aModColor["TO"];
	end

	if aModColor["useBackground"] then
		aBaseColor["useBackground"] = true;
		aBaseColor["R"], aBaseColor["G"], aBaseColor["B"] = aModColor["R"], aModColor["G"], aModColor["B"];
	end

	if aModColor["useOpacity"] then
		aBaseColor["useOpacity"] = true;
		aBaseColor["O"], aBaseColor["TO"] = aModColor["O"], aModColor["TO"];
	end

	if aModColor["useClassColor"] then
		aBaseColor["useClassColor"] = true;
	end

	return aBaseColor;
end



--
function VUHDO_brightenTextColor(aColor, aSummand)
	aColor["TR"], aColor["TG"], aColor["TB"]
		= aColor["TR"] + aSummand, aColor["TG"] + aSummand, aColor["TB"] + aSummand;
	return aColor;
end



-- Bitmap ist 256*256 pixel mit 16 (4*4) Icons (je 64*64 pixel)
local tLeft, tTop;
function VUHDO_getRaidTargetIconTexture(anIndex)
	anIndex = anIndex - 1;
	tLeft = anIndex % 4 * 0.25;
	tTop = floor(anIndex * 0.25) * 0.25;
	return tLeft, tLeft + 0.25, tTop, tTop + 0.25;
end



--
function VUHDO_setRaidTargetIconTexture(aTexture, anIndex)

	if anIndex then
		aTexture:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons");
		aTexture:SetSpriteSheetCell(anIndex, VUHDO_RAID_TARGET_TEXTURE_ROWS, VUHDO_RAID_TARGET_TEXTURE_COLUMNS);
	end

	return;

end



--
local tIsValid;
function VUHDO_isValidFontPath(aFontPath)

	if (aFontPath or "") == "" then
		return false;
	end

	tIsValid = sFontValidationCache[aFontPath];

	if tIsValid ~= nil then
		return tIsValid;
	end

	if not sFontTestRegion then
		sFontTestRegion = UIParent:CreateFontString(nil, "BACKGROUND");
	end

	tIsValid = pcall(sFontTestRegion.SetFont, sFontTestRegion, aFontPath, 10, "");

	sFontValidationCache[aFontPath] = tIsValid;

	return tIsValid;

end



--
function VUHDO_getSafeFontPath(aFontPath)

	if VUHDO_isValidFontPath(aFontPath) then
		return aFontPath;
	end

	return GameFontNormal:GetFont();

end



-- Liefert sicheren Fontnamen. Falls in LSM nicht (mehr) vorhanden oder
function VUHDO_getFont(aFont)

	if (aFont or "") ~= "" then
		for _, tFontInfo in pairs(VUHDO_FONTS) do
			if aFont == tFontInfo[1] then
				return VUHDO_getSafeFontPath(aFont);
			end
		end
	end

	return GameFontNormal:GetFont();

end



--
local VUHDO_BLIZZ_EVENTS = {
	"CVAR_UPDATE",
	"DISPLAY_SIZE_CHANGED",
	"GROUP_ROSTER_UPDATE",
	"IGNORELIST_UPDATE",
	"INCOMING_RESURRECT_CHANGED",
	"INSTANCE_ENCOUNTER_ENGAGE_UNIT",
	"MUTELIST_UPDATE",
	"PARTY_LEADER_CHANGED",
	"PARTY_LFG_RESTRICTED",
	"PARTY_LOOT_METHOD_CHANGED",
	"PARTY_MEMBER_DISABLE",
	"PARTY_MEMBER_ENABLE",
	"PLAYER_ENTER_COMBAT",
	"PLAYER_LEAVE_COMBAT",
	"PLAYER_ENTERING_WORLD",
	"PLAYER_FLAGS_CHANGED",
	"PLAYER_FOCUS_CHANGED",
	"PLAYER_LOGIN",
	"PLAYER_ROLES_ASSIGNED",
	"PLAYER_SPECIALIZATION_CHANGED", 
	"PLAYER_TARGET_CHANGED",
	"PLAYER_UPDATE_RESTING",
	"PLAYTIME_CHANGED",
	"RAID_TARGET_UPDATE",
	"READY_CHECK",
	"READY_CHECK_CONFIRM",
	"READY_CHECK_FINISHED",
	"RUNE_POWER_UPDATE",
	"SPELLS_CHANGED",
	"UI_SCALE_CHANGED",
	"UNIT_AURA",
	"UNIT_CLASSIFICATION_CHANGED",
	"UNIT_CONNECTION",
	"UNIT_COMBAT",
	"UNIT_COMBO_POINTS",
	"UNIT_DISPLAYPOWER",
	"UNIT_ENTERED_VEHICLE",
	"UNIT_ENTERING_VEHICLE",
	"UNIT_EXITED_VEHICLE",
	"UNIT_EXITING_VEHICLE",
	"UNIT_FACTION",
	"UNIT_FLAGS",
	"UNIT_HEAL_PREDICTION",
	"UNIT_HEALTH",
	"UNIT_LEVEL",
	"UNIT_MAXHEALTH",
	"UNIT_MAXPOWER",
	"UNIT_NAME_UPDATE",
	"UNIT_OTHER_PARTY_CHANGED",
	"UNIT_PET",
	"UNIT_PHASE",
	"UNIT_PORTRAIT_UPDATE",
	"UNIT_POWER_UPDATE",
	"UNIT_POWER_BAR_HIDE",
	"UNIT_POWER_BAR_SHOW",
	"UNIT_POWER_FREQUENT",
	"UNIT_TARGETABLE_CHANGED",
	"UNIT_THREAT_SITUATION_UPDATE",
	"UPDATE_ACTIVE_BATTLEFIELD", 
	"UPDATE_INSTANCE_INFO",
	"UPDATE_SHAPESHIFT_FORM",
	"UPDATE_STEALTH",
	"VARIABLES_LOADED",
	"VOICE_START",
	"VOICE_STATUS_UPDATE",
	"VOICE_STOP",
};



--
local VUHDO_FIX_EVENTS = {
	"UNIT_AURA",
	"UNIT_COMBAT",
	"UNIT_HEAL_PREDICTION",
	"UNIT_HEALTH",
	"UNIT_MAXHEALTH",
	"UNIT_MAXPOWER",
	"UNIT_PET",
	"UNIT_POWER_UPDATE",
	"UNIT_POWER_FREQUENT",
	"UNIT_THREAT_SITUATION_UPDATE",
};



--
local sEventsPerFrame = {};
local sFrameHideParents = {};
local sFrameOrigParents = {};



--
local function VUHDO_resetParentToHidden(aFrame, aParent)

	if sIsUnregistering then
		return;
	end

	if sParentBlocked[aFrame] and aParent ~= sFrameHideParents[aFrame] then
		if InCombatLockdown() and aFrame:IsProtected() then
			sPendingReparentFrames[aFrame] = true;
		else
			sIsUnregistering = true;

			aFrame:Hide();
			aFrame:SetParent(sFrameHideParents[aFrame]);

			sIsUnregistering = false;
		end
	end

	return;

end



--
local function VUHDO_onReparentManagerEvent()

	for tFrame in next, sPendingReparentFrames do
		if sParentBlocked[tFrame] and sFrameHideParents[tFrame] then
			tFrame:Hide();
			tFrame:SetParent(sFrameHideParents[tFrame]);
		end
	end

	twipe(sPendingReparentFrames);

	return;

end



--
local sReparentManager = CreateFrame("Frame");
sReparentManager:RegisterEvent("PLAYER_REGEN_ENABLED");
sReparentManager:SetScript("OnEvent", VUHDO_onReparentManagerEvent);



--
local function VUHDO_onCompactUnitFrameUpdateUnitEvents(aFrame)

	if sParentBlocked[aFrame] then
		aFrame:UnregisterAllEvents();
	end

	return;

end



--
local function VUHDO_initCompactUnitFrameHook()

	if sCompactUnitFrameHooked then
		return;
	end

	sCompactUnitFrameHooked = true;

	hooksecurefunc("CompactUnitFrame_UpdateUnitEvents", VUHDO_onCompactUnitFrameUpdateUnitEvents);

	return;

end



--
local function VUHDO_hideFrame(aFrame)

	if not sFrameHideParents[aFrame] then
		local tFrameParent = CreateFrame("Frame");
		tFrameParent:Hide();

		sFrameHideParents[aFrame] = tFrameParent;
	end

	if not sFrameOrigParents[aFrame] then
		sFrameOrigParents[aFrame] = aFrame:GetParent();

		aFrame:Hide();
		aFrame:SetParent(sFrameHideParents[aFrame]);
	end

end



--
local function VUHDO_showFrame(aFrame)

	if sFrameOrigParents[aFrame] then
		sBlizzRestoreNeedsReload = true;
	end

	return;

end



--
local function VUHDO_shouldRestoreBlizzFrameParent(aFrame, anIsShow)

	if anIsShow then
		return true;
	end

	if CompactRaidFrameManager
		and (aFrame == CompactRaidFrameManager or aFrame == CompactRaidFrameManager.container) then
		return false;
	end

	return true;

end



--
local function VUHDO_unregisterAndSaveEvents(_, ...)

	local tFrame;

	for tCnt = 1, select('#', ...) do
		tFrame = select(tCnt, ...);

		if tFrame then
			if not sEventsPerFrame[tFrame] then
				sEventsPerFrame[tFrame] = { };

				for tIndex, tEvent in pairs(VUHDO_BLIZZ_EVENTS) do
					if (tFrame:IsEventRegistered(tEvent)) then
						tinsert(sEventsPerFrame[tFrame], tIndex);
					end
				end

			end

			tFrame:UnregisterAllEvents();

			if not sParentHooked[tFrame] then
				hooksecurefunc(tFrame, "SetParent", VUHDO_resetParentToHidden);

				sParentHooked[tFrame] = true;
			end

			sParentBlocked[tFrame] = true;

			VUHDO_hideFrame(tFrame);
		end
	end

end



--
local function VUHDO_registerOriginalEvents(anIsShow, ...)

	local tFrame;

	for tCnt = 1, select('#', ...) do
		tFrame = select(tCnt, ...);

		if tFrame then
			sParentBlocked[tFrame] = nil;

			if sEventsPerFrame[tFrame] then
				for _, tIndex in pairs(sEventsPerFrame[tFrame]) do
					tFrame:RegisterEvent(VUHDO_BLIZZ_EVENTS[tIndex]);
				end

				for _, tEvent in pairs(VUHDO_FIX_EVENTS) do
					tFrame:RegisterEvent(tEvent);
				end
			else -- must not happen
				tFrame:RegisterAllEvents();
			end

			if VUHDO_shouldRestoreBlizzFrameParent(tFrame, anIsShow) then
				VUHDO_showFrame(tFrame);
			end
		end
	end

end



--
local function VUHDO_onCompactPartyFrameShow(aFrame)

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 3 and not InCombatLockdown() then
		VUHDO_unregisterAndSaveEvents(true, aFrame);
	end

	return;

end



--
local function VUHDO_hideBlizzRaid()

	VUHDO_initCompactUnitFrameHook();
	VUHDO_unregisterAndSaveEvents(true, CompactRaidFrameManager.container);

	return;

end



--
local function VUHDO_showBlizzRaid()

	VUHDO_registerOriginalEvents(VUHDO_GROUP_TYPE_SOLO ~= VUHDO_getCurrentGroupType(), CompactRaidFrameManager.container);

	return;

end



--
local function VUHDO_hideBlizzRaidMgr()

	VUHDO_unregisterAndSaveEvents(true, CompactRaidFrameManager);

	return;

end


--
local function VUHDO_showBlizzRaidMgr()

	VUHDO_registerOriginalEvents(VUHDO_GROUP_TYPE_SOLO ~= VUHDO_getCurrentGroupType(), CompactRaidFrameManager);

	return;

end



--
local function VUHDO_updateBlizzPartyFrames()

	if InCombatLockdown() then
		return;
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 3 then
		_G["PartyFrame"]:HidePartyFrames();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 1 then
		for tPartyMemberFrame in _G["PartyFrame"].PartyMemberFramePool:EnumerateActive() do
			tPartyMemberFrame:Show();
			tPartyMemberFrame:UpdateMember();
		end

		_G["PartyFrame"]:UpdatePartyMemberBackground();
		_G["PartyFrame"]:Layout();
	end

end



--
local tMemberFrame;
local function VUHDO_hideBlizzParty()

	VUHDO_initCompactUnitFrameHook();

	if not EditModeManagerFrame:UseRaidStylePartyFrames() then
		local tPartyFrame = _G["PartyFrame"];

		if not sIsPartyFrameHooked then
			hooksecurefunc(tPartyFrame, "UpdatePartyFrames", VUHDO_updateBlizzPartyFrames);

			sIsPartyFrameHooked = true;
		end

		for tPartyMemberFrame in tPartyFrame.PartyMemberFramePool:EnumerateActive() do
			VUHDO_unregisterAndSaveEvents(false, tPartyMemberFrame, tPartyMemberFrame.HealthBar, tPartyMemberFrame.ManaBar);
		end

		for tCnt = 1, MEMBERS_PER_RAID_GROUP do
			tMemberFrame = _G["CompactPartyFrameMember" .. tCnt];

			if tMemberFrame then
				VUHDO_unregisterAndSaveEvents(false, tMemberFrame);
			end
		end
	else
		if CompactPartyFrame ~= nil then
			if CompactPartyFrame:IsVisible() then
				VUHDO_unregisterAndSaveEvents(true, CompactPartyFrame);
			end

			if not sCompactPartyOnShowHooked then
				CompactPartyFrame:HookScript("OnShow", VUHDO_onCompactPartyFrameShow);

				sCompactPartyOnShowHooked = true;
			end
		end

		for tCnt = 1, MEMBERS_PER_RAID_GROUP do
			tMemberFrame = _G["CompactPartyFrameMember" .. tCnt];

			if tMemberFrame then
				VUHDO_unregisterAndSaveEvents(false, tMemberFrame);
			end
		end
	end

	return;

end



--
local function VUHDO_showBlizzParty()

	if VUHDO_GROUP_TYPE_PARTY ~= VUHDO_getCurrentGroupType() then 
		return;
	end

	if not EditModeManagerFrame:UseRaidStylePartyFrames() then
		local tPartyFrame = _G["PartyFrame"];

		if not sIsPartyFrameHooked then
			hooksecurefunc(tPartyFrame, "UpdatePartyFrames", VUHDO_updateBlizzPartyFrames);

			sIsPartyFrameHooked = true;
		end

		for tPartyMemberFrame in tPartyFrame.PartyMemberFramePool:EnumerateActive() do
			VUHDO_registerOriginalEvents(false, tPartyMemberFrame, tPartyMemberFrame.HealthBar, tPartyMemberFrame.ManaBar);
		end

		for tCnt = 1, MEMBERS_PER_RAID_GROUP do
			tMemberFrame = _G["CompactPartyFrameMember" .. tCnt];

			if tMemberFrame then
				VUHDO_registerOriginalEvents(false, tMemberFrame);
			end
		end
	else
		VUHDO_registerOriginalEvents(true, CompactPartyFrame);

		for tCnt = 1, MEMBERS_PER_RAID_GROUP do
			tMemberFrame = _G["CompactPartyFrameMember" .. tCnt];

			if tMemberFrame then
				VUHDO_registerOriginalEvents(false, tMemberFrame);
			end
		end
	end

	return;

end



--
local function VUHDO_hideBlizzPlayer()

	VUHDO_unregisterAndSaveEvents(true, PlayerFrame, RuneFrame);
	VUHDO_unregisterAndSaveEvents(false, PlayerFrameHealthBar, PlayerFrameManaBar);

end



--
local function VUHDO_showBlizzPlayer()

	VUHDO_registerOriginalEvents(false, PlayerFrame, PlayerFrameHealthBar, PlayerFrameManaBar);

	if "DEATHKNIGHT" == VUHDO_PLAYER_CLASS then
		VUHDO_registerOriginalEvents(true, RuneFrame);
	end

end



--
local function VUHDO_hideBlizzTarget()

	VUHDO_unregisterAndSaveEvents(true, TargetFrame, TargetFrameToT, FocusFrameToT);
	VUHDO_unregisterAndSaveEvents(false, TargetFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, TargetFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);

	ComboFrame:ClearAllPoints();

end



--
local function VUHDO_showBlizzTarget()

	VUHDO_registerOriginalEvents(true, TargetFrame, TargetFrameToT, FocusFrameToT);
	VUHDO_registerOriginalEvents(false, TargetFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, TargetFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);

	VUHDO_PixelUtil.SetPoint(ComboFrame, "TOPRIGHT", "TargetFrame", "TOPRIGHT", -44, -9);

end



--
local function VUHDO_hideBlizzPet()

	VUHDO_unregisterAndSaveEvents(true, PetFrame);

end



--
local function VUHDO_showBlizzPet()

	VUHDO_registerOriginalEvents(true, PetFrame);

end


--
local function VUHDO_hideBlizzFocus()

	VUHDO_unregisterAndSaveEvents(true, FocusFrame);
	VUHDO_unregisterAndSaveEvents(false, FocusFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, FocusFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);

end



--
local function VUHDO_showBlizzFocus()

	VUHDO_registerOriginalEvents(true, FocusFrame);
	VUHDO_registerOriginalEvents(false, FocusFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, FocusFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);

end



--
local function VUHDO_hideBlizzArena()

	if not CompactArenaFrame then
		return;
	end

	VUHDO_initCompactUnitFrameHook();
	VUHDO_unregisterAndSaveEvents(true, CompactArenaFrame);

	for _, tFrame in pairs(CompactArenaFrame.memberUnitFrames or sEmpty) do
		VUHDO_unregisterAndSaveEvents(false, tFrame);
	end

	return;

end



--
local function VUHDO_showBlizzArena()

	if not CompactArenaFrame then
		return;
	end

	VUHDO_registerOriginalEvents(true, CompactArenaFrame);

	for _, tFrame in pairs(CompactArenaFrame.memberUnitFrames or sEmpty) do
		VUHDO_registerOriginalEvents(false, tFrame);
	end

	return;

end



--
local tBossFrame;
local tBossFrameName;
local function VUHDO_hideBlizzBoss()

	VUHDO_unregisterAndSaveEvents(true, BossTargetFrameContainer);

	for tCnt = 1, MAX_BOSS_FRAMES do
		tBossFrameName = "Boss" .. tCnt .. "TargetFrame";
		tBossFrame = _G[tBossFrameName];

		if tBossFrame then
			if tBossFrame.TargetFrameContent then
				if tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBarsContainer then
					VUHDO_unregisterAndSaveEvents(false, tBossFrame, tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBarsContainer.HealthBar, tBossFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);
				else
					VUHDO_unregisterAndSaveEvents(false, tBossFrame, tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, tBossFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);
				end
			else
				VUHDO_unregisterAndSaveEvents(false, tBossFrame, _G[tBossFrameName .. "HealthBar"], _G[tBossFrameName .. "ManaBar"]);
			end
		end
	end

	return;

end



--
local tBossFrame;
local tBossFrameName;
local function VUHDO_showBlizzBoss()

	VUHDO_registerOriginalEvents(true, BossTargetFrameContainer);

	for tCnt = 1, MAX_BOSS_FRAMES do
		tBossFrameName = "Boss" .. tCnt .. "TargetFrame";
		tBossFrame = _G[tBossFrameName];

		if tBossFrame then
			if tBossFrame.TargetFrameContent then
				if tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBarsContainer then
					VUHDO_registerOriginalEvents(false, tBossFrame, tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBarsContainer.HealthBar, tBossFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);
				else
					VUHDO_registerOriginalEvents(false, tBossFrame, tBossFrame.TargetFrameContent.TargetFrameContentMain.HealthBar, tBossFrame.TargetFrameContent.TargetFrameContentMain.ManaBar);
				end
			else
				VUHDO_registerOriginalEvents(false, tBossFrame, _G[tBossFrameName .. "HealthBar"], _G[tBossFrameName .. "ManaBar"]);
			end
		end
	end

	return;

end



--
function VUHDO_initHideBlizzRaid()

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID"] == 3 then
		VUHDO_hideBlizzRaid();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID_MGR"] == 3 then
		VUHDO_hideBlizzRaidMgr();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 3 then
		VUHDO_hideBlizzParty();
	end

end


--
function VUHDO_initBlizzFrames()

	if InCombatLockdown() then
		return;
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PLAYER"] == 3 then
		VUHDO_hideBlizzPlayer();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_PLAYER"] == 1 then
		VUHDO_showBlizzPlayer();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_TARGET"] == 3 then
		VUHDO_hideBlizzTarget();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_TARGET"] == 1 then
		VUHDO_showBlizzTarget();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PET"] == 3 then
		VUHDO_hideBlizzPet();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_PET"] == 1 then
		VUHDO_showBlizzPet();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_FOCUS"] == 3 then
		VUHDO_hideBlizzFocus();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_FOCUS"] == 1 then
		VUHDO_showBlizzFocus(); 
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID"] == 3 then
		VUHDO_hideBlizzRaid();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID"] == 1 then
		VUHDO_showBlizzRaid();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID_MGR"] == 3 then
		VUHDO_hideBlizzRaidMgr();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_RAID_MGR"] == 1 then
		VUHDO_showBlizzRaidMgr();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 3 then
		VUHDO_hideBlizzParty();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_PARTY"] == 1 then
		VUHDO_showBlizzParty();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_BOSS"] == 3 then
		VUHDO_hideBlizzBoss();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_BOSS"] == 1 then
		VUHDO_showBlizzBoss();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_ARENA"] == 3 then
		VUHDO_hideBlizzArena();
	elseif VUHDO_CONFIG["BLIZZ_UI_HIDE_ARENA"] == 1 then
		VUHDO_showBlizzArena();
	end

	if sBlizzRestoreNeedsReload then
		sBlizzRestoreNeedsReload = false;

		VUHDO_Msg(VUHDO_I18N_BLIZZ_RESTORE_RELOAD);
	end

	return;

end



function VUHDO_initHideBlizzFrames()

	if InCombatLockdown() then
		return;
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PLAYER"] == 3 then
		VUHDO_hideBlizzPlayer();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_TARGET"] == 3 then
		VUHDO_hideBlizzTarget();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_PET"] == 3 then
		VUHDO_hideBlizzPet();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_FOCUS"] == 3 then
		VUHDO_hideBlizzFocus();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_BOSS"] == 3 then
		VUHDO_hideBlizzBoss();
	end

	if VUHDO_CONFIG["BLIZZ_UI_HIDE_ARENA"] == 3 then
		VUHDO_hideBlizzArena();
	end

	VUHDO_initHideBlizzRaid();

end



--
local tOldX, tOldY;
function VUHDO_isDifferentButtonPoint(aRegion, aPointX, aPointY)
	_, _, _, tOldX, tOldY	= aRegion:GetPoint();
	if tOldX then
		tOldX = floor(tOldX + 0.5);
		tOldY = floor(tOldY + 0.5);
	end
	return aPointX ~= tOldX or aPointY ~= tOldY;
end



--
local tLabel;
local tFontFlags;
function VUHDO_lnfPatchFont(aComponent, aLabelName)

	if not sIsNotInChina then
		tLabel = _G[aComponent:GetName() .. aLabelName];

		_, _, tFontFlags = tLabel:GetFont();

		tLabel:SetFont(VUHDO_getSafeFontPath(VUHDO_OPTIONS_FONT_NAME), sCjkFontSize, tFontFlags or "");
	end

	return;

end



--
function VUHDO_isConfigDemoUsers()
	return VUHDO_IS_PANEL_CONFIG and VUHDO_CONFIG_SHOW_RAID and VUHDO_CONFIG_TEST_USERS > 0;
end



--
local tFile;
function VUHDO_setLlcStatusBarTexture(aStatusBar, aTextureName)
	tFile = VUHDO_LibSharedMedia:Fetch('statusbar', aTextureName);
	if tFile then
		aStatusBar:SetStatusBarTexture(tFile);
		VUHDO_PixelUtil.ApplySettings(aStatusBar:GetStatusBarTexture());
	end
end



--
local tIsAtlas;
function VUHDO_setTextureOrAtlas(aTexture, anIcon, aClipL, aClipR, aClipT, aClipB)

	if not aTexture or not anIcon then
		return false;
	end

	tIsAtlas = not issecretvalue(anIcon) and VUHDO_ATLAS_TEXTURES[anIcon] and true or false;

	if tIsAtlas then
		aTexture:SetAtlas(anIcon);
		aTexture:SetTexCoord(0, 1, 0, 1);
	else
		aTexture:SetTexture(anIcon);
		aTexture:SetTexCoord(aClipL or 0, aClipR or 1, aClipT or 0, aClipB or 1);
	end

	return tIsAtlas;

end



--
local tSourceTexture;
local tSourceFile;
local tSourceAtlas;
function VUHDO_copyStatusBarFillTexture(aDestTexture, aSourceBar)

	if "StatusBar" ~= aSourceBar:GetObjectType() then
		return;
	end

	tSourceTexture = aSourceBar:GetStatusBarTexture();

	if not tSourceTexture then
		return;
	end

	tSourceAtlas = tSourceTexture:GetAtlas();

	if tSourceAtlas then
		aDestTexture:SetAtlas(tSourceAtlas);
	else
		tSourceFile = tSourceTexture:GetTexture();

		if not tSourceFile then
			return;
		end

		aDestTexture:SetTexture(tSourceFile, "CLAMP", "CLAMP", "NEAREST");
	end

	aDestTexture:SetTexCoord(tSourceTexture:GetTexCoord());

	VUHDO_PixelUtil.ApplySettings(aDestTexture);

	return true;

end



--
local tOurLevel;
function VUHDO_fixFrameLevels(anIsForceUpdateChildren, aFrame, aBaseLevel, ...)

	local tCnt = 1;
	local tChild = select(tCnt, ...);

	VUHDO_PixelUtil.SetFrameLevel(aFrame, aBaseLevel);

	while tChild do -- Layer components seem to have no name, important for HoT icons.
		if tChild:CanBeAccessedInContext() and not tChild:IsForbidden() and tChild:GetName() then
			tOurLevel = tChild["isAlphaChainWrapper"] and aBaseLevel or (aBaseLevel + 1 + (tChild["addLevel"] or 0));

			if not tChild["vfl"] then
				if not VUHDO_isConfigPanelShowing() then
					VUHDO_PixelUtil.SetFrameStrata(tChild, aFrame:GetFrameStrata());
				end

				VUHDO_PixelUtil.SetFrameLevel(tChild, tOurLevel);

				tChild["vfl"] = true;

				VUHDO_fixFrameLevels(anIsForceUpdateChildren, tChild, tOurLevel, tChild:GetChildren());
			elseif(anIsForceUpdateChildren) then
				VUHDO_fixFrameLevels(true, tChild, tOurLevel, tChild:GetChildren());
			end
		end

		tCnt = tCnt + 1;
		tChild = select(tCnt, ...);
	end

	return;

end



--
local tOutline, tShadowAlpha, tColor, tFactor, tFontSize;
function VUHDO_customizeIconText(aParent, aHeight, aLabel, aSetup)

	tFactor = aHeight * 0.01;

	aLabel:ClearAllPoints();
	VUHDO_PixelUtil.SetPoint(aLabel, aSetup["ANCHOR"], aParent, aSetup["ANCHOR"], tFactor * aSetup["X_ADJUST"], -tFactor * aSetup["Y_ADJUST"]);

	tOutline = aSetup["USE_OUTLINE"] and "OUTLINE|" or "";
	tOutline = tOutline .. (aSetup["USE_MONO"] and "OUTLINEMONOCHROME" or ""); -- Bugs out in MoP beta

	tColor = aSetup["COLOR"];

	if tColor then
		tShadowAlpha = aSetup["USE_SHADOW"] and tColor["O"] or 0;

		aLabel:SetTextColor(VUHDO_textColor(tColor));
		aLabel:SetShadowColor(tColor["R"], tColor["G"], tColor["B"], tShadowAlpha);
	else
		tShadowAlpha = aSetup["USE_SHADOW"] and 1 or 0;

		aLabel:SetTextColor(1, 1, 1, 1);
		aLabel:SetShadowColor(0, 0, 0, tShadowAlpha);
	end

	tFontSize = max(1, tFactor * (aSetup["SCALE"] or 100));
	aLabel:SetFont(VUHDO_getSafeFontPath(aSetup["FONT"]), tFontSize, tOutline or "");

	aLabel:SetShadowOffset(1, -1);

	aLabel:SetText("");

	return;

end



--
local tTargetButton;
local tFocusButton;
local tUnit;
local tUnitWatchType;
local tIsWatched;
function VUHDO_setupAllButtonsUnitWatch(anIsEnabled)

	if InCombatLockdown() then
		return;
	end

	if anIsEnabled then
		for tPanelNum = 1, 10 do -- VUHDO_MAX_PANELS
			if VUHDO_PANEL_MODELS[tPanelNum] then
				tTargetButton = _G["Vd" .. tPanelNum .. "H1Tg"];

				if tTargetButton and not VUHDO_BUTTON_CACHE[tTargetButton] then
					VUHDO_BUTTON_CACHE[tTargetButton] = tPanelNum;
				end

				tFocusButton = _G["Vd" .. tPanelNum .. "H1Tot"];

				if tFocusButton and not VUHDO_BUTTON_CACHE[tFocusButton] then
					VUHDO_BUTTON_CACHE[tFocusButton] = tPanelNum;
				end
			end
		end

		for tButton, tPanelNum in pairs(VUHDO_BUTTON_CACHE) do
			tUnit = tButton:GetAttribute("unit");
			tUnitWatchType = tButton["unitWatchType"];

			if not tUnit then
				tIsWatched = false;
			elseif VUHDO_UNIT_WATCH_TYPE_TARGET == tUnitWatchType then
				tIsWatched = VUHDO_PANEL_SETUP[tPanelNum]["SCALING"]["showTarget"] and true or false;
			elseif VUHDO_UNIT_WATCH_TYPE_TOT == tUnitWatchType then
				tIsWatched = VUHDO_PANEL_SETUP[tPanelNum]["SCALING"]["showTot"] and true or false;
			else
				tIsWatched = true;
			end

			if tIsWatched then
				RegisterUnitWatch(tButton);
			else
				UnregisterUnitWatch(tButton);
			end
		end
	else
		for tButton, _ in pairs(VUHDO_BUTTON_CACHE) do
			UnregisterUnitWatch(tButton);
		end
	end

	return;

end



--
local function VUHDO_clamp(aValue, aMin, aMax)

	return math.min(math.max(aValue, aMin), aMax);

end



--
function VUHDO_clampColor(aR, aG, aB, aO)

	return aR and VUHDO_clamp(aR, 0, 1), aG and VUHDO_clamp(aG, 0, 1), aB and VUHDO_clamp(aB, 0, 1), aO and VUHDO_clamp(aO, 0, 1);

end



--
local tOpacity;
function VUHDO_backColorWithFallback(aColor)
	
	if aColor and aColor["useOpacity"] and aColor["O"] then
		tOpacity = aColor["O"];
	else
		tOpacity = 1;
	end

	if aColor and aColor["useBackground"] and aColor["R"] and aColor["G"] and aColor["B"] then
		return aColor["R"], aColor["G"], aColor["B"], tOpacity;
	else
		return 1, 1, 1, tOpacity;
	end

end



--
function VUHDO_backColor(aColor)
	return aColor["R"], aColor["G"], aColor["B"], aColor["O"];
end



--
function VUHDO_textColor(aColor)
	return aColor["TR"], aColor["TG"], aColor["TB"], aColor["TO"];
end



--
local tCopy = { };
function VUHDO_copyColor(aColor)
	if not aColor then return tEmptyColor; end
	tCopy["R"], tCopy["G"], tCopy["B"], tCopy["O"] = aColor["R"], aColor["G"], aColor["B"], aColor["O"];
	tCopy["TR"], tCopy["TG"], tCopy["TB"], tCopy["TO"] = aColor["TR"], aColor["TG"], aColor["TB"], aColor["TO"];
	tCopy["useBackground"], tCopy["useText"], tCopy["useOpacity"] = aColor["useBackground"], aColor["useText"], aColor["useOpacity"];
	return tCopy;
end



--
function VUHDO_copyColorTo(aSource, aDest)

	if not aSource then
		return aDest;
	end

	aDest["R"], aDest["G"], aDest["B"], aDest["O"] = aSource["R"], aSource["G"], aSource["B"], aSource["O"];
	aDest["TR"], aDest["TG"], aDest["TB"], aDest["TO"] = aSource["TR"], aSource["TG"], aSource["TB"], aSource["TO"];
	aDest["useBackground"], aDest["useText"], aDest["useOpacity"] = aSource["useBackground"], aSource["useText"], aSource["useOpacity"];

	return aDest;

end



--
local tSummand;
function VUHDO_brightenColor(aColor, aFactor)
	if not aColor then return; end
	tSummand = aFactor - 1;
	aColor["R"], aColor["G"], aColor["B"] = (aColor["R"] or 0) + tSummand, (aColor["G"] or 0) + tSummand, (aColor["B"] or 0) + tSummand;
	return aColor;
end



----------------------------------------

local sFlashFrames = { };
local sIsFlashFrame = { };



--
local function VUHDO_isFlashRegionWritable(aRegion)

	return aRegion:CanBeAccessedInContext() and not aRegion:IsForbidden();

end



--
function VUHDO_startThreatMarkTextureFlash(aTexture)

	if not aTexture then
		return;
	end

	VUHDO_UIFrameFlash(aTexture, 0.2, 0.5, 3.2, true, 0, 0);

	return;

end



--
function VUHDO_stopThreatMarkTextureFlash(aTexture)

	if not aTexture then
		return;
	end

	VUHDO_UIFrameFlashStop(aTexture);

	if VUHDO_isFlashRegionWritable(aTexture) then
		aTexture:SetAlpha(1);
	end

	return;

end



--
function VUHDO_UIFrameFlash(aFrame, aFadeInTime, aFadeOutTime, aFlashDuration, anIsShowWhenDone, aFlashInHoldTime, aFlashOutHoldTime)

  if sIsFlashFrame[aFrame] then return; end

  aFrame.fadeInTime = aFadeInTime;
  aFrame.fadeOutTime = aFadeOutTime;
  aFrame.flashDuration = aFlashDuration;
  aFrame.showWhenDone = anIsShowWhenDone;
  aFrame.flashTimer = 0;
  aFrame.flashInHoldTime = aFlashInHoldTime;
  aFrame.flashOutHoldTime = aFlashOutHoldTime;

  sFlashFrames[#sFlashFrames + 1] = aFrame;
  sIsFlashFrame[aFrame] = true;
end



--
local tFrame;
local tIndex;
local tFlashTime;
local tAlpha;
function VUHDO_UIFrameFlash_OnUpdate(aTimeDelta)
	tIndex = #sFlashFrames;

	while sFlashFrames[tIndex] do
	  tFrame = sFlashFrames[tIndex];

	  if not VUHDO_isFlashRegionWritable(tFrame) then
	    VUHDO_UIFrameFlashStop(tFrame);
	  else
	    tFrame.flashTimer = tFrame.flashTimer + aTimeDelta;

	    if tFrame.flashTimer > tFrame.flashDuration and tFrame.flashDuration ~= -1 then
	      VUHDO_UIFrameFlashStop(tFrame);
	    else
	      tFlashTime = tFrame.flashTimer;

	      tFlashTime = tFlashTime
	      	% (tFrame.fadeInTime + tFrame.fadeOutTime + (tFrame.flashInHoldTime or 0) + (tFrame.flashOutHoldTime or 0));

	      if tFlashTime < tFrame.fadeInTime then
	      	tAlpha = tFlashTime / tFrame.fadeInTime;
	      elseif tFlashTime < tFrame.fadeInTime + (tFrame.flashInHoldTime or 0) then
	      	tAlpha = 1;
	      elseif tFlashTime < tFrame.fadeInTime + (tFrame.flashInHoldTime or 0) + tFrame.fadeOutTime then
	      	tAlpha = 1 - ((tFlashTime - tFrame.fadeInTime - (tFrame.flashInHoldTime or 0)) / tFrame.fadeOutTime);
	      else
	      	tAlpha = 0;
	      end

	      tFrame:SetAlpha(tAlpha);
	    end
	  end

	  tIndex = tIndex - 1;
	end
end



--
function VUHDO_UIFrameFlashStop(aFrame)
	if sIsFlashFrame[aFrame] then
		tDeleteItem(sFlashFrames, aFrame);

		if VUHDO_isFlashRegionWritable(aFrame) then
			aFrame:SetAlpha(aFrame.showWhenDone and 1 or 0);
		end

		aFrame.flashTimer = nil;
		sIsFlashFrame[aFrame] = nil;
	end
end



--
local tPanelNum;
local tIndicatorConfig;
local tFontString;
local tAlpha;
function VUHDO_indicatorTextCallback(aBarNum, aUnit, aProviderName, aValue, anIndicatorName, aBouquetName, ...)

	for _, tButton in pairs(VUHDO_getUnitButtonsSafe(aUnit)) do
		tPanelNum = VUHDO_BUTTON_CACHE[tButton];
		tIndicatorConfig = VUHDO_INDICATOR_CONFIG[tPanelNum]["TEXT_INDICATORS"][anIndicatorName];

		if (aBouquetName == nil or VUHDO_INDICATOR_CONFIG[tPanelNum]["BOUQUETS"][anIndicatorName] == aBouquetName)
			and VUHDO_getResolvedTextProvider(tIndicatorConfig["TEXT_PROVIDER_SOURCE"], tIndicatorConfig["TEXT_PROVIDER_FORMAT"]) == aProviderName then
			tFontString = VUHDO_getHealthBarText(tButton, aBarNum);

			if type(aValue) == "string" then
				tAlpha = 0;
			elseif issecretvalue(aValue) then
				tAlpha = 1;
			elseif aValue == 0 then
				tAlpha = 0;
			else
				tAlpha = 1;
			end

			tFontString:SetText(format(...));
			tFontString:SetAlpha(tAlpha);
		end
	end

	return;

end



--
local VUHDO_COLOR_CACHE = { };
local tColorCacheKey;
local tColor;
function VUHDO_getOrCreateCachedColor(aR, aG, aB, aO)

	if not aR or not aG or not aB then
		return;
	end

	tColorCacheKey = aR .. "|" .. aG .. "|" .. aB ..  "|" .. (aO or "");

	if VUHDO_COLOR_CACHE[tColorCacheKey] then
		return VUHDO_COLOR_CACHE[tColorCacheKey];
	else
		tColor = CreateColor(aR, aG, aB, aO);
		VUHDO_COLOR_CACHE[tColorCacheKey] = tColor;

		return tColor;
	end

end



--
function VUHDO_hasManaOffsetBar(aButton)

	return VUHDO_getHealthBar(aButton, VUHDO_BAR_MANA_OFFSET) ~= VuhDoDummyStatusBar;

end



do
	--
	local tHealthBar;
	local tAnchorBase;
	local tManaInset;
	local tManaBar;
	local tAuraHost;
	local tBgBar;
	function VUHDO_layoutStaticHealthBarGeometry(aButton, aPanelNum)

		tHealthBar = VUHDO_getHealthBar(aButton, 1);

		if not tHealthBar then
			return;
		end

		tAnchorBase = VUHDO_getRealParent(tHealthBar);
		tManaInset = aButton["manaBarLayoutHeight"] or 0;

		VUHDO_PixelUtil.ClearAllPoints(tHealthBar);
		VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tAnchorBase, "TOPLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMRIGHT", tAnchorBase, "BOTTOMRIGHT", 0, tManaInset);

		tManaBar = VUHDO_getHealthBar(aButton, 2);

		if tManaBar then
			if tManaInset > 0 then
				VUHDO_PixelUtil.SetHeight(tManaBar, tManaInset);
				VUHDO_PixelUtil.Show(tManaBar);
			else
				VUHDO_PixelUtil.Hide(tManaBar);
			end
		end

		tAuraHost = VUHDO_getAuraAnchorHost(aButton);
		tBgBar = VUHDO_getHealthBar(aButton, 3);

		if tAuraHost and tBgBar then
			VUHDO_PixelUtil.ClearAllPoints(tAuraHost);
			VUHDO_PixelUtil.SetPoint(tAuraHost, "TOPLEFT", tBgBar, "TOPLEFT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tAuraHost, "BOTTOMRIGHT", tBgBar, "BOTTOMRIGHT", 0, tManaInset);
		end

		return;

	end
end



--
local function VUHDO_getHealthBarGeometrySignature(aButton, aPanelNum)

	return format("%d|%d|%s|%s|%s|%d|%d|%d|%d|%s|%s",
		aPanelNum,
		aButton["manaBarLayoutHeight"] or 0,
		VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum),
		tostring(VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"]),
		tostring(VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisHealthLoss"]),
		VUHDO_getSideBarWidthLeft(aPanelNum),
		VUHDO_getSideBarWidthRight(aPanelNum),
		aButton["regularHeight"] or 0,
		VUHDO_CONFIG["SHOW_HEALTH_LOSS_BAR"] and 1 or 0,
		sIsSideBarLeft[aPanelNum] and (VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"]["SIDE_LEFT"] or "") or "",
		sIsSideBarRight[aPanelNum] and (VUHDO_INDICATOR_CONFIG[aPanelNum]["BOUQUETS"]["SIDE_RIGHT"] or "") or "");

end



do
	--
	local sProtectedHealthBarWarned = { };
	local tHealthBar;
	local tLossBar;
	local tManaOffsetBar;
	local tManaOffsetTexture;
	local tLossTexture;
	local tManaBar;
	local tSideBar;
	local tAuraHost;
	local tAnchorBase;
	local tLeftInset;
	local tRightInset;
	local tManaInset;
	local tRegularHeight;
	local tOrientation;
	local tEffectiveOrientation;
	local tTurnAxisHealthLoss;
	local tSignature;
	local tIsHealthLossAnchored;
	local tIsHealthBarProtected;
	function VUHDO_layoutHealthBarGeometry(aButton, aPanelNum, anIsForceLayout)

		if InCombatLockdown() then
			return;
		end

		if not VUHDO_hasManaOffsetBar(aButton) then
			VUHDO_layoutStaticHealthBarGeometry(aButton, aPanelNum);

			return;
		end

		tManaOffsetBar = VUHDO_getHealthBar(aButton, VUHDO_BAR_MANA_OFFSET);

		tSignature = VUHDO_getHealthBarGeometrySignature(aButton, aPanelNum);

		if not anIsForceLayout and aButton["healthBarGeometrySignature"] == tSignature then
			return;
		end

		tHealthBar = VUHDO_getHealthBar(aButton, 1);
		tLossBar = VUHDO_getHealthBar(aButton, 22);

		if not tHealthBar or not tLossBar then
			return;
		end

		tRegularHeight = aButton["regularHeight"];

		if not tRegularHeight then
			return;
		end

		tManaInset = aButton["manaBarLayoutHeight"] or 0;
		tLeftInset = VUHDO_getSideBarWidthLeft(aPanelNum);
		tRightInset = VUHDO_getSideBarWidthRight(aPanelNum);
		tAnchorBase = VUHDO_getRealParent(tHealthBar);

		tManaOffsetBar:SetAlpha(0);
		tManaOffsetBar:EnableMouse(false);
		VUHDO_setStatusBarOrientation(tManaOffsetBar, VUHDO_STATUSBAR_BOTTOM_TO_TOP);
		tManaOffsetBar:SetMinMaxValues(0, tRegularHeight, VUHDO_IMMEDIATE);
		tManaOffsetBar:SetValue(tManaInset, VUHDO_IMMEDIATE);

		VUHDO_PixelUtil.ClearAllPoints(tManaOffsetBar);
		VUHDO_PixelUtil.SetPoint(tManaOffsetBar, "TOPLEFT", tAnchorBase, "TOPLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tManaOffsetBar, "BOTTOMRIGHT", tAnchorBase, "BOTTOMRIGHT", 0, 0);

		tManaOffsetTexture = tManaOffsetBar:GetStatusBarTexture();

		tIsHealthLossAnchored = VUHDO_CONFIG["SHOW_HEALTH_LOSS_BAR"];

		tIsHealthBarProtected = tHealthBar:IsProtected();

		if issecretvalue(tIsHealthBarProtected) then
			tIsHealthBarProtected = false;
		end

		if tIsHealthLossAnchored and tIsHealthBarProtected then
			tIsHealthLossAnchored = false;

			if not sProtectedHealthBarWarned[aButton] then
				sProtectedHealthBarWarned[aButton] = true;
				VUHDO_Msg(format("Health bar on %s is protected; health-loss edge anchors disabled until /reload out of combat.",
					aButton:GetName() or "?"));
			end
		end

		if VUHDO_CONFIG["SHOW_HEALTH_LOSS_BAR"] then
			VUHDO_PixelUtil.ClearAllPoints(tLossBar);
			VUHDO_PixelUtil.SetPoint(tLossBar, "TOPLEFT", tAnchorBase, "TOPLEFT", tLeftInset, 0);
			VUHDO_PixelUtil.SetPoint(tLossBar, "BOTTOMRIGHT", tManaOffsetTexture, "TOPRIGHT", -tRightInset, 0);
			VUHDO_PixelUtil.Show(tLossBar);
		else
			VUHDO_PixelUtil.Hide(tLossBar);
		end

		tTurnAxisHealthLoss = VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["turnAxisHealthLoss"];
		tOrientation = VUHDO_getStatusbarOrientationString("HEALTH_BAR", aPanelNum);
		tEffectiveOrientation = VUHDO_calculateDerivedOrientation(tOrientation, tTurnAxisHealthLoss);
		tEffectiveOrientation = VUHDO_calculateDerivedOrientation(tEffectiveOrientation,
			VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HEALTH_BAR"]["invertGrowth"]);

		VUHDO_PixelUtil.ClearAllPoints(tHealthBar);

		if tIsHealthLossAnchored then
			tLossTexture = tLossBar:GetStatusBarTexture();

			if "HORIZONTAL" == tEffectiveOrientation then
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tAnchorBase, "TOPLEFT", tLeftInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPRIGHT", tLossTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMLEFT", tManaOffsetTexture, "TOPLEFT", tLeftInset, 0);
			elseif "HORIZONTAL_INV" == tEffectiveOrientation then
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPRIGHT", tAnchorBase, "TOPRIGHT", -tRightInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tLossTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMRIGHT", tManaOffsetTexture, "TOPRIGHT", -tRightInset, 0);
			elseif "VERTICAL" == tEffectiveOrientation then
				VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMLEFT", tManaOffsetTexture, "TOPLEFT", tLeftInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMRIGHT", tManaOffsetTexture, "TOPRIGHT", -tRightInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tLossTexture, "BOTTOMLEFT", 0, 0);
			else
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tAnchorBase, "TOPLEFT", tLeftInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPRIGHT", tAnchorBase, "TOPRIGHT", -tRightInset, 0);
				VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMLEFT", tLossTexture, "TOPLEFT", 0, 0);
			end
		else
			VUHDO_PixelUtil.SetPoint(tHealthBar, "TOPLEFT", tAnchorBase, "TOPLEFT", tLeftInset, 0);
			VUHDO_PixelUtil.SetPoint(tHealthBar, "BOTTOMRIGHT", tAnchorBase, "BOTTOMRIGHT", -tRightInset, tManaInset);
		end

		tManaBar = VUHDO_getHealthBar(aButton, 2);

		if tManaBar then
			VUHDO_PixelUtil.ClearAllPoints(tManaBar);
			VUHDO_PixelUtil.SetPoint(tManaBar, "TOPLEFT", tManaOffsetTexture, "TOPLEFT", 0, 0);
			VUHDO_PixelUtil.SetPoint(tManaBar, "BOTTOMRIGHT", tManaOffsetTexture, "BOTTOMRIGHT", 0, 0);
			VUHDO_PixelUtil.Show(tManaBar);

			if tManaInset > 0 then
				tManaBar:SetAlpha(1);
			else
				tManaBar:SetAlpha(0);
			end
		end

		if sIsSideBarLeft[aPanelNum] then
			tSideBar = VUHDO_getHealthBar(aButton, 17);

			if tSideBar then
				VUHDO_PixelUtil.ClearAllPoints(tSideBar);
				VUHDO_PixelUtil.SetPoint(tSideBar, "TOPLEFT", tAnchorBase, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tSideBar, "BOTTOMLEFT", tManaOffsetTexture, "TOPLEFT", 0, 0);
				VUHDO_PixelUtil.SetWidth(tSideBar, tLeftInset);
			end
		end

		if sIsSideBarRight[aPanelNum] then
			tSideBar = VUHDO_getHealthBar(aButton, 18);

			if tSideBar then
				VUHDO_PixelUtil.ClearAllPoints(tSideBar);
				VUHDO_PixelUtil.SetPoint(tSideBar, "TOPRIGHT", tAnchorBase, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetPoint(tSideBar, "BOTTOMRIGHT", tManaOffsetTexture, "TOPRIGHT", 0, 0);
				VUHDO_PixelUtil.SetWidth(tSideBar, tRightInset);
			end
		end

		tAuraHost = VUHDO_getAuraAnchorHost(aButton);

		if tAuraHost then
			VUHDO_PixelUtil.ClearAllPoints(tAuraHost);
			VUHDO_PixelUtil.SetPoint(tAuraHost, "TOPLEFT", tAnchorBase, "TOPLEFT", tLeftInset, 0);
			VUHDO_PixelUtil.SetPoint(tAuraHost, "BOTTOMRIGHT", tManaOffsetTexture, "TOPRIGHT", -tRightInset, 0);
		end

		aButton["healthBarGeometrySignature"] = tSignature;

		VUHDO_refreshShieldMaskAnchors(aButton, aPanelNum);

		return;

	end
end



do
	--
	local tPanelNum;
	local tAuraHost;
	local tBgBar;
	local tManaInset;
	function VUHDO_updateAuraAnchorHost(aButton)

		if InCombatLockdown() then
			if not VUHDO_hasManaOffsetBar(aButton) then
				sPendingAuraHostUpdates[aButton] = true;
			end

			return;
		end

		if VUHDO_hasManaOffsetBar(aButton) then
			tPanelNum = VUHDO_BUTTON_CACHE[aButton];

			if not tPanelNum then
				return;
			end

			VUHDO_layoutHealthBarGeometry(aButton, tPanelNum, true);

			return;
		end

		tAuraHost = VUHDO_getAuraAnchorHost(aButton);

		if not tAuraHost then
			return;
		end

		tBgBar = VUHDO_getHealthBar(aButton, 3);
		tManaInset = aButton["manaBarLayoutHeight"] or 0;

		VUHDO_PixelUtil.ClearAllPoints(tAuraHost);
		VUHDO_PixelUtil.SetPoint(tAuraHost, "TOPLEFT", tBgBar, "TOPLEFT", 0, 0);
		VUHDO_PixelUtil.SetPoint(tAuraHost, "BOTTOMRIGHT", tBgBar, "BOTTOMRIGHT", 0, tManaInset);

		return;

	end



	--
	function VUHDO_processPendingAuraHostUpdates()

		for tButton, _ in pairs(sPendingAuraHostUpdates) do
			VUHDO_updateAuraAnchorHost(tButton);
		end

		twipe(sPendingAuraHostUpdates);

		return;

	end
end