local _;

local table = table;
local tinsert = table.insert;
local tsort = table.sort;
local twipe = table.wipe;
local pairs = pairs;
local ipairs = ipairs;
local strfind = string.find;

local UnitCanAttack = UnitCanAttack;
local GetUnitAuras = C_UnitAuras and C_UnitAuras.GetUnitAuras;
local issecretvalue = issecretvalue;
local GetAuraDispelTypeColor = C_UnitAuras and C_UnitAuras.GetAuraDispelTypeColor;
local InCombatLockdown = InCombatLockdown;

local VUHDO_CONFIG;
local VUHDO_RAID;
local VUHDO_PANEL_SETUP;
local VUHDO_PANEL_MODELS;
local VUHDO_DEFAULT_AURA_GROUPS;
local VUHDO_AURA_GROUP_COLOR_OFF;
local VUHDO_AURA_GROUP_COLOR_DISPEL;
local VUHDO_AURA_GROUP_COLOR_ALL_DISPEL;
local VUHDO_AURA_GROUP_COLOR_CUSTOM;
local VUHDO_UPDATE_DEBUFF;
local VUHDO_UNIT_AURA_LIST_SLOTS;
local VUHDO_AURA_GROUP_TYPE_LIST;
local VUHDO_UNIT_AURA_CACHE;
local VUHDO_AURA_LIST_ENTRY_SPELL;
local VUHDO_AURA_LIST_ENTRY_BOUQUET;
local VUHDO_MAX_PANELS;
local VUHDO_UNIT_AURA_BY_SPELL;
local VUHDO_UNIT_AURA_BOUQUET_ACTIVE;
local VUHDO_DEBUFF_TYPES;
local VUHDO_PLAYER_PURGE_ABILITIES;
local VUHDO_PLAYER_DISPEL_ABILITIES;
local VUHDO_INFERRED_AURA_SYNTHETIC_IDS;
local VUHDO_INFERRED_AURAS;
local VUHDO_BUFF_SETTINGS;
local VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS;
local VUHDO_AURA_NAME_MATCH_SPELL_NAMES;

VUHDO_AURA_GROUP_ACTIVE_NO_COLOR = { };
local VUHDO_AURA_GROUP_ACTIVE_NO_COLOR = VUHDO_AURA_GROUP_ACTIVE_NO_COLOR;

local VUHDO_getDispelCurveForUnit;
local VUHDO_getDispelTextCurveForUnit;
local VUHDO_hasInferredAura;
local VUHDO_createTablePool;
local VUHDO_auraMatchesFilter;
local VUHDO_getAuraGroupEffectiveUnitScope;
local VUHDO_isAuraGroupInScopeForUnit;
local VUHDO_isAuraIgnored;
local VUHDO_isAuraDataRestricted;
local VUHDO_isAuraModeContainers;
local VUHDO_isLegacyMissingBuffBarColor;
local VUHDO_syncAllOverlayUnits;
local VUHDO_buildAuraGroupNativeFilterString;
local VUHDO_auraSourceMatchesFilter;
local VUHDO_invalidateOverlayBuildKeys;
local VUHDO_invalidateNativeAuraSoundScanCache;
local VUHDO_clearNativeAuraSounds;
local VUHDO_initNativeAuraSounds;
local VUHDO_invalidateAuraGroupFilterCache;
local VUHDO_invalidateAuraGroupFilterCacheForGroup;
local VUHDO_rebuildAuraAnchorsForGroups;
local VUHDO_processPendingAuraContainerBuilds;
local VUHDO_timeRebuildAuraGroups;
local VUHDO_updateBouquetsForEvent;
local VUHDO_rebuildDefaultAuraNameSpellIds;
local VUHDO_invalidateBouquetRestrictedModeCache;
local VUHDO_isAuraMatchingGroupFilters;

local sUnitDispellableAuraId = { };
local sUnitAuraCanColorBar = { };
local sUnitAuraColorType = { };
local sUnitAuraCustomColor = { };
local sCanColorBarGroups = { };
local sAnyGlowGroups = false;
local sUnitAuraBarWinner = { };
local sUnitAuraTextWinner = { };
local sUnitAuraGlowWinner = { };
local sUnitAuraGroupActive = { };

local sGlowWinnerSet;

local sAuraColorWinnerPool;
local sCanColorBarGroupPool;
local sAuraGroupActiveColorPool;
local sAuraGlowWinnerPool;

local sFilterResultCache = { };
local sListGroupAnchorIndex = { };
local sDispellableAuraScanDone = { };

local sDirtyAuraGroupIds = { };
local sIsAuraGroupSoundsDirty = false;

local sEmpty = { };

local sDispelColorBuffer = {
	["R"] = 0, ["G"] = 0, ["B"] = 0, ["O"] = 1,
	["TR"] = 0, ["TG"] = 0, ["TB"] = 0, ["TO"] = 1,
	["useBackground"] = true,
	["useText"] = nil,
};

local sGlowColorBuffer = { 0.95, 0.95, 0.32, 1 };



--
local function VUHDO_createAuraColorWinnerDelegate()

	return {
		["colorType"] = nil,
		["customColor"] = nil,
		["dispelAuraId"] = nil,
	};

end



--
local function VUHDO_cleanupAuraColorWinnerDelegate(aWinner)

	aWinner["colorType"] = nil;
	aWinner["customColor"] = nil;
	aWinner["dispelAuraId"] = nil;

	return;

end



--
local function VUHDO_createAuraGlowWinnerDelegate()

	return {
		["groupId"] = nil,
		["style"] = nil,
		["colorType"] = nil,
		["color"] = nil,
		["dispelAuraId"] = nil,
		["glowR"] = nil,
		["glowG"] = nil,
		["glowB"] = nil,
		["glowO"] = nil,
		["glowDispelGeneration"] = nil,
	};

end



--
local function VUHDO_cleanupAuraGlowWinnerDelegate(aWinner)

	aWinner["groupId"] = nil;
	aWinner["style"] = nil;
	aWinner["colorType"] = nil;
	aWinner["color"] = nil;
	aWinner["dispelAuraId"] = nil;
	aWinner["glowR"] = nil;
	aWinner["glowG"] = nil;
	aWinner["glowB"] = nil;
	aWinner["glowO"] = nil;
	aWinner["glowDispelGeneration"] = nil;

	return;

end



--
local function VUHDO_createCanColorBarGroupDelegate()

	return { };

end



--
local function VUHDO_cleanupCanColorBarGroupDelegate(aGroup)

	aGroup["isInferred"] = nil;
	aGroup["inferredType"] = nil;
	aGroup["priority"] = nil;
	aGroup["colorType"] = nil;
	aGroup["customColor"] = nil;
	aGroup["canColorBar"] = nil;
	aGroup["canColorText"] = nil;
	aGroup["canGlowBar"] = nil;
	aGroup["glowBarStyle"] = nil;
	aGroup["glowBarColor"] = nil;
	aGroup["isListGroup"] = nil;
	aGroup["groupId"] = nil;
	aGroup["entries"] = nil;
	aGroup["filter"] = nil;
	aGroup["excludeFilter"] = nil;
	aGroup["dispelCheckFilter"] = nil;
	aGroup["allDispel"] = nil;
	aGroup["isHelpful"] = nil;
	aGroup["bouquetTrackOnly"] = nil;
	aGroup["unitScope"] = nil;
	aGroup["group"] = nil;
	aGroup["hasConditions"] = nil;

	return;

end



--
local function VUHDO_createAuraGroupBouquetColorDelegate()

	return { };

end



--
local function VUHDO_cleanupAuraGroupBouquetColorDelegate(aTable)

	aTable["isAuraGroupBouquetColorPooled"] = nil;
	aTable["R"] = nil;
	aTable["G"] = nil;
	aTable["B"] = nil;
	aTable["O"] = nil;
	aTable["TR"] = nil;
	aTable["TG"] = nil;
	aTable["TB"] = nil;
	aTable["TO"] = nil;
	aTable["useBackground"] = nil;
	aTable["useText"] = nil;

	return;

end



--
local function VUHDO_auraColorsInitLocalOverridesFunctions()

	VUHDO_getDispelCurveForUnit = _G["VUHDO_getDispelCurveForUnit"];
	VUHDO_getDispelTextCurveForUnit = _G["VUHDO_getDispelTextCurveForUnit"];
	VUHDO_hasInferredAura = _G["VUHDO_hasInferredAura"];
	VUHDO_createTablePool = _G["VUHDO_createTablePool"];
	VUHDO_auraMatchesFilter = _G["VUHDO_auraMatchesFilter"];
	VUHDO_getAuraGroupEffectiveUnitScope = _G["VUHDO_getAuraGroupEffectiveUnitScope"];
	VUHDO_isAuraGroupInScopeForUnit = _G["VUHDO_isAuraGroupInScopeForUnit"];
	VUHDO_isAuraIgnored = _G["VUHDO_isAuraIgnored"];
	VUHDO_isAuraDataRestricted = _G["VUHDO_isAuraDataRestricted"];
	VUHDO_isAuraModeContainers = _G["VUHDO_isAuraModeContainers"];
	VUHDO_isLegacyMissingBuffBarColor = _G["VUHDO_isLegacyMissingBuffBarColor"];
	VUHDO_syncAllOverlayUnits = _G["VUHDO_syncAllOverlayUnits"];
	VUHDO_buildAuraGroupNativeFilterString = _G["VUHDO_buildAuraGroupNativeFilterString"];
	VUHDO_auraSourceMatchesFilter = _G["VUHDO_auraSourceMatchesFilter"];
	VUHDO_invalidateOverlayBuildKeys = _G["VUHDO_invalidateOverlayBuildKeys"];
	VUHDO_invalidateNativeAuraSoundScanCache = _G["VUHDO_invalidateNativeAuraSoundScanCache"];
	VUHDO_clearNativeAuraSounds = _G["VUHDO_clearNativeAuraSounds"];
	VUHDO_initNativeAuraSounds = _G["VUHDO_initNativeAuraSounds"];
	VUHDO_invalidateAuraGroupFilterCache = _G["VUHDO_invalidateAuraGroupFilterCache"];
	VUHDO_invalidateAuraGroupFilterCacheForGroup = _G["VUHDO_invalidateAuraGroupFilterCacheForGroup"];
	VUHDO_rebuildAuraAnchorsForGroups = _G["VUHDO_rebuildAuraAnchorsForGroups"];
	VUHDO_processPendingAuraContainerBuilds = _G["VUHDO_processPendingAuraContainerBuilds"];
	VUHDO_timeRebuildAuraGroups = _G["VUHDO_timeRebuildAuraGroups"];
	VUHDO_updateBouquetsForEvent = _G["VUHDO_deferUpdateBouquetsForEvent"];
	VUHDO_invalidateBouquetRestrictedModeCache = _G["VUHDO_invalidateBouquetRestrictedModeCache"];
	VUHDO_rebuildDefaultAuraNameSpellIds = _G["VUHDO_rebuildDefaultAuraNameSpellIds"];
	VUHDO_isAuraMatchingGroupFilters = _G["VUHDO_isAuraMatchingGroupFilters"];

	return;

end



--
function VUHDO_auraColorsInitLocalOverrides()

	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];
	VUHDO_PANEL_MODELS = _G["VUHDO_PANEL_MODELS"];
	VUHDO_DEFAULT_AURA_GROUPS = _G["VUHDO_DEFAULT_AURA_GROUPS"];
	VUHDO_AURA_GROUP_COLOR_OFF = _G["VUHDO_AURA_GROUP_COLOR_OFF"];
	VUHDO_AURA_GROUP_COLOR_DISPEL = _G["VUHDO_AURA_GROUP_COLOR_DISPEL"];
	VUHDO_AURA_GROUP_COLOR_ALL_DISPEL = _G["VUHDO_AURA_GROUP_COLOR_ALL_DISPEL"];
	VUHDO_AURA_GROUP_COLOR_CUSTOM = _G["VUHDO_AURA_GROUP_COLOR_CUSTOM"];
	VUHDO_UPDATE_DEBUFF = _G["VUHDO_UPDATE_DEBUFF"];
	VUHDO_UNIT_AURA_LIST_SLOTS = _G["VUHDO_UNIT_AURA_LIST_SLOTS"];
	VUHDO_AURA_GROUP_TYPE_LIST = _G["VUHDO_AURA_GROUP_TYPE_LIST"];
	VUHDO_UNIT_AURA_CACHE = _G["VUHDO_UNIT_AURA_CACHE"];
	VUHDO_AURA_LIST_ENTRY_SPELL = _G["VUHDO_AURA_LIST_ENTRY_SPELL"];
	VUHDO_AURA_LIST_ENTRY_BOUQUET = _G["VUHDO_AURA_LIST_ENTRY_BOUQUET"];
	VUHDO_MAX_PANELS = _G["VUHDO_MAX_PANELS"];
	VUHDO_UNIT_AURA_BY_SPELL = _G["VUHDO_UNIT_AURA_BY_SPELL"];
	VUHDO_UNIT_AURA_BOUQUET_ACTIVE = _G["VUHDO_UNIT_AURA_BOUQUET_ACTIVE"];
	VUHDO_DEBUFF_TYPES = _G["VUHDO_DEBUFF_TYPES"];
	VUHDO_PLAYER_PURGE_ABILITIES = _G["VUHDO_PLAYER_PURGE_ABILITIES"];
	VUHDO_PLAYER_DISPEL_ABILITIES = _G["VUHDO_PLAYER_DISPEL_ABILITIES"];
	VUHDO_INFERRED_AURA_SYNTHETIC_IDS = _G["VUHDO_INFERRED_AURA_SYNTHETIC_IDS"];
	VUHDO_INFERRED_AURAS = _G["VUHDO_INFERRED_AURAS"];
	VUHDO_BUFF_SETTINGS = _G["VUHDO_BUFF_SETTINGS"];
	VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS = _G["VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS"];
	VUHDO_AURA_NAME_MATCH_SPELL_NAMES = _G["VUHDO_AURA_NAME_MATCH_SPELL_NAMES"];

	VUHDO_auraColorsInitLocalOverridesFunctions();

	sAuraColorWinnerPool = VUHDO_createTablePool("AuraColorWinner", 100, VUHDO_createAuraColorWinnerDelegate, VUHDO_cleanupAuraColorWinnerDelegate);
	sCanColorBarGroupPool = VUHDO_createTablePool("CanColorBarGroup", 50, VUHDO_createCanColorBarGroupDelegate, VUHDO_cleanupCanColorBarGroupDelegate);
	sAuraGroupActiveColorPool = VUHDO_createTablePool("AuraGroupBouquetColor", 120, VUHDO_createAuraGroupBouquetColorDelegate, VUHDO_cleanupAuraGroupBouquetColorDelegate);
	sAuraGlowWinnerPool = VUHDO_createTablePool("AuraGlowWinner", 100, VUHDO_createAuraGlowWinnerDelegate, VUHDO_cleanupAuraGlowWinnerDelegate);

	return;

end



do
	--
	local tEffectiveColorType;
	local tColorBarGroup;
	local function VUHDO_auraGroupHasConditions(aGroup)

		if not aGroup then
			return false;
		end

		if aGroup["matchAnyBooleans"] and next(aGroup["matchAnyBooleans"]) then
			return true;
		end

		if aGroup["matchAnyFilters"] and next(aGroup["matchAnyFilters"]) then
			return true;
		end

		if aGroup["candidateBooleans"] and next(aGroup["candidateBooleans"]) then
			return true;
		end

		if aGroup["maxDurationSeconds"] ~= nil or aGroup["hasDuration"] then
			return true;
		end

		if aGroup["processedAuraType"] then
			return true;
		end

		if aGroup["excludeDispelTypes"] and next(aGroup["excludeDispelTypes"]) then
			return true;
		end

		if aGroup["dispellableOnly"] then
			return true;
		end

		return false;

	end



	--
	local function VUHDO_setCanColorGroupBouquetTrackOnly(aColorBarGroup, aEffectiveColorType, aGroupId, aGroup)

		if aEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF and VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS[aGroupId] and not aGroup["canGlowBar"] then
			aColorBarGroup["bouquetTrackOnly"] = true;
		else
			aColorBarGroup["bouquetTrackOnly"] = nil;
		end

		return;

	end



	--
	local tPanelAnchors;
	local tGroupId;
	local tAnchorRef;
	local function VUHDO_rebuildListGroupAnchorIndex()

		twipe(sListGroupAnchorIndex);

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			if VUHDO_PANEL_MODELS[tPanelNum] then
				tPanelAnchors = VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["AURA_ANCHORS"];

				if tPanelAnchors then
					for tAnchorKey, tAnchorConfig in pairs(tPanelAnchors) do
						if tAnchorConfig["enabled"] ~= false and tAnchorConfig["groupId"] then
							tGroupId = tAnchorConfig["groupId"];

							if not sListGroupAnchorIndex[tGroupId] then
								sListGroupAnchorIndex[tGroupId] = { };
							end

							tAnchorRef = sListGroupAnchorIndex[tGroupId];
							tAnchorRef[#tAnchorRef + 1] = {
								["panelNum"] = tPanelNum,
								["anchorKey"] = tAnchorKey,
							};
						end
					end
				end
			end
		end

		return;

	end



	--
	local tIsTextColorAllowed;
	function VUHDO_rebuildAuraGroupCaches(anIsFilterCacheDirty, anIsAnchorIndexDirty, anIsSoundsDirty)

		if anIsFilterCacheDirty then
			VUHDO_invalidateAuraGroupFilterCache();
		end

		if anIsAnchorIndexDirty then
			VUHDO_rebuildListGroupAnchorIndex();
		end

		VUHDO_rebuildActiveAuraCaches();

		VUHDO_rebuildAuraModeEventFlags();

		if anIsSoundsDirty then
			VUHDO_rebuildSoundEnabledAuraGroups();

			VUHDO_invalidateNativeAuraSoundScanCache();

			if VUHDO_isAuraModeContainers() then
				VUHDO_clearNativeAuraSounds();
				VUHDO_initNativeAuraSounds();
			else
				VUHDO_clearNativeAuraSounds();
			end
		end

		VUHDO_collectBouquetAuraGroupIds();

		for tIdx = 1, #sCanColorBarGroups do
			sCanColorBarGroupPool:release(sCanColorBarGroups[tIdx]);
		end

		twipe(sCanColorBarGroups);

		sAnyGlowGroups = false;

		tIsTextColorAllowed = not VUHDO_isAuraModeContainers();

		for tGroupId, tGroup in pairs(VUHDO_CONFIG["AURA_GROUPS"] or sEmpty) do
			tEffectiveColorType = tGroup["colorType"] or ((tGroup["canColorBar"] or tGroup["canColorText"]) and VUHDO_AURA_GROUP_COLOR_DISPEL or VUHDO_AURA_GROUP_COLOR_OFF);

			if tGroup["enabled"] ~= false and (tEffectiveColorType >= VUHDO_AURA_GROUP_COLOR_DISPEL or
				(tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF and VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS[tGroupId])) then
				if tGroup["isInferred"] then
					tColorBarGroup = sCanColorBarGroupPool:get();

					tColorBarGroup["isInferred"] = true;
					tColorBarGroup["inferredType"] = tGroup["inferredType"];
					tColorBarGroup["priority"] = tGroup["priority"] or 50;
					tColorBarGroup["colorType"] = tGroup["colorType"] or tEffectiveColorType;
					tColorBarGroup["customColor"] = tGroup["customColor"];

					if tGroup["canColorBar"] then
						tColorBarGroup["canColorBar"] = true;
					else
						tColorBarGroup["canColorBar"] = false;
					end

					tColorBarGroup["canColorText"] = (tGroup["canColorText"] and tIsTextColorAllowed) == true;

					if tGroup["canGlowBar"] then
						tColorBarGroup["canGlowBar"] = true;
						tColorBarGroup["glowBarColor"] = tGroup["glowBarColor"];
						tColorBarGroup["glowBarStyle"] = tGroup["glowBarStyle"];

						sAnyGlowGroups = true;
					else
						tColorBarGroup["canGlowBar"] = false;
						tColorBarGroup["glowBarColor"] = nil;
						tColorBarGroup["glowBarStyle"] = nil;
					end

					tColorBarGroup["groupId"] = tGroupId;

					tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

					VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

					tinsert(sCanColorBarGroups, tColorBarGroup);
				else
					tColorBarGroup = sCanColorBarGroupPool:get();

					tColorBarGroup["priority"] = tGroup["priority"] or 50;
					tColorBarGroup["colorType"] = tGroup["colorType"] or tEffectiveColorType;
					tColorBarGroup["customColor"] = tGroup["customColor"];

					if tGroup["canColorBar"] then
						tColorBarGroup["canColorBar"] = true;
					else
						tColorBarGroup["canColorBar"] = false;
					end

					tColorBarGroup["canColorText"] = (tGroup["canColorText"] and tIsTextColorAllowed) == true;

					if tGroup["canGlowBar"] then
						tColorBarGroup["canGlowBar"] = true;
						tColorBarGroup["glowBarColor"] = tGroup["glowBarColor"];
						tColorBarGroup["glowBarStyle"] = tGroup["glowBarStyle"];

						sAnyGlowGroups = true;
					else
						tColorBarGroup["canGlowBar"] = false;
						tColorBarGroup["glowBarColor"] = nil;
						tColorBarGroup["glowBarStyle"] = nil;
					end

					tColorBarGroup["groupId"] = tGroupId;

					if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST then
						tColorBarGroup["isListGroup"] = true;
						tColorBarGroup["groupId"] = tGroupId;
						tColorBarGroup["entries"] = tGroup["entries"];
						tColorBarGroup["isHarmful"] = tGroup["isHarmful"];

						tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

						VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

						tinsert(sCanColorBarGroups, tColorBarGroup);
					else
						tColorBarGroup["filter"] = VUHDO_buildAuraGroupNativeFilterString(tGroup);
						tColorBarGroup["excludeFilter"] = tGroup["excludeFilter"];

						tColorBarGroup["dispelCheckFilter"] = nil;
						tColorBarGroup["allDispel"] = nil;

						if tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
							tColorBarGroup["dispelCheckFilter"] = true;

							tColorBarGroup["isHelpful"] = not strfind(tGroup["filter"], "HARMFUL", 1, true);
						elseif tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
							tColorBarGroup["allDispel"] = true;
							tColorBarGroup["isHelpful"] = not strfind(tGroup["filter"], "HARMFUL", 1, true);
						end

						tColorBarGroup["group"] = tGroup;
						tColorBarGroup["hasConditions"] = VUHDO_auraGroupHasConditions(tGroup);

						tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

						VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

						tinsert(sCanColorBarGroups, tColorBarGroup);
					end
				end
			end
		end

		for tGroupId, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS or sEmpty) do
			if not tGroup["playerClassRequired"] or tGroup["playerClassRequired"] == VUHDO_PLAYER_CLASS then
				tEffectiveColorType = tGroup["colorType"] or ((tGroup["canColorBar"] or tGroup["canColorText"]) and VUHDO_AURA_GROUP_COLOR_DISPEL or VUHDO_AURA_GROUP_COLOR_OFF);

				if not (VUHDO_CONFIG["AURA_GROUPS"] and VUHDO_CONFIG["AURA_GROUPS"][tGroupId]) and tGroup["enabled"] ~= false and not (VUHDO_CONFIG["AURA_GROUP_DISABLED"] and VUHDO_CONFIG["AURA_GROUP_DISABLED"][tGroupId]) and
					not (VUHDO_DEFAULT_AURA_GROUPS[tGroupId] and VUHDO_DEFAULT_AURA_GROUPS[tGroupId]["enabled"] == false) and
					(tEffectiveColorType >= VUHDO_AURA_GROUP_COLOR_DISPEL or (tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_OFF and VUHDO_BOUQUET_TRACKED_AURA_GROUP_IDS[tGroupId])) then
					if tGroup["isInferred"] then
						tColorBarGroup = sCanColorBarGroupPool:get();

						tColorBarGroup["isInferred"] = true;
						tColorBarGroup["inferredType"] = tGroup["inferredType"];
						tColorBarGroup["priority"] = tGroup["priority"] or 50;
						tColorBarGroup["colorType"] = tGroup["colorType"] or tEffectiveColorType;
						tColorBarGroup["customColor"] = tGroup["customColor"];

						if tGroup["canColorBar"] then
							tColorBarGroup["canColorBar"] = true;
						else
							tColorBarGroup["canColorBar"] = false;
						end

						tColorBarGroup["canColorText"] = (tGroup["canColorText"] and tIsTextColorAllowed) == true;

						if tGroup["canGlowBar"] then
							tColorBarGroup["canGlowBar"] = true;

							tColorBarGroup["glowBarColor"] = tGroup["glowBarColor"];
							tColorBarGroup["glowBarStyle"] = tGroup["glowBarStyle"];

							sAnyGlowGroups = true;
						else
							tColorBarGroup["canGlowBar"] = false;

							tColorBarGroup["glowBarColor"] = nil;
							tColorBarGroup["glowBarStyle"] = nil;
						end

						tColorBarGroup["groupId"] = tGroupId;

						tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

						VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

						tinsert(sCanColorBarGroups, tColorBarGroup);
					else
						tColorBarGroup = sCanColorBarGroupPool:get();

						tColorBarGroup["priority"] = tGroup["priority"] or 50;
						tColorBarGroup["colorType"] = tGroup["colorType"] or tEffectiveColorType;
						tColorBarGroup["customColor"] = tGroup["customColor"];

						if tGroup["canColorBar"] then
							tColorBarGroup["canColorBar"] = true;
						else
							tColorBarGroup["canColorBar"] = false;
						end

						tColorBarGroup["canColorText"] = (tGroup["canColorText"] and tIsTextColorAllowed) == true;

						if tGroup["canGlowBar"] then
							tColorBarGroup["canGlowBar"] = true;

							tColorBarGroup["glowBarColor"] = tGroup["glowBarColor"];
							tColorBarGroup["glowBarStyle"] = tGroup["glowBarStyle"];

							sAnyGlowGroups = true;
						else
							tColorBarGroup["canGlowBar"] = false;

							tColorBarGroup["glowBarColor"] = nil;
							tColorBarGroup["glowBarStyle"] = nil;
						end

						if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST then
							tColorBarGroup["isListGroup"] = true;

							tColorBarGroup["groupId"] = tGroupId;
							tColorBarGroup["entries"] = tGroup["entries"];
							tColorBarGroup["isHarmful"] = tGroup["isHarmful"];

							tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

							VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

							tinsert(sCanColorBarGroups, tColorBarGroup);
						else
							tColorBarGroup["filter"] = VUHDO_buildAuraGroupNativeFilterString(tGroup);
							tColorBarGroup["excludeFilter"] = tGroup["excludeFilter"];

							tColorBarGroup["dispelCheckFilter"] = nil;
							tColorBarGroup["allDispel"] = nil;

							if tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_DISPEL then
								tColorBarGroup["dispelCheckFilter"] = true;

								tColorBarGroup["isHelpful"] = not strfind(tGroup["filter"], "HARMFUL", 1, true);
							elseif tEffectiveColorType == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
								tColorBarGroup["allDispel"] = true;
								tColorBarGroup["isHelpful"] = not strfind(tGroup["filter"], "HARMFUL", 1, true);
							end

							tColorBarGroup["groupId"] = tGroupId;

							tColorBarGroup["group"] = tGroup;
							tColorBarGroup["hasConditions"] = VUHDO_auraGroupHasConditions(tGroup);

							tColorBarGroup["unitScope"] = VUHDO_getAuraGroupEffectiveUnitScope(tGroup);

							VUHDO_setCanColorGroupBouquetTrackOnly(tColorBarGroup, tEffectiveColorType, tGroupId, tGroup);

							tinsert(sCanColorBarGroups, tColorBarGroup);
						end
					end
				end
			end
		end

		tsort(sCanColorBarGroups, function(tSortA, tSortB)
			return (tSortA["priority"] or 50) < (tSortB["priority"] or 50);
		end);

		VUHDO_clearDispellableAuraCache(nil);

		if VUHDO_RAID then
			for tUnit, tInfo in pairs(VUHDO_RAID) do
				tInfo["debuff"], tInfo["debuffName"] = VUHDO_determineAura(tUnit);
			end
		end

		VUHDO_invalidateOverlayBuildKeys();

		if VUHDO_isAuraDataRestricted() or VUHDO_isAuraModeContainers() then
			VUHDO_syncAllOverlayUnits(false);
		end

		return;

	end



	--
	function VUHDO_rebuildCanColorBarGroupsCache()

		VUHDO_rebuildAuraGroupCaches(true, true, true);

		return;

	end



	--
	function VUHDO_getCanColorBarGroups()

		return sCanColorBarGroups;

	end
end



--
function VUHDO_markAuraGroupChanged(aGroupId, anIsAnchorsDirty, anIsSoundsDirty)

	if anIsAnchorsDirty and aGroupId then
		sDirtyAuraGroupIds[aGroupId] = true;
	end

	if anIsSoundsDirty then
		sIsAuraGroupSoundsDirty = true;
	end

	VUHDO_timeRebuildAuraGroups(0.3);

	return;

end



--
function VUHDO_applyAuraGroupChanges()

	VUHDO_rebuildDefaultAuraNameSpellIds();

	for tGroupId, _ in pairs(sDirtyAuraGroupIds) do
		VUHDO_invalidateAuraGroupFilterCacheForGroup(tGroupId);
	end

	VUHDO_rebuildAuraGroupCaches(false, false, sIsAuraGroupSoundsDirty);

	VUHDO_invalidateBouquetRestrictedModeCache();

	if next(sDirtyAuraGroupIds) then
		VUHDO_rebuildAuraAnchorsForGroups(sDirtyAuraGroupIds);
	end

	twipe(sDirtyAuraGroupIds);

	sIsAuraGroupSoundsDirty = false;

	VUHDO_processPendingAuraContainerBuilds();

	if not VUHDO_isAuraDataRestricted() then
		for tUnit, _ in pairs(VUHDO_RAID) do
			VUHDO_updateBouquetsForEvent(tUnit, VUHDO_UPDATE_DEBUFF);
		end
	end

	return;

end



do
	--
	local tEntryValue;
	local tAuraInstances;
	local tBouquetActive;
	local tCachedAura;
	local tAuraInstanceId;
	local function VUHDO_isListGroupActiveForUnit(aUnit, aEntries)

		if not aEntries then
			return false;
		end

		for _, tEntry in ipairs(aEntries) do
			if tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL then
				if tEntry["mine"] or tEntry["others"] then
					tEntryValue = tEntry["value"];

					if tEntry["isNameMatch"] and type(tEntryValue) == "number" then
						tEntryValue = VUHDO_AURA_NAME_MATCH_SPELL_NAMES[tEntryValue] or tEntryValue;
					end

					if tEntryValue and VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
						tAuraInstances = VUHDO_UNIT_AURA_BY_SPELL[aUnit][tEntryValue];

						if tAuraInstances then
							for tCnt = 1, #tAuraInstances do
								tAuraInstanceId = tAuraInstances[tCnt];
								tCachedAura = VUHDO_UNIT_AURA_CACHE[aUnit] and VUHDO_UNIT_AURA_CACHE[aUnit][tAuraInstanceId];

								if tCachedAura and VUHDO_auraSourceMatchesFilter(tCachedAura, tEntry) then
									return true;
								end
							end
						end
					end
				end
			elseif tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_BOUQUET then
				tEntryValue = tEntry["value"];

				if tEntryValue then
					tBouquetActive = (VUHDO_UNIT_AURA_BOUQUET_ACTIVE[aUnit] or sEmpty)[tEntryValue];

					if tBouquetActive then
						return true;
					end
				end
			end
		end

		return false;

	end



	--
	local tGlowWinner;
	local tDispelCurve;
	local tDispelColorMixin;
	local function VUHDO_setGlowWinnerIfNeeded(aUnit, aCanColorGroup, aDispelAuraInstanceId)

		if not sGlowWinnerSet and aCanColorGroup["canGlowBar"] then
			tGlowWinner = sUnitAuraGlowWinner[aUnit];

			if not tGlowWinner then
				tGlowWinner = sAuraGlowWinnerPool:get();
				sUnitAuraGlowWinner[aUnit] = tGlowWinner;
			end

			tGlowWinner["groupId"] = aCanColorGroup["groupId"];
			tGlowWinner["style"] = aCanColorGroup["glowBarStyle"] or VUHDO_DEFAULT_AURA_GLOW_STYLE;
			tGlowWinner["colorType"] = aCanColorGroup["colorType"];
			tGlowWinner["color"] = aCanColorGroup["glowBarColor"];
			tGlowWinner["dispelAuraId"] = aDispelAuraInstanceId;
			tGlowWinner["glowR"] = nil;
			tGlowWinner["glowG"] = nil;
			tGlowWinner["glowB"] = nil;
			tGlowWinner["glowO"] = nil;
			tGlowWinner["glowDispelGeneration"] = nil;

			if aDispelAuraInstanceId and (aCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or aCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL) then
				tDispelCurve = VUHDO_getDispelCurveForUnit(aUnit, true);

				if tDispelCurve then
					tDispelColorMixin = GetAuraDispelTypeColor(aUnit, aDispelAuraInstanceId, tDispelCurve);

					if tDispelColorMixin then
						tGlowWinner["glowR"] = tDispelColorMixin.r;
						tGlowWinner["glowG"] = tDispelColorMixin.g;
						tGlowWinner["glowB"] = tDispelColorMixin.b;
						tGlowWinner["glowO"] = tDispelColorMixin.a or 1;
						tGlowWinner["glowDispelGeneration"] = VUHDO_DISPEL_COLOR_GENERATION;
					end
				end
			end

			sGlowWinnerSet = true;
		end

		return;

	end



	--
	local tSubMapForAuraGroup;
	local tPooledAuraGroupColor;
	local tGroupIdForBouquetCache;
	local tDispelCurveForBouquetCache;
	local tDispelTextCurveForBouquetCache;
	local tDispelColorMixinForBouquet;
	local tCustomColorSrcForBouquet;
	local function VUHDO_resetUnitAuraGroupActiveSubtable(aUnit)

		tSubMapForAuraGroup = sUnitAuraGroupActive[aUnit];

		if not tSubMapForAuraGroup then
			sUnitAuraGroupActive[aUnit] = { };

			return;
		end

		for _, tPooledAuraGroupColor in pairs(tSubMapForAuraGroup) do
			if tPooledAuraGroupColor and tPooledAuraGroupColor["isAuraGroupBouquetColorPooled"] then
				sAuraGroupActiveColorPool:release(tPooledAuraGroupColor);
			end
		end

		twipe(tSubMapForAuraGroup);

		return;

	end



	--
	local function VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, aDispelAuraInstanceId)

		tGroupIdForBouquetCache = tCanColorGroup["groupId"];

		if not tGroupIdForBouquetCache then
			return;
		end

		tSubMapForAuraGroup = sUnitAuraGroupActive[aUnit];

		if tSubMapForAuraGroup[tGroupIdForBouquetCache] then
			return;
		end

		if tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_CUSTOM and tCanColorGroup["customColor"] then
			tCustomColorSrcForBouquet = tCanColorGroup["customColor"];

			tPooledAuraGroupColor = sAuraGroupActiveColorPool:get();

			tPooledAuraGroupColor["isAuraGroupBouquetColorPooled"] = true;
			tPooledAuraGroupColor["useBackground"] = tCanColorGroup["canColorBar"] or nil;
			tPooledAuraGroupColor["useText"] = tCanColorGroup["canColorText"] or nil;

			if tPooledAuraGroupColor["useBackground"] then
				tPooledAuraGroupColor["R"] = tCustomColorSrcForBouquet["R"];
				tPooledAuraGroupColor["G"] = tCustomColorSrcForBouquet["G"];
				tPooledAuraGroupColor["B"] = tCustomColorSrcForBouquet["B"];
				tPooledAuraGroupColor["O"] = tCustomColorSrcForBouquet["O"];
			end

			if tPooledAuraGroupColor["useText"] then
				tPooledAuraGroupColor["TR"] = tCustomColorSrcForBouquet["TR"];
				tPooledAuraGroupColor["TG"] = tCustomColorSrcForBouquet["TG"];
				tPooledAuraGroupColor["TB"] = tCustomColorSrcForBouquet["TB"];
				tPooledAuraGroupColor["TO"] = tCustomColorSrcForBouquet["TO"];
			end

			if not tPooledAuraGroupColor["R"] and not tPooledAuraGroupColor["TR"] then
				sAuraGroupActiveColorPool:release(tPooledAuraGroupColor);
			else
				tSubMapForAuraGroup[tGroupIdForBouquetCache] = tPooledAuraGroupColor;
			end
		elseif (tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL) and aDispelAuraInstanceId then
			tPooledAuraGroupColor = sAuraGroupActiveColorPool:get();

			tPooledAuraGroupColor["isAuraGroupBouquetColorPooled"] = true;
			tPooledAuraGroupColor["useBackground"] = tCanColorGroup["canColorBar"] or nil;
			tPooledAuraGroupColor["useText"] = tCanColorGroup["canColorText"] or nil;

			if tPooledAuraGroupColor["useBackground"] then
				tDispelCurveForBouquetCache = VUHDO_getDispelCurveForUnit(aUnit, true);

				if tDispelCurveForBouquetCache then
					tDispelColorMixinForBouquet = GetAuraDispelTypeColor(aUnit, aDispelAuraInstanceId, tDispelCurveForBouquetCache);

					if tDispelColorMixinForBouquet then
						tPooledAuraGroupColor["R"] = tDispelColorMixinForBouquet.r;
						tPooledAuraGroupColor["G"] = tDispelColorMixinForBouquet.g;
						tPooledAuraGroupColor["B"] = tDispelColorMixinForBouquet.b;
						tPooledAuraGroupColor["O"] = tDispelColorMixinForBouquet.a or 1;
					end
				end
			end

			if tPooledAuraGroupColor["useText"] then
				tDispelTextCurveForBouquetCache = VUHDO_getDispelTextCurveForUnit(aUnit, true);

				if tDispelTextCurveForBouquetCache then
					tDispelColorMixinForBouquet = GetAuraDispelTypeColor(aUnit, aDispelAuraInstanceId, tDispelTextCurveForBouquetCache);

					if tDispelColorMixinForBouquet then
						tPooledAuraGroupColor["TR"] = tDispelColorMixinForBouquet.r;
						tPooledAuraGroupColor["TG"] = tDispelColorMixinForBouquet.g;
						tPooledAuraGroupColor["TB"] = tDispelColorMixinForBouquet.b;
						tPooledAuraGroupColor["TO"] = tDispelColorMixinForBouquet.a or 1;
					end
				end
			end

			if not tPooledAuraGroupColor["R"] and not tPooledAuraGroupColor["TR"] then
				sAuraGroupActiveColorPool:release(tPooledAuraGroupColor);
			else
				tSubMapForAuraGroup[tGroupIdForBouquetCache] = tPooledAuraGroupColor;
			end
		end

		return;

	end



	--
	function VUHDO_resetAuraFilterResultCachePerFrame()

		twipe(sFilterResultCache);

		return;

	end



	--
	local tUnitFilterCache;
	local tResult;
	local function VUHDO_getCachedFilteredAuras(aUnit, aFilter)

		tUnitFilterCache = sFilterResultCache[aUnit];

		if not tUnitFilterCache then
			tUnitFilterCache = { };
			sFilterResultCache[aUnit] = tUnitFilterCache;
		end

		if tUnitFilterCache[aFilter] ~= nil then
			return tUnitFilterCache[aFilter];
		end

		tResult = GetUnitAuras(aUnit, aFilter, 40, Enum.UnitAuraSortRule.Default, 1);
		tUnitFilterCache[aFilter] = tResult or false;

		return tUnitFilterCache[aFilter];

	end



	--
	local tBarWinnerSet;
	local tTextWinnerSet;
	local function VUHDO_shouldStopDispellableAuraScan()

		return tBarWinnerSet and tTextWinnerSet and sGlowWinnerSet;

	end



	--
	local tCanColorGroup;
	local tIsGroupActiveForBouquet;
	local tAuras;
	local function VUHDO_tryBouquetTrackOnlyForDispellableAura(aUnit, tCanColorGroup)

		tIsGroupActiveForBouquet = false;

		if tCanColorGroup["isListGroup"] and tCanColorGroup["entries"] then
			tIsGroupActiveForBouquet = VUHDO_isListGroupActiveForUnit(aUnit, tCanColorGroup["entries"]);
		elseif tCanColorGroup["isInferred"] then
			tIsGroupActiveForBouquet = VUHDO_hasInferredAura(aUnit) and VUHDO_INFERRED_AURAS[aUnit] and VUHDO_INFERRED_AURAS[aUnit][tCanColorGroup["inferredType"]];
		elseif tCanColorGroup["filter"] then
			tAuras = VUHDO_getCachedFilteredAuras(aUnit, tCanColorGroup["filter"]);

			if tAuras then
				for tIdx = 1, #tAuras do
					if tCanColorGroup["hasConditions"] then
						if VUHDO_isAuraMatchingGroupFilters(aUnit, tCanColorGroup["groupId"], tCanColorGroup["group"], tAuras[tIdx]) then
							tIsGroupActiveForBouquet = true;

							break;
						end
					elseif not (tCanColorGroup["excludeFilter"] and VUHDO_auraMatchesFilter(aUnit, tAuras[tIdx]["auraInstanceID"], tCanColorGroup["excludeFilter"]))
						and not VUHDO_isAuraIgnored(tAuras[tIdx], tCanColorGroup["groupId"]) then
						tIsGroupActiveForBouquet = true;

						break;
					end
				end
			end
		end

		if tIsGroupActiveForBouquet then
			sUnitAuraGroupActive[aUnit][tCanColorGroup["groupId"]] = VUHDO_AURA_GROUP_ACTIVE_NO_COLOR;
		end

		return;

	end



	--
	local tWinnerId;
	local tWinnerIdSecret;
	local tWinnerAppTime;
	local tWinnerAuraInstanceId;
	local tIsDispelColorCandidate;
	local tIsHostile;
	local tGroupActive;
	local tPanelNum;
	local tAnchorKey;
	local tAnchorRefs;
	local tAnchorRef;
	local tListSlots;
	local tAuraCache;
	local tAura;
	local tDispelType;
	local tAppTime;
	local tFoundDispelAuraId;
	local tNewWinner;
	local function VUHDO_tryListGroupForDispellableAura(aUnit, tCanColorGroup)

		tWinnerId = nil;
		tWinnerIdSecret = nil;
		tWinnerAppTime = -1;
		tWinnerAuraInstanceId = -1;

		tIsHostile = UnitCanAttack("player", aUnit);

		tGroupActive = false;

		tAnchorRefs = sListGroupAnchorIndex[tCanColorGroup["groupId"]] or sEmpty;

		for tRefIdx = 1, #tAnchorRefs do
			tAnchorRef = tAnchorRefs[tRefIdx];
			tPanelNum = tAnchorRef["panelNum"];
			tAnchorKey = tAnchorRef["anchorKey"];

			tListSlots = (VUHDO_UNIT_AURA_LIST_SLOTS or sEmpty)[aUnit] and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum] and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum][tAnchorKey];

			if tListSlots then
				if tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_CUSTOM then
					for tEntryIndex, tSlotData in pairs(tListSlots) do
						if tSlotData["isActive"] then
							if not sUnitDispellableAuraId[aUnit] then
								sUnitDispellableAuraId[aUnit] = -1;
							end

							tFoundDispelAuraId = nil;

							if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
								tNewWinner = sAuraColorWinnerPool:get();

								tNewWinner["colorType"] = tCanColorGroup["colorType"];
								tNewWinner["customColor"] = tCanColorGroup["customColor"];
								tNewWinner["dispelAuraId"] = nil;

								sUnitAuraBarWinner[aUnit] = tNewWinner;

								tBarWinnerSet = true;
							end

							if not tTextWinnerSet and tCanColorGroup["canColorText"] then
								tNewWinner = sAuraColorWinnerPool:get();

								tNewWinner["colorType"] = tCanColorGroup["colorType"];
								tNewWinner["customColor"] = tCanColorGroup["customColor"];
								tNewWinner["dispelAuraId"] = nil;

								sUnitAuraTextWinner[aUnit] = tNewWinner;

								tTextWinnerSet = true;
							end

							VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, nil);

							tGroupActive = true;

							break;
						end
					end

					if tGroupActive then
						break;
					end
				elseif tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
					for tEntryIndex, tSlotData in pairs(tListSlots) do
						if tSlotData["isActive"] and tSlotData["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL and tSlotData["auraInstanceID"] then
							tAuraCache = VUHDO_UNIT_AURA_CACHE and VUHDO_UNIT_AURA_CACHE[aUnit];

							if tAuraCache then
								tAura = tAuraCache[tSlotData["auraInstanceID"]];

								if tAura and tAura["dispelName"] then
									if tCanColorGroup["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL then
										tIsDispelColorCandidate = (tIsHostile and tAura["isHelpful"]) or (not tIsHostile and tAura["isHarmful"]);
									else
										tDispelType = VUHDO_DEBUFF_TYPES[tAura["dispelName"]];

										tIsDispelColorCandidate = tDispelType and ((tIsHostile and tAura["isHelpful"] and VUHDO_PLAYER_PURGE_ABILITIES[tDispelType]) or
											(not tIsHostile and tAura["isHarmful"] and VUHDO_PLAYER_DISPEL_ABILITIES[tDispelType]));
									end

									if tIsDispelColorCandidate then
										if issecretvalue(tAura["expirationTime"]) or issecretvalue(tAura["duration"]) then
											if tSlotData["auraInstanceID"] > tWinnerAuraInstanceId then
												tWinnerAuraInstanceId = tSlotData["auraInstanceID"];
												tWinnerIdSecret = tSlotData["auraInstanceID"];
											end
										else
											tAppTime = (tAura["expirationTime"] or 0) - (tAura["duration"] or 0);

											if tAppTime > tWinnerAppTime then
												tWinnerAppTime = tAppTime;

												tWinnerId = tSlotData["auraInstanceID"];
											end
										end
									end
								end
							end
						end
					end
				end
			end

			if tGroupActive then
				break;
			end
		end

		if tGroupActive then
			VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, nil);

			if VUHDO_shouldStopDispellableAuraScan() then
				return true;
			end
		elseif tWinnerId or tWinnerIdSecret then
			tWinnerId = tWinnerId or tWinnerIdSecret;

			if not sUnitDispellableAuraId[aUnit] then
				sUnitDispellableAuraId[aUnit] = tWinnerId;
			end

			tFoundDispelAuraId = tWinnerId;

			if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
				tNewWinner = sAuraColorWinnerPool:get();

				tNewWinner["colorType"] = tCanColorGroup["colorType"];
				tNewWinner["customColor"] = tCanColorGroup["customColor"];
				tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

				sUnitAuraBarWinner[aUnit] = tNewWinner;

				tBarWinnerSet = true;
			end

			if not tTextWinnerSet and tCanColorGroup["canColorText"] then
				tNewWinner = sAuraColorWinnerPool:get();

				tNewWinner["colorType"] = tCanColorGroup["colorType"];
				tNewWinner["customColor"] = tCanColorGroup["customColor"];
				tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

				sUnitAuraTextWinner[aUnit] = tNewWinner;

				tTextWinnerSet = true;
			end

			VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, tWinnerId);

			VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, tWinnerId);

			if VUHDO_shouldStopDispellableAuraScan() then
				return true;
			end
		else
			if VUHDO_isListGroupActiveForUnit(aUnit, tCanColorGroup["entries"]) then
				if not sUnitDispellableAuraId[aUnit] then
					sUnitDispellableAuraId[aUnit] = -1;
				end

				if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
					tNewWinner = sAuraColorWinnerPool:get();

					tNewWinner["colorType"] = tCanColorGroup["colorType"];
					tNewWinner["customColor"] = tCanColorGroup["customColor"];
					tNewWinner["dispelAuraId"] = nil;

					sUnitAuraBarWinner[aUnit] = tNewWinner;

					tBarWinnerSet = true;
				end

				if not tTextWinnerSet and tCanColorGroup["canColorText"] then
					tNewWinner = sAuraColorWinnerPool:get();

					tNewWinner["colorType"] = tCanColorGroup["colorType"];
					tNewWinner["customColor"] = tCanColorGroup["customColor"];
					tNewWinner["dispelAuraId"] = nil;

					sUnitAuraTextWinner[aUnit] = tNewWinner;

					tTextWinnerSet = true;
				end

				VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, nil);

				VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, nil);

				if VUHDO_shouldStopDispellableAuraScan() then
					return true;
				end
			end
		end

		return false;

	end



	--
	local tFoundDispelAuraId;
	local tNewWinner;
	local function VUHDO_tryInferredForDispellableAura(aUnit, tCanColorGroup)

		if not sUnitDispellableAuraId[aUnit] then
			sUnitDispellableAuraId[aUnit] = VUHDO_INFERRED_AURA_SYNTHETIC_IDS[tCanColorGroup["inferredType"]] or -1;
		end

		tFoundDispelAuraId = VUHDO_INFERRED_AURA_SYNTHETIC_IDS[tCanColorGroup["inferredType"]] or -1;

		if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
			tNewWinner = sAuraColorWinnerPool:get();

			tNewWinner["colorType"] = tCanColorGroup["colorType"];
			tNewWinner["customColor"] = tCanColorGroup["customColor"];
			tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

			sUnitAuraBarWinner[aUnit] = tNewWinner;

			tBarWinnerSet = true;
		end

		if not tTextWinnerSet and tCanColorGroup["canColorText"] then
			tNewWinner = sAuraColorWinnerPool:get();

			tNewWinner["colorType"] = tCanColorGroup["colorType"];
			tNewWinner["customColor"] = tCanColorGroup["customColor"];
			tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

			sUnitAuraTextWinner[aUnit] = tNewWinner;

			tTextWinnerSet = true;
		end

		VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, tFoundDispelAuraId);

		VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, tFoundDispelAuraId);

		if VUHDO_shouldStopDispellableAuraScan() then
			return true;
		end

		return false;

	end



	--
	local tAuras;
	local tAura;
	local tAuraInstanceId;
	local tFoundDispelAuraId;
	local tNewWinner;
	local function VUHDO_tryDispelColorForDispellableAura(aUnit, tCanColorGroup)

		tIsHostile = UnitCanAttack("player", aUnit);

		tAuras = VUHDO_getCachedFilteredAuras(aUnit, tCanColorGroup["filter"]);

		if tAuras then
			for tIdx = 1, #tAuras do
				tAura = tAuras[tIdx];
				tAuraInstanceId = tAura["auraInstanceID"];

				if not ((tCanColorGroup["excludeFilter"] and VUHDO_auraMatchesFilter(aUnit, tAuraInstanceId, tCanColorGroup["excludeFilter"]))
					or VUHDO_isAuraIgnored(tAura, tCanColorGroup["groupId"])) then
					if (tCanColorGroup["allDispel"] and tAura["dispelName"]) or (not tCanColorGroup["allDispel"] and tCanColorGroup["dispelCheckFilter"] and tAura["dispelName"]) then
						if tCanColorGroup["allDispel"] then
							tIsDispelColorCandidate = true;
						else
							tDispelType = VUHDO_DEBUFF_TYPES[tAura["dispelName"]];

							tIsDispelColorCandidate = tDispelType and ((tIsHostile and tAura["isHelpful"] and VUHDO_PLAYER_PURGE_ABILITIES[tDispelType]) or
								(not tIsHostile and tAura["isHarmful"] and VUHDO_PLAYER_DISPEL_ABILITIES[tDispelType]));
						end

						if tIsDispelColorCandidate then
							if not sUnitDispellableAuraId[aUnit] then
								sUnitDispellableAuraId[aUnit] = tAuraInstanceId;
							end

							tFoundDispelAuraId = tAuraInstanceId;

							if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
								tNewWinner = sAuraColorWinnerPool:get();

								tNewWinner["colorType"] = tCanColorGroup["colorType"];
								tNewWinner["customColor"] = tCanColorGroup["customColor"];
								tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

								sUnitAuraBarWinner[aUnit] = tNewWinner;

								tBarWinnerSet = true;
							end

							if not tTextWinnerSet and tCanColorGroup["canColorText"] then
								tNewWinner = sAuraColorWinnerPool:get();

								tNewWinner["colorType"] = tCanColorGroup["colorType"];
								tNewWinner["customColor"] = tCanColorGroup["customColor"];
								tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

								sUnitAuraTextWinner[aUnit] = tNewWinner;

								tTextWinnerSet = true;
							end

							VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, tFoundDispelAuraId);

							VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, tFoundDispelAuraId);

							if VUHDO_shouldStopDispellableAuraScan() then
								return true;
							end
						end
					end
				end
			end
		end

		return false;

	end



	--
	local tAuras;
	local tAura;
	local tAuraInstanceId;
	local tFoundDispelAuraId;
	local tNewWinner;
	local function VUHDO_trySimpleFilterForDispellableAura(aUnit, tCanColorGroup)

		tAuras = VUHDO_getCachedFilteredAuras(aUnit, tCanColorGroup["filter"]);

		tAura = nil;
		tAuraInstanceId = nil;

		if tAuras then
			for tIdx = 1, #tAuras do
				tAura = tAuras[tIdx];
				tAuraInstanceId = tAura["auraInstanceID"];

				if (tCanColorGroup["excludeFilter"] and VUHDO_auraMatchesFilter(aUnit, tAuraInstanceId, tCanColorGroup["excludeFilter"]))
					or VUHDO_isAuraIgnored(tAura, tCanColorGroup["groupId"]) then
					tAura = nil;
					tAuraInstanceId = nil;
				else
					break;
				end
			end
		end

		if tAura and tAuraInstanceId then
			if not sUnitDispellableAuraId[aUnit] then
				sUnitDispellableAuraId[aUnit] = tAuraInstanceId;
			end

			tFoundDispelAuraId = tAuraInstanceId;

			if not tBarWinnerSet and tCanColorGroup["canColorBar"] then
				tNewWinner = sAuraColorWinnerPool:get();

				tNewWinner["colorType"] = tCanColorGroup["colorType"];
				tNewWinner["customColor"] = tCanColorGroup["customColor"];
				tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

				sUnitAuraBarWinner[aUnit] = tNewWinner;

				tBarWinnerSet = true;
			end

			if not tTextWinnerSet and tCanColorGroup["canColorText"] then
				tNewWinner = sAuraColorWinnerPool:get();

				tNewWinner["colorType"] = tCanColorGroup["colorType"];
				tNewWinner["customColor"] = tCanColorGroup["customColor"];
				tNewWinner["dispelAuraId"] = tFoundDispelAuraId;

				sUnitAuraTextWinner[aUnit] = tNewWinner;

				tTextWinnerSet = true;
			end

			VUHDO_setGlowWinnerIfNeeded(aUnit, tCanColorGroup, tFoundDispelAuraId);

			VUHDO_cacheAuraGroupBouquetColorForUnit(aUnit, tCanColorGroup, tFoundDispelAuraId);

			if VUHDO_shouldStopDispellableAuraScan() then
				return true;
			end
		end

		return false;

	end



	--
	local tBuffConfig;
	local tInfo;
	local tMissingBuffCategory;
	local tMissingColor;
	local function VUHDO_applyMissingBuffColorsForDispellableAura(aUnit)

		if not VUHDO_isLegacyMissingBuffBarColor() then
			return;
		end

		if (not tBarWinnerSet or not tTextWinnerSet) and VUHDO_RAID and VUHDO_RAID[aUnit] and VUHDO_RAID[aUnit]["missbuff"] then
			tBuffConfig = VUHDO_BUFF_SETTINGS["CONFIG"];

			if tBuffConfig and (tBuffConfig["BAR_COLORS_IN_FIGHT"] or not InCombatLockdown()) then
				tInfo = VUHDO_RAID[aUnit];
				tMissingBuffCategory = tInfo["mibucateg"];

				tMissingColor = tMissingBuffCategory and (VUHDO_BUFF_SETTINGS[tMissingBuffCategory] or sEmpty)["missingColor"];

				if tMissingColor then
					if not tBarWinnerSet and tBuffConfig["BAR_COLORS_BACKGROUND"] then
						tNewWinner = sAuraColorWinnerPool:get();

						tNewWinner["colorType"] = VUHDO_AURA_GROUP_COLOR_CUSTOM;
						tNewWinner["customColor"] = tMissingColor;
						tNewWinner["dispelAuraId"] = nil;

						sUnitAuraBarWinner[aUnit] = tNewWinner;

						tBarWinnerSet = true;
					end

					if not tTextWinnerSet and tBuffConfig["BAR_COLORS_TEXT"] then
						tNewWinner = sAuraColorWinnerPool:get();

						tNewWinner["colorType"] = VUHDO_AURA_GROUP_COLOR_CUSTOM;
						tNewWinner["customColor"] = tMissingColor;
						tNewWinner["dispelAuraId"] = nil;

						sUnitAuraTextWinner[aUnit] = tNewWinner;

						tTextWinnerSet = true;
					end
				end
			end
		end

		return;

	end



	--
	function VUHDO_updateDispellableAuraForUnit(aUnit)

		if not aUnit then
			return;
		end

		if sUnitAuraBarWinner[aUnit] then
			sAuraColorWinnerPool:release(sUnitAuraBarWinner[aUnit]);
			sUnitAuraBarWinner[aUnit] = nil;
		end

		if sUnitAuraTextWinner[aUnit] then
			sAuraColorWinnerPool:release(sUnitAuraTextWinner[aUnit]);
			sUnitAuraTextWinner[aUnit] = nil;
		end

		if sUnitAuraGlowWinner[aUnit] then
			sAuraGlowWinnerPool:release(sUnitAuraGlowWinner[aUnit]);
			sUnitAuraGlowWinner[aUnit] = nil;
		end

		sUnitDispellableAuraId[aUnit] = nil;
		sUnitAuraCanColorBar[aUnit] = nil;
		sUnitAuraColorType[aUnit] = nil;
		sUnitAuraCustomColor[aUnit] = nil;

		tBarWinnerSet = false;
		tTextWinnerSet = false;
		sGlowWinnerSet = not sAnyGlowGroups;

		VUHDO_resetUnitAuraGroupActiveSubtable(aUnit);

		if VUHDO_isAuraDataRestricted() then
			return;
		end

		for tCnt = 1, #sCanColorBarGroups do
			tCanColorGroup = sCanColorBarGroups[tCnt];

			if VUHDO_isAuraGroupInScopeForUnit(tCanColorGroup, aUnit) then
				if tCanColorGroup["bouquetTrackOnly"] then
					VUHDO_tryBouquetTrackOnlyForDispellableAura(aUnit, tCanColorGroup);
				elseif tCanColorGroup["isListGroup"] and tCanColorGroup["groupId"] then
					if VUHDO_tryListGroupForDispellableAura(aUnit, tCanColorGroup) then
						return;
					end
				elseif tCanColorGroup["isInferred"] and VUHDO_hasInferredAura(aUnit) and
					VUHDO_INFERRED_AURAS[aUnit] and VUHDO_INFERRED_AURAS[aUnit][tCanColorGroup["inferredType"]] then
					if VUHDO_tryInferredForDispellableAura(aUnit, tCanColorGroup) then
						return;
					end
				elseif tCanColorGroup["allDispel"] and tCanColorGroup["filter"] then
					if (tCanColorGroup["isHelpful"] and UnitCanAttack("player", aUnit))
						or (not tCanColorGroup["isHelpful"] and not UnitCanAttack("player", aUnit)) then
						if VUHDO_tryDispelColorForDispellableAura(aUnit, tCanColorGroup) then
							return;
						end
					end
				elseif tCanColorGroup["dispelCheckFilter"] and ((tCanColorGroup["isHelpful"] and VUHDO_PLAYER_HAS_PURGE and UnitCanAttack("player", aUnit)) or
					(not tCanColorGroup["isHelpful"] and VUHDO_PLAYER_HAS_DISPEL and not UnitCanAttack("player", aUnit))) then
					if VUHDO_tryDispelColorForDispellableAura(aUnit, tCanColorGroup) then
						return;
					end
				elseif not tCanColorGroup["isInferred"] and not tCanColorGroup["dispelCheckFilter"] and not tCanColorGroup["allDispel"] and tCanColorGroup["filter"] then
					if VUHDO_trySimpleFilterForDispellableAura(aUnit, tCanColorGroup) then
						return;
					end
				end
			end
		end

		VUHDO_applyMissingBuffColorsForDispellableAura(aUnit);

		if sUnitAuraBarWinner[aUnit] then
			sUnitAuraColorType[aUnit] = sUnitAuraBarWinner[aUnit]["colorType"];
			sUnitAuraCustomColor[aUnit] = sUnitAuraBarWinner[aUnit]["customColor"];

			sUnitAuraCanColorBar[aUnit] = true;
		elseif sUnitAuraTextWinner[aUnit] then
			sUnitAuraColorType[aUnit] = sUnitAuraTextWinner[aUnit]["colorType"];
			sUnitAuraCustomColor[aUnit] = sUnitAuraTextWinner[aUnit]["customColor"];
		end

		return;

	end



	--
	function VUHDO_getDispellableAuraId(aUnit)

		return sUnitDispellableAuraId[aUnit];

	end



	--
	function VUHDO_hasDispellableAura(aUnit)

		return sUnitDispellableAuraId[aUnit] ~= nil;

	end



	--
	function VUHDO_getAuraCanColorBar(aUnit)

		return sUnitAuraBarWinner[aUnit] ~= nil;

	end



	--
	function VUHDO_getAuraCanColorText(aUnit)

		return sUnitAuraTextWinner[aUnit] ~= nil;

	end



	--
	local tBarWinner;
	function VUHDO_getAuraBarColorType(aUnit)

		tBarWinner = sUnitAuraBarWinner[aUnit];

		if tBarWinner then
			return tBarWinner["colorType"];
		end

		return nil;

	end



	--
	local tTextWinner;
	function VUHDO_getAuraTextColorType(aUnit)

		tTextWinner = sUnitAuraTextWinner[aUnit];

		if tTextWinner then
			return tTextWinner["colorType"];
		end

		return nil;

	end



	--
	local tGlowWinner;
	local tGlowWinnerColor;
	local tDefaultGlow;
	local tDispelCurve;
	local tDispelColorMixin;
	function VUHDO_getAuraGroupGlowInfo(aUnit)

		tGlowWinner = sUnitAuraGlowWinner[aUnit];

		if not tGlowWinner then
			return false, nil, nil;
		end

		if (tGlowWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or tGlowWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL) and tGlowWinner["dispelAuraId"] then
			if tGlowWinner["glowDispelGeneration"] == VUHDO_DISPEL_COLOR_GENERATION and tGlowWinner["glowR"] then
				sGlowColorBuffer[1] = tGlowWinner["glowR"];
				sGlowColorBuffer[2] = tGlowWinner["glowG"];
				sGlowColorBuffer[3] = tGlowWinner["glowB"];
				sGlowColorBuffer[4] = tGlowWinner["glowO"] or 1;

				return true, sGlowColorBuffer, tGlowWinner["style"] or VUHDO_DEFAULT_AURA_GLOW_STYLE;
			end

			tDispelCurve = VUHDO_getDispelCurveForUnit(aUnit, true);

			if tDispelCurve then
				tDispelColorMixin = GetAuraDispelTypeColor(aUnit, tGlowWinner["dispelAuraId"], tDispelCurve);

				if tDispelColorMixin then
					sGlowColorBuffer[1] = tDispelColorMixin.r;
					sGlowColorBuffer[2] = tDispelColorMixin.g;
					sGlowColorBuffer[3] = tDispelColorMixin.b;
					sGlowColorBuffer[4] = tDispelColorMixin.a or 1;

					return true, sGlowColorBuffer, tGlowWinner["style"] or VUHDO_DEFAULT_AURA_GLOW_STYLE;
				end
			end

			return false, nil, nil;
		end

		tGlowWinnerColor = tGlowWinner["color"];

		if tGlowWinnerColor and tGlowWinnerColor["R"] then
			sGlowColorBuffer[1] = tGlowWinnerColor["R"];
			sGlowColorBuffer[2] = tGlowWinnerColor["G"];
			sGlowColorBuffer[3] = tGlowWinnerColor["B"];
			sGlowColorBuffer[4] = tGlowWinnerColor["O"] or 1;
		else
			tDefaultGlow = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["BAR_COLORS"] and VUHDO_PANEL_SETUP["BAR_COLORS"]["DEBUFF_BAR_GLOW"];

			if tDefaultGlow then
				sGlowColorBuffer[1] = tDefaultGlow["R"];
				sGlowColorBuffer[2] = tDefaultGlow["G"];
				sGlowColorBuffer[3] = tDefaultGlow["B"];
				sGlowColorBuffer[4] = tDefaultGlow["O"] or 1;
			else
				sGlowColorBuffer[1] = 0.95;
				sGlowColorBuffer[2] = 0.95;
				sGlowColorBuffer[3] = 0.32;
				sGlowColorBuffer[4] = 1;
			end
		end

		return true, sGlowColorBuffer, tGlowWinner["style"] or VUHDO_DEFAULT_AURA_GLOW_STYLE;

	end



	--
	local tDispelCurve;
	local tDispelColorMixin;
	function VUHDO_getAuraBarColor(aUnit, aDispelCurve)

		tBarWinner = sUnitAuraBarWinner[aUnit];

		if not tBarWinner then
			return nil;
		end

		if tBarWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_CUSTOM then
			return tBarWinner["customColor"];
		end

		if (tBarWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or tBarWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL) and tBarWinner["dispelAuraId"] then
			tDispelCurve = aDispelCurve or VUHDO_getDispelCurveForUnit(aUnit, true);

			if tDispelCurve then
				tDispelColorMixin = GetAuraDispelTypeColor(aUnit, tBarWinner["dispelAuraId"], tDispelCurve);

				if tDispelColorMixin then
					sDispelColorBuffer["R"] = tDispelColorMixin.r;
					sDispelColorBuffer["G"] = tDispelColorMixin.g;
					sDispelColorBuffer["B"] = tDispelColorMixin.b;
					sDispelColorBuffer["O"] = tDispelColorMixin.a or 1;

					sDispelColorBuffer["useBackground"] = true;
					sDispelColorBuffer["useText"] = nil;

					sDispelColorBuffer["TR"] = tDispelColorMixin.r;
					sDispelColorBuffer["TG"] = tDispelColorMixin.g;
					sDispelColorBuffer["TB"] = tDispelColorMixin.b;
					sDispelColorBuffer["TO"] = tDispelColorMixin.a or 1;

					return sDispelColorBuffer;
				end
			end
		end

		return nil;

	end



	--
	local tTextWinner;
	function VUHDO_getAuraTextColor(aUnit, aDispelTextCurve)

		tTextWinner = sUnitAuraTextWinner[aUnit];

		if not tTextWinner then
			return nil;
		end

		if tTextWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_CUSTOM then
			return tTextWinner["customColor"];
		end

		if (tTextWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_DISPEL or tTextWinner["colorType"] == VUHDO_AURA_GROUP_COLOR_ALL_DISPEL) and tTextWinner["dispelAuraId"] then
			tDispelCurve = aDispelTextCurve or VUHDO_getDispelTextCurveForUnit(aUnit, true);

			if tDispelCurve then
				tDispelColorMixin = GetAuraDispelTypeColor(aUnit, tTextWinner["dispelAuraId"], tDispelCurve);

				if tDispelColorMixin then
					sDispelColorBuffer["R"] = tDispelColorMixin.r;
					sDispelColorBuffer["G"] = tDispelColorMixin.g;
					sDispelColorBuffer["B"] = tDispelColorMixin.b;
					sDispelColorBuffer["O"] = tDispelColorMixin.a or 1;

					sDispelColorBuffer["useBackground"] = nil;
					sDispelColorBuffer["useText"] = true;

					sDispelColorBuffer["TR"] = tDispelColorMixin.r;
					sDispelColorBuffer["TG"] = tDispelColorMixin.g;
					sDispelColorBuffer["TB"] = tDispelColorMixin.b;
					sDispelColorBuffer["TO"] = tDispelColorMixin.a or 1;

					return sDispelColorBuffer;
				end
			end
		end

		return nil;

	end



	--
	function VUHDO_getAuraGroupActiveColor(aUnit, aGroupId)

		if not aUnit or not aGroupId then
			return nil;
		end

		return sUnitAuraGroupActive[aUnit] and sUnitAuraGroupActive[aUnit][aGroupId];

	end



	--
	function VUHDO_clearDispellableAuraCache(aUnit)

		if aUnit then
			if sUnitAuraBarWinner[aUnit] then
				sAuraColorWinnerPool:release(sUnitAuraBarWinner[aUnit]);
			end

			if sUnitAuraTextWinner[aUnit] then
				sAuraColorWinnerPool:release(sUnitAuraTextWinner[aUnit]);
			end

			if sUnitAuraGlowWinner[aUnit] then
				sAuraGlowWinnerPool:release(sUnitAuraGlowWinner[aUnit]);
			end

			tSubMapForAuraGroup = sUnitAuraGroupActive[aUnit];

			if tSubMapForAuraGroup then
				for _, tPooledAuraGroupColor in pairs(tSubMapForAuraGroup) do
					if tPooledAuraGroupColor and tPooledAuraGroupColor["isAuraGroupBouquetColorPooled"] then
						sAuraGroupActiveColorPool:release(tPooledAuraGroupColor);
					end
				end
			end

			sUnitAuraGroupActive[aUnit] = nil;

			sUnitDispellableAuraId[aUnit] = nil;
			sUnitAuraCanColorBar[aUnit] = nil;
			sUnitAuraColorType[aUnit] = nil;
			sUnitAuraCustomColor[aUnit] = nil;
			sUnitAuraBarWinner[aUnit] = nil;
			sUnitAuraTextWinner[aUnit] = nil;
			sUnitAuraGlowWinner[aUnit] = nil;
		else
			for tUnit, _ in pairs(sUnitAuraBarWinner) do
				if sUnitAuraBarWinner[tUnit] then
					sAuraColorWinnerPool:release(sUnitAuraBarWinner[tUnit]);
				end

				if sUnitAuraTextWinner[tUnit] then
					sAuraColorWinnerPool:release(sUnitAuraTextWinner[tUnit]);
				end
			end

			for tUnit, _ in pairs(sUnitAuraTextWinner) do
				if not sUnitAuraBarWinner[tUnit] and sUnitAuraTextWinner[tUnit] then
					sAuraColorWinnerPool:release(sUnitAuraTextWinner[tUnit]);
				end
			end

			for tUnit, _ in pairs(sUnitAuraGlowWinner) do
				if sUnitAuraGlowWinner[tUnit] then
					sAuraGlowWinnerPool:release(sUnitAuraGlowWinner[tUnit]);
				end
			end

			twipe(sUnitDispellableAuraId);
			twipe(sUnitAuraCanColorBar);
			twipe(sUnitAuraColorType);
			twipe(sUnitAuraCustomColor);
			twipe(sUnitAuraBarWinner);
			twipe(sUnitAuraTextWinner);
			twipe(sUnitAuraGlowWinner);

			for tU, tMap in pairs(sUnitAuraGroupActive) do
				for _, tAuraGroupBouquetColor in pairs(tMap) do
					if tAuraGroupBouquetColor and tAuraGroupBouquetColor["isAuraGroupBouquetColorPooled"] then
						sAuraGroupActiveColorPool:release(tAuraGroupBouquetColor);
					end
				end
			end

			twipe(sUnitAuraGroupActive);
			twipe(sDispellableAuraScanDone);
		end

		return;

	end
end



do
	--
	local tInfo;
	local function VUHDO_isDispellableAuraDurationOnlyUpdate(aUpdateInfo)

		if not aUpdateInfo or aUpdateInfo["isFullUpdate"] then
			return false;
		end

		if aUpdateInfo["addedAuras"] or aUpdateInfo["removedAuraInstanceIDs"] then
			return false;
		end

		if aUpdateInfo["updatedAuraInstanceIDs"] then
			return true;
		end

		return false;

	end



	--
	function VUHDO_determineAura(aUnit, aUpdateInfo)

		tInfo = (VUHDO_RAID or sEmpty)[aUnit];

		if not tInfo then
			return nil, nil;
		end

		if VUHDO_isDispellableAuraDurationOnlyUpdate(aUpdateInfo) and sDispellableAuraScanDone[aUnit] then
			if VUHDO_hasDispellableAura(aUnit) then
				return VUHDO_getDispellableAuraId(aUnit), nil;
			end

			if sUnitAuraBarWinner[aUnit] or sUnitAuraTextWinner[aUnit] then
				return -1, nil;
			end

			return nil, nil;
		end

		VUHDO_updateDispellableAuraForUnit(aUnit);

		sDispellableAuraScanDone[aUnit] = true;

		if VUHDO_hasDispellableAura(aUnit) then
			return VUHDO_getDispellableAuraId(aUnit), nil;
		end

		if sUnitAuraBarWinner[aUnit] or sUnitAuraTextWinner[aUnit] then
			return -1, nil;
		end

		return nil, nil;

	end
end