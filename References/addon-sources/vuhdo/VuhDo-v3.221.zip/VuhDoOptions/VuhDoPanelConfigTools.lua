local _;
VUHDO_GLOBAL_ICONS = { };

local VUHDO_GI_SCAN_MAX = 1600001;
VUHDO_GI_SCAN_IDX = VUHDO_GI_SCAN_MAX;

local VUHDO_GI_SCAN_SKIP_IDS = _G["VUHDO_GI_SCAN_SKIP_IDS"] or { };

local VUHDO_GI_SCAN_SKIPS = {
	[1213133] = 1049296,
	[1049295] = 936051,
	[936050] = 556606,
	[556604] = 474771,
};

local GetSpellInfo = GetSpellInfo or VUHDO_getSpellInfo;
local GetSpellBookItemTexture = GetSpellBookItemTexture or VUHDO_getSpellBookItemTexture;
local pairs = pairs;



--
function VUHDO_removeFromModel(aPanelNum, anOrderNum)

	tremove(VUHDO_PANEL_MODELS[aPanelNum], anOrderNum);
	VUHDO_initDynamicPanelModels();

	return;

end



--
function VUHDO_insertIntoModel(aPanelNum, anOrderNum, anIsLeft, aModelId)
	tinsert(VUHDO_PANEL_MODELS[aPanelNum], anOrderNum + (anIsLeft and 0 or 1), aModelId)
	VUHDO_initDynamicPanelModels();
end



--
function VUHDO_rewritePanelModels()
	for tCnt = 1, VUHDO_MAX_PANELS do
		VUHDO_PANEL_SETUP[tCnt]["MODEL"]["groups"] = VUHDO_PANEL_MODELS[tCnt];
	end
end



--
function VUHDO_tableCount(anArray)
	local tCount = 0;
	for _ in pairs(anArray) do tCount = tCount + 1; end
	return tCount;
end



--
function VUHDO_getModelSafeName(anUnsafeName)
	return strtrim(gsub(anUnsafeName or "", "[.#]", " "));
end



--
function VUHDO_getOrCreateGroupOrderPanel(aParentPanelNum, aPanelNum)
	local tName = "Vd" .. aParentPanelNum .. "GrpOrd" .. aPanelNum;
	if not _G[tName] then
		local tPanel = CreateFrame("Frame", tName, _G["Vd" .. aParentPanelNum], "VuhDoGrpOrdTemplate");
		VUHDO_fixFrameLevels(false, tPanel, 2, tPanel:GetChildren());
	end

	return _G[tName];
end



--
function VUHDO_getOrCreateGroupSelectPanel(aParentPanelNum, aPanelNum)
	local tName = "Vd" .. aParentPanelNum .. "GrpSel" .. aPanelNum;
	if not _G[tName] then
		local tPanel = CreateFrame("Frame", tName, _G["Vd" .. aParentPanelNum], "VuhDoGrpSelTemplate");
		VUHDO_fixFrameLevels(false, tPanel, 2, tPanel:GetChildren());
	end

	return _G[tName];
end



--
local sGroupOrderBarsRight = { };
function VUHDO_getConfigOrderBarRight(aPanelNum, anOrderNum)
	local tIndex = aPanelNum * 100 + anOrderNum;
	if not sGroupOrderBarsRight[tIndex] then
		local tPanel = VUHDO_getOrCreateGroupOrderPanel(aPanelNum, anOrderNum);
		sGroupOrderBarsRight[tIndex] = _G[tPanel:GetName() .. "InsTxuR"];
	end

	return sGroupOrderBarsRight[tIndex];
end



--
local sGroupOrderBarsLeft = { };
function VUHDO_getConfigOrderBarLeft(aPanelNum, anOrderNum)
	local tIndex = aPanelNum * 100 + anOrderNum;
	if not sGroupOrderBarsLeft[tIndex] then
		local tPanel = VUHDO_getOrCreateGroupOrderPanel(aPanelNum, anOrderNum);
		sGroupOrderBarsLeft[tIndex] = _G[tPanel:GetName() .. "InsTxuL"];
	end

	return sGroupOrderBarsLeft[tIndex];
end



--
local tText, tTextById, tLabel;
function VUHDO_newOptionsSpellEditBoxCheckId(anEditBox)
	tLabel = _G[anEditBox:GetName() .. "Hint"];
	tText = anEditBox:GetText();
	tTextById = VUHDO_resolveSpellId(tText);

	if tText ~= tTextById then
		tTextById = strsub(tTextById, 1, 20);
		tLabel:SetText(tTextById);
	else
		tLabel:SetText("");
	end
end



--
local VUHDO_USED_BUFFS = { };
local tSpell;
local tSpellId;
local tIcon;
function VUHDO_updateGlobalIconList()

	table.wipe(VUHDO_USED_BUFFS);

	-- Add custom debuffs
	--for _, tName in pairs(VUHDO_CONFIG["CUSTOM_DEBUFF"]["STORED"]) do
	--	VUHDO_USED_BUFFS[tName] = true;
	--end

	-- Add spell traces
	--for _, tName in pairs(VUHDO_CONFIG["SPELL_TRACE"]["STORED"]) do
	--	VUHDO_USED_BUFFS[tName] = true;
	--end

	-- Add bouquet item buffs
	for _, tItems in pairs(VUHDO_BOUQUETS["STORED"]) do
		tItems = VUHDO_decompressIfCompressed(tItems);
		for _, tItem in pairs(tItems) do
		  --  tItem["name"] can be nil for some reason (maybe on compressing bouquets?)
			if tItem["name"] and not VUHDO_BOUQUET_BUFFS_SPECIAL[tItem["name"]] then
				VUHDO_USED_BUFFS[tItem["name"]] = true;
			end
		end
	end

	-- Add standard icons
	for _, tValues in pairs(VUHDO_CUSTOM_ICONS) do
		if tValues[2] then
			VUHDO_USED_BUFFS[tValues[1]] = true;
			VUHDO_GLOBAL_ICONS[tValues[1]] = tValues[2];
		end
	end

	-- Add global aura ignores
	for tName, _  in pairs(VUHDO_AURA_IGNORE_LIST) do
		tSpell = tostring(tName);

		VUHDO_USED_BUFFS[tSpell] = true;
	end

	-- Add spell entries from list type aura groups (defaults)
	-- Add auras from filter type aura group ignore lists
	for _, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS) do
		if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST and tGroup["entries"] then
			for _, tEntry in ipairs(tGroup["entries"]) do
				if tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL then
					tSpell = tostring(tEntry["value"]);

					VUHDO_USED_BUFFS[tSpell] = true;
				end
			end
		elseif (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_FILTER and tGroup["ignoreList"] then
			for tName, _ in pairs(tGroup["ignoreList"]) do
				tSpell = tostring(tName);

				VUHDO_USED_BUFFS[tSpell] = true;
			end
		end
	end

	-- Add spell entries from list type aura groups (custom)
	-- Add auras from filter type aura group ignore lists (custom)
	if VUHDO_CONFIG["AURA_GROUPS"] then
		for _, tGroup in pairs(VUHDO_CONFIG["AURA_GROUPS"]) do
			if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST and tGroup["entries"] then
				for _, tEntry in ipairs(tGroup["entries"]) do
					if tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL then
						tSpell = tostring(tEntry["value"]);

						VUHDO_USED_BUFFS[tSpell] = true;
					end
				end
			elseif (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_FILTER and tGroup["ignoreList"] then
				for tName, _ in pairs(tGroup["ignoreList"]) do
					tSpell = tostring(tName);

					VUHDO_USED_BUFFS[tSpell] = true;
				end
			end
		end
	end

	-- Remove obsolete
	for tName, _ in pairs(VUHDO_GLOBAL_ICONS) do
		if not VUHDO_USED_BUFFS[tName] then
			VUHDO_GLOBAL_ICONS[tName] = nil;
		end
	end

	-- Add new
	for tName, _ in pairs(VUHDO_USED_BUFFS) do
		if (VUHDO_GLOBAL_ICONS[tName] == nil) then
			tSpellId = tonumber(tName);

			if tSpellId then
				_, _, tIcon = GetSpellInfo(tSpellId);

				VUHDO_GLOBAL_ICONS[tName] = tIcon;
			else
				tSpellId = VUHDO_resolveAuraContainerPreferredSpellId(tName);

				if tSpellId then
					_, _, tIcon = GetSpellInfo(tSpellId);

					VUHDO_GLOBAL_ICONS[tName] = tIcon;
					VUHDO_GLOBAL_ICONS[tostring(tSpellId)] = tIcon;
				else
					VUHDO_GLOBAL_ICONS[tName] = "";
				end
			end
		end
	end

	return;

end



--
local function VUHDO_tableContains(aTable, aValue)
	for _, tValue in pairs(aTable) do
		if tValue == aValue then return true; end
	end

	return false;
end



--
local tStep = 50;
local tRef;
local tName;
local tIcon;
local function VUHDO_scanNextGlobalIcons()

	if not VUHDO_tableContains(VUHDO_GLOBAL_ICONS, "") then
		return;
	end

	tRef = VUHDO_GLOBAL_ICONS;

	for tCnt = VUHDO_GI_SCAN_IDX + tStep, VUHDO_GI_SCAN_IDX, -1 do
		if not VUHDO_GI_SCAN_SKIP_IDS[tCnt] then
			tName, _, tIcon = GetSpellInfo(tCnt);

			if tRef[tName] == "" then
				tRef[tName] = tIcon;
			end
		end

		tCnt = VUHDO_GI_SCAN_SKIPS[tCnt] or tCnt;
	end

	VUHDO_GI_SCAN_IDX = VUHDO_GI_SCAN_IDX - tStep;

	if VUHDO_GI_SCAN_IDX < 1 then
		VUHDO_GI_SCAN_IDX = VUHDO_GI_SCAN_MAX;
	end

end



--
function VUHDO_optionsOnUpdate(self, aTimeDelta)
	VUHDO_scanNextGlobalIcons();
	VUHDO_updateRequestsInProgress();
end



--
function VUHDO_getGlobalIcon(aDeBuffName)
	if not aDeBuffName then return nil; end
	return GetSpellBookItemTexture(aDeBuffName) or VUHDO_GLOBAL_ICONS[aDeBuffName];
end
