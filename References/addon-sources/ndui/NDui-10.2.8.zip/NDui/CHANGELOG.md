# NDui

## [10.2.8](https://github.com/siweia/NDui/tree/10.2.8) (2026-11-08)
[Full Changelog](https://github.com/siweia/NDui/compare/10.2.7...10.2.8) [Previous Releases](https://github.com/siweia/NDui/releases)

- 10.2.8  
- Unify  
- typo  
- Cleanup  
- Krowi\_ProgressBarTooltip  
- Hide mask on affix icons  
- Fix worldmap taint  
- Replace with targetindicator  
- Secret value check  
- Update Notifications.lua (#492)  