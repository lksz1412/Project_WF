local _, ns = ...
local B, C, L, DB = unpack(ns)
local M = B:GetModule("Misc")

local format, gsub, strsplit, strfind = string.format, string.gsub, string.split, string.find
local bit_band, bit_bor = bit.band, bit.bor
local pairs, wipe = pairs, wipe
local GetInstanceInfo, PlaySound, print = GetInstanceInfo, PlaySound, print
local IsInRaid, IsInGroup, IsInInstance, IsInGuild = IsInRaid, IsInGroup, IsInInstance, IsInGuild
local UnitName, Ambiguate, GetTime = UnitName, Ambiguate, GetTime
local GetSpellLink = C_Spell.GetSpellLink
local GetSpellName = C_Spell.GetSpellName
local C_Map_GetBestMapForUnit = C_Map.GetBestMapForUnit
local C_VignetteInfo_GetVignetteInfo = C_VignetteInfo.GetVignetteInfo
local C_VignetteInfo_GetVignettePosition = C_VignetteInfo.GetVignettePosition
local C_Texture_GetAtlasInfo = C_Texture.GetAtlasInfo
local C_ChatInfo_SendAddonMessage = C_ChatInfo.SendAddonMessage
local C_ChatInfo_RegisterAddonMessagePrefix = C_ChatInfo.RegisterAddonMessagePrefix
local groupAffiliationMask = bit_bor(Enum.CombatLogObject.AffiliationParty, Enum.CombatLogObject.AffiliationRaid)

local function IsRandomGroup()
	return IsPartyLFG() or C_PartyInfo.IsPartyWalkIn()
end

--[[
	发现稀有/事件时的通报插件
]]
local cache = {}
local isIgnoredZone = {
	[1153] = true,	-- 部落要塞
	[1159] = true,	-- 联盟要塞
	[1803] = true,	-- 涌泉海滩
	[1876] = true,	-- 部落激流堡
	[1943] = true,	-- 联盟激流堡
	[2111] = true,	-- 黑海岸前线
}
local defaultList = {
	[6149] = true, -- 奥妮克希亚龙蛋
	[6699] = true, -- 错放的奇珍，地下堡
}
local isIgnoredIDs = {}

local function isUsefulAtlas(info)
	local atlas = info.atlasName
	if atlas then
		return strfind(atlas, "[Vv]ignette") or (atlas == "nazjatar-nagaevent")
	end
end

function M:RareAlert_UpdateIgnored()
	B.SplitList(isIgnoredIDs, NDuiADB["IgnoredRares"], true)

	for id in pairs(defaultList) do
		isIgnoredIDs[id] = true
	end
end

function M:RareAlert_Update(id)
	if id and not cache[id] then
		local info = C_VignetteInfo_GetVignetteInfo(id)
		if not info or not isUsefulAtlas(info) or isIgnoredIDs[info.vignetteID] then return end

		local atlasInfo = C_Texture_GetAtlasInfo(info.atlasName)
		if not atlasInfo then return end
		local tex = B:GetTextureStrByAtlas(atlasInfo)
		if not tex then return end

		UIErrorsFrame:AddMessage(DB.InfoColor..L["Rare Found"]..tex..(info.name or ""))

		if C.db["Misc"]["RarePrint"] then
			local currrentTime = NDuiADB["TimestampFormat"] == 1 and "|cff00ff00["..date("%H:%M:%S").."]|r" or ""
			local nameString
			local mapID = C_Map_GetBestMapForUnit("player")
			local position = mapID and C_VignetteInfo_GetVignettePosition(info.vignetteGUID, mapID)
			if position then
				local x, y = position:GetXY()
				nameString = format(M.RareString, mapID, x*10000, y*10000, info.name, x*100, y*100, "ID:"..info.vignetteID)
			end
			print(currrentTime.." -> "..tex..DB.InfoColor..(nameString or info.name or ""))
		end

		if not C.db["Misc"]["RareAlertInWild"] or M.RareInstType == "none" then
			PlaySound(23404, "master")
		end

		cache[id] = true
	end

	if #cache > 666 then wipe(cache) end
end

function M:RareAlert_CheckInstance()
	local _, instanceType, _, _, maxPlayers, _, _, instID = GetInstanceInfo()
	if (instID and isIgnoredZone[instID]) or (instanceType == "scenario" and (maxPlayers == 3 or maxPlayers == 6)) then
		B:UnregisterEvent("VIGNETTE_MINIMAP_UPDATED", M.RareAlert_Update)
	else
		B:RegisterEvent("VIGNETTE_MINIMAP_UPDATED", M.RareAlert_Update)
	end
	M.RareInstType = instanceType
end

function M:RareAlert()
	M.RareString = "|Hworldmap:%d+:%d+:%d+|h[%s (%.1f, %.1f) %s]|h|r"

	if C.db["Misc"]["RareAlerter"] then
		M:RareAlert_UpdateIgnored()
		M:RareAlert_CheckInstance()
		B:RegisterEvent("UPDATE_INSTANCE_INFO", M.RareAlert_CheckInstance)
	else
		wipe(cache)
		B:UnregisterEvent("VIGNETTE_MINIMAP_UPDATED", M.RareAlert_Update)
		B:UnregisterEvent("UPDATE_INSTANCE_INFO", M.RareAlert_CheckInstance)
	end
end

--[[
	闭上你的嘴！
	打断、偷取及驱散法术时的警报
]]
function M:GetMsgChannel()
	return IsRandomGroup() and "INSTANCE_CHAT" or IsInRaid() and "RAID" or "PARTY"
end

local infoType = {}

function M:InterruptAlert_Toggle()
	infoType["SPELL_STOLEN"] = C.db["Misc"]["DispellAlert"] and L["Steal"]
	infoType["SPELL_DISPEL"] = C.db["Misc"]["DispellAlert"] and L["Dispel"]
	infoType["SPELL_INTERRUPT"] = C.db["Misc"]["InterruptAlert"] and L["Interrupt"]
	infoType["SPELL_AURA_BROKEN_SPELL"] = C.db["Misc"]["BrokenAlert"] and L["BrokenSpell"]
end

function M:InterruptAlert_IsEnabled()
	for _, value in pairs(infoType) do
		if value then
			return true
		end
	end
end

local blackList = {
	[99] = true,		-- 夺魂咆哮
	[122] = true,		-- 冰霜新星
	[1776] = true,		-- 凿击
	[1784] = true,		-- 潜行
	[5246] = true,		-- 破胆怒吼
	[8122] = true,		-- 心灵尖啸
	[31661] = true,		-- 龙息术
	[33395] = true,		-- 冰冻术
	[64695] = true,		-- 陷地
	[82691] = true,		-- 冰霜之环
	[91807] = true,		-- 蹒跚冲锋
	[102359] = true,	-- 群体缠绕
	[105421] = true,	-- 盲目之光
	[115191] = true,	-- 潜行
	[157997] = true,	-- 寒冰新星
	[197214] = true,	-- 裂地术
	[198121] = true,	-- 冰霜撕咬
	[207167] = true,	-- 致盲冰雨
	[207685] = true,	-- 悲苦咒符
	[226943] = true,	-- 心灵炸弹
	[228600] = true,	-- 冰川尖刺
	[285515] = true,	-- 能量湍流
	[331866] = true,	-- 混沌代理人
	[354051] = true,	-- 轻盈步
	[355689] = true,	-- 山崩
	[386770] = true,	-- 极寒
	[378760] = true,	-- 冰霜撕咬
}

function M:IsAllyPet(sourceFlags)
	if DB:IsMyPet(sourceFlags) or sourceFlags == DB.PartyPetFlags or sourceFlags == DB.RaidPetFlags then
		return true
	end
end

function M:InterruptAlert_Update(...)
	if C.db["Misc"]["LeaderOnly"] and not (UnitIsGroupAssistant("player") or UnitIsGroupLeader("player")) then return end -- only alert for leader, needs review

	local _, eventType, _, sourceGUID, sourceName, sourceFlags, _, _, destName, _, _, spellID, _, _, extraskillID, _, _, auraType = ...
	if not sourceGUID or sourceName == destName then return end

	local isGroupPlayer = bit_band(sourceFlags, groupAffiliationMask) > 0 and bit_band(sourceFlags, Enum.CombatLogObject.TypePlayer) > 0
	if isGroupPlayer or M:IsAllyPet(sourceFlags) then
		local infoText = infoType[eventType]
		if infoText then
			local sourceSpellID, destSpellID
			if infoText == L["BrokenSpell"] then
				if auraType and auraType == AURA_TYPE_BUFF or blackList[spellID] then return end
				sourceSpellID, destSpellID = extraskillID, spellID
			elseif infoText == L["Interrupt"] then
				if C.db["Misc"]["OwnInterrupt"] and sourceName ~= DB.MyName and not DB:IsMyPet(sourceFlags) then return end
				sourceSpellID, destSpellID = spellID, extraskillID
			else
				if C.db["Misc"]["OwnDispell"] and sourceName ~= DB.MyName and not DB:IsMyPet(sourceFlags) then return end
				sourceSpellID, destSpellID = spellID, extraskillID
			end

			if sourceSpellID and destSpellID then
				B:SendChatMessage(format(infoText, sourceName..GetSpellLink(sourceSpellID), destName..GetSpellLink(destSpellID)), M:GetMsgChannel())
			end
		end
	end
end

function M:InterruptAlert_CheckGroup()
	if IsInGroup() and (not C.db["Misc"]["InstAlertOnly"] or (IsInInstance() and not IsRandomGroup())) then
		B:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", M.InterruptAlert_Update)
	else
		B:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED", M.InterruptAlert_Update)
	end
end

function M:InterruptAlert()
	M:InterruptAlert_Toggle()

	if M:InterruptAlert_IsEnabled() then
		M:InterruptAlert_CheckGroup()
		B:RegisterEvent("GROUP_LEFT", M.InterruptAlert_CheckGroup)
		B:RegisterEvent("GROUP_JOINED", M.InterruptAlert_CheckGroup)
		B:RegisterEvent("PLAYER_ENTERING_WORLD", M.InterruptAlert_CheckGroup)
	else
		B:UnregisterEvent("GROUP_LEFT", M.InterruptAlert_CheckGroup)
		B:UnregisterEvent("GROUP_JOINED", M.InterruptAlert_CheckGroup)
		B:UnregisterEvent("PLAYER_ENTERING_WORLD", M.InterruptAlert_CheckGroup)
		B:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED", M.InterruptAlert_Update)
	end
end

--[[
	NDui版本过期提示
]]
local lastVCTime, isVCInit = 0

local function HandleVersonTag(version)
	local major, minor = strsplit(".", version)
	major, minor = tonumber(major), tonumber(minor)
	if major > 10 then
		major, minor = 0, 0
	end
	return major, minor
end

function M:VersionCheck_Compare(new, old)
	local new1, new2 = HandleVersonTag(new)
	local old1, old2 = HandleVersonTag(old)
	if new1 > old1 or (new1 == old1 and new2 > old2) then
		return "IsNew"
	elseif new1 < old1 or (new1 == old1 and new2 < old2) then
		return "IsOld"
	end
end

function M:VersionCheck_Create(text)
	if not NDuiADB["VersionCheck"] then return end

	HelpTip:Show(ChatFrame1, {
		text = text,
		buttonStyle = HelpTip.ButtonStyle.Okay,
		targetPoint = HelpTip.Point.TopEdgeCenter,
		offsetY = 10,
	})
end

function M:VersionCheck_Init()
	if not isVCInit then
		local status = M:VersionCheck_Compare(NDuiADB["DetectVersion"], DB.Version)
		if status == "IsNew" then
			local release = gsub(NDuiADB["DetectVersion"], "(%d+)$", "0")
			M:VersionCheck_Create(format(L["Outdated NDui"], release))
		elseif status == "IsOld" then
			NDuiADB["DetectVersion"] = DB.Version
		end

		isVCInit = true
	end
end

function M:VersionCheck_Send(channel)
	if GetTime() - lastVCTime >= 10 then
		C_ChatInfo_SendAddonMessage("NDuiVersionCheck", NDuiADB["DetectVersion"], channel)
		lastVCTime = GetTime()
	end
end

function M:VersionCheck_Update(...)
	local prefix, msg, distType, author = ...
	if prefix ~= "NDuiVersionCheck" then return end
	if B:IsSecretValue(author) then return end
	if Ambiguate(author, "none") == DB.MyName then return end

	local status = M:VersionCheck_Compare(msg, NDuiADB["DetectVersion"], author)
	if status == "IsNew" then
		NDuiADB["DetectVersion"] = msg
	elseif status == "IsOld" then
		M:VersionCheck_Send(distType)
	end

	M:VersionCheck_Init()
end

function M:VersionCheck_UpdateGroup()
	if not IsInGroup() then return end
	M:VersionCheck_Send(M:GetMsgChannel())
end

function M:VersionCheck()
	M:VersionCheck_Init()
	C_ChatInfo_RegisterAddonMessagePrefix("NDuiVersionCheck")
	B:RegisterEvent("CHAT_MSG_ADDON", M.VersionCheck_Update)

	if IsInGuild() then
		C_ChatInfo_SendAddonMessage("NDuiVersionCheck", DB.Version, "GUILD")
		lastVCTime = GetTime()
	end
	M:VersionCheck_UpdateGroup()
	B:RegisterEvent("GROUP_ROSTER_UPDATE", M.VersionCheck_UpdateGroup)
end

--[[
	放大餐时叫一叫
]]
local myGUID = UnitGUID("player")
local groupUnits = {["player"] = true, ["pet"] = true}
for i = 1, 4 do
	groupUnits["party"..i] = true
	groupUnits["partypet"..i] = true
end
for i = 1, 40 do
	groupUnits["raid"..i] = true
	groupUnits["raidpet"..i] = true
end

local spellList = {
	[698] = true,		-- 拉人
	[29893] = true,		-- 糖
	[190336] = true,	-- 面包
	[54710] = true,		-- 随身邮箱
	[67826] = true,		-- 基维斯
	[226241] = true,	-- 宁神圣典
	[256230] = true,	-- 静心圣典
	[185709] = true,	-- 焦糖鱼宴
	[199109] = true,	-- 自动铁锤
	[259409] = true,	-- 海帆盛宴
	[259410] = true,	-- 船长盛宴
	[276972] = true,	-- 秘法药锅
	[286050] = true,	-- 鲜血大餐
	[265116] = true,	-- 8.0工程战复
	[308458] = true,	-- 惊异怡人大餐
	[308462] = true,	-- 纵情饕餮盛宴
	[345130] = true,	-- 9.0工程战复
	[307157] = true,	-- 永恒药锅
	[359336] = true,	-- 石头汤锅
	[261602] = true,	-- 凯蒂的印哨
	[376664] = true,	-- 欧胡纳栖枝

	[2825]   = true,	-- 嗜血
	[32182]  = true,	-- 英勇
	[80353]  = true,	-- 时间扭曲
	[90355] = true,		-- 远古狂乱，宠物
	[264667] = true,	-- 原始暴怒，宠物
	[272678] = true,	-- 原始暴怒，宠物掌控
	[178207] = true,	-- 狂怒战鼓
	[230935] = true,	-- 高山战鼓
	[256740] = true,	-- 漩涡战鼓
	[292686] = true,	-- 雷皮之槌
	[390386] = true,	-- 守护巨龙之怒
	[309658] = true,	-- 死亡凶蛮战鼓
	[444257] = true,	-- 掣雷之鼓
	[466904] = true, 	-- 鹞鹰尖啸

	[384893] = true,	-- 足以乱真的救急电缆11.0工程战复
	[453949] = true,	-- 不可抗拒的红色按钮11.0工程战复工具
	[453942] = true,	-- 阿加修理机器人11O   
	[432877] = true,	-- 阿加合剂大锅
	[433292] = true,	-- 阿加药水大锅
	[455960] = true,	-- 全味炖煮
	[457285] = true,	-- 午夜舞会盛宴
	[457302] = true,	-- 特色寿司
	[457487] = true,	-- 丰盛的全味炖煮(战团)
	[462211] = true,	-- 丰盛的特色寿司(战团)
	[462213] = true,	-- 丰盛的午夜舞会盛宴(战团)
	--12.0
	[1240019] = true,	-- 辛多雷合剂大锅
	[1240195] = true,	-- 辛多雷合剂大锅
	[1240225] = true,	-- 虚空之光药水大锅
	[1240267] = true,	-- 虚空之光药水大锅
	[1259656] = true,	-- 盛放筵席
	[1259657] = true,	-- 奎尔多雷拼盘
	[1259658] = true,	-- 哈籁恩达尔庆典大餐
	[1259659] = true,	-- 银月城浮华大餐
	[1296432] = true,	-- 阿曼尼丰饶角
	[1296433] = true,	-- 神灵聚会
	[1296434] = true,	-- 知识盛宴
	[1278895] = true,	-- 丰盛银月城浮华大餐
	[1278909] = true,	-- 丰盛的盛放筵席
	[1278915] = true,	-- 丰盛奎尔多雷拼盘
	[1278929] = true,	-- 丰盛哈籁恩达尔庆典大餐
	[1303407] = true,	-- 丰盛的阿曼尼丰饶角
	[1303408] = true,	-- 丰盛的神灵聚会
	[1303409] = true,	-- 丰盛的知识盛宴	
}

function M:ItemAlert_Update(unit, castID, spellID)
	if B:IsSecretValue(spellID) then return end
	if C.db["Misc"]["LeaderOnly"] and not (UnitIsGroupAssistant("player") or UnitIsGroupLeader("player")) then return end -- only alert for leader, needs review

	if groupUnits[unit] and spellList[spellID] and (spellList[spellID] ~= castID) then
		B:SendChatMessage(format(L["SpellItemAlertStr"], UnitName(unit), GetSpellLink(spellID) or GetSpellName(spellID)), M:GetMsgChannel())
		spellList[spellID] = castID
	end
end

local bloodLustDebuffs = {
	[57723]  = true, -- 筋疲力尽
	[57724]  = true, -- 心满意足
	[80354]  = true, -- 时空错位
	[95809]  = true, -- 疯狂
	[160455] = true, -- 疲倦
	[264689] = true, -- 疲倦
	[390435] = true, -- 筋疲力尽，龙希尔
}

function M:CheckBloodlustStatus(...)
	if C.db["Misc"]["LeaderOnly"] and not (UnitIsGroupAssistant("player") or UnitIsGroupLeader("player")) then return end -- only alert for leader, needs review

	local _, eventType, _, sourceGUID, _, _, _, _, _, _, _, spellID = ...
	if eventType == "SPELL_AURA_REMOVED" and bloodLustDebuffs[spellID] and sourceGUID == myGUID then
		B:SendChatMessage(format(L["BloodlustStr"], GetSpellLink(spellID), M.factionSpell), M:GetMsgChannel())
	end
end

function M:ItemAlert_CheckGroup()
	if IsInGroup() then
		B:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED", M.ItemAlert_Update)
	--	B:RegisterEvent("CLEU", M.CheckBloodlustStatus)
	else
		B:UnregisterEvent("UNIT_SPELLCAST_SUCCEEDED", M.ItemAlert_Update)
	--	B:UnregisterEvent("CLEU", M.CheckBloodlustStatus)
	end
end

function M:SpellItemAlert()
	M.factionSpell = DB.MyFaction == "Alliance" and 32182 or 2825
	M.factionSpell = GetSpellLink(M.factionSpell)

	if C.db["Misc"]["SpellItemAlert"] then
		M:ItemAlert_CheckGroup()
		B:RegisterEvent("GROUP_LEFT", M.ItemAlert_CheckGroup)
		B:RegisterEvent("GROUP_JOINED", M.ItemAlert_CheckGroup)
	else
		B:UnregisterEvent("GROUP_LEFT", M.ItemAlert_CheckGroup)
		B:UnregisterEvent("GROUP_JOINED", M.ItemAlert_CheckGroup)
		B:UnregisterEvent("UNIT_SPELLCAST_SUCCEEDED", M.ItemAlert_Update)
	--	B:UnregisterEvent("CLEU", M.CheckBloodlustStatus)
	end
end

-- Incompatible check
local IncompatibleAddOns = {
	["BigFoot"] = true,
	["OrzUI"] = true,
	["!!!163UI!!!"] = true,
	["Aurora"] = true,
	["AuroraClassic"] = true, -- my own addon
	["DomiRank"] = true, -- my own addon
	["MDGuildBest"] = true, -- my own addon
}
local AddonDependency = {
	["BigFoot"] = "!!!Libs",
}
function M:CheckIncompatible()
	local IncompatibleList = {}
	for addon in pairs(IncompatibleAddOns) do
		if C_AddOns.IsAddOnLoaded(addon) then
			tinsert(IncompatibleList, addon)
		end
	end

	if #IncompatibleList > 0 then
		local frame = CreateFrame("Frame", nil, UIParent)
		frame:SetPoint("TOP", 0, -200)
		frame:SetFrameStrata("HIGH")
		B.CreateMF(frame)
		B.SetBD(frame)
		B.CreateFS(frame, 18, L["FoundIncompatibleAddon"], true, "TOPLEFT", 10, -10)
		B.CreateWatermark(frame)

		local offset = 0
		for _, addon in pairs(IncompatibleList) do
			B.CreateFS(frame, 14, addon, false, "TOPLEFT", 10, -(50 + offset))
			offset = offset + 24
		end
		frame:SetSize(300, 100 + offset)

		local close = B.CreateButton(frame, 16, 16, true, DB.closeTex)
		close:SetPoint("TOPRIGHT", -10, -10)
		close:SetScript("OnClick", function() frame:Hide() end)

		local disable = B.CreateButton(frame, 150, 25, L["DisableIncompatibleAddon"])
		disable:SetPoint("BOTTOM", 0, 10)
		disable.text:SetTextColor(1, .8, 0)
		disable:SetScript("OnClick", function()
			for _, addon in pairs(IncompatibleList) do
				C_AddOns.DisableAddOn(addon)
				if AddonDependency[addon] then
					C_AddOns.DisableAddOn(AddonDependency[addon])
				end
			end
			ReloadUI()
		end)
	end
end

-- Init
function M:AddAlerts()
	M:RareAlert()
	--M:InterruptAlert()
	C_Timer.After(0, M.VersionCheck) -- add delay to avoid taint
	M:SpellItemAlert()
	M:CheckIncompatible()
end
M:RegisterMisc("Notifications", M.AddAlerts)
