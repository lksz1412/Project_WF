if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUI_Widgets_CheckboxDropdowns.lua
--  Checkbox dropdowns shared by the options pages: the empty-filter
--  warning, BuildVisOptsCBDropdown and its drag-reorder variant, and the
--  slider dropdown (BuildSliderDropdown). Loads right after
--  EllesmereUI_Widgets.lua.
-------------------------------------------------------------------------------
local EllesmereUI = _G.EllesmereUI

-- The options page pool (EllesmereUI_FramePool.lua, the options addon's first
-- file): a frame made below on a pool host is handed out again, reset to new,
-- when that host is built again, and each lazy menu is kept per dropdown
-- button. Captured once here, never read through the public slot later.
local Pool = EllesmereUI._Pool
local CreateFrame, PoolKept, PoolGen = Pool.CreateFrame, Pool.Kept, Pool.Gen

-- Global search prebuild: the stand-in a builder below returns in place of a
-- control on an absorber row (PrebuildStandIn, EllesmereUI_Widgets.lua). Nil
-- outside the pass and for a real parent.
local function StandIn(parent)
    if not EllesmereUI._prebuilding then return nil end
    return EllesmereUI._widgetInternals.PrebuildStandIn(parent)
end

-- Empty-selection warning for a filter dropdown whose selection is allowed
-- to reach "shows nothing" (PAB buff/debuff Filters, RF Debuff Manager base
-- Filters): while hasContentFn() is false, the dropdown carries a red border
-- and a persistent bubble above it (warnText), and the returned closure --
-- meant as the dropdown's onMenuClosed -- pulses the control red twice when
-- the menu closes on an empty selection. hasContentFn must be the surface's
-- REAL render predicate (broad mode / Show lane / extra spells / enchants /
-- fx-forced or claimed categories): anything that still renders must count,
-- so a surface that displays something never warns. Update registers as a
-- widget refresh, so every lane click that triggers a non-force RefreshPage
-- re-evaluates live. A long warnText wraps at WARN_WRAP px. opts.onDismiss:
-- advice the reader may wave off for good (the Kick Tracker's marker
-- warning): a button in the bubble's own dress sits beside it, the
-- pair centred over the control, and a click runs it and re-reads; the
-- caller's hasContentFn honours the flag it keeps.
local WARN_WRAP = 300       -- px of text a warning bubble holds on one line
local WARN_GAP = 4          -- px between the bubble and its dismiss button
local DISMISS_MAX = 22      -- px the dismiss button grows to beside a wrapped bubble

local function WarnDress(frame)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.12, 0.03, 0.03, 0.95)
    EllesmereUI.MakeRoundedBorder(frame, 0.85, 0.2, 0.2, 1, bg)
end

function EllesmereUI.AttachEmptyFilterWarn(rgn, cbDD, warnText, hasContentFn, opts)
    -- Search prebuild on an absorber row: the warning indexes nothing, so none is built.
    local standIn = StandIn(rgn) or StandIn(cbDD)
    if standIn then return standIn end
    local PP = EllesmereUI.PanelPP
    local onDismiss = opts and opts.onDismiss
    local Update

    local bubble = CreateFrame("Frame", nil, rgn)
    bubble:SetFrameLevel(cbDD:GetFrameLevel() + 10)
    local fs = EllesmereUI.MakeFont(bubble, 12, nil, 1, 0.4, 0.4)
    fs:SetText(warnText)
    fs:SetPoint("CENTER")
    local tw = math.ceil(fs:GetStringWidth())
    if tw > WARN_WRAP then
        tw = WARN_WRAP
        fs:SetWidth(tw)
        fs:SetWordWrap(true)
        fs:SetJustifyH("CENTER")
    end
    local bw, bh = tw + 16, math.ceil(fs:GetStringHeight()) + 10
    PP.Size(bubble, bw, bh)
    WarnDress(bubble)
    if onDismiss then
        local sz = math.min(bh, DISMISS_MAX)
        local cross = CreateFrame("Button", nil, bubble)
        PP.Size(cross, sz, sz)
        cross:SetPoint("LEFT", bubble, "RIGHT", WARN_GAP, 0)
        cross:SetFrameLevel(bubble:GetFrameLevel())
        WarnDress(cross)
        local hl = cross:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(0.85, 0.2, 0.2, 0.25)
        EllesmereUI.RoundBody(cross, hl)
        local xfs = EllesmereUI.MakeFont(cross, 12, nil, 1, 0.4, 0.4)
        xfs:SetPoint("CENTER", cross, "CENTER", 0, 1)
        xfs:SetText("x")
        cross:SetScript("OnEnter", function()
            xfs:SetTextColor(1, 0.75, 0.75)
            EllesmereUI.ShowWidgetTooltip(cross, EllesmereUI.L("Dismiss this warning"))
        end)
        cross:SetScript("OnLeave", function()
            xfs:SetTextColor(1, 0.4, 0.4)
            EllesmereUI.HideWidgetTooltip()
        end)
        cross:SetScript("OnClick", function()
            onDismiss()
            Update()
        end)
        bubble:SetPoint("BOTTOM", cbDD, "TOP", -(sz + WARN_GAP) / 2, 5)
    else
        bubble:SetPoint("BOTTOM", cbDD, "TOP", 0, 5)
    end
    bubble:Hide()

    local warnBorder = CreateFrame("Frame", nil, cbDD)
    warnBorder:SetAllPoints(cbDD)
    EllesmereUI.MakeRoundedBorder(warnBorder, 0.85, 0.2, 0.2, 1)
    warnBorder:Hide()

    local flash = cbDD:CreateTexture(nil, "OVERLAY", nil, 7)
    flash:SetAllPoints()
    flash:SetColorTexture(0.9, 0.15, 0.15, 0.45)
    EllesmereUI.RoundBody(cbDD, flash)
    flash:SetAlpha(0)
    local ag = flash:CreateAnimationGroup()
    local a1 = ag:CreateAnimation("Alpha")
    a1:SetFromAlpha(0); a1:SetToAlpha(1); a1:SetDuration(0.10); a1:SetOrder(1)
    local a2 = ag:CreateAnimation("Alpha")
    a2:SetFromAlpha(1); a2:SetToAlpha(0); a2:SetDuration(0.45); a2:SetOrder(2)
    -- Two pulses read as a deliberate alert; one reads as a rendering glitch.
    ag:SetLooping("REPEAT")
    local loops = 0
    ag:SetScript("OnPlay", function() loops = 0 end)
    ag:SetScript("OnLoop", function(self)
        loops = loops + 1
        if loops >= 2 then self:Stop() end
    end)

    Update = function()
        local empty = not hasContentFn()
        bubble:SetShown(empty)
        warnBorder:SetShown(empty)
        if not empty and ag:IsPlaying() then ag:Stop() end
    end
    Update()
    EllesmereUI.RegisterWidgetRefresh(Update)
    return function()
        Update()
        if not hasContentFn() then ag:Restart() end
    end
end

-------------------------------------------------------------------------------
--  Shared Visibility Options Checkbox Dropdown
--  Reusable across CDM, Action Bars, Resource Bars, Unit Frames.
--  items = EllesmereUI.VIS_OPT_ITEMS (or a subset)
--  getFn(key) -> bool, setFn(key, bool)
--  onMenuClosed (optional) fires once each time the open menu hides --
--  callers that defer page rebuilds while the menu is open flush there.
--  opts.dimLocked: locked rows dim their checkbox too, not only the label.
--  opts.noAllLabel: the summary names every checked row even when all are
--  checked (a selection, not a filter: never "All").
--  opts.countLabel: a partly checked list reads "3 of 5" instead of naming its
--  checked rows (a long list of names, such as characters); "All" and the
--  empty label stay.
--  opts.disabled (fn) + disabledTooltip/rawTooltip/requireState (as
--  ResolveDisabledTip): greyed and click-blocked while it answers true, the
--  reason on hover, re-checked with the page's widgets.
--  Returns: ddBtn, refreshFn. refreshFn(true) also reads a dynamic items list
--  again while the menu is closed, for a change made outside the menu.
-------------------------------------------------------------------------------
function EllesmereUI.BuildVisOptsCBDropdown(parentFrame, ddW, fLevel, items, getFn, setFn, onChanged, maxVisibleItems, searchable, closeButton, onMenuClosed, opts)
    -- Search prebuild on an absorber row: the dropdown indexes nothing, so none is built.
    local standIn = StandIn(parentFrame)
    if standIn then return standIn, standIn end
    local PP = EllesmereUI.PanelPP
    opts = opts or {}
    -- Opt-in dynamic items: pass a FUNCTION returning the items array and it re-evaluates on every menu OPEN (the menu rebuilds), so lists that depend on other settings never go stale. A table stays static.
    local itemsFn
    if type(items) == "function" then
        itemsFn = items
        items = itemsFn() or {}
    end
    local ddBtn = CreateFrame("Button", nil, parentFrame)
    -- This build's dress of the button: once a page pass hands the button out
    -- again (the options page pool), the new build owns it and this build's
    -- painters leave it alone (a setter's own rebuild, a kept refresher).
    local dressGen = PoolGen(ddBtn)
    PP.Size(ddBtn, ddW, 30)
    ddBtn:SetFrameLevel(fLevel)
    local ddBg = ddBtn:CreateTexture(nil, "BACKGROUND")
    ddBg:SetAllPoints()
    ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_A)
    local ddBrd = EllesmereUI.MakeRoundedBorder(ddBtn, 1, 1, 1, EllesmereUI.DD_BRD_A, ddBg)
    local ddLbl = ddBtn:CreateFontString(nil, "OVERLAY")
    -- Options panel is Expressway-locked by design (locale-aware: CJK/Cyrillic get the system glyph font). The user's global font intentionally does not restyle the settings UI.
    local fontPath = EllesmereUI.EXPRESSWAY or "Fonts\\FRIZQT__.TTF"
    ddLbl:SetFont(fontPath, 13, "")
    ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_A)
    ddLbl:SetJustifyH("LEFT")
    ddLbl:SetWordWrap(false)
    ddLbl:SetMaxLines(1)
    ddLbl:SetPoint("LEFT", ddBtn, "LEFT", 12, 0)
    local arrow = EllesmereUI.MakeDropdownArrow(ddBtn, 12, PP)
    ddLbl:SetPoint("RIGHT", arrow, "LEFT", -5, 0)

    local menu
    local function SummaryLabel()
        local names = {}
        local total = 0
        local hiddenCount = 0
        -- A LIVE override replaces the whole setting, whether it is being edited or just
        -- applied, so the summary is what it holds and nothing else. Mixing it with the
        -- rows below reads as one selection that exists nowhere ("Always or Solo"), and
        -- it is also the only place that still tells the truth while the rows underneath
        -- show the shared value they edit.
        local held = opts.ovHeldFn and opts.ovHeldFn()
        if held then
            for _, item in ipairs(items) do
                if item.key == held then return EllesmereUI.L(item.label) end
            end
        end
        for _, item in ipairs(items) do
            -- isModifier rows (the Visibility match toggle) are not conditions: excluded
            -- from the summary and from the "All" shortcut. item.excludeFromSummaryFn
            -- opts a row out the same way (e.g. locked behind an unlearned talent).
            if not item.isHeader and not item.isTopAction and not item.isModifier
               and not (item.excludeFromSummaryFn and item.excludeFromSummaryFn()) then
                total = total + 1
                if getFn(item.key) then names[#names + 1] = EllesmereUI.L(item.label) end
                -- Dual-lane rows: the hide lane reads through getFn(key, true).
                if item.dual and getFn(item.key, true) then hiddenCount = hiddenCount + 1 end
            end
        end
        local base
        -- opts.emptyLabel: the unified Visibility row reads "Always" with no show lane
        -- checked (an unconstrained element still shows), never "None".
        -- opts.separatorFn lets a modifier row rename the join, so the summary reads
        -- the way the conditions actually combine.
        local sep = opts.separatorFn and opts.separatorFn() or ", "
        if #names == 0 then base = opts.emptyLabel and EllesmereUI.L(opts.emptyLabel) or EllesmereUI.L("None")
        elseif #names == total and not opts.noAllLabel then base = EllesmereUI.L("All")
        elseif opts.countLabel then base = EllesmereUI.Lf("%1$d of %2$d", #names, total)
        else base = table.concat(names, sep) end
        if hiddenCount > 0 then base = base .. " (-" .. hiddenCount .. ")" end
        return base
    end
    local function UpdateLabel()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetText(SummaryLabel())
    end
    UpdateLabel()

    -- The menu and its fixed parts are built on the first open. A dynamic list
    -- (itemsFn) marks it stale on every open, and EnsureMenu then lays the same
    -- menu out again for the new items: rows come from per-kind pools (AcquireRow),
    -- and the ones a layout leaves unused are hidden.
    local menuStale
    local ITEM_H = 28
    local HDR_H = 22
    -- _allRows: { frame, isHeader, label(string), height } per laid-out row.
    -- Top-action locked tints refresh in the same sweeps as _allRows. They can't JOIN _allRows: the search relayout repositions every frame in that list, and top actions live above the search box.
    local _allRows, _taTints = {}, {}
    local sf, child, searchEdit, searchPlaceholder, taDivider, closeBtn, seal
    local UpdateCBThumb
    local rowPools = {}
    local function AcquireRow(kind, make, arg)
        local pool = rowPools[kind]
        if not pool then pool = { used = 0 }; rowPools[kind] = pool end
        pool.used = pool.used + 1
        local row = pool[pool.used]
        if not row then
            row = make(arg)
            pool[pool.used] = row
        end
        row:Show()
        return row
    end
    -- Label row: a top action (parent: the menu) or an action item (the scroll child).
    local function MakeTextRow(parent)
        local row = CreateFrame("Button", nil, parent)
        row:SetHeight(ITEM_H)
        local lbl = row:CreateFontString(nil, "OVERLAY")
        lbl:SetFont(fontPath, 13, "")
        lbl:SetPoint("LEFT", row, "LEFT", 10, 0)
        lbl:SetPoint("RIGHT", row, "RIGHT", -10, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        lbl:SetMaxLines(1)
        local hl = row:CreateTexture(nil, "ARTWORK")
        hl:SetAllPoints()
        row._lbl, row._hl = lbl, hl
        return row
    end
    local function MakeHeaderRow()
        local hdr = CreateFrame("Frame", nil, child)
        hdr:SetHeight(HDR_H)
        local hdrLbl = hdr:CreateFontString(nil, "OVERLAY")
        hdrLbl:SetFont(fontPath, 10, "")
        hdrLbl:SetTextColor(0.5, 0.5, 0.5, 1)
        hdrLbl:SetPoint("LEFT", hdr, "LEFT", 10, 0)
        hdrLbl:SetJustifyH("LEFT")
        local hdrLine = hdr:CreateTexture(nil, "ARTWORK")
        hdrLine:SetHeight(1)
        hdrLine:SetPoint("LEFT", hdrLbl, "RIGHT", 6, 0)
        hdrLine:SetColorTexture(0.3, 0.3, 0.3, 0.5)
        hdr._lbl, hdr._line = hdrLbl, hdrLine
        return hdr
    end
    -- Checkbox row with the parts its item's shape needs (check box, icon, hide
    -- lane, swatch); the pool key carries that shape, so a reused row has them.
    local function MakeCheckRow(item)
        local row = CreateFrame("Button", nil, child)
        row:SetHeight(ITEM_H)
        row:SetFrameLevel(menu:GetFrameLevel() + 2)
        if not item.noCheck then
            local box = CreateFrame("Frame", nil, row)
            box:SetSize(16, 16)
            box:SetPoint("LEFT", row, "LEFT", 10, 0)
            local boxBg = box:CreateTexture(nil, "BACKGROUND")
            boxBg:SetAllPoints()
            boxBg:SetColorTexture(0.114, 0.106, 0.099, 1)
            row._boxBrd = EllesmereUI.MakeRoundedBorder(box, 0.4, 0.4, 0.4, 0.6, boxBg)
            local chk = box:CreateTexture(nil, "ARTWORK")
            PP.SetInside(chk, box, 2, 2)
            chk:SetSnapToPixelGrid(false)
            EllesmereUI.RoundBody(box, chk, 2)
            row._box, row._chk = box, chk
        end
        -- Optional icon (spell icon etc.) between checkbox and label
        local lblAnchor = row._box
        if item.icon then
            local ico = row:CreateTexture(nil, "ARTWORK")
            if row._box then
                ico:SetPoint("LEFT", row._box, "RIGHT", 6, 0)
            else
                ico:SetPoint("LEFT", row, "LEFT", 10, 0)
            end
            ico:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            row._ico = ico
            lblAnchor = ico
        end
        local lbl = row:CreateFontString(nil, "OVERLAY")
        lbl:SetFont(fontPath, 13, "")
        if lblAnchor then
            lbl:SetPoint("LEFT", lblAnchor, "RIGHT", item.icon and 6 or 8, 0)
        else
            lbl:SetPoint("LEFT", row, "LEFT", 10, 0)
        end
        lbl:SetPoint("RIGHT", row, "RIGHT", (item.dual and not item.noCheck) and -32 or -10, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        lbl:SetMaxLines(1)
        local hl = row:CreateTexture(nil, "ARTWORK")
        hl:SetAllPoints()
        row._lbl, row._hl = lbl, hl
        if item.dual and not item.noCheck then
            local negBox = CreateFrame("Button", nil, row)
            negBox:SetSize(16, 16)
            negBox:SetPoint("RIGHT", row, "RIGHT", -10, 0)
            negBox:SetFrameLevel(row:GetFrameLevel() + 1)
            local negBg = negBox:CreateTexture(nil, "BACKGROUND")
            negBg:SetAllPoints()
            negBg:SetColorTexture(0.114, 0.106, 0.099, 1)
            row._negBrd = EllesmereUI.MakeRoundedBorder(negBox, 0.4, 0.4, 0.4, 0.6, negBg)
            local negChk = negBox:CreateTexture(nil, "ARTWORK")
            PP.SetInside(negChk, negBox, 2, 2)
            negChk:SetColorTexture(0.85, 0.3, 0.3, 1)
            negChk:SetSnapToPixelGrid(false)
            EllesmereUI.RoundBody(negBox, negChk, 2)
            row._negBox, row._negChk = negBox, negChk
        end
        if item.swatch then
            -- The swatch reads and writes the swatch spec of the item the row shows (row._swSpec).
            row._swSpec = item.swatch
            local sw, swUpdate = EllesmereUI.BuildColorSwatch(row, row:GetFrameLevel() + 1,
                function() return row._swSpec.get() end,
                function(...) row._swSpec.set(...) end,
                item.swatch.hasAlpha, 16)
            sw:ClearAllPoints()
            sw:SetPoint("RIGHT", row, "RIGHT", row._negBox and -32 or -10, 0)
            lbl:SetPoint("RIGHT", sw, "LEFT", -6, 0)
            local swBlock = CreateFrame("Frame", nil, sw)
            swBlock:SetAllPoints()
            swBlock:SetFrameLevel(sw:GetFrameLevel() + 10)
            swBlock:EnableMouse(true)
            swBlock:SetScript("OnEnter", function()
                local tip = EllesmereUI.ResolveDisabledTip(row._swSpec)
                if tip then EllesmereUI.ShowWidgetTooltip(sw, tip) end
            end)
            swBlock:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            swBlock:Hide()
            row._sw, row._swUpdate, row._swBlock = sw, swUpdate, swBlock
        end
        return row
    end

    local function EnsureMenu()
        if menu and not menuStale then return end
        menuStale = nil
        local firstBuild = not menu
        -- Opt-in top-action rows (item.isTopAction with label + onClick): accent clickable entries pinned ABOVE the search box with a divider under the group -- the "Custom Spell ID at the top" pattern from the CDM spell pickers. Excluded from the scroll list, the checkable count, and the summary label.
        local topActions = {}
        wipe(_taTints)
        for _, item in ipairs(items) do
            if item.isTopAction then topActions[#topActions + 1] = item end
        end
        local TOP_H = (#topActions > 0) and (#topActions * ITEM_H + 7) or 0
        local checkableCount = 0
        local contentH = 8
        for _, item in ipairs(items) do
            if item.isTopAction then -- rendered above the search box
            elseif item.isHeader then contentH = contentH + HDR_H
            else contentH = contentH + ITEM_H; checkableCount = checkableCount + 1 end
        end
        local SEARCH_H = searchable and 26 or 0
        -- The box plus its 4-unit gap: the menu reserves exactly what the scroll area skips.
        local SEARCH_PAD = searchable and (SEARCH_H + 4) or 0
        local CLOSE_BTN_H = closeButton and (6 + 26 + 6) or 0
        contentH = contentH + CLOSE_BTN_H
        local needsScroll = maxVisibleItems and checkableCount > maxVisibleItems
        -- +2 accounts for scroll frame 1px top + 1px bottom insets so non-scrolling menus don't scroll
        local menuH = (needsScroll and (4 + maxVisibleItems * ITEM_H + 4 + CLOSE_BTN_H) or (contentH + 4)) + SEARCH_PAD + TOP_H
        if firstBuild then
            -- One menu per dropdown button for the session: a build that dresses
            -- the button again gets this frame back here, reset to new.
            menu = PoolKept(ddBtn, "cbMenu", "Frame", EllesmereUI.OverlayParent())
        end
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetFrameLevel(200)
        menu:SetClampedToScreen(true)
        menu:EnableMouse(true)
        menu:SetSize(ddW, menuH)
        menu:ClearAllPoints()
        menu:SetPoint("TOPLEFT", ddBtn, "BOTTOMLEFT", 0, -2)
        menu:Hide()
        if firstBuild then
            -- Controller cursor: the list blocks what is under it but is not a stop itself;
            -- Cancel clicks the dropdown button (it toggles the list closed).
            if EllesmereUI.PadCP() then
                EllesmereUI.PadHint(menu, "nodepass")
                menu.CloseButton = ddBtn
            end
            local mBg = menu:CreateTexture(nil, "BACKGROUND")
            mBg:SetAllPoints()
            mBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_HA)
            EllesmereUI.MakeRoundedBorder(menu, 1, 1, 1, EllesmereUI.DD_BRD_A, mBg, nil, true)
        end
        local ppScale = EllesmereUI.GetPopupScale() or 1
        menu:SetScale(ppScale)
        for _, pool in pairs(rowPools) do pool.used = 0 end

        -- Top-action rows above the search box, divider under the group.
        if #topActions > 0 then
            local ay = -4
            for i = 1, #topActions do
                local item = topActions[i]
                local row = AcquireRow("ta", MakeTextRow, menu)
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, ay)
                row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, ay)
                row:SetFrameLevel(menu:GetFrameLevel() + 2)
                local lbl, hl = row._lbl, row._hl
                lbl:SetTextColor(EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b, 0.8)
                lbl:SetText(EllesmereUI.L(item.label))
                hl:SetColorTexture(1, 1, 1, 0)
                -- Opt-in locked state (item.lockedFn + item.lockedTooltip): evaluated LIVE on hover/click (checkbox toggles can flip it while the menu is open), plus once at build for the initial tint.
                local function TALocked()
                    return item.lockedFn and item.lockedFn() or false
                end
                local function TATint()
                    if TALocked() then
                        lbl:SetTextColor(1, 1, 1, 0.3)
                    else
                        lbl:SetTextColor(EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b, 0.8)
                    end
                end
                TATint()
                _taTints[#_taTints + 1] = TATint
                row:SetScript("OnEnter", function()
                    TATint()
                    if TALocked() then
                        local tip = item.lockedTooltip
                        if tip and EllesmereUI.ShowWidgetTooltip then
                            EllesmereUI.ShowWidgetTooltip(row, type(tip) == "function" and tip() or tip)
                        end
                        return
                    end
                    hl:SetColorTexture(1, 1, 1, 0.06)
                end)
                row:SetScript("OnLeave", function()
                    hl:SetColorTexture(1, 1, 1, 0)
                    EllesmereUI.HideWidgetTooltip()
                    TATint()
                end)
                row:SetScript("OnClick", function()
                    if TALocked() then return end
                    menu:Hide()
                    if item.onClick then item.onClick() end
                end)
                ay = ay - ITEM_H
            end
            if not taDivider then
                taDivider = menu:CreateTexture(nil, "ARTWORK")
                taDivider:SetHeight(1)
                taDivider:SetColorTexture(0.3, 0.3, 0.3, 0.5)
            end
            taDivider:ClearAllPoints()
            taDivider:SetPoint("TOPLEFT", menu, "TOPLEFT", 10, ay - 3)
            taDivider:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -10, ay - 3)
            taDivider:Show()
        elseif taDivider then
            taDivider:Hide()
        end

        -- Search box (optional)
        if searchable then
            if not searchEdit then
                searchEdit = CreateFrame("EditBox", nil, menu)
                searchEdit:SetFont(fontPath, 11, "")
                searchEdit:SetTextColor(1, 1, 1, 0.9)
                searchEdit:SetJustifyH("LEFT")
                searchEdit:SetAutoFocus(false)
                searchEdit:SetMaxLetters(30)
                -- Text at the check boxes' x (the scroll area sits 1 unit in, boxes 10 into a row).
                searchEdit:SetTextInsets(10, 10, 0, 0)
                local sDiv = searchEdit:CreateTexture(nil, "ARTWORK")
                sDiv:SetHeight(1)
                -- This list's own divider style (the top actions' divider above).
                sDiv:SetPoint("BOTTOMLEFT", searchEdit, "BOTTOMLEFT", 9, 0)
                sDiv:SetPoint("BOTTOMRIGHT", searchEdit, "BOTTOMRIGHT", -9, 0)
                sDiv:SetColorTexture(0.3, 0.3, 0.3, 0.5)
                searchPlaceholder = searchEdit:CreateFontString(nil, "OVERLAY")
                searchPlaceholder:SetFont(fontPath, 11, "")
                searchPlaceholder:SetTextColor(0.5, 0.5, 0.5, 0.6)
                searchPlaceholder:SetPoint("LEFT", searchEdit, "LEFT", 10, 0)
                searchPlaceholder:SetText(EllesmereUI.L("Search..."))
                searchEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
            end
            -- The list's flush first row: inside the border (below the top
            -- actions), its last unit the divider, the scroll area right below.
            searchEdit:ClearAllPoints()
            searchEdit:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, -1 - TOP_H)
            searchEdit:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, -1 - TOP_H)
            searchEdit:SetHeight(SEARCH_PAD - 1)
            searchEdit:SetFrameLevel(menu:GetFrameLevel() + 3)
        end

        -- Scroll frame for items
        if not sf then
            sf = CreateFrame("ScrollFrame", nil, menu)
            sf:EnableMouseWheel(true)
            child = CreateFrame("Frame", nil, sf)
            child:SetWidth(ddW - 2)
            sf:SetScrollChild(child)
            -- Thin scrollbar track (4px, right side, matching standard dropdown)
            local cbTrack = CreateFrame("Frame", nil, sf)
            cbTrack:SetWidth(4)
            cbTrack:SetPoint("TOPRIGHT", sf, "TOPRIGHT", -4, -4)
            cbTrack:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", -4, 4)
            cbTrack:SetFrameLevel(sf:GetFrameLevel() + 2)
            local cbTrackBg = cbTrack:CreateTexture(nil, "BACKGROUND")
            cbTrackBg:SetAllPoints()
            cbTrackBg:SetColorTexture(1, 1, 1, 0.02)

            local cbThumb = CreateFrame("Button", nil, cbTrack)
            cbThumb:SetWidth(4)
            cbThumb:SetFrameLevel(cbTrack:GetFrameLevel() + 1)
            cbThumb:EnableMouse(true)
            cbThumb:RegisterForDrag("LeftButton")
            local cbThumbBg = cbThumb:CreateTexture(nil, "ARTWORK")
            cbThumbBg:SetAllPoints()
            cbThumbBg:SetColorTexture(1, 1, 1, 0.27)
            -- Controller cursor: it scrolls the list to the row itself; the pointer-drag thumb is no stop.
            EllesmereUI.PadHint(cbThumb, "nodeignore")

            local function SafeMaxScroll()
                return math.max(0, child:GetHeight() - sf:GetHeight())
            end

            UpdateCBThumb = function()
                local maxScroll = SafeMaxScroll()
                if maxScroll <= 0 then cbTrack:Hide(); return end
                cbTrack:Show()
                local trackH = cbTrack:GetHeight()
                local visH = sf:GetHeight()
                local ratio = visH / (visH + maxScroll)
                local thumbH = math.max(20, trackH * ratio)
                cbThumb:SetHeight(thumbH)
                local scrollRatio = (tonumber(sf:GetVerticalScroll()) or 0) / maxScroll
                local maxTravel = trackH - thumbH
                cbThumb:ClearAllPoints()
                cbThumb:SetPoint("TOP", cbTrack, "TOP", 0, -(scrollRatio * maxTravel))
            end

            -- Thumb drag
            cbThumb:SetScript("OnMouseDown", function(self, button)
                if button ~= "LeftButton" then return end
                local _, cursorY = GetCursorPosition()
                local dragStartY = cursorY / self:GetEffectiveScale()
                local dragStartScroll = sf:GetVerticalScroll()
                self:SetScript("OnUpdate", function(self2)
                    if not IsMouseButtonDown("LeftButton") then
                        self2:SetScript("OnUpdate", nil)
                        return
                    end
                    local _, cy = GetCursorPosition()
                    cy = cy / self2:GetEffectiveScale()
                    local deltaY = dragStartY - cy
                    local trackH = cbTrack:GetHeight()
                    local maxTravel = trackH - self2:GetHeight()
                    if maxTravel <= 0 then return end
                    local maxScroll = SafeMaxScroll()
                    local newScroll = math.max(0, math.min(maxScroll,
                        dragStartScroll + (deltaY / maxTravel) * maxScroll))
                    sf:SetVerticalScroll(newScroll)
                    UpdateCBThumb()
                end)
            end)
            cbThumb:SetScript("OnMouseUp", function(self, button)
                if button ~= "LeftButton" then return end
                self:SetScript("OnUpdate", nil)
            end)

            sf:SetScript("OnMouseWheel", function(self, delta)
                local maxScroll = SafeMaxScroll()
                if maxScroll <= 0 then return end
                local cur = self:GetVerticalScroll()
                self:SetVerticalScroll(math.max(0, math.min(maxScroll, cur - delta * ITEM_H)))
                UpdateCBThumb()
            end)
        end
        local sfTop = -((SEARCH_PAD > 0 and SEARCH_PAD or 1) + TOP_H)
        sf:ClearAllPoints()
        sf:SetPoint("TOPLEFT", 1, sfTop)
        sf:SetPoint("BOTTOMRIGHT", -1, 1)
        child:SetHeight(contentH)
        sf:SetVerticalScroll(0)

        local yOff = -4
        wipe(_allRows)
        -- Published for the refreshers below: the rows are parented to the SCROLL CHILD,
        -- so a menu:GetChildren() walk never reaches them.
        menu._rows = _allRows
        for _, item in ipairs(items) do
            -- Top-action items render above the search box, never here.
            if item.isTopAction then -- luacheck: ignore (intentional empty)
            -- Header/divider items: non-interactive label
            elseif item.isHeader then
                local hdrH = HDR_H
                local hdr = AcquireRow("hdr", MakeHeaderRow)
                hdr:ClearAllPoints()
                hdr:SetPoint("TOPLEFT", child, "TOPLEFT", 1, yOff)
                hdr:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, yOff)
                hdr:SetFrameLevel(menu:GetFrameLevel() + 2)
                local hdrLine = hdr._line
                hdr._lbl:SetText(EllesmereUI.L(item.label))
                -- Opt-in right caption (item.rightLabel): labels the hide-lane column on dual menus.
                if item.rightLabel then
                    local hdrR = hdr._right
                    if not hdrR then
                        hdrR = hdr:CreateFontString(nil, "OVERLAY")
                        hdrR:SetFont(fontPath, 10, "")
                        hdrR:SetTextColor(0.5, 0.5, 0.5, 1)
                        hdrR:SetPoint("RIGHT", hdr, "RIGHT", -10, 0)
                        hdrR:SetJustifyH("RIGHT")
                        hdr._right = hdrR
                    end
                    hdrR:SetText(EllesmereUI.L(item.rightLabel))
                    hdrR:Show()
                    hdrLine:SetPoint("RIGHT", hdrR, "LEFT", -6, 0)
                else
                    if hdr._right then hdr._right:Hide() end
                    hdrLine:SetPoint("RIGHT", hdr, "RIGHT", -10, 0)
                end
                if item.tooltip then
                    hdr:EnableMouse(true)
                    hdr:SetScript("OnEnter", function()
                        EllesmereUI.ShowWidgetTooltip(hdr, item.tooltip)
                    end)
                    hdr:SetScript("OnLeave", function()
                        EllesmereUI.HideWidgetTooltip()
                    end)
                else
                    hdr:SetScript("OnEnter", nil)
                    hdr:SetScript("OnLeave", nil)
                    hdr:EnableMouse(false)
                end
                _allRows[#_allRows + 1] = { frame = hdr, isHeader = true, label = item.label, height = hdrH }
                yOff = yOff - hdrH
            elseif item.isAction then
                -- Action item: clickable text, no checkbox (for "All Specs", "All Healers", etc.)
                local row = AcquireRow("act", MakeTextRow, child)
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", child, "TOPLEFT", 1, yOff)
                row:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, yOff)
                row:SetFrameLevel(menu:GetFrameLevel() + 2)
                local lbl, hl = row._lbl, row._hl
                lbl:SetTextColor(EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b, 0.8)
                lbl:SetText(EllesmereUI.L(item.labelFn and item.labelFn() or item.label))
                local function UpdateActionLabel()
                    if item.labelFn then lbl:SetText(EllesmereUI.L(item.labelFn())) end
                end
                row._updateActionLabel = UpdateActionLabel
                hl:SetColorTexture(1, 1, 1, 0)
                local EG_r, EG_g, EG_b = EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b
                local function UpdateActionLocked()
                    local isLocked = item.lockedFn and item.lockedFn()
                    if isLocked then
                        lbl:SetTextColor(0.4, 0.4, 0.4, 0.4)
                        row:EnableMouse(false)
                    else
                        lbl:SetTextColor(EG_r, EG_g, EG_b, 0.8)
                        row:EnableMouse(true)
                    end
                end
                row._updateLocked = UpdateActionLocked
                UpdateActionLocked()
                row:SetScript("OnEnter", function() lbl:SetTextColor(1, 1, 1, 1); hl:SetColorTexture(1, 1, 1, 0.04) end)
                row:SetScript("OnLeave", function() UpdateActionLocked(); hl:SetColorTexture(1, 1, 1, 0) end)
                row:SetScript("OnClick", function()
                    if item.lockedFn and item.lockedFn() then return end
                    setFn(item.key, true)
                    -- Refresh all checkbox visuals + dynamic action labels
                    for _, r in ipairs(_allRows) do
                        if r.frame._updateCheck then r.frame._updateCheck() end
                        if r.frame._updateActionLabel then r.frame._updateActionLabel() end
                        if r.frame._updateLocked then r.frame._updateLocked() end
                    end
                    for i = 1, #_taTints do _taTints[i]() end
                    UpdateLabel()
                end)
                _allRows[#_allRows + 1] = { frame = row, isHeader = false, isAction = true, label = item.label, height = ITEM_H }
                yOff = yOff - ITEM_H
            else

            -- Opt-in plain rows (item.noCheck): the identical row minus the checkbox -- the regular-dropdown look for select-style pickers. Click still routes setFn(key, not getFn(key)), so a picker whose getFn is constant-false always selects with true.
            local shape = (item.noCheck and "n" or "c") .. (item.icon and "i" or "")
                .. ((item.dual and not item.noCheck) and "d" or "")
                .. (item.swatch and (item.swatch.hasAlpha and "A" or "s") or "")
            local row = AcquireRow("chk" .. shape, MakeCheckRow, item)
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", child, "TOPLEFT", 1, yOff)
            row:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, yOff)
            row:SetFrameLevel(menu:GetFrameLevel() + 2)
            row._isLocked = nil
            local box, boxBrd, chk = row._box, row._boxBrd, row._chk
            if chk then
                chk:SetColorTexture(EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b, 1)
                box:SetScript("OnEnter", nil)
                box:SetScript("OnLeave", nil)
                box:EnableMouse(false)
                box:SetAlpha(1)
            end
            -- Optional icon (spell icon etc.) between checkbox and label
            if row._ico then
                local icoSz = item.iconSize or (ITEM_H - 6)
                row._ico:SetSize(icoSz, icoSz)
                row._ico:SetTexture(item.icon)
            end
            -- Opt-in dimmed rows (item.dimFn): a pick that has no effect here right now
            -- (it shows somewhere else) rests dimmed but stays clickable, and hovering it
            -- shows item.dimTooltip (string or function) in place of item.tooltip.
            local function Dimmed()
                return (item.dimFn and item.dimFn()) and true or false
            end
            -- Modifier rows rest in the accent only while active; read live, since a
            -- sibling's click flips the checked state (UpdateCheck runs on every row).
            local function RestColor()
                if item.isModifier and getFn(item.key) then
                    return EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b
                end
                if Dimmed() then return 0.5, 0.5, 0.5 end
                return 0.75, 0.75, 0.75
            end
            local lbl, hl = row._lbl, row._hl
            lbl:SetTextColor(RestColor())
            lbl:SetText(EllesmereUI.L(item.label))
            hl:SetColorTexture(1, 1, 1, 0)
            -- Opt-in dual-lane rows (item.dual): a second right-aligned box is the HIDE lane.
            -- Lane state reads getFn(key, true) and writes setFn(key, v, true); the show lane
            -- keeps the plain getFn(key)/setFn(key, v) contract, so single-lane callers are
            -- untouched. item.showLockedFn dims the show lane; while it is locked, row clicks
            -- fall through to the hide lane (broad "All" modes already show everything).
            local negBox, negBrd, negChk = row._negBox, row._negBrd, row._negChk
            -- Opt-in colour swatch (item.swatch = { get = fn -> r, g, b, a, set = fn(r, g, b, a),
            -- hasAlpha, disabled = fn, disabledTooltip (+ rawTooltip / requireState, as
            -- ResolveDisabledTip) }): its own button at the row's right edge, so a click
            -- opens the colour picker and never toggles the row. While disabled it dims
            -- and a blocker takes its clicks and explains the requirement.
            local sw, swUpdate, swBlock = row._sw, row._swUpdate, row._swBlock
            if sw then row._swSpec = item.swatch end
            local function ShowLaneLocked()
                return item.showLockedFn and item.showLockedFn() or false
            end
            -- item.ovLockedFn is the override-session lock: it blocks the click like any
            -- other lock, but is painted and explained differently, because the row is not
            -- merely unavailable here -- it cannot be captured into an override at all.
            local function OvLocked()
                return (item.ovLockedFn and item.ovLockedFn()) and true or false
            end
            local function RowLocked()
                if OvLocked() or item.locked then return true end
                return (item.lockedFn and item.lockedFn()) and true or false
            end
            local function LockedTip()
                local lt = (OvLocked() and item.ovLockedTooltip) or item.lockedTooltip
                if type(lt) == "function" then lt = lt() end
                return lt
            end
            local function UpdateCheck()
                if chk then
                    if getFn(item.key) then
                        chk:Show()
                        boxBrd:SetColor(EllesmereUI.ELLESMERE_GREEN.r, EllesmereUI.ELLESMERE_GREEN.g, EllesmereUI.ELLESMERE_GREEN.b, 0.8)
                    else
                        chk:Hide()
                        boxBrd:SetColor(0.4, 0.4, 0.4, 0.6)
                    end
                    if box and item.dual then
                        local laneLocked = ShowLaneLocked()
                        box:SetAlpha(laneLocked and 0.3 or 1)
                        -- Mouse only while locked AND the item explains the
                        -- dim (item.showLockedTooltip): the disabled box then
                        -- swallows its own hover for the tooltip, and clicks,
                        -- like any disabled control. Unlocked, the box goes
                        -- mouse-inert again so the ROW keeps every click.
                        box:EnableMouse((laneLocked and item.showLockedTooltip) and true or false)
                    end
                end
                if negChk then
                    if getFn(item.key, true) then
                        negChk:Show()
                        negBrd:SetColor(0.85, 0.3, 0.3, 0.8)
                    else
                        negChk:Hide()
                        negBrd:SetColor(0.4, 0.4, 0.4, 0.6)
                    end
                end
                if sw then
                    swUpdate()
                    local off = item.swatch.disabled and item.swatch.disabled() or false
                    sw:SetAlpha(off and 0.3 or 1)
                    swBlock:SetShown(off and true or false)
                end
                -- Radio partners refresh each other, so this also runs on the hovered row;
                -- repainting that one would drop its hover white until the mouse re-enters.
                if item.isModifier and not row._isLocked and not row:IsMouseOver() then
                    lbl:SetTextColor(RestColor())
                end
            end
            UpdateCheck()
            row._updateCheck = UpdateCheck
            row:SetScript("OnEnter", function()
                if row._isLocked then
                    -- Locked rows keep the gray look (no highlight); if the item explains its lock, show that instead of the normal tooltip.
                    local lt = LockedTip()
                    if lt then
                        EllesmereUI.ShowWidgetTooltip(row, lt)
                    end
                    return
                end
                lbl:SetTextColor(1, 1, 1, 1)
                hl:SetColorTexture(1, 1, 1, 0.04)
                local tip = item.tooltip
                if item.dimTooltip and Dimmed() then tip = item.dimTooltip end
                if type(tip) == "function" then tip = tip() end
                if tip then
                    EllesmereUI.ShowWidgetTooltip(row, tip)
                end
            end)
            row:SetScript("OnLeave", function()
                if row._isLocked then
                    if item.lockedTooltip or item.ovLockedTooltip then
                        EllesmereUI.HideWidgetTooltip()
                    end
                    return
                end
                lbl:SetTextColor(RestColor())
                hl:SetColorTexture(1, 1, 1, 0)
                if item.tooltip or item.dimTooltip then
                    EllesmereUI.HideWidgetTooltip()
                end
            end)
            local function UpdateLocked()
                local isLocked = RowLocked()
                -- Mouse stays enabled so locked rows can explain themselves on hover; clicks are guarded independently in OnClick.
                row._isLocked = isLocked and true or false
                if isLocked then
                    lbl:SetTextColor(0.4, 0.4, 0.4, 0.5)
                else
                    lbl:SetTextColor(RestColor())
                end
                -- opts.dimLocked: a locked row's checkbox dims with its label, so a
                -- checked one reads as fixed rather than clickable (dual rows keep
                -- their own lane dimming).
                if opts.dimLocked and box and not item.dual then
                    box:SetAlpha(isLocked and 0.4 or 1)
                end
            end
            row._updateLocked = UpdateLocked
            UpdateLocked()
            -- snap: the slot snapshot the click took before its setter ran
            -- (EllesmereUI._SOAttribution), or nil.
            local function AfterToggle(snap)
                -- opts.notifyWrites: join the primary capture path every other widget's
                -- setter uses. Without it a checklist has only the polling fallback,
                -- whose mouse attribution is CLEARED while the menu (a UIParent child
                -- with no popup marker) holds focus, so an override session never sees
                -- the write when it happens. ddBtn's parent carries the row's
                -- _captureCfg, so the slot is attributed exactly. Opt-in: every other
                -- checklist keeps the behaviour it has always had.
                if opts.notifyWrites then
                    EllesmereUI._NotifySettingWrite(ddBtn, snap)
                end
                UpdateLabel()
                -- Refresh checkbox visuals + dynamic action labels, so items whose checked state depends on others (e.g. "Always" in crosshair) update live. Locked visuals refresh too, so rows whose lockedFn depends on the current selection never show a stale gray/active state.
                for _, r in ipairs(_allRows) do
                    if r.frame._updateCheck then r.frame._updateCheck() end
                    if r.frame._updateActionLabel then r.frame._updateActionLabel() end
                    if r.frame._updateLocked then r.frame._updateLocked() end
                end
                for i = 1, #_taTints do _taTints[i]() end
                if onChanged then
                    -- Anchor menu to absolute screen position BEFORE callback so a page rebuild (which destroys
                    -- ddBtn) can't shift us. GetCenter and SetPoint offsets are both in the menu's own coordinate
                    -- space, so the values pass through unscaled -- scaling them by effective-scale ratios made
                    -- the menu creep toward the bottom-left on every click when the options panel scale differs from UIParent's.
                    local cx, cy = menu:GetCenter()
                    menu:ClearAllPoints()
                    menu:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
                    onChanged()
                end
            end
            row:SetScript("OnClick", function()
                if RowLocked() then return end
                -- The slot the write belongs to, taken before the setter runs: a
                -- setter that rebuilds the page can dress ddBtn for another slot.
                local snap = opts.notifyWrites and EllesmereUI._SOAttribution(ddBtn) or nil
                -- The slot's Apply to link stays a few seconds after the pick.
                EllesmereUI._SyncPickNotice(ddBtn)
                if negBox and ShowLaneLocked() then
                    setFn(item.key, not getFn(item.key, true), true)
                else
                    setFn(item.key, not getFn(item.key))
                end
                AfterToggle(snap)
            end)
            if negBox then
                negBox:SetScript("OnClick", function()
                    if RowLocked() then return end
                    local snap = opts.notifyWrites and EllesmereUI._SOAttribution(ddBtn) or nil
                    EllesmereUI._SyncPickNotice(ddBtn)
                    setFn(item.key, not getFn(item.key, true), true)
                    AfterToggle(snap)
                end)
                negBox:SetScript("OnEnter", function()
                    if row._isLocked then
                        local lt = LockedTip()
                        if lt then EllesmereUI.ShowWidgetTooltip(negBox, lt) end
                        return
                    end
                    lbl:SetTextColor(1, 1, 1, 1)
                    hl:SetColorTexture(1, 1, 1, 0.04)
                    local hlt = opts.hideLaneTooltip
                    if type(hlt) == "function" then hlt = hlt(item.key) end
                    EllesmereUI.ShowWidgetTooltip(negBox,
                        hlt and EllesmereUI.L(hlt)
                        or EllesmereUI.L("Hide these instead of showing them"))
                end)
                negBox:SetScript("OnLeave", function()
                    if not row._isLocked then lbl:SetTextColor(RestColor()) end
                    hl:SetColorTexture(1, 1, 1, 0)
                    EllesmereUI.HideWidgetTooltip()
                end)
                -- The SHOW box mirrors the hide box's self-explanation, but
                -- only while a broad mode locks the lane: UpdateCheck enables
                -- its mouse exactly then, so these scripts never fire for an
                -- active lane and row clicks stay untouched.
                if box then
                    box:SetScript("OnEnter", function()
                        lbl:SetTextColor(1, 1, 1, 1)
                        hl:SetColorTexture(1, 1, 1, 0.04)
                        local tt = item.showLockedTooltip
                        if type(tt) == "function" then tt = tt() end
                        if tt then EllesmereUI.ShowWidgetTooltip(box, tt) end
                    end)
                    box:SetScript("OnLeave", function()
                        if not row._isLocked then lbl:SetTextColor(RestColor()) end
                        hl:SetColorTexture(1, 1, 1, 0)
                        EllesmereUI.HideWidgetTooltip()
                    end)
                end
            end
            -- Marks the contiguous run the override overlay below seals off.
            row._ovBlock = item.ovLockedFn and true or nil
            _allRows[#_allRows + 1] = { frame = row, isHeader = false, label = item.label, height = ITEM_H }
            yOff = yOff - ITEM_H

            end -- isHeader else
        end

        -- Override session: the excluded rows are sealed off as ONE block rather than
        -- marked one by one -- 1px red border, a 5% red wash, a lock glyph with a caption
        -- and a click blocker holding the explanation, the same treatment SetSlotMark
        -- gives an override-red slot in the panel.
        -- Parented to the scroll child so it travels with the rows.
        if opts.ovLockedFn then
            local first, last
            for i = 1, #_allRows do
                if _allRows[i].frame._ovBlock then
                    -- A header sitting directly on top of the run introduces it.
                    if not first then
                        first = (i > 1 and _allRows[i - 1].isHeader) and (i - 1) or i
                    end
                    last = i
                end
            end
            if first and last then
                if not seal then
                    seal = CreateFrame("Button", nil, child)
                    seal:SetFrameLevel(menu:GetFrameLevel() + 8)
                    local wash = seal:CreateTexture(nil, "BACKGROUND")
                    wash:SetAllPoints()
                    wash:SetColorTexture(0.9, 0.2, 0.2, 0.05)
                    if PP and PP.CreateBorder then
                        PP.CreateBorder(seal, 0.9, 0.2, 0.2, 0.9, 1, "OVERLAY", 7)
                    end
                    -- Caption on the block's top edge rather than across its middle: the wash
                    -- is deliberately faint, so a centred label would land on readable rows.
                    local sealLbl = seal:CreateFontString(nil, "OVERLAY", nil, 7)
                    sealLbl:SetFont(fontPath, 11, "")
                    sealLbl:SetTextColor(1, 0.35, 0.35, 1)
                    sealLbl:SetPoint("TOPRIGHT", seal, "TOPRIGHT", -6, -5)
                    sealLbl:SetText(EllesmereUI.L("Not overridable"))
                    -- The section header's divider line runs straight THROUGH the caption at
                    -- this height. A plate in the menu's own background colour cuts the line
                    -- for the width of the text: the seal sits at a higher frame level than
                    -- the header, so anything it draws covers that line.
                    local plate = seal:CreateTexture(nil, "ARTWORK", nil, 6)
                    plate:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G,
                        EllesmereUI.DD_BG_B, 1)
                    plate:SetPoint("TOPLEFT", sealLbl, "TOPLEFT", -5, 2)
                    plate:SetPoint("BOTTOMRIGHT", sealLbl, "BOTTOMRIGHT", 5, -2)
                    seal:EnableMouse(true)
                    seal:SetScript("OnEnter", function(self)
                        if opts.ovLockedTooltip then
                            EllesmereUI.ShowWidgetTooltip(self, opts.ovLockedTooltip)
                        end
                    end)
                    seal:SetScript("OnLeave", function()
                        EllesmereUI.HideWidgetTooltip()
                    end)
                end
                seal:ClearAllPoints()
                seal:SetPoint("TOPLEFT", _allRows[first].frame, "TOPLEFT", 1, 0)
                -- The 4px scrollbar track sits 4px off the right edge, ON the scroll
                -- frame rather than in here, so the seal stops short of it instead of
                -- running underneath and having the bar cut through its border.
                seal:SetPoint("BOTTOMRIGHT", _allRows[last].frame, "BOTTOMRIGHT", -9, 0)
                seal:SetFrameLevel(menu:GetFrameLevel() + 8)
                menu._ovSeal = seal
                seal:SetShown(opts.ovLockedFn())
            else
                menu._ovSeal = nil
                if seal then seal:Hide() end
            end
        end

        -- Close button at bottom of dropdown (optional)
        if closeButton then
            local CLOSE_H = 26
            local closePad = 6
            yOff = yOff - closePad
            local EG = EllesmereUI.ELLESMERE_GREEN or { r = 0.05, g = 0.82, b = 0.62 }
            if not closeBtn then
                closeBtn = CreateFrame("Button", nil, child)
                closeBtn:SetHeight(CLOSE_H)
                local closeBtnW = math.floor((ddW - 2) * 0.75)
                closeBtn:SetWidth(closeBtnW)
                closeBtn:SetFrameLevel(menu:GetFrameLevel() + 3)
                local closeBg = closeBtn:CreateTexture(nil, "BACKGROUND")
                closeBg:SetAllPoints()
                closeBtn._bg = closeBg
                local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
                closeLbl:SetFont(fontPath, 12, "")
                closeLbl:SetPoint("CENTER")
                closeLbl:SetText(EllesmereUI.L(type(closeButton) == "string" and closeButton or "Okay"))
                closeLbl:SetTextColor(1, 1, 1, 1)
                closeBtn:SetScript("OnClick", function() menu:Hide() end)
                closeBtn:SetScript("OnEnter", function() closeBg:SetColorTexture(EG.r, EG.g, EG.b, 1) end)
                closeBtn:SetScript("OnLeave", function() closeBg:SetColorTexture(EG.r, EG.g, EG.b, 0.85) end)
            end
            closeBtn._bg:SetColorTexture(EG.r, EG.g, EG.b, 0.85)
            closeBtn:ClearAllPoints()
            closeBtn:SetPoint("TOP", child, "TOPLEFT", (ddW - 2) / 2, yOff)
            closeBtn:SetFrameLevel(menu:GetFrameLevel() + 3)
            yOff = yOff - CLOSE_H - closePad
        end

        child:SetHeight(math.max(1, math.abs(yOff)))

        -- Rows a dynamic list no longer uses stay pooled, hidden and inert.
        for _, pool in pairs(rowPools) do
            for i = pool.used + 1, #pool do
                local r = pool[i]
                r:Hide()
                r._updateCheck, r._updateLocked, r._updateActionLabel = nil, nil, nil
            end
        end
        if not firstBuild then return end

        -- Wire search filtering
        if searchEdit then
            searchEdit:SetScript("OnTextChanged", function(self)
                local t = strlower(strtrim(self:GetText()))
                searchPlaceholder:SetShown(t == "")
                local visY = -4
                local lastHdr = nil
                local lastHdrY = 0
                local hdrHasVisible = false
                for _, r in ipairs(_allRows) do
                    if r.isHeader then
                        -- Defer header: show only if a child is visible
                        if lastHdr and not hdrHasVisible then lastHdr:Hide() end
                        lastHdr = r.frame
                        lastHdrY = visY
                        hdrHasVisible = false
                        if t == "" then
                            lastHdr:Show()
                            lastHdr:ClearAllPoints()
                            lastHdr:SetPoint("TOPLEFT", child, "TOPLEFT", 1, visY)
                            lastHdr:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, visY)
                            visY = visY - r.height
                            hdrHasVisible = true
                        end
                    else
                        if t == "" or strfind(strlower(r.label), t, 1, true) then
                            -- Show header if this is the first visible child
                            if lastHdr and not hdrHasVisible then
                                lastHdr:Show()
                                lastHdr:ClearAllPoints()
                                lastHdr:SetPoint("TOPLEFT", child, "TOPLEFT", 1, lastHdrY)
                                lastHdr:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, lastHdrY)
                                visY = lastHdrY - HDR_H
                                hdrHasVisible = true
                            end
                            r.frame:Show()
                            r.frame:ClearAllPoints()
                            r.frame:SetPoint("TOPLEFT", child, "TOPLEFT", 1, visY)
                            r.frame:SetPoint("TOPRIGHT", child, "TOPRIGHT", -1, visY)
                            visY = visY - r.height
                        else
                            r.frame:Hide()
                        end
                    end
                end
                -- Hide trailing header with no visible children
                if lastHdr and not hdrHasVisible then lastHdr:Hide() end
                -- The override seal is anchored to the FIRST and LAST row of its run,
                -- which this filter hides and repositions without touching the seal. Drop
                -- it while a filter is active rather than re-deriving the run: with rows
                -- missing there is no contiguous block left to mark, and a stale seal is a
                -- mouse-enabled frame parked over whatever rows did survive.
                if menu._ovSeal then
                    menu._ovSeal:SetShown(t == "" and opts.ovLockedFn
                        and opts.ovLockedFn() or false)
                end
                child:SetHeight(math.max(1, math.abs(visY)))
                sf:SetVerticalScroll(0)
                UpdateCBThumb()
            end)
            menu:HookScript("OnShow", function()
                searchEdit:SetText("")
                -- Not under the controller cursor: focus would pop its on-screen keyboard over the list.
                if not EllesmereUI.PadCursorShown() then searchEdit:SetFocus() end
                UpdateCBThumb()
            end)
        end

        menu:HookScript("OnShow", UpdateCBThumb)

        -- Refresh all checkbox + locked visuals on show
        menu:HookScript("OnShow", function()
            for _, rowInfo in ipairs(_allRows) do
                if rowInfo.frame._updateCheck then rowInfo.frame._updateCheck() end
                if rowInfo.frame._updateLocked then rowInfo.frame._updateLocked() end
            end
            for i = 1, #_taTints do _taTints[i]() end
        end)

        if EllesmereUI.PadCP() then
            -- Controller cursor (ShowMenu calls this only while it is shown): list back
            -- to the top, cursor onto the first row.
            menu._padFocus = function()
                sf:SetVerticalScroll(0)
                UpdateCBThumb()
                local first
                for i = 1, #_allRows do
                    local r = _allRows[i]
                    if not r.isHeader and r.frame:IsShown() then first = r.frame; break end
                end
                EllesmereUI.PadFocus(first or menu)
            end
            EllesmereUI.TrackOverlay(menu)
        end
        ddBtn._ddMenu = menu
    end

    local function ApplyNormal()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_A)
        ddBrd:SetColor(1, 1, 1, EllesmereUI.DD_BRD_A)
        ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_A)
    end
    local function ApplyHover()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_HA)
        ddBrd:SetColor(1, 1, 1, EllesmereUI.DD_BRD_HA)
        ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_HA)
    end
    ddBtn:SetScript("OnEnter", function()
        ApplyHover()
        if not (menu and menu:IsShown()) then EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl) end
    end)
    ddBtn:SetScript("OnLeave", function()
        if not (menu and menu:IsShown()) then
            ApplyNormal()
        end
        EllesmereUI._widgetInternals.HideDropdownTip(ddBtn)
    end)

    local function ShowMenu()
        -- Dynamic items: re-evaluate and lay the menu out again on every open (only when about to show -- a toggle-close never rebuilds).
        if itemsFn and not (menu and menu:IsShown()) then
            items = itemsFn() or {}
            if menu then
                menu:Hide()
                menuStale = true
            end
            UpdateLabel()
        end
        EnsureMenu()
        if menu:IsShown() then
            menu:Hide()
            return
        end
        -- A static menu is built once and reused, so anything that changed while it was
        -- closed would show stale: refresh checked state AND locks on every open. The
        -- case that matters is an override session starting between two opens.
        for _, r in ipairs(menu._rows or {}) do
            if r.frame._updateCheck then r.frame._updateCheck() end
            if r.frame._updateLocked then r.frame._updateLocked() end
        end
        if menu._ovSeal then menu._ovSeal:SetShown(opts.ovLockedFn()) end
        -- Match the panel's effective scale since menu lives on UIParent
        local btnScale = ddBtn:GetEffectiveScale()
        local uiScale = UIParent:GetEffectiveScale()
        menu:SetScale(btnScale / uiScale)
        EllesmereUI.SeatDropdownMenu(menu)
        ApplyHover()
        menu:Show()
        -- Track the open menu globally so popup outside-click watchers don't treat clicks on rows that extend below the popup as a dismissing outside click.
        EllesmereUI._openDropdownMenu = menu
        menu:SetScript("OnUpdate", function(self)
            -- Close when left-clicking outside the menu and button. The shared colour
            -- picker is a separate popup a row swatch opens: working in it keeps the menu.
            local cp = EllesmereUI._colorPickerPopup
            if not self:IsMouseOver() and not ddBtn:IsMouseOver() and IsMouseButtonDown("LeftButton")
                and not (cp and cp:IsShown()) then
                self:Hide()
                return
            end
            -- Close when the dropdown button scrolls out of the visible area
            local scrollFrame = EllesmereUI._scrollFrame
            if scrollFrame then
                if ddBtn._inScrollChild == nil then
                    local scrollChild = scrollFrame.GetScrollChild and scrollFrame:GetScrollChild()
                    local found = false
                    if scrollChild then
                        local p = ddBtn:GetParent()
                        while p do
                            if p == scrollChild then found = true; break end
                            p = p:GetParent()
                        end
                    end
                    ddBtn._inScrollChild = found
                end
                if ddBtn._inScrollChild then
                    local sfTop = scrollFrame:GetTop()
                    local sfBot = scrollFrame:GetBottom()
                    local btnBot = ddBtn:GetBottom()
                    if sfTop and sfBot and btnBot then
                        if btnBot < sfBot or btnBot > sfTop then self:Hide() end
                    end
                end
            end
        end)
        menu:SetScript("OnHide", function(self)
            self:SetScript("OnUpdate", nil)
            if EllesmereUI._openDropdownMenu == self then EllesmereUI._openDropdownMenu = nil end
            if ddBtn:IsMouseOver() then
                ApplyHover()
                EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl)
            else
                ApplyNormal()
            end
            if onMenuClosed then onMenuClosed() end
            -- Controller cursor: back onto the dropdown button (a no-op once that is hidden too).
            if EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(ddBtn) end
        end)
        if menu._padFocus and EllesmereUI.PadCursorShown() then menu._padFocus() end
    end

    ddBtn:SetScript("OnClick", function() EllesmereUI._widgetInternals.HideDropdownTip(ddBtn); ShowMenu() end)
    ddBtn:HookScript("OnHide", function() if menu then menu:Hide() end end)

    -- RefreshAll(true), opt-in: a dynamic list is read again first, so the summary
    -- names a change made outside the menu while it is closed (an entry typed into
    -- a popup). A page refresh calls it with no argument and reads nothing again.
    local function RefreshAll(reread)
        -- A caller may keep this past a page pass that dressed ddBtn (and with it
        -- the kept menu) for another build.
        if PoolGen(ddBtn) ~= dressGen then return end
        if reread == true and itemsFn and not (menu and menu:IsShown()) then
            items = itemsFn() or {}
        end
        UpdateLabel()
        if menu then
            for _, r in ipairs(menu._rows or {}) do
                if r.frame._updateCheck then r.frame._updateCheck() end
                if r.frame._updateLocked then r.frame._updateLocked() end
            end
            if menu._ovSeal then menu._ovSeal:SetShown(opts.ovLockedFn()) end
        end
    end

    if opts.disabled then
        local block = CreateFrame("Frame", nil, ddBtn)
        block:SetAllPoints()
        block:SetFrameLevel(ddBtn:GetFrameLevel() + 20)
        block:EnableMouse(true)
        block:SetScript("OnEnter", function()
            local tip = EllesmereUI.ResolveDisabledTip(opts)
            if tip then EllesmereUI.ShowWidgetTooltip(ddBtn, tip) end
        end)
        block:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
        local function DisabledState()
            local off = opts.disabled() and true or false
            ddBtn:SetAlpha(off and 0.4 or 1)
            block:SetShown(off)
            if off and menu then menu:Hide() end
        end
        DisabledState()
        EllesmereUI.RegisterWidgetRefresh(DisabledState)
    end
    return ddBtn, RefreshAll
end

-------------------------------------------------------------------------------
--  Spec picker items for BuildVisOptsCBDropdown (the "Select a Spec" lists):
--  "All Specs" first (key EllesmereUI.SPEC_PICK_ALL, an action row), then on
--  retail every class's specs under its class header, classes in alphabetical
--  order, with opts.roles adding the All Healers / All Tanks / All DPS action
--  rows (keys SPEC_PICK_HEALERS / _TANKS / _DPS) after it. WoW Forever lists
--  one row per class instead, keyed by its class token and standing for every
--  retail spec of the class (EllesmereUI.ForeverClassSpecIDs; the caller's
--  getter and setter expand it), and no role rows. opts.allLockedFn locks the
--  action rows; opts.lockedFn(specID) locks a spec row, and a Forever class row
--  while any spec of its class is locked. Returns the items and the role table
--  ({ [SPEC_PICK_HEALERS] = spec IDs, ... }, empty on Forever).
-------------------------------------------------------------------------------
EllesmereUI.SPEC_PICK_ALL, EllesmereUI.SPEC_PICK_HEALERS = 0, -1
EllesmereUI.SPEC_PICK_TANKS, EllesmereUI.SPEC_PICK_DPS = -2, -3
function EllesmereUI.SpecPickItems(opts)
    opts = opts or {}
    local lockedFn, allLockedFn = opts.lockedFn, opts.allLockedFn
    local items, roles = {}, {}
    items[1] = { key = EllesmereUI.SPEC_PICK_ALL, label = "All Specs", isAction = true, lockedFn = allLockedFn }
    if EllesmereUI.IS_FOREVER then
        local classes = EllesmereUI.ForeverClasses()
        for n = 1, #classes do
            local token = classes[n]
            local ids = EllesmereUI.ForeverClassSpecIDs(token)
            items[#items + 1] = { key = token, label = EllesmereUI.ForeverClassName(token),
                lockedFn = lockedFn and function()
                    for i = 1, #ids do
                        if lockedFn(ids[i]) then return true end
                    end
                    return false
                end or nil }
        end
        return items, roles
    end
    if opts.roles then
        items[#items + 1] = { key = EllesmereUI.SPEC_PICK_HEALERS, label = "All Healers", isAction = true, lockedFn = allLockedFn }
        items[#items + 1] = { key = EllesmereUI.SPEC_PICK_TANKS, label = "All Tanks", isAction = true, lockedFn = allLockedFn }
        items[#items + 1] = { key = EllesmereUI.SPEC_PICK_DPS, label = "All DPS", isAction = true, lockedFn = allLockedFn }
    end
    local classList = {}
    for classID = 1, (GetNumClasses and GetNumClasses() or 13) do
        local className = GetClassInfo(classID)
        if className then
            classList[#classList + 1] = { classID = classID, className = className }
        end
    end
    table.sort(classList, function(a, b) return a.className < b.className end)
    local healers, tanks, dps = {}, {}, {}
    for _, cls in ipairs(classList) do
        items[#items + 1] = { isHeader = true, label = cls.className }
        for specIndex = 1, (C_SpecializationInfo.GetNumSpecializationsForClassID(cls.classID) or 0) do
            local specID, specName, _, _, role = GetSpecializationInfoForClassID(cls.classID, specIndex)
            if specID and specName then
                local sid = specID
                items[#items + 1] = { key = specID, label = specName,
                    lockedFn = lockedFn and function() return lockedFn(sid) end or nil }
                if role == "HEALER" then healers[#healers + 1] = specID
                elseif role == "TANK" then tanks[#tanks + 1] = specID
                else dps[#dps + 1] = specID end
            end
        end
    end
    roles[EllesmereUI.SPEC_PICK_HEALERS] = healers
    roles[EllesmereUI.SPEC_PICK_TANKS] = tanks
    roles[EllesmereUI.SPEC_PICK_DPS] = dps
    return items, roles
end

-------------------------------------------------------------------------------
--  AttachRowReorder
--  Drag-to-reorder for a column of rows at fixed slots in a host frame (the
--  reorder dropdown's movable rows, the Cooldown Manager's Combat Potion
--  priority rows): a 3px drag threshold, the dragged row floating with the
--  cursor, an insertion line at the gap it points at, and a drop that shuffles
--  the ITEMS (spec.items, in place) while the row frames keep their slots.
--  spec = {
--      rows    = { row, ... },       -- row._item (its item), row._slotY (its slot's y)
--      items   = { item, ... },      -- in row order; item.key; mutated on a drop
--      itemH   = number,             -- the row height
--      slotY   = function(i),        -- y of slot i from the host's top (slot 1 highest)
--      insLine = texture,            -- the insertion line, on the host, hidden
--      state   = { dragging = false },  -- read by the rows' own hover/click scripts
--      refresh = function(),         -- repaint every row from spec.items
--      onDrop  = function(keys),     -- after a drop that changed the order
--      canReorder  = function() -> boolean,  -- optional drag guard
--      onDragStart = function(row),  -- optional, as the drag begins
--  }
--  Rows anchor TOPLEFT (1, slotY) / TOPRIGHT (-1, slotY) to the host at the
--  host's level + 2 and float at + 10. Every row gets row:_cancelDrag().
-------------------------------------------------------------------------------
function EllesmereUI.AttachRowReorder(host, spec)
    local rows, movable, ITEM_H, SlotY = spec.rows, spec.items, spec.itemH, spec.slotY
    local insLine, state = spec.insLine, spec.state
    -- Read live: a host raised after this call (a cog popup lifts its open
    -- dropdown menu) would otherwise park dropped rows behind its background.
    local function BaseLevel() return host:GetFrameLevel() + 2 end
    local function Park(row)
        row:SetFrameLevel(BaseLevel())
        row:SetAlpha(1)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", host, "TOPLEFT", 1, row._slotY)
        row:SetPoint("TOPRIGHT", host, "TOPRIGHT", -1, row._slotY)
    end
    -- Gap index (1..#items+1) the cursor points at: walk the slot midpoints, skipping the dragged row's own slot -- the same logic as the raid frames Sort By reorder menu, so the insertion line and the drop target always agree.
    local function TargetGap(cursorY, fromIdx)
        local mT = host:GetTop() or 0
        local iI = #movable
        for i = 1, #movable do
            if i ~= fromIdx then
                local mid = mT + SlotY(i) - ITEM_H / 2
                if cursorY > mid then iI = i; break end
                iI = i + 1
            end
        end
        return math.max(1, math.min(iI, #movable + 1))
    end
    for i = 1, #rows do
        local row = rows[i]
        local dsY, dgO, dgFrom
        local DragUpdate
        row:SetScript("OnMouseDown", function(self, b)
            if b ~= "LeftButton" then return end
            row._suppressClick = nil
            if spec.canReorder and not spec.canReorder() then return end
            local _, cy = GetCursorPosition()
            dsY = cy
            self:SetScript("OnUpdate", DragUpdate)
        end)
        row:SetScript("OnMouseUp", function(self, b)
            if b ~= "LeftButton" then return end
            dsY = nil
            self:SetScript("OnUpdate", nil)
            if not state.dragging then return end
            self._suppressClick = true
            state.dragging = false
            insLine:Hide()
            -- Snap the floated row back to its slot
            Park(self)
            if spec.canReorder and not spec.canReorder() then
                spec.refresh()
                return
            end
            local _, cy = GetCursorPosition()
            cy = cy / host:GetEffectiveScale()
            local from
            for mi = 1, #movable do
                if movable[mi] == self._item then from = mi; break end
            end
            -- Gap -> insertion index: removing the row first shifts everything after it up one, so downward moves adjust by -1 (same as the raid frames Sort By drop).
            local iI = TargetGap(cy, from)
            if from and from < iI then iI = iI - 1 end
            local to = math.max(1, math.min(iI, #movable))
            if from and from ~= to then
                local mv = table.remove(movable, from)
                table.insert(movable, to, mv)
                if spec.onDrop then
                    local keys = {}
                    for mi = 1, #movable do keys[mi] = movable[mi].key end
                    spec.onDrop(keys)
                end
            end
            spec.refresh()
        end)
        DragUpdate = function(self)
            if not dsY then return end
            local _, cy = GetCursorPosition()
            if not state.dragging then
                if math.abs(cy - dsY) < 3 then return end
                state.dragging = true
                local sc = host:GetEffectiveScale()
                dgO = (cy / sc) - (self:GetTop() or 0)
                dgFrom = nil
                for mi = 1, #movable do
                    if movable[mi] == self._item then dgFrom = mi; break end
                end
                self:SetFrameLevel(BaseLevel() + 8)
                self:SetAlpha(0.8)
                if spec.onDragStart then spec.onDragStart(self) end
            end
            local sc = host:GetEffectiveScale()
            local cY = cy / sc
            local mT = host:GetTop() or 0
            local lY = cY - (dgO or 0) - mT
            lY = math.max(SlotY(#movable), math.min(lY, SlotY(1)))
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", host, "TOPLEFT", 1, lY)
            self:SetPoint("TOPRIGHT", host, "TOPRIGHT", -1, lY)
            local lnY = SlotY(TargetGap(cY, dgFrom)) + 1
            insLine:ClearAllPoints()
            insLine:SetPoint("TOPLEFT", host, "TOPLEFT", 8, lnY)
            insLine:SetPoint("TOPRIGHT", host, "TOPRIGHT", -8, lnY)
            insLine:Show()
        end
        row._cancelDrag = function(self)
            if not dsY then return end
            dsY = nil
            self:SetScript("OnUpdate", nil)
            Park(self)
        end
    end
end

-------------------------------------------------------------------------------
--  BuildReorderCBDropdown
--  Checkbox dropdown whose rows can also be drag-reordered vertically. Row visuals match BuildVisOptsCBDropdown;
--  the drag behavior matches the Macro Factory per-macro menus (3px threshold, floating row, insertion line, contents shuffle on drop).
--  items: array in initial display order:
--      { key = "...", label = "...", fixed = true|nil, tooltip = "..."|nil }
--  fixed rows are checkbox-only and pinned below the movable rows; a row's
--  tooltip shows while the cursor is on it.
--  getFn(key) -> checked; setFn(key, checked, orderedMovableKeys) fires on row click.
--  opts = {
--      setOrder = function(orderedMovableKeys),  -- fired on every drop
--      onClose  = function(orderChanged),        -- fired once per menu close
--      hint     = "Drag to Reorder",             -- text above the rows (unset with every row fixed:
--                                                --   no hint line and no divider, a plain checklist)
--      grip     = true,                          -- a three-dash drag handle on each movable row
--      hint2    = "...",                         -- optional second hint line
--      canReorder = function() -> boolean,       -- optional drag guard
--      summaryLabel = function(movable, fixed, getFn) -> string,
--      head     = { { key, label }, ... },       -- plain rows (no box) at the top, a divider under them
--      onHead   = function(key),
--      tail     = { { key, label }, ... },       -- plain rows at the bottom, a divider above them
--      onTail   = function(key),
--      tailSelected = function(key) -> boolean,  -- shows a tail row as the current choice
--      openOrder = function() -> keys | nil,     -- on every open: these movable rows first, in this
--  }                                             -- order, the rest in their first order
--  A plain row calls its callback, then closes the menu (onClose sees the pick).
--  Returns ddBtn, RefreshAll (same contract as BuildVisOptsCBDropdown).
-------------------------------------------------------------------------------
function EllesmereUI.BuildReorderCBDropdown(parentFrame, ddW, fLevel, items, getFn, setFn, opts)
    -- Search prebuild on an absorber row: the dropdown indexes nothing, so none is built.
    local standIn = StandIn(parentFrame)
    if standIn then return standIn, standIn end
    opts = opts or {}
    local PP = EllesmereUI.PanelPP
    local EG = EllesmereUI.ELLESMERE_GREEN or { r = 0.05, g = 0.82, b = 0.62 }
    -- Options panel is Expressway-locked by design (locale-aware: CJK/Cyrillic get the system glyph font). The user's global font intentionally does not restyle the settings UI.
    local fontPath = EllesmereUI.EXPRESSWAY or "Fonts\\FRIZQT__.TTF"

    -- Split movable / fixed, preserving the given order
    local movable, fixedItems = {}, {}
    for _, it in ipairs(items) do
        if it.fixed then fixedItems[#fixedItems + 1] = it
        else movable[#movable + 1] = it end
    end
    local head, tail = opts.head or {}, opts.tail or {}
    -- The movable rows' first order (opts.openOrder sorts from it).
    local baseMovable = {}
    for i = 1, #movable do baseMovable[i] = movable[i] end
    local function MovableKeys()
        local keys = {}
        for i = 1, #movable do keys[i] = movable[i].key end
        return keys
    end
    local plainPaints = {}
    local function PaintPlainRows()
        for i = 1, #plainPaints do plainPaints[i]() end
    end

    local ddBtn = CreateFrame("Button", nil, parentFrame)
    -- This build's dress of the button (see BuildVisOptsCBDropdown).
    local dressGen = PoolGen(ddBtn)
    PP.Size(ddBtn, ddW, 30)
    ddBtn:SetFrameLevel(fLevel)
    local ddBg = ddBtn:CreateTexture(nil, "BACKGROUND")
    ddBg:SetAllPoints()
    ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_A)
    local ddBrd = EllesmereUI.MakeRoundedBorder(ddBtn, 1, 1, 1, EllesmereUI.DD_BRD_A, ddBg)
    local ddLbl = ddBtn:CreateFontString(nil, "OVERLAY")
    ddLbl:SetFont(fontPath, 13, "")
    ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_A)
    ddLbl:SetJustifyH("LEFT")
    ddLbl:SetWordWrap(false)
    ddLbl:SetMaxLines(1)
    ddLbl:SetPoint("LEFT", ddBtn, "LEFT", 12, 0)
    local arrow = EllesmereUI.MakeDropdownArrow(ddBtn, 12, PP)
    ddLbl:SetPoint("RIGHT", arrow, "LEFT", -5, 0)

    local function SummaryLabel()
        if opts.summaryLabel then return opts.summaryLabel(movable, fixedItems, getFn) end
        local names = {}
        local total = 0
        local function collect(list)
            for _, item in ipairs(list) do
                total = total + 1
                if getFn(item.key) then names[#names + 1] = EllesmereUI.L(item.label) end
            end
        end
        collect(movable); collect(fixedItems)
        if #names == 0 then return EllesmereUI.L("None") end
        if #names == total then return EllesmereUI.L("All") end
        return table.concat(names, ", ")
    end
    local function UpdateLabel()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetText(SummaryLabel())
    end
    UpdateLabel()

    local menu
    local orderChanged = false
    local allRows = {}

    local ITEM_H = 28
    local DIV_H = 7
    -- A list with nothing to drag and no hint of its own is a plain checklist:
    -- no hint line, and no divider above its (all fixed) rows
    local hasHint = opts.hint ~= nil or opts.hint2 ~= nil or #movable > 0
    local HINT_H = (not hasHint) and 0 or (opts.hint2 and 32 or 18)
    local FIXED_DIV = hasHint and DIV_H or 0

    local function EnsureMenu()
        if menu then return end
        local HEAD_H = (#head > 0) and (#head * ITEM_H + DIV_H) or 0
        local TAIL_H = (#tail > 0) and (DIV_H + #tail * ITEM_H) or 0
        local ROWS_BASE_Y = -4 - HEAD_H - HINT_H
        local menuH = 4 + HEAD_H + HINT_H + #movable * ITEM_H
            + ((#fixedItems > 0) and (FIXED_DIV + #fixedItems * ITEM_H) or 0) + TAIL_H + 4
        -- One menu per dropdown button for the session: a build that dresses the
        -- button again gets this frame back here, reset to new.
        menu = PoolKept(ddBtn, "reorderMenu", "Frame", EllesmereUI.OverlayParent())
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetFrameLevel(200)
        menu:SetClampedToScreen(true)
        menu:EnableMouse(true)
        menu:SetSize(ddW, menuH)
        menu:SetPoint("TOPLEFT", ddBtn, "BOTTOMLEFT", 0, -2)
        menu:Hide()
        local mBg = menu:CreateTexture(nil, "BACKGROUND")
        mBg:SetAllPoints()
        mBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_HA)
        EllesmereUI.MakeRoundedBorder(menu, 1, 1, 1, EllesmereUI.DD_BRD_A, mBg, nil, true)
        -- Controller cursor: the list blocks what is under it but is not a stop itself;
        -- Cancel clicks the dropdown button (it toggles the list closed).
        if EllesmereUI.PadCP() then
            EllesmereUI.PadHint(menu, "nodepass")
            menu.CloseButton = ddBtn
        end

        -- Hint line(s) above the rows
        if hasHint then
            local hint = menu:CreateFontString(nil, "OVERLAY")
            hint:SetFont(fontPath, 10, "")
            hint:SetTextColor(1, 1, 1, 0.25)
            if opts.hint2 then
                hint:SetPoint("TOP", menu, "TOP", 0, -6 - HEAD_H)
                local hint2 = menu:CreateFontString(nil, "OVERLAY")
                hint2:SetFont(fontPath, 9, "")
                hint2:SetTextColor(1, 1, 1, 0.25)
                hint2:SetPoint("TOP", hint, "BOTTOM", 0, -3)
                hint2:SetText(EllesmereUI.L(opts.hint2))
            else
                hint:SetPoint("TOP", menu, "TOP", 0, -4 - HEAD_H - (HINT_H - 10) / 2)
            end
            hint:SetText(EllesmereUI.L(opts.hint or "Drag to Reorder"))
        end

        -- A plain row (head or tail): its label alone; its callback runs before
        -- the menu closes, so onClose sees the pick. A tail row shows the
        -- current choice.
        local function BuildPlainRow(item, slotY, onPick, selFn)
            local row = CreateFrame("Button", nil, menu)
            row:SetHeight(ITEM_H)
            row:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, slotY)
            row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, slotY)
            row:SetFrameLevel(menu:GetFrameLevel() + 2)
            local lbl = row:CreateFontString(nil, "OVERLAY")
            lbl:SetFont(fontPath, 13, "")
            lbl:SetPoint("LEFT", row, "LEFT", 10, 0)
            lbl:SetPoint("RIGHT", row, "RIGHT", -10, 0)
            lbl:SetJustifyH("LEFT")
            lbl:SetWordWrap(false)
            lbl:SetMaxLines(1)
            lbl:SetText(EllesmereUI.L(item.label))
            local hl = row:CreateTexture(nil, "ARTWORK")
            hl:SetAllPoints()
            local hover = false
            local function Paint()
                local lit = hover or (selFn and selFn(item.key))
                lbl:SetTextColor(lit and 1 or 0.75, lit and 1 or 0.75, lit and 1 or 0.75, 1)
                hl:SetColorTexture(1, 1, 1, lit and 0.04 or 0)
            end
            Paint()
            plainPaints[#plainPaints + 1] = Paint
            row:SetScript("OnEnter", function() hover = true; Paint() end)
            row:SetScript("OnLeave", function() hover = false; Paint() end)
            row:SetScript("OnClick", function()
                hover = false
                if onPick then onPick(item.key) end
                menu:Hide()
                UpdateLabel()
            end)
        end
        for i = 1, #head do
            BuildPlainRow(head[i], -4 - (i - 1) * ITEM_H, opts.onHead)
        end
        if #head > 0 then
            local hd = menu:CreateTexture(nil, "ARTWORK")
            hd:SetHeight(1)
            hd:SetPoint("TOPLEFT", menu, "TOPLEFT", 10, -4 - #head * ITEM_H - 3)
            hd:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -10, -4 - #head * ITEM_H - 3)
            hd:SetColorTexture(1, 1, 1, 0.08)
        end

        -- Shared with the row reorder (AttachRowReorder below): the rows' own
        -- scripts stand down while a drag runs.
        local dragState = { dragging = false }
        local insLine = menu:CreateTexture(nil, "OVERLAY", nil, 7)
        insLine:SetHeight(2)
        insLine:SetColorTexture(EG.r, EG.g, EG.b, 0.9)
        insLine:Hide()

        local function SlotY(i) return ROWS_BASE_Y - (i - 1) * ITEM_H end

        local function BuildRow(item, slotY, draggable)
            local row = CreateFrame("Button", nil, menu)
            row:SetHeight(ITEM_H)
            row:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, slotY)
            row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, slotY)
            row:SetFrameLevel(menu:GetFrameLevel() + 2)
            row._item = item
            row._slotY = slotY
            local box = CreateFrame("Frame", nil, row)
            box:SetSize(16, 16)
            box:SetPoint("LEFT", row, "LEFT", 10, 0)
            local boxBg = box:CreateTexture(nil, "BACKGROUND")
            boxBg:SetAllPoints()
            boxBg:SetColorTexture(0.114, 0.106, 0.099, 1)
            local boxBrd = EllesmereUI.MakeRoundedBorder(box, 0.4, 0.4, 0.4, 0.6, boxBg)
            local chk = box:CreateTexture(nil, "ARTWORK")
            PP.SetInside(chk, box, 2, 2)
            chk:SetColorTexture(EG.r, EG.g, EG.b, 1)
            chk:SetSnapToPixelGrid(false)
            EllesmereUI.RoundBody(box, chk, 2)
            local lbl = row:CreateFontString(nil, "OVERLAY")
            lbl:SetFont(fontPath, 13, "")
            lbl:SetTextColor(0.75, 0.75, 0.75, 1)
            lbl:SetPoint("LEFT", box, "RIGHT", 8, 0)
            lbl:SetPoint("RIGHT", row, "RIGHT", (draggable and opts.grip) and -30 or -10, 0)
            lbl:SetJustifyH("LEFT")
            lbl:SetWordWrap(false)
            lbl:SetMaxLines(1)
            lbl:SetText(EllesmereUI.L(item.label))
            local hl = row:CreateTexture(nil, "ARTWORK")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0)
            -- opts.grip: a three-dash handle on the right of each movable row.
            if draggable and opts.grip then
                for g = 1, 3 do
                    local bar = row:CreateTexture(nil, "ARTWORK")
                    bar:SetSize(10, 1)
                    bar:SetPoint("RIGHT", row, "RIGHT", -10, (2 - g) * 3)
                    bar:SetColorTexture(1, 1, 1, 0.35)
                end
            end
            local function UpdateCheck()
                if getFn(row._item.key) then
                    chk:Show()
                    boxBrd:SetColor(EG.r, EG.g, EG.b, 0.8)
                else
                    chk:Hide()
                    boxBrd:SetColor(0.4, 0.4, 0.4, 0.6)
                end
            end
            UpdateCheck()
            row._updateCheck = UpdateCheck
            row._lbl = lbl
            row:SetScript("OnEnter", function()
                if dragState.dragging then return end
                lbl:SetTextColor(1, 1, 1, 1)
                hl:SetColorTexture(1, 1, 1, 0.04)
                -- The row's current item (drops shuffle row contents).
                local tip = row._item.tooltip
                if tip then EllesmereUI.ShowWidgetTooltip(row, tip) end
            end)
            row:SetScript("OnLeave", function()
                if dragState.dragging then return end
                lbl:SetTextColor(0.75, 0.75, 0.75, 1)
                hl:SetColorTexture(1, 1, 1, 0)
                if row._item.tooltip then EllesmereUI.HideWidgetTooltip() end
            end)
            row:SetScript("OnClick", function()
                if row._suppressClick then row._suppressClick = nil; return end
                if dragState.dragging then return end
                setFn(row._item.key, not getFn(row._item.key), MovableKeys())
                UpdateLabel()
                for _, r in ipairs(allRows) do
                    if r._updateCheck then r._updateCheck() end
                end
                PaintPlainRows()
            end)
            allRows[#allRows + 1] = row
            return row
        end

        -- Movable rows sit at fixed slots; drops shuffle row CONTENTS, not frames, so slot geometry stays constant for the drag math.
        local movableRows = {}
        local function RefreshMovableRows()
            for i = 1, #movableRows do
                local rf = movableRows[i]
                rf._item = movable[i]
                rf._lbl:SetText(EllesmereUI.L(movable[i].label))
                rf._updateCheck()
            end
        end

        for i = 1, #movable do
            movableRows[i] = BuildRow(movable[i], SlotY(i), true)
        end
        -- The drag itself (threshold, floating row, insertion line, drop) is the
        -- shared row reorder; a drop shuffles `movable` and repaints the rows.
        EllesmereUI.AttachRowReorder(menu, {
            rows = movableRows, items = movable, itemH = ITEM_H, slotY = SlotY,
            insLine = insLine, state = dragState, canReorder = opts.canReorder,
            refresh = RefreshMovableRows,
            onDragStart = function()
                for _, rf in ipairs(movableRows) do
                    if rf._lbl then rf._lbl:SetTextColor(0.75, 0.75, 0.75, 1) end
                end
            end,
            onDrop = function(keys)
                orderChanged = true
                if opts.setOrder then opts.setOrder(keys) end
                UpdateLabel()
            end,
        })

        -- Divider + fixed (non-draggable) rows below the movable group
        if #fixedItems > 0 then
            if FIXED_DIV > 0 then
                local divY = ROWS_BASE_Y - #movable * ITEM_H - 3
                local dl = menu:CreateTexture(nil, "ARTWORK")
                dl:SetHeight(1)
                dl:SetPoint("TOPLEFT", menu, "TOPLEFT", 10, divY)
                dl:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -10, divY)
                dl:SetColorTexture(1, 1, 1, 0.08)
            end
            for i = 1, #fixedItems do
                BuildRow(fixedItems[i], ROWS_BASE_Y - #movable * ITEM_H - FIXED_DIV - (i - 1) * ITEM_H, false)
            end
        end

        -- Divider + plain tail rows at the bottom
        if #tail > 0 then
            local tailTop = ROWS_BASE_Y - #movable * ITEM_H
                - ((#fixedItems > 0) and (FIXED_DIV + #fixedItems * ITEM_H) or 0)
            local td = menu:CreateTexture(nil, "ARTWORK")
            td:SetHeight(1)
            td:SetPoint("TOPLEFT", menu, "TOPLEFT", 10, tailTop - 3)
            td:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -10, tailTop - 3)
            td:SetColorTexture(1, 1, 1, 0.08)
            for i = 1, #tail do
                BuildPlainRow(tail[i], tailTop - DIV_H - (i - 1) * ITEM_H, opts.onTail, opts.tailSelected)
            end
        end

        -- Every open: the caller's row order (opts.openOrder), then the check
        -- and choice visuals.
        menu:HookScript("OnShow", function()
            if opts.openOrder then
                local keys = opts.openOrder()
                local byKey, used, n = {}, {}, 0
                for _, it in ipairs(baseMovable) do byKey[it.key] = it end
                if keys then
                    for _, k in ipairs(keys) do
                        local it = byKey[k]
                        if it and not used[k] then
                            n = n + 1
                            movable[n] = it
                            used[k] = true
                        end
                    end
                end
                for _, it in ipairs(baseMovable) do
                    if not used[it.key] then
                        n = n + 1
                        movable[n] = it
                    end
                end
                RefreshMovableRows()
            end
            for _, r in ipairs(allRows) do
                if r._updateCheck then r._updateCheck() end
            end
            PaintPlainRows()
        end)

        -- One close notification per open/close cycle (reload prompts hook this)
        menu:HookScript("OnHide", function()
            for _, row in ipairs(movableRows) do row:_cancelDrag() end
            dragState.dragging = false
            insLine:Hide()
            -- Controller cursor: back onto the dropdown button before onClose, so a
            -- prompt it opens can still take the cursor (a no-op once the button is hidden).
            if EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(ddBtn) end
            if ddBtn:IsMouseOver() then EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl) end
            local changed = orderChanged
            orderChanged = false
            if opts.onClose then opts.onClose(changed) end
        end)

        EllesmereUI.TrackOverlay(menu)
        ddBtn._ddMenu = menu
    end

    local function ApplyNormal()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_A)
        ddBrd:SetColor(1, 1, 1, EllesmereUI.DD_BRD_A)
        ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_A)
    end
    local function ApplyHover()
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetTextColor(1, 1, 1, EllesmereUI.DD_TXT_HA)
        ddBrd:SetColor(1, 1, 1, EllesmereUI.DD_BRD_HA)
        ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_HA)
    end
    ddBtn:SetScript("OnEnter", function()
        ApplyHover()
        if not (menu and menu:IsShown()) then EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl) end
    end)
    ddBtn:SetScript("OnLeave", function()
        if not (menu and menu:IsShown()) then ApplyNormal() end
        EllesmereUI._widgetInternals.HideDropdownTip(ddBtn)
    end)

    local function ShowMenu()
        EnsureMenu()
        if menu:IsShown() then
            menu:Hide()
            return
        end
        local btnScale = ddBtn:GetEffectiveScale()
        local uiScale = UIParent:GetEffectiveScale()
        menu:SetScale(btnScale / uiScale)
        EllesmereUI.SeatDropdownMenu(menu)
        ApplyHover()
        menu:Show()
        menu:SetScript("OnUpdate", function(self)
            if not self:IsMouseOver() and not ddBtn:IsMouseOver() and IsMouseButtonDown("LeftButton") then
                self:Hide()
            end
        end)
        -- Controller cursor: into the opened list.
        if EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(menu) end
    end
    ddBtn:SetScript("OnClick", function() EllesmereUI._widgetInternals.HideDropdownTip(ddBtn); ShowMenu() end)
    ddBtn:HookScript("OnHide", function() if menu then menu:Hide() end end)

    local function RefreshAll()
        -- A caller may keep this past a page pass that dressed ddBtn (and with it
        -- the kept menu's rows) for another build.
        if PoolGen(ddBtn) ~= dressGen then return end
        UpdateLabel()
        for _, r in ipairs(allRows) do
            if r._updateCheck then r._updateCheck() end
        end
        PaintPlainRows()
    end
    return ddBtn, RefreshAll
end

-------------------------------------------------------------------------------
--  Slider dropdown: a dropdown button whose menu is a short stack of sliders
--  (label, track and value box per row), several related amounts behind one
--  control. items[i] = { label, tooltip, min, max, step, get = fn -> number,
--  set = fn(v) }; tooltip shows over the row's label. The button reads the
--  labels of the rows away from their minimum ("None" when none, "All" when
--  every one). opts.menuW = the menu width (default 320); the menu opens
--  right-aligned under the button, stays open while a slider is dragged past
--  its edge and runs nothing while closed.
--  Returns: ddBtn, refreshFn
-------------------------------------------------------------------------------
function EllesmereUI.BuildSliderDropdown(parentFrame, ddW, fLevel, items, opts)
    -- Search prebuild on an absorber row: the dropdown indexes nothing, so none is built.
    local standIn = StandIn(parentFrame)
    if standIn then return standIn, standIn end
    local PP = EllesmereUI.PanelPP
    opts = opts or {}
    local fontPath = EllesmereUI.EXPRESSWAY
    local ddBtn = CreateFrame("Button", nil, parentFrame)
    -- This build's dress of the button (see BuildVisOptsCBDropdown).
    local dressGen = PoolGen(ddBtn)
    PP.Size(ddBtn, ddW, 30)
    ddBtn:SetFrameLevel(fLevel)
    local ddBg = ddBtn:CreateTexture(nil, "BACKGROUND")
    ddBg:SetAllPoints()
    local ddBrd = EllesmereUI.MakeRoundedBorder(ddBtn, 1, 1, 1, EllesmereUI.DD_BRD_A, ddBg)
    local ddLbl = ddBtn:CreateFontString(nil, "OVERLAY")
    ddLbl:SetFont(fontPath, 13, "")
    ddLbl:SetJustifyH("LEFT")
    ddLbl:SetWordWrap(false)
    ddLbl:SetMaxLines(1)
    ddLbl:SetPoint("LEFT", ddBtn, "LEFT", 12, 0)
    local arrow = EllesmereUI.MakeDropdownArrow(ddBtn, 12, PP)
    ddLbl:SetPoint("RIGHT", arrow, "LEFT", -5, 0)

    local function Paint(hover)
        if PoolGen(ddBtn) ~= dressGen then return end
        ddLbl:SetTextColor(1, 1, 1, hover and EllesmereUI.DD_TXT_HA or EllesmereUI.DD_TXT_A)
        ddBrd:SetColor(1, 1, 1, hover and EllesmereUI.DD_BRD_HA or EllesmereUI.DD_BRD_A)
        ddBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B,
            hover and EllesmereUI.DD_BG_HA or EllesmereUI.DD_BG_A)
    end
    Paint(false)

    local function UpdateLabel()
        if PoolGen(ddBtn) ~= dressGen then return end
        local names = {}
        for _, item in ipairs(items) do
            local v = item.get()
            if v and v ~= (item.min or 0) then names[#names + 1] = EllesmereUI.L(item.label) end
        end
        if #names == 0 then
            ddLbl:SetText(EllesmereUI.L("None"))
        elseif #names == #items then
            ddLbl:SetText(EllesmereUI.L("All"))
        else
            ddLbl:SetText(table.concat(names, ", "))
        end
    end
    UpdateLabel()

    local menu, refreshers
    local ROW_H, PAD, TRACK_W = 34, 6, 140
    local function EnsureMenu()
        if menu then return end
        -- One menu per dropdown button for the session: a build that dresses the
        -- button again gets this frame back here, reset to new.
        menu = PoolKept(ddBtn, "sliderMenu", "Frame", EllesmereUI.OverlayParent())
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetFrameLevel(200)
        menu:SetClampedToScreen(true)
        menu:EnableMouse(true)
        -- The page under the menu must not scroll away from it.
        menu:EnableMouseWheel(true)
        menu:SetScript("OnMouseWheel", function() end)
        menu:SetSize(opts.menuW or 320, PAD * 2 + #items * ROW_H)
        menu:SetPoint("TOPRIGHT", ddBtn, "BOTTOMRIGHT", 0, -2)
        menu:Hide()
        -- Controller cursor: the menu blocks what is under it but is not a stop
        -- itself; Cancel clicks the button (it toggles the menu closed).
        if EllesmereUI.PadCP() then
            EllesmereUI.PadHint(menu, "nodepass")
            menu.CloseButton = ddBtn
        end
        local mBg = menu:CreateTexture(nil, "BACKGROUND")
        mBg:SetAllPoints()
        mBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, EllesmereUI.DD_BG_HA)
        EllesmereUI.MakeRoundedBorder(menu, 1, 1, 1, EllesmereUI.DD_BRD_A, mBg, nil, true)

        refreshers = {}
        for i, item in ipairs(items) do
            local y = -(PAD + (i - 1) * ROW_H)
            local row = CreateFrame("Frame", nil, menu)
            row:SetHeight(ROW_H)
            row:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, y)
            row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, y)
            row:SetFrameLevel(menu:GetFrameLevel() + 2)
            local track, valBox, refresh = EllesmereUI.BuildSliderCore(row, TRACK_W, 4, 14, 40, 24, 12,
                EllesmereUI.SL_INPUT_A, item.min or 0, item.max or 100, item.step or 1,
                item.get,
                function(v)
                    -- Attributed to the button: its row carries the override
                    -- capture config, the menu sits on the overlay parent. The
                    -- slot is taken before the setter runs: one that rebuilds
                    -- the page can dress ddBtn for another slot.
                    local snap = EllesmereUI._SOAttribution(ddBtn)
                    item.set(v)
                    UpdateLabel()
                    EllesmereUI._NotifySettingWrite(ddBtn, snap)
                end, true)
            PP.Point(valBox, "RIGHT", row, "RIGHT", -12, 0)
            PP.Point(track, "RIGHT", valBox, "LEFT", -12, 0)
            refreshers[i] = refresh
            local lbl = row:CreateFontString(nil, "OVERLAY")
            lbl:SetFont(fontPath, 13, "")
            lbl:SetTextColor(1, 1, 1, 0.85)
            lbl:SetJustifyH("LEFT")
            lbl:SetWordWrap(false)
            lbl:SetPoint("LEFT", row, "LEFT", 14, 0)
            lbl:SetPoint("RIGHT", track, "LEFT", -12, 0)
            lbl:SetText(EllesmereUI.L(item.label))
            if item.tooltip then
                row:EnableMouse(true)
                row:SetScript("OnEnter", function() EllesmereUI.ShowWidgetTooltip(lbl, item.tooltip) end)
                row:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            end
            if i < #items then
                local div = row:CreateTexture(nil, "ARTWORK")
                div:SetColorTexture(1, 1, 1, 0.06)
                div:SetHeight(1)
                div:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 10, 0)
                div:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -10, 0)
            end
        end

        menu:SetScript("OnHide", function(self)
            self:SetScript("OnUpdate", nil)
            if EllesmereUI._openDropdownMenu == self then EllesmereUI._openDropdownMenu = nil end
            Paint(ddBtn:IsMouseOver())
            if ddBtn:IsMouseOver() then EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl) end
            -- Controller cursor: back onto the button (a no-op once that is hidden too).
            if EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(ddBtn) end
        end)
        if EllesmereUI.PadCP() then EllesmereUI.TrackOverlay(menu) end
    end

    -- Whether the button scrolls with the page (decided on the first open).
    local inScroll
    local function ShowMenu()
        EnsureMenu()
        if menu:IsShown() then
            menu:Hide()
            return
        end
        for i = 1, #refreshers do refreshers[i]() end
        -- The menu lives on the overlay parent: match the panel's scale.
        menu:SetScale(ddBtn:GetEffectiveScale() / UIParent:GetEffectiveScale())
        EllesmereUI.SeatDropdownMenu(menu)
        Paint(true)
        menu:Show()
        EllesmereUI._openDropdownMenu = menu
        local sf = EllesmereUI._scrollFrame
        if inScroll == nil then
            inScroll = false
            local child = sf and sf.GetScrollChild and sf:GetScrollChild()
            local p = ddBtn:GetParent()
            while child and p do
                if p == child then inScroll = true; break end
                p = p:GetParent()
            end
        end
        menu:SetScript("OnUpdate", function(self)
            -- A left click outside the menu and its button closes it; never
            -- mid-drag, so a slider dragged past the menu's edge keeps it.
            if not EllesmereUI._sliderDragging and IsMouseButtonDown("LeftButton")
               and not self:IsMouseOver() and not ddBtn:IsMouseOver() then
                self:Hide()
                return
            end
            -- The button scrolled out of the page's visible area.
            if inScroll then
                local top, bot, b = sf:GetTop(), sf:GetBottom(), ddBtn:GetBottom()
                if top and bot and b and (b < bot or b > top) then self:Hide() end
            end
        end)
        if EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(menu) end
    end
    ddBtn:SetScript("OnEnter", function()
        Paint(true)
        if not (menu and menu:IsShown()) then EllesmereUI._widgetInternals.ShowDropdownTip(ddBtn, ddLbl) end
    end)
    ddBtn:SetScript("OnLeave", function()
        if not (menu and menu:IsShown()) then Paint(false) end
        EllesmereUI._widgetInternals.HideDropdownTip(ddBtn)
    end)
    ddBtn:SetScript("OnClick", function() EllesmereUI._widgetInternals.HideDropdownTip(ddBtn); ShowMenu() end)
    ddBtn:HookScript("OnHide", function() if menu then menu:Hide() end end)

    local function RefreshAll()
        -- A caller may keep this past a page pass that dressed ddBtn (and with it
        -- the kept menu's sliders) for another build.
        if PoolGen(ddBtn) ~= dressGen then return end
        UpdateLabel()
        if menu and menu:IsShown() then
            for i = 1, #refreshers do refreshers[i]() end
        end
    end
    return ddBtn, RefreshAll
end

