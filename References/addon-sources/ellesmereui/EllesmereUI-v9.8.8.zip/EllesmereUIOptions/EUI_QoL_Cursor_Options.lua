if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EUI_CursorLite_Options.lua
--  Registers the Cursor Lite module with EllesmereUI.
--  All get/set calls go to the addon's DB profile.
--  Does NOT touch cursor tracking logic.
-------------------------------------------------------------------------------
local ADDON_NAME = "EllesmereUIQoL"
local ns = EllesmereUI._ModuleNS[ADDON_NAME]  -- module namespace (published by the module at its load)
if not ns then return end  -- module disabled: no options page

-- Page reuse: frames this file builds go through the options frame pool
-- (EllesmereUI_FramePool.lua), which hands a kept page its previous build's
-- frames back reset to new; on any other parent it is the plain CreateFrame.
local CreateFrame = EllesmereUI._Pool.CreateFrame

local PAGE_CURSOR     = "Cursor"
local PAGE_UNLOCK     = "Unlock Mode"

local SECTION_APPEARANCE   = "CURSOR"
local SECTION_GCD          = "GLOBAL COOLDOWN"
local SECTION_CAST         = "CAST BAR"

local strupper, strgsub, strmatch, strsub = string.upper, string.gsub, string.match, string.sub
local floor = math.floor

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")

    if not EllesmereUI or not EllesmereUI.RegisterModule then return end
    local PP = EllesmereUI.PP

    ---------------------------------------------------------------------------
    --  DB helpers
    ---------------------------------------------------------------------------
    local db

    C_Timer.After(0, function()
        db = _G._ECL_AceDB
    end)

    local function DB()
        if not db then db = _G._ECL_AceDB end
        return db and db.profile
    end

    local function GCD_DB()
        local p = DB()
        if not p then return {} end
        if not p.gcd then p.gcd = {} end
        return p.gcd
    end

    local function Cast_DB()
        local p = DB()
        if not p then return {} end
        if not p.castCircle then p.castCircle = {} end
        return p.castCircle
    end

    ---------------------------------------------------------------------------
    --  Hex color helpers
    ---------------------------------------------------------------------------
    local function HexToRGB(hex)
        hex = strupper(strgsub(hex or "0CD29D", "#", ""))
        if not strmatch(hex, "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$") then
            hex = "0CD29D"
        end
        return tonumber(strsub(hex, 1, 2), 16) / 255,
               tonumber(strsub(hex, 3, 4), 16) / 255,
               tonumber(strsub(hex, 5, 6), 16) / 255
    end

    local function RGBToHex(r, g, b)
        return string.format("%02X%02X%02X",
            floor(r * 255 + 0.5),
            floor(g * 255 + 0.5),
            floor(b * 255 + 0.5))
    end

    ---------------------------------------------------------------------------
    --  Refresh helpers
    ---------------------------------------------------------------------------
    local function RefreshAddon()
        if _G._ECL_Apply then _G._ECL_Apply() end
    end

    local function RefreshGCD()
        if _G._ECL_ApplyGCDCircle then _G._ECL_ApplyGCDCircle() end
        if _G._ECL_RegisterUnlock then _G._ECL_RegisterUnlock() end
    end

    local function RefreshCast()
        if _G._ECL_ApplyCastCircle then _G._ECL_ApplyCastCircle() end
        if _G._ECL_RegisterUnlock then _G._ECL_RegisterUnlock() end
    end

    ---------------------------------------------------------------------------
    --  Ring texture dropdown values (shared by GCD + Cast)
    ---------------------------------------------------------------------------
    local ringTexValues = { normal = "Ring Normal", light = "Ring Light", thin = "Ring Thin", heavy = "Ring Heavy", thick = "Ring Thick" }
    local ringTexOrder  = { "normal", "light", "---", "thin", "heavy", "thick" }

    ---------------------------------------------------------------------------
    --  Cursor Circle page  (Appearance + GCD + Cast Bar sections)
    ---------------------------------------------------------------------------
    local function BuildCursorPage(pageName, parent, yOffset)
        local W = EllesmereUI.Widgets
        local y = yOffset
        local _, h, row, hdr

        EllesmereUI:ClearContentHeader()

        -----------------------------------------------------------------------
        --  APPEARANCE
        -----------------------------------------------------------------------
        _, h = W:SectionHeader(parent, SECTION_APPEARANCE, y);  y = y - h

        -- Enable Cursor Circle ---- Color (multiSwatch: custom left, class colored right)
        row, h = W:DualRow(parent, y,
            { type="toggle", text="Enable Cursor Circle",
              getValue=function() local p = DB(); return p and (p.enabled ~= false) end,
              -- DependentSetValue: the rows below Row 1 are hidden while the
              -- circle is off; the flip forces the full rebuild.
              setValue=EllesmereUI.DependentSetValue(
                  function() local p = DB(); return p and (p.enabled ~= false) end,
                  function(v)
                    local p = DB(); if not p then return end
                    p.enabled = v
                    RefreshAddon()
                    EllesmereUI:RefreshPage()
                  end) },
            { type="multiSwatch", text="Color",
              swatches = {
                { tooltip = "Custom Color",
                  hasAlpha = false,
                  getValue = function()
                      local p = DB()
                      if not p then return 12/255, 210/255, 157/255 end
                      local r, g, b = HexToRGB(p.hex)
                      return r, g, b
                  end,
                  setValue = function(r, g, b)
                      local p = DB(); if not p then return end
                      p.hex = RGBToHex(r, g, b)
                      RefreshAddon()
                  end,
                  onClick = function(self)
                      local p = DB(); if not p then return end
                      if p.useClassColor or p.useAccentColor then
                          p.useClassColor = false
                          p.useAccentColor = false
                          RefreshAddon(); EllesmereUI:RefreshPage()
                          return
                      end
                      if self._eabOrigClick then self._eabOrigClick(self) end
                  end,
                  refreshAlpha = function()
                      local p = DB()
                      if not p or p.enabled == false then return 0.15 end
                      return (p.useClassColor or p.useAccentColor) and 0.3 or 1
                  end },
                { tooltip = "Class Colored",
                  hasAlpha = false,
                  getValue = function()
                      local _, classFile = UnitClass("player")
                      local cc = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
                      if cc then return cc.r, cc.g, cc.b end
                      return 12/255, 210/255, 157/255
                  end,
                  setValue = function() end,
                  onClick = function()
                      local p = DB(); if not p then return end
                      p.useClassColor = true
                      p.useAccentColor = false
                      RefreshAddon(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local p = DB()
                      if not p or p.enabled == false then return 0.15 end
                      return (p.useClassColor) and 1 or 0.3
                  end },
                { tooltip = "Accent Color",
                  hasAlpha = false,
                  getValue = function()
                      local ar, ag, ab = EllesmereUI.GetAccentColor()
                      return ar, ag, ab
                  end,
                  setValue = function() end,
                  onClick = function()
                      local p = DB(); if not p then return end
                      p.useAccentColor = true
                      p.useClassColor = false
                      RefreshAddon(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local p = DB()
                      if not p or p.enabled == false then return 0.15 end
                      return (p.useAccentColor) and 1 or 0.3
                  end },
              } }
        );  y = y - h
        -- Block overlay on the right region when Cursor Circle is disabled
        if not EllesmereUI._prebuilding then
            local rightRgn = row._rightRegion
            local circleBlock = CreateFrame("Frame", nil, rightRgn)
            circleBlock:SetAllPoints()
            circleBlock:SetFrameLevel(rightRgn:GetFrameLevel() + 20)
            circleBlock:EnableMouse(true)
            circleBlock:SetScript("OnEnter", function()
                EllesmereUI.ShowWidgetTooltip(rightRgn, EllesmereUI.DisabledTooltip("Cursor Circle"))
            end)
            circleBlock:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            local function UpdateCircleBlock()
                local p = DB()
                local off = not p or p.enabled == false
                circleBlock:SetShown(off)
                -- Dim the "Color" label with its swatches
                if rightRgn._label then rightRgn._label:SetAlpha(off and 0.3 or 1) end
            end
            UpdateCircleBlock()
            EllesmereUI.RegisterWidgetRefresh(UpdateCircleBlock)
        end

        -- Rows below are HIDDEN entirely while the Cursor Circle is off (the
        -- toggle's DependentSetValue forces the rebuild on flips).
        if DB() and DB().enabled ~= false then
        -- Texture ---- Scale
        _, h = W:DualRow(parent, y,
            { type="dropdown", text="Texture",
              values={ ring_normal = "Ring Normal", ring_light = "Ring Light", custom = "Ellesmere Logo", ring_thin = "Ring Thin", ring_heavy = "Ring Heavy", ring_thick = "Ring Thick" },
              order={ "ring_normal", "ring_light", "custom", "---", "ring_thin", "ring_heavy", "ring_thick" },
              getValue=function() local p = DB(); return p and p.texture or "ring_normal" end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.texture = v
                RefreshAddon()
              end },
            { type="slider", text="Scale", min=0.5, max=2.0, step=0.1,
              getValue=function() local p = DB(); return p and p.scale or 1 end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.scale = v
                RefreshAddon()
              end }
        );  y = y - h

        -- Circle Opacity ---- Cursor Trail
        _, h = W:DualRow(parent, y,
            { type="slider", text="Circle Opacity", min=0, max=100, step=1,
              getValue=function() local p = DB(); return p and (p.alpha or 100) end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.alpha = v
                RefreshAddon()
              end },
            { type="toggle", text="Cursor Trail",
              getValue=function() local p = DB(); return p and p.trail or false end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.trail = v
                if _G._ECL_ApplyTrail then _G._ECL_ApplyTrail() end
              end }
        );  y = y - h

        -- Only Show in Instances ---- Only Show When Hidden
        _, h = W:DualRow(parent, y,
            { type="toggle", text="Only Show in Instances",
              getValue=function() local p = DB(); return p and p.instanceOnly end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.instanceOnly = v
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end },
            { type="toggle", text="Only Show When Hidden",
              tooltip="Only shows the cursor circle while the mouse is hidden -- that is, while you hold the left and/or right mouse button to pan the camera or move your character.",
              getValue=function() local p = DB(); return p and p.onlyWhenHidden or false end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.onlyWhenHidden = v
                if _G._ECL_ApplyOnlyWhenHidden then _G._ECL_ApplyOnlyWhenHidden() end
              end }
        );  y = y - h

        -- Combat Only ---- Center Reticle
        _, h = W:DualRow(parent, y,
            { type="toggle", text="Combat Only",
              tooltip="Only shows the cursor circle while you are in combat.",
              getValue=function() local p = DB(); return p and p.combatOnly or false end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.combatOnly = v
                if _G._ECL_ApplyCombatOnlyEvents then _G._ECL_ApplyCombatOnlyEvents() end
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end },
            { type="toggle", text="Center Reticle",
              tooltip="Adds a small filled dot at the center of the cursor circle. Uses the same color and opacity as the circle.",
              getValue=function() local p = DB(); return p and p.reticle or false end,
              setValue=function(v)
                local p = DB(); if not p then return end
                p.reticle = v
                RefreshAddon()
              end }
        );  y = y - h
        end   -- close Cursor Circle hidden-while-disabled gate

        _, h = W:Spacer(parent, y, 20);  y = y - h

        -----------------------------------------------------------------------
        --  GLOBAL COOLDOWN
        -----------------------------------------------------------------------
        hdr, h = W:SectionHeader(parent, SECTION_GCD, y);  y = y - h
        -- The circle has a mover only while enabled and detached from the
        -- cursor, so the button names whichever of the two it still needs.
        EllesmereUI.BuildSectionUnlockJump(hdr, { key = "ECL_GCD",
            disabled = function() local g = GCD_DB(); return not (g.enabled and g.attached == false) end,
            disabledTooltip = function() return GCD_DB().enabled and "Attach to Cursor" or "GCD Circle" end,
            requireState = function() return GCD_DB().enabled and "disabled" or "enabled" end })

        -- Enable GCD Circle ---- Color (multiSwatch: custom left, class colored right)
        row, h = W:DualRow(parent, y,
            { type="toggle", text="Enable GCD Circle",
              getValue=function() return GCD_DB().enabled or false end,
              -- DependentSetValue: the rows below Row 1 are hidden while the
              -- circle is off; the flip forces the full rebuild.
              setValue=EllesmereUI.DependentSetValue(
                  function() return GCD_DB().enabled or false end,
                  function(v)
                    GCD_DB().enabled = v
                    RefreshGCD()
                    EllesmereUI:RefreshPage()
                  end) },
            { type="multiSwatch", text="Color",
              swatches = {
                { tooltip = "Custom Color",
                  hasAlpha = false,
                  getValue = function()
                      local g = GCD_DB()
                      local r, ng, b = HexToRGB(g.hex)
                      return r, ng, b
                  end,
                  setValue = function(r, g, b)
                      local gd = GCD_DB()
                      gd.hex = RGBToHex(r, g, b)
                      RefreshGCD()
                  end,
                  onClick = function(self)
                      local g = GCD_DB()
                      if g.useClassColor or g.useAccentColor then
                          g.useClassColor = false
                          g.useAccentColor = false
                          RefreshGCD(); EllesmereUI:RefreshPage()
                          return
                      end
                      if self._eabOrigClick then self._eabOrigClick(self) end
                  end,
                  refreshAlpha = function()
                      local g = GCD_DB()
                      if not g.enabled then return 0.15 end
                      return (g.useClassColor or g.useAccentColor) and 0.3 or 1
                  end },
                { tooltip = "Class Colored",
                  hasAlpha = false,
                  getValue = function()
                      local _, classFile = UnitClass("player")
                      local cc = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
                      if cc then return cc.r, cc.g, cc.b end
                      return 12/255, 210/255, 157/255
                  end,
                  setValue = function() end,
                  onClick = function()
                      local g = GCD_DB()
                      g.useClassColor = true
                      g.useAccentColor = false
                      RefreshGCD(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local g = GCD_DB()
                      if not g.enabled then return 0.15 end
                      return g.useClassColor and 1 or 0.3
                  end },
                { tooltip = "Accent Color",
                  hasAlpha = false,
                  getValue = function()
                      local ar, ag, ab = EllesmereUI.GetAccentColor()
                      return ar, ag, ab
                  end,
                  setValue = function() end,
                  onClick = function()
                      local g = GCD_DB()
                      g.useAccentColor = true
                      g.useClassColor = false
                      RefreshGCD(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local g = GCD_DB()
                      if not g.enabled then return 0.15 end
                      return g.useAccentColor and 1 or 0.3
                  end },
              } }
        );  y = y - h
        -- Block overlay on the right region when GCD Circle is disabled
        if not EllesmereUI._prebuilding then
            local rightRgn = row._rightRegion
            local gcdBlock = CreateFrame("Frame", nil, rightRgn)
            gcdBlock:SetAllPoints()
            gcdBlock:SetFrameLevel(rightRgn:GetFrameLevel() + 20)
            gcdBlock:EnableMouse(true)
            gcdBlock:SetScript("OnEnter", function()
                EllesmereUI.ShowWidgetTooltip(rightRgn, EllesmereUI.DisabledTooltip("GCD Circle"))
            end)
            gcdBlock:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            local function UpdateGCDBlock()
                local off = not GCD_DB().enabled
                gcdBlock:SetShown(off)
                -- Dim the "Color" label with its swatches
                if rightRgn._label then rightRgn._label:SetAlpha(off and 0.3 or 1) end
            end
            UpdateGCDBlock()
            EllesmereUI.RegisterWidgetRefresh(UpdateGCDBlock)
        end

        -- Rows below are HIDDEN entirely while the GCD Circle is off (the
        -- toggle's DependentSetValue forces the rebuild on flips).
        if GCD_DB().enabled then
        -- Ring Texture ---- Scale
        _, h = W:DualRow(parent, y,
            { type="dropdown", text="Ring Texture",
              values=ringTexValues, order=ringTexOrder,
              getValue=function() return GCD_DB().ringTex or "light" end,
              setValue=function(v) GCD_DB().ringTex = v; RefreshGCD() end },
            { type="slider", text="Scale", min=10, max=100, step=1,
              getValue=function() return GCD_DB().radius or 21 end,
              setValue=function(v) GCD_DB().radius = v; RefreshGCD() end }
        );  y = y - h

        -- Circle Opacity ---- Attach to Cursor
        _, h = W:DualRow(parent, y,
            { type="slider", text="Circle Opacity", min=0, max=100, step=1,
              getValue=function() return GCD_DB().alpha or 80 end,
              setValue=function(v) GCD_DB().alpha = v; RefreshGCD() end },

            { type="toggle", text="Attach to Cursor",
              getValue=function() return GCD_DB().attached ~= false end,
              setValue=function(v)
                GCD_DB().attached = v
                RefreshGCD()
                EllesmereUI:RefreshPage()
              end }
        );  y = y - h

        -- Only Show in Instances ---- Combat Only
        _, h = W:DualRow(parent, y,
            { type="toggle", text="Only Show in Instances",
              getValue=function() return GCD_DB().instanceOnly or false end,
              setValue=function(v)
                GCD_DB().instanceOnly = v
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end },
            { type="toggle", text="Combat Only",
              tooltip="Only shows the GCD circle while you are in combat.",
              getValue=function() return GCD_DB().combatOnly or false end,
              setValue=function(v)
                GCD_DB().combatOnly = v
                if _G._ECL_ApplyCombatOnlyEvents then _G._ECL_ApplyCombatOnlyEvents() end
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end }
        );  y = y - h
        end   -- close GCD Circle hidden-while-disabled gate

        _, h = W:Spacer(parent, y, 20);  y = y - h

        -----------------------------------------------------------------------
        --  CAST BAR
        -----------------------------------------------------------------------
        hdr, h = W:SectionHeader(parent, SECTION_CAST, y);  y = y - h
        -- As the GCD circle: a mover only while enabled and detached.
        EllesmereUI.BuildSectionUnlockJump(hdr, { key = "ECL_Cast",
            disabled = function() local c = Cast_DB(); return not (c.enabled and c.attached == false) end,
            disabledTooltip = function() return Cast_DB().enabled and "Attach to Cursor" or "Cast Bar Circle" end,
            requireState = function() return Cast_DB().enabled and "disabled" or "enabled" end })

        -- Enable Cast Bar Circle ---- Color (multiSwatch: custom left, class colored right)
        row, h = W:DualRow(parent, y,
            { type="toggle", text="Enable Cast Bar Circle",
              getValue=function() return Cast_DB().enabled or false end,
              -- DependentSetValue: the rows below Row 1 are hidden while the
              -- circle is off; the flip forces the full rebuild.
              setValue=EllesmereUI.DependentSetValue(
                  function() return Cast_DB().enabled or false end,
                  function(v)
                    Cast_DB().enabled = v
                    RefreshCast()
                    EllesmereUI:RefreshPage()
                  end) },
            { type="multiSwatch", text="Color",
              swatches = {
                { tooltip = "Custom Color",
                  hasAlpha = false,
                  getValue = function()
                      local c = Cast_DB()
                      local r, ng, b = HexToRGB(c.hex)
                      return r, ng, b
                  end,
                  setValue = function(r, g, b)
                      local cd = Cast_DB()
                      cd.hex = RGBToHex(r, g, b)
                      RefreshCast()
                  end,
                  onClick = function(self)
                      local c = Cast_DB()
                      if c.useClassColor or c.useAccentColor then
                          c.useClassColor = false
                          c.useAccentColor = false
                          RefreshCast(); EllesmereUI:RefreshPage()
                          return
                      end
                      if self._eabOrigClick then self._eabOrigClick(self) end
                  end,
                  refreshAlpha = function()
                      local c = Cast_DB()
                      if not c.enabled then return 0.15 end
                      return (c.useClassColor or c.useAccentColor) and 0.3 or 1
                  end },
                { tooltip = "Class Colored",
                  hasAlpha = false,
                  getValue = function()
                      local _, classFile = UnitClass("player")
                      local cc = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
                      if cc then return cc.r, cc.g, cc.b end
                      return 12/255, 210/255, 157/255
                  end,
                  setValue = function() end,
                  onClick = function()
                      local c = Cast_DB()
                      c.useClassColor = true
                      c.useAccentColor = false
                      RefreshCast(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local c = Cast_DB()
                      if not c.enabled then return 0.15 end
                      return c.useClassColor and 1 or 0.3
                  end },
                { tooltip = "Accent Color",
                  hasAlpha = false,
                  getValue = function()
                      local ar, ag, ab = EllesmereUI.GetAccentColor()
                      return ar, ag, ab
                  end,
                  setValue = function() end,
                  onClick = function()
                      local c = Cast_DB()
                      c.useAccentColor = true
                      c.useClassColor = false
                      RefreshCast(); EllesmereUI:RefreshPage()
                  end,
                  refreshAlpha = function()
                      local c = Cast_DB()
                      if not c.enabled then return 0.15 end
                      return c.useAccentColor and 1 or 0.3
                  end },
              } }
        );  y = y - h
        -- Block overlay on the right region when Cast Bar Circle is disabled
        if not EllesmereUI._prebuilding then
            local rightRgn = row._rightRegion
            local castBlock = CreateFrame("Frame", nil, rightRgn)
            castBlock:SetAllPoints()
            castBlock:SetFrameLevel(rightRgn:GetFrameLevel() + 20)
            castBlock:EnableMouse(true)
            castBlock:SetScript("OnEnter", function()
                EllesmereUI.ShowWidgetTooltip(rightRgn, EllesmereUI.DisabledTooltip("Cast Bar Circle"))
            end)
            castBlock:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            local function UpdateCastBlock()
                local off = not Cast_DB().enabled
                castBlock:SetShown(off)
                -- Dim the "Color" label with its swatches
                if rightRgn._label then rightRgn._label:SetAlpha(off and 0.3 or 1) end
            end
            UpdateCastBlock()
            EllesmereUI.RegisterWidgetRefresh(UpdateCastBlock)
        end

        -- Inline cog on Enable Cast Bar Circle for "Show Spark"
        EllesmereUI.BuildInlineCog(row._leftRegion, {
            title = "Cast Bar Settings",
            disabled = function() return not Cast_DB().enabled end,
            disabledTooltip = "Cast Bar Circle",
            rows = {
                { type="toggle", label="Show Spark",
                  get=function()
                    local c = Cast_DB()
                    return c.sparkEnabled ~= false
                  end,
                  set=function(v)
                    Cast_DB().sparkEnabled = v
                    RefreshCast()
                  end },
            },
        })

        -- Rows below are HIDDEN entirely while the Cast Bar Circle is off
        -- (the toggle's DependentSetValue forces the rebuild on flips).
        if Cast_DB().enabled then
        -- Ring Texture ---- Scale
        _, h = W:DualRow(parent, y,
            { type="dropdown", text="Ring Texture",
              values=ringTexValues, order=ringTexOrder,
              getValue=function() return Cast_DB().ringTex or "normal" end,
              setValue=function(v) Cast_DB().ringTex = v; RefreshCast() end },
            { type="slider", text="Scale", min=10, max=100, step=1,
              getValue=function() return Cast_DB().radius or 30 end,
              setValue=function(v) Cast_DB().radius = v; RefreshCast() end }
        );  y = y - h

        -- Circle Opacity ---- Attach to Cursor
        row, h = W:DualRow(parent, y,
            { type="slider", text="Circle Opacity", min=0, max=100, step=1,
              getValue=function() return Cast_DB().alpha or 80 end,
              setValue=function(v) Cast_DB().alpha = v; RefreshCast() end },

            { type="toggle", text="Attach to Cursor",
              getValue=function() return Cast_DB().attached ~= false end,
              setValue=function(v)
                Cast_DB().attached = v
                RefreshCast()
                EllesmereUI:RefreshPage()
              end }
        );  y = y - h

        -- Only Show in Instances ---- Combat Only
        _, h = W:DualRow(parent, y,
            { type="toggle", text="Only Show in Instances",
              getValue=function() return Cast_DB().instanceOnly or false end,
              setValue=function(v)
                Cast_DB().instanceOnly = v
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end },
            { type="toggle", text="Combat Only",
              tooltip="Only shows the cast bar circle while you are in combat.",
              getValue=function() return Cast_DB().combatOnly or false end,
              setValue=function(v)
                Cast_DB().combatOnly = v
                if _G._ECL_ApplyCombatOnlyEvents then _G._ECL_ApplyCombatOnlyEvents() end
                if _G._ECL_UpdateVisibility then _G._ECL_UpdateVisibility() end
              end }
        );  y = y - h
        end   -- close Cast Bar Circle hidden-while-disabled gate

        return math.abs(y)
    end

    ---------------------------------------------------------------------------
    --  Cross-file bus: EUI_QoL_Options.lua builds the Cursor page and fires the
    --  reset through these (_EBS_ names are historical; consumers match them).
    ---------------------------------------------------------------------------
    _G._EBS_BuildCursorPage = BuildCursorPage
    _G._EBS_ResetCursor = function()
        if _G._ECL_AceDB then _G._ECL_AceDB:ResetProfile() end
        RefreshAddon()
        RefreshGCD()
        RefreshCast()
        if _G._ECL_ApplyTrail then _G._ECL_ApplyTrail() end
    end
end)
-- LoadOnDemand: this addon loads after PLAYER_LOGIN, so the event above will never fire; run the init now.
if IsLoggedIn() then initFrame:GetScript("OnEvent")(initFrame) end
