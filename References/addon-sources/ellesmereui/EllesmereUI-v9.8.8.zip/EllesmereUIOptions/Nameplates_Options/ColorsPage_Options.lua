if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  Nameplates_Options\ColorsPage_Options.lua
--  Nameplates options: the Colors page (BuildColorsPage). Definitions only;
--  the shared helpers come from ns._NPO_OptEnv.
-------------------------------------------------------------------------------
local ns = EllesmereUI._ModuleNS["EllesmereUINameplates"]
if not ns then return end  -- module disabled: no options page

-- The options page frame pool (EllesmereUI_FramePool.lua): frames made under a
-- pooled page part are handed back to the page's next build.
local CreateFrame = EllesmereUI._Pool.CreateFrame

-- The nameplate Threat % cog's rows (WoW Forever): get(key) reads the
-- profile, set(key, v) writes it and refreshes the text.
if EllesmereUI.IS_FOREVER then
    function ns.NPO_ThreatPctRows(get, set)
        local function Slider(key, label, lo, hi)
            return { type="slider", label=label, min=lo, max=hi, step=1,
              get=function() return get(key) end,
              set=function(v) set(key, v) end }
        end
        -- The gap colours show while the gap is picked and coloured.
        local function GapColorOff()
            return get("threatPctMode") ~= "gap" or not get("threatPctColorByThreat")
        end
        local function GapColor(key, label, tip)
            return { type="colorpicker", label=label, tooltip=tip, hidden=GapColorOff,
              get=function()
                local c = get(key)
                if c then return c.r, c.g, c.b end
                return 1, 1, 1
              end,
              set=function(r, g, b) set(key, { r = r, g = g, b = b }) end }
        end
        return {
            { type="dropdown", label="Text Shows",
              values={ percent = "Threat %", gap = "Threat Gap" }, order={ "percent", "gap" },
              tooltip="Threat Gap shows on your target's plate only.",
              get=function() return get("threatPctMode") or "percent" end,
              set=function(v) set("threatPctMode", v) end },
            { type="toggle", label="Color by Threat",
              tooltip="Colors the number. Off shows it in white.",
              get=function() return get("threatPctColorByThreat") end,
              set=function(v) set("threatPctColorByThreat", v) end },
            GapColor("threatGapAheadColor", "Ahead Color", "When your threat is higher."),
            GapColor("threatGapBehindColor", "Behind Color", "When theirs is higher."),
            Slider("threatPctSize", "Size", 6, 20),
            Slider("threatPctXOffset", "X Offset", -300, 300),
            Slider("threatPctYOffset", "Y Offset", -300, 300),
        }
    end
end

-- EUI_DEBUFF_COLORS: the per-class debuff lists (the list kit lives in
-- EllesmereUINameplates_DebuffColors.lua). One expandable card
-- per class that holds an entry, its icon and its name in its class color on
-- the header; Add Class, one wide button below them, starts one. Inside, the debuffs run down the left column
-- and the combos down the right, each with up/down arrows beside its name
-- that reorder it (the higher entry wins) and an Add button closing its
-- column. Every edit reaches the plates as it is made (the runtime
-- rebuilds at most once a frame, and only for the player's own class); a
-- color drag waits for the picker to close. debuffColorAdded: the entry Add
-- just made, kept across the page rebuild Add runs so the rebuilt row
-- reports the write to Spec Overrides. debuffColorOpen: the expanded cards
-- by class token, for the session (the player's starts expanded).
local debuffColorAdded
local debuffColorOpen = {}
function ns.NP_BuildDebuffColorsOptions(parent, y)
    local DC = ns.DebuffColorKit
    if not DC then return y end
    local W = EllesmereUI.Widgets
    local PP = EllesmereUI.PanelPP
    local function Get(key)
        local db = ns.db and ns.db.profile
        if db and db[key] ~= nil then return db[key] end
        return ns.defaults[key]
    end
    local function Off() return Get("debuffColorsEnabled") ~= true end
    local function Read(class) return DC.Read(class, Get) end
    -- Every edit applies at once. The color picker writes on every frame of a
    -- drag, so while it is open the refresh waits for it to close.
    local function Apply()
        if EllesmereUI._colorPickerOpen then
            EllesmereUI._deferredDriftChecks = EllesmereUI._deferredDriftChecks or {}
            EllesmereUI._deferredDriftChecks[ns.DebuffColors_RequestRefresh] = true
        else
            ns.DebuffColors_RequestRefresh()
        end
    end
    -- rgn: the row reporting the write to Spec Overrides, its slot read before the
    -- write (a structure change then rebuilds the page, dressing the row again).
    local function Write(class, singles, combos, rgn)
        local snap = rgn and EllesmereUI._SOAttribution(rgn)
        ns.db.profile[DC.Key(class)] = DC.Encode(singles, combos)
        if rgn then EllesmereUI._NotifySettingWrite(rgn, snap) end
        Apply()
    end
    local function Rebuild() EllesmereUI:RefreshPage(true) end
    local function SpellName(id, fallback)
        return (id and C_Spell and C_Spell.GetSpellName(id)) or fallback
    end
    local function SpellIcon(id)
        if not id then return end
        local texture = C_Spell and C_Spell.GetSpellTexture(id)
        if texture then return texture end
        local info = C_Spell and C_Spell.GetSpellInfo(id)
        local preset = ns.DebuffColorPresetByID[id]
        return (info and info.iconID) or (preset and preset[4])
            or "Interface\\Icons\\INV_Misc_QuestionMark"
    end
    local function CopyColor(c) return { r = c.r, g = c.g, b = c.b } end
    -- A list's chosen spells, each once, in priority order.
    local function Chosen(singles)
        local out, seen = {}, {}
        for _, e in ipairs(singles) do
            if e.spell > 0 and not seen[e.spell] then
                seen[e.spell] = true
                out[#out + 1] = e.spell
            end
        end
        return out
    end

    -- Classes: the player's first, then the rest alphabetically. Only the
    -- classes this client has (a class's saved list elsewhere stays as is).
    local _, playerClass = UnitClass("player")
    local NAME, ORDER = {}, {}
    if EllesmereUI.IS_FOREVER then
        for _, file in ipairs(EllesmereUI.ForeverClasses()) do
            NAME[file] = EllesmereUI.ForeverClassName(file)
            ORDER[#ORDER + 1] = file
        end
    else
        for i = 1, (GetNumClasses and GetNumClasses() or 0) do
            local name, file = GetClassInfo(i)
            if name and file then
                NAME[file] = name
                ORDER[#ORDER + 1] = file
            end
        end
    end
    table.sort(ORDER, function(a, b)
        if (a == playerClass) ~= (b == playerClass) then return a == playerClass end
        return NAME[a] < NAME[b]
    end)
    local CLASS_VALUES = { _noLoc = true }
    for _, class in ipairs(ORDER) do
        local c = EllesmereUI.GetClassColor(class)
        CLASS_VALUES[class] = EllesmereUI.HexColor(c.r, c.g, c.b) .. NAME[class] .. "|r"
    end

    -- The presets for the spell menus (WoW Forever lists none: they are
    -- retail spell IDs). A debuff row offers only its own class's presets, in
    -- the preset table's order; any other spell it holds reads as custom.
    local classPresets = {}
    if not EllesmereUI.IS_FOREVER then
        for _, spell in ipairs(ns.DebuffColorPresets) do
            local token = spell[3]:gsub("%s", ""):upper()
            local set = classPresets[token]
            if not set then
                set = { order = { "remove", "custom" }, byKey = {} }
                classPresets[token] = set
            end
            local key = tostring(spell[1])
            set.order[#set.order + 1] = key
            set.byKey[key] = { id = spell[1], name = SpellName(spell[1], spell[2]), class = spell[3] }
        end
    end
    local NO_PRESETS = { order = { "remove", "custom" }, byKey = {} }
    local function Presets(class) return classPresets[class] or NO_PRESETS end
    -- A class's custom spells: every spell its lists hold that is not one of
    -- its presets, once each, debuffs first. Each is an item of the class's
    -- spell menus for as long as something holds it.
    local function Customs(class)
        local own, out, seen = Presets(class).byKey, {}, {}
        local singles, combos = Read(class)
        local function Add(id)
            local key = tostring(id)
            if id > 0 and not own[key] and not seen[key] then
                seen[key] = true
                out[#out + 1] = key
            end
        end
        for _, e in ipairs(singles) do Add(e.spell) end
        for _, k in ipairs(combos) do
            for _, id in ipairs(k.spells) do Add(id) end
        end
        return out
    end

    -- A row reads by its place on its class's card ("1. Debuff"). FullLabel
    -- names it across classes: its popup title, and the text Spec Overrides
    -- keys its entry by (two classes' rows share a visible label).
    local function Label(cell)
        if cell.kind == "combo" then return EllesmereUI.Lf("%1$d. Combo", cell.n) end
        return EllesmereUI.Lf("%1$d. Debuff", cell.n)
    end
    local function MissingOf(cell)
        local e = Read(cell.class)[cell.n]
        return e ~= nil and e.missing == true
    end
    local function FullLabel(cell)
        if cell.kind == "combo" then
            return EllesmereUI.Lf("%1$s Combo %2$d", NAME[cell.class], cell.n)
        end
        return EllesmereUI.Lf("%1$s Debuff %2$d", NAME[cell.class], cell.n)
    end
    local function SpellOf(cell)
        local e = Read(cell.class)[cell.n]
        return e and e.spell or 0
    end
    -- A spell another debuff of the class already holds in the same state:
    -- picking it again would only duplicate that row, so its menu item is greyed
    -- with the reason and Custom Spell... refuses it (the arrows move a debuff).
    local IN_USE = "Already in use. Use the arrows to reorder."
    local function HeldElsewhere(cell, id, missing, singles)
        if missing == nil then missing = MissingOf(cell) end
        for n, e in ipairs(singles or Read(cell.class)) do
            if n ~= cell.n and e.spell == id and (e.missing == true) == missing then return true end
        end
        return false
    end
    -- Whether MAX_MISSING other rows already color a chosen debuff while it is
    -- missing (the plates draw no more). above: only rows higher in the list
    -- count, as the plates keep the first MAX_MISSING.
    local MISSING_FULL = EllesmereUI.Lf("Up to %1$d debuffs can be Missing.", DC.MAX_MISSING)
    local function MissingFull(cell, singles, above)
        local ids, n = {}, 0
        for i, e in ipairs(singles or Read(cell.class)) do
            if above and i >= cell.n then break end
            if i ~= cell.n and e.missing and e.spell > 0 and not ids[e.spell] then
                ids[e.spell], n = true, n + 1
            end
        end
        return n >= DC.MAX_MISSING
    end
    local function ComboSpells(cell)
        local _, combos = Read(cell.class)
        local k = combos[cell.n]
        return k and k.spells or {}
    end

    -- List edits. Structure changes (add, remove, reorder) rebuild the page;
    -- the edited or new row reports the write to Spec Overrides.
    local function SetSpell(cell, id, rgn)
        local singles, combos = Read(cell.class)
        local e = singles[cell.n]
        if not e or e.spell == id then return end
        e.spell = id
        Write(cell.class, singles, combos, rgn)
        EllesmereUI:RefreshPage()
    end
    local function SetMissing(cell, missing)
        local singles, combos = Read(cell.class)
        singles[cell.n].missing = missing or nil
        Write(cell.class, singles, combos, cell.rgn)
        EllesmereUI:RefreshPage()
    end
    local function Move(cell, dir)
        local singles, combos = Read(cell.class)
        local list = cell.kind == "combo" and combos or singles
        local j = cell.n + dir
        if not (list[cell.n] and list[j]) then return end
        list[cell.n], list[j] = list[j], list[cell.n]
        Write(cell.class, singles, combos, cell.rgn)
        Rebuild()
    end
    local function Remove(cell)
        local singles, combos = Read(cell.class)
        local list = cell.kind == "combo" and combos or singles
        if not list[cell.n] then return end
        table.remove(list, cell.n)
        Write(cell.class, singles, combos, cell.rgn)
        Rebuild()
    end
    -- A new debuff starts unchosen; a new combo pairs the class's top two.
    local function AddSingle(class)
        local singles, combos = Read(class)
        if #singles >= DC.MAX_SINGLES then return end
        singles[#singles + 1] = { spell = 0, color = CopyColor(DC.SINGLE_COLOR) }
        Write(class, singles, combos)
        debuffColorOpen[class] = true
        debuffColorAdded = { kind = "single", class = class, n = #singles }
        Rebuild()
        debuffColorAdded = nil
    end
    local function ComboRoom(class)
        local singles, combos = Read(class)
        return #combos < DC.MAX_COMBOS and #Chosen(singles) >= 2
    end
    local function AddCombo(class)
        if not ComboRoom(class) then return end
        local singles, combos = Read(class)
        local picks = Chosen(singles)
        combos[#combos + 1] = { spells = { picks[1], picks[2] }, color = CopyColor(DC.COMBO_COLOR) }
        Write(class, singles, combos)
        debuffColorAdded = { kind = "combo", class = class, n = #combos }
        Rebuild()
        debuffColorAdded = nil
    end

    -- Debuff Coloring: a pure view over debuffColorsEnabled (off = None) and
    -- the module's mode (DC.Mode: Texture Nameplate and Color Name in
    -- debuffColorsMode, else debuffColorsBorder picks Color Border or Color
    -- Nameplate). Color Border's cog (Extra Border Size) shows only over a
    -- Basic or Custom Solid border; a textured custom border is recolored as it
    -- is. Both checks follow the runtime's border reading (BorderSpec in the module).
    local function Mode()
        if Off() then return "none" end
        return DC.Mode(Get)
    end
    local function NoBorder()
        if EllesmereUI.BlizzStyle.Get("nameplates") then return true end
        if Get("customBorderEnabled") then
            if (Get("customBorderSize") or 0) <= 0 then return true end
            -- A textured border whose art no longer resolves (its media pack
            -- removed) draws nothing.
            local tex = Get("customBorderTexture")
            return tex ~= nil and tex ~= "" and tex ~= "solid"
                and not EllesmereUI.ResolveBorderTexture(tex)
        end
        return Get("showBorder") == false
    end
    local function StripBorder()
        if NoBorder() then return false end
        if Get("customBorderEnabled") then
            local tex = Get("customBorderTexture")
            return not tex or tex == "" or tex == "solid"
        end
        return true
    end
    local _, h, modeRow
    _, h = W:SectionHeader(parent, "DEBUFF BASED NAMEPLATE COLORING", y); y = y - h
    modeRow, h = W:DualRow(parent, y,
        { type="dropdown", text="Debuff Coloring",
          values={ none = "None", nameplate = "Color Nameplate", texture = "Texture Nameplate",
                   border = "Color Border", name = "Color Name" },
          order={ "none", "nameplate", "texture", "border", "name" },
          disabledValues=function(key)
              if key == "border" and NoBorder() then return "This option requires a Border to be selected" end
              if key == "name" and not ns.FindNameSlot() then return "This option requires the enemy name to be shown" end
              return false
          end,
          getValue=Mode,
          setValue=EllesmereUI.SectionToggleSetValue(function(v)
              local db = ns.db.profile
              db.debuffColorsEnabled = v ~= "none"
              if v ~= "none" then
                  db.debuffColorsBorder = v == "border"
                  db.debuffColorsMode = (v == "texture" or v == "name") and v or nil
              end
              ns.DebuffColors_Refresh()
          end),
          tooltip="Colors enemy health bars, their borders or their names while the chosen debuffs are on them." },
        { type="toggle", text="Only My Debuffs",
          getValue=function() return Get("debuffColorsPlayerOnly") ~= false end,
          setValue=function(v)
              ns.db.profile.debuffColorsPlayerOnly = v
              Apply()
          end,
          disabled=Off, disabledTooltip="Debuff Coloring",
          tooltip="Counts only the debuffs you applied." }); y = y - h

    -- Color Border's cog, built while it is picked (the dropdown rebuilds the
    -- page) and shown only over a border drawn as strips; a border change on
    -- the Display page reaches it through the page's refreshers.
    if Mode() == "border" then
        local cog = EllesmereUI.BuildInlineCog(modeRow._leftRegion, {
            title = "Color Border",
            rows = {
                { type="slider", label="Extra Border Size", min=0, max=4, step=1,
                  tooltip="Thickens the border by this many pixels while it shows a debuff color.",
                  get=function() return Get("debuffColorsBorderExtra") or 0 end,
                  set=function(v)
                      ns.db.profile.debuffColorsBorderExtra = v
                      Apply()
                  end },
            },
        })
        if not EllesmereUI._prebuilding then
            local function ShowCog() cog:SetShown(StripBorder()) end
            ShowCog()
            EllesmereUI.RegisterWidgetRefresh(ShowCog)
        end
    end

    -- Texture Nameplate's texture, the row below while it is picked (unset reads
    -- the health bar's own).
    if Mode() == "texture" then
        local env = ns._NPO_OptEnv
        _, h = W:DualRow(parent, y,
            { type="dropdown", text="Texture", values=env.hbtValues, order=env.hbtOrder,
              tooltip="The texture the debuff color is drawn in.",
              getValue=function() return Get("debuffColorsTexture") or Get("healthBarTexture") or "none" end,
              setValue=function(v)
                  ns.db.profile.debuffColorsTexture = v
                  Apply()
              end },
            EllesmereUI.BlankRowCfg()); y = y - h
    end

    -- Section gate: the rows below exist only while Debuff Coloring is on (the
    -- dropdown's SectionToggleSetValue rebuilds the page).
    if Off() then
        _, h = W:Spacer(parent, y, 20); y = y - h
        return y
    end

    -- Up/down arrows beside a row's name (white, the accent while hovered;
    -- a darker white when the accent itself is white). The first entry
    -- cannot move up nor the last down.
    local UP_ICON = "Interface\\AddOns\\EllesmereUI\\media\\icons\\eui-arrow-up3.png"
    local DOWN_ICON = "Interface\\AddOns\\EllesmereUI\\media\\icons\\eui-arrow-down3.png"
    local function HoverColor()
        local ac = EllesmereUI.ELLESMERE_GREEN
        if ac.r > 0.9 and ac.g > 0.9 and ac.b > 0.9 then return 0.72, 0.72, 0.72 end
        return ac.r, ac.g, ac.b
    end
    local function Arrow(rgn, texture, tip, enabled, onClick)
        local btn = CreateFrame("Button", nil, rgn)
        btn:SetFrameLevel(rgn:GetFrameLevel() + 12)
        btn:SetSize(16, 20)
        local icon = btn:CreateTexture(nil, "ARTWORK")
        icon:SetTexture(texture)
        icon:SetSize(16, 16)
        icon:SetPoint("CENTER")
        if not enabled then
            icon:SetAlpha(0.2)
            btn:EnableMouse(false)
            return btn
        end
        btn:SetScript("OnEnter", function()
            icon:SetVertexColor(HoverColor())
            EllesmereUI.ShowWidgetTooltip(btn, tip)
        end)
        btn:SetScript("OnLeave", function()
            icon:SetVertexColor(1, 1, 1)
            EllesmereUI.HideWidgetTooltip()
        end)
        btn:SetScript("OnClick", function()
            EllesmereUI.HideWidgetTooltip()
            onClick()
        end)
        return btn
    end
    local function ReorderArrows(rgn, cell)
        local label = rgn._label
        local up = Arrow(rgn, UP_ICON, "Move Up", cell.n > 1, function() Move(cell, -1) end)
        up:SetPoint("LEFT", label, "LEFT", math.ceil(label:GetStringWidth()) + 6, -1)
        local down = Arrow(rgn, DOWN_ICON, "Move Down", cell.n < cell.count, function() Move(cell, 1) end)
        down:SetPoint("LEFT", up, "RIGHT", 0, 0)
    end

    local SINGLE_TIP = "Higher in the list wins when several are up."
    local COMBO_TIP = "Combos win over single debuffs; higher in the list wins."
    local STATE_ORDER = { "applied", "missing" }
    local STATE_VALUES = { applied = "Applied", missing = "Missing", _menuOpts = {
        onItemHover = function(key, item)
            if key == "missing" then
                EllesmereUI.ShowWidgetTooltip(item, EllesmereUI.L("Colors enemies you fight without this debuff."))
            end
        end,
        onItemLeave = function() EllesmereUI.HideWidgetTooltip() end,
    } }

    -- A debuff: its spell menu (Remove, Custom Spell..., the class's presets,
    -- then its custom spells) with its color inline. The custom tail follows
    -- edits on every row of the class (cell.syncCustoms, run by the row's
    -- refresher); Custom Spell... is an action: it adds a spell and keeps its label.
    local function SingleCfg(cell)
        local own = Presets(cell.class)
        local values = { _noLoc = true, none = EllesmereUI.L("None"),
            remove = { text = EllesmereUI.L("Remove"), action = function() Remove(cell) end } }
        for key, s in pairs(own.byKey) do values[key] = s.name end
        local order = {}
        for i, key in ipairs(own.order) do order[i] = key end
        local base = #order
        -- True when the menu's items changed (it must rebuild).
        function cell.syncCustoms()
            local customs, changed = Customs(cell.class), false
            for i, key in ipairs(customs) do
                if order[base + i] ~= key then
                    order[base + i] = key
                    changed = true
                end
                local name = SpellName(tonumber(key), "Spell " .. key)
                if values[key] ~= name then
                    values[key] = name
                    changed = true
                end
            end
            for i = #order, base + #customs + 1, -1 do
                order[i] = nil
                changed = true
            end
            return changed
        end
        cell.syncCustoms()
        values.custom = { text = EllesmereUI.L("Custom Spell..."), action = function()
            EllesmereUI:ShowInputPopup({
                title=FullLabel(cell), confirmText="Add", cancelText="Cancel",
                message="Enter the debuff's spell ID.",
                placeholder="Spell ID", maxLetters=10,
                onConfirm=function(text)
                    local value = DC.SpellID((text or ""):match("^%s*(%d+)%s*$"))
                    if not (value and C_Spell and C_Spell.GetSpellInfo(value)) then
                        EllesmereUI.PrintError(EllesmereUI.L("Enter a valid debuff spell ID."))
                        return
                    end
                    if HeldElsewhere(cell, value) then
                        EllesmereUI.PrintError(EllesmereUI.L("Already in use. Use the arrows to reorder."))
                        return
                    end
                    if MissingOf(cell) and MissingFull(cell, nil, SpellOf(cell) > 0) then
                        EllesmereUI.PrintError(MISSING_FULL)
                        return
                    end
                    SetSpell(cell, value, cell.rgn)
                end,
            })
        end }
        values._menuOpts = {
            searchable=true, itemHeight=28, maxHeight=280, iconNativeColor=true,
            icon=function(key)
                local id = tonumber(key)
                return SpellIcon(id and id > 0 and id), .08, .92, .08, .92
            end,
            onItemHover=function(key, item)
                local spell = own.byKey[key]
                if spell then
                    EllesmereUI.ShowWidgetTooltip(item, spell.class .. " | " .. EllesmereUI.Lf("Spell ID: %1$s", spell.id))
                elseif tonumber(key) then
                    EllesmereUI.ShowWidgetTooltip(item, EllesmereUI.Lf("Spell ID: %1$s", key))
                end
            end,
            onItemLeave=function() EllesmereUI.HideWidgetTooltip() end,
        }
        return { type="dropdown", text=Label(cell), values=values, order=order,
            getValue=function()
                local id = SpellOf(cell)
                if id == 0 then return "none" end
                return tostring(id)
            end,
            setValue=function(v)
                local id = DC.SpellID(v)
                if id then SetSpell(cell, id) end
            end,
            -- Never the row's own spell (a list saved with a duplicate keeps
            -- its label lit). A Missing row past MAX_MISSING shows why it colors
            -- nothing; an unchosen one may not take a spell once the rest are full.
            disabledValues=function(key)
                local id, singles = tonumber(key), Read(cell.class)
                local e = singles[cell.n]
                if not id or (e and e.spell == id) then return false end
                local missing = e ~= nil and e.missing == true
                if HeldElsewhere(cell, id, missing, singles) then return IN_USE end
                return missing and MissingFull(cell, singles, e.spell > 0) and MISSING_FULL or false
            end,
            tooltip=SINGLE_TIP }
    end
    -- Applied / Missing, beside the spell menu; a state a same-spell row holds is
    -- greyed, and Missing once MAX_MISSING rows use it.
    local function StateDropdown(rgn, cell)
        local dd = EllesmereUI.BuildDropdownControl(rgn, 90, rgn:GetFrameLevel() + 3, STATE_VALUES, STATE_ORDER,
            function() return MissingOf(cell) and "missing" or "applied" end,
            function(v) SetMissing(cell, v == "missing") end,
            function(key)
                local singles, missing = Read(cell.class), key == "missing"
                local e = singles[cell.n]
                if not e or missing == (e.missing == true) then return false end
                if missing and MissingFull(cell, singles) then return MISSING_FULL end
                return e.spell > 0 and HeldElsewhere(cell, e.spell, missing, singles)
                    and "Another row already uses this debuff this way." or false
            end)
        PP.Point(dd, "RIGHT", rgn._lastInline or rgn._control, "LEFT", -8, 0)
        rgn._lastInline = dd
        EllesmereUI.RegisterWidgetRefresh(dd._refreshLabel)
    end
    local function SingleChrome(rgn, cell)
        ReorderArrows(rgn, cell)
        -- The menu rebuilds only when its custom spells change.
        local function Sync()
            local ctrl = rgn._control
            if cell.syncCustoms() and ctrl._invalidateMenu then ctrl._invalidateMenu() end
            if ctrl._refreshLabel then ctrl._refreshLabel() end
        end
        Sync()
        EllesmereUI.RegisterWidgetRefresh(Sync)
        StateDropdown(rgn, cell)
        EllesmereUI.BuildInlineSwatches(rgn, { {
            tooltip = "Debuff Color",
            getValue = function()
                local e = Read(cell.class)[cell.n]
                local c = e and e.color or DC.SINGLE_COLOR
                return c.r, c.g, c.b
            end,
            setValue = function(r, g, b)
                local singles, combos = Read(cell.class)
                local e = singles[cell.n]
                if not e then return end
                e.color = { r = r, g = g, b = b }
                Write(cell.class, singles, combos)
            end,
            disabled = function() return SpellOf(cell) == 0 end,
            disabledTooltip = "This option requires a debuff to be selected",
        } })
    end

    -- A combo: a checkbox list of its class's debuffs (two to four checked),
    -- Remove above them, its color inline. The row's own dropdown, hidden
    -- under the list, reads and writes the combo's spells.
    local function SetComboSpells(cell, spells, rgn)
        local singles, combos = Read(cell.class)
        local k = combos[cell.n]
        if not k then return end
        k.spells = spells
        Write(cell.class, singles, combos, rgn)
    end
    local COMBO_VALUES = setmetatable({}, { __index = function(_, key)
        if type(key) ~= "string" or key:sub(1, 1) == "_" then return nil end
        local names = {}
        for id in key:gmatch("%d+") do names[#names + 1] = SpellName(tonumber(id), "Spell " .. id) end
        return #names > 0 and table.concat(names, " + ") or nil
    end })
    local function ComboCfg(cell)
        return { type="dropdown", text=Label(cell), values=COMBO_VALUES, order={},
            getValue=function() return table.concat(ComboSpells(cell), "+") end,
            setValue=function(v)
                local spells = {}
                for id in tostring(v):gmatch("%d+") do
                    id = DC.SpellID(id)
                    if id and #spells < DC.MAX_COMBO_SPELLS then spells[#spells + 1] = id end
                end
                SetComboSpells(cell, spells)
            end,
            tooltip=COMBO_TIP }
    end
    local function ComboChrome(rgn, cell)
        ReorderArrows(rgn, cell)
        local function Has(id)
            for _, s in ipairs(ComboSpells(cell)) do
                if s == id then return true end
            end
            return false
        end
        local function Valid()
            local seen, n = {}, 0
            for _, s in ipairs(ComboSpells(cell)) do
                if not seen[s] then seen[s] = true; n = n + 1 end
            end
            return n >= 2
        end
        -- Its class's chosen debuffs, then any spell only the combo holds.
        local function Items()
            local items = { { key = "_remove", label = "Remove", isTopAction = true,
                onClick = function() Remove(cell) end } }
            local listed = {}
            local function Add(id)
                if listed[id] then return end
                listed[id] = true
                items[#items + 1] = { key = tostring(id), label = SpellName(id, "Spell " .. id),
                    icon = SpellIcon(id),
                    lockedFn = function() return not Has(id) and #ComboSpells(cell) >= DC.MAX_COMBO_SPELLS end,
                    lockedTooltip = "A combo holds up to four debuffs." }
            end
            for _, id in ipairs(Chosen((Read(cell.class)))) do Add(id) end
            for _, id in ipairs(ComboSpells(cell)) do Add(id) end
            return items
        end
        local ctrl = rgn._control
        local ddW = ctrl and ctrl:GetWidth() or 0
        if ddW < 50 then ddW = 170 end
        local pulse
        local cbDD, cbRefresh = EllesmereUI.BuildVisOptsCBDropdown(rgn, ddW, rgn:GetFrameLevel() + 2,
            Items,
            function(key) return Has(tonumber(key)) end,
            function(key, on)
                local id = tonumber(key)
                local spells = {}
                for _, s in ipairs(ComboSpells(cell)) do
                    if s ~= id then spells[#spells + 1] = s end
                end
                if on and #spells < DC.MAX_COMBO_SPELLS then spells[#spells + 1] = id end
                SetComboSpells(cell, spells)
            end,
            nil, 8, false, false,
            function() if pulse then pulse() end end,
            { notifyWrites = true, noAllLabel = true, separatorFn = function() return " + " end })
        local p1, rel, p2, ax, ay
        if ctrl then
            p1, rel, p2, ax, ay = ctrl:GetPoint(1)
            ctrl:Hide()
        end
        if p1 then cbDD:SetPoint(p1, rel, p2, ax, ay)
        else PP.Point(cbDD, "RIGHT", rgn, "RIGHT", -20, 0) end
        rgn._control = cbDD
        rgn._lastInline = nil
        EllesmereUI.RegisterWidgetRefresh(cbRefresh)
        pulse = EllesmereUI.AttachEmptyFilterWarn(rgn, cbDD, EllesmereUI.L("Pick at least two debuffs"), Valid)
        EllesmereUI.BuildInlineSwatches(rgn, { {
            tooltip = "Combo Color",
            getValue = function()
                local _, combos = Read(cell.class)
                local k = combos[cell.n]
                local c = k and k.color or DC.COMBO_COLOR
                return c.r, c.g, c.b
            end,
            setValue = function(r, g, b)
                local singles, combos = Read(cell.class)
                local k = combos[cell.n]
                if not k then return end
                k.color = { r = r, g = g, b = b }
                Write(cell.class, singles, combos)
            end,
        } })
    end

    -- Add Class opens the classes that have no card yet (the standard
    -- dropdown menu, as wide as the button, built on first open).
    local ADD_W, CLASS_W = 220, 450
    local NO_PAINT = { SetColor = function() end, SetColorTexture = function() end }
    local function AddPicker(btn, order, pick)
        -- Its own hover look, kept past the menu wiring (which takes the scripts).
        local enter, leave = btn:GetScript("OnEnter"), btn:GetScript("OnLeave")
        local proxyLbl = EllesmereUI.MakeFont(btn, 12, nil, 1, 1, 1)
        proxyLbl:Hide()
        local menu
        local function EnsureMenu()
            if menu then return menu end
            local refresh
            menu, _, refresh = EllesmereUI.BuildDropdownMenu(btn, CLASS_W, order, CLASS_VALUES,
                function() return nil end, pick, proxyLbl, "regular")
            EllesmereUI.WireDropdownScripts(btn, proxyLbl, NO_PAINT, NO_PAINT, menu, refresh, EllesmereUI.RD_DD_COLOURS, true)
            btn:HookScript("OnEnter", enter)
            btn:HookScript("OnLeave", function(self) if not menu:IsShown() then leave(self) end end)
            menu:HookScript("OnHide", function() if not btn:IsMouseOver() then leave(btn) end end)
            return menu
        end
        btn:HookScript("OnHide", function() if menu then menu:Hide() end end)
        return function()
            local m = EnsureMenu()
            if m:IsShown() then m:Hide() else m:Show() end
        end
    end
    local function SingleRoom(class) return #Read(class) < DC.MAX_SINGLES end
    local function AddSingleCfg(class)
        return { type="button", text="+ Add Debuff", width=ADD_W,
            onClick=function() AddSingle(class) end,
            disabled=function() return not SingleRoom(class) end,
            disabledTooltip="This class has ten debuffs.", rawTooltip=true }
    end
    local function AddComboCfg(class)
        return { type="button", text="+ Add Combo", width=ADD_W,
            onClick=function() AddCombo(class) end,
            disabled=function() return not ComboRoom(class) end,
            disabledTooltip="This option requires two debuffs for the same class" }
    end

    local function CellCfg(c)
        if c == nil then return EllesmereUI.BlankRowCfg() end
        if c.type then return c end
        return c.kind == "combo" and ComboCfg(c) or SingleCfg(c)
    end
    local function CellChrome(rgn, c)
        if EllesmereUI._prebuilding or c == nil or c.type then return end
        c.rgn = rgn
        if rgn._captureCfg then
            rgn._captureCfg = setmetatable({ text = FullLabel(c) }, { __index = rgn._captureCfg })
        end
        if c.kind == "combo" then ComboChrome(rgn, c) else SingleChrome(rgn, c) end
        -- The entry Add just made: its own row takes the write (its slot read now,
        -- while this build's row is its dress).
        local a = debuffColorAdded
        if a and a.kind == c.kind and a.class == c.class and a.n == c.n then
            debuffColorAdded = nil
            local snap = EllesmereUI._SOAttribution(rgn)
            EllesmereUI._NotifySettingWrite(rgn, snap)
        end
    end

    -- A class card's rows: its debuffs down the left column, its combos down
    -- the right, each column closed by its Add button. The shorter column
    -- leaves its slots blank so both read top to bottom in priority order.
    local DEBUFFS, COMBOS = "Debuffs", "Combos"
    local function ClassRows(class, singles, combos, cy)
        local titles, ch
        titles, ch = W:DualRow(parent, cy,
            { type="label", text="DEBUFFS", tooltip=SINGLE_TIP },
            { type="label", text="COMBOS", tooltip=COMBO_TIP }); cy = cy - ch
        -- The column titles read as section headers: their size and tint.
        local tint = EllesmereUI.TEXT_SECTION
        for _, rgn in ipairs({ titles._leftRegion, titles._rightRegion }) do
            local font, _, flags = rgn._label:GetFont()
            rgn._label:SetFont(font, 12, flags)
            rgn._label:SetTextColor(tint.r, tint.g, tint.b, tint.a)
        end
        local left, right = {}, {}
        for n = 1, #singles do
            left[n] = { kind = "single", class = class, n = n, count = #singles }
        end
        left[#left + 1] = AddSingleCfg(class)
        for n = 1, #combos do
            right[n] = { kind = "combo", class = class, n = n, count = #combos }
        end
        right[#right + 1] = AddComboCfg(class)
        for k = 1, math.max(#left, #right) do
            local l, r = left[k], right[k]
            local row
            row, ch = W:DualRow(parent, cy, CellCfg(l), CellCfg(r)); cy = cy - ch
            CellChrome(row._leftRegion, l)
            CellChrome(row._rightRegion, r)
        end
        return cy
    end
    -- The class icon on a card's header, in a 1px black border: the
    -- stock sheet's cell cropped past its own beveled frame (WoW Forever:
    -- the class's first spec icon; a class without one gets none).
    local CLASS_ICONS = "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES"
    local ICON_CROP = 0.1
    local function ClassGlyph(hdr, class)
        local box = CreateFrame("Frame", nil, hdr)
        PP.Size(box, 24, 24)
        PP.Point(box, "LEFT", hdr, "LEFT", 14, 0)
        local icon = box:CreateTexture(nil, "ARTWORK")
        icon:SetAllPoints()
        local coords = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
        if EllesmereUI.IS_FOREVER then
            icon:SetTexture(EllesmereUI.ForeverClassIcon(class))
            icon:SetTexCoord(.08, .92, .08, .92)
        elseif coords then
            local du = (coords[2] - coords[1]) * ICON_CROP
            local dv = (coords[4] - coords[3]) * ICON_CROP
            icon:SetTexture(CLASS_ICONS)
            icon:SetTexCoord(coords[1] + du, coords[2] - du, coords[3] + dv, coords[4] - dv)
        end
        EllesmereUI.MakeBorder(box, 0, 0, 0, 1, PP)
    end

    -- A class has a card while it holds an entry, the player's first; Add
    -- Class offers the rest.
    local listed, unlisted = {}, {}
    for _, class in ipairs(ORDER) do
        local singles, combos = Read(class)
        if #singles > 0 or #combos > 0 then
            listed[#listed + 1] = { class = class, singles = singles, combos = combos }
        else
            unlisted[#unlisted + 1] = class
        end
    end

    -- The cards (the house module card, as on Global Settings > Fonts), the
    -- first right under the settings above.
    if debuffColorOpen[playerClass] == nil then debuffColorOpen[playerClass] = true end
    for _, entry in ipairs(listed) do
        local class, singles, combos = entry.class, entry.singles, entry.combos
        local tile = { key = class, display = NAME[class],
            desc = EllesmereUI.L(DEBUFFS) .. ": " .. #singles .. "    " .. EllesmereUI.L(COMBOS) .. ": " .. #combos,
            buildContent = function(_, cy) return ClassRows(class, singles, combos, cy) end }
        y = EllesmereUI.BuildModuleCard(parent, y, W, tile, {
            enabled = true, expanded = debuffColorOpen, descW = 440,
            searchDesc = "Debuff Coloring",
            glyph = function(hdr) ClassGlyph(hdr, class) end })
        -- The card's title (its description line hangs off it) takes the
        -- class color at full strength.
        local _, title = tile._descFS:GetPoint(1)
        if title and title.SetTextColor then
            local c = EllesmereUI.GetClassColor(class)
            title:SetTextColor(c.r, c.g, c.b, 1)
        end
    end

    -- Add Class: a first, unchosen debuff gives the picked class its card.
    if #unlisted > 0 then
        local openClass, wide
        wide, h = W:WideButton(parent, "+ Add Class", y,
            function() if openClass then openClass() end end, CLASS_W); y = y - h
        if not EllesmereUI._prebuilding then
            -- The row's button: its one shown child (page reuse keeps the row's
            -- children of its earlier dresses among its children, hidden).
            local btn
            local kids = { wide:GetChildren() }
            for i = 1, #kids do
                if kids[i]:IsShown() then btn = kids[i]; break end
            end
            if btn then openClass = AddPicker(btn, unlisted, AddSingle) end
        end
    end
    _, h = W:Spacer(parent, y, 20); y = y - h
    return y
end

local function BuildColorsPage(pageName, parent, yOffset)
    local env = ns._NPO_OptEnv
    local DB, DBColor, DBVal, defaults = env.DB, env.DBColor, env.DBVal, env.defaults
    local pairs, PP = env.pairs, env.PP
    local RefreshAllPlates, SECTION_ENEMY, SECTION_THREAT, THREAT_PCT_POSITION_ORDER = env.RefreshAllPlates, env.SECTION_ENEMY, env.SECTION_THREAT, env.THREAT_PCT_POSITION_ORDER
    local THREAT_PCT_POSITIONS = env.THREAT_PCT_POSITIONS
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    -- No content header on Colors tab (presets are inline in scroll area)
    EllesmereUI:ClearContentHeader()

    -- Enable per-row center divider for the dual-column layout (same as Display tab)
    parent._showRowDivider = true

    -----------------------------------------------------------------------
    --  ENEMY COLORS
    -----------------------------------------------------------------------
    _, h = W:SectionHeader(parent, SECTION_ENEMY, y);  y = y - h

    -- Modify Out of Combat is a view over darkenEnemiesOOC + darkenOOCRecolor (the
    -- runtime ignores the recolor flag while darkening is off): No Change = off,
    -- Darken = on, Change Color = on with the recolor. A pick writes only the keys
    -- whose value it changes.
    local function OOCOn()
        local db = DB()
        if db and db.darkenEnemiesOOC ~= nil then return db.darkenEnemiesOOC end
        return defaults.darkenEnemiesOOC
    end
    local function OOCRecolorOn()
        local db = DB()
        local v = db and db.darkenOOCRecolor
        if v == nil then v = defaults.darkenOOCRecolor end
        return v
    end
    local function OOCMode()
        if not OOCOn() then return "none" end
        return OOCRecolorOn() and "color" or "darken"
    end

    -- Enemy Types | Modify Out of Combat
    local enemyTypesRow
    enemyTypesRow, h = W:DualRow(parent, y,
        { type="multiSwatch", text="Enemy Types",
          swatches = {
            { tooltip = "Enemies",
              getValue = function() return DBColor("enemyInCombat") end,
              setValue = function(r, g, b)
                DB().enemyInCombat = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "Spell Casters",
              getValue = function() return DBColor("caster") end,
              setValue = function(r, g, b)
                DB().caster = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "Mini-Bosses",
              getValue = function() return DBColor("miniboss") end,
              setValue = function(r, g, b)
                DB().miniboss = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "Bosses",
              getValue = function() return DBColor("boss") end,
              setValue = function(r, g, b)
                DB().boss = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
          } },
        { type="dropdown", text="Modify Out of Combat",
          values={ none = "No Change", darken = "Darken", color = "Change Color" },
          order={ "none", "darken", "color" },
          getValue=OOCMode,
          -- The inline color swatch exists only for Change Color: rebuild when that flips.
          setValue=EllesmereUI.DependentSetValue(function() return OOCMode() == "color" end, function(v)
            local on = v ~= "none"
            local db = DB()
            if OOCOn() ~= on then db.darkenEnemiesOOC = on end
            if on and OOCRecolorOn() ~= (v == "color") then db.darkenOOCRecolor = (v == "color") end
            if ns.NP_CastTintsDirty then ns.NP_CastTintsDirty() end
            for _, plate in pairs(ns.plates) do
                plate:UpdateHealthColor()
            end
            EllesmereUI:RefreshPage()
          end),
          tooltip="How enemy plates look while out of combat." });  y = y - h

    -- Change Color's flat color (MaybeDarken), inline beside the dropdown while
    -- that mode is picked.
    if not EllesmereUI._prebuilding and OOCMode() == "color" then
        EllesmereUI.BuildInlineSwatches(enemyTypesRow._rightRegion, {
            { tooltip = "Out of Combat Color",
              getValue = function()
                local db = DB()
                local c = (db and db.darkenOOCColor) or defaults.darkenOOCColor
                return c.r, c.g, c.b
              end,
              setValue = function(r, g, b)
                DB().darkenOOCColor = { r = r, g = g, b = b }
                if ns.NP_CastTintsDirty then ns.NP_CastTintsDirty() end
                for _, plate in pairs(ns.plates) do
                    plate:UpdateHealthColor()
                end
              end },
        })
    end

    -- Inline cog on "Enemy Types": Simple Coloring When Not In M+. On: outside 5-man dungeons, Mini/Caster/Miniboss/Boss all use the flat "All Enemies" color below (Neutral keeps its own); off (default) has no effect anywhere. Keys keep their owBasic* names from before the current UI label.
    do
        local leftRgn = enemyTypesRow._leftRegion
        local isOWOff = function()
            local v = DBVal("owBasicColoring")
            if v == nil then return not defaults.owBasicColoring end
            return not v
        end
        EllesmereUI.BuildInlineCog(leftRgn, {
            title = "Enemy Colors",
            rows = {
                { type="toggle", label="Simple Coloring When Not In M+",
                  get=function()
                    local v = DBVal("owBasicColoring")
                    if v == nil then return defaults.owBasicColoring end
                    return v
                  end,
                  set=function(v)
                    DB().owBasicColoring = v
                    RefreshAllPlates()
                  end },
                { type="colorpicker", label="All Enemies",
                  get=function() return DBColor("owBasicColor") end,
                  set=function(r, g, b)
                    DB().owBasicColor = { r = r, g = g, b = b }
                    RefreshAllPlates()
                  end,
                  disabled=isOWOff,
                  disabledTooltip="Simple Coloring When Not In M+" },
            },
        })
    end

    -- Neutral & Mini Enemies | Enable Quest Mob Color
    local neutralMiniRow
    neutralMiniRow, h = W:DualRow(parent, y,
        { type="multiSwatch", text="Neutral & Mini Enemies",
          swatches = {
            { tooltip = "Neutral",
              getValue = function() return DBColor("neutral") end,
              setValue = function(r, g, b)
                DB().neutral = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "Mini Enemies",
              -- Until explicitly set, views the user's "Enemies" color so the swatch starts matching enemyInCombat (see GetReactionColor).
              getValue = function()
                local db = DB()
                local c = (db and db.miniEnemy) or (db and db.enemyInCombat) or defaults.enemyInCombat
                return c.r, c.g, c.b
              end,
              setValue = function(r, g, b)
                DB().miniEnemy = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
          } },
        { type="toggle", text="Enable Quest Mob Color",
          getValue=function() return DBVal("questMobColorEnabled") == true end,
          setValue=function(v)
            DB().questMobColorEnabled = v
            for _, plate in pairs(ns.plates) do
                plate:UpdateHealthColor()
            end
            EllesmereUI:RefreshPage()
          end,
          tooltip="Colors enemy nameplates for quest mobs you still need to kill." });  y = y - h

    -- Inline Quest Mob Color swatch
    if not EllesmereUI._prebuilding then
        local rightRgn = neutralMiniRow._rightRegion
        local questColorGet = function()
            local c = DB().questMobColor or defaults.questMobColor
            return c.r, c.g, c.b
        end
        local questColorSet = function(r, g, b)
            DB().questMobColor = { r = r, g = g, b = b }
            RefreshAllPlates()
        end
        local isQuestOff = function() return DBVal("questMobColorEnabled") ~= true end
        local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rightRgn, rightRgn:GetFrameLevel() + 5, questColorGet, questColorSet, nil, 20)
        PP.Point(swatch, "RIGHT", rightRgn._control, "LEFT", -12, 0)
        EllesmereUI.RegisterWidgetRefresh(function()
            local off = isQuestOff()
            swatch:SetAlpha(off and 0.15 or 1)
            swatch:EnableMouse(not off)
            updateSwatch()
        end)
        local off = isQuestOff()
        swatch:SetAlpha(off and 0.15 or 1)
        swatch:EnableMouse(not off)
    end

    -- Inline cog on "Neutral & Mini Enemies": "Mini Coloring M+ Only" toggle. On (default) restricts the Mini Enemies color to 5-man dungeons; off applies it everywhere.
    do
        local leftRgn = neutralMiniRow._leftRegion
        EllesmereUI.BuildInlineCog(leftRgn, {
            title = "Mini Enemies",
            rows = {
                { type="toggle", label="Mini Coloring M+ Only",
                  get=function()
                    local v = DBVal("miniColoringMPlusOnly")
                    if v == nil then return defaults.miniColoringMPlusOnly end
                    return v
                  end,
                  set=function(v)
                    DB().miniColoringMPlusOnly = v
                    RefreshAllPlates()
                  end },
            },
        })
    end

    -- Color Casting Enemies | Enemy Players Use Enemy Color
    local castingRow
    castingRow, h = W:DualRow(parent, y,
        { type="toggle", text="Color Casting Enemies",
          getValue=function() return DBVal("castingEnemyColors") == true end,
          setValue=function(v)
            DB().castingEnemyColors = v
            RefreshAllPlates()
            EllesmereUI:RefreshPage()
          end,
          tooltip="Enemies not colored as Spell Casters take the Interruptible Caster or Uninterruptible Caster color once they cast a spell that can or cannot be interrupted." },
        { type="toggle", text="Enemy Players Use Enemy Color",
          getValue=function() return DBVal("enemyPlayerEnemyColor") == true end,
          setValue=function(v)
            DB().enemyPlayerEnemyColor = v
            RefreshAllPlates()
          end,
          tooltip="Enemy players take the Enemies color instead of their class color." });  y = y - h

    -- Inline cog with the mob types each applies to, then the Interruptible / Uninterruptible swatches.
    do
        local rgn = castingRow._leftRegion
        local isCastingOff = function() return DBVal("castingEnemyColors") ~= true end
        local typeItems = {
            { key="Normal",   label="Normal / Trivial", fixed=true },
            { key="Elite",    label="Elite",            fixed=true },
            { key="MiniBoss", label="Mini-Bosses",      fixed=true },
            { key="Boss",     label="Bosses",           fixed=true },
        }
        local function TypeRow(label, prefix)
            -- hint replaces the widget's "Drag to Reorder": every row is fixed.
            return { type="reordercheck", label=label, ddWidth=170, items=typeItems, hint="Enemy Types",
              get=function(key) return DBVal(prefix .. key) end,
              set=function(key, v)
                DB()[prefix .. key] = v
                RefreshAllPlates()
              end }
        end
        EllesmereUI.BuildInlineCog(rgn, {
            title = "Casting Enemies",
            disabled = isCastingOff,
            disabledTooltip = "Color Casting Enemies",
            rows = {
                TypeRow("Interruptible Applies To", "castingInt"),
                TypeRow("Uninterruptible Applies To", "castingUnint"),
            },
        })
        if not EllesmereUI._prebuilding then
            EllesmereUI.BuildInlineSwatches(rgn, {
                { tooltip = "Interruptible Caster",
                  getValue = function() return DBColor("castingIntColor") end,
                  setValue = function(r, g, b)
                    DB().castingIntColor = { r = r, g = g, b = b }
                    RefreshAllPlates()
                  end },
                { tooltip = "Uninterruptible Caster",
                  getValue = function() return DBColor("castingUnintColor") end,
                  setValue = function(r, g, b)
                    DB().castingUnintColor = { r = r, g = g, b = b }
                    RefreshAllPlates()
                  end },
            }, { disabled = isCastingOff, disabledTooltip = "Color Casting Enemies" })
        end
    end

    _, h = W:Spacer(parent, y, 20);  y = y - h

    -----------------------------------------------------------------------
    --  THREAT COLORS
    -----------------------------------------------------------------------
    _, h = W:SectionHeader(parent, SECTION_THREAT, y);  y = y - h

    -- Show Threat Colors (threatColorMode): Never / Instances (dungeons, raids and
    -- delves) / Group or Pet ("always": everywhere) / Always ("alwaysSolo"); an unknown
    -- saved value reads as the default. Never locks every threat-color control below.
    -- The WoW Forever Threat % rows are their own feature and stay live. Under the first
    -- two, damage dealers and healers get the colors in a group or with a pet out; Always
    -- drops that rule. On WoW Forever the tank shapes and Righteous Fury count as tanking
    -- while nobody in the group has the tank role.
    local function threatModeGet()
        local v = DBVal("threatColorMode")
        if v ~= "never" and v ~= "instances" and v ~= "always" and v ~= "alwaysSolo" then
            v = defaults.threatColorMode
        end
        return v
    end
    local function threatNever() return threatModeGet() == "never" end

    -- Row 1: Show Threat Colors (left) ---- Tank Threat (right)
    _, h = W:DualRow(parent, y,
        { type="dropdown", text="Show Threat Colors",
          tooltip="Where nameplates show threat colors.",
          values={ never="Never", instances="Instances", always="Group or Pet", alwaysSolo="Always" },
          order={ "never", "instances", "always", "alwaysSolo" },
          getValue=threatModeGet,
          setValue=function(v)
            DB().threatColorMode = v
            ns.NP_ApplyThreatColorMode()
            EllesmereUI:RefreshPage()
          end },
        { type="multiSwatch", text="Tank Threat",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          swatches = {
            { tooltip = "Losing Aggro",
              getValue = function() return DBColor("tankLosingAggro") end,
              setValue = function(r, g, b)
                DB().tankLosingAggro = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "No Aggro",
              getValue = function() return DBColor("tankNoAggro") end,
              setValue = function(r, g, b)
                DB().tankNoAggro = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
          } });  y = y - h

    -- Disabled-state helpers (shared across the toggle rows' swatches and cogs)
    local function isTankHasAggroDisabled()
        local db = DB()
        if db and db.tankHasAggroEnabled ~= nil then return not db.tankHasAggroEnabled end
        return not defaults.tankHasAggroEnabled
    end
    local function isClassicTankAggroDisabled()
        local db = DB()
        if db and db.classicTankAggro ~= nil then return not db.classicTankAggro end
        return not defaults.classicTankAggro
    end
    local function isOffTankDisabled()
        local db = DB()
        if db and db.offTankAggroEnabled ~= nil then return not db.offTankAggroEnabled end
        return not defaults.offTankAggroEnabled
    end
    local function isDpsNoAggroDisabled()
        local db = DB()
        if db and db.dpsNoAggroEnabled ~= nil then return not db.dpsNoAggroEnabled end
        return not defaults.dpsNoAggroEnabled
    end
    -- The Override toggles only reorder the health bar's color priority, so the No Aggro
    -- and Has Aggro cogs (Override rows only) lock while Show Threat On leaves the Health Bar out.
    local function isThreatHealthOff() return not ns.GetThreatColorHealth() end

    -- Inline swatch lock for the toggle rows: dimmed and click-blocked while its own
    -- toggle is off or Show Threat Colors is Never; the block names the missing one.
    local function LockThreatSwatch(swatch, updateSwatch, ownOff, ownReq)
        local tipCfg = { disabledTooltip = function()
            if threatNever() then return "Show Threat Colors" end
            return ownReq
        end }
        local block = CreateFrame("Frame", nil, swatch)
        block:SetAllPoints()
        block:SetFrameLevel(swatch:GetFrameLevel() + 10)
        block:EnableMouse(true)
        block:SetScript("OnEnter", function()
            EllesmereUI.ShowWidgetTooltip(swatch, EllesmereUI.ResolveDisabledTip(tipCfg))
        end)
        block:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
        local function State()
            local off = threatNever() or ownOff()
            swatch:SetAlpha(off and 0.3 or 1)
            block:SetShown(off)
        end
        EllesmereUI.RegisterWidgetRefresh(function()
            State()
            updateSwatch()
        end)
        State()
    end

    -- Row 2: Non-Tank Threat (left) ---- DPS: Show Special "No Aggro" Color (right)
    local nonTankRow
    nonTankRow, h = W:DualRow(parent, y,
        { type="multiSwatch", text="Non-Tank Threat",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          swatches = {
            { tooltip = "Has Aggro",
              getValue = function() return DBColor("dpsHasAggro") end,
              setValue = function(r, g, b)
                DB().dpsHasAggro = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
            { tooltip = "Near Aggro",
              getValue = function() return DBColor("dpsNearAggro") end,
              setValue = function(r, g, b)
                DB().dpsNearAggro = { r = r, g = g, b = b }
                RefreshAllPlates()
              end },
          } },
        { type="toggle", text="DPS: Show Special \"No Aggro\" Color",
          tooltip="Shows a special color for non caster/mini-boss enemies when you do not have aggro on them.",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          getValue=function()
            local db = DB()
            if db and db.dpsNoAggroEnabled ~= nil then return db.dpsNoAggroEnabled end
            return defaults.dpsNoAggroEnabled
          end,
          setValue=function(v)
            DB().dpsNoAggroEnabled = v
            RefreshAllPlates()
            EllesmereUI:RefreshPage()
          end });  y = y - h

    -- Inline cog on "Non-Tank Threat": steady red execute-style glow
    -- while the Near Aggro color is active (see EnsureNearAggroGlow).
    do
        EllesmereUI.BuildInlineCog(nonTankRow._leftRegion, {
            disabled = threatNever,
            disabledTooltip = "Show Threat Colors",
            title = "Near Aggro",
            rows = {
                { type="toggle", label="Glow Nameplate When Near Aggro",
                  tooltip="Adds a steady red glow around the nameplate while the Near Aggro color is active.",
                  get=function()
                    local db = DB()
                    local v = db and db.threatNearAggroGlow
                    if v == nil then v = defaults.threatNearAggroGlow end
                    return v
                  end,
                  set=function(v)
                    DB().threatNearAggroGlow = v and true or false
                    for _, plate in pairs(ns.plates) do
                        plate:UpdateHealthColor()
                    end
                  end },
            },
        })
    end

    -- Inline cog next to the DPS toggle, then the "No Aggro" color swatch left of it
    do
        local rgn = nonTankRow._rightRegion
        local dpsNoAggroColorGet = function() return DBColor("dpsNoAggro") end
        local dpsNoAggroColorSet = function(r, g, b)
            DB().dpsNoAggro = { r = r, g = g, b = b }
            RefreshAllPlates()
        end

        -- Inline cog: independent "Override Mini-Boss colors" / "Override Caster colors" / "Override Boss colors" toggles promote the DPS No Aggro color above that single mob-type color (kept separate for contrast); dimmed while off.
        EllesmereUI.BuildInlineCog(rgn, {
            disabled = function() return threatNever() or isDpsNoAggroDisabled() or isThreatHealthOff() end,
            disabledTooltip = function()
                if threatNever() then return "Show Threat Colors" end
                if isDpsNoAggroDisabled() then return 'DPS: Show Special "No Aggro" Color' end
                return "Health Bar"
            end,
            title = "No Aggro",
            rows = {
                { type="toggle", label="Override Mini-Boss colors",
                  get=function()
                    local db = DB()
                    if db and db.dpsNoAggroOverrideMiniBoss ~= nil then return db.dpsNoAggroOverrideMiniBoss end
                    return defaults.dpsNoAggroOverrideMiniBoss
                  end,
                  set=function(v) DB().dpsNoAggroOverrideMiniBoss = v; RefreshAllPlates() end },
                { type="toggle", label="Override Caster colors",
                  get=function()
                    local db = DB()
                    if db and db.dpsNoAggroOverrideCaster ~= nil then return db.dpsNoAggroOverrideCaster end
                    return defaults.dpsNoAggroOverrideCaster
                  end,
                  set=function(v) DB().dpsNoAggroOverrideCaster = v; RefreshAllPlates() end },
                { type="toggle", label="Override Boss colors",
                  get=function()
                    local db = DB()
                    if db and db.dpsNoAggroOverrideBoss ~= nil then return db.dpsNoAggroOverrideBoss end
                    return defaults.dpsNoAggroOverrideBoss
                  end,
                  set=function(v) DB().dpsNoAggroOverrideBoss = v; RefreshAllPlates() end },
            },
        })
        if not EllesmereUI._prebuilding then
            local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rgn, rgn:GetFrameLevel() + 5, dpsNoAggroColorGet, dpsNoAggroColorSet, nil, 20)
            PP.Point(swatch, "RIGHT", rgn._lastInline or rgn._control, "LEFT", -8, 0)
            rgn._lastInline = swatch
            LockThreatSwatch(swatch, updateSwatch, isDpsNoAggroDisabled, 'DPS: Show Special "No Aggro" Color')
        end
    end

    -- Row 3: Classic Tank Aggro (left) ---- Tank: Show Special "Has Aggro" Color (right)
    local tankAggroRow
    tankAggroRow, h = W:DualRow(parent, y,
        { type="toggle", text="Classic Tank Aggro",
          tooltip="Enables a three-tier tank aggro system: has aggro, losing aggro, and no aggro colors override all mob-type colors.",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          getValue=function()
            local db = DB()
            if db and db.classicTankAggro ~= nil then return db.classicTankAggro end
            return defaults.classicTankAggro
          end,
          setValue=function(v)
            DB().classicTankAggro = v
            RefreshAllPlates()
            EllesmereUI:RefreshPage()
          end },
        { type="toggle", text="Tank: Show Special \"Has Aggro\" Color",
          tooltip="Shows a special color for non caster/mini-boss enemies when you have aggro on them.",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          getValue=function()
            local db = DB()
            if db and db.tankHasAggroEnabled ~= nil then return db.tankHasAggroEnabled end
            return defaults.tankHasAggroEnabled
          end,
          setValue=function(v)
            DB().tankHasAggroEnabled = v
            RefreshAllPlates()
            EllesmereUI:RefreshPage()
          end });  y = y - h

    -- Inline "Has Aggro" color swatch next to Classic Tank Aggro toggle
    if not EllesmereUI._prebuilding then
        local rgn = tankAggroRow._leftRegion
        local aggroColorGet = function() return DBColor("tankHasAggro") end
        local aggroColorSet = function(r, g, b)
            DB().tankHasAggro = { r = r, g = g, b = b }
            RefreshAllPlates()
        end
        local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rgn, rgn:GetFrameLevel() + 5, aggroColorGet, aggroColorSet, nil, 20)
        PP.Point(swatch, "RIGHT", rgn._control, "LEFT", -12, 0)
        LockThreatSwatch(swatch, updateSwatch, isClassicTankAggroDisabled, "Classic Tank Aggro")
    end

    -- Inline cog next to the tank Has Aggro toggle, then the "Has Aggro" color swatch left of it
    do
        local rgn = tankAggroRow._rightRegion
        local tankAggroColorGet = function() return DBColor("tankHasAggro") end
        local tankAggroColorSet = function(r, g, b)
            DB().tankHasAggro = { r = r, g = g, b = b }
            RefreshAllPlates()
        end

        -- Inline cog "Override Mini-Boss and Caster colors" promotes the tank has-aggro color above the mini-boss/caster priority steps; dimmed while Has Aggro is off.
        EllesmereUI.BuildInlineCog(rgn, {
            disabled = function() return threatNever() or isTankHasAggroDisabled() or isThreatHealthOff() end,
            disabledTooltip = function()
                if threatNever() then return "Show Threat Colors" end
                if isTankHasAggroDisabled() then return 'Tank: Show Special "Has Aggro" Color' end
                return "Health Bar"
            end,
            title = "Has Aggro",
            rows = {
                { type="toggle", label="Override Mini-Boss and Caster colors",
                  get=function()
                    local db = DB()
                    if db and db.tankHasAggroOverrideMobType ~= nil then return db.tankHasAggroOverrideMobType end
                    return defaults.tankHasAggroOverrideMobType
                  end,
                  set=function(v) DB().tankHasAggroOverrideMobType = v; RefreshAllPlates() end },
                { type="toggle", label="Override Boss colors",
                  get=function()
                    local db = DB()
                    if db and db.tankHasAggroOverrideBoss ~= nil then return db.tankHasAggroOverrideBoss end
                    return defaults.tankHasAggroOverrideBoss
                  end,
                  set=function(v) DB().tankHasAggroOverrideBoss = v; RefreshAllPlates() end },
            },
        })
        if not EllesmereUI._prebuilding then
            local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rgn, rgn:GetFrameLevel() + 5, tankAggroColorGet, tankAggroColorSet, nil, 20)
            PP.Point(swatch, "RIGHT", rgn._lastInline or rgn._control, "LEFT", -8, 0)
            rgn._lastInline = swatch
            LockThreatSwatch(swatch, updateSwatch, isTankHasAggroDisabled, 'Tank: Show Special "Has Aggro" Color')
        end
    end

    -- Show Threat On: which parts of the plate carry the threat colors above. Border and
    -- Name are second signals beside the Health Bar, so the bar can keep its Enemy Types
    -- color (Caster / Mini-Boss / Boss) while the border and the name show aggro.
    -- Border locks while no EUI border is drawn (None, or a stock style). Built as a
    -- placeholder dropdown (its disabled config dims the label and blocks the slot) and
    -- replaced below in whichever half of chanRow holds it.
    local chanCfg = { type="dropdown", text="Show Threat On",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          values={ __placeholder = "..." }, order={ "__placeholder" },
          getValue=function() return "__placeholder" end,
          setValue=function() end }

    -- WoW Forever Threat % helpers and toggle (nil on retail, where Show Threat On
    -- takes the Off-Tank row's right slot instead).
    local threatPctOff, ThreatPctSet, offTankRightCfg
    if EllesmereUI.IS_FOREVER then
        threatPctOff = function() return not DBVal("threatPctEnabled") end
        ThreatPctSet = function(key, v)
            DB()[key] = v
            ns.RefreshThreatPct()
        end
        offTankRightCfg = { type="toggle", text="Show Threat % on Nameplates",
              tooltip="Shows your threat percentage on each enemy nameplate while you are in combat with it.",
              getValue=function() return DBVal("threatPctEnabled") end,
              setValue=function(v)
                ThreatPctSet("threatPctEnabled", v)
                EllesmereUI:RefreshPage()
              end }
    else
        offTankRightCfg = chanCfg
    end

    -- Row 4: Tank: Show Special "Off-Tank" Color (left) ---- Show Threat On (right);
    -- on WoW Forever the right slot is Show Threat % on Nameplates.
    local offTankRow
    offTankRow, h = W:DualRow(parent, y,
        { type="toggle", text="Tank: Show Special \"Off-Tank\" Color",
          tooltip="Shows a special color for nameplates that another tank in your raid has aggro on.",
          disabled=threatNever, disabledTooltip="Show Threat Colors",
          getValue=function()
            local db = DB()
            if db and db.offTankAggroEnabled ~= nil then return db.offTankAggroEnabled end
            return defaults.offTankAggroEnabled
          end,
          setValue=function(v)
            DB().offTankAggroEnabled = v
            RefreshAllPlates()
            EllesmereUI:RefreshPage()
          end },
        offTankRightCfg);  y = y - h

    -- Inline "Off-Tank" color swatch next to the Off-Tank toggle
    if not EllesmereUI._prebuilding then
        local rgn = offTankRow._leftRegion
        local otColorGet = function() return DBColor("offTankAggro") end
        local otColorSet = function(r, g, b)
            DB().offTankAggro = { r = r, g = g, b = b }
            RefreshAllPlates()
        end
        local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rgn, rgn:GetFrameLevel() + 5, otColorGet, otColorSet, nil, 20)
        PP.Point(swatch, "RIGHT", rgn._control, "LEFT", -12, 0)
        LockThreatSwatch(swatch, updateSwatch, isOffTankDisabled, 'Tank: Show Special "Off-Tank" Color')
    end

    -- Row 5 (WoW Forever only): Threat % Position (left) ---- Show Threat On (right).
    local chanRow = offTankRow
    if EllesmereUI.IS_FOREVER then
        local threatPctRow
        threatPctRow, h = W:DualRow(parent, y,
            { type="dropdown", text="Threat % Position",
              values=THREAT_PCT_POSITIONS, order=THREAT_PCT_POSITION_ORDER,
              disabled=threatPctOff, disabledTooltip="Show Threat % on Nameplates",
              getValue=function() return DBVal("threatPctPosition") end,
              setValue=function(v) ThreatPctSet("threatPctPosition", v) end },
            chanCfg);  y = y - h
        chanRow = threatPctRow

        do
            EllesmereUI.BuildInlineCog(threatPctRow._leftRegion, {
                title = "Threat %",
                disabled = threatPctOff,
                disabledTooltip = "Show Threat % on Nameplates",
                rows = ns.NPO_ThreatPctRows(DBVal, ThreatPctSet),
            })
        end
    end

    -- Replace the Show Threat On placeholder with a multi-select checkbox dropdown,
    -- in whichever half of chanRow was built from chanCfg.
    if not EllesmereUI._prebuilding then
        local rgn = chanRow._rightRegion
        if chanRow._leftRegion._cfg == chanCfg then rgn = chanRow._leftRegion end
        if rgn._control then rgn._control:Hide() end
        -- A locked Border also drops out of the summary, which then reads what is drawn.
        local function isThreatBorderLocked()
            return not (ns.IsBorderEnabled() or ns.IsCustomBorderEnabled())
        end
        local chanItems = {
            { key = "health", label = "Health Bar" },
            { key = "border", label = "Border",
              lockedFn = isThreatBorderLocked,
              excludeFromSummaryFn = isThreatBorderLocked,
              lockedTooltip = function()
                if EllesmereUI.BlizzStyle.Get("nameplates") then
                    return EllesmereUI.DisabledTooltip(EllesmereUI.BlizzStyle.Label("nameplates"), "disabled")
                end
                return "This option requires a Border to be selected"
              end },
            { key = "name",   label = "Name" },
        }
        local cbDD, cbDDRefresh = EllesmereUI.BuildVisOptsCBDropdown(
            rgn, 170, rgn:GetFrameLevel() + 2,
            chanItems,
            function(k)
                if k == "health" then return ns.GetThreatColorHealth() end
                if k == "border" then return ns.GetThreatColorBorder() end
                if k == "name"   then return ns.GetThreatColorName() end
                return false
            end,
            function(k, v)
                if k == "health" then DB().threatColorHealth = v
                elseif k == "border" then DB().threatColorBorder = v
                elseif k == "name" then DB().threatColorName = v end
                RefreshAllPlates()
                -- Health Bar gates the No Aggro and Has Aggro cogs.
                EllesmereUI:RefreshPage()
            end)
        PP.Point(cbDD, "RIGHT", rgn, "RIGHT", -20, 0)
        rgn._control = cbDD
        cbDD._ttText = "Chooses which parts of the nameplate show the threat colors; with Health Bar off, the bar keeps its Enemy Types color."
        EllesmereUI.RegisterWidgetRefresh(cbDDRefresh)
        -- The checkbox dropdown has no disabled state of its own: grey it and block
        -- clicks while Show Threat Colors is Never; the placeholder's disabled overlay
        -- over the same slot shows the requirement.
        local function ApplyChanDisabled()
            local off = threatNever()
            cbDD:SetAlpha(off and 0.3 or 1)
            cbDD:EnableMouse(not off)
        end
        ApplyChanDisabled()
        EllesmereUI.RegisterWidgetRefresh(ApplyChanDisabled)
    end

    _, h = W:Spacer(parent, y, 20);  y = y - h

    y = ns.NP_BuildDebuffColorsOptions(parent, y)

    return math.abs(y)
end

-- Used by EUI_Nameplates_Options.lua
ns.NPO_BuildColorsPage = BuildColorsPage
