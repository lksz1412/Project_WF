if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUI_Widgets_ApplyToAll.lua
--  Apply to All / Apply to Multiple: the sync flashes, the multi-apply
--  dropdown and the sync icon.
--  DEFERRED: body runs on first EllesmereUI:EnsureLoaded() call, not at load.
-------------------------------------------------------------------------------
local EllesmereUI = _G.EllesmereUI
EllesmereUI._deferredInits[#EllesmereUI._deferredInits + 1] = function()
-- Options page pool (EllesmereUI_FramePool.lua): frames made here on a pool
-- host are reset and dressed again by the next build instead of made anew;
-- elsewhere this is CreateFrame.
local CreateFrame = EllesmereUI._Pool.CreateFrame
local PoolAttach, PoolGen, PoolIsIdle = EllesmereUI._Pool.Attach, EllesmereUI._Pool.Gen, EllesmereUI._Pool.IsIdle
local PP = EllesmereUI.PanelPP
local EXPRESSWAY = EllesmereUI.EXPRESSWAY
local ShowWidgetTooltip = EllesmereUI.ShowWidgetTooltip
local HideWidgetTooltip = EllesmereUI.HideWidgetTooltip

--------------------------------------------------------------------------------
--  PlaySyncFlash -- accent-colored 4-edge border glow on a target frame
--  Pooled: one glow frame per target, reused across flashes.
--------------------------------------------------------------------------------
local _syncGlowPool = {}

-- A glow rides on its target: made outside the pool, it is attached to a
-- target of the options page pool, so it stays on it through the target's
-- resets (hidden, its fade stopped) and the next flash of that frame, whatever
-- the frame shows then, plays it again.
local function StopGlow(glow) glow:SetScript("OnUpdate", nil) end

local function PlaySyncFlash(targetFrame)
    if not targetFrame then return end
    local glow = _syncGlowPool[targetFrame]
    if not glow then
        glow = _G.CreateFrame("Frame", nil, targetFrame)
        PoolAttach(targetFrame, glow, nil, StopGlow)
        local ar, ag, ab = EllesmereUI.GetAccentColor()
        local function MkEdge()
            local t = glow:CreateTexture(nil, "OVERLAY", nil, 7)
            t:SetColorTexture(ar, ag, ab, 1)
            glow["_c_" .. (glow._edgeN or 0)] = t
            glow._edgeN = (glow._edgeN or 0) + 1
            return t
        end
        glow._top = MkEdge();  glow._top:SetHeight(2)
        glow._top:SetPoint("TOPLEFT");  glow._top:SetPoint("TOPRIGHT")
        glow._bot = MkEdge();  glow._bot:SetHeight(2)
        glow._bot:SetPoint("BOTTOMLEFT");  glow._bot:SetPoint("BOTTOMRIGHT")
        glow._lft = MkEdge();  glow._lft:SetWidth(2)
        glow._lft:SetPoint("TOPLEFT", glow._top, "BOTTOMLEFT")
        glow._lft:SetPoint("BOTTOMLEFT", glow._bot, "TOPLEFT")
        glow._rgt = MkEdge();  glow._rgt:SetWidth(2)
        glow._rgt:SetPoint("TOPRIGHT", glow._top, "BOTTOMRIGHT")
        glow._rgt:SetPoint("BOTTOMRIGHT", glow._bot, "TOPRIGHT")
        _syncGlowPool[targetFrame] = glow
    end
    -- Re-color edges in case accent changed
    local ar, ag, ab = EllesmereUI.GetAccentColor()
    for i = 0, (glow._edgeN or 0) - 1 do
        local e = glow["_c_" .. i]
        if e then e:SetColorTexture(ar, ag, ab, 1) end
    end
    glow:SetAllPoints(targetFrame)
    glow:SetFrameLevel(targetFrame:GetFrameLevel() + 5)
    glow:SetAlpha(1)
    glow:Show()
    local elapsed = 0
    glow:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed >= 0.75 then
            self:Hide();  self:SetScript("OnUpdate", nil);  return
        end
        self:SetAlpha(1 - elapsed / 0.75)
    end)
end

EllesmereUI.PlaySyncFlash = PlaySyncFlash

--------------------------------------------------------------------------------
--  PlayWhiteFlash -- white 4-edge border flash on click, fades out over 0.35s
--  Reuses the same glow pool as PlaySyncFlash, just recolors edges white.
--------------------------------------------------------------------------------
local function PlayWhiteFlash(targetFrame)
    if not targetFrame then return end
    -- Ensure the glow frame exists (creates it if needed via PlaySyncFlash)
    if not _syncGlowPool[targetFrame] then PlaySyncFlash(targetFrame) end
    local glow = _syncGlowPool[targetFrame]
    if not glow then return end
    -- Stop any running animation (hover pulse or previous flash)
    glow:SetScript("OnUpdate", nil)
    -- Recolor edges white
    for i = 0, (glow._edgeN or 0) - 1 do
        local e = glow["_c_" .. i]
        if e then e:SetColorTexture(1, 1, 1, 1) end
    end
    glow:SetAllPoints(targetFrame)
    glow:SetFrameLevel(targetFrame:GetFrameLevel() + 5)
    glow:SetAlpha(0.75)
    glow:Show()
    local elapsed = 0
    glow:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed >= 0.5 then
            self:Hide(); self:SetScript("OnUpdate", nil); return
        end
        self:SetAlpha(0.75 - 0.50 * (elapsed / 0.5))
    end)
end

EllesmereUI.PlayWhiteFlash = PlayWhiteFlash

--------------------------------------------------------------------------------
--  BuildMultiApplyDropdown -- checkbox popup for selective "Apply to Multiple".
--  Opens a DIALOG-strata popup with checkboxes for each element. The current
--  element is pre-checked and grayed out (non-interactive); all others are
--  checked by default. An "Apply" button at the top applies the setting to all checked elements.
--  opts = {
--      elementKeys   = { "MainBar", "Bar2", ... },
--      elementLabels = { MainBar = "Bar 1", Bar2 = "Bar 2", ... },
--      getCurrentKey = function() return selectedBarKey end,
--      onApply       = function(checkedKeys) ... end,
--  }
--  anchorFrame: frame to anchor the dropdown below
--  flashTargets: optional table or function for PlayWhiteFlash on apply
--  Returns: dropdownFrame
--------------------------------------------------------------------------------
local _activeMultiApplyDropdown = nil  -- only one open at a time
-- Persistent checkbox state per element-key-set (survives dropdown close/reopen)
local _multiApplyCheckedState = {}
-- The popup, its click-away catcher and its rows (pooled by position) are built on
-- the first open and reused; ma also holds what the open popup was opened with.
local ma = { rows = {} }

local function MakeMultiApplyRow(menu, fontPath)
    local row = CreateFrame("Button", nil, menu)
    row:SetHeight(28)
    row:SetFrameLevel(menu:GetFrameLevel() + 2)

    local box = CreateFrame("Frame", nil, row)
    box:SetSize(16, 16)
    box:SetPoint("LEFT", row, "LEFT", 10, 0)
    local boxBg = box:CreateTexture(nil, "BACKGROUND")
    boxBg:SetAllPoints()
    boxBg:SetColorTexture(0.114, 0.106, 0.099, 1)
    row._boxBrd = EllesmereUI.MakeRoundedBorder(box, 0.4, 0.4, 0.4, 0.6, boxBg)

    local chk = box:CreateTexture(nil, "ARTWORK")
    PP.SetInside(chk, box, 2, 2)
    EllesmereUI.RoundBody(box, chk, 2)
    row._chk = chk

    local lbl = row:CreateFontString(nil, "OVERLAY")
    lbl:SetFont(fontPath, 13, "")
    lbl:SetPoint("LEFT", box, "RIGHT", 8, 0)
    row._lbl = lbl

    local hl = row:CreateTexture(nil, "ARTWORK")
    hl:SetAllPoints()
    row._hl = hl
    return row
end

local function BuildMultiApplyDropdown(anchorFrame, opts, flashTargets)
    -- Close any existing dropdown first
    if _activeMultiApplyDropdown then
        _activeMultiApplyDropdown:Hide()
        _activeMultiApplyDropdown = nil
    end

    local currentKey = opts.getCurrentKey()
    local keys = opts.elementKeys
    local labels = opts.elementLabels

    -- Build a stable cache key from the element keys list
    local cacheKey = table.concat(keys, "|")

    local ITEM_H = 28
    local APPLY_H = 29   -- 10% smaller than the 32px footer button height
    local PAD = 6
    local menuW = 180
    local menuH = PAD + APPLY_H + 2 + #keys * ITEM_H + PAD

    -- Controller cursor loaded: the one gate for everything controller-only below.
    local padCP = EllesmereUI.PadCP()
    -- Options panel is Expressway-locked by design (locale-aware: CJK/Cyrillic get the system glyph font). The user's global font intentionally does not restyle the settings UI.
    local fontPath = EllesmereUI.EXPRESSWAY or "Fonts\\FRIZQT__.TTF"

    local menu = ma.menu
    if not menu then
        menu = CreateFrame("Frame", nil, EllesmereUI.OverlayParent())
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetFrameLevel(200)
        menu:SetClampedToScreen(true)
        menu:EnableMouse(true)
        menu:Hide()

        local mBg = menu:CreateTexture(nil, "BACKGROUND")
        mBg:SetAllPoints()
        mBg:SetColorTexture(EllesmereUI.DD_BG_R, EllesmereUI.DD_BG_G, EllesmereUI.DD_BG_B, 0.96)
        EllesmereUI.MakeRoundedBorder(menu, 1, 1, 1, EllesmereUI.DD_BRD_A, mBg, nil, true)

        -- "Apply" button at top -- styled like the footer Reset/Reload buttons (white, muted, fade hover)
        local applyRow = CreateFrame("Button", nil, menu)
        applyRow:SetHeight(APPLY_H)
        applyRow:SetPoint("TOPLEFT", menu, "TOPLEFT", PAD, -PAD)
        applyRow:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -PAD, -PAD)
        applyRow:SetFrameLevel(menu:GetFrameLevel() + 2)

        local DB_BG = EllesmereUI.DARK_BG
        local applyBg = applyRow:CreateTexture(nil, "BACKGROUND")
        applyBg:SetAllPoints()
        applyBg:SetColorTexture(DB_BG.r, DB_BG.g, DB_BG.b, 0.92)
        local applyBrd = EllesmereUI.MakeRoundedBorder(applyRow, 1, 1, 1, 0.4, applyBg)

        local applyLbl = applyRow:CreateFontString(nil, "OVERLAY")
        applyLbl:SetFont(fontPath, 12, "")
        applyLbl:SetTextColor(1, 1, 1, 0.5)
        applyLbl:SetText(EllesmereUI.L("Apply"))
        applyLbl:SetPoint("CENTER", applyRow, "CENTER", 0, 0)

        -- Fade hover (matches footer button 0.1s fade)
        do
            local FADE_DUR = 0.1
            local progress, target = 0, 0
            local function ApplyHover(t)
                applyLbl:SetTextColor(1, 1, 1, 0.5 + 0.2 * t)
                applyBrd:SetColor(1, 1, 1, 0.4 + 0.2 * t)
            end
            local function OnUpdate(self, elapsed)
                local dir = (target == 1) and 1 or -1
                progress = progress + dir * (elapsed / FADE_DUR)
                if (dir == 1 and progress >= 1) or (dir == -1 and progress <= 0) then
                    progress = target; self:SetScript("OnUpdate", nil)
                end
                ApplyHover(progress)
            end
            applyRow:SetScript("OnEnter", function(self)
                if not applyRow:IsEnabled() then return end
                target = 1; self:SetScript("OnUpdate", OnUpdate)
            end)
            applyRow:SetScript("OnLeave", function(self)
                target = 0; self:SetScript("OnUpdate", OnUpdate)
            end)
            -- Each open starts with the button at rest.
            ma.resetApplyHover = function()
                progress, target = 0, 0
                applyRow:SetScript("OnUpdate", nil)
            end
        end

        -- Separator line below Apply button
        local sep = menu:CreateTexture(nil, "ARTWORK")
        sep:SetHeight(1)
        sep:SetPoint("TOPLEFT", applyRow, "BOTTOMLEFT", 0, -1)
        sep:SetPoint("TOPRIGHT", applyRow, "BOTTOMRIGHT", 0, -1)
        sep:SetColorTexture(1, 1, 1, 0.08)

        -- Click-outside-to-close
        local blocker = CreateFrame("Button", nil, EllesmereUI.OverlayParent())
        blocker:SetFrameStrata("FULLSCREEN")
        blocker:SetFrameLevel(199)
        blocker:SetAllPoints(UIParent)
        blocker:Hide()
        blocker:SetScript("OnClick", function()
            menu:Hide()
        end)

        menu:HookScript("OnHide", function()
            blocker:Hide()
            _activeMultiApplyDropdown = nil
            -- Controller cursor: back onto the sync link that opened it (a no-op once that is hidden).
            if ma.padCP and EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(ma.anchor) end
        end)

        -- Controller cursor: the popup and its catcher block what they cover without
        -- being stops, and Cancel clicks the catcher (closing the popup).
        if padCP then
            EllesmereUI.PadHint(menu, "nodepass")
            EllesmereUI.PadHint(blocker, "nodepass")
            menu.CloseButton = blocker
            EllesmereUI.TrackOverlay(blocker)
            EllesmereUI.TrackOverlay(menu)
        end

        ma.menu, ma.applyRow, ma.applyBg, ma.applyBrd, ma.applyLbl, ma.blocker =
            menu, applyRow, applyBg, applyBrd, applyLbl, blocker
    end
    ma.anchor, ma.padCP = anchorFrame, padCP
    local applyRow, applyBg, applyBrd, applyLbl = ma.applyRow, ma.applyBg, ma.applyBrd, ma.applyLbl
    local DB_BG = EllesmereUI.DARK_BG
    local blocker = ma.blocker

    PP.Size(menu, menuW, menuH)
    menu:ClearAllPoints()
    menu:SetPoint("TOPLEFT", anchorFrame, "BOTTOMLEFT", 0, -2)
    local ppScale = EllesmereUI.GetPopupScale() or 1
    menu:SetScale(ppScale)
    ma.resetApplyHover()

    -- Reset the checked state to all-true on every open. Intentionally NOT carried over between opens: a prior per-operation deselection must never silently persist to another source unit or another sync icon (e.g. a stale exclusion could make a Bar Background sync from Target/Focus silently skip the Player frame).
    _multiApplyCheckedState[cacheKey] = {}
    for _, key in ipairs(keys) do
        _multiApplyCheckedState[cacheKey][key] = true
    end
    local checked = _multiApplyCheckedState[cacheKey]

    -- Count checked (excluding current) for disabled state
    local function CountChecked()
        local n = 0
        for _, key in ipairs(keys) do
            if key ~= currentKey and checked[key] then n = n + 1 end
        end
        return n
    end

    local function UpdateApplyState()
        local n = CountChecked()
        if n > 0 then
            applyLbl:SetTextColor(1, 1, 1, 0.5)
            applyBrd:SetColor(1, 1, 1, 0.4)
            applyBg:SetColorTexture(DB_BG.r, DB_BG.g, DB_BG.b, 0.92)
            applyRow:Enable()
        else
            applyLbl:SetTextColor(1, 1, 1, 0.2)
            applyBrd:SetColor(1, 1, 1, 0.15)
            applyBg:SetColorTexture(DB_BG.r, DB_BG.g, DB_BG.b, 0.92)
            applyRow:Disable()
        end
    end

    -- Checkbox rows
    local yOff = -(PAD + APPLY_H + 3)
    local rows = ma.rows
    for i, key in ipairs(keys) do
        local isCurrent = (key == currentKey)
        local row = rows[i]
        if not row then
            row = MakeMultiApplyRow(menu, fontPath)
            rows[i] = row
        end
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", menu, "TOPLEFT", 1, yOff)
        row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -1, yOff)
        row:SetFrameLevel(menu:GetFrameLevel() + 2)
        row:Show()

        local boxBrd, chk, lbl, hl = row._boxBrd, row._chk, row._lbl, row._hl
        local gr = EllesmereUI.ELLESMERE_GREEN
        chk:SetColorTexture(gr.r, gr.g, gr.b, 1)
        chk:SetAlpha(1)

        lbl:SetText(EllesmereUI.L(labels[key] or key))

        hl:SetColorTexture(1, 1, 1, 0)

        local function UpdateCheck()
            if checked[key] then
                chk:Show()
                boxBrd:SetColor(gr.r, gr.g, gr.b, 0.8)
            else
                chk:Hide()
                boxBrd:SetColor(0.4, 0.4, 0.4, 0.6)
            end
        end

        if isCurrent then
            -- Current element: checked, grayed out, non-interactive
            lbl:SetTextColor(0.45, 0.45, 0.45, 0.7)
            chk:Show()
            boxBrd:SetColor(gr.r, gr.g, gr.b, 0.4)
            chk:SetAlpha(0.4)
            row:SetScript("OnEnter", nil)
            row:SetScript("OnLeave", nil)
            row:SetScript("OnClick", nil)
            row:Disable()
        else
            row:Enable()
            lbl:SetTextColor(0.75, 0.75, 0.75, 1)
            UpdateCheck()
            row:SetScript("OnEnter", function()
                lbl:SetTextColor(1, 1, 1, 1)
                hl:SetColorTexture(1, 1, 1, 0.04)
            end)
            row:SetScript("OnLeave", function()
                lbl:SetTextColor(0.75, 0.75, 0.75, 1)
                hl:SetColorTexture(1, 1, 1, 0)
            end)
            row:SetScript("OnClick", function()
                checked[key] = not checked[key]
                UpdateCheck()
                UpdateApplyState()
            end)
        end

        yOff = yOff - ITEM_H
    end
    for i = #keys + 1, #rows do rows[i]:Hide() end

    UpdateApplyState()

    -- Apply button click
    applyRow:SetScript("OnClick", function()
        local result = {}
        for _, key in ipairs(keys) do
            if checked[key] and key ~= currentKey then
                result[#result + 1] = key
            end
        end
        if #result > 0 and opts.onApply then
            opts.onApply(result)
        end
        -- White flash on targets
        if flashTargets then
            local targets = flashTargets
            if type(targets) == "function" then targets = targets() end
            for _, f in ipairs(targets) do PlayWhiteFlash(f) end
        end
        menu:Hide()
    end)

    -- Click-outside-to-close
    blocker:Show()

    _activeMultiApplyDropdown = menu
    menu:Show()
    if padCP and EllesmereUI.PadCursorShown() then EllesmereUI.PadFocus(menu) end
    return menu
end

--------------------------------------------------------------------------------
--  BuildSyncIcon -- label-shift + "Apply to All" subtext pattern.
--  When the setting is desynced across bars, the row label shifts up and an
--  accent-colored "Apply to All" button appears below it; clicking it syncs,
--  hovering it pulses the flash targets' borders. When opts.multiApply is
--  provided, an additional " | Apply to Multiple" link appears next to "Apply
--  to All" that opens a checkbox dropdown for selective application.
--  Hover gate (owner 2026-11-05): on top of that, the link shows only while its
--  slot (the region) is hovered, and stays while a dropdown list opened from
--  the slot (its control's or the Multiple menu) is open; with the controller
--  cursor loaded the gate stays open.
--  opts = {
--      region       = DualRow half-region (_leftRegion / _rightRegion),
--      tooltip      = "Apply X to all Bars",          -- shown on subtext hover
--      onClick      = function() ... end,
--      isSynced     = function() return bool end,      -- required
--      flashTargets = { f1, f2, ... } or function(),   -- optional
--      multiApply   = {                                 -- optional
--          elementKeys   = { "MainBar", "Bar2", ... },
--          elementLabels = { MainBar = "Bar 1", ... },
--          getCurrentKey = function() return key end,
--          onApply       = function(checkedKeys) ... end,
--      },
--  }
--  Returns: applyBtn (the "Apply to All" button, or nil if no isSynced)
--------------------------------------------------------------------------------
local LABEL_Y_NORMAL  =  0   -- label vertical offset when synced
local LABEL_Y_SHIFTED =  8   -- label vertical offset when desynced (shifted up)
local SUBTEXT_Y       = -10  -- "Apply to All" vertical offset below center
local ANIM_DUR        = 0.20 -- seconds for slide/fade transition
local HOVER_DUR       = 0.15 -- seconds for the hover gate's fade
-- The hover hit frame sits above the slot's own controls (the highest, an
-- inline cog's disabled block, is 15 levels up).
local HOVER_LEVEL     = 25

-- Hover gate: the dropdown list the cursor may have left a slot for (a
-- standard or checkbox dropdown's, or the Apply to Multiple menu).
local function OpenList()
    local m = EllesmereUI._openDropdownMenu
    if m and m:IsShown() then return m end
    m = _activeMultiApplyDropdown
    if m and m:IsShown() then return m end
end

-- Links held shown by a dropdown list opened from their slot after the cursor
-- left it: one hidden frame checks each frame while any is held and lets each
-- go (its release) once its list closes.
local held = {}   -- release fn -> list frame
local heldFrame
local function HeldTick(self)
    local any = false
    for release, list in pairs(held) do
        if list:IsShown() then
            any = true
        else
            held[release] = nil
            release()
        end
    end
    if not any then self:Hide() end
end
local function HoldUntilClosed(release, list)
    held[release] = list
    if not heldFrame then
        heldFrame = _G.CreateFrame("Frame")
        heldFrame:Hide()
        heldFrame:SetScript("OnUpdate", HeldTick)
    end
    heldFrame:Show()
end

-- Linger: a pick from a dropdown in a slot (EllesmereUI._SyncPickNotice, which the
-- dropdown widgets call before their setter runs) keeps that slot's link shown for
-- LINGER_SECONDS whatever the hover says (the cursor is on the list, not the slot,
-- as the pick lands). One link lingers at a time: a pick in another slot ends the
-- last one. A page the pick rebuilds dresses the slot again, and its new link takes
-- the linger over (same region, same label). At most one C_Timer.After is ever
-- pending: a pick while one is pending only moves the deadline it checks.
local LINGER_SECONDS = 3
local linger = { region = nil, label = nil, set = nil, untilT = 0, pending = false }
local function LingerTick()
    linger.pending = false
    local left = linger.untilT - GetTime()
    if linger.set and left > 0.05 then
        linger.pending = true
        C_Timer.After(left, LingerTick)
        return
    end
    local set = linger.set
    linger.region, linger.label, linger.set = nil, nil, nil
    if set then set(false) end
end
-- frame: the picked dropdown's button (its slot is found up to two parents up).
function EllesmereUI._SyncPickNotice(frame)
    local set
    for _ = 1, 3 do
        if type(frame) ~= "table" then return end
        set = frame._euiSyncLinger
        if set or not frame.GetParent then break end
        frame = frame:GetParent()
    end
    if not set then return end
    local prev, lbl = linger.set, frame._label
    linger.region, linger.label, linger.set = frame, lbl and lbl:GetText(), set
    linger.untilT = GetTime() + LINGER_SECONDS
    if prev and prev ~= set then prev(false) end
    set(true)
    if not linger.pending then
        linger.pending = true
        C_Timer.After(LINGER_SECONDS, LingerTick)
    end
end

local function BuildSyncIcon(opts)
    local region = opts.region
    local label  = region and region._label
    if not region or not label then return nil end
    if not opts.isSynced then return nil end

    local ar, ag, ab = EllesmereUI.GetAccentColor()

    -- "Apply to:" prefix label + "All" clickable link
    local applyBtn = CreateFrame("Button", nil, region)
    -- The dress these frames are in (options page pool; nil outside the pool).
    local dressGen = PoolGen(applyBtn)
    applyBtn:SetFrameLevel(region:GetFrameLevel() + 4)

    local prefixText = applyBtn:CreateFontString(nil, "OVERLAY")
    prefixText:SetFont(EXPRESSWAY, 11, "")
    prefixText:SetTextColor(1, 1, 1, 0.65)
    prefixText:SetText(EllesmereUI.L("Apply to:"))
    prefixText:SetPoint("LEFT", applyBtn, "LEFT", 0, 0)

    local allBtn = CreateFrame("Button", nil, region)
    allBtn:SetFrameLevel(region:GetFrameLevel() + 4)
    local allText = allBtn:CreateFontString(nil, "OVERLAY")
    allText:SetFont(EXPRESSWAY, 11, "")
    allText:SetTextColor(ar, ag, ab, 0.65)
    allText:SetText(EllesmereUI.L("All"))
    allText:SetPoint("CENTER", allBtn, "CENTER", 0, 0)
    allBtn:SetSize(20, 14)
    allBtn:SetPoint("LEFT", prefixText, "RIGHT", 4, 0)

    allBtn:SetScript("OnEnter", function()
        local r, g, b = EllesmereUI.GetAccentColor()
        allText:SetTextColor(r, g, b, 1)
        if opts.tooltip then ShowWidgetTooltip(allBtn, opts.tooltip, opts.tooltipOpts) end
    end)
    allBtn:SetScript("OnLeave", function()
        local r, g, b = EllesmereUI.GetAccentColor()
        allText:SetTextColor(r, g, b, 0.65)
        if opts.tooltip then HideWidgetTooltip() end
    end)

    -- " | Multiple" link (only when multiApply opts are provided)
    local multiBtn, multiText, sepText
    if opts.multiApply then
        sepText = region:CreateFontString(nil, "OVERLAY")
        sepText:SetFont(EXPRESSWAY, 11, "")
        sepText:SetTextColor(0.45, 0.45, 0.45, 0.7)
        sepText:SetText("|")
        sepText:SetPoint("LEFT", allBtn, "RIGHT", 4, 0)

        multiBtn = CreateFrame("Button", nil, region)
        multiBtn:SetFrameLevel(region:GetFrameLevel() + 4)
        multiText = multiBtn:CreateFontString(nil, "OVERLAY")
        multiText:SetFont(EXPRESSWAY, 11, "")
        multiText:SetTextColor(ar, ag, ab, 0.65)
        multiText:SetText(EllesmereUI.L("Multiple"))
        multiText:SetPoint("CENTER", multiBtn, "CENTER", 0, 0)
        multiBtn:SetSize(50, 14)
        multiBtn:SetPoint("LEFT", sepText, "RIGHT", 4, 0)

        multiBtn:SetScript("OnEnter", function()
            local r, g, b = EllesmereUI.GetAccentColor()
            multiText:SetTextColor(r, g, b, 1)
        end)
        multiBtn:SetScript("OnLeave", function()
            local r, g, b = EllesmereUI.GetAccentColor()
            multiText:SetTextColor(r, g, b, 0.65)
        end)
    end

    -- Size buttons to their text
    applyBtn:SetSize(80, 14)  -- initial estimate, corrected below
    local function ResizeBtn()
        local pw = prefixText:GetStringWidth()
        local ph = prefixText:GetStringHeight()
        if pw and pw > 0 then
            applyBtn:SetSize(pw + 4, ph + 4)
        end
        local aw = allText:GetStringWidth()
        local ah = allText:GetStringHeight()
        if aw and aw > 0 then
            allBtn:SetSize(aw + 4, ah + 4)
        end
        if multiBtn and multiText then
            local mw = multiText:GetStringWidth()
            local mh = multiText:GetStringHeight()
            if mw and mw > 0 then
                multiBtn:SetSize(mw + 4, mh + 4)
            end
        end
    end
    -- Anchor subtext below label's left edge
    local labelPoint = { label:GetPoint(1) }
    local labelXOff  = labelPoint[4] or 20
    PP.Point(applyBtn, "LEFT", region, "LEFT", labelXOff - 1, SUBTEXT_Y)

    -- ----------------------------------------------------------------
    --  State: track current animated position (0 = synced, 1 = desynced)
    -- ----------------------------------------------------------------
    local animState = opts.isSynced() and 0 or 1  -- start at correct state
    -- Hover gate (see "Hover gate" below): multiplies the state above, 0 while
    -- the slot is not hovered. The controller cursor moves no pointer, so with
    -- it loaded the gate stays open and the state above alone decides.
    local hoverGate = not EllesmereUI.PadCP()
    local hoverState = hoverGate and 0 or 1

    local function ApplyState(s)
        s = s * hoverState
        -- Force hidden when the parent widget is disabled
        local parentCfg = region._widgetCfg
        if parentCfg and parentCfg.disabled and parentCfg.disabled() then s = 0 end
        -- s: 0 = synced (label centered, subtext hidden), 1 = desynced (label up, subtext visible)
        local labelY = LABEL_Y_NORMAL + s * (LABEL_Y_SHIFTED - LABEL_Y_NORMAL)
        label:ClearAllPoints()
        PP.Point(label, "LEFT", region, "LEFT", labelXOff, labelY)
        applyBtn:SetAlpha(s)
        allBtn:SetAlpha(s)
        if s <= 0 then applyBtn:Hide(); allBtn:Hide() else applyBtn:Show(); allBtn:Show() end
        if multiBtn then
            multiBtn:SetAlpha(s)
            if s <= 0 then multiBtn:Hide() else multiBtn:Show() end
        end
        if sepText then sepText:SetAlpha(s) end
    end

    -- Apply immediately on load (no animation)
    ApplyState(animState)
    ResizeBtn()

    -- ----------------------------------------------------------------
    --  Animate state transitions (uses a dedicated frame to avoid conflicting with the pulse OnUpdate on applyBtn)
    -- ----------------------------------------------------------------
    local animFrame = CreateFrame("Frame", nil, region)
    local animTarget = animState
    local function AnimateTo(target)
        if target == animTarget and not animFrame:GetScript("OnUpdate") and
           math.abs(animState - target) < 0.01 then return end
        animTarget = target
        animFrame:SetScript("OnUpdate", function(self, dt)
            local dir = animTarget > animState and 1 or -1
            animState = animState + dir * (dt / ANIM_DUR)
            if (dir == 1 and animState >= animTarget) or (dir == -1 and animState <= animTarget) then
                animState = animTarget
                self:SetScript("OnUpdate", nil)
            end
            ApplyState(animState)
        end)
    end

    -- ----------------------------------------------------------------
    --  Button scripts
    -- ----------------------------------------------------------------
    allBtn:SetScript("OnClick", function()
        if opts.onClick then opts.onClick() end
        -- White border flash on all targets
        local targets = opts.flashTargets
        if targets then
            if type(targets) == "function" then targets = targets() end
            for _, f in ipairs(targets) do PlayWhiteFlash(f) end
        end
    end)

    -- ----------------------------------------------------------------
    --  "Apply to Multiple" button scripts
    -- ----------------------------------------------------------------
    if multiBtn then
        multiBtn:SetScript("OnClick", function()
            BuildMultiApplyDropdown(multiBtn, opts.multiApply, opts.flashTargets)
        end)
        -- The menu hangs from this link and applies this row's setting: when the link
        -- goes (a page pass dresses it again or drops it, the values synced, the panel
        -- closed or folded), the menu it opened closes with it.
        multiBtn:SetScript("OnHide", function()
            local menu = ma.menu
            if menu and ma.anchor == multiBtn and menu:IsShown() then menu:Hide() end
        end)
    end

    -- ----------------------------------------------------------------
    --  RefreshPage hook: animate when sync state changes. Deferred if a slider is being dragged or color picker
    --  is open, so the label doesn't jitter mid-interaction.
    --  The hook and its deferred checks act only while this link's frames are still in the dress they made
    --  (options page pool: a rebuild in between resets them and may dress them for another row).
    -- ----------------------------------------------------------------
    local function Redressed()
        return PoolGen(applyBtn) ~= dressGen or PoolIsIdle(applyBtn)
    end

    -- ----------------------------------------------------------------
    --  Hover gate: on top of the sync state, which still decides whether the
    --  link may show, the link shows only while its slot is hovered, and stays
    --  while a dropdown list opened from the slot is open (until it closes).
    --  A motion-only hit frame over the whole slot gives the slot's enter and
    --  leave edges; clicks and motion pass through it to the controls beneath
    --  (AttachSliderTooltip's pattern), so every control works as before.
    -- ----------------------------------------------------------------
    if hoverGate then
        local hoverTarget = 0
        local hoverFrame = CreateFrame("Frame", nil, region)
        local function HoverStep(self, dt)
            local dir = hoverTarget > hoverState and 1 or -1
            hoverState = hoverState + dir * (dt / HOVER_DUR)
            if (dir == 1 and hoverState >= hoverTarget) or (dir == -1 and hoverState <= hoverTarget) then
                hoverState = hoverTarget
                self:SetScript("OnUpdate", nil)
            end
            ApplyState(animState)
        end
        local function HoverTo(t)
            hoverTarget = t
            if hoverState ~= t then hoverFrame:SetScript("OnUpdate", HoverStep) end
        end

        local hit = CreateFrame("Frame", nil, region)
        hit:SetAllPoints(region)
        hit:SetFrameLevel(region:GetFrameLevel() + HOVER_LEVEL)
        hit:SetMouseClickEnabled(false)
        EllesmereUI.PadHint(hit, "nodeignore")
        -- hovered: the cursor is on the slot. foreign: a list already open as the
        -- cursor came in (another slot's). holding: this slot's list keeps it.
        -- lingering: a dropdown pick in the slot keeps it (Linger above).
        local hovered, foreign, holding, lingering = false, nil, false, false
        local function Release()
            holding = false
            if Redressed() or hovered or lingering then return end
            -- Closing a list under the cursor: the slot's enter is on its way.
            if hit:IsMouseOver() then return end
            HoverTo(0)
        end
        hit:SetScript("OnEnter", function()
            if Redressed() then return end
            hovered = true
            if not holding then foreign = OpenList() end
            HoverTo(1)
        end)
        hit:SetScript("OnLeave", function()
            if Redressed() then return end
            hovered = false
            local list = OpenList()
            if list and list ~= foreign then
                holding = true
                HoldUntilClosed(Release, list)
                return
            end
            if lingering then return end
            HoverTo(0)
        end)
        hit:SetPropagateMouseClicks(true)
        hit:SetPropagateMouseMotion(true)
        local function SetLinger(on)
            if Redressed() then return end
            lingering = on
            if on then
                HoverTo(1)
            elseif not (hovered or holding) and not hit:IsMouseOver() then
                HoverTo(0)
            end
        end
        region._euiSyncLinger = SetLinger
        -- The page a pick rebuilt: this slot's new link takes the linger over, shown
        -- at once as the link it replaces was.
        if linger.set and linger.region == region and linger.label == label:GetText() then
            linger.set = SetLinger
            lingering = true
            hoverState, hoverTarget = 1, 1
            ApplyState(animState)
        end
    end
    EllesmereUI.RegisterWidgetRefresh(function()
        if Redressed() then return end
        -- Re-color accent in case it changed
        local r, g, b = EllesmereUI.GetAccentColor()
        prefixText:SetTextColor(1, 1, 1, 0.65)
        allText:SetTextColor(r, g, b, 0.65)
        if multiText then multiText:SetTextColor(r, g, b, 0.65) end
        ResizeBtn()


        local synced = opts.isSynced()
        local target = synced and 0 or 1

        -- Slider dragging: allow showing (desynced -> 1) immediately, but defer hiding (synced -> 0) until the drag ends.
        if EllesmereUI._sliderDragging then
            if target == 1 then
                -- Value diverged mid-drag: show right away
                AnimateTo(1)
            else
                -- Values re-converged mid-drag: don't hide yet, defer to drag end
                if not EllesmereUI._deferredDriftChecks then
                    EllesmereUI._deferredDriftChecks = {}
                end
                EllesmereUI._deferredDriftChecks[function()
                    if Redressed() then return end
                    local r2, g2, b2 = EllesmereUI.GetAccentColor()
                    prefixText:SetTextColor(1, 1, 1, 0.65)
                    allText:SetTextColor(r2, g2, b2, 0.65)
                    if multiText then multiText:SetTextColor(r2, g2, b2, 0.65) end
                    ResizeBtn()
                    AnimateTo(opts.isSynced() and 0 or 1)
                end] = true
            end
            return
        end

        -- Color picker open: defer all changes until it closes
        if EllesmereUI._colorPickerOpen then
            if not EllesmereUI._deferredDriftChecks then
                EllesmereUI._deferredDriftChecks = {}
            end
            EllesmereUI._deferredDriftChecks[function()
                if Redressed() then return end
                local r2, g2, b2 = EllesmereUI.GetAccentColor()
                prefixText:SetTextColor(1, 1, 1, 0.65)
                allText:SetTextColor(r2, g2, b2, 0.65)
                if multiText then multiText:SetTextColor(r2, g2, b2, 0.65) end
                ResizeBtn()
                AnimateTo(opts.isSynced() and 0 or 1)
            end] = true
            return
        end

        AnimateTo(target)
    end)

    return applyBtn
end

EllesmereUI.BuildSyncIcon       = BuildSyncIcon
EllesmereUI.BuildMultiApplyDropdown = BuildMultiApplyDropdown
end  -- end deferred init
