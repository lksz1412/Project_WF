if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EUI_QoL_BattleRes_Options.lua
--  Options page for the BattleRes icon (registered under EllesmereUIQoL).
-------------------------------------------------------------------------------

if not EllesmereUI._ModuleNS["EllesmereUIQoL"] then return end  -- module disabled: no options page

-- Page reuse: frames this file builds go through the options frame pool
-- (EllesmereUI_FramePool.lua), which hands a kept page its previous build's
-- frames back reset to new; on any other parent it is the plain CreateFrame.
local CreateFrame = EllesmereUI._Pool.CreateFrame

local function DB()
    local fn = _G._EUI_BattleRes_DB
    return fn and fn() or nil
end

local function P()
    local d = DB()
    return d and d.profile and d.profile.battleRes
end

local function Cfg(key, fallback)
    local p = P()
    if not p then return fallback end
    if p[key] == nil then return fallback end
    return p[key]
end

local function Set(key, v)
    local p = P()
    if p then p[key] = v end
end

local function Refresh()
    if _G._EUI_BattleRes_Apply then _G._EUI_BattleRes_Apply() end
end

local SHAPE_VALUES = {
    none     = "None",
    cropped  = "Cropped",
    square   = "Square",
    circle   = "Circle",
    csquare  = "Curved Square",
    diamond  = "Diamond",
    hexagon  = "Hexagon",
    portrait = "Portrait",
    shield   = "Shield",
}
local SHAPE_ORDER = { "none", "cropped", "---", "square", "circle", "csquare", "diamond", "hexagon", "portrait", "shield" }

-- Border Size as a 0-4 pixel slider over the stored word (none..strong): the
-- border is solid only, so the step is the pixel count. It writes the same
-- word the dropdown wrote and only on a real change, so a Bloodlust value that
-- inherits Battle Res (nil) keeps inheriting while the slider merely shows it.
-- get/set/refresh are the page's accessors (Cfg/Set/Refresh or the BL_ trio).
local function BorderSizeSliderCfg(get, set, refresh, disabled, disabledTooltip)
    return { type="slider", text="Border Size", min=0, max=4, step=1,
      disabled=disabled, disabledTooltip=disabledTooltip,
      getValue=function()
          return EllesmereUI.BORDER_STEP_OF_LABEL[get("borderSize") or "thin"] or 1
      end,
      setValue=function(v)
          local word = EllesmereUI.BORDER_LABEL_OF_STEP[math.floor(v + 0.5)] or "thin"
          if word == (get("borderSize") or "thin") then return end
          set("borderSize", word); refresh()
      end }
end

local VIS_VALUES = {
    MPLUS_AND_RAID = "M+ and Raid",
    MPLUS          = "M+",
    RAID           = "Raid",
    NEVER          = "Never",
}
local VIS_ORDER = { "MPLUS_AND_RAID", "MPLUS", "RAID", "NEVER" }

local function MakeBorderColorSwatches()
    return {
        { tooltip = "Custom Color",
          hasAlpha = false,
          getValue = function()
              local c = Cfg("borderColor")
              if c then return c.r or 0, c.g or 0, c.b or 0 end
              return 0, 0, 0
          end,
          setValue = function(r, g, b)
              Set("borderColor", { r = r, g = g, b = b, a = 1 })
              Refresh()
          end,
          onClick = function(self)
              if Cfg("borderUseClass") then
                  Set("borderUseClass", false)
                  Refresh(); EllesmereUI:RefreshPage()
                  return
              end
              if self._eabOrigClick then self._eabOrigClick(self) end
          end,
          refreshAlpha = function()
              if Cfg("enabled") == false or Cfg("visibility") == "NEVER" then return 0.15 end
              return Cfg("borderUseClass") and 0.3 or 1
          end },
        { tooltip = "Class Colored",
          hasAlpha = false,
          getValue = function()
              local _, ct = UnitClass("player")
              local cc = ct and RAID_CLASS_COLORS and RAID_CLASS_COLORS[ct]
              if cc then return cc.r, cc.g, cc.b end
              return 1, 1, 1
          end,
          setValue = function() end,
          onClick = function()
              Set("borderUseClass", true)
              Refresh(); EllesmereUI:RefreshPage()
          end,
          refreshAlpha = function()
              if Cfg("enabled") == false or Cfg("visibility") == "NEVER" then return 0.15 end
              return Cfg("borderUseClass") and 1 or 0.3
          end },
    }
end

-- Text display mode ("2 | 4:14"): shared predicates + swatches for the
-- Display Style controls.
local function TextModeOn()
    return (Cfg("displayMode") or "icon") == "text"
end

local ICON_ROWS_TIP = "This option requires Display Style to be set to Icon"
local TEXT_ROWS_TIP = "This option requires Display Style to be set to Text"

-- Settings cog holding one toggle, placed left of the row region's inline
-- controls (same shape as the Skip Cinematics cog). offFn greys and blocks
-- it; offReq is the DisabledTooltip requirement shown while blocked.
local function AttachToggleCog(rgn, title, label, get, set, offFn, offReq)
    EllesmereUI.BuildInlineCog(rgn, {
        title = title, gap = 9,
        rows = { { type="toggle", label=label, get=get, set=set } },
        disabled = offFn, disabledTooltip = offReq,
    })
end

local function BuildBattleResPage(pageName, parent, yOffset)
    local W = EllesmereUI.Widgets
    local PP = EllesmereUI.PP
    local y = yOffset
    local _, h, row

    if EllesmereUI.ClearContentHeader then EllesmereUI:ClearContentHeader() end
    parent._showRowDivider = true

    -- -- BATTLE RES ----------------------------------------------------
    _, h = W:SectionHeader(parent, "BATTLE RES", y); y = y - h

    -- Enable + Icon Size
    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Enable BattleRes Icon",
          values=VIS_VALUES,
          order=VIS_ORDER,
          getValue=function() return Cfg("visibility") or "MPLUS_AND_RAID" end,
          setValue=function(v) Set("visibility", v); Refresh(); EllesmereUI:RefreshPage() end },
        { type="slider", text="Icon Size",
          disabled=function() return Cfg("visibility") == "NEVER" end,
          disabledTooltip="BattleRes Icon",
          min=16, max=120, step=1, isPercent=false,
          getValue=function() return Cfg("iconSize") or 40 end,
          setValue=function(v) Set("iconSize", v); Refresh() end })
    y = y - h

    -- Shape | Border Color
    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Icon Shape",
          disabled=function() return Cfg("visibility") == "NEVER" end,
          disabledTooltip="BattleRes Icon",
          values=SHAPE_VALUES,
          order=SHAPE_ORDER,
          getValue=function() return Cfg("shape") or "none" end,
          setValue=function(v) Set("shape", v); Refresh() end },
        { type="multiSwatch", text="Border Color",
          disabled=function() return Cfg("visibility") == "NEVER" end,
          disabledTooltip="BattleRes Icon",
          swatches = MakeBorderColorSwatches() })
    y = y - h

    -- Border Size | Icon Zoom
    row, h = W:DualRow(parent, y,
        BorderSizeSliderCfg(Cfg, Set, Refresh,
          function() return Cfg("visibility") == "NEVER" end,
          "BattleRes Icon"),
        { type="slider", text="Icon Zoom",
          disabled=function()
              if Cfg("visibility") == "NEVER" then return true end
              local s = Cfg("shape") or "none"
              return s ~= "none" and s ~= "cropped"
          end,
          disabledTooltip=function()
              if Cfg("visibility") == "NEVER" then return "BattleRes Icon" end
              return "This option requires Icon Shape to be set to None or Cropped"
          end,
          min=0, max=20, step=0.5, isPercent=false,
          getValue=function() return Cfg("iconZoom") or 11 end,
          setValue=function(v) Set("iconZoom", v); Refresh() end })
    y = y - h

    -- Duration Size | Count Size, each with inline cog (X/Y offsets)
    row, h = W:DualRow(parent, y,
        { type="slider", text="Duration Size",
          disabled=function() return Cfg("visibility") == "NEVER" end,
          disabledTooltip="BattleRes Icon",
          min=8, max=30, step=1, isPercent=false,
          getValue=function() return Cfg("durationSize") or 12 end,
          setValue=function(v) Set("durationSize", v); Refresh() end },
        { type="slider", text="Count Size",
          disabled=function() return Cfg("visibility") == "NEVER" end,
          disabledTooltip="BattleRes Icon",
          min=8, max=20, step=1, isPercent=false,
          getValue=function() return Cfg("countSize") or 11 end,
          setValue=function(v) Set("countSize", v); Refresh() end })
    y = y - h

    -- Inline RESIZE cogs on Duration Size (left) and Count Size (right): X/Y offsets
    do
        local function _attachOffsetCog(rgn, popupTitle, xKey, yKey)
            EllesmereUI.BuildInlineCog(rgn, {
                title = popupTitle,
                rows = {
                    { type="slider", label="X Offset", min=-50, max=50, step=1,
                      get=function() return Cfg(xKey) or 0 end,
                      set=function(v) Set(xKey, v); Refresh() end },
                    { type="slider", label="Y Offset", min=-50, max=50, step=1,
                      get=function() return Cfg(yKey) or 0 end,
                      set=function(v) Set(yKey, v); Refresh() end },
                },
                gap = 6, chain = false,
                disabled = function() return Cfg("visibility") == "NEVER" end,
            })
        end
        _attachOffsetCog(row._leftRegion,  "Duration Position", "durationOffsetX", "durationOffsetY")
        _attachOffsetCog(row._rightRegion, "Count Position",    "countOffsetX",    "countOffsetY")
    end

    _, h = W:Spacer(parent, y, 20); y = y - h

    parent:SetHeight(math.abs(y - yOffset))
end

_G._EUI_BuildBattleResPage = BuildBattleResPage

-- Live preview hidden per tracker for this session only (a preview toggle is
-- never saved): shown again after a /reload.
local previewHidden = {}
local function PreviewHidden(key)
    return previewHidden[key] == true
end
local function SetPreviewHidden(key, hidden)
    previewHidden[key] = hidden or nil
end

-- Inline eye left of a row's control: shows/hides that tracker's live preview.
local function AttachPreviewEye(rgn, key, showTip, hideTip, setOwner, owner)
    local EYE_VISIBLE   = EllesmereUI.EYE_VISIBLE_ICON
    local EYE_INVISIBLE = EllesmereUI.EYE_INVISIBLE_ICON
    local eyeBtn = CreateFrame("Button", nil, rgn)
    eyeBtn:SetSize(26, 26)
    eyeBtn:SetPoint("RIGHT", rgn._lastInline or rgn._control, "LEFT", -8, 0)
    eyeBtn:SetFrameLevel(rgn:GetFrameLevel() + 5)
    EllesmereUI.SetGlyphAlpha(eyeBtn, 0.4)
    rgn._lastInline = eyeBtn
    local eyeTex = eyeBtn:CreateTexture(nil, "OVERLAY")
    eyeTex:SetAllPoints()
    local function RefreshEye()
        eyeTex:SetTexture(PreviewHidden(key) and EYE_VISIBLE or EYE_INVISIBLE)
    end
    RefreshEye()
    eyeBtn:SetScript("OnClick", function(self)
        SetPreviewHidden(key, not PreviewHidden(key))
        RefreshEye()
        local fn = _G[setOwner]
        if fn then fn((not PreviewHidden(key)) and owner or nil) end
        if self:IsMouseOver() then self:GetScript("OnEnter")(self) end
    end)
    eyeBtn:SetScript("OnEnter", function(self)
        EllesmereUI.SetGlyphAlpha(self, 0.7)
        EllesmereUI.ShowWidgetTooltip(self, PreviewHidden(key) and showTip or hideTip)
    end)
    eyeBtn:SetScript("OnLeave", function(self)
        EllesmereUI.SetGlyphAlpha(self, 0.4)
        EllesmereUI.HideWidgetTooltip()
    end)
end

-- Section-only builder for embedding in the Keys, Logs & Brez tab.
-- Returns total height consumed.
_G._EUI_BuildBattleResSection = function(parent, yOffset, W, PP)
    local y = yOffset
    local _, h, row, hdr

    hdr, h = W:SectionHeader(parent, "BATTLE RES", y); y = y - h
    EllesmereUI.BuildSectionUnlockJump(hdr, { key = "EUI_BattleRes",
        disabled = function() return Cfg("visibility") == "NEVER" end,
        disabledTooltip = "BattleRes Icon" })

    -- Live preview: forces the icon on screen for as long as this page is (mirrors
    -- the Bloodlust Tracker section below). PollCharges falls back to stand-in
    -- charge data wherever the brez pool reports none, so it previews from anywhere.
    -- The OnSHOW hook is what makes revisits work: the options panel caches built
    -- pages and re-shows the wrapper without re-running this builder, so without it
    -- the preview would arm on the first visit only.
    if not EllesmereUI._prebuilding and _G._EUI_BattleRes_SetPreviewOwner then
        _G._EUI_BattleRes_SetPreviewOwner((not PreviewHidden("brez")) and parent or nil)
        if not parent._brPreviewHooked then
            parent._brPreviewHooked = true
            parent:HookScript("OnShow", function()
                if _G._EUI_BattleRes_SetPreviewOwner then
                    _G._EUI_BattleRes_SetPreviewOwner((not PreviewHidden("brez")) and parent or nil)
                end
            end)
            parent:HookScript("OnHide", function()
                if _G._EUI_BattleRes_UpdateVisibility then
                    _G._EUI_BattleRes_UpdateVisibility()
                end
            end)
        end
    end

    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Enable BattleRes Icon",
          values=VIS_VALUES, order=VIS_ORDER,
          getValue=function() return Cfg("visibility") or "MPLUS_AND_RAID" end,
          -- DependentSetValue: the rows below Row 1 are hidden while Never;
          -- only the Never <-> shown flip forces the full rebuild.
          setValue=EllesmereUI.DependentSetValue(
              function() return Cfg("visibility") ~= "NEVER" end,
              function(v) Set("visibility", v); Refresh(); EllesmereUI:RefreshPage() end) },
        { type="slider", text="Icon Size",
          disabled=function() return Cfg("visibility") == "NEVER" or TextModeOn() end,
          disabledTooltip=function()
              if Cfg("visibility") == "NEVER" then return "BattleRes Icon" end
              return ICON_ROWS_TIP
          end,
          min=16, max=120, step=1, isPercent=false,
          getValue=function() return Cfg("iconSize") or 40 end,
          setValue=function(v) Set("iconSize", v); Refresh() end })
    y = y - h

    -- Rows below are HIDDEN entirely while the icon is set to Never (the
    -- dropdown's DependentSetValue forces the rebuild on flips).
    if Cfg("visibility") ~= "NEVER" then
    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Icon Shape",
          disabled=TextModeOn,
          disabledTooltip=ICON_ROWS_TIP,
          values=SHAPE_VALUES, order=SHAPE_ORDER,
          getValue=function() return Cfg("shape") or "none" end,
          setValue=function(v) Set("shape", v); Refresh() end },
        { type="multiSwatch", text="Border Color",
          disabled=TextModeOn,
          disabledTooltip=ICON_ROWS_TIP,
          swatches = MakeBorderColorSwatches() })
    if not EllesmereUI._prebuilding then
        AttachPreviewEye(row._leftRegion, "brez", "Show Battle Res preview",
            "Hide Battle Res preview", "_EUI_BattleRes_SetPreviewOwner", parent)
    end
    y = y - h

    row, h = W:DualRow(parent, y,
        BorderSizeSliderCfg(Cfg, Set, Refresh, TextModeOn, ICON_ROWS_TIP),
        { type="slider", text="Icon Zoom",
          disabled=function()
              if TextModeOn() then return true end
              local s = Cfg("shape") or "none"
              return s ~= "none" and s ~= "cropped"
          end,
          disabledTooltip=function()
              if TextModeOn() then return ICON_ROWS_TIP end
              return "This option requires Icon Shape to be set to None or Cropped"
          end,
          min=0, max=20, step=0.5, isPercent=false,
          getValue=function() return Cfg("iconZoom") or 11 end,
          setValue=function(v) Set("iconZoom", v); Refresh() end })
    y = y - h

    row, h = W:DualRow(parent, y,
        { type="slider", text="Duration Size",
          disabled=TextModeOn,
          disabledTooltip=ICON_ROWS_TIP,
          min=8, max=30, step=1, isPercent=false,
          getValue=function() return Cfg("durationSize") or 12 end,
          setValue=function(v) Set("durationSize", v); Refresh() end },
        { type="slider", text="Count Size",
          disabled=TextModeOn,
          disabledTooltip=ICON_ROWS_TIP,
          min=8, max=20, step=1, isPercent=false,
          getValue=function() return Cfg("countSize") or 11 end,
          setValue=function(v) Set("countSize", v); Refresh() end })
    y = y - h

    do
        local function _attachOffsetCog(rgn, popupTitle, xKey, yKey)
            EllesmereUI.BuildInlineCog(rgn, {
                title = popupTitle,
                rows = {
                    { type="slider", label="X Offset", min=-50, max=50, step=1,
                      get=function() return Cfg(xKey) or 0 end,
                      set=function(v) Set(xKey, v); Refresh() end },
                    { type="slider", label="Y Offset", min=-50, max=50, step=1,
                      get=function() return Cfg(yKey) or 0 end,
                      set=function(v) Set(yKey, v); Refresh() end },
                },
                gap = 6, chain = false,
                disabled = TextModeOn,
            })
        end
        _attachOffsetCog(row._leftRegion,  "Duration Position", "durationOffsetX", "durationOffsetY")
        _attachOffsetCog(row._rightRegion, "Count Position",    "countOffsetX",    "countOffsetY")
    end

    -- Display Style (icon vs text) + text-mode appearance. The count / timer
    -- color swatches sit inline on the dropdown, disabled outside text mode.
    local dispRow
    dispRow, h = W:DualRow(parent, y,
        { type="dropdown", text="Display Style",
          tooltip="Show the tracker as the Rebirth icon or as a compact text line with charges and time until the next one.",
          values={ icon="Icon", text="Text" }, order={ "icon", "text" },
          getValue=function() return Cfg("displayMode") or "icon" end,
          setValue=function(v) Set("displayMode", v); Refresh(); EllesmereUI:RefreshPage() end },
        { type="slider", text="Text Size",
          disabled=function() return not TextModeOn() end,
          disabledTooltip=TEXT_ROWS_TIP,
          min=8, max=40, step=1, isPercent=false,
          getValue=function() return Cfg("textSize") or 14 end,
          setValue=function(v) Set("textSize", v); Refresh() end })
    y = y - h

    AttachToggleCog(dispRow._leftRegion, "Icon Settings", "Desaturate when No Charges",
        function() return Cfg("desaturateNoCharges") ~= false end,
        function(v) Set("desaturateNoCharges", v); Refresh() end,
        TextModeOn, ICON_ROWS_TIP)
    if not EllesmereUI._prebuilding then
        local rgn = dispRow._leftRegion
        -- Builds one inline color swatch with the blocking-overlay disabled
        -- state (interactive only while Display Style is Text). Anchored
        -- right-to-left so the visual order matches the "2 | 4:14" line.
        local function MakeInlineTextSwatch(colorKey, tipText, anchorTo)
            local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(rgn, rgn:GetFrameLevel() + 5,
                function()
                    local c = Cfg(colorKey)
                    if c then return c.r or 1, c.g or 1, c.b or 1 end
                    return 1, 1, 1
                end,
                function(r, g, b)
                    Set(colorKey, { r = r, g = g, b = b })
                    Refresh()
                end, nil, 20)
            PP.Point(swatch, "RIGHT", anchorTo, "LEFT", -8, 0)
            swatch:HookScript("OnEnter", function()
                if TextModeOn() then EllesmereUI.ShowWidgetTooltip(swatch, tipText) end
            end)
            swatch:HookScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            local block = CreateFrame("Frame", nil, swatch)
            block:SetAllPoints()
            block:SetFrameLevel(swatch:GetFrameLevel() + 10)
            block:EnableMouse(true)
            block:SetScript("OnEnter", function() EllesmereUI.ShowWidgetTooltip(swatch, TEXT_ROWS_TIP) end)
            block:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            local function UpdateState()
                updateSwatch()
                if TextModeOn() then
                    swatch:SetAlpha(1); block:Hide()
                else
                    swatch:SetAlpha(0.3); block:Show()
                end
            end
            EllesmereUI.RegisterWidgetRefresh(UpdateState)
            UpdateState()
            return swatch
        end
        local timerSwatch = MakeInlineTextSwatch("textTimerColor", "Timer Color", rgn._lastInline or rgn._control)
        local countSwatch = MakeInlineTextSwatch("textCountColor", "Count Color", timerSwatch)
        rgn._lastInline = countSwatch
    end

    -- Font | Font Outline: text-display-only controls (the icon's duration /
    -- count texts keep the fixed module style), so both disable while
    -- Display Style is Icon. Mirrors the Chat module's font controls, but
    -- applies live -- no reload needed for these font strings.
    do
        local fontValues, fontOrder = EllesmereUI.BuildFontDropdownData()
        local outlineValues = {
            ["__global"] = { text = "EUI Global Default" },
            ["none"]     = { text = "Drop Shadow" },
            ["outline"]  = { text = "Outline" },
            ["thick"]    = { text = "Thick Outline" },
        }
        local outlineOrder = { "__global", "none", "outline", "thick" }
        row, h = W:DualRow(parent, y,
            { type="dropdown", text="Font",
              disabled=function() return not TextModeOn() end,
              disabledTooltip=TEXT_ROWS_TIP,
              values=fontValues, order=fontOrder,
              getValue=function() return Cfg("font") or "__global" end,
              setValue=function(v) Set("font", v); Refresh() end },
            { type="dropdown", text="Font Outline",
              disabled=function() return not TextModeOn() end,
              disabledTooltip=TEXT_ROWS_TIP,
              values=outlineValues, order=outlineOrder,
              getValue=function() return Cfg("outlineMode") or "__global" end,
              setValue=function(v) Set("outlineMode", v); Refresh() end })
        y = y - h
    end
    end   -- close BattleRes hidden-while-Never gate

    _, h = W:Spacer(parent, y, 20); y = y - h

    return math.abs(y - yOffset)
end

-------------------------------------------------------------------------------
--  BLOODLUST TRACKER
--  A 1:1 duplicate of the BattleRes section. Appearance keys proxy-read through
--  to the current battleRes values until the user overrides them here, so the
--  tracker "starts identical" to Brez but can diverge (the raid/party model).
--  Only the Enable dropdown and position are stored independently per icon.
-------------------------------------------------------------------------------
local function BL_DB()
    local fn = _G._EUI_Bloodlust_DB or _G._EUI_BattleRes_DB
    return fn and fn() or nil
end

local function BL_P()
    local d = BL_DB()
    return d and d.profile and d.profile.bloodlust
end

local function BL_BR()
    local d = BL_DB()
    return d and d.profile and d.profile.battleRes
end

-- Keys stored independently on the bloodlust profile (everything else proxies).
local BL_OWN_KEYS = {
    visibility = true, enabled = true, pos = true,
    showSated = true, showReady = true, readySize = true, readyColor = true,
    readyOffsetX = true, readyOffsetY = true, desaturateSated = true,
}

local function BL_Cfg(key, fallback)
    local bl = BL_P()
    if BL_OWN_KEYS[key] then
        if not bl then return fallback end
        if bl[key] == nil then return fallback end
        return bl[key]
    end
    -- Proxied appearance key: own override -> battleRes -> fallback.
    if bl and bl[key] ~= nil then return bl[key] end
    local br = BL_BR()
    if br and br[key] ~= nil then return br[key] end
    return fallback
end

local function BL_Set(key, v)
    local bl = BL_P()
    if bl then bl[key] = v end
end

local function BL_Refresh()
    if _G._EUI_Bloodlust_Apply then _G._EUI_Bloodlust_Apply() end
end

local function MakeBloodlustBorderColorSwatches()
    return {
        { tooltip = "Custom Color",
          hasAlpha = false,
          getValue = function()
              local c = BL_Cfg("borderColor")
              if c then return c.r or 0, c.g or 0, c.b or 0 end
              return 0, 0, 0
          end,
          setValue = function(r, g, b)
              BL_Set("borderColor", { r = r, g = g, b = b, a = 1 })
              BL_Refresh()
          end,
          onClick = function(self)
              if BL_Cfg("borderUseClass") then
                  BL_Set("borderUseClass", false)
                  BL_Refresh(); EllesmereUI:RefreshPage()
                  return
              end
              if self._eabOrigClick then self._eabOrigClick(self) end
          end,
          refreshAlpha = function()
              if BL_Cfg("enabled") == false or BL_Cfg("visibility") == "NEVER" then return 0.15 end
              return BL_Cfg("borderUseClass") and 0.3 or 1
          end },
        { tooltip = "Class Colored",
          hasAlpha = false,
          getValue = function()
              local _, ct = UnitClass("player")
              local cc = ct and RAID_CLASS_COLORS and RAID_CLASS_COLORS[ct]
              if cc then return cc.r, cc.g, cc.b end
              return 1, 1, 1
          end,
          setValue = function() end,
          onClick = function()
              BL_Set("borderUseClass", true)
              BL_Refresh(); EllesmereUI:RefreshPage()
          end,
          refreshAlpha = function()
              if BL_Cfg("enabled") == false or BL_Cfg("visibility") == "NEVER" then return 0.15 end
              return BL_Cfg("borderUseClass") and 1 or 0.3
          end },
    }
end

-- Section-only builder for embedding in the Keys, Logs & Brez tab, directly
-- below the Battle Res section. Returns total height consumed.
_G._EUI_BuildBloodlustSection = function(parent, yOffset, W, PP)
    local y = yOffset
    local _, h, row, hdr

    hdr, h = W:SectionHeader(parent, "BLOODLUST TRACKER", y); y = y - h
    EllesmereUI.BuildSectionUnlockJump(hdr, { key = "EUI_Bloodlust",
        disabled = function() return BL_Cfg("visibility") == "NEVER" end,
        disabledTooltip = "Bloodlust Icon" })

    -- Live preview: the icon is forced on screen for as long as this page is, so the
    -- ready label, sizes and offsets can be judged without waiting for a real lust.
    -- The runtime keys off the page's own visibility, so the OnHide hook only has to
    -- poke it; a hidden search pre-build never owns the preview.
    -- The OnSHOW hook is what makes revisits work: the options panel caches built
    -- pages and re-shows the wrapper without re-running this builder, so without it
    -- the preview would arm on the first visit only.
    if not EllesmereUI._prebuilding and _G._EUI_Bloodlust_SetPreviewOwner then
        _G._EUI_Bloodlust_SetPreviewOwner((not PreviewHidden("lust")) and parent or nil)
        if not parent._blPreviewHooked then
            parent._blPreviewHooked = true
            parent:HookScript("OnShow", function()
                if _G._EUI_Bloodlust_SetPreviewOwner then
                    _G._EUI_Bloodlust_SetPreviewOwner((not PreviewHidden("lust")) and parent or nil)
                end
            end)
            parent:HookScript("OnHide", function()
                if _G._EUI_Bloodlust_UpdateVisibility then
                    _G._EUI_Bloodlust_UpdateVisibility()
                end
            end)
        end
    end

    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Enable Bloodlust Icon",
          values=VIS_VALUES, order=VIS_ORDER,
          getValue=function() return BL_Cfg("visibility") or "NEVER" end,
          -- DependentSetValue: the rows below Row 1 are hidden while Never;
          -- only the Never <-> shown flip forces the full rebuild.
          setValue=EllesmereUI.DependentSetValue(
              function() return BL_Cfg("visibility") ~= "NEVER" end,
              function(v)
                  local was = BL_Cfg("visibility") or "NEVER"
                  BL_Set("visibility", v)
                  if was == "NEVER" and v ~= "NEVER" and _G._EUI_Bloodlust_SeedPos then
                      _G._EUI_Bloodlust_SeedPos()
                  end
                  BL_Refresh(); EllesmereUI:RefreshPage()
              end) },
        { type="slider", text="Icon Size",
          disabled=function() return BL_Cfg("visibility") == "NEVER" end,
          disabledTooltip="Bloodlust Icon",
          min=16, max=120, step=1, isPercent=false,
          getValue=function() return BL_Cfg("iconSize") or 40 end,
          setValue=function(v) BL_Set("iconSize", v); BL_Refresh() end })
    y = y - h

    -- Rows below are HIDDEN entirely while the icon is set to Never (the
    -- dropdown's DependentSetValue forces the rebuild on flips).
    if BL_Cfg("visibility") ~= "NEVER" then
    row, h = W:DualRow(parent, y,
        { type="dropdown", text="Icon Shape",
          values=SHAPE_VALUES, order=SHAPE_ORDER,
          getValue=function() return BL_Cfg("shape") or "none" end,
          setValue=function(v) BL_Set("shape", v); BL_Refresh() end },
        { type="multiSwatch", text="Border Color",
          swatches = MakeBloodlustBorderColorSwatches() })
    if not EllesmereUI._prebuilding then
        AttachPreviewEye(row._leftRegion, "lust", "Show Bloodlust preview",
            "Hide Bloodlust preview", "_EUI_Bloodlust_SetPreviewOwner", parent)
    end
    y = y - h

    row, h = W:DualRow(parent, y,
        BorderSizeSliderCfg(BL_Cfg, BL_Set, BL_Refresh),
        { type="slider", text="Icon Zoom",
          disabled=function()
              local s = BL_Cfg("shape") or "none"
              return s ~= "none" and s ~= "cropped"
          end,
          disabledTooltip="This option requires Icon Shape to be set to None or Cropped",
          min=0, max=20, step=0.5, isPercent=false,
          getValue=function() return BL_Cfg("iconZoom") or 11 end,
          setValue=function(v) BL_Set("iconZoom", v); BL_Refresh() end })
    y = y - h

    row, h = W:DualRow(parent, y,
        { type="slider", text="Duration Size",
          min=8, max=30, step=1, isPercent=false,
          getValue=function() return BL_Cfg("durationSize") or 12 end,
          setValue=function(v) BL_Set("durationSize", v); BL_Refresh() end },
        { type="slider", text="Count Size",
          min=8, max=20, step=1, isPercent=false,
          getValue=function() return BL_Cfg("countSize") or 11 end,
          setValue=function(v) BL_Set("countSize", v); BL_Refresh() end })
    y = y - h

    do
        -- disabledFn/disabledText: optional, block the popup + grey the cog while
        -- the row it belongs to is disabled (Duration/Count Position pass neither
        -- and stay always-on, unchanged). anchorTo: optional, anchor the cog to
        -- something other than the row's own control while keeping rgn as parent
        -- (parenting it to the anchor instead would multiply the cog's disabled
        -- alpha by that anchor's, greying it into invisibility).
        local function _attachOffsetCog(rgn, popupTitle, xKey, yKey, disabledFn, disabledText, anchorTo)
            return EllesmereUI.BuildInlineCog(rgn, {
                title = popupTitle,
                rows = {
                    { type="slider", label="X Offset", min=-50, max=50, step=1,
                      get=function() return BL_Cfg(xKey) or 0 end,
                      set=function(v) BL_Set(xKey, v); BL_Refresh() end },
                    { type="slider", label="Y Offset", min=-50, max=50, step=1,
                      get=function() return BL_Cfg(yKey) or 0 end,
                      set=function(v) BL_Set(yKey, v); BL_Refresh() end },
                },
                gap = 6, chain = false, anchorTo = anchorTo,
                disabled = disabledFn, disabledTooltip = disabledText,
            })
        end
        _attachOffsetCog(row._leftRegion,  "Duration Position", "durationOffsetX", "durationOffsetY")
        _attachOffsetCog(row._rightRegion, "Count Position",    "countOffsetX",    "countOffsetY")

        -- Show Sated / Show Ready: independent toggles. Sated gates the real lockout
        -- countdown, Ready gates the label shown once that lockout is gone -- either,
        -- both or neither can be on.
        -- Toggle controls don't self-trigger a refresh pass (unlike sliders/
        -- dropdowns), so without the explicit RefreshPage() the Ready row below
        -- stays stale (not greyed/ungreyed) until something else repaints the page.
        row, h = W:DualRow(parent, y,
            { type="toggle", text="Show Icon when Sated",
              tooltip="Show the Sated/Exhaustion lockout countdown on the icon.",
              getValue=function() return BL_Cfg("showSated") ~= false end,
              setValue=function(v)
                  BL_Set("showSated", v); BL_Refresh(); EllesmereUI:RefreshPage()
              end },
            { type="toggle", text="Show Icon with Ready Text",
              tooltip="Once the lockout expires, show a Ready label on the icon in place of the countdown. The visibility rule above still applies.",
              getValue=function() return BL_Cfg("showReady") == true end,
              setValue=function(v)
                  BL_Set("showReady", v); BL_Refresh(); EllesmereUI:RefreshPage()
              end })
        y = y - h

        AttachToggleCog(row._leftRegion, "Sated Settings", "Desaturate when Sated",
            function() return BL_Cfg("desaturateSated") ~= false end,
            function(v) BL_Set("desaturateSated", v); BL_Refresh() end,
            function() return BL_Cfg("showSated") == false end, "Show Icon when Sated")

        -- Ready appearance: colour swatch, offset cog and size slider on one row,
        -- disabled (not hidden) while Show Ready is off so the layout never
        -- reshuffles on the toggle.
        local function readyOff() return BL_Cfg("showReady") ~= true end
        row, h = W:DualRow(parent, y,
            { type="slider", text="Ready Size",
              disabled=readyOff,
              disabledTooltip="Show Icon with Ready Text",
              min=8, max=30, step=1, isPercent=false,
              getValue=function() return BL_Cfg("readySize") or 12 end,
              setValue=function(v) BL_Set("readySize", v); BL_Refresh() end },
            { type="label", text="" })
        y = y - h
        do
            local leftRgn = row._leftRegion
            -- The offset cog sits beside the slider and the swatch left of it,
            -- both parented to the row region like the other two.
            local readyCog = _attachOffsetCog(leftRgn, "Ready Position", "readyOffsetX", "readyOffsetY",
                readyOff, "Show Icon with Ready Text")
            local swatch, updateSwatch = EllesmereUI.BuildColorSwatch(leftRgn, leftRgn:GetFrameLevel() + 5,
                function()
                    local c = BL_Cfg("readyColor")
                    if c then return c.r or 1, c.g or 1, c.b or 1 end
                    return 1, 1, 1
                end,
                function(r, g, b)
                    BL_Set("readyColor", { r = r, g = g, b = b })
                    BL_Refresh()
                end, false, 20)
            PP.Point(swatch, "RIGHT", readyCog or leftRgn._control, "LEFT", -8, 0)
            -- The leftmost item: the label clamp's bound.
            leftRgn._lastInline = swatch
            EllesmereUI.RegisterWidgetRefresh(function()
                local off = readyOff()
                swatch:SetAlpha(off and 0.3 or 1)
                updateSwatch()
            end)
            -- The slider's own "disabled" already blocks clicks on itself; the
            -- swatch is a manual inline extra, so it needs the same click-block
            -- overlay the ActionBars range-colour swatch uses.
            local readyColorBlock = CreateFrame("Frame", nil, swatch)
            readyColorBlock:SetAllPoints()
            readyColorBlock:SetFrameLevel(swatch:GetFrameLevel() + 10)
            readyColorBlock:EnableMouse(true)
            readyColorBlock:SetScript("OnEnter", function()
                EllesmereUI.ShowWidgetTooltip(swatch, EllesmereUI.DisabledTooltip("Show Icon with Ready Text"))
            end)
            readyColorBlock:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
            EllesmereUI.RegisterWidgetRefresh(function()
                readyColorBlock:SetShown(readyOff())
            end)
            readyColorBlock:SetShown(readyOff())
        end
    end
    end   -- close Bloodlust hidden-while-Never gate

    _, h = W:Spacer(parent, y, 20); y = y - h

    return math.abs(y - yOffset)
end
