if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUICdmBarGlows.lua
--  Bar Glows: Overlays glow effects on action bar / CDM bar buttons when
--  configured buff/aura spells become active (or inactive in MISSING mode).
--  v4: CDM bar assignments keyed by cooldownID for stability across reanchors.
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...

-- Glow functions from EUI_CDM_Glows.lua (available after it loads)
local StartNativeGlow = function(...) if ns.StartNativeGlow then return ns.StartNativeGlow(...) end end
local StopNativeGlow  = function(...) if ns.StopNativeGlow then return ns.StopNativeGlow(...) end end

-- Slot offsets per bar index (matches EllesmereUIActionBars BAR_SLOT_OFFSETS)
local BAR_OFFSETS = { 0, 60, 48, 24, 36, 144, 156, 168 }

-------------------------------------------------------------------------------
--  Button Lookup
-------------------------------------------------------------------------------

-- Action bar button lookup (stable slot-based)
local function GetActionBarButton(barIdx, btnIdx)
    local offset = BAR_OFFSETS[barIdx] or 0
    local slot = offset + btnIdx
    local btn = _G["EABButton" .. slot]
    if btn then return btn end
    local BLIZZ_PREFIXES = {
        "ActionButton",
        "MultiBarBottomLeftButton",
        "MultiBarBottomRightButton",
        "MultiBarRightButton",
        "MultiBarLeftButton",
        "MultiBar5Button",
        "MultiBar6Button",
        "MultiBar7Button",
    }
    if barIdx >= 1 and barIdx <= #BLIZZ_PREFIXES then
        btn = _G[BLIZZ_PREFIXES[barIdx] .. btnIdx]
    end
    return btn
end

-- CDM bar icon lookup by cooldownID (stable across reanchors).
-- Walks all CDM bars (default + extras) since the 1-spell-per-bar invariant
-- guarantees a cooldownID can only live on one bar at a time.
local function FindCDMButtonByCooldownID(cooldownID)
    if not ns.cdmBarIcons then return nil end
    for _, icons in pairs(ns.cdmBarIcons) do
        for i = 1, #icons do
            local icon = icons[i]
            if icon and icon.cooldownID == cooldownID then
                return icon
            end
        end
    end
    return nil
end

-------------------------------------------------------------------------------
--  Data Access
-------------------------------------------------------------------------------

--- Get barGlows data from SavedVariables (with lazy init)
function ns.GetBarGlows()
    local specKey = ns.GetActiveSpecKey and ns.GetActiveSpecKey()
    if not specKey then return { enabled = true, selectedBar = "cooldowns", assignments = {} } end
    -- Bar glows are spec-specific and per-profile: specProfiles[specKey].barGlows
    -- under the active profile's bucket (ns.GetActiveSpecProfiles).
    local sp = ns.GetActiveSpecProfiles and ns.GetActiveSpecProfiles()
    if not sp then return { enabled = true, selectedBar = "cooldowns", assignments = {} } end
    if not sp[specKey] then sp[specKey] = { barSpells = {} } end
    local prof = sp[specKey]
    if not prof.barGlows or not next(prof.barGlows) then
        prof.barGlows = {
            enabled = true,
            selectedBar = "cooldowns",
            assignments = {},
        }
    end
    -- Live migration: colorMode replaced classColor + "glowColor set" nil check
    if not prof.barGlows._colorModeMigrated then
        prof.barGlows._colorModeMigrated = true
        for _, buffList in pairs(prof.barGlows.assignments) do
            for _, entry in ipairs(buffList) do
                if not entry.colorMode then
                    if entry.classColor then
                        entry.colorMode = "class"
                    elseif entry.glowColor then
                        entry.colorMode = "custom"
                    else
                        entry.colorMode = "default"
                    end
                end
            end
        end
    end
    return prof.barGlows
end

--- Collect all tracked buff spells across all CDM buff bars
--- Returns tracked (displayed in CDM) and untracked (known but not displayed)
function ns.GetAllCDMBuffSpells()
    local ECME = ns.ECME
    if not ECME or not ECME.db then return {}, {} end
    local p = ECME.db.profile
    if not p or not p.cdmBars or not p.cdmBars.bars then return {}, {} end

    local trackedSet = {}
    local trackedOrder = {}

    for _, bar in ipairs(p.cdmBars.bars) do
        if ns.IsBarBuffFamily(bar) then
            local spells = ns.GetCDMSpellsForBar and ns.GetCDMSpellsForBar(bar.key)
            if spells then
                for _, sp in ipairs(spells) do
                    if sp.isKnown and sp.spellID and sp.spellID > 0 and not trackedSet[sp.spellID] then
                        local entry = {
                            spellID = sp.spellID,
                            cdID = sp.cdID,
                            name = sp.name,
                            icon = sp.icon,
                            barKey = bar.key,
                            barName = bar.name or bar.key,
                        }
                        trackedSet[sp.spellID] = entry
                        trackedOrder[#trackedOrder + 1] = entry
                    end
                end
            end
        end
    end

    local IsInViewer = ns.IsSpellInBuffBarViewer
    local tracked, untracked = {}, {}
    for _, entry in ipairs(trackedOrder) do
        local sid = entry.spellID
        if sid and IsInViewer and IsInViewer(sid) then
            tracked[#tracked + 1] = entry
        else
            untracked[#untracked + 1] = entry
        end
    end

    return tracked, untracked
end

-------------------------------------------------------------------------------
--  Overlay System
-------------------------------------------------------------------------------
local overlayFrames = {}  -- [key] = overlay frame
local lastStates = {}     -- [key] = bool (last glow state for change detection)
local _cachedBG = nil     -- cached barGlows reference (refreshed on SetupOverlays)

-------------------------------------------------------------------------------
--  Stack-threshold gate (secret-safe)
--  Applications counts read SECRET even in open-world content, so the
--  threshold compare can never happen in Lua (a hard error on a secret).
--  Same trick -- and same 5-operator support -- as the per-icon Glow at
--  Stacks feature (EllesmereUICdmHooks.lua's StackGlow_Configure/Feed):
--  one-unit StatusBar windows perform lower/upper bounds C-side via
--  SetValue; equality intersects one of each (two gates). A fixed-size
--  CLAMPTOBLACKADDITIVE mask rides each gate's fill edge and is handed to
--  StartNativeGlow so the glow texture itself is cropped by the fill(s) --
--  Lua never reads the count, just forwards it.
-------------------------------------------------------------------------------
local stackGates = {}  -- [key] = { gate,mask,fill, gate2,mask2,fill2, pad, threshold, operator, closeValue, openValue, closeValue2 }

local function StackGateSize(overlay)
    local w, h = overlay:GetWidth(), overlay:GetHeight()
    if not w or w < 5 then w = 36 end
    if not h or h < 5 then h = w end
    return w, h
end

local function NewStackGate(overlay, pad)
    local gate = CreateFrame("StatusBar", nil, overlay)
    gate:SetPoint("TOPLEFT", overlay, "TOPLEFT", -pad, pad)
    gate:SetPoint("BOTTOMRIGHT", overlay, "BOTTOMRIGHT", pad, -pad)
    gate:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
    local fill = gate:GetStatusBarTexture()
    if fill then fill:SetAlpha(0) end
    gate:EnableMouse(false)
    local mask = gate:CreateMaskTexture()
    mask:SetTexture("Interface\\Buttons\\WHITE8x8",
        "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE", "NEAREST")
    return gate, mask, fill
end

local function SizeStackGateMasks(st, width, height)
    local w, h = width + st.pad * 2, height + st.pad * 2
    st.mask:SetSize(w, h)
    if st.mask2 then st.mask2:SetSize(w, h) end
end

local function StackGlowMatches(value, operator, threshold)
    if operator == "lt" then return value < threshold end
    if operator == "lte" then return value <= threshold end
    if operator == "eq" then return value == threshold end
    if operator == "gt" then return value > threshold end
    return value >= threshold
end

local function EnsureStackGate(overlay, key)
    local st = stackGates[key]
    if not st then
        st = {}
        stackGates[key] = st
        local w, h = StackGateSize(overlay)
        local pad = math.ceil(math.max(w, h) * 0.4)
        if pad < 12 then pad = 12 end
        st.pad = pad
        st.gate, st.mask, st.fill = NewStackGate(overlay, pad)
        SizeStackGateMasks(st, w, h)
    end
    return st
end

-- (Re)configure the gate(s) for the current threshold/operator. Mirrors
-- StackGlow_Configure's edge math exactly: lower bounds park the mask left
-- and open at max; upper bounds open at min and park right; equality
-- intersects one lower + one upper gate (both masks applied to the glow).
local function ConfigureStackGate(overlay, key, threshold, operator)
    local st = EnsureStackGate(overlay, key)
    if st.threshold == threshold and st.operator == operator then return st end
    st.threshold, st.operator = threshold, operator

    local upper = operator == "lt" or operator == "lte"
    local edge = (operator == "gt" or operator == "lte") and threshold + 1 or threshold
    st.gate:SetMinMaxValues(edge - 1, edge)
    st.mask:ClearAllPoints()
    st.mask:SetPoint(upper and "LEFT" or "RIGHT", st.fill or st.gate, "RIGHT", 0, 0)
    st.closeValue = upper and edge or edge - 1
    st.openValue = upper and edge - 1 or edge

    if operator == "eq" and not st.gate2 then
        local w, h = StackGateSize(overlay)
        st.gate2, st.mask2, st.fill2 = NewStackGate(overlay, st.pad)
        SizeStackGateMasks(st, w, h)
    end
    if st.gate2 then
        local equality = operator == "eq"
        st.gate2:SetMinMaxValues(equality and threshold or 0, equality and threshold + 1 or 1)
        st.mask2:ClearAllPoints()
        st.mask2:SetPoint(equality and "LEFT" or "RIGHT", st.fill2 or st.gate2, "RIGHT", 0, 0)
        st.closeValue2 = equality and threshold + 1 or 0
    end
    return st
end

-- Whether a Cooldown Manager entry names one of the glow spells (its spell,
-- override or a linked spell).
local function EntryHasSid(info, sids)
    if sids[info.spellID] or (info.overrideSpellID and sids[info.overrideSpellID]) then return true end
    local linked = info.linkedSpellIDs
    if linked then
        for i = 1, #linked do
            if sids[linked[i]] then return true end
        end
    end
    return false
end

-- Whether a Cooldown Manager entry tracks an aura on another unit.
-- selfAura == false covers spells whose own aura lands elsewhere (Polymorph,
-- Frost Nova, ...). A talent entry that tracks a debuff it applies still reads
-- selfAura == true (Frost Mage's Shatter tracks its linked Freezing debuff on
-- the target), so a harmful linked spell counts as well.
local function EntryOnOtherUnit(info, harmful)
    if info.selfAura == false then return true end
    local linked = info.linkedSpellIDs
    if harmful and linked then
        for i = 1, #linked do
            if linked[i] and harmful(linked[i]) then return true end
        end
    end
    return false
end

-- Whether any of the glow spells (sids: set of spellIDs) is tracked on another
-- unit (a target debuff such as Freezing). Only then does the buff ticker need
-- the target UNIT_AURA listener (EllesmereUICdmHooks): every target aura change
-- rebuilds the active-aura cache, so on a raid boss the whole raid's aura
-- churn would otherwise cost players whose glows only watch their own buffs.
-- Walks the Tracked Buff / Tracked Bar category sets; called from
-- SetupOverlays only (glow rebuilds), never per tick.
local function AnyTargetAura(sids)
    if not next(sids) then return false end
    local CV = C_CooldownViewer
    local cats = Enum and Enum.CooldownViewerCategory
    if not (cats and CV and CV.GetCooldownViewerCategorySet and CV.GetCooldownViewerCooldownInfo) then
        return false
    end
    local harmful = C_Spell and C_Spell.IsSpellHarmful
    for _, cat in ipairs({ cats.TrackedBuff, cats.TrackedBar }) do
        local ok, cdIDs = pcall(CV.GetCooldownViewerCategorySet, cat, true)
        if ok and type(cdIDs) == "table" then
            for _, cdID in ipairs(cdIDs) do
                local info = CV.GetCooldownViewerCooldownInfo(cdID)
                if info and EntryHasSid(info, sids) and EntryOnOtherUnit(info, harmful) then
                    return true
                end
            end
        end
    end
    return false
end

-------------------------------------------------------------------------------
--  Glow When Usable (entry.mode == "USABLE"): the glow runs while the button's
--  own ability could be pressed, the same test as the Cooldown State Effect
--  Hidden Until Usable: off cooldown (the GCD does not count) and usable for any
--  reason but missing power, so reactive abilities (Overpower, Revenge, Execute)
--  light up on their proc. The buff ticker is dirty-gated and stops itself, so
--  these glows carry their own edges: SPELL_UPDATE_USABLE (procs),
--  SPELL_UPDATE_COOLDOWN / SPELL_UPDATE_CHARGES (cooldown start and end),
--  registered only while such an entry exists and folded into one pass on the
--  next frame. A changed button ability rebinds through the ability-key path.
-------------------------------------------------------------------------------
-- The spell on a button: a CDM icon's own spell, or what the action slot holds
-- right now (a macro counts through its spell; items and empty slots are nil).
local function RawButtonSpell(btn)
    local fc = ns._ecmeFC and ns._ecmeFC[btn]
    local sid
    if fc then
        sid = fc.spellID
    else
        local slot = btn.GetAttribute and btn:GetAttribute("action") or btn.action
        if slot and ns.SlotSpellID then
            -- The assisted-combat button shows whatever is suggested, not an ability of its own.
            local _, _, subType = GetActionInfo(slot)
            if subType ~= "assistedcombat" then sid = ns.SlotSpellID(slot) end
        end
    end
    if type(sid) ~= "number" or issecretvalue(sid) or sid <= 0 then return nil end
    return sid
end

local function BaseSpell(sid)
    return C_Spell.GetBaseSpell(sid) or sid
end

local function LiveSpell(sid)
    return C_SpellBook.FindSpellOverrideByID(sid) or sid
end

-- Glows on an action bar button are saved per ability ("spell_<base spellID>"),
-- so a stance or form swap that repages the bar never moves a glow onto the
-- new ability. Items and empty slots have no ability: positional key instead.
function ns.BarGlowAbilityKey(btn)
    local sid = btn and RawButtonSpell(btn)
    return sid and ("spell_" .. BaseSpell(sid)) or nil
end

local function ButtonSpellID(btn)
    local sid = RawButtonSpell(btn)
    return sid and LiveSpell(sid)
end
-- Options: the ability a CDM icon's Glow When Usable tests ("cdm_" glows save none).
ns.BarGlowButtonSpell = ButtonSpellID

local UpdateOverlayVisuals  -- forward: defined below
local usableEventsOn = false
local usableFlush, usableEvents  -- built on the first Glow When Usable entry

-- Blizzard only guarantees GetSpellCooldown's isOnGCD inside the cooldown event itself:
-- a frame later, at the end of a GCD, it reads as a real cooldown for ~0.25s. So whether
-- each USABLE spell is on a real cooldown is worked out in the SPELL_UPDATE_COOLDOWN /
-- CHARGES handler and kept here; the next-frame flush and the buff ticker read the kept
-- answer. A spell not yet seen is read once, outside an event, and kept until the next one.
local usableOnCD = {}  -- [live spellID] = true when on a real cooldown
local function ReadRealCooldown(sid)
    local info = C_Spell.GetSpellCooldown(sid)
    return (info and info.isActive and not info.isOnGCD) or false
end

local function UsableSpellOf(overlay)
    return overlay._abilitySid and LiveSpell(overlay._abilitySid) or ButtonSpellID(overlay:GetParent())
end

-- Re-read every tracked USABLE spell; called from the cooldown event handler.
local function RefreshUsableCooldowns()
    wipe(usableOnCD)
    for _, overlay in pairs(overlayFrames) do
        if overlay:IsShown() and overlay._assignEntry and overlay._assignEntry.mode == "USABLE" then
            local sid = UsableSpellOf(overlay)
            if sid and usableOnCD[sid] == nil then usableOnCD[sid] = ReadRealCooldown(sid) end
        end
    end
end

-- The icon Hidden Until Usable shows: off cooldown (the GCD does not count) and usable.
local function UsablePressable(sid)
    local onCD = usableOnCD[sid]
    if onCD == nil then
        onCD = ReadRealCooldown(sid); usableOnCD[sid] = onCD
    elseif onCD then
        -- isActive can be trusted outside the event (only isOnGCD cannot): a
        -- cooldown that has ended reads inactive, so the glow comes back without
        -- waiting for the next cooldown event.
        local info = C_Spell.GetSpellCooldown(sid)
        if not (info and info.isActive) then onCD = false; usableOnCD[sid] = false end
    end
    return not onCD and not ns.CdmSpellNotUsable(sid)
end

local function SyncUsableEvents(on)
    if on == usableEventsOn then return end
    usableEventsOn = on
    if on then
        if not usableEvents then
            usableFlush = ns.TakeShell()
            usableFlush:Hide()
            usableFlush:SetScript("OnUpdate", function(self)
                self:Hide()
                if UpdateOverlayVisuals then UpdateOverlayVisuals() end
            end)
            usableEvents = ns.TakeShell()
            usableEvents:SetScript("OnEvent", function(_, event)
                if event ~= "SPELL_UPDATE_USABLE" then RefreshUsableCooldowns() end
                usableFlush:Show()
            end)
        end
        usableEvents:RegisterEvent("SPELL_UPDATE_USABLE")
        usableEvents:RegisterEvent("SPELL_UPDATE_COOLDOWN")
        usableEvents:RegisterEvent("SPELL_UPDATE_CHARGES")
    elseif usableEvents then
        usableEvents:UnregisterAllEvents()
        usableFlush:Hide()
        wipe(usableOnCD)
    end
end

-- Existing position keys ("<bar>_<button>") become ability keys once per spec,
-- by the ability saved with each entry. An entry saved before actionSpellID
-- existed stays on its position key: the button's ability right now (a form or
-- stance may have repaged the bar) could be the wrong one, and the move deletes
-- the old key.
local function MigrateAbilityKeys(bg)
    if bg._abilityKeysMigrated or not IsLoggedIn() or not GetActionBarButton(1, 1) then return end
    bg._abilityKeysMigrated = true
    local moves  -- { { oldKey, newKey, entry }, ... }
    for key, list in pairs(bg.assignments) do
        local barIdx, btnIdx = key:match("^(%d+)_(%d+)$")
        barIdx, btnIdx = tonumber(barIdx), tonumber(btnIdx)
        if barIdx and btnIdx and barIdx <= #BAR_OFFSETS and type(list) == "table" then
            for _, e in ipairs(list) do
                local sid = tonumber(e.actionSpellID)
                if sid and sid > 0 then
                    moves = moves or {}
                    moves[#moves + 1] = { key, "spell_" .. BaseSpell(sid), e }
                end
            end
        end
    end
    if not moves then return end
    for _, m in ipairs(moves) do
        local old, new, e = m[1], m[2], m[3]
        local dst = bg.assignments[new]
        if not dst then dst = {}; bg.assignments[new] = dst end
        dst[#dst + 1] = e
        local src = bg.assignments[old]
        for i = #src, 1, -1 do
            if src[i] == e then table.remove(src, i); break end
        end
        if #src == 0 then bg.assignments[old] = nil end
    end
end

-- The action buttons currently showing each ability: base spellID -> { {btn, tag}, ... }.
-- Every table is reused by the next scan (it runs on each form shift or bar change):
-- the target record and its tag are built once per button, the lists wiped and refilled.
local scanMap = {}
local scanTargets = {}  -- [btn] = { btn =, tag = }
local slotBase = {}     -- [action slot] = base spellID the last scan found there
local glowedAbilities = {}  -- base spellIDs a "spell_<id>" glow is saved for (last BindOverlays)

local function ScanActionButtons()
    for _, t in pairs(scanMap) do wipe(t) end
    wipe(slotBase)
    for barIdx = 1, #BAR_OFFSETS do
        for btnIdx = 1, 12 do
            local btn = GetActionBarButton(barIdx, btnIdx)
            local sid = btn and RawButtonSpell(btn)
            if sid then
                local base = BaseSpell(sid)
                local t = scanMap[base]
                if not t then t = {}; scanMap[base] = t end
                local target = scanTargets[btn]
                if not target then
                    target = { btn = btn, tag = "b" .. barIdx .. "x" .. btnIdx }
                    scanTargets[btn] = target
                end
                t[#t + 1] = target
                local slot = btn.GetAttribute and btn:GetAttribute("action") or btn.action
                if slot then slotBase[slot] = base end
            end
        end
    end
    return scanMap
end

-- Create / re-parent one overlay per glow entry on every button it applies to,
-- hide the rest. Returns what the full setup needs to know about the glows.
local function BindOverlays(bg)
    local stackSids
    local glowSids = {}  -- every assigned glow's spellID, for AnyTargetAura
    local anyHero, anyUsable, anySpellKey
    local abilityButtons  -- ScanActionButtons(), built on the first ability key
    wipe(glowedAbilities)

    local activeKeys = {}
    for assignKey, buffList in pairs(bg.assignments) do
        if buffList and #buffList > 0 then
            local targets  -- { { btn =, tag = }, ... }
            local abilitySid

            local cdID = assignKey:match("^cdm_(%d+)$")
            local spellKey = assignKey:match("^spell_(%d+)$")
            if cdID then
                -- CDM bar assignment: "cdm_<cooldownID>"
                local btn = FindCDMButtonByCooldownID(tonumber(cdID))
                targets = btn and { { btn = btn } }
            elseif spellKey then
                -- Action bar ability: "spell_<base spellID>"
                anySpellKey = true
                abilitySid = tonumber(spellKey)
                glowedAbilities[abilitySid] = true
                abilityButtons = abilityButtons or ScanActionButtons()
                targets = abilityButtons[abilitySid]
            else
                -- Action bar position (items, empty slots): "<barIdx>_<btnIdx>"
                local barIdx, btnIdx = assignKey:match("^(%d+)_(%d+)$")
                barIdx = tonumber(barIdx)
                btnIdx = tonumber(btnIdx)
                local btn = barIdx and btnIdx and GetActionBarButton(barIdx, btnIdx)
                targets = btn and { { btn = btn } }
            end

            if targets then
                for _, target in ipairs(targets) do
                    local btn = target.btn
                    for i, entry in ipairs(buffList) do
                        local key = assignKey .. "_" .. i .. (target.tag and ("_" .. target.tag) or "")
                        local overlay = overlayFrames[key]
                        if not overlay then
                            overlay = CreateFrame("Frame", "ECME_Glow_" .. key, btn)
                            overlayFrames[key] = overlay
                        end
                        if overlay:GetParent() ~= btn then
                            -- A running glow stays on its old button otherwise.
                            StopNativeGlow(overlay)
                            lastStates[key] = nil
                            overlay:SetParent(btn)
                        end
                        overlay:SetAllPoints(btn)
                        overlay:SetFrameLevel(btn:GetFrameLevel() + 15)
                        overlay:SetAlpha(1)
                        overlay._assignEntry = entry
                        overlay._abilitySid = abilitySid
                        overlay:Show()
                        activeKeys[key] = true
                        if entry.spellID and entry.spellID > 0 then glowSids[entry.spellID] = true end
                        -- The And condition's second buff can be a target debuff too.
                        local cond = entry.andMode == "and" and type(entry.conditions) == "table" and entry.conditions[1]
                        local csid = type(cond) == "table" and tonumber(cond.spellID)
                        if csid and csid > 0 then glowSids[csid] = true end
                        if entry.heroTree and not EllesmereUI.IS_FOREVER then anyHero = true end
                        if entry.mode == "USABLE" then anyUsable = true end
                        local sid = entry.stackEnabled and entry.spellID
                        if sid and sid > 0 then
                            stackSids = stackSids or {}
                            stackSids[sid] = true
                        end
                    end
                end
            end
        end
    end

    -- Hide overlays that are no longer assigned or whose ability left the bars
    for key, overlay in pairs(overlayFrames) do
        if not activeKeys[key] then
            StopNativeGlow(overlay)
            overlay:Hide()
            lastStates[key] = nil
        end
    end
    return stackSids, glowSids, anyHero, anyUsable, anySpellKey
end

-- Ability-keyed glows follow the bars: a stance or form change, a moved or
-- replaced ability and a spell change rebind them. The CDM event frame
-- (EUI_CDM_Events.lua) already receives those events and calls
-- ns.QueueBarGlowRebind while ns._barGlowRebindOn is set; bursts fold into one
-- pass on the next frame. No events of our own, no frame until first needed.
local rebindFlush
local function SyncRebindEvents(on)
    ns._barGlowRebindOn = on or nil
    if on and not rebindFlush then
        rebindFlush = ns.TakeShell()
        rebindFlush:Hide()
        rebindFlush:SetScript("OnUpdate", function(self)
            self:Hide()
            local bg = _cachedBG
            if not bg or not bg.enabled then return end
            BindOverlays(bg)
            if UpdateOverlayVisuals then UpdateOverlayVisuals() end
        end)
    elseif not on and rebindFlush then
        rebindFlush:Hide()
    end
end

-- A slot change only matters when the slot holds, or held at the last scan, an ability
-- a glow is saved for (slot is ACTIONBAR_SLOT_CHANGED's payload; 0 or nil = any slot).
-- The slot's new ability is recorded either way so the next change compares against it.
function ns.QueueBarGlowRebind(event, slot)
    if not rebindFlush then return end
    if event == "ACTIONBAR_SLOT_CHANGED" and slot and slot ~= 0 and ns.SlotSpellID then
        local now = ns.SlotSpellID(slot)
        now = type(now) == "number" and not issecretvalue(now) and now > 0 and BaseSpell(now) or nil
        local was = slotBase[slot]
        slotBase[slot] = now
        if not ((now and glowedAbilities[now]) or (was and glowedAbilities[was])) then return end
    end
    rebindFlush:Show()
end

--- Rebuild overlay frames from assignments
local function SetupOverlays()
    local bg = ns.GetBarGlows()
    _cachedBG = bg
    if not bg or not bg.enabled then
        for key, overlay in pairs(overlayFrames) do
            StopNativeGlow(overlay)
            overlay:Hide()
        end
        ns._barGlowStackSids = nil
        ns._barGlowAnyHero = nil
        SyncUsableEvents(false)
        SyncRebindEvents(false)
        ns._bgWantTargetAuras = false
        if ns.SetBarGlowTargetAuras then ns.SetBarGlowTargetAuras(false) end
        return
    end

    MigrateAbilityKeys(bg)

    -- stackSids: whether the buff-tick's aura pool-walk should bother reading
    -- applications at all (EUI_CDM_HookViewers.lua): the set of spellIDs
    -- stack-gated entries name, nil when there are none. Only frames resolving
    -- to one of these ids pay the applications read; no gated entry = no reads.
    local stackSids, glowSids, anyHero, anyUsable, anySpellKey = BindOverlays(bg)
    ns._barGlowStackSids = stackSids
    -- A hero-talent-gated glow exists: talent changes re-run the glow pass.
    ns._barGlowAnyHero = anyHero
    -- A Glow When Usable entry exists: its own cooldown / usability edges listen.
    SyncUsableEvents(anyUsable == true)
    -- An ability-keyed glow exists: bar changes rebind it.
    SyncRebindEvents(anySpellKey == true)
    -- Listen to target auras only while some glow tracks a non-self aura (EllesmereUICdmHooks).
    local wantTarget = AnyTargetAura(glowSids)
    ns._bgWantTargetAuras = wantTarget
    if ns.SetBarGlowTargetAuras then ns.SetBarGlowTargetAuras(wantTarget) end

    -- Force re-evaluation on next tick
    wipe(lastStates)
end

--- Update glow visuals based on current aura state.
--- Called each CDM tick (~10Hz from BuffTicker).
UpdateOverlayVisuals = function()
    local bg = _cachedBG
    if not bg or not bg.enabled then return end

    for key, overlay in pairs(overlayFrames) do
        if overlay:IsShown() and overlay._assignEntry then
            local entry = overlay._assignEntry
            local spellID = entry.spellID
            local mode = entry.mode or "ACTIVE"
            local onlyInCombat = entry.onlyInCombat == true

            local auraActive = false
            if spellID and spellID > 0 and mode ~= "USABLE" then
                local cache = ns._tickBlizzActiveCache
                if cache and cache[spellID] then
                    auraActive = true
                end
            end

            local shouldGlow
            if mode == "USABLE" then
                local btnSid = UsableSpellOf(overlay)
                shouldGlow = btnSid ~= nil and UsablePressable(btnSid)
            elseif mode == "MISSING" then
                shouldGlow = not auraActive
            else
                shouldGlow = auraActive
            end
            -- Second-buff (And) and hero talent conditions (EllesmereUICdmBarGlowConditions.lua)
            if entry.andMode or entry.heroTree then
                shouldGlow = ns.BarGlowCombine(entry, shouldGlow, ns._tickBlizzActiveCache)
            end

            if shouldGlow and onlyInCombat then
                shouldGlow = (InCombatLockdown and InCombatLockdown()) or UnitAffectingCombat("player") or false
            end

            -- At Stacks (ACTIVE mode only): fed to the gate(s) every tick
            -- regardless of state-change dedupe below, so the mask tracks a
            -- live stack count while the glow keeps running. A KNOWN count
            -- that fails the comparison stops the glow outright (Lua-side,
            -- cheap); an UNKNOWN/SECRET count never blocks it -- the gate's
            -- open value / the engine-side clamp decide instead.
            local gateSt
            if shouldGlow and mode ~= "MISSING" and mode ~= "USABLE" and entry.stackEnabled and spellID and spellID > 0 then
                local threshold = tonumber(entry.stackThreshold) or 2
                local operator = entry.stackOperator or "gte"
                gateSt = ConfigureStackGate(overlay, key, threshold, operator)
                -- Same sid/baseSID/linked resolution as auraActive above, so
                -- this matches whatever spellID the entry was saved against
                -- (a raw GetPlayerAuraBySpellID(spellID) query missed on the
                -- override/linked-id drift these tracked buffs can have).
                local stacks = ns._tickBlizzAuraStacks and ns._tickBlizzAuraStacks[spellID]
                -- Secret probe FIRST: any truthy/nil/relational test on a
                -- secret value hard-errors, not just `<`/`>=`.
                local secret = issecretvalue and issecretvalue(stacks)
                local feedValue
                if secret then
                    feedValue = stacks
                elseif stacks == nil then
                    feedValue = gateSt.openValue
                elseif not StackGlowMatches(stacks, operator, threshold) then
                    shouldGlow = false
                else
                    feedValue = stacks
                end
                if shouldGlow then
                    gateSt.gate:SetValue(feedValue)
                    if gateSt.gate2 then
                        -- Explicit branch: an `and feedValue or 1` form would test
                        -- a secret feedValue's truthiness and hard-error.
                        if operator == "eq" then
                            gateSt.gate2:SetValue(feedValue)
                        else
                            gateSt.gate2:SetValue(1)
                        end
                    end
                end
            end

            -- Only update start/stop on state change (avoids restarting animations)
            if shouldGlow ~= lastStates[key] then
                lastStates[key] = shouldGlow
                if shouldGlow then
                    StopNativeGlow(overlay)
                    local style = entry.glowStyle or 1
                    -- Force Custom Shape Glow for custom-shaped icons
                    local glowParent = overlay:GetParent()
                    local gpfc = glowParent and ns._ecmeFC and ns._ecmeFC[glowParent]
                    local shapeName = gpfc and gpfc.shapeName
                    if shapeName and shapeName ~= "square" and shapeName ~= "csquare" and shapeName ~= "none" then
                        style = 2
                    end
                    local cr, cg, cb
                    if entry.colorMode == "class" then
                        local cc = EllesmereUI.GetClassColor(EllesmereUI._playerClass)
                        cr, cg, cb = cc.r, cc.g, cc.b
                    elseif entry.colorMode == "custom" and entry.glowColor then
                        cr = entry.glowColor.r or 1
                        cg = entry.glowColor.g or 0.788
                        cb = entry.glowColor.b or 0.137
                    end
                    -- Blackout on a CDM icon sits BELOW its cooldown swipe/countdown,
                    -- at the per-icon Blackout's level (+12): under the border (+13)
                    -- and the cooldown widget (+14). An action button's cooldown
                    -- shares the button's own level, so no level lies between its
                    -- icon and its swipe: there the fill takes the normal level like
                    -- every other style and covers the whole button, swipe included.
                    local styleEntry = ns.GLOW_STYLES and ns.GLOW_STYLES[style]
                    local isFill = styleEntry and styleEntry.solidFill
                    overlay:SetFrameLevel(glowParent:GetFrameLevel() + ((isFill and gpfc) and 12 or 15))
                    -- The fill opacity rides opts only for Blackout (fresh table per
                    -- start: the combat-gate record keeps opts by reference).
                    if gateSt then
                        -- Both gate masks travel as data (mask2 is nil unless the
                        -- operator needs the upper gate): the Show Glows Only in
                        -- Combat replay restarts from the recorded opts, so a mask
                        -- bound out here would be missing on every texture that
                        -- replay creates fresh.
                        StartNativeGlow(overlay, style, cr, cg, cb, { maskWith = gateSt.mask, maskWith2 = gateSt.mask2,
                            alpha = isFill and entry.glowAlpha or nil })
                    else
                        StartNativeGlow(overlay, style, cr, cg, cb, isFill and { alpha = entry.glowAlpha } or nil)
                    end
                else
                    StopNativeGlow(overlay)
                end
            end
        end
    end
end
ns.UpdateOverlayVisuals = UpdateOverlayVisuals

--- Rebuild overlays and force a visual update
function ns.RequestBarGlowUpdate()
    SetupOverlays()
    UpdateOverlayVisuals()
end
-- Alias for backward compatibility with options code
ns.RequestUpdate = ns.RequestBarGlowUpdate

-------------------------------------------------------------------------------
--  Integration: called from main file's UpdateAllCDMBars tick
-------------------------------------------------------------------------------

-- Called once during CDMFinishSetup
function ns.InitBarGlows()
    SetupOverlays()
end
