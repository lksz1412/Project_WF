if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUIBags_DB.lua
--  Bags profile database + login-time seeding. Lives in the resident module
--  (first in the TOC, the options file's old slot) so the DB exists from login
--  regardless of the LoadOnDemand options surface. NewDB stays at Bags
--  file-execution time: the suite-safe window (after the parent's SVs) and, in
--  standalone builds, the pre-SV window the Lite re-root queue handles.
-------------------------------------------------------------------------------
local BAGS_DEFAULTS = {
    profile = {
        bagScale              = 1,
        bagItemIconZoom       = 0.08,
        bagSlotSize           = 34,      -- item slot size, bags and bank
        bagSlotSpacing        = 4,       -- gap between slots
        bagColumns            = 12,
        bagAutoSize           = false,
        bagAnchorCorner       = true,    -- Anchor to Nearest Corner (the Window Scale cog), bags and bank
        bagCatTitleSize       = 11,
        bagCountFontSize      = 11,
        bagSlotCountFormat    = "used_total",
        bagSeparateReagentSlots = false,
        itemlevelFontSize     = 12,
        showItemlevelInBags   = true,
        showUpgradeIndicator  = true,
        bagShowTrackRank      = false,
        itemlevelUseCustomColor = false,
        bagHideEmptyCategories = true,
        bagSplitSetGearBySet  = false,
        bagShowSetGearName    = false,
        bagSetNameFontSize    = 9,
        bagMergeDuplicates    = true,    -- every display
        bagSidebarCollapsed   = false,
        bagHideSidebarIconsCollapsed = false, -- on: collapsed = no icon strip, the expand arrow sits by the title
        bankSidebarCollapsed  = false,
        bagShowPinnedItems    = true,
        -- Profiles saved before these defaults carry their own value of
        -- bagShowRecentItems, bagHidePinnedInCategories and bagDefaultBagType
        -- (EllesmereUI_Migration.lua: bags_hide_pinned_existing_off_v1, and on
        -- WoW Forever bags_forever_defaults_existing_v1).
        bagShowRecentItems    = EllesmereUI.IS_FOREVER ~= true,   -- off on WoW Forever
        bagPinnedInOneBag     = true,
        bagHidePinnedInCategories = true,
        bagDimPinnedInOneBag  = false,   -- Dim Items in OneBag/MultiBag (the Pinned Items cog)
        bagRecentInOneBag     = false,
        bagShowRecentClear    = false,
        bagRecentNewOnly      = false,   -- Recent Items: only items not carried before (gear, mail, trade always)
        -- Bag Top Bar Icons: the header's Show Bags, Junk Marker, Quick Actions, Sort and Keyring icons
        bagShowBagsIcon       = true,
        bagShowJunkIcon       = true,    -- the Junk Marker: header coin, Junk category, Sell Junk at merchants
        bagShowQuickIcon      = false,   -- Quick Actions: dim all but items a spell works on; click or Alt-click casts it
        bagShowSortIcon       = true,
        bagShowKeyringIcon    = false,   -- WoW Forever only: opens the keyring above the icon
        bagSortToBottom       = false,
        -- Show Coins: the coins the gold summary shows, "gold" | "silver" (gold and silver) |
        -- "copper" (all three); Gold and Silver on WoW Forever
        bagGoldCoins          = (EllesmereUI.IS_FOREVER == true) and "silver" or "gold",
        -- "all" | "onebag" | "multibag"; MultiBag on WoW Forever
        bagDefaultBagType     = (EllesmereUI.IS_FOREVER == true) and "multibag" or "all",
        bagDefaultOneBag      = false,   -- legacy; migrated to bagDefaultBagType
        bagNestByExpansion    = false,
        bankNestByExpansion   = false,
        bankGroupByCategory   = false,
        bankCategorySidebar   = false,
        bankHideTabsInSidebar = false,
        bankHideEmptyWhenNested = false,
        bankListView          = false,  -- reload to apply
        bankCompactView       = false,  -- reload to apply; bankListView wins when both are set
        bagArmoryGroupBySlot  = false,
        bagCompactArmorySlotGroups = false,
        bagHideAddCategory    = false,
        bagBgOpacity          = 100,     -- background opacity for bags and bank (bagBgColor / bagSlotBgColor: nil = default)
        bagWindowLocked       = false,   -- footer lock icon: no resizing or moving
        bankWindowLocked      = false,
        bagOpenWithCharacter  = false,
        -- bagFrameStrata has no default: unset reads the retired
        -- bagAllowWindowsOverBags (ns.BagFrameStrata)
        bagStackSplitter      = false,
        detachReagentBag      = false,
        enhancedBags          = true,
        bagDesaturateJunkItems = false,  -- Junk Item Visuals: grey items and Junk Marker junk, every display
        bagShowJunkCoin       = false,   -- Junk Item Visuals: the coin badge on junk (Grid and Compact)
        bagQualityBorder      = true,    -- Quality Item Border, every display
        bagDisplayBindType    = false,
        bagBindTypeFontSize   = 11,
        bagDisplayMode        = "grid",  -- "grid" | "list" | "compact" (reload to apply)
        bagListRoundIcons     = false,
        bagListSplitArmor     = false,
        bagListSplitWeapons   = false,
        bagListSplitProfessions = false,
        bagListGapL           = 15,
        bagListGapR           = 23,
        bagListFontSize       = 11,
        bagListRowHeight      = 24,
        bagListHideStripes    = false,
        bagListSectionValue   = false,
    },
}
local db = EllesmereUI.Lite.NewDB("EllesmereUIBagsDB", BAGS_DEFAULTS)
EllesmereUI._bagsDB = db

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")

    if not EllesmereUIDB then EllesmereUIDB = {} end
    local p = db.profile

    -- The bank grouping dropdowns were replaced by two toggles. Convert the
    -- short-lived string keys once, then drop them.
    if p.bankGroupBy ~= nil then
        if p.bankGroupBy == "category" then
            p.bankGroupByCategory = true
        elseif p.bankGroupBy == "expansion" then
            p.bankNestByExpansion = true
        end
        p.bankGroupBy = nil
        p.bankSubGroupBy = nil
    end

    -- Default disabled categories: Housing and Quest Items off by default
    if EllesmereUIDB.bagDisabledCategoriesSeeded == nil then
        EllesmereUIDB.bagDisabledCategoriesSeeded = true
        if not p.bagDisabledCategories then p.bagDisabledCategories = {} end
        p.bagDisabledCategories["Housing"] = true
        p.bagDisabledCategories["Quest Items"] = true
    end

    -- Default category groups and order
    if not EllesmereUIDB.bagDefaultGroupsSeeded then
        EllesmereUIDB.bagDefaultGroupsSeeded = true
        -- Only seed if user has no existing customization
        if not p.bagCategoryState and not p.bagCategoryOrder then
            p.bagCategoryState = {
                ["Weapons / Trinkets"] = { groupName = "The Armory", groupNameCustom = true },
                ["Armor"]              = { groupName = "The Armory", groupNameCustom = true },
                ["Item Set Gear"]      = { groupName = "The Armory", groupNameCustom = true },
                ["Consumables"]        = { groupName = "Adventure Prep", groupNameCustom = true },
                ["Gear Enhancements"]  = { groupName = "Adventure Prep", groupNameCustom = true },
            }
            p.bagCategoryOrder = {
                "Pinned Items",
                "Recent Items",
                "Weapons / Trinkets",
                "Armor",
                "Item Set Gear",
                "Consumables",
                "Gear Enhancements",
                "Trade Goods",
                "Professions",
                "Reagent Bag",
                "Miscellaneous",
                "Quest Items",
                "Housing",
            }
            -- Re-init categories with the new state
            if _G.EUI_CategoryManager then
                _G.EUI_CategoryManager:InitCategories()
            end
        end
    end
    -- Migrate old numeric-keyed disabled categories to name-keyed
    if p.bagDisabledCategories and _G.EUI_CategoryManager then
        local dc = p.bagDisabledCategories
        local cats = _G.EUI_CategoryManager:GetCategories()
        local migrated = {}
        local changed = false
        for k, v in pairs(dc) do
            if type(k) == "number" then
                if cats[k] then migrated[cats[k]._defaultName] = v end
                changed = true
            else
                migrated[k] = v
            end
        end
        if changed then p.bagDisabledCategories = migrated end
    end
end)
