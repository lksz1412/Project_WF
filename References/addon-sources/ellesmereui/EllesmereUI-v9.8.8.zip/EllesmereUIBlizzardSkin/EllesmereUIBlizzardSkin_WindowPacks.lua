if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUIBlizzardSkin_WindowPacks.lua
--  Per-window skin packs on the shared engine (..._WindowEngine.lua):
--  style-aware shell, flat panels, white-hover buttons, accent-underlined tabs,
--  squared icons, flat scroll bars. Each pack registers via
--  WSkin.RegisterWindow, which gates it on the window's style ("off" = never
--  runs, zero cost), applies it when its load-on-demand Blizzard addon arrives,
--  and pcall-isolates it. Repaint hooks are debounced and early-out while
--  hidden, so navigation spam costs one pass per frame at most.
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...
local WSkin = ns.WSkin
if not WSkin then return end

local Theme = WSkin.Theme
local GetFFD = WSkin.GetFFD
local FFD = WSkin.FFD
local SolidTex = WSkin.SolidTex

-- LOCAL LIMIT: Lua 5.1 allows 200 ACTIVE locals per function, and this file's
-- main chunk is one function. Going over is a compile error that takes every
-- pack in the file down with it. So each pack lives in its own do...end block:
-- its locals are released when the block closes, and the packs no longer add
-- up. Only the core aliases above and the few helpers shared ACROSS packs sit
-- outside a block (right after their section header, before its `do`). A new
-- helper goes inside its pack's block; hoist it out only once a later pack
-- actually calls it.

-------------------------------------------------------------------------------
--  Collections (Mounts / Pets / Toys / Heirlooms / Appearances / Campsites)
-------------------------------------------------------------------------------
-- Collection-tab filter dropdown: pins "Filter" left of the arrow (as on
-- achievement/housing/professions filters). Appearances' FilterButton
-- re-anchors or re-creates its label on tab-show, so SetPoint is hooked
-- (synchronous re-assert, no blink) and the fontstring re-derived each OnShow.
local function LeftAlignFilterLabel(dd)
    if not dd then return end
    local fd = GetFFD(dd)
    if fd.labHooked then return end
    fd.labHooked = true
    local guard = false
    local hooked = setmetatable({}, { __mode = "k" })
    local function apply()
        if guard then return end
        guard = true
        local lab = dd.Text or (dd.GetFontString and dd:GetFontString())
        if lab and lab.ClearAllPoints then
            lab:ClearAllPoints()
            lab:SetPoint("LEFT", dd, "LEFT", 8, 0)
            lab:SetPoint("RIGHT", dd, "RIGHT", -22, 0)
            if lab.SetJustifyH then lab:SetJustifyH("LEFT") end
            if not hooked[lab] then
                hooked[lab] = true
                hooksecurefunc(lab, "SetPoint", apply)
            end
        end
        guard = false
    end
    apply()
    if dd.HookScript then
        dd:HookScript("OnShow", function()
            apply()
            if C_Timer then C_Timer.After(0, apply) end
        end)
    end
end

-- Active-filter reset "X": WSkin.FilterResetX (the window engine).
local SkinFilterResetX = WSkin.FilterResetX

do
local PREVIEW_JOURNALS = { WarbandSceneJournal = true }  -- texture previews are content

-- Tabs whose filter dropdown height should track the search box beside it.
local MATCH_FILTER_HEIGHT = {
    MountJournal = true, HeirloomsJournal = true, WardrobeCollectionFrame = true,
}

-- Collected-count bar (Appearances/Heirlooms/Toys): 2px taller, non-fill
-- regions faded, flat accent fill (Blizzard's fill kept as driver, re-textured),
-- dark trough, white text, VISIBLE themed border (a black BorderRegion would
-- vanish on the dark backplate).
local function SkinCollectionsProgressBar(pb)
    if not pb then return end
    local pd = GetFFD(pb)
    if not pd.heightBumped then
        pd.heightBumped = true
        pb:SetHeight(pb:GetHeight() + 2)
    end
    if pb.border and pb.border.SetAlpha then pb.border:SetAlpha(0) end
    local fill = pb.GetStatusBarTexture and pb:GetStatusBarTexture()
    local regions = { pb:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= fill and r ~= pd.bg and r.IsObjectType then
            if r:IsObjectType("Texture") and r:GetDrawLayer() ~= "HIGHLIGHT" then
                r:SetAlpha(0)
            elseif r:IsObjectType("FontString") then
                WSkin.White(r)
            end
        end
    end
    if pb.SetStatusBarTexture then
        pb:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
        WSkin.ApplyBarFill(pb)
    end
    if not pd.bg then
        local trough = pb:CreateTexture(nil, "BACKGROUND", nil, -1)
        trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
        trough:SetAllPoints(pb)
        pd.bg = trough
    end
    WSkin.AddBorder(pb)
end

local _mountRowHook = false
local function Skin_Collections()
    local f = _G.CollectionsJournal
    if not f then return end
    WSkin.Shell("collections", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    local cTabs = {}
    for _, key in ipairs({ "MountsTab", "PetsTab", "ToysTab", "HeirloomsTab",
                           "WardrobeTab", "WarbandScenesTab" }) do
        local t = f[key]
        if t then WSkin.Tab(t); cTabs[#cTabs + 1] = t end
    end
    -- Blizzard re-anchors bottom tabs to native spacing on every show, flashing
    -- the wide gap before our debounced re-skin. Re-normalize synchronously off
    -- each tab's SetPoint (reentry-guarded) so the seam is restored same-frame;
    -- scoped to this window, the shared helper stays untouched.
    local cd = GetFFD(f)
    if not cd.tabNormHook then
        cd.tabNormHook = true
        local guard = false
        local function ReNorm()
            if guard then return end
            guard = true
            WSkin.NormalizeTabRow(cTabs)
            guard = false
        end
        cd.tabReNorm = ReNorm
        for _, t in ipairs(cTabs) do
            hooksecurefunc(t, "SetPoint", ReNorm)
        end
    end
    if cd.tabReNorm then cd.tabReNorm() end
    -- Wardrobe's inner Items/Sets tabs are real tabs; treat them before the
    -- journal button sweep below flattens them into plain blocks.
    local wardrobe = _G.WardrobeCollectionFrame
    if wardrobe then
        local wTabs = {}
        if wardrobe.ItemsTab then WSkin.Tab(wardrobe.ItemsTab, { darkActive = true }); wTabs[#wTabs + 1] = wardrobe.ItemsTab end
        if wardrobe.SetsTab then WSkin.Tab(wardrobe.SetsTab, { darkActive = true }); wTabs[#wTabs + 1] = wardrobe.SetsTab end
        WSkin.NormalizeTabRow(wTabs)
    end
    -- Mount-equipment slot (BottomLeftInset.SlotButton) is its own art (slot
    -- border + icon), not journal chrome -- exempt before the art sweeps run.
    local _mj = _G.MountJournal
    if _mj and _mj.BottomLeftInset and _mj.BottomLeftInset.SlotButton then
        WSkin.ExemptArt(_mj.BottomLeftInset.SlotButton)
    end
    for _, name in ipairs({ "MountJournal", "PetJournal", "ToyBox", "HeirloomsJournal",
                            "WardrobeCollectionFrame", "WarbandSceneJournal" }) do
        local j = _G[name]
        if j then
            for _, k in ipairs({ "RightInset", "LeftInset", "Inset" }) do
                if j[k] then WSkin.Inset(j[k]) end
            end
            -- Tiled bg + corners live on the icons frame; fade chrome, never the grid content.
            local icons = j.iconsFrame or j.IconsFrame
            if icons then
                WSkin.FadeRegions(icons)
                WSkin.FadeKeyedArt(icons)
                WSkin.Register(icons, true)
            end
            WSkin.PagingIn(j)
            WSkin.ScrollBarsIn(j)
            if not PREVIEW_JOURNALS[name] then
                WSkin.ButtonsIn(j)
                WSkin.FadeKeyedArt(j)
                WSkin.FadeArtIn(j)
            end
            -- Collected-count bar last, so the keyed-art sweep above cannot re-fade it.
            if j.progressBar then SkinCollectionsProgressBar(j.progressBar) end
            local filter = j.FilterDropdown or j.FilterButton
                or _G[name .. "FilterDropdown"] or _G[name .. "FilterButton"]
            LeftAlignFilterLabel(filter)
            if filter then
                SkinFilterResetX(filter.ResetButton or filter.ClearFiltersButton, filter)
            end
            if MATCH_FILTER_HEIGHT[name] and filter and filter.SetHeight then
                local sb = j.SearchBox or j.searchBox or _G[name .. "SearchBox"]
                local h = sb and sb.GetHeight and sb:GetHeight()
                if h and h > 0 then filter:SetHeight(h) end
            end
        end
    end

    -- Mount list rows recycle; restyle in the row initializer.
    if MountJournal_InitMountButton and not _mountRowHook then
        _mountRowHook = true
        hooksecurefunc("MountJournal_InitMountButton", function(button)
            if not button or button:IsForbidden() then return end
            if button.background then button.background:SetAlpha(0) end
            local d = GetFFD(button)
            if not d.bg then
                local bg = button:CreateTexture(nil, "BACKGROUND")
                bg:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                bg:SetPoint("TOPLEFT", 1, -1)
                bg:SetPoint("BOTTOMRIGHT", -1, 1)
                d.bg = bg
                WSkin.AddBorder(button)
            end
            if button.name then WSkin.White(button.name) end
        end)
    end

    -- Warband campsites is a preview journal: Show Owned sits outside the
    -- button sweep, treat checkbox + label directly.
    local wj = _G.WarbandSceneJournal
    local so = wj and wj.IconsFrame and wj.IconsFrame.Icons
        and wj.IconsFrame.Icons.Controls and wj.IconsFrame.Icons.Controls.ShowOwned
    if so then
        if so.Checkbox then WSkin.Checkbox(so.Checkbox) end
        if so.Text then WSkin.White(so.Text) end
    end

    local mj = _G.MountJournal
    if mj and mj.MountDisplay then
        local md = mj.MountDisplay
        if md.ShadowOverlay then md.ShadowOverlay:SetAlpha(0) end
        if md.ModelScene and md.ModelScene.ShadowOverlay then md.ModelScene.ShadowOverlay:SetAlpha(0) end
        for _, k in ipairs({ "Border", "BorderFrame", "NineSlice" }) do
            if md[k] then WSkin.FadeRegions(md[k]); WSkin.Register(md[k], true) end
        end
        -- Scenic backdrop -> flat 3% white fill; SetAlpha(0) survives Blizzard's Yes/No toggle.
        for _, k in ipairs({ "YesMountsTex", "NoMountsTex" }) do
            if md[k] and md[k].SetAlpha then md[k]:SetAlpha(0) end
        end
        local mdd = GetFFD(md)
        if not mdd.modelFill then
            local fill = md:CreateTexture(nil, "BACKGROUND")
            fill:SetColorTexture(1, 1, 1, 0.03)
            fill:SetAllPoints(md.YesMountsTex or md.ModelScene or md)
            mdd.modelFill = fill
        end
    end

    WSkin.ButtonsIn(f)
    WSkin.FadeKeyedArt(f)
    -- Appearances area keeps a faint 50% backing; the keyed-art sweep above
    -- zeroes Bg + BackgroundTile, so re-assert every pass (NineSlice/shadows stay stripped).
    local icf = wardrobe and wardrobe.ItemsCollectionFrame
    if icf then
        if icf.Bg then icf.Bg:SetAlpha(0.5) end
        if icf.BackgroundTile then icf.BackgroundTile:SetAlpha(0.5) end
    end
    -- Battle pet loadout: card + every border piece at a matched faint 25%
    -- (survives Blizzard re-texturing on pet swaps).
    for i = 1, 3 do
        local bg = _G["PetJournalLoadoutPet" .. i .. "BG"]
        if bg and bg.SetAlpha then bg:SetAlpha(0.25) end
    end
    local ploadBorder = _G.PetJournalLoadoutBorder
    if ploadBorder and ploadBorder.GetRegions then
        local regions = { ploadBorder:GetRegions() }
        for ri = 1, #regions do
            local r = regions[ri]
            if r and r.SetAlpha and r.IsObjectType and r:IsObjectType("Texture") then
                r:SetAlpha(0.25)
            end
        end
    end
    -- Bottom-bar action buttons (Mount/Summon/Find Battle) default gold;
    -- force white (color only), re-applied on OnEnable since re-enabling resets the gold font object.
    for _, bn in ipairs({ "MountJournalMountButton", "PetJournalSummonButton",
                          "PetJournalFindBattle" }) do
        local btn = _G[bn]
        local lab = btn and (btn.Text or (btn.GetFontString and btn:GetFontString()))
        if lab then
            WSkin.White(lab)
            local bd = GetFFD(btn)
            if not bd.whiteHook then
                bd.whiteHook = true
                btn:HookScript("OnEnable", function() WSkin.White(lab) end)
            end
        end
    end
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then Skin_Collections(); WSkin.Restrip(); WSkin.UpdateAllTabs() end
    end))
end

WSkin.RegisterWindow({
    key = "collections",
    addons = { Blizzard_Collections = true },
    apply = Skin_Collections,
})
end

-------------------------------------------------------------------------------
--  Talents & Spellbook (PlayerSpellsFrame)
-------------------------------------------------------------------------------
do
-- Blizzard re-raises the spellbook parchment backplate + gilded item frame on
-- every populate/mouseover, so re-fade in post-hooks. Visual-only (SetAlpha),
-- never the item's own alpha knobs or click path.
local function FadeSpellItem(item)
    if not item or item:IsForbidden() then return end
    if item.Backplate and item.Backplate.SetAlpha then item.Backplate:SetAlpha(0) end
    local b = item.Button
    if b then
        -- The per-icon ring stays, at half strength and half color.
        if b.Border and b.Border.SetAlpha then
            b.Border:SetAlpha(0.5)
            if b.Border.SetDesaturation then b.Border:SetDesaturation(0.5) end
        end
        if b.BorderSheen and b.BorderSheen.SetAlpha then b.BorderSheen:SetAlpha(0) end
        if b.IconHighlight and b.IconHighlight.SetAlpha then b.IconHighlight:SetAlpha(0) end
    end
    if item.Name then WSkin.White(item.Name) end
    if item.SubName then WSkin.White(item.SubName) end
    -- The "Level N" / trainable line of an unlearned spell: the same parchment ink.
    if item.RequiredLevel then WSkin.White(item.RequiredLevel) end
end

local function FadeSpellItemsIn(frame, depth)
    depth = depth or 0
    if not frame or depth > 10 or not frame.GetChildren or frame:IsForbidden() then return end
    if depth > 0 and WSkin.IsForeignFrame(frame) then return end
    if frame.Backplate and frame.Button then FadeSpellItem(frame) end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        FadeSpellItemsIn(children[i], depth + 1)
    end
end

-- Talents tab: tree art stays, dimmed to 75%, lower-only (never raise),
-- BACKGROUND layer only, shallow (talent buttons/icons live deeper on ARTWORK,
-- untouched). Re-runs are no-ops.
local function DimTalentArt(host, depth)
    depth = depth or 0
    if not host or depth > 2 or not host.GetRegions or host:IsForbidden() then return end
    if depth > 0 and WSkin.IsForeignFrame(host) then return end
    local regions = { host:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("Texture") and r:GetDrawLayer() == "BACKGROUND" then
            local a = r:GetAlpha() or 1
            if a > 0.75 then r:SetAlpha(0.75) end
        end
    end
    local children = { host:GetChildren() }
    for i = 1, #children do
        DimTalentArt(children[i], depth + 1)
    end
end

-- Spellbook page chrome: category headers -> white house-font text, gold glow
-- washes gone, dividers stay white, "Page X/Y" matches. Decoration lives on
-- both OVERLAY page-view regions and pooled header textures: wide-short strips
-- are dividers (kept, whitened), the rest is wash (faded).
local function SkinSpellBookChrome(sb)
    local paged = sb and sb.PagedSpellsFrame
    if not paged then return end
    local pc = paged.PagingControls
    if pc and pc.PageText then WSkin.Font(pc.PageText); WSkin.White(pc.PageText) end
    -- The divider is an anonymous non-OVERLAY texture region on the view.
    local function SweepDeco(host)
        local regions = { host:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r.IsObjectType then
                if r:IsObjectType("FontString") then
                    WSkin.Font(r)
                    WSkin.White(r)
                elseif r:IsObjectType("Texture") and not (FFD[r] and FFD[r].isOurLine) then
                    -- Skip our own replacement lines above (else the divider branch
                    -- would re-chain each one 20px shorter per sweep). Rects not yet
                    -- computed (hidden first pass) measure 0x0 and land in the fade
                    -- bucket; the next sweep sees real sizes.
                    local w, h = r:GetSize()
                    if w and h and w > 0 and h > 0 then
                        if h <= 30 and w > 80 then
                            -- Ornate divider art is too dark to read white: fade it,
                            -- draw a clean 1px white 25% line over the same rect.
                            r:SetAlpha(0)
                            local rd = GetFFD(r)
                            if not rd.line then
                                local line = r:GetParent():CreateTexture(nil, "OVERLAY")
                                line:SetColorTexture(1, 1, 1, 0.25)
                                local PPx = EllesmereUI and EllesmereUI.PanelPP
                                if PPx and PPx.DisablePixelSnap then
                                    PPx.DisablePixelSnap(line)
                                    line:SetHeight(PPx.mult or 1)
                                else
                                    line:SetHeight(1)
                                end
                                line:SetPoint("LEFT", r, "LEFT", 20, 0)
                                line:SetPoint("RIGHT", r, "RIGHT", 0, 0)
                                rd.line = line
                                GetFFD(line).isOurLine = true
                            end
                        else
                            r:SetAlpha(0)
                        end
                    end
                end
            end
        end
    end
    for _, k in ipairs({ "View1", "View2" }) do
        if paged[k] then SweepDeco(paged[k]) end
    end
    -- Pooled elements: items answer HasValidData, headers/spacers do not. The
    -- header's gold "card" wash is its keyed Backplate texture, on a lower draw
    -- layer the OVERLAY sweep never saw.
    pcall(function()
        for _, el in paged:EnumerateFrames() do
            if not (el.HasValidData and el:HasValidData()) and el.GetRegions then
                if el.Backplate and el.Backplate.SetAlpha then el.Backplate:SetAlpha(0) end
                SweepDeco(el)
            end
        end
    end)
end

-- Talent loadout popups (import/edit): dark panel + border, white title, house
-- buttons + inputs. Separate top-level frames created with the PlayerSpells
-- addon, so skinning sticks on the talent pass even though shown on demand.
local function SkinTalentDialog(dialog)
    if not dialog or dialog:IsForbidden() then return end
    -- STYLE-AWARE shell (not a flat WSkin.Panel): the popup must follow the
    -- Talents window's theme (atlas "glass" or Modern flat color); a plain
    -- Panel is style-agnostic and reads as opaque next to it.
    WSkin.Shell("playerspells", dialog)
    -- Leftover Blizzard border sub-frame: shell's atlas border replaces it, alpha 0 inherits to all pieces.
    if dialog.Border and dialog.Border.SetAlpha then dialog.Border:SetAlpha(0) end
    local title = dialog.Title or (dialog.TitleContainer and dialog.TitleContainer.TitleText) or dialog.TitleText
    if title then
        WSkin.Font(title); WSkin.White(title)
        -- Seat the title on the shell's top bar (1px above center): the shell's
        -- 25px top strip sits below the native title anchor.
        local sd = WSkin.FFD and WSkin.FFD[dialog]
        local td = GetFFD(title)
        if sd and sd.topBar and title.ClearAllPoints and not td.centered then
            td.centered = true
            title:ClearAllPoints()
            title:SetPoint("CENTER", sd.topBar, "CENTER", 0, 1)
        end
    end
    for _, k in ipairs({ "AcceptButton", "CancelButton", "DeleteButton" }) do
        local b = dialog[k]
        if b then
            WSkin.Button(b)
            local fs = b.GetFontString and b:GetFontString()
            if fs then WSkin.White(fs) end
        end
    end
    -- Loadout-name input: down 15px, 20px shorter. Top+bottom anchored so
    -- SetHeight is ignored -- move anchors instead (top -15, bottom +5); falls
    -- back to SetHeight when there is no bottom anchor. One-shot.
    local nc = dialog.NameControl
    if nc and nc.EditBox then
        WSkin.EditBox(nc.EditBox)
        local eb = nc.EditBox
        local ed = GetFFD(eb)
        if not ed.shorter then
            ed.shorter = true
            local n = eb:GetNumPoints() or 0
            local pts, hasBottom = {}, false
            for i = 1, n do
                local p, rel, rp, x, y = eb:GetPoint(i)
                if p and p:find("BOTTOM") then
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + 5 }
                    hasBottom = true
                elseif p then
                    -- TOP / LEFT / RIGHT / CENTER: shift down 15.
                    pts[i] = { p, rel, rp, x or 0, (y or 0) - 15 }
                end
            end
            eb:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; eb:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            if not hasBottom then
                local h = eb:GetHeight()
                if h and h > 20 then eb:SetHeight(h - 20) end
            end
        end
    end
end

local _spellItemHook = false
local function Skin_PlayerSpells()
    local f = _G.PlayerSpellsFrame
    if not f then return end
    WSkin.Shell("playerspells", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    WSkin.TabSystem(f.TabSystem)
    -- Spellbook class/general tabs get real tab treatment before the button
    -- sweep flattens them; our label stays centered vs. Blizzard's low-seated inactive text.
    if f.SpellBookFrame and f.SpellBookFrame.CategoryTabSystem then
        WSkin.TabSystem(f.SpellBookFrame.CategoryTabSystem, { darkActive = true })
    end
    -- WoW Forever's talents page carries its own dual-spec tabs (Primary /
    -- Secondary): the same tab treatment, also ahead of the button sweep.
    if f.TalentsFrame and f.TalentsFrame.TabSystem then
        WSkin.TabSystem(f.TalentsFrame.TabSystem, { darkActive = true })
    end
    -- Collapse/restore control: quest-tracker collapse/expand atlas pair,
    -- 16x16, desaturated white. Atlas-guarded: a missing name keeps Blizzard's art.
    local function MaxMinGlyph(btn, atlas)
        if not btn or btn:IsForbidden() then return end
        if not (C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas)) then return end
        local d = GetFFD(btn)
        if d.glyph then return end
        for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
            local t = btn[g] and btn[g](btn)
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        WSkin.FadeRegions(btn)
        local glyph = btn:CreateTexture(nil, "OVERLAY")
        glyph:SetAtlas(atlas)
        glyph:SetSize(16, 16)
        glyph:SetPoint("CENTER", -2, 0)
        glyph:SetDesaturated(true)
        glyph:SetVertexColor(1, 1, 1, 0.75)
        d.glyph = glyph
        btn:HookScript("OnEnter", function() glyph:SetVertexColor(1, 1, 1, 1) end)
        btn:HookScript("OnLeave", function() glyph:SetVertexColor(1, 1, 1, 0.75) end)
    end
    local mm = f.MaximizeMinimizeButton or f.MaxMinButtonFrame
    if mm then
        MaxMinGlyph(mm.MinimizeButton, "UI-QuestTrackerButton-Secondary-Collapse")
        MaxMinGlyph(mm.MaximizeButton, "UI-QuestTrackerButton-Secondary-Expand")
    end
    for _, key in ipairs({ "SpellBookFrame", "TalentsFrame", "InspectFrame" }) do
        local sub = f[key]
        if sub then
            WSkin.ButtonsIn(sub)
            WSkin.ScrollBarsIn(sub)
            if key == "SpellBookFrame" then
                -- Page art returns dimmed (halved page is the minimized layout's
                -- art); center bookmark stays full, top bar/corner flipbook stay off.
                WSkin.ExemptArt(sub)
                for _, bk in ipairs({ "BookBGLeft", "BookBGRight", "BookBGHalved" }) do
                    local t = sub[bk]
                    if t and t.SetAlpha then t:SetAlpha(0.1) end
                end
                if sub.TopBar and sub.TopBar.SetAlpha then sub.TopBar:SetAlpha(0) end
                if sub.BookCornerFlipbook and sub.BookCornerFlipbook.SetAlpha then sub.BookCornerFlipbook:SetAlpha(0) end
                -- Assisted-rotation separator: exemption above blocks the art
                -- sweeps reaching it, so fade directly (its button child survives).
                if sub.AssistedCombatRotationSpellFrame then
                    WSkin.FadeRegions(sub.AssistedCombatRotationSpellFrame)
                    WSkin.Register(sub.AssistedCombatRotationSpellFrame, true)
                end
            elseif key == "TalentsFrame" then
                -- Tree background is content: exempt from art sweeps, shown at 75%.
                WSkin.ExemptArt(sub)
                DimTalentArt(sub)
                -- WoW Forever keeps the spec art in ClassBackground and draws a
                -- backdrop of its own as Background, 20px taller than the page,
                -- over the shell's top bar: off, so the shell shows round the tree.
                if sub.ClassBackground and sub.Background and sub.Background.SetAlpha then
                    sub.Background:SetAlpha(0)
                end
                -- WoW Forever's search options button beside the search box: our
                -- arrow alone, no block, on the search box's centre line (Blizzard
                -- seats the button 2px below it). One-shot.
                local sod = sub.SearchOptionsDropdown
                if sod and not sod:IsForbidden() and not GetFFD(sod).arrow then
                    WSkin.FadeRegions(sod)
                    local arrow = sod:CreateTexture(nil, "OVERLAY")
                    arrow:SetAtlas("Azerite-PointingArrow")
                    arrow:SetSize(14, 10)
                    arrow:SetPoint("CENTER", sod, "CENTER", 0, 2)
                    GetFFD(sod).arrow = arrow
                end
                -- Search box matches loadout dropdown height (one-shot, retries until laid out).
                local dd = sub.LoadSystem and sub.LoadSystem.Dropdown
                local sbx = sub.SearchBox
                if dd and sbx and not GetFFD(sbx).hMatched then
                    local dh = dd:GetHeight()
                    if dh and dh > 0 then
                        GetFFD(sbx).hMatched = true
                        sbx:SetHeight(dh)
                    end
                end
            else
                WSkin.FadeKeyedArt(sub)
                WSkin.FadeArtIn(sub)
            end
        end
    end

    -- Spec page: per-spec tile art IS content, so the pane is exempt from art
    -- sweeps and tiles keep their backgrounds. Only the page-level black
    -- underlay + background go (direct sf regions, not tile art, that fight the shell).
    local sf = f.SpecFrame
    if sf then
        WSkin.ExemptArt(sf)
        if sf.BlackBG and sf.BlackBG.SetAlpha then sf.BlackBG:SetAlpha(0) end
        if sf.Background and sf.Background.SetAlpha then sf.Background:SetAlpha(0) end
        WSkin.ButtonsIn(sf)
        WSkin.ScrollBarsIn(sf)
    end

    if f.SpellBookFrame then
        FadeSpellItemsIn(f.SpellBookFrame)
        local sb = f.SpellBookFrame
        SkinSpellBookChrome(sb)
        -- Headers are pooled/re-realized on tab changes and page flips; re-sweep chrome one debounced frame after each.
        local sd = GetFFD(sb)
        if not sd.chromeHooked then
            sd.chromeHooked = true
            local re = WSkin.Debounce(function()
                if f:IsVisible() then SkinSpellBookChrome(sb) end
            end)
            if sb.SetTab then hooksecurefunc(sb, "SetTab", re) end
            -- Returning from Spec/Talents re-realizes pooled headers but only
            -- fires the spellbook subframe's OnShow (window never hid).
            sb:HookScript("OnShow", re)
            local paged = sb.PagedSpellsFrame
            local pc = paged and paged.PagingControls
            if pc and pc.PrevPageButton then pc.PrevPageButton:HookScript("OnClick", re) end
            if pc and pc.NextPageButton then pc.NextPageButton:HookScript("OnClick", re) end
            if paged then paged:HookScript("OnMouseWheel", re) end
        end
    end
    if SpellBookItemMixin and not _spellItemHook then
        _spellItemHook = true
        if SpellBookItemMixin.UpdateVisuals then
            hooksecurefunc(SpellBookItemMixin, "UpdateVisuals", FadeSpellItem)
        end
        -- Both hover edges re-fade the full art set: enter raises highlight art,
        -- leave restores Blizzard's baseline (else a stuck texture is left behind items).
        if SpellBookItemMixin.OnIconEnter then
            hooksecurefunc(SpellBookItemMixin, "OnIconEnter", FadeSpellItem)
        end
        if SpellBookItemMixin.OnIconLeave then
            hooksecurefunc(SpellBookItemMixin, "OnIconLeave", FadeSpellItem)
        end
    end

    -- Loadout popups.
    local importD = _G.ClassTalentLoadoutImportDialog
    if importD then
        SkinTalentDialog(importD)
        -- Import-string box.
        local ic = importD.ImportControl
        if ic and ic.InputContainer then WSkin.Panel(ic.InputContainer) end
    end
    local createD = _G.ClassTalentLoadoutCreateDialog
    if createD then SkinTalentDialog(createD) end
    local editD = _G.ClassTalentLoadoutEditDialog
    if editD then
        SkinTalentDialog(editD)
        if editD.LoadoutName then WSkin.EditBox(editD.LoadoutName) end
        local chk = editD.UsesSharedActionBars and editD.UsesSharedActionBars.CheckButton
        if chk then WSkin.Checkbox(chk) end
    end

    WSkin.ButtonsIn(f)
    WSkin.ScrollBarsIn(f)
    WSkin.FadeKeyedArt(f)
    WSkin.FadeArtIn(f)
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then Skin_PlayerSpells(); WSkin.Restrip(); WSkin.UpdateAllTabs() end
    end))
end

WSkin.RegisterWindow({
    key = "playerspells",
    addons = { Blizzard_PlayerSpells = true },
    apply = Skin_PlayerSpells,
})
end

-------------------------------------------------------------------------------
--  Adventure Guide (EncounterJournal)
-------------------------------------------------------------------------------
-- Some Blizzard text bakes a |cff000000 black or |cff414141 grey run INTO the
-- string (gossip/quest titles, reward/greeting blurbs); SetTextColor cannot
-- lighten those, the embedded run wins. Rewrite only those two tones in place,
-- leaving other colors (links, quest difficulty) untouched; idempotent since
-- the source codes are gone after rewrite.
local DARK_TEXT_RECOLOR = { ["000000"] = "ffffff", ["414141"] = "b0b8bc" }
local function RecolorDarkText(fs)
    if not fs or not fs.GetText then return end
    local txt = fs:GetText()
    if not txt or txt == "" or not txt:find("|cff", 1, true) then return end
    local new, n = txt:gsub("|c[fF][fF](%x%x%x%x%x%x)", function(hex)
        local repl = DARK_TEXT_RECOLOR[hex:lower()]
        if repl then return "|cff" .. repl end
    end)
    if n > 0 and new ~= txt then fs:SetText(new) end
end

-- Force encounter text white once the parchment is gone (SimpleHTML bodies
-- take per-element colors). Embedded hyperlink |c codes are rewritten to the
-- Global Options link color; the |H payload stays untouched so clicking still
-- works and re-runs are idempotent.
local function RecolorLinks(fs)
    local txt = fs.GetText and fs:GetText()
    if not txt or txt == "" or not txt:find("|H", 1, true) then return end
    local new, n = txt:gsub("|c%x%x%x%x%x%x%x%x|H", "|cff" .. WSkin.LinkColorHex() .. "|H")
    if n > 0 and new ~= txt then fs:SetText(new) end
end

local function WhitenTextIn(frame, depth)
    depth = depth or 0
    if not frame or depth > 9 or frame:IsForbidden() then return end
    if frame.GetRegions then
        local regions = { frame:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r.IsObjectType and r:IsObjectType("FontString") and r.SetTextColor then
                r:SetTextColor(1, 1, 1)
                RecolorLinks(r)
                RecolorDarkText(r)
            end
        end
    end
    if frame.GetChildren then
        local children = { frame:GetChildren() }
        for i = 1, #children do
            local c = children[i]
            if c and not WSkin.IsForeignFrame(c, frame) then
                if c.GetObjectType and c:GetObjectType() == "SimpleHTML" and c.SetTextColor then
                    for _, el in ipairs({ "P", "H1", "H2", "H3" }) do
                        pcall(c.SetTextColor, c, el, 1, 1, 1)
                    end
                end
                WhitenTextIn(c, depth + 1)
            end
        end
    end
end

do
local EJ_ART_MATCH = {
    "journalbg", "ui-ej-cataclysm", "abilitytextbg", "paperoverlay",
    "activities-background", "adventureguide-pane",
}
local function ejKeepTex(hay)
    if not hay then return false end
    if WSkin.TexIsIcon(hay) then return true end
    if hay:find("ui-ej-lorebg", 1, true) then return true end   -- instance picture
    if hay:find("ui-ej-boss", 1, true) then return true end     -- boss render
    if hay:find("ui-ej-icons", 1, true) then return true end
    return false
end
local function FadeEJArt(frame, depth)
    depth = depth or 0
    if not frame or depth > 11 or not frame.GetRegions or frame:IsForbidden() then return end
    if WSkin.IsArtExempt(frame) then return end
    if depth > 0 and WSkin.IsForeignFrame(frame) then return end
    local mybg = FFD[frame] and FFD[frame].bg
    local regions = { frame:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= mybg and r.IsObjectType and r:IsObjectType("Texture") and (r:GetAlpha() or 0) > 0 then
            local hay = WSkin.TexHay(r)
            if hay and not ejKeepTex(hay) then
                for _, m in ipairs(EJ_ART_MATCH) do
                    if hay:find(m, 1, true) then r:SetAlpha(0); break end
                end
            end
        end
    end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        FadeEJArt(children[i], depth + 1)
    end
end

-- Breadcrumb nav button: art gone, white text, 1px right-edge divider (hidden
-- on the last crumb), subnav caret drawn with the house arrow. Crumbs resize to
-- content (|pad| text (gap arrow) |pad|) and re-chain seamlessly in RefreshNav.
local NAV_PAD       = 14   -- even padding on each side of a crumb's content
local NAV_ARROW_GAP = 4    -- gap between text and the subnav arrow
local NAV_ARROW_W   = 12   -- arrow width (62x44 atlas at 12x8.5)
local _navReflow           -- assigned to RefreshNav once the nav is skinned
local function SkinNavButton(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    if not d.navskin then
        d.navskin = true
        -- Rewinding (earlier crumb/Home click) relayouts survivors inside the
        -- click handler; reflow synchronously so they never render at Blizzard's layout.
        btn:HookScript("OnClick", function()
            local nv = btn:GetParent()
            local rf = nv and FFD[nv] and FFD[nv].reflow
            if rf then
                rf()
            elseif _navReflow then
                _navReflow()
            end
        end)
        for _, g in ipairs({ "GetNormalTexture", "GetHighlightTexture", "GetPushedTexture", "GetDisabledTexture" }) do
            local fn = btn[g]; local t = fn and fn(btn)
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        WSkin.FadeRegions(btn)
        local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetPoint("TOPLEFT", 2, -3)
        hov:SetPoint("BOTTOMRIGHT", -2, 3)
        d.hover = hov
        local div = btn:CreateTexture(nil, "OVERLAY")
        div:SetColorTexture(1, 1, 1, 0.15)
        div:SetWidth(1)
        div:SetPoint("TOPRIGHT", btn, "TOPRIGHT", 0, -5)
        div:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 5)
        d.divider = div
    end
    if btn.text then WSkin.White(btn.text) end

    local ma = btn.MenuArrowButton
    if ma and not d.arrow then
        -- Arrow lives ON the caret button, so it follows Blizzard's show/hide for crumbs with a subnav menu.
        local arrow = ma:CreateTexture(nil, "OVERLAY")
        arrow:SetAtlas("Azerite-PointingArrow")
        arrow:SetSize(12, 8.5)   -- native 62x44 aspect
        arrow:SetPoint("CENTER")
        d.arrow = arrow
    end
    if ma then
        -- Blizzard re-applies caret/border/glow art on nav rebuild AND raises
        -- hover art on OnEnter, so fade ALL native art every pass and from
        -- enter/leave hooks too, keeping our arrow.
        local md = GetFFD(ma)
        local function FadeArrowArt()
            local keep = { [d.arrow] = true }
            WSkin.FadeRegions(ma, keep)
            for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
                local fn = ma[g]; local t = fn and fn(ma)
                if t and not keep[t] and t.SetAlpha then t:SetAlpha(0) end
            end
            if ma.Art and ma.Art.SetAlpha then ma.Art:SetAlpha(0) end
        end
        FadeArrowArt()
        if not md.hoverHooked then
            md.hoverHooked = true
            ma:HookScript("OnEnter", FadeArrowArt)
            ma:HookScript("OnLeave", FadeArrowArt)
        end
    end

    -- |pad| text (gap arrow) |pad| -- even spacing against the dividers.
    if btn.text then
        btn.text:ClearAllPoints()
        btn.text:SetPoint("LEFT", btn, "LEFT", NAV_PAD, 0)
        if ma and not d.maMoved then
            d.maMoved = true
            ma:ClearAllPoints()
            -- 5px left of the nominal gap position (arrow hugs the text).
            ma:SetPoint("LEFT", btn.text, "RIGHT", NAV_ARROW_GAP - 5, 0)
        end
    end
end

-- Breadcrumb bar restyle (adventure guide + world map): faint wash over just
-- the crumbs, white text with 1px dividers, house subnav arrows,
-- content-driven widths chained seamlessly. dx/dy reseat from Blizzard's spot
-- (captured once), bar runs 6px slimmer. bgColor {r,g,b,a} sets the crumb wash
-- (default 5% white; map uses 20% black).
local function RestyleNavGeneric(nav, dx, dy, bgColor)
    if not nav then return end
    for _, k in ipairs({ "InsetBorderBottomLeft", "InsetBorderBottomRight", "InsetBorderBottom",
                         "InsetBorderLeft", "InsetBorderRight" }) do
        local t = nav[k]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    local nd = GetFFD(nav)
    if not nd.bg then
        local wash = nav:CreateTexture(nil, "BACKGROUND", nil, -6)
        wash:SetAllPoints(nav)
        nd.bg = wash
    end
    local bc = bgColor or { 1, 1, 1, 0.05 }
    nd.bg:SetColorTexture(bc[1], bc[2], bc[3], bc[4])
    if nd.origP == nil then
        local p, rel, rp, x, y = nav:GetPoint(1)
        if p then
            nd.origP, nd.origRel, nd.origRP = p, rel, rp
            nd.origX, nd.origY = x or 0, y or 0
        end
    end
    if nd.origP then
        nav:ClearAllPoints()
        nav:SetPoint(nd.origP, nd.origRel, nd.origRP,
            nd.origX + (dx or 0), nd.origY + (dy or 0))
    end
    if nd.origH == nil then
        local h = nav:GetHeight()
        if h and h > 0 then nd.origH = h end
    end
    if nd.origH then nav:SetHeight(nd.origH - 6) end
    local keep = { [nd.bg] = true }
    WSkin.FadeRegions(nav, keep)
    WSkin.Register(nav, true)
    if nav.overlay then
        -- Decorative overlay: alpha the whole frame so anonymous textures cannot resurface.
        WSkin.FadeRegions(nav.overlay)
        local nt = nav.overlay.GetNormalTexture and nav.overlay:GetNormalTexture()
        if nt and nt.SetAlpha then nt:SetAlpha(0) end
        if nav.overlay.SetAlpha then nav.overlay:SetAlpha(0) end
        WSkin.Register(nav.overlay, true)
    end
    if nav.navList then
        local n = #nav.navList
        -- Wash covers only the crumbs, not the full nav width: left edges ride the nav, right edge rides the last crumb.
        local last = nav.navList[n]
        if last and nd.bg then
            nd.bg:ClearAllPoints()
            nd.bg:SetPoint("TOPLEFT", nav, "TOPLEFT", 0, 0)
            nd.bg:SetPoint("BOTTOMLEFT", nav, "BOTTOMLEFT", 0, 0)
            nd.bg:SetPoint("RIGHT", last, "RIGHT", 0, 0)
        end
        for i = 1, n do
            local b = nav.navList[i]
            if b then
                SkinNavButton(b)
                -- Content-driven width: each crumb is exactly |pad|text (gap
                -- arrow)|pad| wide, butting its neighbour so the divider sits on
                -- the boundary with even spacing both sides.
                local tw = (b.text and b.text.GetStringWidth and b.text:GetStringWidth()) or 0
                local ma = b.MenuArrowButton
                local hasArrow = ma and ma:IsShown()
                b:SetWidth(NAV_PAD + tw + (hasArrow and (NAV_ARROW_GAP + NAV_ARROW_W) or 0) + NAV_PAD)
                if i > 1 and nav.navList[i - 1] then
                    b:ClearAllPoints()
                    b:SetPoint("LEFT", nav.navList[i - 1], "RIGHT", 0, 0)
                end
                local bd = FFD[b]
                if bd and bd.divider then bd.divider:SetShown(i < n) end
            end
        end
    end
end

-- Boss-list row: keep the creature render, 10% white block behind, white name.
local function SkinBossButton(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    if not d.bossbtn then
        d.bossbtn = true
        for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
            local fn = btn[g]; local t = fn and fn(btn)
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local fill = btn:CreateTexture(nil, "BACKGROUND", nil, -2)
        fill:SetColorTexture(1, 1, 1, 0.1)
        fill:SetPoint("TOPLEFT", 1, -1)
        fill:SetPoint("BOTTOMRIGHT", -1, 1)
        d.bg = fill
        -- No border: the creature render overflows the row and a border would
        -- draw a line across the model.
    end
    if btn.text then WSkin.White(btn.text) end
    if btn.name then WSkin.White(btn.name) end
    -- Active boss keeps the full plate, the rest read at half. With no boss
    -- selected (instance overview), all stay full.
    local ejID = _G.EncounterJournal and _G.EncounterJournal.encounterID
    local active = not ejID or (btn.encounterID and btn.encounterID == ejID)
    d.bg:SetAlpha(active and 1 or 0.5)
end
local function FlattenBossButtons(frame, depth)
    depth = depth or 0
    if not frame or depth > 8 or frame:IsForbidden() or not frame.GetChildren then return end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        local c = children[i]
        if c and not WSkin.IsForeignFrame(c, frame) then
            if c.creature and (c.text or c.name) and c.GetObjectType and c:GetObjectType() == "Button" then
                SkinBossButton(c)
            end
            FlattenBossButtons(c, depth + 1)
        end
    end
end

-- Instance-select tile: keep the splash image, square it, frame with the AH
-- item-header atlas (sized to image) + white hover. Raid tiles carry extra baked
-- border art getter fades miss, so every region except splash/frame/hover is
-- faded, re-asserted per pass (tiles are pooled and repainted).
local function SkinInstanceButton(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    if not d.instbtn then
        d.instbtn = true
        local frameArt = btn:CreateTexture(nil, "OVERLAY", nil, 7)
        frameArt:SetAtlas("shop-card-wide-frame-default")
        frameArt:SetAlpha(0.5)
        if btn.bgImage then
            frameArt:SetAllPoints(btn.bgImage)
        else
            frameArt:SetAllPoints(btn)
        end
        d.frameArt = frameArt
        local hov = btn:CreateTexture(nil, "HIGHLIGHT")
        hov:SetAtlas("shop-card-wide-frame-hover")
        hov:SetAllPoints(frameArt)
        d.hover = hov
    end
    -- Blizzard re-anchors the splash on pool updates; re-assert a 1px inset every pass to clear the clipping viewport.
    if btn.bgImage and btn.bgImage.SetPoint then
        btn.bgImage:ClearAllPoints()
        btn.bgImage:SetPoint("TOPLEFT", 1, -1)
        btn.bgImage:SetPoint("BOTTOMRIGHT", -1, 1)
    end
    -- Native tile art blends at half strength under our frame art (splash/frame/
    -- hover stay full); native highlight fully faded since our hover atlas replaces it.
    local keep = {}
    if btn.bgImage then keep[btn.bgImage] = true end
    if d.frameArt then keep[d.frameArt] = true end
    if d.hover then keep[d.hover] = true end
    local regions = { btn:GetRegions() }
    for j = 1, #regions do
        local r = regions[j]
        if r and not keep[r] and r.IsObjectType and r:IsObjectType("Texture") then
            r:SetAlpha(0.5)
        end
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture" }) do
        local fn = btn[g]; local t = fn and fn(btn)
        if t and not keep[t] and t.SetAlpha then t:SetAlpha(0.5) end
    end
    local hl = btn.GetHighlightTexture and btn:GetHighlightTexture()
    if hl and not keep[hl] and hl.SetAlpha then hl:SetAlpha(0) end
end
local function FlattenInstanceButtons(frame, depth)
    depth = depth or 0
    if not frame or depth > 8 or frame:IsForbidden() or not frame.GetChildren then return end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        local c = children[i]
        if c and not WSkin.IsForeignFrame(c, frame) then
            if c.bgImage and c.name and c.GetObjectType and c:GetObjectType() == "Button" then
                SkinInstanceButton(c)
            end
            FlattenInstanceButtons(c, depth + 1)
        end
    end
end

-- Side icon tab (overview/loot/boss/model): smaller dark box behind the glyph
-- (icon keeps its size) with a black border, pushed right so tabs hang off the
-- window's side, extra spacing between them. Hover glow (HighlightTexture) is
-- re-faded every detail pass since the journal re-raises tab art on navigation.
local SIDE_TAB_X     = 16   -- push right so the box sits flush on the panel edge
local SIDE_TAB_GAP   = 2    -- extra vertical space between tabs
local SIDE_TAB_INSET = 3    -- how much smaller the dark box is than the tab

-- Idempotent: original anchor offsets captured once, shift is always original
-- + constants (never compounds). Handles both anchoring shapes: chained
-- (tab -> previous tab) and flat (every tab -> shared host).
local function PositionSideTab(tab, index)
    if not tab or tab:IsForbidden() then return end
    local d = GetFFD(tab)
    local p, rel, rp, x, y = tab:GetPoint(1)
    if not p then return end
    if d.origX == nil then d.origX, d.origY = x or 0, y or 0 end
    local relIsTab = rel and FFD[rel] and FFD[rel].sidetab
    local xAdd = relIsTab and 0 or SIDE_TAB_X
    local yMult = relIsTab and 1 or ((index or 1) - 1)
    tab:ClearAllPoints()
    tab:SetPoint(p, rel, rp, d.origX + xAdd, d.origY - SIDE_TAB_GAP * yMult)
end

local function SkinSideTab(tab, index)
    if not tab or tab:IsForbidden() then return end
    local d = GetFFD(tab)
    if not d.sidetab then
        d.sidetab = true
        -- Box sits two levels below the tab so its fill AND its border
        -- container (box level + 1) both draw beneath the tab's glyph.
        local box = CreateFrame("Frame", nil, tab)
        box:SetPoint("TOPLEFT", SIDE_TAB_INSET, -SIDE_TAB_INSET)
        box:SetPoint("BOTTOMRIGHT", -SIDE_TAB_INSET, SIDE_TAB_INSET)
        box:SetFrameLevel(math.max(0, tab:GetFrameLevel() - 2))
        local fill = SolidTex(box, "BACKGROUND", Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        fill:SetAllPoints(box)
        WSkin.AddBorder(box, 0, 0, 0, 1)
        d.box = box
        d.bg = fill
        local hov = SolidTex(tab, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetPoint("TOPLEFT", box, "TOPLEFT", 0, 0)
        hov:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 0, 0)
        d.hover = hov
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture", "GetHighlightTexture" }) do
        local fn = tab[g]; local t = fn and fn(tab)
        if t and t ~= d.hover and t.SetAlpha then t:SetAlpha(0) end
    end
    -- Pin the glyph to its original anchor (no nudge: icons read off-center).
    -- Blizzard re-seats it on click/selection, so the pin re-asserts synchronously
    -- inside that SetPoint (reentry-guarded); single-point regions only, all-points state textures left alone.
    local regions = { tab:GetRegions() }
    for j = 1, #regions do
        local r = regions[j]
        if r and r ~= d.hover and r.IsObjectType and r:IsObjectType("Texture")
           and r.GetNumPoints and r:GetNumPoints() == 1 then
            local rd = GetFFD(r)
            if not rd.pinned then
                local p, rel, rp, x, y = r:GetPoint(1)
                if p then
                    rd.pinned = true
                    rd.pin = { p, rel, rp, x or 0, y or 0 }
                    hooksecurefunc(r, "SetPoint", function()
                        if rd.inPin then return end
                        rd.inPin = true
                        r:ClearAllPoints()
                        r:SetPoint(rd.pin[1], rd.pin[2], rd.pin[3], rd.pin[4], rd.pin[5])
                        rd.inPin = false
                    end)
                end
            end
        end
    end
    -- Disabled tabs read at half opacity: plate/border/icon dim together via the tab's own alpha.
    local enabled = not tab.IsEnabled or tab:IsEnabled()
    tab:SetAlpha(enabled and 1 or 0.5)
    -- Tab 10% smaller (one-shot; the box follows its insets, the glyph keeps
    -- its native size).
    if not d.shrunk then
        local w, h = tab:GetSize()
        if w and h and w > 0 and h > 0 then
            d.shrunk = true
            tab:SetSize(w * 0.9, h * 0.9)
        end
    end
    PositionSideTab(tab, index)
end

-- Loot row: parchment art gone, flat block, squared item icon, light subtext.
local function SkinLootRow(btn)
    if not btn or btn:IsForbidden() then return end
    if btn.bossTexture and btn.bossTexture.SetAlpha then btn.bossTexture:SetAlpha(0) end
    if btn.bosslessTexture and btn.bosslessTexture.SetAlpha then btn.bosslessTexture:SetAlpha(0) end
    local d = GetFFD(btn)
    if not d.lootrow then
        d.lootrow = true
        local fill = btn:CreateTexture(nil, "BACKGROUND", nil, -3)
        fill:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
        fill:SetPoint("TOPLEFT", 1, -1)
        fill:SetPoint("BOTTOMRIGHT", -1, 1)
        d.bg = fill
        WSkin.AddBorder(btn)
        if btn.icon then WSkin.SquareIcon(btn.icon, btn) end
    end
    for _, k in ipairs({ "slot", "armorType", "boss" }) do
        local fs = btn[k]
        if fs then WSkin.White(fs, 0.82, 0.82, 0.82) end
    end
end
local function FlattenLootRows(frame, depth)
    depth = depth or 0
    if not frame or depth > 8 or frame:IsForbidden() or not frame.GetChildren then return end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        local c = children[i]
        if c and not WSkin.IsForeignFrame(c, frame) then
            if c.bossTexture and c.slot and c.GetObjectType and c:GetObjectType() == "Button" then
                SkinLootRow(c)
            end
            FlattenLootRows(c, depth + 1)
        end
    end
end

-- Gear-tab filter dropdowns: native caret faded, house arrow seated just past
-- the label's MEASURED text end, re-seated on text change. Label rect is wider
-- than the text, so anchoring to Blizzard's caret position sits it too far away.
local function SwapFilterArrow(filt)
    if not filt then return end
    local fd = GetFFD(filt)
    if filt.Arrow and filt.Arrow.SetAlpha then filt.Arrow:SetAlpha(0) end
    if fd.arrow then return end
    local arrow = filt:CreateTexture(nil, "OVERLAY")
    arrow:SetAtlas("Azerite-PointingArrow")
    arrow:SetSize(12, 8.5)
    fd.arrow = arrow
    local label = filt.Text or (filt.GetFontString and filt:GetFontString())
    if label and label.GetStringWidth then
        local function seat()
            arrow:ClearAllPoints()
            -- GetStringWidth is the FULL untruncated width; a width-constrained
            -- label ellipsis-truncates, so hug the visible edge (label width), not the phantom one.
            local sw = label:GetStringWidth() or 0
            local lw = (label.GetWidth and label:GetWidth()) or 0
            if lw > 0 and sw > lw then sw = lw end
            arrow:SetPoint("LEFT", label, "LEFT", sw + 4, 0)
        end
        seat()
        hooksecurefunc(label, "SetText", seat)
    elseif filt.Arrow then
        arrow:SetPoint("CENTER", filt.Arrow, "CENTER", 0, 0)
    else
        arrow:SetPoint("RIGHT", filt, "RIGHT", -6, 0)
    end
end

-- Ability/overview section header: paper art gone, flat block, white title,
-- hover glow -> subtle whiten wash. Covers encounter-info headers (title +
-- expandedIcon) and Overview headers (Title only, separate Glow child frame).
-- All native art re-faded per pass since Blizzard repaints on expand/collapse.
local function SkinAbilityHeaders(frame, depth)
    depth = depth or 0
    if not frame or depth > 9 or frame:IsForbidden() or not frame.GetChildren then return end
    local children = { frame:GetChildren() }
    for i = 1, #children do
        local c = children[i]
        if c and not WSkin.IsForeignFrame(c, frame) then
            if c.descriptionBG and c.descriptionBG.SetAlpha then c.descriptionBG:SetAlpha(0) end
            if c.descriptionBGBottom and c.descriptionBGBottom.SetAlpha then c.descriptionBGBottom:SetAlpha(0) end
            -- Description bullets -> round status orb (first cell of the lootroll reveal sheet), white.
            local blt = c.Bullet
            if blt and blt.SetTexture and not GetFFD(blt).orbed then
                GetFFD(blt).orbed = true
                local info = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("lootroll-animreveal-a")
                if info and info.file then
                    local aL, aR = info.leftTexCoord or 0, info.rightTexCoord or 1
                    local aT, aB = info.topTexCoord or 0, info.bottomTexCoord or 1
                    blt:SetTexture(info.file)
                    blt:SetTexCoord(aL, aL + (aR - aL) / 6, aT, aT + (aB - aT) / 2)
                else
                    blt:SetAtlas("lootroll-animreveal-a")
                    blt:SetTexCoord(0, 1 / 6, 0, 0.5)
                end
                blt:SetVertexColor(1, 1, 1, 1)
                local bw, bh = blt:GetSize()
                if bw and bh and bw > 0 and bh > 0 then blt:SetSize(bw + 2, bh + 2) end
            end
            local b = c.button
            local bTitle = b and (b.title or b.Title)
            if b and bTitle then
                local d = GetFFD(b)
                if not d.abilrow then
                    d.abilrow = true
                    local fill = b:CreateTexture(nil, "BACKGROUND", nil, -2)
                    fill:SetColorTexture(Theme.bgR + 0.02, Theme.bgG + 0.02, Theme.bgB + 0.02, Theme.bgA)
                    fill:SetPoint("TOPLEFT", 0, -1)
                    fill:SetPoint("BOTTOMRIGHT", 0, 1)
                    d.bg = fill
                    WSkin.AddBorder(b)
                    local hov = SolidTex(b, "HIGHLIGHT", 1, 1, 1, 0.05)
                    hov:SetPoint("TOPLEFT", 0, -1)
                    hov:SetPoint("BOTTOMRIGHT", 0, 1)
                    d.hover = hov
                end
                -- Every native texture region goes (paper caps, highlight strips,
                -- anonymous art), keeping our fill+wash AND the boss ability icon
                -- (<button>AbilityIcon) -- a real region the blanket fade would
                -- strip unless preserved by name/parentKey.
                local keep = { [d.bg] = true, [d.hover] = true }
                local abIcon = b.AbilityIcon
                    or (b.GetName and b:GetName() and _G[b:GetName() .. "AbilityIcon"])
                if abIcon then keep[abIcon] = true end
                WSkin.FadeRegions(b, keep)
                local hl = b.GetHighlightTexture and b:GetHighlightTexture()
                if hl and not keep[hl] and hl.SetAlpha then hl:SetAlpha(0) end
                -- Glow lives on a child frame found by name (parentKey varies).
                local children2 = { b:GetChildren() }
                for j = 1, #children2 do
                    local ch = children2[j]
                    if ch and ch.GetName then
                        local nm = ch:GetName()
                        if nm and nm:find("Glow", 1, true) and ch.SetAlpha then
                            WSkin.FadeRegions(ch)
                            ch:SetAlpha(0)
                        end
                    end
                end
                WSkin.White(bTitle)
                if b.expandedIcon and b.expandedIcon.SetTextColor then b.expandedIcon:SetTextColor(1, 1, 1) end
                -- Role icons (tank/healer/dps): 4px smaller. Hang off the header
                -- button by GLOBAL name only (no parent key): <button>Icon1..4
                -- frames, each with an <icon>Icon texture inside (also shrunk when
                -- explicitly sized; all-points ones follow the frame).
                if not d.iconShrunk then
                    d.iconShrunk = true
                    local bn = b.GetName and b:GetName()
                    local seen = {}
                    for j = 0, 4 do
                        local ic
                        if j == 0 then
                            ic = b.icon or b.Icon
                        else
                            ic = b["Icon" .. j] or (bn and _G[bn .. "Icon" .. j])
                        end
                        if ic and ic.GetSize then
                            local w, h = ic:GetSize()
                            if w and h and w > 4 and h > 4 then
                                ic:SetSize(w - 4, h - 4)
                                local inner = ic.Icon or (ic.GetName and ic:GetName() and _G[ic:GetName() .. "Icon"])
                                if inner and inner.GetSize then
                                    local iw, ih = inner:GetSize()
                                    if iw and ih and iw > 4 and ih > 4 then
                                        inner:SetSize(iw - 4, ih - 4)
                                    end
                                end
                            end
                            -- 3px left, chain roots only: an icon chained to a
                            -- previous icon keeps its relative anchor since shifting the root moves the whole group.
                            local p, rel, rp, x, y = ic:GetPoint(1)
                            if p and not seen[rel] then
                                ic:ClearAllPoints()
                                ic:SetPoint(p, rel, rp, (x or 0) - 3, y or 0)
                            end
                            seen[ic] = true
                        end
                    end
                end
            end
            SkinAbilityHeaders(c, depth + 1)
        end
    end
end

-- Instance-select pane scene (shared by Tutorials and Dungeons/Raids) drops
-- alpha so the shell shows through: true translucency, not a darken. The art is
-- $parentBG plus anonymous BACKGROUND regions; every BACKGROUND texture above
-- 50% is lowered (never raised, so art already faded stays faded). Re-applied
-- per refresh pass in case Blizzard re-asserts.
local function RestyleInstanceScene(isel)
    if not isel then return end
    local regions = { isel:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("Texture") and r:GetDrawLayer() == "BACKGROUND" then
            local a = r:GetAlpha() or 1
            if a > 0.5 then r:SetAlpha(0.25) end
        end
    end
end

-- Great Vault shortcut (top right of Journeys/instance views): same vault art
-- as the minimap's button, state textures retextured in place (geometry/anchors/hover untouched).
local VAULT_BUTTON_ATLAS = "greatVault-whole-normal"
local function RestyleGreatVaultButton(gv)
    if not gv or gv:IsForbidden() then return end
    local d = GetFFD(gv)
    -- 14px smaller (one-shot; retries until the button has a laid-out size).
    if not d.shrunk then
        local w, h = gv:GetSize()
        if w and h and w > 14 and h > 14 then
            d.shrunk = true
            gv:SetSize(w - 14, h - 14)
        end
    end
    -- 4px right of wherever Blizzard seats it, applied relative to the CURRENT
    -- anchor via a SetPoint post-hook so per-view repositioning is kept (a fixed
    -- captured anchor would bleed the Journeys position onto other tabs).
    if not d.nudged then
        d.nudged = true
        local function nudge()
            if d.inNudge then return end
            local p, rel, rp, x, y = gv:GetPoint(1)
            if not p then return end
            d.inNudge = true
            gv:ClearAllPoints()
            gv:SetPoint(p, rel, rp, (x or 0) + 4, y or 0)
            d.inNudge = false
        end
        hooksecurefunc(gv, "SetPoint", nudge)
        nudge()
    end
    if d.vaultSwapped then return end
    local swapped = false
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture" }) do
        local t = gv[g] and gv[g](gv)
        if t and t.SetAtlas then
            t:SetAtlas(VAULT_BUTTON_ATLAS)
            swapped = true
        end
    end
    local regions = { gv:GetRegions() }
    for j = 1, #regions do
        local r = regions[j]
        if r and r.IsObjectType and r:IsObjectType("Texture") then
            local hay = WSkin.TexHay(r)
            if hay and hay:find("vault", 1, true) then
                r:SetAtlas(VAULT_BUTTON_ATLAS)
                swapped = true
            end
        end
    end
    if swapped then d.vaultSwapped = true end
end

-- Round creature portraits: delve companion ring as circle border, sized 2px
-- outside the CREATURE texture (not its frame), no plate -- their field shape
-- matches the boss-row pass, which would otherwise light-background them. No
-- active/inactive styling.
local function RingCreatureFrame(cb, creature)
    if not cb or cb:IsForbidden() then return end
    local d = GetFFD(cb)
    creature = creature or cb.creature or cb.Creature
    if not creature then
        local n = cb.GetName and cb:GetName()
        creature = n and _G[n .. "Creature"] or nil
    end
    if not d.ring then
        local ring = cb:CreateTexture(nil, "OVERLAY", nil, 7)
        ring:SetAtlas("UI-Journeys-Delve-Companion-Ring")
        -- 2px outset per side (4px larger than the portrait).
        local anchor = creature or cb
        ring:SetPoint("TOPLEFT", anchor, "TOPLEFT", -2, 2)
        ring:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", 2, -2)
        d.ring = ring
        d.creature = creature
    end
    -- Neutralize the white plate laid on by the boss-row pass.
    if d.bg then d.bg:SetColorTexture(0, 0, 0, 0) end
end

local function SkinCreatureButtons()
    for i = 1, 9 do
        local cb = _G["EncounterJournalEncounterFrameInfoCreatureButton" .. i]
        if not cb then break end
        RingCreatureFrame(cb)
    end
    -- Main creature display: anonymous child of info carrying a CircleMask;
    -- its portrait is the info-named Creature texture.
    local info = _G.EncounterJournalEncounterFrameInfo
    if info then
        local children = { info:GetChildren() }
        for i = 1, #children do
            local ch = children[i]
            if ch and ch.CircleMask and not GetFFD(ch).ring then
                local creature = _G.EncounterJournalEncounterFrameInfoCreature
                if creature and creature.GetParent and creature:GetParent() ~= ch then
                    creature = nil
                end
                RingCreatureFrame(ch, creature)
            end
        end
    end
end

local _ejHooked = false
local function Skin_EncounterJournal()
    local f = _G.EncounterJournal
    if not f then return end
    WSkin.Shell("adventureguide", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "EncounterJournal")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.EncounterJournalBg then _G.EncounterJournalBg:SetAlpha(0) end
    for _, k in ipairs({ "inset", "Inset" }) do
        if f[k] then WSkin.Inset(f[k]) end
    end

    -- The scene background (instanceSelect.evergreenBg) is shared by Tutorials
    -- and Dungeons/Raids and IS the content there, so every art sweep skips
    -- those subtrees; instance tiles still get squared by FlattenInstanceButtons (a targeted pass, not a sweep).
    if f.TutorialsFrame then WSkin.ExemptArt(f.TutorialsFrame) end
    if f.instanceSelect then WSkin.ExemptArt(f.instanceSelect) end

    -- Breadcrumb bar: faint 5% white wash (no border), seated 8px lower and
    -- 35px left of Blizzard's spot, white crumbs with dividers. Reseat is idempotent (original anchors captured once).
    local nav = f.navBar
    local function RefreshNav()
        RestyleNavGeneric(nav, -37, -8)
    end
    _navReflow = RefreshNav
    if nav then GetFFD(nav).reflow = RefreshNav end
    RefreshNav()

    if f.LootJournalViewDropdown then WSkin.Dropdown(f.LootJournalViewDropdown) end
    if f.searchBox then
        WSkin.EditBox(f.searchBox)
        -- Seat 2px lower than Blizzard's spot (idempotent, original anchor captured once).
        local sd = GetFFD(f.searchBox)
        if sd.origP == nil then
            local p, rel, rp, x, y = f.searchBox:GetPoint(1)
            if p then
                sd.origP, sd.origRel, sd.origRP = p, rel, rp
                sd.origX, sd.origY = x or 0, y or 0
            end
        end
        if sd.origP then
            f.searchBox:ClearAllPoints()
            f.searchBox:SetPoint(sd.origP, sd.origRel, sd.origRP, sd.origX, sd.origY - 2)
        end
    end
    -- Search autocomplete popout + full results window: container -> flat dark
    -- panel; preview rows + "show all results" -> subtle hover + white text;
    -- results window -> panel + slim scrollbar + house close button.
    local sbox = f.searchBox
    local prevC = sbox and sbox.searchPreviewContainer
    if prevC then
        WSkin.Panel(prevC)
        -- framed = the button is its OWN panel (bg + border). Preview rows sit
        -- inside the container's panel so need none; showAllResults is a SIBLING
        -- below the container with no backdrop, so it gets its own fill+border.
        local function SkinEJSearchBtn(btn, framed)
            if not btn or btn:IsForbidden() then return end
            local d = GetFFD(btn)
            if not d.ejSearchSkinned then
                d.ejSearchSkinned = true
                local icon = btn.icon or btn.Icon
                local keep = icon and { [icon] = true } or nil
                WSkin.FadeRegions(btn, keep)
                if framed then
                    local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -6)
                    bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
                    bg:SetAllPoints(btn)
                    d.bg = bg
                    WSkin.AddBorder(btn)
                end
                local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.1)
                hov:SetAllPoints(btn)
                d.hover = hov
                WSkin.Register(btn, keep or true)
                if icon then WSkin.SquareIcon(icon, btn) end
            end
            if btn.selectedTexture and btn.selectedTexture.SetColorTexture then
                btn.selectedTexture:SetColorTexture(1, 1, 1, 0.12)
            end
            for _, k in ipairs({ "name", "text", "resultType" }) do
                local fs = btn[k]
                if fs and fs.SetTextColor then WSkin.White(fs) end
            end
        end
        local function SkinAllEJSearch()
            -- Re-assert the container panel: Blizzard re-raises corner art on popout show, hiding our border.
            WSkin.Panel(prevC)
            for i = 1, (_G.EJ_NUM_SEARCH_PREVIEWS or 5) do
                SkinEJSearchBtn(sbox["searchPreview" .. i])
            end
            SkinEJSearchBtn(sbox.showAllResults, true)
        end
        SkinAllEJSearch()
        -- Preview rows re-populate as you type; re-white after each update.
        if not GetFFD(sbox).searchHook and type(_G.EncounterJournal_SetSearchPreview) == "function" then
            GetFFD(sbox).searchHook = true
            hooksecurefunc("EncounterJournal_SetSearchPreview", SkinAllEJSearch)
        end
    end
    local sr = _G.EncounterJournalSearchResults
    if sr then
        WSkin.Panel(sr)
        if sr.ScrollBar then WSkin.ScrollBar(sr.ScrollBar) end
        local cb = _G.EncounterJournalSearchResultsCloseButton or sr.CloseButton
        if cb then WSkin.CloseButton(cb) end
    end
    if f.instanceSelect then
        if f.instanceSelect.ExpansionDropdown then WSkin.Dropdown(f.instanceSelect.ExpansionDropdown) end
        if f.instanceSelect.Title then WSkin.White(f.instanceSelect.Title) end
        FlattenInstanceButtons(f.instanceSelect)
    end
    if f.encounter and f.encounter.info and f.encounter.info.difficulty then
        local diff = f.encounter.info.difficulty
        WSkin.Dropdown(diff)
        -- Seat 4px left of Blizzard's spot (idempotent: original anchor captured once).
        local dd = GetFFD(diff)
        if dd.origP == nil then
            local p, rel, rp, x, y = diff:GetPoint(1)
            if p then
                dd.origP, dd.origRel, dd.origRP = p, rel, rp
                dd.origX, dd.origY = x or 0, y or 0
            end
        end
        if dd.origP then
            diff:ClearAllPoints()
            diff:SetPoint(dd.origP, dd.origRel, dd.origRP, dd.origX - 6, dd.origY)
        end
    end

    local ejTabs = {}
    for _, k in ipairs({ "JourneysTab", "MonthlyActivitiesTab", "suggestTab",
                         "dungeonsTab", "raidsTab", "LootJournalTab", "TutorialsTab" }) do
        local t = f[k]
        if t then WSkin.Tab(t); ejTabs[#ejTabs + 1] = t end
    end
    WSkin.NormalizeTabRow(ejTabs)

    if f.instanceSelect then
        RestyleGreatVaultButton(f.instanceSelect.GreatVaultButton)
        RestyleInstanceScene(f.instanceSelect)
    end

    local function RefreshSuggest()
        local sf = f.suggestFrame
        if not sf then return end
        WhitenTextIn(sf)
        -- The three suggestion panels keep their big artwork: exempt their
        -- subtrees from the art fade and restore the bg it zeroed.
        for i = 1, 3 do
            local s = sf["Suggestion" .. i]
            if s then
                WSkin.ExemptArt(s)
                if s.bg then s.bg:SetAlpha(0.4) end
            end
        end
        local s1 = sf.Suggestion1
        if s1 then
            if s1.prevButton then WSkin.PageButton(s1.prevButton, "<", 12) end
            if s1.nextButton then WSkin.PageButton(s1.nextButton, ">", 12) end
            -- Hero suggestion action button label 2px smaller (target captured once,
            -- re-asserted since Blizzard re-applies its font object on refresh).
            local bfs = s1.button and s1.button.GetFontString and s1.button:GetFontString()
            if bfs then
                local path, sz, flags = bfs:GetFont()
                if path and sz then
                    local bd = GetFFD(bfs)
                    if not bd.size then bd.size = sz - 2 end
                    if math.abs(sz - bd.size) > 0.01 then bfs:SetFont(path, bd.size, flags) end
                end
            end
        end
    end
    RefreshSuggest()

    -- Traveler's Log: seat the info (help) button on the window's left edge,
    -- keeping its vertical spot. Anchored to the WINDOW, not the inset activities
    -- pane (its left edge is not the window's). Retries until laid out.
    local function SeatMonthlyHelp()
        local ma = f.MonthlyActivitiesFrame
        local hb = ma and ma.HelpButton
        if not hb or GetFFD(hb).moved then return end
        local top, fTop = hb:GetTop(), f:GetTop()
        if top and fTop then
            GetFFD(hb).moved = true
            hb:ClearAllPoints()
            hb:SetPoint("TOPLEFT", f, "TOPLEFT", 4, top - fTop)
        end
    end
    SeatMonthlyHelp()

    -- Boss detail "book": strip parchment, flatten rows, white the text.
    local function RefreshDetail()
        local e = f.encounter
        if not e then return end
        if _G.EncounterJournalEncounterFrameInfoBG then _G.EncounterJournalEncounterFrameInfoBG:SetAlpha(0) end
        local info = e.info
        if info then
            for _, k in ipairs({ "leftShadow", "rightShadow", "titleBG" }) do
                local t = info[k]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            -- Model tab: scene backdrop + vignette re-texture per encounter, so re-fade each pass.
            for _, n in ipairs({ "EncounterJournalEncounterFrameInfoModelFrameDungeonBG",
                                 "EncounterJournalEncounterFrameInfoModelFrameShadow" }) do
                local t = _G[n]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            local lc = info.LootContainer
            if lc then
                for _, k in ipairs({ "bossTexture", "bosslessTexture" }) do
                    local t = lc[k]
                    if t and t.SetAlpha then t:SetAlpha(0) end
                end
                FlattenLootRows(lc)
                -- Pooled rows: scrolling realizes/re-inits frames via paths that
                -- fire no journal repaint, bringing Blizzard's art back on
                -- scroll-up. Re-skin realized rows on every ScrollBox update (cost scales with visible rows only).
                local sb = lc.ScrollBox
                if sb and sb.ForEachFrame then
                    pcall(sb.ForEachFrame, sb, SkinLootRow)
                    if sb.Update and not GetFFD(sb).rowHook then
                        GetFFD(sb).rowHook = true
                        hooksecurefunc(sb, "Update", function(box)
                            pcall(box.ForEachFrame, box, SkinLootRow)
                        end)
                    end
                end
                -- Gear tab filters: house arrows hugging the label text.
                SwapFilterArrow(lc.filter)
                SwapFilterArrow(lc.slotFilter)
            end
            local sideTabs = { "overviewTab", "lootTab", "bossTab", "modelTab" }
            for i = 1, #sideTabs do
                SkinSideTab(info[sideTabs[i]], i)
            end
            -- Vertical divider down the center of the detail view. The info
            -- frame spans the whole detail area (boss list lives INSIDE it),
            -- so the true split is the boss list's right edge.
            local ed = GetFFD(info)
            local bossList = info.BossesScrollBox
            if bossList and not ed.centerDivider then
                local div = info:CreateTexture(nil, "ARTWORK")
                div:SetColorTexture(1, 1, 1, 0.15)
                div:SetWidth(1)
                div:SetPoint("TOPLEFT", bossList, "TOPRIGHT", 24, 8)
                div:SetPoint("BOTTOMLEFT", bossList, "BOTTOMRIGHT", 24, 12)
                ed.centerDivider = div
            end
            if info.overviewScroll and info.overviewScroll.child and info.overviewScroll.child.header
               and info.overviewScroll.child.header.SetAlpha then
                info.overviewScroll.child.header:SetAlpha(0)
            end
        end
        if e.instance and e.instance.titleBG and e.instance.titleBG.SetAlpha then
            e.instance.titleBG:SetAlpha(0)
        end
        SkinAbilityHeaders(e)
        FadeEJArt(e)
        FlattenBossButtons(e)
        SkinCreatureButtons()
        WhitenTextIn(e)
    end
    RefreshDetail()

    FadeEJArt(f)
    WSkin.ButtonsIn(f)
    WSkin.ScrollBarsIn(f)
    WSkin.FadeKeyedArt(f)

    -- Blizzard repopulates the detail panes on navigation; the hooks fire many
    -- times per click, so the pass is debounced and skipped while hidden.
    if not _ejHooked then
        _ejHooked = true
        local refresh = WSkin.Debounce(function()
            if not f:IsVisible() then return end
            RefreshDetail()
            RefreshNav()
            if f.instanceSelect then
                FlattenInstanceButtons(f.instanceSelect)
                RestyleGreatVaultButton(f.instanceSelect.GreatVaultButton)
                RestyleInstanceScene(f.instanceSelect)
            end
            SeatMonthlyHelp()
            WSkin.Restrip()
        end)
        local function deferRefresh()
            -- Kill the biggest parchment synchronously so it cannot flash a
            -- frame before the debounced pass runs.
            if _G.EncounterJournalEncounterFrameInfoBG then _G.EncounterJournalEncounterFrameInfoBG:SetAlpha(0) end
            refresh()
        end
        for _, fn in ipairs({ "EncounterJournal_DisplayInstance", "EncounterJournal_DisplayEncounter",
                              "EncounterJournal_SetUpOverview", "EncounterJournal_ToggleHeaders",
                              "EncounterJournal_SetTab", "EJ_ContentTab_Select", "NavBar_AddButton" }) do
            if type(_G[fn]) == "function" then hooksecurefunc(fn, deferRefresh) end
        end
        -- The debounced pass runs a frame late, so a new crumb would render one
        -- frame at Blizzard's layout (a visible snap). Reflow the nav
        -- synchronously the moment a crumb is added; cheap (a handful of buttons).
        if type(_G.NavBar_AddButton) == "function" then
            hooksecurefunc("NavBar_AddButton", function(bar)
                if bar == nav then RefreshNav() end
            end)
        end
        if type(_G.EJSuggestFrame_RefreshDisplay) == "function" then
            hooksecurefunc("EJSuggestFrame_RefreshDisplay", WSkin.Debounce(RefreshSuggest))
        end
        -- Global Options edits (link color) re-run the text passes live.
        WSkin.OnLooksChanged(function()
            if f:IsVisible() then
                deferRefresh()
                RefreshSuggest()
            end
        end)
    end

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then
            RefreshDetail()
            RefreshNav()
            if f.instanceSelect then
                RestyleGreatVaultButton(f.instanceSelect.GreatVaultButton)
                RestyleInstanceScene(f.instanceSelect)
            end
            WSkin.Restrip()
            WSkin.UpdateAllTabs()
        end
    end))
end

WSkin.RegisterWindow({
    key = "adventureguide",
    addons = { Blizzard_EncounterJournal = true },
    apply = Skin_EncounterJournal,
})
end

-------------------------------------------------------------------------------
--  Professions Book (ProfessionsBookFrame)
-------------------------------------------------------------------------------
do
local PROF_FRAMES = { "PrimaryProfession1", "PrimaryProfession2",
                      "SecondaryProfession1", "SecondaryProfession2", "SecondaryProfession3" }

-- Settle gate: Shifter applies the user's scale on OnShow AFTER the book has
-- shown, so content reflows across several passes on a scaled reopen; text
-- seating run mid-reflow nudges strings from a transient baseline and the
-- correction stacks (text flung 60-70px off). Seat ONLY when the content
-- geometry signature matches the prior pass; while moving, skip and schedule one trailing pass.
local _profSettleSig, _profSettlePending
local function ProfContentSig()
    local sig = 0
    for _, n in ipairs(PROF_FRAMES) do
        local fr = _G[n]
        if fr then
            local t = fr.GetTop and fr:GetTop()
            local sb = fr.statusBar
            local bt = sb and sb.GetTop and sb:GetTop()
            sig = sig + (t or 0) * 7 + (bt or 0) * 13
        end
    end
    return sig
end

local function SkinProfSpellButton(b)
    if not b then return end
    local bn = b.GetName and b:GetName()
    if bn then
        local nf = _G[bn .. "NameFrame"]
        if nf and nf.SetAlpha then nf:SetAlpha(0) end
    end
    for _, k in ipairs({ "Border", "FlyoutBorder", "FlyoutBorderShadow", "Background", "Flash" }) do
        local t = b[k]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    local nt = b.GetNormalTexture and b:GetNormalTexture()
    if nt and nt.SetAlpha then nt:SetAlpha(0) end
    local icon = b.IconTexture or (bn and _G[bn .. "IconTexture"])
    if icon then WSkin.SquareIcon(icon, b) end
    if b.spellString then WSkin.Font(b.spellString); WSkin.White(b.spellString) end
    if b.subSpellString then WSkin.Font(b.subSpellString); WSkin.White(b.subSpellString, 0.8, 0.8, 0.8) end
end

local function SkinProfStatusBar(sb)
    if not sb then return end
    local n = sb.GetName and sb:GetName()
    if n then
        for _, suf in ipairs({ "Left", "Right", "BGLeft", "BGMiddle", "BGRight" }) do
            local t = _G[n .. suf]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
    end
    if sb.capRight and sb.capRight.SetAlpha then sb.capRight:SetAlpha(0) end
    if sb.SetStatusBarTexture then
        sb:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
        WSkin.ApplyBarFill(sb)
    end
    local d = GetFFD(sb)
    -- Blizzard's bar VISUAL (cap + middle + cap art) is wider than the StatusBar
    -- frame, so the flat fill reads short and skews text anchored around it.
    -- Stretch the frame to the art's measured span, but ONLY when the art sits
    -- a plausible cap-width (<= 20px) away: a bigger delta means a different
    -- row layout (secondary rows), and moving the bar would yank those off their tiles.
    if not d.stretched and n and not InCombatLockdown() then
        local bgl, bgr = _G[n .. "BGLeft"], _G[n .. "BGRight"]
        local L = bgl and bgl.GetLeft and bgl:GetLeft()
        local R = bgr and bgr.GetRight and bgr:GetRight()
        local sL = sb.GetLeft and sb:GetLeft()
        if L and R and sL and R > L then
            d.stretched = true
            local delta = L - sL
            if math.abs(delta) <= 20 then
                local p, rel, rp, x, y = sb:GetPoint(1)
                if p and p:find("LEFT", 1, true) then
                    sb:ClearAllPoints()
                    sb:SetPoint(p, rel, rp, (x or 0) + delta, y or 0)
                end
                sb:SetWidth(R - L)
            end
        end
    end
    if not d.bg then
        local bg = sb:CreateTexture(nil, "BACKGROUND", nil, -1)
        bg:SetColorTexture(0.12, 0.12, 0.12, 0.85)
        bg:SetAllPoints(sb)
        d.bg = bg
        WSkin.AddBorder(sb)
    end
    if sb.rankText then
        WSkin.Font(sb.rankText)
        WSkin.White(sb.rankText)
        -- 3px lower (one-shot).
        local rd = GetFFD(sb.rankText)
        if not rd.lowered then
            local p, rel, rp, x, y = sb.rankText:GetPoint(1)
            if p then
                rd.lowered = true
                sb.rankText:ClearAllPoints()
                sb.rankText:SetPoint(p, rel, rp, x or 0, (y or 0) - 3)
            end
        end
    end
end

local function RecolorProfessions()
    -- Profession frames chain to each other; a chained frame inherits the shift
    -- of the frame it hangs from, so only chain roots get the x offset
    -- (shifting every frame would compound 30px per row down the chain).
    local profSet = {}
    for _, n in ipairs(PROF_FRAMES) do
        local fr = _G[n]
        if fr then profSet[fr] = true end
    end
    -- Text seating runs only on a settled layout (signature matches prior pass);
    -- while reflowing (Shifter-scaled reopen) skip and queue one trailing pass.
    -- The one-shot geometry below is idempotent and runs every pass; only the
    -- delta-nudge seating is gated.
    local sig = ProfContentSig()
    local seatOK = (_profSettleSig ~= nil) and (math.abs(sig - _profSettleSig) <= 0.5)
    _profSettleSig = sig
    if not seatOK and not _profSettlePending then
        _profSettlePending = true
        C_Timer.After(0.05, function()
            _profSettlePending = false
            local pf = _G.ProfessionsBookFrame
            if pf and pf:IsVisible() then RecolorProfessions() end
        end)
    end
    for _, n in ipairs(PROF_FRAMES) do
        local fr = _G[n]
        if fr then
            -- Content reaches 30px further left, right edge unchanged (one-shot;
            -- left-anchored roots shift+widen, right-anchored just widen
            -- leftward). Row frames are PROTECTED (host secure profession spell
            -- buttons), so combat blocks geometry writes: skip WITHOUT setting
            -- the one-shot flag, letting the next OOC repaint apply it.
            local gd = GetFFD(fr)
            if not gd.extended and not InCombatLockdown() then
                local p, rel, rp, x, y = fr:GetPoint(1)
                local w = fr:GetWidth()
                if p and w and w > 0 then
                    gd.extended = true
                    if p:find("LEFT", 1, true) and not profSet[rel] then
                        fr:ClearAllPoints()
                        fr:SetPoint(p, rel, rp, (x or 0) - 30, y or 0)
                    end
                    fr:SetWidth(w + 30)
                    -- Rects are stale right after re-anchor; let text alignment below measure on the NEXT pass.
                    gd.skipAlignOnce = true
                end
            end
            -- Primary tiles: big left icon 12px smaller, seated 10px lower
            -- (one-shot; border lines follow its rect). Secondary: icon 2px smaller.
            local isPrimary = n:find("Primary", 1, true) ~= nil
            if fr.icon and not gd.iconAdj then
                local iw, ih = fr.icon:GetSize()
                if iw and ih and iw > 12 and ih > 12 then
                    gd.iconAdj = true
                    local shrink = isPrimary and 12 or 2
                    fr.icon:SetSize(iw - shrink, ih - shrink)
                    if isPrimary then
                        local p, rel, rp, x, y = fr.icon:GetPoint(1)
                        if p then
                            fr.icon:ClearAllPoints()
                            fr.icon:SetPoint(p, rel, rp, x or 0, (y or 0) - 10)
                        end
                    end
                end
            end
            -- Bar cluster rises 20px on learned primaries to close the gap the
            -- title drop opens. MUST run before text seating, or a bar-anchored
            -- skill line double-shifts (targets need post-raise geometry).
            SkinProfStatusBar(fr.statusBar, isPrimary and 20 or 0)
            if isPrimary then
                local ub = fr.unlearn or fr.UnlearnButton or _G[n .. "Unlearn"] or _G[n .. "UnlearnButton"]
                if ub and not GetFFD(ub).raised and not InCombatLockdown() then
                    local p, rel, rp, x, y = ub:GetPoint(1)
                    if p then
                        GetFFD(ub).raised = true
                        if rel ~= fr.statusBar and rel ~= fr.rank then
                            ub:ClearAllPoints()
                            ub:SetPoint(p, rel, rp, x or 0, (y or 0) + 20)
                        end
                    end
                end
            end
            -- Text seating re-runs every pass since Blizzard re-anchors these
            -- strings (one-shots get stomped): delta-based against measured
            -- targets (bar-left for x, captured top minus drop for y), so an
            -- already-seated string is a no-op. Learned primary titles drop 20px;
            -- unlearned header stays put (else a blank band opens above "Second
            -- Profession"); skill line rises 20 only when off the bar.
            if gd.skipAlignOnce then
                gd.skipAlignOnce = nil
            elseif seatOK then
                local sbL = fr.statusBar and fr.statusBar.GetLeft and fr.statusBar:GetLeft()
                -- Y target is a gap from the FRAME top, never absolute local-Y:
                -- GetTop deltas are scale-invariant since a frame and its strings
                -- share one effective scale, but local-Y shifts with scale and
                -- would fling every string ~300px on a scale change + reopen.
                local frameTop = fr.GetTop and fr:GetTop()
                if sbL and frameTop then
                    local rankRel = fr.rank and fr.rank.GetPoint and select(2, fr.rank:GetPoint(1))
                    -- Anything the BAR hangs from (directly or up its chain) must
                    -- NOT be aligned TO the bar: moving such a string drags the bar
                    -- with it and the cluster creeps 1px left per open.
                    local barChain = {}
                    do
                        local node = fr.statusBar
                        for _ = 1, 4 do
                            if not (node and node.GetPoint) then break end
                            local _, rel2 = node:GetPoint(1)
                            if not rel2 then break end
                            barChain[rel2] = true
                            node = rel2
                        end
                    end
                    local strings = {
                        { fs = fr.professionName, alignX = true,  drop = isPrimary and 20 or 0 },
                        { fs = fr.rank,           alignX = true,
                          drop = (isPrimary and rankRel ~= fr.statusBar) and -20 or 0 },
                        { fs = fr.missingHeader,  alignX = false, drop = 0 },
                    }
                    for _, s in ipairs(strings) do
                        local fs = s.fs
                        if fs and fs.GetLeft then
                            local l, t = fs:GetLeft(), fs:GetTop()
                            if l and t then
                                local td = GetFFD(fs)
                                -- Title capture sanity: the profession name always
                                -- sits ABOVE its bar, so a mid-relayout capture
                                -- (name at/below bar) would lock a bogus gap.
                                -- Skip until a settled pass measures it above.
                                if fs == fr.professionName and td.gapTop == nil
                                    and fr.statusBar and fr.statusBar.GetTop then
                                    local barTop = fr.statusBar:GetTop()
                                    if barTop and t <= barTop then
                                        l = nil -- stale measure; skip this pass
                                    end
                                end
                                -- Capture the default gap from the frame top
                                -- once, then drive to frameTop + gap - drop.
                                if l and td.gapTop == nil then td.gapTop = t - frameTop end
                                local targetTop = td.gapTop and (frameTop + td.gapTop - s.drop)
                                if l and targetTop then
                                    -- WHOLE pixels only: rects are quantized but point
                                    -- offsets are continuous, so a fractional residual
                                    -- re-measures every pass and creeps the cluster ~1px left per open.
                                    local wantX = s.alignX and not barChain[fs]
                                    local dx = math.floor((wantX and (sbL - l) or 0) + 0.5)
                                    local dy = math.floor((targetTop - t) + 0.5)
                                    if dx ~= 0 or dy ~= 0 then
                                        local p, rel, rp, x, y = fs:GetPoint(1)
                                        if p then
                                            fs:ClearAllPoints()
                                            fs:SetPoint(p, rel, rp, (x or 0) + dx, (y or 0) + dy)
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            -- Tile backdrop: dialog sheet art at half strength, padded past the
            -- frame so content never crowds the card edges. Top pad stays SMALL,
            -- else a tall card overlaps the row above and cuts a seam through it.
            if not gd.bg then
                local bg = fr:CreateTexture(nil, "BACKGROUND", nil, -6)
                bg:SetAtlas("Ui-Dialog-New-Background")
                -- Primary tiles are taller than content: pinched card with bottom
                -- pulled up (bar cluster rides 20px higher) keeps a visible gap
                -- between the two primary cards. Secondary rows get 6px extra height above/below.
                local topY = isPrimary and -4 or 10
                local botY = isPrimary and 6 or -16
                bg:SetPoint("TOPLEFT", fr, "TOPLEFT", -16, topY)
                bg:SetPoint("BOTTOMRIGHT", fr, "BOTTOMRIGHT", 16, botY)
                bg:SetAlpha(0.5)
                gd.bg = bg
                gd.bgBottomY = botY
            end
            -- Secondary rows lay rank bar BELOW the frame's rect; drop the card bottom under it once geometry is readable.
            if gd.bg and not gd.bgFit then
                local fb = fr.GetBottom and fr:GetBottom()
                local bb = fr.statusBar and fr.statusBar.GetBottom and fr.statusBar:GetBottom()
                if fb then
                    gd.bgFit = true
                    if bb and bb < fb then
                        gd.bg:SetPoint("BOTTOMRIGHT", fr, "BOTTOMRIGHT", 16, (bb - fb) - 16)
                    end
                end
            end
            if fr.professionName then WSkin.Font(fr.professionName); WSkin.White(fr.professionName) end
            if fr.missingHeader then WSkin.Font(fr.missingHeader); WSkin.White(fr.missingHeader) end
            if fr.rank then WSkin.Font(fr.rank); WSkin.White(fr.rank) end
            if fr.missingText then WSkin.Font(fr.missingText); WSkin.White(fr.missingText) end

            local ib = _G[n .. "IconBorder"]
            if ib and ib.SetAlpha then ib:SetAlpha(0) end
            if fr.icon then
                if fr.CircleMask and fr.icon.RemoveMaskTexture then
                    pcall(fr.icon.RemoveMaskTexture, fr.icon, fr.CircleMask)
                end
                if fr.icon.SetBlendMode then fr.icon:SetBlendMode("BLEND") end
                if fr.icon.SetDesaturated then fr.icon:SetDesaturated(false) end
                WSkin.SquareIcon(fr.icon, fr)
            end

            SkinProfSpellButton(fr.SpellButton1)
            SkinProfSpellButton(fr.SpellButton2)
        end
    end

    -- Both primary cards render at the same height: once both are measurable the shorter one's bottom extends by the difference (one-shot).
    local p1, p2 = _G.PrimaryProfession1, _G.PrimaryProfession2
    local d1, d2 = p1 and FFD[p1], p2 and FFD[p2]
    if d1 and d2 and d1.bg and d2.bg and not d1.eqDone then
        local h1, h2 = d1.bg:GetHeight(), d2.bg:GetHeight()
        if h1 and h2 and h1 > 0 and h2 > 0 then
            d1.eqDone = true
            if math.abs(h1 - h2) > 0.5 then
                local sd = (h1 < h2) and d1 or d2
                local sf = (h1 < h2) and p1 or p2
                -- Never extend past 2px below the frame: an uncapped match
                -- runs the card into the next tile and eats the gap.
                sd.bg:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", 16,
                    math.max((sd.bgBottomY or 6) - math.abs(h1 - h2), -2))
            end
        end
    end
end

local _profHook = false
local function Skin_ProfessionsBook()
    local f = _G.ProfessionsBookFrame
    if not f then return end
    WSkin.Shell("professionsbook", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.ProfessionsBookFrameBg then _G.ProfessionsBookFrameBg:SetAlpha(0) end
    for _, n in ipairs({ "ProfessionsBookPage1", "ProfessionsBookPage2" }) do
        local p = _G[n]
        if p and p.GetObjectType then
            if p:GetObjectType() == "Texture" then p:SetAlpha(0) else WSkin.FadeRegions(p) end
        end
    end
    for _, k in ipairs({ "Inset", "RightInset", "LeftInset" }) do
        if f[k] then WSkin.Inset(f[k]) end
    end
    WSkin.FadeKeyedArt(f)

    -- Info (help plate) button: seat on the window's left edge keeping its
    -- vertical spot (as with the Adventure Guide Traveler's Log). No parent
    -- key, found by its help-i art; retries until laid out.
    local function SeatProfHelp(host, depth)
        host = host or f
        depth = depth or 0
        if depth > 3 or not host.GetChildren then return end
        local children = { host:GetChildren() }
        for i = 1, #children do
            local c = children[i]
            if c and not WSkin.IsForeignFrame(c, host) and c.GetObjectType and c:GetObjectType() == "Button" then
                if not GetFFD(c).moved then
                    local nt = c.GetNormalTexture and c:GetNormalTexture()
                    local hay = nt and WSkin.TexHay(nt)
                    if hay and hay:find("help-i", 1, true) then
                        local top, fTop = c:GetTop(), f:GetTop()
                        if top and fTop then
                            GetFFD(c).moved = true
                            c:ClearAllPoints()
                            c:SetPoint("TOPLEFT", f, "TOPLEFT", 4, top - fTop)
                        end
                    end
                end
            elseif c then
                SeatProfHelp(c, depth + 1)
            end
        end
    end
    SeatProfHelp()

    RecolorProfessions()
    if not _profHook and type(_G.ProfessionsBookFrame_Update) == "function" then
        _profHook = true
        hooksecurefunc("ProfessionsBookFrame_Update", WSkin.Debounce(function()
            if f:IsVisible() then RecolorProfessions() end
        end))
    end

    WSkin.ButtonsIn(f)
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then RecolorProfessions(); SeatProfHelp(); WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "professionsbook",
    addons = { Blizzard_ProfessionsBook = true },
    apply = Skin_ProfessionsBook,
})
end

-------------------------------------------------------------------------------
--  Archaeology (ArchaeologyFrame). Opened from the professions book, so it
--  rides the professionsbook style key.
-------------------------------------------------------------------------------
do
local function Skin_Archaeology()
    local f = _G.ArchaeologyFrame
    if not f then return end
    WSkin.Shell("professionsbook", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.ArchaeologyFrameNineSlice then
        WSkin.FadeNineSlice(_G.ArchaeologyFrameNineSlice)
    end
    for _, g in ipairs({ "ArchaeologyFrameBg", "ArchaeologyFrameBgLeft",
                         "ArchaeologyFrameBgRight", "ArchaeologyFrameInset",
                         "ArchaeologyFrameportrait", "ArchaeologyFramePortrait" }) do
        local t = _G[g]
        if t then
            if t.IsObjectType and t:IsObjectType("Texture") then
                t:SetAlpha(0)
            elseif t.GetObjectType then
                if t.NineSlice then WSkin.FadeNineSlice(t.NineSlice) end
                WSkin.FadeRegions(t)
                WSkin.Register(t, true)
            end
        end
    end
    -- Old-template art lives all over the child tree: keyed bg pieces + keyword art (parchment/corner/frametexture family) both swept.
    WSkin.FadeKeyedArt(f)
    WSkin.FadeArtIn(f)
    -- Direct fontstrings go white (color-only; this is a profession-specific window, not the font-exempt book).
    WhitenTextIn(f)
    if f.CloseButton then WSkin.CloseButton(f.CloseButton) end
    if f.raceFilterDropdown then WSkin.Dropdown(f.raceFilterDropdown) end
    if f.RaceFilterDropdown then WSkin.Dropdown(f.RaceFilterDropdown) end
    for _, k in ipairs({ "summaryPage", "SummaryPage", "artifactPage",
                         "ArtifactPage", "completedPage", "CompletedPage",
                         "helpPage", "HelpPage" }) do
        local pg = f[k]
        if pg then
            WSkin.FadeKeyedArt(pg)
            WhitenTextIn(pg)
        end
    end
    -- Help page scroll text lives a level deeper than the page sweeps.
    local helpText = _G.ArchaeologyFrameHelpPageHelpScrollHelpText
    if helpText and helpText.SetTextColor then WSkin.White(helpText) end
    for _, base in ipairs({ "ArchaeologyFrameSummaryPage", "ArchaeologyFrameCompletedPage" }) do
        for suffix, ch in pairs({ PrevPageButton = "<", NextPageButton = ">" }) do
            local pb = _G[base .. suffix]
            if pb then
                WSkin.PageButton(pb, ch)
                -- These old buttons repaint arrow art on every state change:
                -- sweep all non-house art per repaint and clamp the icon's alpha
                -- against Blizzard's re-raises.
                local ic = _G[base .. suffix .. "Icon"]
                local function SweepArrowArt()
                    if ic and ic.SetAlpha then ic:SetAlpha(0) end
                    -- Spare OUR pieces by identity: the arrow path resolves to a fileID later, so name matching is unreliable.
                    local own = GetFFD(pb)
                    local regions = { pb:GetRegions() }
                    for i = 1, #regions do
                        local r = regions[i]
                        if r and r ~= own.arrow and r ~= own.bg and r ~= own.hover
                            and r.IsObjectType and r:IsObjectType("Texture")
                            and r:GetDrawLayer() ~= "HIGHLIGHT" then
                            r:SetAlpha(0)
                        end
                    end
                end
                SweepArrowArt()
                local pd = GetFFD(pb)
                if not pd.arrowHooks then
                    pd.arrowHooks = true
                    local function Deferred()
                        if C_Timer then
                            C_Timer.After(0, SweepArrowArt)
                        else
                            SweepArrowArt()
                        end
                    end
                    pb:HookScript("OnClick", Deferred)
                    pb:HookScript("OnEnable", Deferred)
                    pb:HookScript("OnDisable", Deferred)
                    pb:HookScript("OnShow", Deferred)
                    if ic and ic.SetAlpha then
                        hooksecurefunc(ic, "SetAlpha", function(_, a)
                            if pd.inIcAlpha then return end
                            if a and not issecretvalue(a) and a > 0 then
                                pd.inIcAlpha = true
                                ic:SetAlpha(0)
                                pd.inIcAlpha = false
                            end
                        end)
                    end
                end
            end
        end
    end
    -- Skill/rank bar -> full house bar: chrome uses its own names (Background/
    -- Border + anonymous pieces), so fade everything but the fill, flatten it, and seat the house trough+border.
    local arb = f.rankBar or f.RankBar or _G.ArchaeologyFrameRankBar
    if arb then
        local abd = GetFFD(arb)
        for _, g in ipairs({ "ArchaeologyFrameRankBarBackground",
                             "ArchaeologyFrameRankBarBorder" }) do
            local t = _G[g]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local fill = arb.GetStatusBarTexture and arb:GetStatusBarTexture()
        local regions = { arb:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r ~= fill and r ~= abd.bg and r.IsObjectType
                and r:IsObjectType("Texture")
                and r:GetDrawLayer() ~= "HIGHLIGHT" then
                r:SetAlpha(0)
            end
        end
        if arb.SetStatusBarTexture then
            arb:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            WSkin.ApplyBarFill(arb)
        end
        if not abd.bg then
            local trough = arb:CreateTexture(nil, "BACKGROUND", nil, -1)
            trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
            trough:SetAllPoints(arb)
            abd.bg = trough
            WSkin.BorderRegion(arb, trough)
        end
        local regions2 = { arb:GetRegions() }
        for i = 1, #regions2 do
            local r = regions2[i]
            if r and r.IsObjectType and r:IsObjectType("FontString") then
                WSkin.White(r)
            end
        end
    end
    WSkin.ScrollBarsIn(f)
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "professionsbook",
    addons = { Blizzard_ArchaeologyUI = true },
    apply = Skin_Archaeology,
})
end

-------------------------------------------------------------------------------
--  Guild & Communities (CommunitiesFrame)
-------------------------------------------------------------------------------
-- Custom themed checkbox: Blizzard's atlas check art on these templates resists
-- the generic checkbox skin, so every texture region is cleared and a 14px
-- bordered box with an accent tick draws instead, whitening 10% on hover/check.
local function SkinGuildCheck(cb)
    if not cb or cb:IsForbidden() then return end
    local d = GetFFD(cb)
    if d.custom then return end
    d.custom = true
    local regions = { cb:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("Texture") and r.SetTexture then
            r:SetTexture("")
        end
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture",
                         "GetCheckedTexture", "GetDisabledCheckedTexture" }) do
        local t = cb[g] and cb[g](cb)
        if t and t.SetTexture then t:SetTexture("") end
    end
    local boxF = CreateFrame("Frame", nil, cb)
    boxF:SetSize(14, 14)
    boxF:SetPoint("LEFT", cb, "LEFT", 4, 0)
    local fill = SolidTex(boxF, "BACKGROUND", 0.02, 0.02, 0.02, 1)
    fill:SetAllPoints(boxF)
    WSkin.AddBorder(boxF, 0.25, 0.25, 0.25, 1)
    local EG2 = EllesmereUI.ELLESMERE_GREEN or { r = 0.047, g = 0.824, b = 0.616 }
    local tick = boxF:CreateTexture(nil, "OVERLAY")
    tick:SetPoint("TOPLEFT", 3, -3)
    tick:SetPoint("BOTTOMRIGHT", -3, 3)
    tick:SetColorTexture(EG2.r or 0.047, EG2.g or 0.824, EG2.b or 0.616, 1)
    local wash = SolidTex(boxF, "ARTWORK", 1, 1, 1, 0.1)
    wash:SetAllPoints(boxF)
    wash:Hide()
    local hovering = false
    local function updState()
        local checked = cb:GetChecked() and true or false
        tick:SetShown(checked)
        wash:SetShown(hovering or checked)
    end
    cb:HookScript("OnEnter", function() hovering = true; updState() end)
    cb:HookScript("OnLeave", function() hovering = false; updState() end)
    cb:HookScript("OnClick", updState)
    hooksecurefunc(cb, "SetChecked", updState)
    updState()
    local lbl = cb.Text or (cb.GetFontString and cb:GetFontString())
    if lbl then WSkin.White(lbl) end
end

-- Side tab (Chat/Roster/Benefits/Info): square the icon, drop the gold ring.
local function SquareTabIcon(tab)
    if not tab then return end
    local d = GetFFD(tab)
    local icon = tab.Icon
    local overlay = tab.IconOverlay
    if icon then
        WSkin.SquareIcon(icon)
        if icon.SetDrawLayer then icon:SetDrawLayer("ARTWORK") end
    end
    if tab.GetRegions then
        local regions = { tab:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r ~= icon and r ~= overlay and r ~= d.hover and r.IsObjectType
               and r:IsObjectType("Texture") and r.SetAlpha then
                r:SetAlpha(0)
            end
        end
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetCheckedTexture", "GetHighlightTexture" }) do
        local fn = tab[g]; local t = fn and fn(tab)
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
end

-- Guild dialog popouts (member detail, request-to-join): chrome lives in child
-- FRAMES ("BG"/"Border" wrappers holding the bg + nine-slice), invisible to
-- the keyed art sweeps, so flatten to a house panel.
local function ApplyGuildPopup(pop, d)
    WSkin.FadeRegions(pop, d.bg and { [d.bg] = true })
    if pop.NineSlice then WSkin.FadeNineSlice(pop.NineSlice) end
    for _, k in ipairs({ "BG", "Border" }) do
        local piece = pop[k]
        if piece then
            if piece.IsObjectType and piece:IsObjectType("Texture") then
                piece:SetAlpha(0)
            else
                WSkin.FadeRegions(piece)
                if piece.NineSlice then WSkin.FadeNineSlice(piece.NineSlice) end
                WSkin.Register(piece, true)
            end
        end
    end
    local bg = d.bg
    if not bg then
        bg = pop:CreateTexture(nil, "BACKGROUND", nil, -6)
        d.bg = bg
    end
    bg:SetColorTexture(0.05, 0.05, 0.05, 0.95)
    bg:SetAllPoints(pop)
    WSkin.AddBorder(pop)
    WSkin.Register(pop, true)
    if pop.CloseButton then WSkin.CloseButton(pop.CloseButton) end
    -- The member detail popup's name and rank are player and guild writing: a
    -- font family.
    local regions = { pop:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("FontString") then
            if r == pop.Name or r == pop.RankText then WSkin.FontFamily(r) else WSkin.Font(r) end
            WSkin.White(r)
        end
    end
end

local function SkinGuildPopup(pop)
    -- Some same-named globals are functions until their dialog exists.
    if type(pop) ~= "table" or not pop.IsForbidden or pop:IsForbidden() then return end
    WSkin.CompleteSetup(pop, "popupSkinned", ApplyGuildPopup)
end

do
-- Max/Min glyph matching the transmog / dressing-room look: quest-tracker
-- collapse/expand chevron (up = maximize/Expand, down = minimize/Collapse),
-- desaturated white at 0.75, brightening on hover.
local function CaretGlyph(btn, up)
    if not btn then return end
    local atlas = up and "UI-QuestTrackerButton-Secondary-Expand"
                      or "UI-QuestTrackerButton-Secondary-Collapse"
    if not (C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas)) then return end
    local d = GetFFD(btn)
    -- The glyph is a texture region on the button itself: keep it out of the
    -- region fade on re-runs.
    WSkin.FadeRegions(btn, d.caret and { [d.caret] = true } or nil)
    for _, m in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
        local t = btn[m] and btn[m](btn)
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    if not d.caret then
        local t = btn:CreateTexture(nil, "OVERLAY")
        t:SetAtlas(atlas, false)
        t:SetSize(16, 16)
        t:SetPoint("CENTER", -2, 0)
        t:SetDesaturated(true)
        t:SetVertexColor(1, 1, 1, 0.75)
        d.caret = t
        btn:HookScript("OnEnter", function() t:SetVertexColor(1, 1, 1, 1) end)
        btn:HookScript("OnLeave", function() t:SetVertexColor(1, 1, 1, 0.75) end)
    end
end

-- Community list entry: flat block + accent selection. Blizzard repaints the
-- entry background per type, so this re-runs from the list update hook.
local function SkinCommunityEntry(entry)
    if not entry then return end
    -- Each entry reads as a defined tile: the professions tiles' dialog-sheet
    -- card art at half strength, pulled in 2px top/bottom so neighbours never
    -- sit flush. Selection + hover washes clamp to the same card rect (native
    -- regions run past it). `extra` = extra inset for the flat washes, since
    -- the card atlas bakes in soft edges and a wash on the same rect reads
    -- bigger than the visible art.
    local function CardRect(tex, extra)
        extra = extra or 0
        tex:ClearAllPoints()
        tex:SetPoint("TOPLEFT", entry, "TOPLEFT", extra, -2 - extra)
        tex:SetPoint("BOTTOMRIGHT", entry, "BOTTOMRIGHT", -extra, 2 + extra)
    end
    if entry.Background and entry.Background.SetAtlas then
        local tex = entry.Background
        local bgd = GetFFD(tex)
        -- Self-guarding card: Blizzard re-sets this texture per entry type
        -- from several paths, and pooled entries carry mixin COPIES so mixin
        -- table hooks miss them. Post-hooks on the TEXTURE OBJECT re-assert
        -- the card synchronously against every caller.
        if not bgd.guard then
            bgd.guard = true
            local function reapply()
                if bgd.inSet then return end
                bgd.inSet = true
                tex:SetAtlas("Ui-Dialog-New-Background")
                tex:SetTexCoord(0, 1, 0, 1)
                tex:SetVertexColor(1, 1, 1, 1)
                tex:SetAlpha(0.5)
                bgd.inSet = false
            end
            bgd.reapply = reapply
            hooksecurefunc(tex, "SetAtlas", reapply)
            hooksecurefunc(tex, "SetTexture", reapply)
            hooksecurefunc(tex, "SetAlpha", reapply)
        end
        bgd.reapply()
        CardRect(tex)
    end
    -- Selected entry = the same subtle white wash as hover: never accent, and
    -- no brighter than hovering.
    if entry.Selection and entry.Selection.SetTexture then
        entry.Selection:SetTexture("Interface\\Buttons\\WHITE8X8")
        entry.Selection:SetVertexColor(1, 1, 1, 0.05)
        entry.Selection:SetTexCoord(0, 1, 0, 1)
        CardRect(entry.Selection, 3)
    end
    if entry.IconRing and entry.IconRing.SetAlpha then entry.IconRing:SetAlpha(0) end
    local hl = entry.GetHighlightTexture and entry:GetHighlightTexture()
    if hl and hl.SetTexture then
        hl:SetTexture("Interface\\Buttons\\WHITE8X8")
        hl:SetVertexColor(1, 1, 1, 0.05)
        hl:SetTexCoord(0, 1, 0, 1)
        CardRect(hl, 3)
    end
end

-- Popup inputs get 6px of left padding: the BOX edge moves left (left-edge
-- anchors shift, or centered fixed-width boxes widen +6 and recenter), with a
-- matching text inset so the text's on-screen start is unchanged.
local function PadPopupInput(eb)
    if not eb or not eb.GetNumPoints then return end
    local d = GetFFD(eb)
    if d.padLeft then return end
    local np = eb:GetNumPoints() or 0
    if np == 0 then return end
    local pts, ok, hasLeft = {}, true, false
    for i = 1, np do
        local p, rel, rp, x, y = eb:GetPoint(i)
        if not p then ok = false break end
        if p:find("LEFT", 1, true) then hasLeft = true end
        pts[i] = { p, rel, rp, x or 0, y or 0 }
    end
    if not ok then return end
    d.padLeft = true
    if hasLeft then
        for i = 1, #pts do
            if pts[i][1]:find("LEFT", 1, true) then
                pts[i][4] = pts[i][4] - 6
            end
        end
    else
        local w = eb:GetWidth()
        if w and w > 0 then eb:SetWidth(w + 6) end
        for i = 1, #pts do pts[i][4] = pts[i][4] - 3 end
    end
    eb:ClearAllPoints()
    for i = 1, #pts do
        local t = pts[i]
        eb:SetPoint(t[1], t[2], t[3], t[4], t[5])
    end
    if eb.GetTextInsets and eb.SetTextInsets then
        local l, r, t2, b = eb:GetTextInsets()
        eb:SetTextInsets((l or 0) + 6, r or 0, t2 or 0, b or 0)
    end
end
EllesmereUI._WSkinPadInput = PadPopupInput

local function PopupEditBox(eb)
    if not eb then return end
    WSkin.EditBox(eb)
    PadPopupInput(eb)
end

local _guildNewsHook = false

-- Only named controls belong to this skin. In particular, never discover
-- buttons by walking the member ScrollBox or its pooled rows.
local GUILD_CONTROL_HOSTS = {
    "CommunitiesControlFrame", "GuildMemberDetailFrame", "InvitationFrame",
    "ClubFinderInvitationFrame", "TicketFrame", "GuildFinderFrame",
    "CommunityFinderFrame", "NotificationSettingsDialog",
}
local GUILD_BUTTON_KEYS = {
    "InviteButton", "GuildLogButton", "GuildControlButton", "GuildRecruitmentButton",
    "CommunitiesSettingsButton", "RemoveButton", "GroupInviteButton",
    "AcceptButton", "DeclineButton", "ApplyButton", "FindAGuildButton",
    "OkayButton", "AllButton", "NoneButton",
}
local GUILD_TAB_KEYS = { "ChatTab", "RosterTab", "GuildBenefitsTab", "GuildInfoTab" }
local function SkinGuildControlHost(host)
    if not host then return end
    for _, key in ipairs(GUILD_BUTTON_KEYS) do
        if host[key] then WSkin.Button(host[key]) end
    end
    if host.ScrollBar then WSkin.ScrollBar(host.ScrollBar) end
    if host.RankDropdown then WSkin.Dropdown(host.RankDropdown) end
    if host.InsetFrame then WSkin.Inset(host.InsetFrame) end
end
local function SkinGuildControls(f)
    SkinGuildControlHost(f)
    for _, key in ipairs(GUILD_CONTROL_HOSTS) do SkinGuildControlHost(f[key]) end
    if f.Chat then SkinGuildControlHost(f.Chat) end
    if f.MemberList and f.MemberList.ScrollBar then WSkin.ScrollBar(f.MemberList.ScrollBar) end
    if f.CommunitiesList and f.CommunitiesList.ScrollBar then WSkin.ScrollBar(f.CommunitiesList.ScrollBar) end
end

local function SkinGuildDialogs(f)
    SkinGuildPopup(f.GuildMemberDetailFrame)
    SkinGuildPopup(_G.CommunitiesAddDialog)
    SkinGuildPopup(_G.CommunitiesCreateCommunityDialog)
    -- Add/Create Community dialogs: their globals are NOT live frames at addon
    -- load (the real frame appears when the dialog first opens), so catch it
    -- from StaticPopupSpecial_Show, which receives the frame itself. The BG is
    -- a layout-KIT frame whose chrome pieces are not plain regions, so
    -- container alpha suppresses all of it at once.
    if type(_G.StaticPopupSpecial_Show) == "function" and not GetFFD(f).addDlgHook then
        GetFFD(f).addDlgHook = true
        local wanted = {
            CommunitiesAddDialog = true,
            CommunitiesCreateCommunityDialog = true,
        }
        hooksecurefunc("StaticPopupSpecial_Show", WSkin.WindowCallback("guild", function(dlg)
            if type(dlg) ~= "table" or not dlg.GetName then return end
            local ok, nm2 = pcall(dlg.GetName, dlg)
            if not ok or not nm2 or not wanted[nm2] then return end
            SkinGuildPopup(dlg)
            local d2 = GetFFD(dlg)
            if dlg.BG and not d2.bgKilled then
                d2.bgKilled = true
                pcall(dlg.BG.SetAlpha, dlg.BG, 0)
            end
            for _, k in ipairs({ "InviteLinkBox", "NameEdit", "ShortNameEdit" }) do
                if dlg[k] then PopupEditBox(dlg[k]) end
            end
            if dlg.JoinButton then
                WSkin.Button(dlg.JoinButton)
                local jfs = dlg.JoinButton.Text
                    or (dlg.JoinButton.GetFontString and dlg.JoinButton:GetFontString())
                if jfs then WSkin.White(jfs) end
            end
        end))
    end
    -- Community settings dialog (name/description/MOTD editor).
    local csd = _G.CommunitiesSettingsDialog
    if csd and type(csd) == "table" and not GetFFD(csd).csdSkinned then
        GetFFD(csd).csdSkinned = true
        SkinGuildPopup(csd)
        for _, k in ipairs({ "Accept", "AcceptButton", "Cancel", "CancelButton",
                             "Delete", "DeleteButton", "ChangeAvatarButton" }) do
            local b = csd[k]
            if b and b.GetObjectType and b:GetObjectType() == "Button" then
                WSkin.Button(b)
                local bfs = b.GetFontString and b:GetFontString()
                if bfs then WSkin.White(bfs) end
            end
        end
        for _, k in ipairs({ "NameEdit", "ShortNameEdit" }) do
            if csd[k] then PopupEditBox(csd[k]) end
        end
        for _, k in ipairs({ "ClubFocusDropdown", "LookingForDropdown", "LanguageDropdown" }) do
            if csd[k] then WSkin.Dropdown(csd[k]) end
        end
        WSkin.ScrollBarsIn(csd)
    end
    -- Guild recruitment settings dialog ("List My Guild in Guild Finder"):
    -- parented INSIDE CommunitiesFrame like EditStreamDialog, so the art sweeps strip
    -- its DialogBorderDark BG and it renders see-through without the house popup pass.
    local rd = f.RecruitmentDialog
    if rd and not GetFFD(rd).rdSkinned then
        GetFFD(rd).rdSkinned = true
        SkinGuildPopup(rd)
        -- Blizzard pins this to the SCREEN (UIParent), nowhere near a
        -- repositioned Communities window; dock it to the panel's right edge
        -- instead (nothing re-anchors it at runtime). 38 = the 32px side tabs
        -- riding that edge + a 6px gap.
        rd:ClearAllPoints()
        rd:SetPoint("TOPLEFT", f, "TOPRIGHT", 38, 0)
        -- Docked to the panel it can leave the screen, so clamp.
        rd:SetClampedToScreen(true)
        for _, k in ipairs({ "Accept", "Cancel" }) do
            local b = rd[k]
            if b and b.GetObjectType and b:GetObjectType() == "Button" then
                WSkin.Button(b)
                local bfs = b.GetFontString and b:GetFontString()
                if bfs then WSkin.White(bfs) end
            end
        end
        for _, k in ipairs({ "ClubFocusDropdown", "LookingForDropdown", "LanguageDropdown" }) do
            if rd[k] then WSkin.Dropdown(rd[k]) end
        end
        WSkin.ScrollBarsIn(rd)
    end
    -- Create/Edit Channel dialog: parented INSIDE CommunitiesFrame, so the recursive
    -- Bg-family art sweeps reach it and strip its fill (standalone UIParent dialogs are
    -- untouched). The house popup pass restores a backdrop.
    local esd = f.EditStreamDialog
    if esd and not GetFFD(esd).esdSkinned then
        GetFFD(esd).esdSkinned = true
        SkinGuildPopup(esd)
        for _, k in ipairs({ "Accept", "AcceptButton", "Cancel", "CancelButton",
                             "Delete", "DeleteButton" }) do
            local b = esd[k]
            if b and b.GetObjectType and b:GetObjectType() == "Button" then
                WSkin.Button(b)
                local bfs = b.GetFontString and b:GetFontString()
                if bfs then WSkin.White(bfs) end
            end
        end
        if esd.NameEdit then PopupEditBox(esd.NameEdit) end
        if esd.Description then PopupEditBox(esd.Description) end
        local modCheck = esd.TypeCheckBox or esd.ModeratorsOnlyCheckBox
            or esd.ModeratorsOnlyCheckbox
        if modCheck then SkinGuildCheck(modCheck) end
    end
    -- Notification settings dialog (chat bell): house popup + its extras.
    local nsd = f.NotificationSettingsDialog
    if nsd then
        SkinGuildPopup(nsd)
        if nsd.Selector then
            WSkin.FadeRegions(nsd.Selector)
            WSkin.Register(nsd.Selector, true)
            for _, k in ipairs({ "OkayButton", "AllButton", "NoneButton" }) do
                if nsd.Selector[k] then WSkin.Button(nsd.Selector[k]) end
            end
        end
        for _, k in ipairs({ "OkayButton", "AllButton", "NoneButton" }) do
            if nsd[k] then WSkin.Button(nsd[k]) end
        end
        if nsd.CommunitiesListDropdown then WSkin.Dropdown(nsd.CommunitiesListDropdown) end
        WSkin.ScrollBarsIn(nsd)
    end
end

local function Skin_Guild()
    local f = _G.CommunitiesFrame
    if not f then return end
    local state = GetFFD(f)
    if state.refreshGuild then state.refreshGuild(); return end
    WSkin.Shell("guild", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, nil, true)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.PortraitOverlay then
        WSkin.FadeRegions(f.PortraitOverlay)
        if f.PortraitOverlay.SetAlpha then f.PortraitOverlay:SetAlpha(0) end
        WSkin.Register(f.PortraitOverlay, true)
    end
    if f.StreamDropdown then
        if f.StreamDropdown.NotificationOverlay then
            WSkin.FadeRegions(f.StreamDropdown.NotificationOverlay)
            f.StreamDropdown.NotificationOverlay:SetAlpha(0)
        end
        WSkin.Dropdown(f.StreamDropdown)
        -- Chat tab's stream picker: 10% smaller, seated 10px left (one-shot).
        local sdd = GetFFD(f.StreamDropdown)
        if not sdd.adjusted then
            sdd.adjusted = true
            f.StreamDropdown:SetScale(0.9)
            local p, rel, rp, x, y = f.StreamDropdown:GetPoint(1)
            if p then
                f.StreamDropdown:ClearAllPoints()
                f.StreamDropdown:SetPoint(p, rel, rp, (x or 0) - 10, y or 0)
            end
        end
    end
    -- Minimized view swaps the community-list sidebar for a dropdown; style it.
    if f.CommunitiesListDropdown then WSkin.Dropdown(f.CommunitiesListDropdown) end
    -- Side tabs, EJ-style plates without geometry fights: the dark box +
    -- black border anchor AROUND THE ICON, never the tab, so the plate rides
    -- along wherever Blizzard's display-mode layout seats the tab. Tab size,
    -- icon anchors and the native tab chain are never touched. Only the root
    -- tab re-anchors (flush to the window edge); the others chain to it.
    for _, k in ipairs(GUILD_TAB_KEYS) do
        local tab = f[k]
        if tab and not tab:IsForbidden() then
            SquareTabIcon(tab)
            local icon = tab.Icon
            local td = GetFFD(tab)
            if icon and not td.box then
                local box = CreateFrame("Frame", nil, tab)
                box:SetPoint("TOPLEFT", icon, "TOPLEFT", -2, 2)
                box:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT", 2, -2)
                box:SetFrameLevel(math.max(0, tab:GetFrameLevel() - 2))
                local fill = SolidTex(box, "BACKGROUND", Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
                fill:SetAllPoints(box)
                WSkin.AddBorder(box, 0, 0, 0, 1)
                td.box = box
                td.bg = fill
                local hov = SolidTex(tab, "HIGHLIGHT", 1, 1, 1, 0.1)
                hov:SetPoint("TOPLEFT", box, "TOPLEFT", 0, 0)
                hov:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 0, 0)
                td.hover = hov
            end
            -- Tighter icon zoom than the standard crop, re-applied per pass:
            -- SquareTabIcon resets it to the 0.08 standard above.
            if icon and icon.SetTexCoord then icon:SetTexCoord(0.12, 0.88, 0.12, 0.88) end
            tab:SetAlphaFromBoolean(tab:IsEnabled(), 1, 0.5)
            -- Chain gap 10px tighter (one-shot): the native anchor to the
            -- previous tab is kept, only its y offset closes.
            if k ~= "ChatTab" and not td.gapAdj then
                local p, rel, rp, x, y = tab:GetPoint(1)
                if p then
                    td.gapAdj = true
                    tab:ClearAllPoints()
                    tab:SetPoint(p, rel, rp, x or 0, (y or 0) + 10)
                end
            end
        end
    end
    local chat = f.ChatTab
    if chat and not GetFFD(chat).rooted then
        GetFFD(chat).rooted = true
        chat:ClearAllPoints()
        chat:SetPoint("TOPLEFT", f, "TOPRIGHT", 1, -36)
    end

    -- Club finder (Guild Finder / Find a Community): the search input ships
    -- far taller than the search button, so both become the same slim size,
    -- stacked input-over-button.
    for _, finder in ipairs({ _G.ClubFinderGuildFinderFrame, _G.ClubFinderCommunityAndGuildFinderFrame }) do
        if finder and finder.InsetFrame then WSkin.Inset(finder.InsetFrame) end
        -- Card pagers carry PreviousPage/NextPage keys, which the generic
        -- paging sweep does not match.
        if finder then
            for _, ck in ipairs({ "GuildCards", "CommunityCards", "PendingGuildCards", "PendingCommunityCards" }) do
                local cards = finder[ck]
                if cards then
                    if cards.PreviousPage then WSkin.PageButton(cards.PreviousPage, "<", 13) end
                    if cards.NextPage then WSkin.PageButton(cards.NextPage, ">", 13) end
                end
            end
        end
        local ol = finder and finder.OptionsList
        if ol and ol.SearchBox and ol.Search then
            local od = GetFFD(ol)
            if not od.searchFit then
                od.searchFit = true
                ol.SearchBox:SetSize(118, 20)
                ol.Search:SetSize(120, 22)
            end
            -- Blizzard's options layout re-anchors these controls after us, so
            -- one-shot moves never show: both PIN their seats via synchronous
            -- SetPoint post-hooks. Box = Blizzard's base shifted left/up
            -- (captured point set); button = stacked under the box.
            local sbx2 = ol.SearchBox
            local sd2 = GetFFD(sbx2)
            if not sd2.pinHooked then
                sd2.pinHooked = true
                local function capture()
                    local numPts = sbx2:GetNumPoints()
                    if not numPts or numPts == 0 then return false end
                    local pts = {}
                    for i = 1, numPts do
                        local p, rel, rp, x, y = sbx2:GetPoint(i)
                        if not p then return false end
                        pts[i] = { p, rel, rp, (x or 0) - 10, (y or 0) + 6 }
                    end
                    sd2.pin = pts
                    return true
                end
                local function reseat()
                    if not sd2.pin then return end
                    sd2.inPin = true
                    sbx2:ClearAllPoints()
                    for i = 1, #sd2.pin do
                        local t = sd2.pin[i]
                        sbx2:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                    sd2.inPin = false
                end
                if capture() then reseat() end
                hooksecurefunc(sbx2, "SetPoint", function()
                    if sd2.inPin then return end
                    if not sd2.pin then
                        if capture() then reseat() end
                    else
                        reseat()
                    end
                end)
            end
            local sBtn = ol.Search
            local bd2 = GetFFD(sBtn)
            if not bd2.pinHooked then
                bd2.pinHooked = true
                local function reseatBtn()
                    bd2.inPin = true
                    sBtn:ClearAllPoints()
                    sBtn:SetPoint("TOP", sbx2, "BOTTOM", 1, -3)
                    bd2.inPin = false
                end
                reseatBtn()
                hooksecurefunc(sBtn, "SetPoint", function()
                    if bd2.inPin then return end
                    reseatBtn()
                end)
            end
            -- Filter/sort dropdowns carry finder-specific keys that the
            -- generic controls sweep does not match.
            if ol.ClubFilterDropdown then WSkin.Dropdown(ol.ClubFilterDropdown) end
            if ol.SortByDropdown then WSkin.Dropdown(ol.SortByDropdown) end
            if ol.ClubSizeDropdown then WSkin.Dropdown(ol.ClubSizeDropdown) end
            WSkin.EditBox(ol.SearchBox)
            WSkin.Button(ol.Search)
            local bfs = ol.Search.GetFontString and ol.Search:GetFontString()
            if bfs then WSkin.White(bfs) end
        end
        -- These views' top controls run 20px deeper than the chat view's band:
        -- a band extension parented to the FINDER (so it shows and hides with the view)
        -- with its own bottom separator, while the main band's separator hides so no
        -- line cuts mid-bar. The request-to-join dialog hangs off the finder.
        if finder and finder.RequestToJoinFrame then
            SkinGuildPopup(finder.RequestToJoinFrame)
        end
        if finder and not GetFFD(finder).bandExt then
            local fd2 = GetFFD(finder)
            fd2.bandExt = true
            -- The zone-band FFD entry on f (built further down; GetFFD returns
            -- the same table either way).
            local gz = GetFFD(f)
            local sbw = gz.sbw or 170
            local ext = finder:CreateTexture(nil, "BACKGROUND", nil, -4)
            ext:SetColorTexture(0, 0, 0, 0.10)
            ext:SetPoint("TOPLEFT", f, "TOPLEFT", sbw, -59)
            ext:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -59)
            ext:SetHeight(20)
            local extSep = finder:CreateTexture(nil, "ARTWORK")
            extSep:SetColorTexture(0.15, 0.15, 0.15, 1)
            extSep:SetHeight(gz.sepPx or 1)
            extSep:SetPoint("BOTTOMLEFT", ext, "BOTTOMLEFT", 0, 0)
            extSep:SetPoint("BOTTOMRIGHT", ext, "BOTTOMRIGHT", 0, 0)
            finder:HookScript("OnShow", function()
                if gz.topSep then gz.topSep:Hide() end
            end)
            finder:HookScript("OnHide", function()
                local a2 = _G.ClubFinderGuildFinderFrame
                local b2 = _G.ClubFinderCommunityAndGuildFinderFrame
                if gz.topSep and not ((a2 and a2:IsShown()) or (b2 and b2:IsShown())) then
                    gz.topSep:Show()
                end
            end)
            if finder:IsShown() and gz.topSep then gz.topSep:Hide() end
        end
    end

    -- Zone bands laid out like the bags window (secondary top bar below the
    -- shell's 25px title bar, bottom bar, sidebar column + 1px separator).
    -- All band art MUST live on OUR OWN child frame: as direct f regions the
    -- shell's region fade wipes the bands on every re-skin pass.
    local gzd = GetFFD(f)
    if not gzd.zoneBands then
        gzd.zoneBands = true
        -- Separator sizing: exactly one PHYSICAL pixel in this frame's own units,
        -- default pixel snapping. PP.mult is one physical pixel in UIParent units, so
        -- when the host's effective scale differs the raw mult is slightly over a pixel
        -- here and snapping rounds the line onto two rows.
        local PPz = EllesmereUI.PanelPP
        local px = (PPz and PPz.mult) or 1
        do
            local es = f:GetEffectiveScale()
            local uiScale = UIParent and UIParent:GetScale() or 1
            if es and es > 0 and uiScale > 0 then
                px = px * uiScale / es
            end
        end
        local GUILD_SIDEBAR_W = 170   -- hardcoded sidebar column width
        local host = CreateFrame("Frame", nil, f)
        host:SetAllPoints(f)
        host:SetFrameLevel(f:GetFrameLevel())
        gzd.zoneHost = host
        -- Secondary top bar: starts AFTER the sidebar column (never over it).
        local topBand = host:CreateTexture(nil, "BACKGROUND")
        topBand:SetColorTexture(0, 0, 0, 0.10)
        topBand:SetPoint("TOPLEFT", f, "TOPLEFT", GUILD_SIDEBAR_W, -25)
        topBand:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -25)
        topBand:SetHeight(34)
        local topSep = host:CreateTexture(nil, "ARTWORK")
        topSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        topSep:SetHeight(px)
        topSep:SetPoint("BOTTOMLEFT", topBand, "BOTTOMLEFT", 0, 0)
        topSep:SetPoint("BOTTOMRIGHT", topBand, "BOTTOMRIGHT", 0, 0)
        gzd.topSep = topSep
        gzd.sbw = GUILD_SIDEBAR_W
        gzd.sepPx = px
        local botBand = host:CreateTexture(nil, "BACKGROUND")
        botBand:SetColorTexture(0, 0, 0, 0.10)
        botBand:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
        botBand:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
        botBand:SetHeight(30)
        local botSep = host:CreateTexture(nil, "ARTWORK")
        botSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        botSep:SetHeight(px)
        botSep:SetPoint("TOPLEFT", botBand, "TOPLEFT", 0, 0)
        botSep:SetPoint("TOPRIGHT", botBand, "TOPRIGHT", 0, 0)
        -- Sidebar wash + separator on OUR host with FIXED geometry (window left edge to
        -- GUILD_SIDEBAR_W, title bar to bottom band). Never anchor these to the list's
        -- ScrollBox: Blizzard rebuilds its rect on view churn, so the art vanishes
        -- whenever the box's anchors are momentarily invalid and pops back on relayout.
        local wash = host:CreateTexture(nil, "BACKGROUND")
        wash:SetColorTexture(0, 0, 0, 0.07)
        wash:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -25)
        wash:SetPoint("BOTTOMRIGHT", f, "BOTTOMLEFT", GUILD_SIDEBAR_W, 30)
        local sideSep = host:CreateTexture(nil, "ARTWORK")
        sideSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        sideSep:SetWidth(px)
        sideSep:SetPoint("TOPRIGHT", f, "TOPLEFT", GUILD_SIDEBAR_W, -25)
        sideSep:SetPoint("BOTTOMRIGHT", f, "BOTTOMLEFT", GUILD_SIDEBAR_W, 30)
    end

    -- Left community list: filigrees + bluemenu bg gone, flat entries. Cleared
    -- via SetTexture(""), NOT alpha: Blizzard's list repaints re-raise this
    -- art after our show pass and cover the sidebar wash until the next skin
    -- pass. A cleared texture file survives every repaint.
    local list = f.CommunitiesList or _G.CommunitiesFrameCommunitiesList
    if list then
        for _, k in ipairs({ "TopFiligree", "BottomFiligree", "Bg" }) do
            local t = list[k]
            if t and t.SetTexture then t:SetTexture("") end
        end
        if list.FilligreeOverlay then
            local regions = { list.FilligreeOverlay:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r.IsObjectType and r:IsObjectType("Texture") and r.SetTexture then
                    r:SetTexture("")
                end
            end
            list.FilligreeOverlay:SetAlpha(0)
        end
        if list.InsetFrame then WSkin.Inset(list.InsetFrame) end
        WSkin.FadeKeyedArt(list)
        -- Entries re-skin from the ENTRY MIXIN's own setters: Blizzard
        -- re-inits pooled entries through these on every toggle/list build,
        -- paths that never fire ScrollBox Update, reverting the card art.
        if _G.CommunitiesListEntryMixin and not GetFFD(list).entryHook then
            GetFFD(list).entryHook = true
            local function reskinEntry(entryFrame)
                if entryFrame and not (entryFrame.IsForbidden and entryFrame:IsForbidden()) then
                    SkinCommunityEntry(entryFrame)
                end
            end
            for _, m in ipairs({ "SetClubInfo", "SetAddCommunity", "SetFindCommunity", "SetGuildFinder" }) do
                if _G.CommunitiesListEntryMixin[m] then
                    hooksecurefunc(_G.CommunitiesListEntryMixin, m, reskinEntry)
                end
            end
        end
        SkinCommunityEntry = WSkin.WindowCallback("guild", SkinCommunityEntry)
        local sb = list.ScrollBox
        if sb then
            if sb.ForEachFrame then pcall(sb.ForEachFrame, sb, SkinCommunityEntry) end
            if sb.Update and not GetFFD(sb).reHooked then
                GetFFD(sb).reHooked = true
                hooksecurefunc(sb, "Update", function()
                    if sb.ForEachFrame then pcall(sb.ForEachFrame, sb, SkinCommunityEntry) end
                end)
            end
        end
        -- Scrollbar flush with the sidebar's inner right edge (one-shot).
        local lsb = list.ScrollBar
        if lsb and not GetFFD(lsb).seated then
            GetFFD(lsb).seated = true
            lsb:ClearAllPoints()
            lsb:SetPoint("TOPRIGHT", list, "TOPRIGHT", 0, -8)
            lsb:SetPoint("BOTTOMRIGHT", list, "BOTTOMRIGHT", 0, 8)
        end
    end

    local chat = f.Chat
    if chat then
        local ci = chat.ChatInsetFrame or chat.InsetFrame
        if ci then WSkin.Inset(ci) end
    end
    -- Input skin ONLY: no anchor/position meddling. Pinning this box makes it
    -- stop rendering entirely, so it runs stock Blizzard geometry (height-only
    -- slim below is the sole exception). Blizzard re-raises the input's art on
    -- chat layout passes, so the art re-fades EVERY pass (our fill protected)
    -- and the box registers for restrips.
    if f.ChatEditBox then
        local eb = f.ChatEditBox
        WSkin.EditBox(eb)
        local ebd = GetFFD(eb)
        local keep = {}
        if ebd.bg then keep[ebd.bg] = true end
        WSkin.FadeRegions(eb, keep)
        for _, k in ipairs({ "Left", "Right", "Middle", "Mid" }) do
            local r = eb[k]
            if r and r.SetAlpha then r:SetAlpha(0) end
        end
        WSkin.Register(eb, true)
        -- Height-only slim: one-shot, no anchor writes.
        if not ebd.slimmed then
            local hh = eb:GetHeight()
            if hh and hh > 26 then
                ebd.slimmed = true
                eb:SetHeight(hh - 12)
            end
        end
    end

    local ml = f.MemberList
    if ml and ml.InsetFrame then WSkin.Inset(ml.InsetFrame) end
    -- "N/M Online" count above the roster: white.
    if ml and ml.MemberCount and ml.MemberCount.SetTextColor then
        WSkin.White(ml.MemberCount)
    end
    -- Member-list view dropdowns (guild + community): scaled down, seated 8px
    -- lower (one-shot; the label keeps its stock font size, the 0.85 scale is
    -- the only text shrink).
    for _, ddKey in ipairs({ "GuildMemberListDropdown", "CommunityMemberListDropdown" }) do
        local dd2 = f[ddKey]
        if dd2 then
            WSkin.Dropdown(dd2)
            local gdd = GetFFD(dd2)
            if not gdd.scaled then
                gdd.scaled = true
                dd2:SetScale(0.85)
                local p, rel, rp, x, y = dd2:GetPoint(1)
                if p then
                    dd2:ClearAllPoints()
                    dd2:SetPoint(p, rel, rp, x or 0, (y or 0) - 8)
                end
            end
        end
    end
    if ml and ml.ShowOfflineButton then SkinGuildCheck(ml.ShowOfflineButton) end
    SkinGuildDialogs(f)
    -- Ticket frame (community invite ticket pane): inset chrome off.
    local tkf = f.TicketFrame
    if tkf then
        WSkin.FadeRegions(tkf)
        WSkin.Register(tkf, true)
        if tkf.InsetFrame then
            WSkin.Inset(tkf.InsetFrame)
            if tkf.InsetFrame.NineSlice then
                WSkin.FadeNineSlice(tkf.InsetFrame.NineSlice)
            end
        end
        for _, k in ipairs({ "AcceptButton", "DeclineButton" }) do
            local b = tkf[k]
            if b then
                WSkin.Button(b)
                local bfs = b.GetFontString and b:GetFontString()
                if bfs then WSkin.White(bfs) end
            end
        end
    end
    -- Roster click-to-sort column headers: flat plates, white labels, standard
    -- hover. Columns are pooled 3-slice buttons under ColumnDisplay that
    -- rebuild per club/view, so the pass re-runs (see the refresh hook below).
    local function SkinRosterColumns()
        local cd = ml and ml.ColumnDisplay
        if not cd then return end
        WSkin.FadeRegions(cd)
        WSkin.Register(cd, true)
        local children = { cd:GetChildren() }
        for i = 1, #children do
            local col = children[i]
            if col and col.GetObjectType and col:GetObjectType() == "Button" then
                local d2 = GetFFD(col)
                if not d2.bg then
                    for _, k2 in ipairs({ "Left", "Middle", "Right" }) do
                        local t2 = col[k2]
                        if t2 and t2.SetTexture then t2:SetTexture("") end
                    end
                    WSkin.FadeRegions(col)
                    local bg2 = SolidTex(col, "BACKGROUND",
                        Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                    bg2:SetPoint("TOPLEFT", 1, -1)
                    bg2:SetPoint("BOTTOMRIGHT", -1, 1)
                    d2.bg = bg2
                    local hov = SolidTex(col, "HIGHLIGHT", 1, 1, 1, 0.1)
                    hov:SetAllPoints(col)
                    d2.hover = hov
                    WSkin.Register(col, true)
                end
                local fs2 = col.GetFontString and col:GetFontString()
                if fs2 then WSkin.White(fs2) end
            end
        end
    end
    SkinRosterColumns = WSkin.WindowCallback("guild", SkinRosterColumns)
    SkinRosterColumns()
    -- Re-skin roster columns on Blizzard's rebuild (per club / view change) via
    -- hooksecurefunc on the list refresh. NEVER HookScript the secure ColumnDisplay: an
    -- OnShow/OnHide there fires INSIDE the secure roster refresh triggered by a
    -- protected guild action (SetNote / SetGuildRankOrder) -> ADDON_ACTION_FORBIDDEN.
    -- hooksecurefunc post-hooks are taint-safe by design.
    if ml and ml.RefreshListDisplay and not GetFFD(ml).colRefreshHooked then
        GetFFD(ml).colRefreshHooked = true
        hooksecurefunc(ml, "RefreshListDisplay", WSkin.Debounce(SkinRosterColumns))
    end
    -- NEVER re-anchor or resize the roster: CommunitiesMemberListEntryMixin
    -- sizes every row from GetMemberList():GetWidth(), and the list view reads
    -- ScrollBox:GetVisibleExtent() in the same pass that creates the row
    -- buttons, so an addon-written width or anchor is read back and taints it.
    -- Rows born in that pass stay tainted for the session: the protected
    -- actions the refresh triggers are blocked (SetNote / SetGuildRankOrder /
    -- whisper -> ADDON_ACTION_FORBIDDEN) and the row tooltip throws on the
    -- secret member fields (C_CreatureInfo.GetRaceInfo(memberInfo.race)).

    local mm = f.MaximizeMinimizeFrame
    if mm then
        CaretGlyph(mm.MaximizeButton, true)
        CaretGlyph(mm.MinimizeButton, false)
    end
    -- Zone bands belong to the full layout only (the minimized view has no
    -- sidebar column or top/bottom bars): hide the band host while minimized.
    -- The Maximize button shows only when minimized, so it is the state probe.
    if gzd.zoneHost then
        local function UpdateZoneBands()
            local minimized = mm and mm.MaximizeButton and mm.MaximizeButton:IsShown()
            gzd.zoneHost:SetShown(not minimized)
        end
        UpdateZoneBands()
        if mm and not gzd.mmHook then
            gzd.mmHook = true
            for _, b in ipairs({ mm.MaximizeButton, mm.MinimizeButton }) do
                if b and b.HookScript then
                    b:HookScript("OnClick", function()
                        if C_Timer then C_Timer.After(0, UpdateZoneBands) else UpdateZoneBands() end
                    end)
                end
            end
        end
    end
    -- Raise the chat input 7px ONLY when minimized. Its stock position is
    -- view-dependent, so a captured original bleeds across views: hook SetPoint
    -- and re-apply +7 the NEXT frame, relative to Blizzard's LIVE position
    -- (an immediate re-apply compounds across multi-point sets). Each pass
    -- reads the just-set stock, so it never stacks.
    local eb = f.ChatEditBox
    if eb and mm and not GetFFD(eb).raiseHook then
        GetFFD(eb).raiseHook = true
        local applying, pending = false, false
        local function ApplyOffset()
            pending = false
            if not (mm.MaximizeButton and mm.MaximizeButton:IsShown()) then return end  -- maximized: leave stock
            local np = eb:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = eb:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) + 7 }
            end
            if ok then
                applying = true
                eb:ClearAllPoints()
                for i = 1, #pts do local t = pts[i]; eb:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                applying = false
            end
        end
        hooksecurefunc(eb, "SetPoint", function()
            if applying or pending then return end
            pending = true
            if C_Timer then C_Timer.After(0, ApplyOffset) else ApplyOffset() end
        end)
        -- Initial apply (box is at its stock position at load).
        pending = true
        if C_Timer then C_Timer.After(0, ApplyOffset) else ApplyOffset() end
    end

    -- Perks (Guild Benefits) tab: parchment inset borders + section art
    -- gone, section titles in the house font, slim scrollbars, flat rows,
    -- and the reputation bar as a flat accent fill on a dark trough.
    local gb = f.GuildBenefitsFrame
    if gb then
        for _, k in ipairs({ "InsetBorderLeft", "InsetBorderRight", "InsetBorderBottomRight",
                             "InsetBorderBottomLeft", "InsetBorderTopRight", "InsetBorderTopLeft",
                             "InsetBorderLeft2", "InsetBorderBottomLeft2", "InsetBorderTopLeft2" }) do
            local t = gb[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local function SkinBenefitRow(row)
            if not row or row:IsForbidden() then return end
            local rd = GetFFD(row)
            if not rd.bg then
                local keep = {}
                if row.Icon then keep[row.Icon] = true end
                WSkin.FadeRegions(row, keep)
                local bg = row:CreateTexture(nil, "BACKGROUND", nil, -3)
                bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
                bg:SetPoint("TOPLEFT", 1, -1)
                bg:SetPoint("BOTTOMRIGHT", -1, 1)
                rd.bg = bg
                WSkin.AddBorder(row)
                if row.Icon then WSkin.SquareIcon(row.Icon, row) end
                WSkin.Register(row, keep)
            end
            local regions = { row:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r.IsObjectType and r:IsObjectType("FontString") then
                    WSkin.Font(r)
                    WSkin.White(r)
                end
            end
        end
        SkinBenefitRow = WSkin.WindowCallback("guild", SkinBenefitRow)
        for _, sec in ipairs({ gb.Perks, gb.Rewards }) do
            if sec then
                WSkin.FadeRegions(sec)
                WSkin.Register(sec, true)
                if sec.Bg and sec.Bg.SetAlpha then sec.Bg:SetAlpha(0) end
                if sec.TitleText then WSkin.Font(sec.TitleText); WSkin.White(sec.TitleText) end
                if sec.ScrollBar then WSkin.ScrollBar(sec.ScrollBar) end
                local sbx3 = sec.ScrollBox
                if sbx3 and sbx3.ForEachFrame then
                    pcall(sbx3.ForEachFrame, sbx3, SkinBenefitRow)
                    if sbx3.Update and not GetFFD(sbx3).rowHook then
                        GetFFD(sbx3).rowHook = true
                        hooksecurefunc(sbx3, "Update", function(box)
                            pcall(box.ForEachFrame, box, SkinBenefitRow)
                        end)
                    end
                end
            end
        end
        -- Reputation bar: the bar FRAME is taller than the visual fill, so the
        -- trough + border wrap the fill's MEASURED vertical band at full
        -- width. The fill cannot be the anchor -- its width IS the progress.
        -- Retries from the pane's OnShow until laid out.
        local function FlattenRepBar()
            local rep = gb.FactionFrame and gb.FactionFrame.Bar
            if not rep or GetFFD(rep).flat then return end
            local prog = rep.Progress
            local rt, pt2 = rep:GetTop(), prog and prog:GetTop()
            local rb, pb = rep:GetBottom(), prog and prog:GetBottom()
            if not (rt and pt2 and rb and pb) then return end
            local bd3 = GetFFD(rep)
            bd3.flat = true
            for _, k in ipairs({ "Middle", "Right", "Left", "BG" }) do
                local t = rep[k]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            if rep.Shadow and rep.Shadow.SetAlpha then rep.Shadow:SetAlpha(0) end
            prog:SetTexture("Interface\\Buttons\\WHITE8X8")
            local fr2, fg2, fb2, fa2 = WSkin.BarFillColor()
            prog:SetVertexColor(fr2, fg2, fb2, fa2)
            local trough = rep:CreateTexture(nil, "BACKGROUND", nil, -1)
            trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
            trough:SetPoint("TOPLEFT", rep, "TOPLEFT", 0, -(rt - pt2))
            trough:SetPoint("BOTTOMRIGHT", rep, "BOTTOMRIGHT", 0, pb - rb)
            bd3.bg = trough
            WSkin.BorderRegion(rep, trough)
            -- "Guild Reputation" label + on-bar text in white house font.
            for _, host2 in ipairs({ gb.FactionFrame, rep }) do
                if host2 and host2.GetRegions then
                    local regions = { host2:GetRegions() }
                    for i = 1, #regions do
                        local r = regions[i]
                        if r and r.IsObjectType and r:IsObjectType("FontString") then
                            WSkin.Font(r)
                            WSkin.White(r)
                        end
                    end
                end
            end
        end
        FlattenRepBar = WSkin.WindowCallback("guild", FlattenRepBar)
        FlattenRepBar()
        if not GetFFD(gb).repHook then
            GetFFD(gb).repHook = true
            gb:HookScript("OnShow", WSkin.Debounce(FlattenRepBar))
        end
    end

    -- Guild Info tab: inset borders + parchment gone, section titles in the
    -- house font, slim scrollbars, themed news-filter popout + checkboxes,
    -- and the per-row news header strips cleared as rows populate.
    local gdet = _G.CommunitiesFrameGuildDetailsFrame
    if gdet then
        for _, k in ipairs({ "InsetBorderLeft", "InsetBorderRight", "InsetBorderBottomRight",
                             "InsetBorderBottomLeft", "InsetBorderTopRight", "InsetBorderTopLeft",
                             "InsetBorderLeft2", "InsetBorderBottomLeft2", "InsetBorderTopLeft2" }) do
            local t = gdet[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
    end
    -- "View Log" button: white label, 2px smaller.
    local logBtn = f.GuildLogButton
    if logBtn then
        local lfs = logBtn.GetFontString and logBtn:GetFontString()
        if lfs then
            WSkin.White(lfs)
            local ld = GetFFD(lfs)
            if not ld.shrunk then
                local pth, sz, fl = lfs:GetFont()
                if pth and sz then
                    ld.shrunk = true
                    lfs:SetFont(pth, sz - 2, fl)
                end
            end
        end
    end
    -- Guild log popup (old-style dialog: named Bg/corner pieces, corner X
    -- "<name>Close", bottom text button "<name>CloseButton", old scrollbar).
    local function SkinGuildLog()
        local gl = _G.CommunitiesGuildLogFrame
        if not gl or type(gl) ~= "table" or GetFFD(gl).logSkinned then return end
        GetFFD(gl).logSkinned = true
        local n = (gl.GetName and gl:GetName()) or "CommunitiesGuildLogFrame"
        -- TWO buttons can carry the CloseButton name (corner X + bottom text
        -- button; the global resolves to only one). Classify every button by
        -- label (text -> house button, blank -> house X) BEFORE the popup pass,
        -- so its own CloseButton call cannot glyph the text button.
        local function TreatClose(cand)
            if not cand or type(cand) ~= "table" or not cand.GetObjectType then return end
            local cd = GetFFD(cand)
            if cd.closeTreated then return end
            cd.closeTreated = true
            local bfs = cand.GetFontString and cand:GetFontString()
            local btxt = bfs and bfs.GetText and bfs:GetText()
            if btxt and btxt ~= "" then
                WSkin.Button(cand)
                if bfs then WSkin.White(bfs) end
                -- Sentinel on CloseButton's guard key: blocks any later
                -- WSkin.CloseButton on this frame. No hover hooks read it.
                if not cd.x then cd.x = true end
            else
                WSkin.CloseButton(cand)
            end
        end
        TreatClose(gl.Close)
        TreatClose(gl.CloseButton)
        TreatClose(_G[n .. "Close"])
        TreatClose(_G[n .. "CloseButton"])
        local children = { gl:GetChildren() }
        for i = 1, #children do
            local ch = children[i]
            if ch and not WSkin.IsForeignFrame(ch, gl)
               and ch.GetObjectType and ch:GetObjectType() == "Button" then
                TreatClose(ch)
            end
        end
        SkinGuildPopup(gl)
        -- Inner container carries its own NineSlice chrome.
        local cont = gl.Container
        if cont then
            WSkin.FadeRegions(cont)
            if cont.NineSlice then WSkin.FadeNineSlice(cont.NineSlice) end
            WSkin.Register(cont, true)
        end
        local tt = gl.Title or gl.TitleText or _G[n .. "Title"] or _G[n .. "TitleText"]
        if tt and tt.SetTextColor then
            WSkin.Font(tt)
            WSkin.White(tt)
        end
        WSkin.ScrollBarsIn(gl)
        -- Old-style scrollbar: arrows faded, thumb -> 4px house strip.
        local sb = _G[n .. "ScrollFrameScrollBar"]
        if sb and not GetFFD(sb).slim then
            GetFFD(sb).slim = true
            local sbn = (sb.GetName and sb:GetName()) or ""
            for _, suffix in ipairs({ "ScrollUpButton", "ScrollDownButton" }) do
                local b = sb[suffix] or _G[sbn .. suffix]
                if b then
                    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                                         "GetDisabledTexture", "GetHighlightTexture" }) do
                        local t = b[g] and b[g](b)
                        if t and t.SetAlpha then t:SetAlpha(0) end
                    end
                end
            end
            local thumb = sb.GetThumbTexture and sb:GetThumbTexture()
            if thumb then
                thumb:SetTexture("Interface\\Buttons\\WHITE8X8")
                thumb:SetVertexColor(1, 1, 1, 0.3)
                thumb:SetWidth(4)
            end
        end
    end
    SkinGuildLog = WSkin.WindowCallback("guild", SkinGuildLog)
    SkinGuildLog()
    if logBtn and not GetFFD(logBtn).logHook then
        GetFFD(logBtn).logHook = true
        logBtn:HookScript("OnClick", SkinGuildLog)
    end
    -- "Add to Chat" button: house caret + white label.
    local atc = f.AddToChatButton
    if atc and not GetFFD(atc).atcSkinned then
        GetFFD(atc).atcSkinned = true
        -- The label may be the fontstring, a Text key, or an anonymous region:
        -- collect deduped, white them (color only, stock font kept), seat 2px
        -- lower (one-shot, all anchors preserved).
        local labels = {}
        local afs = atc.GetFontString and atc:GetFontString()
        if afs then labels[afs] = true end
        if atc.Text and atc.Text.SetTextColor then labels[atc.Text] = true end
        local regions = { atc:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r.IsObjectType and r:IsObjectType("FontString") then
                labels[r] = true
            end
        end
        for fsr in pairs(labels) do
            WSkin.White(fsr)
            local ld = GetFFD(fsr)
            if not ld.dropped then
                local np = fsr:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = fsr:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) - 2 }
                end
                if ok then
                    ld.dropped = true
                    fsr:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        fsr:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
        end
        local arrow = atc.Arrow
        if arrow then
            local tex = arrow
            if arrow.IsObjectType and not arrow:IsObjectType("Texture") then
                tex = nil
                if arrow.GetRegions then
                    local regions2 = { arrow:GetRegions() }
                    for i = 1, #regions2 do
                        local r = regions2[i]
                        if r and r.IsObjectType and r:IsObjectType("Texture") then
                            tex = r
                            break
                        end
                    end
                end
            end
            if tex and tex.SetAtlas then
                -- Blizzard repaints the arrow on hover/press state changes, so
                -- self-guarding hooks keep the house caret in place.
                local td = GetFFD(tex)
                local function ApplyCaret()
                    if td.inSet then return end
                    td.inSet = true
                    tex:SetAtlas("Azerite-PointingArrow", false)
                    tex:SetSize(14, 10)
                    tex:SetVertexColor(1, 1, 1, 1)
                    td.inSet = false
                end
                if not td.hooked then
                    td.hooked = true
                    hooksecurefunc(tex, "SetAtlas", ApplyCaret)
                    hooksecurefunc(tex, "SetTexture", ApplyCaret)
                    hooksecurefunc(tex, "SetTexCoord", ApplyCaret)
                end
                ApplyCaret()
            end
        end
    end
    -- Settings + Invite buttons: white labels, 1px smaller text.
    local function SlimWhiteLabel(b)
        if not b then return end
        local lfs2 = b.GetFontString and b:GetFontString()
        if not lfs2 then return end
        WSkin.White(lfs2)
        local ld2 = GetFFD(lfs2)
        if not ld2.shrunk then
            local pth, sz, fl = lfs2:GetFont()
            if pth and sz then
                ld2.shrunk = true
                lfs2:SetFont(pth, sz - 1, fl)
            end
        end
    end
    SlimWhiteLabel(f.CommunitiesControlFrame and f.CommunitiesControlFrame.CommunitiesSettingsButton)
    SlimWhiteLabel(f.InviteButton)
    local infoFrame = _G.CommunitiesFrameGuildDetailsFrameInfo
    local newsFrame = _G.CommunitiesFrameGuildDetailsFrameNews
    for _, sub in ipairs({ infoFrame, newsFrame }) do
        if sub then
            -- Keep our divider (stored as the pane's protected fill): Restrip
            -- honors protect keys, but a plain FadeRegions does not.
            local keepSub = {}
            local sd4 = FFD[sub]
            if sd4 and sd4.fill then keepSub[sd4.fill] = true end
            WSkin.FadeRegions(sub, keepSub)
            WSkin.Register(sub, true)
            if sub.TitleText then WSkin.Font(sub.TitleText); WSkin.White(sub.TitleText) end
            if sub.ScrollBar then WSkin.ScrollBar(sub.ScrollBar) end
            if sub.DetailsFrame and sub.DetailsFrame.ScrollBar then
                WSkin.ScrollBar(sub.DetailsFrame.ScrollBar)
            end
        end
    end
    -- Info tab dividers: vertical between the info and news columns, plus a
    -- horizontal above Guild Information. The horizontal one is stored as the
    -- info pane's protected fill, since that pane is registered for restrips
    -- and would fade an unprotected anonymous region.
    if gdet and infoFrame and newsFrame and not GetFFD(gdet).dividers then
        GetFFD(gdet).dividers = true
        local mid = gdet:CreateTexture(nil, "OVERLAY")
        mid:SetColorTexture(1, 1, 1, 0.15)
        mid:SetWidth(1)
        mid:SetPoint("TOP", newsFrame, "TOPLEFT", -7, -4)
        mid:SetPoint("BOTTOM", newsFrame, "BOTTOMLEFT", -7, 4)
        local above = infoFrame:CreateTexture(nil, "OVERLAY")
        above:SetColorTexture(1, 1, 1, 0.15)
        above:SetHeight(1)
        above:SetPoint("TOPLEFT", infoFrame, "TOPLEFT", 14, -194)
        above:SetPoint("TOPRIGHT", infoFrame, "TOPRIGHT", -7, -194)
        GetFFD(infoFrame).fill = above
    end

    local filters = _G.CommunitiesGuildNewsFiltersFrame
    if filters and not GetFFD(filters).skinned then
        GetFFD(filters).skinned = true
        WSkin.Panel(filters)
        local fcb = filters.CloseButton or _G.CommunitiesGuildNewsFiltersFrameCloseButton
        if fcb then WSkin.CloseButton(fcb) end
        for _, k in ipairs({ "GuildAchievement", "Achievement", "DungeonEncounter",
                             "EpicItemLooted", "EpicItemCrafted", "EpicItemPurchased",
                             "LegendaryItemLooted" }) do
            if filters[k] then SkinGuildCheck(filters[k]) end
        end
    end
    if type(_G.GuildNewsButton_SetNews) == "function" and not _guildNewsHook then
        _guildNewsHook = true
        hooksecurefunc("GuildNewsButton_SetNews", function(button)
            if button and button.header and button.header.SetAlpha then
                button.header:SetAlpha(0)
            end
        end)
    end

    for _, k in ipairs({ "Inset", "LeftInset", "RightInset" }) do
        if f[k] then WSkin.Inset(f[k]) end
    end
    SkinGuildControls(f)
    local function RefreshGuild()
        if not f:IsVisible() then return end
        SkinGuildDialogs(f)
        SkinGuildLog()
        SkinGuildControls(f)
        SkinRosterColumns()
        -- State-dependent tab opacity remains Blizzard-driven. Do not branch
        -- on the enabled state: it can be secret under forced restrictions.
        for _, key in ipairs(GUILD_TAB_KEYS) do
            local tab = f[key]
            if tab then tab:SetAlphaFromBoolean(tab:IsEnabled(), 1, 0.5) end
        end
        WSkin.Restrip("guild")
        -- The guild tabs are display-mode buttons, not PanelTemplates tabs, so
        -- the engine's SetTab/UpdateTabs hooks never refresh their active
        -- visual; the reopen pass has to (O(skinned tabs), one pass per show).
        WSkin.UpdateAllTabs()
    end
    state.refreshGuild = WSkin.WindowCallback("guild", RefreshGuild)
    WSkin.HookShow(f, WSkin.Debounce(state.refreshGuild))
end

Skin_Guild = WSkin.WindowCallback("guild", Skin_Guild)

WSkin.RegisterWindow({
    key = "guild",
    addons = { Blizzard_Communities = true },
    apply = Skin_Guild,
})
end

-------------------------------------------------------------------------------
--  Calendar (CalendarFrame)
-------------------------------------------------------------------------------
-- Shift a frame up by dyUp px, preserving EVERY anchor point (one-shot): a
-- single-point reseat would width-collapse a multi-anchored frame.
local function CalReseat(frame, dyUp)
    if not frame then return end
    local d = GetFFD(frame)
    if d.reseated then return end
    local n = frame:GetNumPoints() or 0
    if n < 1 then return end
    local pts = {}
    for i = 1, n do
        local p, rel, rp, x, y = frame:GetPoint(i)
        if not p then return end
        pts[i] = { p, rel, rp, x or 0, (y or 0) + dyUp }
    end
    d.reseated = true
    frame:ClearAllPoints()
    for i = 1, #pts do local t = pts[i]; frame:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
end

do
local _calendarHook = false
local function SkinCalendarDays()
    for i = 1, 42 do
        local day = _G["CalendarDayButton" .. i]
        if day then
            local d = GetFFD(day)
            if not d.bg then
                if day.SetNormalTexture then day:SetNormalTexture("") end
                local nt = day.GetNormalTexture and day:GetNormalTexture()
                if nt then nt:SetAlpha(0) end
                local bg = day:CreateTexture(nil, "BACKGROUND", nil, -8)
                bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
                bg:SetAllPoints(day)
                d.bg = bg
                WSkin.AddBorder(day)
            end
        end
    end
end

local function Skin_Calendar()
    local f = _G.CalendarFrame
    if not f then return end
    WSkin.Shell("calendar", f)
    -- Drop the shell's black top-bar strip (clashes with month header row); shell stores it in the engine's own FFD.
    local ed = WSkin.FFD and WSkin.FFD[f]
    if ed and ed.topBar and ed.topBar.SetAlpha then ed.topBar:SetAlpha(0) end
    WSkin.CommonChrome(f, "Calendar")
    if _G.CalendarCloseButton then WSkin.CloseButton(_G.CalendarCloseButton) end
    if _G.CalendarPrevMonthButton then WSkin.PageButton(_G.CalendarPrevMonthButton, "<", 16) end
    if _G.CalendarNextMonthButton then WSkin.PageButton(_G.CalendarNextMonthButton, ">", 16) end
    SkinCalendarDays()
    WSkin.ButtonsIn(f)
    WSkin.ScrollBarsIn(f)
    WSkin.FadeArtIn(f)

    -- Filter dropdown: left-align "Filters" label; it and the close button rise 10px (both sit low against the shell top bar).
    if f.FilterButton then
        LeftAlignFilterLabel(f.FilterButton)
        CalReseat(f.FilterButton, 10)
    end
    if _G.CalendarCloseButton then CalReseat(_G.CalendarCloseButton, 10) end

    -- Holiday view popup: style-aware shell backdrop (atlas/Modern flat, not a
    -- flat black panel), header art gone, no screen-dimming modal overlay, house close.
    local hf = _G.CalendarViewHolidayFrame
    if hf then
        local function SkinHoliday()
            WSkin.Shell("calendar", hf)
            if hf.Border and hf.Border.SetAlpha then hf.Border:SetAlpha(0) end
            if hf.Header then WSkin.FadeRegions(hf.Header) end
            local ov = _G.CalendarViewHolidayFrameModalOverlay
            if ov and ov.SetAlpha then ov:SetAlpha(0) end
            -- Header text: white, shifted down 5px (one-shot).
            local ht = hf.HeaderText or _G.CalendarViewHolidayFrameHeaderText
                or (hf.Header and hf.Header.Text)
            if ht then WSkin.Font(ht); WSkin.White(ht); CalReseat(ht, -5) end
            local cb = _G.CalendarViewHolidayCloseButton
            if cb then
                WSkin.CloseButton(cb)
                -- Nudge the house X glyph up 6px (one-shot).
                local xd = GetFFD(cb)
                if xd.x and not xd.xNudged then
                    xd.xNudged = true
                    xd.x:SetPoint("CENTER", -2, 6)
                end
            end
        end
        SkinHoliday()
        WSkin.HookShow(hf, WSkin.Debounce(SkinHoliday))
    end

    -- Create Event popup: STYLE-AWARE shell backdrop (a flat Panel would not
    -- match the other calendar popups), time/type dropdowns, title+invite
    -- inputs, top-right close, title down 5px, class-icon column right 3px,
    -- leftover Blizzard border sub-frame + divider hidden.
    local cef = _G.CalendarCreateEventFrame
    if cef then
        local function SkinCreateEvent()
            WSkin.Shell("calendar", cef)
            if cef.Header then WSkin.FadeRegions(cef.Header) end
            -- Stray art: border sub-frame (Bg+edges, hidden via alpha inheritance) and the divider.
            if cef.Border and cef.Border.SetAlpha then cef.Border:SetAlpha(0) end
            if _G.CalendarCreateEventDivider and _G.CalendarCreateEventDivider.SetAlpha then
                _G.CalendarCreateEventDivider:SetAlpha(0)
            end
            -- Dropdowns (event type + hour/minute/AM-PM + difficulty when shown).
            for _, k in ipairs({ "EventTypeDropdown", "HourDropdown", "MinuteDropdown",
                                 "AMPMDropdown", "DifficultyOptionDropdown" }) do
                if cef[k] then WSkin.Dropdown(cef[k]) end
            end
            if _G.CalendarCreateEventTitleEdit then WSkin.EditBox(_G.CalendarCreateEventTitleEdit) end
            if _G.CalendarCreateEventInviteEdit then WSkin.EditBox(_G.CalendarCreateEventInviteEdit) end
            -- Close button (top right): house X glyph nudged up 6px (one-shot).
            local cceCB = _G.CalendarCreateEventCloseButton
            if cceCB then
                WSkin.CloseButton(cceCB)
                local xd = GetFFD(cceCB)
                if xd.x and not xd.xNudged then
                    xd.xNudged = true
                    xd.x:SetPoint("CENTER", -2, 6)
                end
            end
            -- Action buttons + lock checkbox.
            for _, k in ipairs({ "CalendarCreateEventCreateButton", "CalendarCreateEventMassInviteButton",
                                 "CalendarCreateEventInviteButton", "CalendarCreateEventRaidInviteButton" }) do
                if _G[k] then WSkin.Button(_G[k]) end
            end
            -- borderInset 4: frame is larger than its check graphic, so the border must hug the visible box, not the frame.
            if _G.CalendarCreateEventLockEventCheck then
                WSkin.Checkbox(_G.CalendarCreateEventLockEventCheck, { borderInset = 4 })
            end
            local il = _G.CalendarCreateEventInviteList
            if il and il.ScrollBar then WSkin.ScrollBar(il.ScrollBar) end
            -- Title down 5px (find the header's title FontString).
            local titleFS = (cef.Header and cef.Header.Text) or _G.CalendarCreateEventTitle
            if not titleFS and cef.Header and cef.Header.GetRegions then
                local regions = { cef.Header:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r.GetObjectType and r:GetObjectType() == "FontString" then titleFS = r; break end
                end
            end
            if titleFS then CalReseat(titleFS, -5) end
            -- Class-icon column: button 1 anchors to the container, the rest
            -- chain off it, so nudging the container right 3px moves the whole column (one-shot).
            local ccc = _G.CalendarClassButtonContainer
            if ccc and not GetFFD(ccc).nudgedRight then
                local np = ccc:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = ccc:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + 3, y or 0 }
                end
                if ok then
                    GetFFD(ccc).nudgedRight = true
                    ccc:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; ccc:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            end
        end
        SkinCreateEvent()
        WSkin.HookShow(cef, WSkin.Debounce(SkinCreateEvent))
    end

    -- Event picker popup (day with multiple events): style-aware shell
    -- backdrop, leftover Blizzard border/button-bar/close-border gone, house
    -- close + scrollbar, title down 8px.
    local pf = _G.CalendarEventPickerFrame
    if pf then
        local function SkinEventPicker()
            WSkin.Shell("calendar", pf)
            if pf.Border and pf.Border.SetAlpha then pf.Border:SetAlpha(0) end
            for _, n in ipairs({ "CalendarEventPickerFrameButtonBackground",
                                 "CalendarEventPickerCloseButtonBorder" }) do
                local t = _G[n]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            if pf.Header then WSkin.FadeRegions(pf.Header) end
            -- Bottom text "Close" button, NOT a corner X: plain button + white label, no stray X glyph.
            local pcb = _G.CalendarEventPickerCloseButton
            if pcb then
                WSkin.Button(pcb)
                local cfs = pcb.GetFontString and pcb:GetFontString()
                if cfs then WSkin.White(cfs) end
            end
            local sb = pf.ScrollBar or _G.CalendarEventPickerFrameScrollBar
                or (pf.ScrollBox and pf.ScrollBox.ScrollBar)
            if sb then WSkin.ScrollBar(sb) end
            -- Title down 8px (header title FontString).
            local titleFS = (pf.Header and pf.Header.Text) or _G.CalendarEventPickerFrameTitle or pf.Title
            if not titleFS and pf.Header and pf.Header.GetRegions then
                local regions = { pf.Header:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r.GetObjectType and r:GetObjectType() == "FontString" then titleFS = r; break end
                end
            end
            if titleFS then CalReseat(titleFS, -8) end
        end
        SkinEventPicker()
        WSkin.HookShow(pf, WSkin.Debounce(SkinEventPicker))
    end

    if not _calendarHook and type(_G.CalendarFrame_Update) == "function" then
        _calendarHook = true
        hooksecurefunc("CalendarFrame_Update", WSkin.Debounce(function()
            if f:IsVisible() then SkinCalendarDays(); WSkin.Restrip() end
        end))
    end
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then SkinCalendarDays(); WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "calendar",
    addons = { Blizzard_Calendar = true },
    apply = Skin_Calendar,
})
end

-------------------------------------------------------------------------------
--  Achievements (AchievementFrame)
-------------------------------------------------------------------------------
do
-- White house-font text on a frame's direct FontString regions.
local function AchWhiteTexts(host)
    if not host or not host.GetRegions then return end
    local regions = { host:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("FontString") then
            WSkin.Font(r)
            WSkin.White(r)
        end
    end
end

local function AchWhiteTextsIn(host, depth)
    depth = depth or 0
    if not host or depth > 5 or host:IsForbidden() then return end
    if depth > 0 and WSkin.IsForeignFrame(host) then return end
    AchWhiteTexts(host)
    if not host.GetChildren then return end
    local children = { host:GetChildren() }
    for i = 1, #children do
        AchWhiteTextsIn(children[i], depth + 1)
    end
end

-- Progress bar -> flat accent bar (the professions-window look): cap/trough
-- art gone, accent fill, dark trough, 1px border, white labels.
local function AchAccentBar(bar)
    if not bar or bar:IsForbidden() then return end
    local d = GetFFD(bar)
    local fill = bar.GetStatusBarTexture and bar:GetStatusBarTexture()
    if fill then d.fill = fill end
    local keep = {}
    if d.fill then keep[d.fill] = true end
    if d.bg then keep[d.bg] = true end
    WSkin.FadeRegions(bar, keep)
    WSkin.Register(bar, true)
    if bar.SetStatusBarTexture then
        bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
        WSkin.ApplyBarFill(bar)
    end
    if not d.bg then
        local bg = bar:CreateTexture(nil, "BACKGROUND", nil, -1)
        bg:SetColorTexture(0.12, 0.12, 0.12, 0.85)
        bg:SetAllPoints(bar)
        d.bg = bg
        WSkin.AddBorder(bar)
    end
    local n = bar.GetName and bar:GetName()
    for _, key in ipairs({ "Title", "Label", "Text" }) do
        local fs = bar[key] or (n and _G[n .. key])
        if fs and fs.SetTextColor then
            WSkin.Font(fs)
            WSkin.White(fs)
            -- Bar text 3px lower (one-shot), as on professions bars: house font rides high on these.
            local rd = GetFFD(fs)
            if not rd.lowered then
                local p, rel, rp, x, y = fs:GetPoint(1)
                if p then
                    local offsetY = -3
                    if bar and bar.GetParent then
                        local parent = bar:GetParent()
                        -- Under AchievementFrameAchievementsObjectives, bar is the
                        -- progress bar itself (not the holder): match parent name, needs no offset.
                        if parent and parent.GetName and parent:GetName() == "AchievementFrameAchievementsObjectives" then
                            offsetY = 0
                        end
                    end
                    rd.lowered = true
                    fs:ClearAllPoints()
                    fs:SetPoint(p, rel, rp, x or 0, (y or 0) + offsetY)
                end
            end
        end
    end
end

-- Title tinted like the row art this pack strips: account-wide = blue,
-- character = gold; no completion date = the dimmed take on the same hue.
local function AchTitleColor(row)
    local fs = row.Label
    if not fs or not fs.SetTextColor then return end
    local done = row.DateCompleted and row.DateCompleted.IsShown and row.DateCompleted:IsShown()
    if row.accountWide then
        if done then fs:SetTextColor(0.35, 0.75, 1) else fs:SetTextColor(0.24, 0.46, 0.6) end
    else
        if done then fs:SetTextColor(1, 0.85, 0.35) else fs:SetTextColor(0.64, 0.56, 0.3) end
    end
end

-- Hold a texture permanently invisible against Blizzard's re-raises: a
-- reentry-guarded SetAlpha post-hook forces it back to 0 (a plain SetAlpha(0)
-- is reverted by the next row re-init on expand/select). Taint-safe (hooksecurefunc only).
local function KillTex(t)
    if not t or not t.SetAlpha then return end
    t:SetAlpha(0)
    local td = GetFFD(t)
    if td.killed then return end
    td.killed = true
    hooksecurefunc(t, "SetAlpha", function(self)
        local dd = GetFFD(self)
        if dd.inKill then return end
        dd.inKill = true
        self:SetAlpha(0)
        dd.inKill = false
    end)
end

-- Lock a fontstring to the house font + a color, re-applied whenever Blizzard
-- swaps its font object or recolors it (the achievement list reverts BOTH on
-- expand/select). colorFn(fs) applies the color, nil = white. One-time hooks per string.
local function LockAchText(fs, colorFn)
    if not fs or not fs.SetFont then return end
    local fd = GetFFD(fs)
    fd.colorFn = colorFn
    local function reapply()
        if fd.inLock then return end
        fd.inLock = true
        WSkin.Font(fs)
        if fd.colorFn then fd.colorFn(fs) else WSkin.White(fs) end
        fd.inLock = false
    end
    reapply()
    if not fd.textLocked then
        fd.textLocked = true
        if fs.SetFontObject then hooksecurefunc(fs, "SetFontObject", reapply) end
        hooksecurefunc(fs, "SetFont", reapply)
        if fs.SetTextColor then hooksecurefunc(fs, "SetTextColor", reapply) end
    end
end

-- Kill every Blizzard TEXTURE on the row (keyed + anon), sparing our bg+hover
-- and all fontstrings. NineSlice is a child FRAME, not a direct region: kill it whole (alpha inherits to Center+edges).
local function KillAchRowArt(row, d)
    local regions = { row:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= d.bg and r ~= d.hover and r.IsObjectType and r:IsObjectType("Texture") then
            KillTex(r)
        end
    end
    if row.NineSlice then KillTex(row.NineSlice) end
    if row.Icon and row.Icon.frame then KillTex(row.Icon.frame) end
    if row.Check then KillTex(row.Check) end
end

-- Achievement row (main + summary list): parchment/glow art gone, flat block +
-- subtle hover, squared icon, white house-font text. Art and text must be
-- LOCKED (KillTex/LockAchText); a per-pass re-fade loses the race against Blizzard's re-init on expand/select.
local function SkinAchRow(row)
    if not row or row:IsForbidden() then return end
    local d = GetFFD(row)
    if not d.bg then
        local bg = row:CreateTexture(nil, "BACKGROUND", nil, -3)
        bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        bg:SetPoint("TOPLEFT", 1, -1)
        bg:SetPoint("BOTTOMRIGHT", -1, 1)
        d.bg = bg
        WSkin.AddBorder(row)
        local hov = SolidTex(row, "HIGHLIGHT", 1, 1, 1, 0.08)
        hov:SetAllPoints(row)
        d.hover = hov
        WSkin.Register(row, true)
        if row.Icon and row.Icon.texture then WSkin.SquareIcon(row.Icon.texture, row.Icon) end
        -- Text locks: Label keeps its per-state color, the rest go white.
        -- HiddenDescription is the FULL description swapped in on expand
        -- (collapsed row shows truncated Description) and must be locked too, or it reverts on click.
        LockAchText(row.Label, function() AchTitleColor(row) end)
        LockAchText(row.Description, nil)
        LockAchText(row.HiddenDescription, nil)
        LockAchText(row.DateCompleted, nil)
        if row.Shield and row.Shield.Points then LockAchText(row.Shield.Points, nil) end
        if row.DisplayObjectives then
            hooksecurefunc(row, "DisplayObjectives", function(rw)
                -- Expand rebuilds the row art: re-kill it and re-color the title
                -- (completed state can flip on expand); font/color locks hold the
                -- rest. Immediate + next-frame catches a deferred re-show.
                local rd = GetFFD(rw)
                KillAchRowArt(rw, rd)
                AchTitleColor(rw)
                if C_Timer then C_Timer.After(0, function()
                    KillAchRowArt(rw, rd); AchTitleColor(rw)
                end) end
                local ok, of = pcall(rw.GetObjectiveFrame, rw)
                if ok and of and of.progressBars then
                    for _, b in pairs(of.progressBars) do AchAccentBar(b) end
                end
            end)
        end
    end
    KillAchRowArt(row, d)
    AchTitleColor(row)
end

-- Category list row (left side): the clickable is the child's Button.
local function SkinCategoryRow(child)
    local btn = child and child.Button
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    if not d.bg then
        local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -3)
        bg:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
        bg:SetPoint("TOPLEFT", 1, -1)
        bg:SetPoint("BOTTOMRIGHT", -1, 1)
        d.bg = bg
        WSkin.AddBorder(btn)
        local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetAllPoints(btn)
        d.hover = hov
        WSkin.Register(btn, true)
    end
    -- Pooled rows: re-fade the native art every pass (see SkinAchRow).
    if btn.Background and btn.Background.SetAlpha then btn.Background:SetAlpha(0) end
    local keep = {}
    if d.bg then keep[d.bg] = true end
    if d.hover then keep[d.hover] = true end
    WSkin.FadeRegions(btn, keep)
    if btn.Label then
        WSkin.White(btn.Label)
        -- Category labels sit low in the house font: raise 3px (one-shot).
        -- Label is pinned by BOTH edges, so EVERY anchor must survive the shift
        -- or the text collapses onto its remaining pin.
        local rd = GetFFD(btn.Label)
        if not rd.raised then
            local fsn = btn.Label
            local numPts = fsn:GetNumPoints()
            if numPts and numPts > 0 then
                local pts, ok = {}, true
                for i = 1, numPts do
                    local p, rel, rp, x, y = fsn:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + 3 }
                end
                if ok then
                    rd.raised = true
                    fsn:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        fsn:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
        end
    end
end

-- Statistics row: art gone, subtle hover, white text.
local function SkinStatRow(child)
    if not child or child:IsForbidden() then return end
    local d = GetFFD(child)
    if not d.statSkinned then
        d.statSkinned = true
        WSkin.FadeRegions(child)
        WSkin.Register(child, true)
        local hov = SolidTex(child, "HIGHLIGHT", 1, 1, 1, 0.08)
        hov:SetAllPoints(child)
        d.hover = hov
    end
    AchWhiteTexts(child)
end

-- Search result row (popout list): flat + hover, squared icon, white text.
local function SkinResultRow(child)
    if not child or child:IsForbidden() then return end
    local d = GetFFD(child)
    if not d.bg then
        local bg = child:CreateTexture(nil, "BACKGROUND", nil, -3)
        bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        bg:SetAllPoints(child)
        d.bg = bg
        local hov = SolidTex(child, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetAllPoints(child)
        d.hover = hov
        WSkin.Register(child, true)
        if child.Icon then WSkin.SquareIcon(child.Icon) end
    end
    -- Pooled rows: re-fade the native art every pass (see SkinAchRow).
    local keep = {}
    if d.bg then keep[d.bg] = true end
    if d.hover then keep[d.hover] = true end
    WSkin.FadeRegions(child, keep)
    AchWhiteTexts(child)
end

-- Search preview button (dropdown under the search box).
local function SkinPreviewBtn(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    if not d.bg then
        local icon = btn.icon or btn.Icon
        local keep = icon and { [icon] = true } or nil
        WSkin.FadeRegions(btn, keep)
        local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -3)
        bg:SetColorTexture(0.05, 0.05, 0.05, 0.95)
        bg:SetAllPoints(btn)
        d.bg = bg
        WSkin.AddBorder(btn)
        local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetAllPoints(btn)
        d.hover = hov
        WSkin.Register(btn, keep or true)
        if icon then WSkin.SquareIcon(icon, btn) end
    end
    AchWhiteTexts(btn)
end

local _achSummaryHook = false
local _achCritHook = false
local function Skin_Achievements()
    local f = _G.AchievementFrame
    if not f then return end
    -- Frame rect extends above the visible panel (floating points header), so
    -- the shell skips its border to avoid a line drawn across mid-air.
    WSkin.Shell("achievements", f, { noBorder = true })
    WSkin.CommonChrome(f, "AchievementFrame")

    -- Header banner: art gone, title+points in house font on a flat plate.
    -- Plate anchors to the TEXT (resizes with tab title), sits a frame level
    -- lower so it draws under the strings.
    local host = f.Header or _G.AchievementFrameHeader
    if host then
        WSkin.FadeRegions(host)
        WSkin.Register(host, true)
        local title = host.Title or _G.AchievementFrameHeaderTitle
        local points = host.Points or _G.AchievementFrameHeaderPoints
        if title then WSkin.Font(title); WSkin.White(title) end
        if points then WSkin.Font(points); WSkin.White(points) end
        local hd = GetFFD(host)
        if not hd.plate and title and points then
            local plate = CreateFrame("Frame", nil, host)
            plate:SetFrameLevel(math.max(0, host:GetFrameLevel() - 1))
            plate:SetPoint("TOP", title, "TOP", 0, 9)
            plate:SetPoint("BOTTOM", points, "BOTTOM", 0, -9)
            plate:SetPoint("LEFT", title, "LEFT", -28, 0)
            plate:SetPoint("RIGHT", title, "RIGHT", 28, 0)
            local fill = SolidTex(plate, "BACKGROUND", 0, 0, 0, 1)
            fill:SetAllPoints(plate)
            hd.plateFill = fill
            WSkin.AddBorder(plate)
            hd.plate = plate
        end
    end
    -- Plate fill per style: eui = #070604 opaque, Modern = #050505 at the
    -- user's Modern backdrop opacity. Re-tinted every show so style/opacity edits carry over.
    local function RetintHeaderPlate()
        local hd2 = host and FFD[host]
        local fillTex = hd2 and hd2.plateFill
        if not fillTex then return end
        if WSkin.GetStyle("achievements") == "modern" then
            local _, _, _, ma = WSkin.GetModernBG()
            fillTex:SetColorTexture(0.0196, 0.0196, 0.0196, ma or 1)
        else
            fillTex:SetColorTexture(0.0275, 0.0235, 0.0157, 1)
        end
    end
    RetintHeaderPlate()
    for _, name in ipairs({
        "AchievementFrameMetalBorderTop", "AchievementFrameMetalBorderBottom",
        "AchievementFrameMetalBorderLeft", "AchievementFrameMetalBorderRight",
        "AchievementFrameMetalBorderTopLeft", "AchievementFrameMetalBorderTopRight",
        "AchievementFrameMetalBorderBottomLeft", "AchievementFrameMetalBorderBottomRight",
        "AchievementFrameWoodBorderTopLeft", "AchievementFrameWoodBorderTopRight",
        "AchievementFrameWoodBorderBottomLeft", "AchievementFrameWoodBorderBottomRight",
        "AchievementFrameWaterMark", "AchievementFrameStatsBG" }) do
        local t = _G[name]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    for _, name in ipairs({ "AchievementFrameSummary", "AchievementFrameAchievements",
                            "AchievementFrameAchievementsContainer", "AchievementFrameCategories",
                            "AchievementFrameCategoriesContainer", "AchievementFrameStats",
                            "AchievementFrameComparison" }) do
        local sub = _G[name]
        if sub then WSkin.FadeRegions(sub); WSkin.Register(sub, true) end
    end
    -- Every list pane wraps content in an anonymous inset child whose NineSlice
    -- is the box art, so fade any such child. Swept again on show: some panes only build theirs when first opened.
    local function SweepInsetChildren()
        for _, name in ipairs({ "AchievementFrameSummary", "AchievementFrameStats",
                                "AchievementFrameAchievements", "AchievementFrameCategories",
                                "AchievementFrameComparison" }) do
            local sub = _G[name]
            if sub then
                local children = { sub:GetChildren() }
                for i = 1, #children do
                    local c = children[i]
                    if c and c.NineSlice and not WSkin.IsForeignFrame(c, sub) then
                        WSkin.FadeNineSlice(c.NineSlice)
                        WSkin.FadeRegions(c)
                        WSkin.Register(c, true)
                    end
                end
            end
        end
    end
    SweepInsetChildren()

    -- Search box: tucked into the top bar's right side, filter dropdown left.
    local sbx = f.SearchBox
    if sbx then
        WSkin.EditBox(sbx)
        local sd = GetFFD(sbx)
        if not sd.moved then
            sd.moved = true
            sbx:ClearAllPoints()
            sbx:SetPoint("TOPRIGHT", f, "TOPRIGHT", -28, -3)
            sbx:SetSize(150, 19)
        end
    end
    local filt = f.FilterDropdown or _G.AchievementFrameFilterDropdown
    if filt then
        WSkin.Dropdown(filt)
        local fd = GetFFD(filt)
        if not fd.moved then
            fd.moved = true
            filt:ClearAllPoints()
            filt:SetPoint("TOPLEFT", f, "TOPLEFT", 26, -3)
        end
        -- Label pinned left (this dropdown only), clear of the arrow.
        local lab = filt.Text or (filt.GetFontString and filt:GetFontString())
        if lab and not fd.labLeft then
            fd.labLeft = true
            lab:ClearAllPoints()
            lab:SetPoint("LEFT", filt, "LEFT", 8, 0)
            lab:SetPoint("RIGHT", filt, "RIGHT", -22, 0)
            if lab.SetJustifyH then lab:SetJustifyH("LEFT") end
        end
    end

    -- Search preview popout + full results panel.
    local pv = f.SearchPreviewContainer
    if pv then
        WSkin.FadeRegions(pv)
        WSkin.Register(pv, true)
        for i = 1, 5 do SkinPreviewBtn(pv["SearchPreview" .. i]) end
        SkinPreviewBtn(pv.ShowAllSearchResults)
    end
    local sr = f.SearchResults
    if sr then
        WSkin.Panel(sr)
        local rb = sr.ScrollBox
        if rb and rb.ForEachFrame then
            pcall(rb.ForEachFrame, rb, SkinResultRow)
            if rb.Update and not GetFFD(rb).rowHook then
                GetFFD(rb).rowHook = true
                hooksecurefunc(rb, "Update", function(box) pcall(box.ForEachFrame, box, SkinResultRow) end)
            end
        end
    end

    local sweepOnTab = WSkin.Debounce(function()
        if f:IsVisible() then SweepInsetChildren(); WSkin.Restrip() end
    end)
    local achTabs = {}
    for i = 1, 3 do
        local t = _G["AchievementFrameTab" .. i]
        if t then
            WSkin.Tab(t)
            achTabs[#achTabs + 1] = t
            if not GetFFD(t).sweepHook then
                GetFFD(t).sweepHook = true
                t:HookScript("OnClick", sweepOnTab)
            end
        end
    end
    WSkin.NormalizeTabRow(achTabs)
    -- Comparison mode toggles tabs in this row: the normalize pass skips a
    -- hidden tab, then Blizzard seats it with stock anchors on show, landing on
    -- top of the tab our chain already placed. Re-chain synchronously whenever Blizzard moves/toggles any of them.
    do
        local fd = GetFFD(f)
        if not fd.tabNormHook then
            fd.tabNormHook = true
            local guard = false
            local function ReNorm()
                if guard then return end
                guard = true
                WSkin.NormalizeTabRow(achTabs)
                guard = false
            end
            for _, t in ipairs(achTabs) do
                hooksecurefunc(t, "SetPoint", ReNorm)
                t:HookScript("OnShow", ReNorm)
                t:HookScript("OnHide", ReNorm)
            end
        end
    end
    WSkin.ScrollBarsIn(f)

    -- List rows are ScrollBox-pooled; restyle realized rows on every list update (cost scales with visible rows only).
    local function HookRows(hostFrame, fn)
        local sb = hostFrame and hostFrame.ScrollBox
        if not (sb and sb.ForEachFrame) then return end
        pcall(sb.ForEachFrame, sb, fn)
        if sb.Update and not GetFFD(sb).rowHook then
            GetFFD(sb).rowHook = true
            hooksecurefunc(sb, "Update", function(box) pcall(box.ForEachFrame, box, fn) end)
        end
    end
    HookRows(_G.AchievementFrameCategories, SkinCategoryRow)
    HookRows(_G.AchievementFrameAchievements, SkinAchRow)
    HookRows(_G.AchievementFrameStats, SkinStatRow)

    -- Category sidebar sits 10px lower as a unit: shift its ScrollBox once, preserving every anchor.
    local catBox = _G.AchievementFrameCategories and _G.AchievementFrameCategories.ScrollBox
    if catBox and not GetFFD(catBox).shifted then
        local numPts = catBox:GetNumPoints()
        if numPts and numPts > 0 then
            local pts, ok = {}, true
            for i = 1, numPts do
                local p, rel, rp, x, y = catBox:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 10 }
            end
            if ok then
                GetFFD(catBox).shifted = true
                catBox:ClearAllPoints()
                for i = 1, #pts do
                    local t = pts[i]
                    catBox:SetPoint(t[1], t[2], t[3], t[4], t[5])
                end
            end
        end
    end

    -- Achievement list (non-summary pages) drops 10px the same way.
    local achBox = _G.AchievementFrameAchievements and _G.AchievementFrameAchievements.ScrollBox
    if achBox and not GetFFD(achBox).shifted then
        local numPts = achBox:GetNumPoints()
        if numPts and numPts > 0 then
            local pts, ok = {}, true
            for i = 1, numPts do
                local p, rel, rp, x, y = achBox:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 10 }
            end
            if ok then
                GetFFD(achBox).shifted = true
                achBox:ClearAllPoints()
                for i = 1, #pts do
                    local t = pts[i]
                    achBox:SetPoint(t[1], t[2], t[3], t[4], t[5])
                end
            end
        end
    end

    -- Summary page: heading strips faint white, summary text white house font,
    -- recent-achievement cards through row skin, 12 category bars + total bar as flat accent bars.
    for _, tn in ipairs({ "AchievementFrameSummaryAchievementsHeaderHeader",
                          "AchievementFrameSummaryCategoriesHeaderTexture" }) do
        local t = _G[tn]
        if t and t.SetVertexColor then t:SetVertexColor(1, 1, 1, 0.25) end
    end
    for i = 1, 12 do
        local bar = _G["AchievementFrameSummaryCategoriesCategory" .. i]
        if bar then
            AchAccentBar(bar)
            local hl = _G["AchievementFrameSummaryCategoriesCategory" .. i .. "ButtonHighlight"]
            if hl and hl.SetAlpha then hl:SetAlpha(0) end
        end
    end
    AchAccentBar(_G.AchievementFrameSummaryCategoriesStatusBar)
    if _G.AchievementFrameSummary then AchWhiteTextsIn(_G.AchievementFrameSummary) end
    if not _achSummaryHook and type(_G.AchievementFrameSummary_UpdateAchievements) == "function" then
        _achSummaryHook = true
        hooksecurefunc("AchievementFrameSummary_UpdateAchievements", WSkin.Debounce(function()
            local maxSum = _G.ACHIEVEMENTUI_MAX_SUMMARY_ACHIEVEMENTS or 4
            for i = 1, maxSum do SkinAchRow(_G["AchievementFrameSummaryAchievement" .. i]) end
        end))
    end

    -- Comparison view: header art gone, both summary bars as accent bars, dual player/friend cards+stat rows through pooled-row skins.
    local comp = _G.AchievementFrameComparison
    if comp then
        for _, tn in ipairs({ "AchievementFrameComparisonHeaderBG",
                              "AchievementFrameComparisonHeaderPortrait",
                              "AchievementFrameComparisonHeaderPortraitBg" }) do
            local t = _G[tn]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local compHdr = _G.AchievementFrameComparisonHeader
        if compHdr then
            WSkin.FadeRegions(compHdr)
            WSkin.Register(compHdr, true)
            AchWhiteTexts(compHdr)
        end
        -- Compared character's name sits in the top bar, left of the search box.
        local compName = _G.AchievementFrameComparisonHeaderName
        if compName and f.SearchBox and not GetFFD(compName).moved then
            GetFFD(compName).moved = true
            compName:ClearAllPoints()
            compName:SetPoint("RIGHT", f.SearchBox, "LEFT", -10, 0)
        end
        -- Their points ride NEXT TO the name in the user's link color, retinted whenever Blizzard rewrites the value.
        local compPts = _G.AchievementFrameComparisonHeaderPoints
        if compPts and compName and not GetFFD(compPts).moved then
            GetFFD(compPts).moved = true
            compPts:ClearAllPoints()
            compPts:SetPoint("LEFT", compName, "RIGHT", 6, 0)
            local function TintComparePoints()
                local lr, lg, lb = WSkin.LinkColor()
                compPts:SetTextColor(lr, lg, lb)
            end
            TintComparePoints()
            hooksecurefunc(compPts, "SetText", TintComparePoints)
            if compPts.SetFormattedText then
                hooksecurefunc(compPts, "SetFormattedText", TintComparePoints)
            end
        end
        local function SkinCompareCard(card)
            if not card or card:IsForbidden() then return end
            local cdd = GetFFD(card)
            if not cdd.bg then
                local bg = card:CreateTexture(nil, "BACKGROUND", nil, -3)
                bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
                bg:SetPoint("TOPLEFT", 1, -1)
                bg:SetPoint("BOTTOMRIGHT", -1, 1)
                cdd.bg = bg
                WSkin.AddBorder(card)
                WSkin.Register(card, true)
                if card.Icon and card.Icon.texture then
                    WSkin.SquareIcon(card.Icon.texture, card.Icon)
                end
            end
            -- Pooled: re-fade the native art + retint text every pass.
            for _, k in ipairs({ "Background", "TitleBar", "Glow", "Highlight" }) do
                local t = card[k]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            local keep = {}
            if cdd.bg then keep[cdd.bg] = true end
            WSkin.FadeRegions(card, keep)
            if card.Icon and card.Icon.frame and card.Icon.frame.SetAlpha then
                card.Icon.frame:SetAlpha(0)
            end
            AchWhiteTexts(card)
            for _, key in ipairs({ "Label", "Description", "DateCompleted" }) do
                local fs = card[key]
                if fs and fs.SetTextColor then WSkin.Font(fs); WSkin.White(fs) end
            end
        end
        local function SkinCompareRow(child)
            if not child then return end
            SkinCompareCard(child.Player)
            SkinCompareCard(child.Friend)
        end
        local ac = comp.AchievementContainer
        if ac then
            if ac.ScrollBar then WSkin.ScrollBar(ac.ScrollBar) end
            local box = ac.ScrollBox
            if box and box.ForEachFrame then
                pcall(box.ForEachFrame, box, SkinCompareRow)
                if box.Update and not GetFFD(box).rowHook then
                    GetFFD(box).rowHook = true
                    hooksecurefunc(box, "Update", function(b2)
                        pcall(b2.ForEachFrame, b2, SkinCompareRow)
                    end)
                end
            end
        end
        local sc = comp.StatContainer
        if sc then
            if sc.ScrollBar then WSkin.ScrollBar(sc.ScrollBar) end
            local box = sc.ScrollBox
            if box and box.ForEachFrame then
                pcall(box.ForEachFrame, box, SkinStatRow)
                if box.Update and not GetFFD(box).rowHook then
                    GetFFD(box).rowHook = true
                    hooksecurefunc(box, "Update", function(b2)
                        pcall(b2.ForEachFrame, b2, SkinStatRow)
                    end)
                end
            end
        end
        local summ = comp.Summary
        if summ then
            WSkin.FadeRegions(summ)
            WSkin.Register(summ, true)
            for _, side in ipairs({ summ.Player, summ.Friend }) do
                if side then
                    WSkin.FadeRegions(side)
                    WSkin.Register(side, true)
                    if side.StatusBar then AchAccentBar(side.StatusBar) end
                end
            end
        end
    end

    -- Criteria lines default to dark parchment ink: recolor on display, completed = white, incomplete = gray.
    if not _achCritHook and type(_G.AchievementObjectives_DisplayCriteria) == "function" then
        _achCritHook = true
        hooksecurefunc("AchievementObjectives_DisplayCriteria", function(of, id)
            if not (of and id) or (of.IsForbidden and of:IsForbidden()) then return end
            local num = GetAchievementNumCriteria and GetAchievementNumCriteria(id)
            if not num then return end
            local texts, metas = 0, 0
            local barFlag = _G.EVALUATION_TREE_FLAG_PROGRESS_BAR or 1
            for i = 1, num do
                local _, cType, completed, _, _, _, flags, assetID = GetAchievementCriteriaInfo(id, i)
                local fs
                if assetID and cType == _G.CRITERIA_TYPE_ACHIEVEMENT then
                    metas = metas + 1
                    local ok, m = pcall(of.GetMeta, of, metas)
                    fs = ok and m and m.Label
                elseif bit.band(flags or 0, barFlag) ~= barFlag then
                    texts = texts + 1
                    local ok, c = pcall(of.GetCriteria, of, texts)
                    fs = ok and c and c.Name
                end
                if fs and fs.SetTextColor then
                    -- Lines are (re)created in Blizzard's font on display: force house font too, not just color.
                    WSkin.Font(fs)
                    if completed then fs:SetTextColor(1, 1, 1) else fs:SetTextColor(0.65, 0.65, 0.65) end
                end
            end
        end)
    end

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then
            -- Re-run realized-row passes: first population can land before any ScrollBox Update the hooks see.
            HookRows(_G.AchievementFrameCategories, SkinCategoryRow)
            HookRows(_G.AchievementFrameAchievements, SkinAchRow)
            HookRows(_G.AchievementFrameStats, SkinStatRow)
            if _G.AchievementFrameSummary then AchWhiteTextsIn(_G.AchievementFrameSummary) end
            SweepInsetChildren()
            RetintHeaderPlate()
            WSkin.Restrip()
            WSkin.UpdateAllTabs()
        end
    end))
end

WSkin.RegisterWindow({
    key = "achievements",
    addons = { Blizzard_AchievementUI = true },
    apply = Skin_Achievements,
})
end

-------------------------------------------------------------------------------
--  Mail (MailFrame + OpenMailFrame)
-------------------------------------------------------------------------------
-- Labeled prev/next page button (mail inbox, merchant): house page-arrow
-- block, box 4px smaller (13px arrow re-centers), 3px left plus any per-button
-- nudge, native "Prev"/"Next" label hidden. That label is a font-string REGION,
-- not the designated GetFontString, so every font string fades; size/shift is one-shot, label fade re-runs per pass.
local function SkinLabeledPageButton(btn, ch, extraX)
    if not btn then return end
    WSkin.PageButton(btn, ch, 13)
    local pd = GetFFD(btn)
    if not pd.adjusted then
        pd.adjusted = true
        local w, h = btn:GetSize()
        if w and h and w > 4 and h > 4 then btn:SetSize(w - 4, h - 4) end
        local np = btn:GetNumPoints() or 0
        local pts, ok = {}, np > 0
        for i = 1, np do
            local p, rel, rp, x, y = btn:GetPoint(i)
            if not p then ok = false break end
            pts[i] = { p, rel, rp, (x or 0) - 3 + (extraX or 0), y or 0 }
        end
        if ok then
            btn:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; btn:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
        end
    end
    -- Per-pass: hide label font strings AND plain texture regions -- merchant
    -- buttons carry box art as anonymous regions PageButton's Normal/Pushed/
    -- Highlight fade never touches. Our arrow/fill/hover spared by identity.
    local regions = { btn:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= pd.arrow and r ~= pd.bg and r ~= pd.hover and r.IsObjectType
           and (r:IsObjectType("FontString") or r:IsObjectType("Texture")) then
            r:SetAlpha(0)
        end
    end
end

-- `quality` opts the button into the SQUARE rarity border instead of the plain
-- black one. OPT-IN because this helper is shared: the merchant grid passes it,
-- MAIL deliberately does not. Mail rows have no other rarity cue and Blizzard's
-- rounded ring is the only one they get, so flipping it there is a visual
-- change nobody asked for -- it is a one-word change if that is ever wanted.
local function SkinMailItemButton(b, quality)
    if not b or b:IsForbidden() then return end
    local nt = b.GetNormalTexture and b:GetNormalTexture()
    if nt and nt.SetAlpha then nt:SetAlpha(0) end
    local bn = b.GetName and b:GetName()
    local slot = bn and _G[bn .. "Slot"]
    if slot and slot.SetAlpha then slot:SetAlpha(0) end
    -- IconBorder is the item-quality color ring. Left to Blizzard without
    -- `quality`; with it, the ROUNDED ring is stripped and its color is read
    -- back onto a square border, so the tile keeps the rarity and loses the
    -- round art. Alpha 0 does not hide it from the read -- WSkin.RingQuality
    -- goes by shown state and vertex color.
    local icon = b.Icon or b.icon or (bn and _G[bn .. "IconTexture"])
    if quality then
        local ring = b.IconBorder or (bn and _G[bn .. "IconBorder"])
        if ring and ring.SetAlpha then ring:SetAlpha(0) end
    end
    if icon then WSkin.SquareIcon(icon, b, quality) end
end

do
-- Inbox row: parchment gone, flat block, white sender/subject, squared icon.
local function SkinMailRow(row)
    if not row or row:IsForbidden() then return end
    local d = GetFFD(row)
    if not d.bg then
        WSkin.FadeRegions(row)
        local bg = row:CreateTexture(nil, "BACKGROUND", nil, -7)
        bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        bg:SetPoint("TOPLEFT", 2, -1)
        bg:SetPoint("BOTTOMRIGHT", -2, 3)
        d.bg = bg
        WSkin.AddBorder(row)
    end
    local name = row.GetName and row:GetName()
    if name then
        -- Sender and subject show other players' writing: font families, which
        -- draw the scripts the house font lacks
        local sender = _G[name .. "Sender"]
        if sender then WSkin.FontFamily(sender); WSkin.White(sender) end
        -- Subject is the item name for item mail: font only, no forced white, so Blizzard's item-quality color shows.
        local subject = _G[name .. "Subject"]
        if subject then WSkin.FontFamily(subject) end
    end
    if row.Button then SkinMailItemButton(row.Button) end
end

-- Auction-house invoices and crafting-order mail are their own panels (not the
-- letter body), drawn in InvoiceTextFontNormal: a dark brown meant for the
-- stationery parchment this pack fades. Re-font and whiten them.
local INVOICE_TEXT = {
    "OpenMailInvoiceItemLabel", "OpenMailInvoicePurchaser", "OpenMailInvoiceSalePrice",
    "OpenMailInvoiceDeposit", "OpenMailInvoiceHouseCut", "OpenMailInvoiceAmountReceived",
    "OpenMailInvoiceNotYetSent", "OpenMailInvoiceMoneyDelay",
}
local CONSORTIUM_TEXT = {
    "OpeningText", "CrafterText", "CommissionReceived", "CrafterNote", "ConsortiumNote",
}
-- Only money frames declaring an inline +/-/count font string (amounts live on child frames, see SkinMoneyFrameText).
local INVOICE_MONEY = {
    "OpenMailDepositMoneyFrame", "OpenMailHouseCutMoneyFrame", "OpenMailSalePriceMoneyFrame",
}

local function SkinInvoiceFS(fs)
    if not fs or (fs.IsForbidden and fs:IsForbidden()) then return end
    WSkin.Font(fs)
    WSkin.White(fs)
end

-- +/- signs and stack count are unnamed font strings parented straight to the
-- money frames, so sweeping direct regions gets those and nothing else. Amounts
-- live on Gold/Silver/CopperButton children driven by SetNormalFontObject,
-- re-applied every update by SetMoneyFrameColor: they deliberately keep
-- Blizzard's number font (SetFont here is clobbered) and the house-cut/commission red.
local function SkinMoneyFrameText(mf)
    if not mf or mf:IsForbidden() then return end
    local regions = { mf:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("FontString") then SkinInvoiceFS(r) end
    end
end

-- The invoice arithmetic rule is parchment art (thin line in a mostly
-- transparent 256x32 box) and AMOUNT_RECEIVED anchors to that box. It cannot
-- be recolored (a multiply keeps the orange) nor turned into a color texture
-- (the box fills and resizing drags the anchor). Fade the art, keep the box as an invisible spacer, run our own rule through it.
local function SkinArithmeticLine()
    local art = _G.OpenMailArithmeticLine
    if not art or art:IsForbidden() then return end
    art:SetAlpha(0)
    local d = GetFFD(art)
    if d.rule then return end
    local parent = art:GetParent()
    if not parent then return end
    d.rule = SolidTex(parent, "OVERLAY", Theme.brdR, Theme.brdG, Theme.brdB, Theme.brdA)
    d.rule:SetHeight(1)
    d.rule:SetPoint("LEFT", art, "LEFT", 0, 0)
    d.rule:SetPoint("RIGHT", art, "RIGHT", 0, 0)
end

local function SkinInvoiceText()
    for _, n in ipairs(INVOICE_TEXT) do SkinInvoiceFS(_G[n]) end
    for _, n in ipairs(INVOICE_MONEY) do SkinMoneyFrameText(_G[n]) end
    SkinArithmeticLine()
    local cm = _G.ConsortiumMailFrame
    if not cm or cm:IsForbidden() then return end
    for _, k in ipairs(CONSORTIUM_TEXT) do SkinInvoiceFS(cm[k]) end
    local paid = cm.CommissionPaidDisplay
    if paid then
        SkinInvoiceFS(paid.CommissionPaidText)
        SkinMoneyFrameText(paid.MoneyDisplayFrame)
        -- Plain 1px color texture, so it themes in place like the rule above.
        if paid.Separator then
            paid.Separator:SetColorTexture(Theme.brdR, Theme.brdG, Theme.brdB, Theme.brdA)
        end
    end
end

-- Letter body: force readable white + skin font on the SimpleHTML elements. The
-- body is another player's writing, so the font is a family (no shadow, as
-- Blizzard's own mail font): the skin font draws what it has, the client's own
-- faces the scripts it lacks. The colour goes on after the font.
local function WhitenMailText()
    local html = _G.OpenMailBodyText
    if html and html.SetTextColor then
        local fp = Theme.fontPath
        local ff = Theme.fontFlag or ""
        for _, el in ipairs({ "P", "H1", "H2", "H3" }) do
            if fp and html.GetFont then
                local ok, _, sz = pcall(html.GetFont, html, el)
                if ok and not issecretvalue(sz) and type(sz) == "number" then
                    local fam = html.SetFontObject and EllesmereUI.GetFontFamily(fp, sz, ff, false)
                    if not (fam and pcall(html.SetFontObject, html, el, fam)) then
                        pcall(html.SetFont, html, el, fp, sz, ff)
                    end
                end
            end
            pcall(html.SetTextColor, html, el, 1, 1, 1)
        end
    end
    -- The letter's subject and sender: font families (other players' writing)
    if _G.OpenMailSubject then WSkin.FontFamily(_G.OpenMailSubject); WSkin.White(_G.OpenMailSubject) end
    local sender = _G.OpenMailSender
    if sender and sender.Name then WSkin.FontFamily(sender.Name); WSkin.White(sender.Name) end
    SkinInvoiceText()
end

local function Skin_OpenMail()
    local f = _G.OpenMailFrame
    if not f then return end
    WSkin.Shell("mail", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "OpenMailFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.OpenMailFrameBg then _G.OpenMailFrameBg:SetAlpha(0) end
    if f.Inset then WSkin.Inset(f.Inset) end
    WSkin.FadeKeyedArt(f)
    for _, n in ipairs({ "OpenStationeryBackgroundLeft", "OpenStationeryBackgroundRight", "OpenMailHorizontalBarLeft" }) do
        local t = _G[n]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    for _, n in ipairs({ "OpenMailReplyButton", "OpenMailDeleteButton",
                         "OpenMailCancelButton", "OpenMailReportSpamButton" }) do
        local b = _G[n]
        if b then WSkin.Button(b) end
    end
    SkinMailItemButton(_G.OpenMailLetterButton)
    SkinMailItemButton(_G.OpenMailMoneyButton)
    for i = 1, 16 do SkinMailItemButton(_G["OpenMailAttachmentButton" .. i]) end
    WhitenMailText()
end

local _mailHook = false
local function Skin_Mail()
    local f = _G.MailFrame
    if not f then return end
    WSkin.Shell("mail", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "MailFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.MailFrameBg then _G.MailFrameBg:SetAlpha(0) end
    if f.Inset then WSkin.Inset(f.Inset) end

    -- Inbox
    if _G.InboxFrameBg then _G.InboxFrameBg:SetAlpha(0) end
    for i = 1, 7 do SkinMailRow(_G["MailItem" .. i]) end
    -- MailItem1 is the chain root (2-7 anchor below it): lifting it lifts the whole inbox list. One-shot.
    local m1 = _G.MailItem1
    if m1 and not GetFFD(m1).raised then
        local np = m1:GetNumPoints() or 0
        local pts, ok = {}, np > 0
        for i = 1, np do
            local p, rel, rp, x, y = m1:GetPoint(i)
            if not p then ok = false break end
            pts[i] = { p, rel, rp, x or 0, (y or 0) + 20 }
        end
        if ok then
            GetFFD(m1).raised = true
            m1:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; m1:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
        end
    end
    if _G.OpenAllMail then WSkin.Button(_G.OpenAllMail); WSkin.WhiteButtonLabel(_G.OpenAllMail) end
    SkinLabeledPageButton(_G.InboxPrevPageButton, "<")
    SkinLabeledPageButton(_G.InboxNextPageButton, ">", 2)   -- right arrow 2px back to the right
    if _G.InboxCurrentPage then WSkin.Font(_G.InboxCurrentPage); WSkin.White(_G.InboxCurrentPage) end

    -- Send Mail
    if _G.SendMailNameEditBox then WSkin.EditBox(_G.SendMailNameEditBox) end
    if _G.SendMailSubjectEditBox then WSkin.EditBox(_G.SendMailSubjectEditBox) end
    if _G.SendMailFrame then WSkin.FadeRegions(_G.SendMailFrame); WSkin.Register(_G.SendMailFrame, true) end
    if _G.SendMailMoneyInset then WSkin.Inset(_G.SendMailMoneyInset) end
    if _G.SendMailMoneyBg then WSkin.FadeRegions(_G.SendMailMoneyBg); WSkin.Register(_G.SendMailMoneyBg, true) end
    if _G.SendMailMailButton then WSkin.Button(_G.SendMailMailButton) end
    if _G.SendMailCancelButton then WSkin.Button(_G.SendMailCancelButton) end
    for i = 1, 16 do
        local a = _G["SendMailAttachment" .. i]
        if a and not GetFFD(a).sock then
            local d = GetFFD(a)
            d.sock = true
            local nt = a.GetNormalTexture and a:GetNormalTexture()

            -- SendMailAttachment carries a static placeholder texture plus a
            -- dynamic icon texture Blizzard creates/updates on item placement.
            -- Fade everything up front so the placeholder cannot clip through;
            -- the hook below re-shows the real icon when an item is dropped in.
            WSkin.FadeRegions(a)
            if nt and nt.SetAlpha then nt:SetAlpha(0) end
            if a.IconBorder then a.IconBorder:SetAlpha(0) end

            local bg = a:CreateTexture(nil, "BACKGROUND", nil, -8)
            bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
            bg:SetAllPoints(a)
            d.bg = bg
            WSkin.AddBorder(a)

            -- A slot already holding an item on show (reopened mailbox) has its
            -- icon at ARTWORK/OVERLAY with a real texture: re-show it here, since
            -- the hook below only fires on later SetItemButtonTexture calls.
            local countFS = a.Count or (a.GetName and _G[a:GetName() .. "Count"])
            local countText = countFS and countFS.GetText and countFS:GetText()
            if countText and countText ~= "" and countText ~= "0" then
                local regions = { a:GetRegions() }
                for j = 1, #regions do
                    local r = regions[j]
                    if r and r:IsObjectType("Texture") and r.GetDrawLayer and r.GetTexture then
                        local layer = ({r:GetDrawLayer()})[1]
                        if (layer == "ARTWORK" or layer == "OVERLAY") and r:GetTexture() then
                            r:SetAlpha(1)
                            r:Show()
                            if r.SetTexCoord then r:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
                        end
                    end
                end
            end

            -- On SetItemButtonTexture: show only the region that received the
            -- item texture; on clear, hide all icon textures.
            if a.SetItemButtonTexture and not d.texHook then
                d.texHook = true
                hooksecurefunc(a, "SetItemButtonTexture", function(self, texture)
                    -- Our themed bg is a direct region: sweeps below must never
                    -- fade it, or the slot loses its backdrop on set/clear.
                    if not texture then
                        local regions = { self:GetRegions() }
                        for j = 1, #regions do
                            local r = regions[j]
                            if r and r ~= d.bg and r:IsObjectType("Texture") then
                                r:SetAlpha(0)
                            end
                        end
                        return
                    end
                    local regions = { self:GetRegions() }
                    for j = 1, #regions do
                        local r = regions[j]
                        if r and r ~= d.bg and r:IsObjectType("Texture") then
                            local match = (r.GetTexture and r:GetTexture() == texture) or (r.GetAtlas and r:GetAtlas() == texture)
                            if match then
                                r:SetAlpha(1)
                                r:Show()
                                if r.SetTexCoord then r:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
                            else
                                r:SetAlpha(0)
                            end
                        end
                    end
                end)
            end
        end
    end

    local mailTabs = {}
    for i = 1, 2 do
        local tab = _G["MailFrameTab" .. i]
        if tab then WSkin.Tab(tab); mailTabs[#mailTabs + 1] = tab end
    end
    WSkin.NormalizeTabRow(mailTabs)
    WSkin.ScrollBarsIn(f)

    if not _mailHook then
        _mailHook = true
        if type(_G.InboxFrame_Update) == "function" then
            hooksecurefunc("InboxFrame_Update", WSkin.Debounce(function()
                if f:IsVisible() then
                    for i = 1, 7 do SkinMailRow(_G["MailItem" .. i]) end
                    WSkin.Restrip()
                end
            end))
        end
        if type(_G.OpenMail_Update) == "function" then
            hooksecurefunc("OpenMail_Update", WSkin.Debounce(function()
                SkinMailItemButton(_G.OpenMailLetterButton)
                for i = 1, 16 do SkinMailItemButton(_G["OpenMailAttachmentButton" .. i]) end
                WhitenMailText()
            end))
        end
    end

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then
            for i = 1, 7 do SkinMailRow(_G["MailItem" .. i]) end
            WSkin.Restrip()
            WSkin.UpdateAllTabs()
        end
    end))
    Skin_OpenMail()
end

WSkin.RegisterWindow({
    key = "mail",
    addons = { Blizzard_MailFrame = true },
    apply = Skin_Mail,
})
end

-------------------------------------------------------------------------------
--  Catalyst / Item Interaction (ItemInteractionFrame)
--  Chrome only: the input slot's green "+" is its NormalAtlas, so the item
--  slots stay stock.
-------------------------------------------------------------------------------
do
local function Skin_Catalyst()
    local f = _G.ItemInteractionFrame
    if not f then return end
    WSkin.Shell("catalyst", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "ItemInteractionFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Bg and f.Bg.SetAlpha then f.Bg:SetAlpha(0) end
    if _G.ItemInteractionFrameBg then _G.ItemInteractionFrameBg:SetAlpha(0) end
    if f.Inset then WSkin.Inset(f.Inset) end
    if f.Background and f.Background.SetAlpha then f.Background:SetAlpha(0) end
    if f.Description then WSkin.White(f.Description) end

    local bf = f.ButtonFrame
    if bf then
        for _, k in ipairs({ "BlackBorder", "ButtonBorder", "ButtonBottomBorder" }) do
            local t = bf[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        if bf.ActionButton then WSkin.Button(bf.ActionButton) end
        if bf.MoneyFrameEdge then WSkin.FadeRegions(bf.MoneyFrameEdge); WSkin.Register(bf.MoneyFrameEdge, true) end
    end
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "catalyst",
    addons = { Blizzard_ItemInteractionUI = true },
    apply = Skin_Catalyst,
})
end

-------------------------------------------------------------------------------
--  Gem Socketing (ItemSocketingFrame)
-------------------------------------------------------------------------------
do
local function SkinSocket(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    -- Lock detection every pass: lock state changes per inspected item; LOCKED sockets keep ALL Blizzard art (closed ring + padlock).
    local isLocked = false
    local regions = { btn:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("Texture") then
            local hay = WSkin.TexHay(r)
            if hay and hay:find("lock", 1, true) then isLocked = true break end
        end
    end
    local kids = {}
    local children = { btn:GetChildren() }
    for i = 1, #children do
        local c = children[i]
        if c and c.SetAlpha then
            kids[#kids + 1] = c
            if not isLocked and c.GetRegions then
                local regions2 = { c:GetRegions() }
                for j = 1, #regions2 do
                    local r2 = regions2[j]
                    if r2 and r2.IsObjectType and r2:IsObjectType("Texture") then
                        local hay2 = WSkin.TexHay(r2)
                        if hay2 and hay2:find("lock", 1, true) then isLocked = true break end
                    end
                end
            end
        end
    end
    local nt = btn.GetNormalTexture and btn:GetNormalTexture()
    if isLocked then
        -- Un-stripped: the whole locked presentation stays Blizzard's.
        local regions2 = { btn:GetRegions() }
        for i = 1, #regions2 do
            local r = regions2[i]
            if r and r.IsObjectType and r:IsObjectType("Texture") then r:SetAlpha(1) end
        end
        for _, c in ipairs(kids) do c:SetAlpha(1) end
        if nt and nt.SetAlpha then nt:SetAlpha(1) end
    else
        -- Blizzard's socket presentation stays whole (icon/ring/border/bracket
        -- art); only decorative spark/shine CHILDREN dim, replaced by the house
        -- glow. Spared: the bracket frame and any child with a fileID-backed
        -- texture (the gem holder -- decor art is atlas/path-based).
        for _, c in ipairs(kids) do
            local spare = (c == btn.BracketFrame)
            if not spare and c.GetRegions then
                local regions2 = { c:GetRegions() }
                for j = 1, #regions2 do
                    local r2 = regions2[j]
                    if r2 and r2.IsObjectType and r2:IsObjectType("Texture")
                        and not WSkin.TexHay(r2) then
                        local tx = r2.GetTexture and r2:GetTexture()
                        if type(tx) == "number" then
                            spare = true
                            break
                        end
                    end
                end
            end
            c:SetAlpha(spare and 1 or 0)
        end
    end
    -- Side filigree flourishes stay off in every state; multi-piece and partly anonymous, so sweep by geometry too.
    for _, k in ipairs({ "LeftFiligree", "RightFiligree" }) do
        local t = btn[k]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    -- Flourishes are the only regions overhanging the button's sides, so
    -- anything protruding past the edges fades (rects only exist while shown; update-pass re-runs catch it).
    local bl, br2 = btn:GetLeft(), btn:GetRight()
    if bl and br2 then
        local regions2 = { btn:GetRegions() }
        for i = 1, #regions2 do
            local r = regions2[i]
            if r and r.IsObjectType and r:IsObjectType("Texture") then
                local rl, rr = r:GetLeft(), r:GetRight()
                if rl and rr and (rl < bl - 6 or rr > br2 + 6) then
                    r:SetAlpha(0)
                end
            end
        end
    end
    if d.sock then return end
    d.sock = true
    -- House Modern WoW glow (gold) on our own wrapper frame.
    if EllesmereUI.Glows and EllesmereUI.Glows.StartGlow then
        local gw = CreateFrame("Frame", nil, btn)
        local w2, h2 = btn:GetSize()
        if not w2 or w2 == 0 then w2, h2 = 36, 36 end
        gw:SetSize(w2, h2)
        gw:SetPoint("CENTER")
        EllesmereUI.Glows.StartGlow(gw, 6, w2, 1, 0.91, 0.5, nil, h2)
        d.glow = gw
    end
end


local function Skin_Socket()
    local f = _G.ItemSocketingFrame
    if not f then return end
    WSkin.Shell("socket", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "ItemSocketingFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.ItemSocketingFrameBg then _G.ItemSocketingFrameBg:SetAlpha(0) end
    if f.Inset then WSkin.Inset(f.Inset) end
    WSkin.FadeKeyedArt(f)
    WSkin.FadeArtIn(f)
    -- Tighter window: 40 narrower, 80 shorter than stock (one-shot).
    local fd5 = GetFFD(f)
    if not fd5.hCut then
        local ww, hh = f:GetSize()
        if ww and hh and hh > 140 and ww > 100 then
            fd5.hCut = true
            f:SetSize(ww - 40, hh - 80)
        end
    end
    -- Owned layout: a FIXED scrollable tooltip viewport between the title bar
    -- and a gem section at the bottom. Tooltip text keeps its native scroll-
    -- child anchors; only the scrollframe and gem container are positioned
    -- (absolute anchors, idempotent per update pass).
    local function LayoutSocketing()
        local sf2 = _G.ItemSocketingScrollFrame or f.ScrollFrame
        local c = f.SocketingContainer
        if sf2 then
            sf2:ClearAllPoints()
            sf2:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -32)
            sf2:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -32, 100)
        end
        if c then
            c:ClearAllPoints()
            c:SetPoint("BOTTOM", f, "BOTTOM", 0, 40)
        end
        -- Blizzard re-anchors only Socket1 each update; Socket2/3 chain off it,
        -- so pin Socket1 alone (pinning the others latches stale offsets).
        local fcx = f:GetCenter()
        local s1 = c and c.Socket1
        if fcx and s1 and s1:IsShown() then
            local scx = s1:GetCenter()
            if scx then
                s1:ClearAllPoints()
                s1:SetPoint("BOTTOM", f, "BOTTOM", scx - fcx, 40)
            end
        end
        -- Old-style scrollbar -> slim house strip (arrow buttons dark),
        -- seated 15px right of Blizzard's spot.
        local sbr = _G.ItemSocketingScrollFrameScrollBar or (sf2 and sf2.ScrollBar)
        if sbr and not GetFFD(sbr).slim then
            GetFFD(sbr).slim = true
            local numPts = sbr:GetNumPoints()
            if numPts and numPts > 0 then
                local pts, ok = {}, true
                for i = 1, numPts do
                    local p, rel, rp, x, y = sbr:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + 15, y or 0 }
                end
                if ok then
                    sbr:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        sbr:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
            local sbrName = sbr.GetName and sbr:GetName() or ""
            for _, b in ipairs({ sbr.ScrollUpButton or _G[sbrName .. "ScrollUpButton"],
                                 sbr.ScrollDownButton or _G[sbrName .. "ScrollDownButton"] }) do
                if b then
                    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                                         "GetDisabledTexture", "GetHighlightTexture" }) do
                        local t = b[g] and b[g](b)
                        if t and t.SetAlpha then t:SetAlpha(0) end
                    end
                end
            end
            local thumb = sbr.GetThumbTexture and sbr:GetThumbTexture()
            if thumb then
                thumb:SetTexture("Interface\\Buttons\\WHITE8X8")
                thumb:SetVertexColor(1, 1, 1, 0.3)
                thumb:SetWidth(4)
            end
        end
    end
    -- Skin every realized socket (art only; layout is separate).
    local function SkinSocketsArt()
        local c = f.SocketingContainer
        if not c then return end
        for _, k in ipairs({ "Socket1", "Socket2", "Socket3" }) do SkinSocket(c[k]) end
        if c.SocketFrames then
            for _, sock in ipairs(c.SocketFrames) do SkinSocket(sock) end
        end
        if c.ApplySocketsButton then WSkin.Button(c.ApplySocketsButton) end
    end
    -- Full pass: reposition + reskin + restrip. Idempotent, safe to repeat.
    local function FullPass()
        if not f:IsVisible() then return end
        LayoutSocketing()
        SkinSocketsArt()
        WSkin.Restrip()
    end

    LayoutSocketing()
    SkinSocketsArt()
    WSkin.ScrollBarsIn(f)

    -- Blizzard repaints sockets on every item change. LAYOUT must run
    -- SYNCHRONOUSLY: Blizzard re-anchors sockets inside the update, so a
    -- debounced reposition renders a frame at Blizzard's spot then snaps (the
    -- gem-click bounce). The debounced FullPass ALSO re-layouts, covering the
    -- FIRST open where sockets are not laid out for the sync pass.
    if type(_G.ItemSocketingFrame_Update) == "function" and not GetFFD(f).updHook then
        GetFFD(f).updHook = true
        local deferred = WSkin.Debounce(FullPass)
        hooksecurefunc("ItemSocketingFrame_Update", function()
            if not f:IsVisible() then return end
            LayoutSocketing()
            deferred()
        end)
    end

    -- On (re)show, run the full pass now AND once sockets have realized: first
    -- open loads this LoD addon with the frame already showing, unbuilt.
    WSkin.HookShow(f, WSkin.Debounce(function()
        FullPass()
        if C_Timer then
            C_Timer.After(0, FullPass)
            C_Timer.After(0.1, FullPass)
        end
    end))
end

WSkin.RegisterWindow({
    key = "socket",
    addons = { Blizzard_ItemSocketingUI = true },
    apply = Skin_Socket,
})
end

-------------------------------------------------------------------------------
--  Reputation & Currency tabs (CharacterFrame sub-panes). Rides the charsheet
--  style key but touches ONLY content inside ReputationFrame/TokenFrame (page
--  chrome/backdrops belong to CharacterSheet). Taint: currency transfer log
--  toggle never restyled (breaks transfers); scrollbar work is texture-only.
-------------------------------------------------------------------------------
do
local function RCWhiteTextsIn(host)
    if not host or not host.GetRegions then return end
    local regions = { host:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("FontString") then
            WSkin.Font(r)
            WSkin.White(r)
        end
    end
end

-- Collapse state comes from the row's element data; painted atlas names differ
-- between rep/token lists and nesting levels, so they are only a fallback.
local function RCCollapsedIn(t)
    if type(t) ~= "table" then return nil end
    if t.isCollapsed ~= nil then return t.isCollapsed and true or false end
    if t.isHeaderExpanded ~= nil then return (not t.isHeaderExpanded) and true or false end
    return nil
end

local function RCRowCollapsed(row)
    if not row.GetElementData then return nil end
    local ok, dt = pcall(row.GetElementData, row)
    if not ok or type(dt) ~= "table" then return nil end
    local c = RCCollapsedIn(dt)
    if c == nil then c = RCCollapsedIn(dt.factionData) end
    if c == nil then c = RCCollapsedIn(dt.data) end
    return c
end

local RC_STRIP_KEYS = { "Left", "Middle", "HighlightLeft", "HighlightMiddle",
                        "HighlightRight" }
local function SkinRCRow(child, isCurrency)
    if not child or child:IsForbidden() then return end
    -- Currency (TokenFrame) rows stay 100% STOCK. ANY skinning, even the
    -- band-strip fade, taints warband currency transfer (forbidding the
    -- protected RequestCurrencyFromAccountCharacter) and blanks currency
    -- column headers. Reputation rows are fine.
    if isCurrency then return end
    local d = GetFFD(child)
    -- Per-pass: pooled rows get re-initialized by Blizzard, so header band fades must re-assert on every list update.
    for _, k in ipairs(RC_STRIP_KEYS) do
        local t = child[k]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    -- Header +/- toggle: strip Blizzard's paint, drive the spellbook max/min
    -- glyph off the state it painted; per pass so the strip survives pooled-row repaints.
    local tcb = child.ToggleCollapseButton
    if tcb then
        local bd = GetFFD(tcb)
        if not bd.glyph then
            local glyph = tcb:CreateTexture(nil, "OVERLAY")
            glyph:SetSize(16, 16)
            glyph:SetPoint("CENTER", tcb, "CENTER", 0, 0)
            bd.glyph = glyph
            -- Stock button is a tiny click target: pad the hit rect.
            tcb:SetHitRectInsets(-6, -6, -6, -6)
            local function classify(a)
                if type(a) ~= "string" then return nil end
                a = a:lower()
                if a:find("expanded", 1, true) then return true end
                if a:find("minus", 1, true) or a:find("collapse", 1, true) then return true end
                if a:find("plus", 1, true) or a:find("expand", 1, true) then return false end
                return nil
            end
            local function repaint()
                local expanded
                local collapsed = RCRowCollapsed(child)
                if collapsed ~= nil then expanded = not collapsed end
                for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                                     "GetHighlightTexture", "GetDisabledTexture" }) do
                    local t = tcb[g] and tcb[g](tcb)
                    if t then
                        if expanded == nil and t.GetAtlas then
                            expanded = classify(t:GetAtlas())
                        end
                        t:SetAlpha(0)
                    end
                end
                local regions = { tcb:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r ~= glyph and r.IsObjectType and r:IsObjectType("Texture") then
                        if expanded == nil and r.GetAtlas then
                            expanded = classify(r:GetAtlas())
                        end
                        r:SetAlpha(0)
                    end
                end
                if expanded == nil then expanded = true end
                glyph:SetAtlas(expanded and "UI-QuestTrackerButton-Secondary-Collapse"
                                        or "UI-QuestTrackerButton-Secondary-Expand", false)
                glyph:SetDesaturated(true)
                glyph:SetVertexColor(1, 1, 1, tcb:IsMouseOver() and 1 or 0.75)
            end
            bd.repaint = repaint
            if tcb.RefreshIcon then hooksecurefunc(tcb, "RefreshIcon", repaint) end
            tcb:HookScript("OnClick", repaint)
            tcb:HookScript("OnEnter", function() glyph:SetVertexColor(1, 1, 1, 1) end)
            tcb:HookScript("OnLeave", function() glyph:SetVertexColor(1, 1, 1, 0.75) end)
            repaint()
        else
            bd.repaint()
        end
    end
    -- Rep-style header rows carry the boxed +/- directly in the Right texture
    -- slot (Options_ListExpand atlases): hide that art and drive the spellbook
    -- max/min glyph in its place (rows with a ToggleCollapseButton get theirs
    -- from the handler above). Per pass, since collapse toggles rebuild rows
    -- without always re-setting the atlas.
    local chev = child.Right
    if chev and chev.GetAtlas then
        local cd = GetFFD(chev)
        if not cd.styleRight then
            cd.styleRight = function()
                local a = chev:GetAtlas()
                local isExpandArt = a == "Options_ListExpand_Right"
                    or a == "Options_ListExpand_Right_Expanded"
                chev:SetAlpha(0)
                if not isExpandArt or child.ToggleCollapseButton then
                    if cd.glyph then cd.glyph:Hide() end
                    return
                end
                local g = cd.glyph
                if not g then
                    g = child:CreateTexture(nil, "OVERLAY")
                    g:SetSize(16, 16)
                    g:SetPoint("CENTER", chev, "CENTER", 0, 0)
                    cd.glyph = g
                end
                local collapsed = RCRowCollapsed(child)
                if collapsed == nil then
                    collapsed = a == "Options_ListExpand_Right"
                end
                g:SetAtlas(collapsed and "UI-QuestTrackerButton-Secondary-Expand"
                    or "UI-QuestTrackerButton-Secondary-Collapse", false)
                g:SetDesaturated(true)
                g:SetVertexColor(1, 1, 1, 0.75)
                g:Show()
            end
            hooksecurefunc(chev, "SetAtlas", cd.styleRight)
        end
        cd.styleRight()
    end
    if d.rcSkinned then return end
    d.rcSkinned = true
    -- Header rows (those carrying the band art) get a subtle house plate and a
    -- white hover in place of the faded highlight band.
    if child.Middle and not d.plate then
        local plate = SolidTex(child, "BACKGROUND", 1, 1, 1, 0.05)
        plate:SetAllPoints(child)
        d.plate = plate
        local hov = SolidTex(child, "HIGHLIGHT", 1, 1, 1, 0.05)
        hov:SetAllPoints(child)
        d.hover = hov
    end
    RCWhiteTextsIn(child)
    local content = child.Content
    if content then
        RCWhiteTextsIn(content)
        local icon = content.CurrencyIcon
        if icon then WSkin.SquareIcon(icon) end
        local rb = content.ReputationBar
        if rb and rb.GetStatusBarTexture then
            local keep = {}
            local fill = rb:GetStatusBarTexture()
            if fill then keep[fill] = true end
            WSkin.FadeRegions(rb, keep)
            rb:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            local rd = GetFFD(rb)
            if not rd.bg then
                local trough = rb:CreateTexture(nil, "BACKGROUND", nil, -1)
                trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
                trough:SetAllPoints(rb)
                rd.bg = trough
                WSkin.AddBorder(rb)
            end
            RCWhiteTextsIn(rb)
        end
    end
end

local function HookRCScrollBox(box, isCurrency)
    if not box or not box.ForEachFrame then return end
    local skin = function(row) SkinRCRow(row, isCurrency) end
    pcall(box.ForEachFrame, box, skin)
    local d = GetFFD(box)
    if box.Update and not d.rowHook then
        d.rowHook = true
        hooksecurefunc(box, "Update", function(b)
            pcall(b.ForEachFrame, b, skin)
        end)
    end
end

local function Skin_RepCurrency()
    -- The character sheet's Blizz Default keeps Blizzard's whole sheet,
    -- these tabs included.
    if ns.CharSheetStock and ns.CharSheetStock() then return end
    local rep = _G.ReputationFrame
    -- WoW Forever keeps the list, its filter and the detail pane Blizzard's on
    -- the sheet's backdrop, like that client's other character tabs (Skills,
    -- PvP, Currency); only the list's scroll bar takes the house style, as
    -- the Currency and stats lists' do.
    if rep and EllesmereUI.IS_FOREVER then
        if rep.ScrollBar then WSkin.ScrollBar(rep.ScrollBar) end
    elseif rep then
        if rep.filterDropdown then WSkin.Dropdown(rep.filterDropdown) end
        WSkin.ScrollBarsIn(rep)
        HookRCScrollBox(rep.ScrollBox)
        local det = rep.ReputationDetailFrame
        if det then
            SkinGuildPopup(det)
            for _, k in ipairs({ "AtWarCheckbox", "MakeInactiveCheckbox",
                                 "WatchFactionCheckbox" }) do
                if det[k] then SkinGuildCheck(det[k]) end
            end
            if det.ViewRenownButton then WSkin.Button(det.ViewRenownButton) end
            if det.ScrollingDescriptionScrollBar then
                WSkin.ScrollBar(det.ScrollingDescriptionScrollBar)
            end
        end
    end

    local tok = _G.TokenFrame
    if tok then
        if tok.filterDropdown then WSkin.Dropdown(tok.filterDropdown) end
        WSkin.ScrollBarsIn(tok)
        HookRCScrollBox(tok.ScrollBox, true)  -- currency rows: band-fade only, no collapse/content skin (taints transfer)
        -- NOTHING IN THE CURRENCY-TRANSFER PATH GETS SKINNED: not the entry
        -- buttons (tok.CurrencyTransferLogToggleButton, pop.CurrencyTransferToggleButton),
        -- not the CurrencyTransferMenu window. Any write taints the protected
        -- RequestCurrencyFromAccountCharacter() -> ADDON_ACTION_FORBIDDEN for
        -- warband transfers. READ BEFORE RE-SKINNING: the failure hides itself
        -- (first transfer of a session succeeds, only later ones are forbidden,
        -- so testing once proves nothing). A no-write external-shell menu would
        -- work but needs a per-frame driver for one dialog -- not worth it. Leave stock.
        local pop = _G.TokenFramePopup
        if pop then
            -- Currency Options popup. Deliberately NOT SkinGuildPopup: that flat
            -- 0.05 slab reads as a dead grey box next to the character panel.
            -- The style-aware shell on the CHARSHEET key follows the panel's own
            -- setting (atlas+black overlay on "eui", flat user color on
            -- "modern") and swaps live. noTopBar keeps the backdrop/atlas frame
            -- but drops the 25px title strip, a hard bar across something this small.
            WSkin.Shell("charsheet", pop, { noTopBar = true })
            if pop.NineSlice then WSkin.FadeNineSlice(pop.NineSlice) end
            -- Chrome in child FRAMES ("BG"/"Border" wrappers), invisible to the shell's own region fade.
            for _, k in ipairs({ "BG", "Border" }) do
                local piece = pop[k]
                if piece then
                    if piece.IsObjectType and piece:IsObjectType("Texture") then
                        piece:SetAlpha(0)
                    else
                        WSkin.FadeRegions(piece)
                        if piece.NineSlice then WSkin.FadeNineSlice(piece.NineSlice) end
                        WSkin.Register(piece, true)
                    end
                end
            end
            local regions = { pop:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r.IsObjectType and r:IsObjectType("FontString") then
                    WSkin.Font(r); WSkin.White(r)
                end
            end
            if pop.CloseButton then WSkin.CloseButton(pop.CloseButton) end
            local pcb = pop["$parent.CloseButton"]
            if pcb then WSkin.CloseButton(pcb) end
            -- "Unused"/"Show on Backpack": plain square treatment KEEPING
            -- Blizzard's checkmark art, as the calendar lock-event check does --
            -- NOT SkinGuildCheck, which replaces it with a solid block.
            -- borderInset 4 hugs the visible box (frame is larger than its check graphic).
            for _, k in ipairs({ "InactiveCheckbox", "BackpackCheckbox" }) do
                if pop[k] then WSkin.Checkbox(pop[k], { borderInset = 4 }) end
            end
            -- pop.CurrencyTransferToggleButton stays 100% stock (see the
            -- transfer-path note above). The popup around it is skinned.
        end
    end
end

WSkin.RegisterWindow({
    key = "charsheet",
    apply = Skin_RepCurrency,
})
-- Second pass for clients where TokenFrame/TokenFramePopup arrive with the
-- load-on-demand Blizzard_TokenUI rather than at login. Idempotent.
WSkin.RegisterWindow({
    key = "charsheet",
    addons = { Blizzard_TokenUI = true },
    apply = Skin_RepCurrency,
})
end

-------------------------------------------------------------------------------
--  Housing Dashboard. Chrome only by request: shell backdrop/border, top bar,
--  title, close button. Dashboard CONTENT (house info, catalog, initiatives) stays 100% stock.
-------------------------------------------------------------------------------
do
local function Skin_Housing()
    local f = _G.HousingDashboardFrame
    if not f then return end
    WSkin.Shell("housing", f)
    WSkin.RemovePortrait(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if title then
        WSkin.Font(title)
        WSkin.White(title)
    end
    local cb = f.CloseButton or (f.GetName and _G[(f:GetName() or "") .. "CloseButton"])
    if cb then WSkin.CloseButton(cb) end
    -- Only top tab row, house finder button, and neighborhood dropdown are touched; everything else stays stock.
    local info = f.HouseInfoContent
    if info then
        -- Finder button + house dropdown 8px lower (one-shot, anchors kept).
        local function DropInfoControl(ctrl)
            if not ctrl then return end
            local cd2 = GetFFD(ctrl)
            if cd2.dropped8 then return end
            local np = ctrl:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = ctrl:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 8 }
            end
            if not ok then return end
            cd2.dropped8 = true
            ctrl:ClearAllPoints()
            for i = 1, #pts do
                local t = pts[i]
                ctrl:SetPoint(t[1], t[2], t[3], t[4], t[5])
            end
        end
        if info.HouseFinderButton then
            WSkin.Button(info.HouseFinderButton)
            local hfs = info.HouseFinderButton.GetFontString
                and info.HouseFinderButton:GetFontString()
            if hfs then WSkin.White(hfs) end
        end
        if info.HouseDropdown then
            WSkin.Dropdown(info.HouseDropdown)
            local hdd = GetFFD(info.HouseDropdown)
            if not hdd.scaled then
                hdd.scaled = true
                info.HouseDropdown:SetScale(0.86)
            end
            DropInfoControl(info.HouseDropdown)
        end
        local cf = info.ContentFrame
        if cf and cf.TabSystem then
            WSkin.TabSystem(cf.TabSystem, { darkActive = true })
            -- 1px up: accent underline rides the tabs' bottom edge, clipped at the stock seat.
            local tsd = GetFFD(cf.TabSystem)
            if not tsd.lifted then
                local np = cf.TabSystem:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = cf.TabSystem:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + 1 }
                end
                if ok then
                    tsd.lifted = true
                    cf.TabSystem:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        cf.TabSystem:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
            -- Blizzard rebuilds these tabs; restyle new ones as they appear.
            if cf.UpdateTabs and not GetFFD(cf).tabHook then
                GetFFD(cf).tabHook = true
                hooksecurefunc(cf, "UpdateTabs", function(cf2)
                    if cf2.TabSystem then
                        WSkin.TabSystem(cf2.TabSystem, { darkActive = true })
                    end
                end)
            end
        end
    end
    local cat = f.CatalogContent
    if cat then
        local sbx = cat.SearchBox
        local fdd = cat.Filters and cat.Filters.FilterDropdown
        if sbx then WSkin.EditBox(sbx) end
        if fdd then
            WSkin.Dropdown(fdd)
            -- Left-aligned label (this dropdown only, not engine wide).
            local lab = fdd.Text or (fdd.GetFontString and fdd:GetFontString())
            local fdData = GetFFD(fdd)
            if lab and not fdData.labLeft then
                fdData.labLeft = true
                lab:ClearAllPoints()
                lab:SetPoint("LEFT", fdd, "LEFT", 8, 0)
                lab:SetPoint("RIGHT", fdd, "RIGHT", -22, 0)
                if lab.SetJustifyH then lab:SetJustifyH("LEFT") end
            end
        end
        -- Search box matches filter dropdown height (one-shot; retries on catalog show until laid out).
        if sbx and fdd then
            local function MatchSearchHeight()
                if GetFFD(sbx).hMatched then return end
                local dh = fdd:GetHeight()
                if dh and dh > 0 then
                    GetFFD(sbx).hMatched = true
                    sbx:SetHeight(dh)
                end
            end
            MatchSearchHeight()
            if not GetFFD(cat).hHook then
                GetFFD(cat).hHook = true
                cat:HookScript("OnShow", MatchSearchHeight)
            end
        end
    end
end

WSkin.RegisterWindow({
    key = "housing",
    addons = { Blizzard_HousingDashboard = true },
    apply = Skin_Housing,
})
end

-------------------------------------------------------------------------------
--  Profession Crafting window (recipe list, schematic form, specializations,
--  crafting orders): shell chrome, tabs, lists, buttons, rank bar, gear slots.
--  Reagent slot art stays stock. Visual-only throughout.
-------------------------------------------------------------------------------
local function SkinProfMaxMin(btn, atlas)
    if not btn or GetFFD(btn).mm then return end
    if not (C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas)) then return end
    GetFFD(btn).mm = true
    local regions = { btn:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("Texture") then r:SetAlpha(0) end
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                         "GetHighlightTexture", "GetDisabledTexture" }) do
        local t = btn[g] and btn[g](btn)
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    local glyph = btn:CreateTexture(nil, "OVERLAY")
    glyph:SetSize(16, 16)
    glyph:SetPoint("CENTER", btn, "CENTER", -2, 0)
    glyph:SetAtlas(atlas, false)
    glyph:SetDesaturated(true)
    glyph:SetVertexColor(1, 1, 1, 0.75)
    btn:HookScript("OnEnter", function() glyph:SetVertexColor(1, 1, 1, 1) end)
    btn:HookScript("OnLeave", function() glyph:SetVertexColor(1, 1, 1, 0.75) end)
end

do
-- Profession rank bar (crafting page + order view): house trough+border behind Blizzard's own fill (fill itself is kept).
local function ProfFlatBar(bar)
    if not bar then return end
    local d = GetFFD(bar)
    if d.flat then return end
    d.flat = true
    for _, k in ipairs({ "Border", "Background" }) do
        local t = bar[k]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    if not d.bg then
        local trough = bar:CreateTexture(nil, "BACKGROUND", nil, -1)
        trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
        -- The bar FRAME matches the band's size, only its origin is off, and
        -- the Fill's fixed top-left corner IS the band origin: frame size + fill origin = the exact band (right 8px cut off).
        local w, h = bar:GetSize()
        if bar.Fill and w and w > 8 and h and h > 0 then
            trough:SetSize(w - 8, h)
            trough:SetPoint("TOPLEFT", bar.Fill, "TOPLEFT", 0, 0)
        else
            trough:SetAllPoints(bar)
        end
        d.bg = trough
        WSkin.BorderRegion(bar, trough)
    end
    local rankText = bar.Rank and bar.Rank.Text
    if rankText then
        WSkin.Font(rankText)
        WSkin.White(rankText)
    end
    -- Expansion picker: stock arrow art stripped, house dropdown arrow with standard 5% hover wash.
    local edb = bar.ExpansionDropdownButton
    if edb and not GetFFD(edb).arrow then
        local ed = GetFFD(edb)
        ed.arrow = true
        local regions = { edb:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and r.IsObjectType and r:IsObjectType("Texture") then r:SetAlpha(0) end
        end
        for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                             "GetHighlightTexture", "GetDisabledTexture" }) do
            local t = edb[g] and edb[g](edb)
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local ar = edb:CreateTexture(nil, "OVERLAY")
        ar:SetAtlas("Azerite-PointingArrow", false)
        ar:SetSize(14, 10)
        ar:SetPoint("CENTER", edb, "CENTER", 0, 0)
        ed.caret = ar
        local hov = edb:CreateTexture(nil, "HIGHLIGHT")
        hov:SetColorTexture(1, 1, 1, 0.05)
        hov:SetAllPoints(edb)
    end
end

local function SkinSchematic(form)
    if not form or form:IsForbidden() then return end
    local d = GetFFD(form)
    if d.schem then return end
    d.schem = true
    WSkin.FadeRegions(form)
    WSkin.Register(form, true)
    if form.Background then form.Background:SetAlpha(0) end
    if form.MinimalBackground then form.MinimalBackground:SetAlpha(0) end
    if not d.bg then
        local bg = SolidTex(form, "BACKGROUND", 0, 0, 0, 0.25, -6)
        bg:SetAllPoints(form)
        d.bg = bg
    end
    for _, k in ipairs({ "TrackRecipeCheckbox", "AllocateBestQualityCheckbox" }) do
        if form[k] then SkinGuildCheck(form[k]) end
    end
    local qd = form.QualityDialog
    if qd then
        SkinGuildPopup(qd)
        if qd.ClosePanelButton then WSkin.CloseButton(qd.ClosePanelButton) end
        if qd.AcceptButton then WSkin.Button(qd.AcceptButton) end
        if qd.CancelButton then WSkin.Button(qd.CancelButton) end
    end
end

local function SkinOutputLog(log)
    if not log or GetFFD(log).outLog then return end
    GetFFD(log).outLog = true
    SkinGuildPopup(log)
    if log.ClosePanelButton then WSkin.CloseButton(log.ClosePanelButton) end
    WSkin.ScrollBarsIn(log)
end

local PROF_GEAR_SLOTS = {
    "Prof0ToolSlot", "Prof0Gear0Slot", "Prof0Gear1Slot",
    "Prof1ToolSlot", "Prof1Gear0Slot", "Prof1Gear1Slot",
    "CookingToolSlot", "CookingGear0Slot",
    "FishingToolSlot", "FishingGear0Slot", "FishingGear1Slot",
}
local function SkinProfGearSlot(btn)
    if not btn then return end
    local d = GetFFD(btn)
    if d.slot then return end
    d.slot = true
    local icon = btn.icon or btn.Icon
    local keep = {}
    if icon then keep[icon] = true end
    if btn.IconBorder then keep[btn.IconBorder] = true end
    WSkin.FadeRegions(btn, keep)
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture" }) do
        local t = btn[g] and btn[g](btn)
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    if icon then WSkin.SquareIcon(icon, btn) end
    -- 2px smaller than stock (top-right tool/gear icons).
    if not InCombatLockdown() then
        local w, h = btn:GetSize()
        if w and w > 4 and h and h > 4 then
            btn:SetSize(w - 2, h - 2)
        end
    end
end

-- Sortable column header over crafting orders (roster-columns look: 3-slice art gone, raised plate, border-free, white labels, 10% hover).
local function SkinOrderColumns(cd)
    if not cd then return end
    WSkin.FadeRegions(cd)
    WSkin.Register(cd, true)
    local children = { cd:GetChildren() }
    for i = 1, #children do
        local col = children[i]
        if col and col.GetObjectType and col:GetObjectType() == "Button" then
            local d2 = GetFFD(col)
            if not d2.bg then
                for _, k2 in ipairs({ "Left", "Middle", "Right" }) do
                    local t2 = col[k2]
                    if t2 and t2.SetTexture then t2:SetTexture("") end
                end
                WSkin.FadeRegions(col)
                local bg2 = SolidTex(col, "BACKGROUND",
                    Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                bg2:SetPoint("TOPLEFT", 1, -1)
                bg2:SetPoint("BOTTOMRIGHT", -1, 1)
                d2.bg = bg2
                local hov = SolidTex(col, "HIGHLIGHT", 1, 1, 1, 0.1)
                hov:SetAllPoints(col)
                d2.hover = hov
                WSkin.Register(col, true)
            end
            local fs2 = col.GetFontString and col:GetFontString()
            if fs2 then WSkin.White(fs2) end
        end
    end
end

local function SkinOrderView(ov)
    if not ov then return end
    for _, k in ipairs({ "CreateButton", "StartRecraftButton", "CompleteOrderButton" }) do
        if ov[k] then WSkin.Button(ov[k]) end
    end
    ProfFlatBar(ov.RankBar)
    SkinOutputLog(ov.CraftingOutputLog)
    local oi = ov.OrderInfo
    if oi then
        WSkin.FadeRegions(oi)
        WSkin.Register(oi, true)
        for _, k in ipairs({ "BackButton", "StartOrderButton",
                             "DeclineOrderButton", "ReleaseOrderButton" }) do
            if oi[k] then WSkin.Button(oi[k]) end
        end
    end
    local od = ov.OrderDetails
    if od then
        -- Preserve the quality-tier icon (pentagon next to recipe name): a
        -- direct OVERLAY region of OrderDetails the blanket fade would zero.
        -- The keep set must ALSO go into the restrip registry -- the show hook
        -- re-fades registered frames, and a bare `true` there would zero it again.
        local keep = od.MinimumQualityIcon and { [od.MinimumQualityIcon] = true } or nil
        WSkin.FadeRegions(od, keep)
        WSkin.Register(od, keep)
        if od.Background then od.Background:SetAlpha(0) end
        SkinSchematic(od.SchematicForm)
    end
    local dd = ov.DeclineOrderDialog
    if dd then
        SkinGuildPopup(dd)
        if dd.ConfirmButton then WSkin.Button(dd.ConfirmButton) end
        if dd.CancelButton then WSkin.Button(dd.CancelButton) end
    end
end

local function Skin_Professions()
    local f = _G.ProfessionsFrame
    if not f then return end
    WSkin.Shell("professions", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if title then
        WSkin.Font(title)
        WSkin.White(title)
    end
    if f.CloseButton then WSkin.CloseButton(f.CloseButton) end
    local mm = f.MaximizeMinimize
    if mm then
        SkinProfMaxMin(mm.MinimizeButton, "UI-QuestTrackerButton-Secondary-Collapse")
        SkinProfMaxMin(mm.MaximizeButton, "UI-QuestTrackerButton-Secondary-Expand")
    end
    if f.TabSystem then WSkin.TabSystem(f.TabSystem) end

    local cp = f.CraftingPage
    if cp then
        for _, k in ipairs({ "CreateButton", "CreateAllButton", "ViewGuildCraftersButton" }) do
            if cp[k] then WSkin.Button(cp[k]) end
        end
        if cp.MinimizedSearchBox then WSkin.EditBox(cp.MinimizedSearchBox) end
        ProfFlatBar(cp.RankBar)
        SkinSchematic(cp.SchematicForm)
        SkinOutputLog(cp.CraftingOutputLog)
        local rl = cp.RecipeList
        if rl then
            WSkin.FadeRegions(rl)
            WSkin.Register(rl, true)
            if rl.BackgroundNineSlice then WSkin.FadeNineSlice(rl.BackgroundNineSlice) end
            local d = GetFFD(rl)
            if not d.bg then
                local bg = SolidTex(rl, "BACKGROUND", 0, 0, 0, 0.25, -6)
                bg:SetAllPoints(rl)
                d.bg = bg
            end
            -- Sidebar filter dropdown: 2px taller, label left-aligned (this dropdown only, not engine-wide).
            local fdd = rl.FilterDropdown
            if fdd then
                local fd = GetFFD(fdd)
                if not fd.hTuned then
                    local h0 = fdd:GetHeight()
                    if h0 and h0 > 0 then
                        fd.hTuned = true
                        fdd:SetHeight(h0 + 2)
                        -- Nudged up 1px (one-shot, all points preserved).
                        local pts = {}
                        local ok = true
                        for i = 1, fdd:GetNumPoints() do
                            local p, rel, rp, x, y = fdd:GetPoint(i)
                            if not p then ok = false break end
                            pts[i] = { p, rel, rp, x or 0, (y or 0) + 1 }
                        end
                        if ok and #pts > 0 then
                            fdd:ClearAllPoints()
                            for i = 1, #pts do
                                local t = pts[i]
                                fdd:SetPoint(t[1], t[2], t[3], t[4], t[5])
                            end
                        end
                    end
                end
                local lab = fdd.Text or (fdd.GetFontString and fdd:GetFontString())
                if lab and not fd.labLeft then
                    fd.labLeft = true
                    lab:ClearAllPoints()
                    lab:SetPoint("LEFT", fdd, "LEFT", 8, 0)
                    lab:SetPoint("RIGHT", fdd, "RIGHT", -22, 0)
                    if lab.SetJustifyH then lab:SetJustifyH("LEFT") end
                end
                -- Active-filter reset X (house glyph).
                SkinFilterResetX(fdd.ResetButton, fdd)
            end
        end
        for _, k in ipairs(PROF_GEAR_SLOTS) do SkinProfGearSlot(cp[k]) end
    end

    local sp = f.SpecPage
    if sp then
        for _, k in ipairs({ "ViewTreeButton", "UnlockTabButton", "ApplyButton",
                             "ViewPreviewButton", "BackToFullTreeButton",
                             "BackToPreviewButton" }) do
            if sp[k] then WSkin.Button(sp[k]); WSkin.WhiteButtonLabel(sp[k]) end
        end
        if sp.PanelFooter then WSkin.FadeRegions(sp.PanelFooter) end
        local tv = sp.TreeView
        if tv then
            -- Tree background art is content: keep it dimmed (talents look).
            local keep = {}
            if tv.Background then keep[tv.Background] = true end
            WSkin.FadeRegions(tv, keep)
            if tv.Background then tv.Background:SetAlpha(0.75) end
            -- Tree art bleeds past the center divider: clamp its right edge to the detail pane's left edge.
            local dv0 = sp.DetailedView
            if tv.Background and dv0 and not GetFFD(tv).bgClamped then
                GetFFD(tv).bgClamped = true
                tv.Background:ClearAllPoints()
                tv.Background:SetPoint("TOPLEFT", tv, "TOPLEFT", 0, 0)
                tv.Background:SetPoint("BOTTOMRIGHT", dv0, "BOTTOMLEFT", 0, 0)
            end
        end
        local dv = sp.DetailedView
        if dv then
            WSkin.FadeRegions(dv)
            WSkin.Register(dv, true)
            for _, k in ipairs({ "UnlockPathButton", "SpendPointsButton" }) do
                if dv[k] then WSkin.Button(dv[k]); WSkin.WhiteButtonLabel(dv[k]) end
            end
        end
        -- Spec tabs are pooled and rebuilt; skin now and on every rebuild.
        local function SkinSpecTabs(sp2)
            if sp2.tabsPool then
                for tab in sp2.tabsPool:EnumerateActive() do
                    WSkin.Tab(tab, { darkActive = true })
                end
            end
        end
        if sp.UpdateTabs and not GetFFD(sp).tabHook then
            GetFFD(sp).tabHook = true
            hooksecurefunc(sp, "UpdateTabs", SkinSpecTabs)
        end
        SkinSpecTabs(sp)
    end

    local op = f.OrdersPage
    if op then
        local bf = op.BrowseFrame
        if bf then
            -- Order-type tabs populate LAZILY (some not created until you click
            -- through types), so a one-time pass leaves later ones unstyled;
            -- WSkin.Tab is guarded, so re-runs skin only NEW tabs.
            local ORDER_TAB_KEYS = { "PublicOrdersButton", "NpcOrdersButton",
                                     "GuildOrdersButton", "PersonalOrdersButton" }
            local function SkinOrderTabs()
                for _, k in ipairs(ORDER_TAB_KEYS) do
                    local b = bf[k]
                    if b then WSkin.Tab(b, { darkActive = true }) end
                end
            end
            SkinOrderTabs()
            if C_Timer then C_Timer.After(0, SkinOrderTabs) end
            -- Re-skin AND repaint selection on every order-type switch. These
            -- tabs carry no tabID and BrowseFrame is no TabSystem, so the
            -- engine's PanelTemplates/TabSystem hooks only repaint incidentally.
            -- A per-tab OnClick hook does NOT survive: InitOrderTypeTabs()
            -- re-SetScript's each tab's OnClick on PLAYER_ENTERING_WORLD/
            -- PLAYER_GUILD_UPDATE, wiping the hook and freezing the underline.
            -- Hook the authoritative SETTER instead: a method hook survives
            -- SetScript and catches programmatic switches (leave-guild fallback
            -- to Public); hooksecurefunc runs after the original so isSelected is current.
            if op.SetCraftingOrderType and not GetFFD(op).orderTypeHook then
                GetFFD(op).orderTypeHook = true
                hooksecurefunc(op, "SetCraftingOrderType", SkinOrderTabs)
            end
            -- Tab row starts where the sort header starts: shift the chain root
            -- right by the measured delta (one-shot; other three chain off it).
            -- Rects exist only once laid out, so retry on show.
            local firstTab = bf.PublicOrdersButton
            local function AlignOrderTabs()
                if GetFFD(bf).tabsAligned or not firstTab then return end
                local ol2 = bf.OrderList
                local tl = firstTab.GetLeft and firstTab:GetLeft()
                local ll = ol2 and ol2.GetLeft and ol2:GetLeft()
                if not tl or not ll then return end
                local dx = math.floor((ll - tl) + 0.5)
                if dx == 0 then
                    GetFFD(bf).tabsAligned = true
                    return
                end
                local pts, ok = {}, true
                for i = 1, firstTab:GetNumPoints() do
                    local p, rel, rp, x, y = firstTab:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
                end
                if ok and #pts > 0 then
                    GetFFD(bf).tabsAligned = true
                    firstTab:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        firstTab:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
            AlignOrderTabs()
            if not GetFFD(bf).alignHook then
                GetFFD(bf).alignHook = true
                bf:HookScript("OnShow", function()
                    SkinOrderTabs()
                    if C_Timer then
                        C_Timer.After(0, function() SkinOrderTabs(); AlignOrderTabs() end)
                    else
                        AlignOrderTabs()
                    end
                end)
            end
            local searchBar = bf.SearchBox or bf.searchBox
            if bf.SearchButton then
                WSkin.Button(bf.SearchButton)
                local sfs = bf.SearchButton.GetFontString and bf.SearchButton:GetFontString()
                if sfs then WSkin.White(sfs) end
                local sbtn = bf.SearchButton
                local sd = GetFFD(sbtn)
                if not sd.shrunk then
                    local w, h = sbtn:GetSize()
                    if w and w > 2 and h and h > 2 then
                        sd.shrunk = true
                        sbtn:SetSize(w - 1, h - 1)
                    end
                end
                -- Left edge flush with the search box's left, Y unchanged; retried on show until the search bar lays out.
                local function AlignSearchBtn()
                    if not searchBar or GetFFD(sbtn).leftAligned then return end
                    local bl, sl = sbtn:GetLeft(), searchBar:GetLeft()
                    if not bl or not sl then return end
                    local dx = sl - bl
                    if math.abs(dx) < 0.5 then GetFFD(sbtn).leftAligned = true; return end
                    local np = sbtn:GetNumPoints() or 0
                    local pts, ok = {}, np > 0
                    for i = 1, np do
                        local p, rel, rp, x, y = sbtn:GetPoint(i)
                        if not p then ok = false break end
                        pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
                    end
                    if ok then
                        GetFFD(sbtn).leftAligned = true
                        sbtn:ClearAllPoints()
                        for i = 1, #pts do local t = pts[i]; sbtn:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                    end
                end
                AlignSearchBtn()
                if not GetFFD(sbtn).alignHook then
                    GetFFD(sbtn).alignHook = true
                    bf:HookScript("OnShow", function()
                        if C_Timer then C_Timer.After(0, AlignSearchBtn) else AlignSearchBtn() end
                    end)
                end
            end
            if bf.FavoritesSearchButton then
                -- Keep the star art: Icon key survives the strip, state textures restored after.
                local fav = bf.FavoritesSearchButton
                WSkin.Button(fav, { "Icon" })
                for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture" }) do
                    local t = fav[g] and fav[g](fav)
                    if t and t.SetAlpha then t:SetAlpha(1) end
                end
                -- 10px right of the search box (direct anchor, no rects needed).
                if searchBar and not GetFFD(fav).reseated then
                    GetFFD(fav).reseated = true
                    fav:ClearAllPoints()
                    fav:SetPoint("LEFT", searchBar, "RIGHT", 10, 0)
                end
            end
            if bf.BackButton then WSkin.Button(bf.BackButton) end
            local ord = bf.OrdersRemainingDisplay
            if ord then
                WSkin.FadeRegions(ord)
                WSkin.Register(ord, true)
                -- Top-right, pinned via SetPoint post-hook so Blizzard's browse layout cannot reseat it.
                local od = GetFFD(ord)
                if not od.pinned then
                    od.pinned = true
                    local function Pin()
                        if od.inPin then return end
                        od.inPin = true
                        ord:ClearAllPoints()
                        ord:SetPoint("TOPRIGHT", f, "TOPRIGHT", -20, -35)
                        od.inPin = false
                    end
                    hooksecurefunc(ord, "SetPoint", function()
                        if not od.inPin then Pin() end
                    end)
                    Pin()
                end
                -- Trailing count in accent: display-time recolor, skipped if text already carries a color code.
                local fs
                local regions = { ord:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r.IsObjectType and r:IsObjectType("FontString") then
                        fs = r
                        break
                    end
                end
                if fs and not GetFFD(fs).accentNum then
                    local fsd = GetFFD(fs)
                    fsd.accentNum = true
                    WSkin.Font(fs)
                    WSkin.White(fs)
                    local function Recolor()
                        if fsd.inSet then return end
                        local txt = fs:GetText()
                        if type(txt) ~= "string" or txt == "" then return end
                        if txt:find("|c", 1, true) then return end
                        local EG = EllesmereUI.ELLESMERE_GREEN or { r = 0.047, g = 0.824, b = 0.616 }
                        local hex = string.format("%02x%02x%02x",
                            (EG.r or 0) * 255, (EG.g or 0) * 255, (EG.b or 0) * 255)
                        local new, n = txt:gsub("(%d+%s*)$", "|cff" .. hex .. "%1|r")
                        if n > 0 then
                            fsd.inSet = true
                            fs:SetText(new)
                            fsd.inSet = false
                        end
                    end
                    hooksecurefunc(fs, "SetText", Recolor)
                    hooksecurefunc(fs, "SetFormattedText", Recolor)
                    Recolor()
                end
            end
            local brl = bf.RecipeList
            if brl then
                WSkin.FadeRegions(brl)
                WSkin.Register(brl, true)
                if brl.BackgroundNineSlice then WSkin.FadeNineSlice(brl.BackgroundNineSlice) end
            end
            local ol = bf.OrderList
            if ol then
                WSkin.FadeRegions(ol)
                WSkin.Register(ol, true)
                if ol.BackgroundNineSlice then WSkin.FadeNineSlice(ol.BackgroundNineSlice) end
                -- Sort header: AH-style near-black strip over HeaderContainer
                -- (this list uses HeaderContainer, not the older ColumnDisplay);
                -- SortHeaderBar also strips each column's 3-slice art and whites
                -- its label. Column SET changes per order-type, and Blizzard
                -- rebuilds header buttons IN PLACE via the table builder WITHOUT
                -- re-showing the container, so an OnShow hook never catches fresh
                -- columns. Re-run from the table rebuild (SetupTable) and list
                -- refresh, the same signals AH sort headers ride.
                if ol.HeaderContainer then
                    local function ReskinHeaders() WSkin.SortHeaderBar(ol) end
                    ReskinHeaders()
                    local hc = ol.HeaderContainer
                    if not GetFFD(hc).showHooked then
                        GetFFD(hc).showHooked = true
                        hc:HookScript("OnShow", WSkin.Debounce(ReskinHeaders))
                    end
                    -- Column-rebuild triggers: SetupTable (order-type switch /
                    -- view rebuild) and scroll refresh. Hook whichever exist;
                    -- guarded, idempotent, deferred a frame so new column rects exist.
                    for _, pair in ipairs({ { bf, "SetupTable" }, { ol, "SetupTable" },
                                            { ol, "RefreshScrollFrame" } }) do
                        local host, method = pair[1], pair[2]
                        if host and type(host[method]) == "function" then
                            local hd = GetFFD(host)
                            local flag = "hdrHook_" .. method
                            if not hd[flag] then
                                hd[flag] = true
                                hooksecurefunc(host, method, WSkin.Debounce(ReskinHeaders))
                            end
                        end
                    end
                    -- Guaranteed trigger regardless of Blizzard method names:
                    -- order-type tabs are what the user clicks to repopulate
                    -- the column set. Re-skin a frame after each click.
                    for _, k in ipairs(ORDER_TAB_KEYS) do
                        local tb = bf[k]
                        if tb and not GetFFD(tb).hdrReskin then
                            GetFFD(tb).hdrReskin = true
                            tb:HookScript("OnClick", WSkin.Debounce(ReskinHeaders))
                        end
                    end
                end
                -- Legacy ColumnDisplay fallback (no-op when the list uses HeaderContainer instead).
                local ocd = ol.ColumnDisplay
                if ocd then
                    SkinOrderColumns(ocd)
                    if not GetFFD(ocd).showHooked then
                        GetFFD(ocd).showHooked = true
                        ocd:HookScript("OnShow", WSkin.Debounce(function()
                            SkinOrderColumns(ocd)
                        end))
                    end
                end
            end
        end
        SkinOrderView(op.OrderView)
    end

    WSkin.ScrollBarsIn(f)
    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "professions",
    addons = { Blizzard_Professions = true },
    apply = Skin_Professions,
})
end

-------------------------------------------------------------------------------
--  World Map & Quest Log: flat window chrome, nav bar strip, quest log panel,
--  details/campaign/events/legend panes, side tabs. Deliberately HANDS-OFF:
--  QuestMapFrame's own scripts (Objective Tracker taint path), the session-sync
--  command button, map overlay buttons (tracking/pin/floor) and pooled quest
--  rows stay stock. Visual-only throughout.
-------------------------------------------------------------------------------
do
-- Quest log side tabs: guild sidebar-tab treatment (squared icon on a
-- black-bordered box, 10% hover, 0.12-0.88 icon crop per pass, half alpha when disabled, no active overlay).
local function SkinMapSideTab(tab)
    if not tab or tab:IsForbidden() then return end
    SquareTabIcon(tab)
    local icon = tab.Icon
    local td = GetFFD(tab)
    if icon and not td.box then
        local box = CreateFrame("Frame", nil, tab)
        box:SetPoint("TOPLEFT", icon, "TOPLEFT", -5, 5)
        box:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT", 5, -5)
        box:SetFrameLevel(math.max(0, tab:GetFrameLevel() - 2))
        local fill = SolidTex(box, "BACKGROUND", Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        fill:SetAllPoints(box)
        WSkin.AddBorder(box, 0, 0, 0, 1)
        td.box = box
        td.bg = fill
        local hov = SolidTex(tab, "HIGHLIGHT", 1, 1, 1, 0.1)
        hov:SetPoint("TOPLEFT", box, "TOPLEFT", 0, 0)
        hov:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 0, 0)
        td.hover = hov
    end
    -- Tighter icon zoom than the standard crop (re-applied per pass;
    -- SquareTabIcon resets it to the 0.08 standard above).
    if icon and icon.SetTexCoord then icon:SetTexCoord(0.12, 0.88, 0.12, 0.88) end
    local enabled = not tab.IsEnabled or tab:IsEnabled()
    tab:SetAlpha(enabled and 1 or 0.5)
end

-- Quest log collapsible header rows (rep-tab treatment: band art gone, house
-- plate+hover, white text). Blizzard's +/- stays (small square texture, told
-- apart from wide band art by width). Pooled rows, so everything re-asserts per pass.
local function SkinQuestHeader(btn, kind)
    if not btn or btn:IsForbidden() then return end
    local withCard = kind == "campaign"
    local d = GetFFD(btn)
    local regions = { btn:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= d.plate and r ~= d.hover and r ~= d.card
            and r ~= d.divider
            and r.IsObjectType and r:IsObjectType("Texture") then
            local w = r:GetWidth()
            if w and not issecretvalue(w) and w > 40 then r:SetAlpha(0) end
        end
    end
    -- Campaign card: guild-sidebar tile sheet behind the big header, bottom edge 6px up for breathing room above the first quest title.
    if withCard and not d.card then
        local card = btn:CreateTexture(nil, "BACKGROUND", nil, -5)
        card:SetAtlas("Ui-Dialog-New-Background")
        card:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)
        card:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 6)
        card:SetAlpha(0.5)
        d.card = card
    end
    -- Divider above section headers, separating the campaign block from regular quest sections.
    if kind == "header" and not d.divider then
        local div = btn:CreateTexture(nil, "OVERLAY")
        div:SetColorTexture(1, 1, 1, 0.15)
        local PPd = EllesmereUI and EllesmereUI.PanelPP
        if PPd and PPd.DisablePixelSnap then
            PPd.DisablePixelSnap(div)
            div:SetHeight(PPd.mult or 1)
        else
            div:SetHeight(1)
        end
        div:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 12)
        div:SetPoint("TOPRIGHT", btn, "TOPRIGHT", 0, 12)
        d.divider = div
    end
    local hl = btn.GetHighlightTexture and btn:GetHighlightTexture()
    if hl and hl ~= d.hover then hl:SetAlpha(0) end
    local bt = btn.ButtonText
        or (btn.GetName and btn:GetName() and _G[btn:GetName() .. "ButtonText"])
    if bt and bt.SetTextColor then WSkin.White(bt) end
    if btn.Text and btn.Text.SetTextColor then WSkin.White(btn.Text) end
    -- Blizzard recolors the label gray on hover: re-white after its enter/leave handlers.
    if not d.hoverTextHook then
        d.hoverTextHook = true
        local function ReWhite()
            local bt2 = btn.ButtonText
                or (btn.GetName and btn:GetName() and _G[btn:GetName() .. "ButtonText"])
            if bt2 and bt2.SetTextColor then WSkin.White(bt2) end
            if btn.Text and btn.Text.SetTextColor then WSkin.White(btn.Text) end
        end
        btn:HookScript("OnEnter", ReWhite)
        btn:HookScript("OnLeave", ReWhite)
    end
    if not d.plate then
        d.plate = SolidTex(btn, "BACKGROUND", 1, 1, 1, 0.05)
        local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.05)
        if withCard then
            -- Dialog-sheet art has soft edges, so washes sit 3px inside to
            -- match its visible card; bottom follows the card's raised edge (6px) plus the inset.
            d.plate:SetPoint("TOPLEFT", btn, "TOPLEFT", 3, -3)
            d.plate:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -3, 9)
            hov:SetPoint("TOPLEFT", btn, "TOPLEFT", 3, -3)
            hov:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -3, 9)
        else
            d.plate:SetAllPoints(btn)
            hov:SetAllPoints(btn)
        end
        d.hover = hov
    end
end

local function Skin_WorldMap()
    local f = _G.WorldMapFrame
    if not f then return end
    -- Style-aware shell like every other window: canvas covers the middle, but
    -- quest log flank/top bar/borders show it, and the eui/Modern swap follows the style dropdown.
    WSkin.Shell("worldmap", f)

    WSkin.RemovePortrait(f)
    local bf = f.BorderFrame
    if bf then
        WSkin.RemovePortrait(bf)
        WSkin.FadeRegions(bf)
        WSkin.Register(bf, true)
        if bf.NineSlice then WSkin.FadeNineSlice(bf.NineSlice) end
        if bf.PortraitContainer then
            WSkin.FadeRegions(bf.PortraitContainer)
            WSkin.Register(bf.PortraitContainer, true)
        end
        if _G.WorldMapFramePortrait and _G.WorldMapFramePortrait.SetAlpha then
            _G.WorldMapFramePortrait:SetAlpha(0)
        end
        if bf.CloseButton then WSkin.CloseButton(bf.CloseButton) end
        local mm = bf.MaximizeMinimizeFrame
        if mm then
            SkinProfMaxMin(mm.MinimizeButton, "UI-QuestTrackerButton-Secondary-Collapse")
            SkinProfMaxMin(mm.MaximizeButton, "UI-QuestTrackerButton-Secondary-Expand")
        end
        local title = (bf.TitleContainer and bf.TitleContainer.TitleText) or bf.TitleText
        if title then
            WSkin.Font(title)
            WSkin.White(title)
        end
    end

    -- Breadcrumb nav bar. Keep Blizzard's NATIVE crumb layout: re-widthing or
    -- re-anchoring crumbs (as the Adventure Guide restyle does) flings the
    -- map's text off-window, since the map nav has a home button, an overflow
    -- button, and arrow-shaped crumb geometry the chain logic breaks. Art only:
    -- flatten, one 20% black bar, white text, house carets.
    local nav = f.NavBar
    if nav then
        local nd = GetFFD(nav)
        -- One crumb (home + navList): native art faded, subtle hover, white
        -- text, and the Adventure Guide caret treatment (aspect-correct arrow,
        -- Blizzard's caret re-faded on hover so it cannot resurface from
        -- OnEnter). No width/anchor changes.
        local function SkinMapCrumb(btn)
            if not btn or btn:IsForbidden() then return end
            local d = GetFFD(btn)
            if not d.mapNav then
                d.mapNav = true
                for _, g in ipairs({ "GetNormalTexture", "GetHighlightTexture", "GetPushedTexture", "GetDisabledTexture" }) do
                    local fn = btn[g]; local t = fn and fn(btn); if t and t.SetAlpha then t:SetAlpha(0) end
                end
                WSkin.FadeRegions(btn)
                local hov = SolidTex(btn, "HIGHLIGHT", 1, 1, 1, 0.1)
                hov:SetPoint("TOPLEFT", 2, -3); hov:SetPoint("BOTTOMRIGHT", -2, 3)
                d.hover = hov
                WSkin.Register(btn, true)
                -- Rewinding (clicking an earlier crumb) hides later ones, so
                -- re-anchor the capped bar to the new last crumb.
                btn:HookScript("OnClick", function()
                    if nd.reflow then nd.reflow() end
                end)
            end
            if btn.text then WSkin.White(btn.text) end
            local ma = btn.MenuArrowButton
            if ma then
                local md = GetFFD(ma)
                if not md.arrow then
                    local arrow = ma:CreateTexture(nil, "OVERLAY")
                    arrow:SetAtlas("Azerite-PointingArrow")
                    arrow:SetSize(12, 8.5)   -- native 62x44 aspect
                    arrow:SetPoint("CENTER")
                    md.arrow = arrow
                end
                -- Fade ALL native caret art, keeping our arrow; re-run on hover
                -- so Blizzard's caret cannot resurface from OnEnter.
                local function FadeArrowArt()
                    local keep = { [md.arrow] = true }
                    WSkin.FadeRegions(ma, keep)
                    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
                        local fn = ma[g]; local t = fn and fn(ma); if t and not keep[t] and t.SetAlpha then t:SetAlpha(0) end
                    end
                    if ma.Art and ma.Art.SetAlpha then ma.Art:SetAlpha(0) end
                end
                FadeArrowArt()
                if not md.hoverHooked then
                    md.hoverHooked = true
                    ma:HookScript("OnEnter", FadeArrowArt)
                    ma:HookScript("OnLeave", FadeArrowArt)
                end
            end
        end
        local function RefreshMapNav()
            -- Move the whole bar 4px lower WITHOUT collapsing its width: the nav
            -- has MORE THAN ONE point (TOPLEFT + a right edge), so re-applying
            -- only point 1 shrinks the bar to one crumb and forces every parent
            -- into overflow. Preserve EVERY original point, each -4 in y.
            if nd.origPts == nil then
                local n = nav:GetNumPoints() or 0
                local pts, ok = {}, n > 0
                for i = 1, n do
                    local p, rel, rp, x, y = nav:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) - 4 }
                end
                if ok then nd.origPts = pts end
            end
            if nd.origPts then
                nav:ClearAllPoints()
                for i = 1, #nd.origPts do
                    local t = nd.origPts[i]
                    nav:SetPoint(t[1], t[2], t[3], t[4], t[5])
                end
            end
            for _, k in ipairs({ "InsetBorderBottomLeft", "InsetBorderBottomRight", "InsetBorderBottom",
                                 "InsetBorderLeft", "InsetBorderRight" }) do
                local t = nav[k]; if t and t.SetAlpha then t:SetAlpha(0) end
            end
            local keep = nd.bg and { [nd.bg] = true } or nil
            WSkin.FadeRegions(nav, keep)
            WSkin.Register(nav, true)
            if nav.overlay then
                WSkin.FadeRegions(nav.overlay)
                local nt = nav.overlay.GetNormalTexture and nav.overlay:GetNormalTexture()
                if nt and nt.SetAlpha then nt:SetAlpha(0) end
                if nav.overlay.SetAlpha then nav.overlay:SetAlpha(0) end
                WSkin.Register(nav.overlay, true)
            end
            if nav.homeButton then SkinMapCrumb(nav.homeButton) end
            if nav.navList then
                for i = 1, #nav.navList do SkinMapCrumb(nav.navList[i]) end
            end
            -- 20% black bar: left edge on the nav, right edge 8px past the LAST
            -- crumb (capped, never spanning the whole frame).
            if not nd.bg then
                local bar = nav:CreateTexture(nil, "BACKGROUND", nil, -6)
                bar:SetColorTexture(0, 0, 0, 0.2)
                nd.bg = bar
            end
            local last = (nav.navList and #nav.navList > 0 and nav.navList[#nav.navList]) or nav.homeButton
            nd.bg:ClearAllPoints()
            nd.bg:SetPoint("TOPLEFT", nav, "TOPLEFT", 0, 0)
            nd.bg:SetPoint("BOTTOMLEFT", nav, "BOTTOMLEFT", 0, 0)
            if last then
                nd.bg:SetPoint("RIGHT", last, "RIGHT", 8, 0)
            else
                nd.bg:SetPoint("RIGHT", nav, "RIGHT", 0, 0)
            end
            -- Overflow ("...") button: flatten, aspect-correct arrow, hover,
            -- Blizzard's art re-faded on hover.
            local ovf = nav.overflowButton
            if ovf then
                local od = GetFFD(ovf)
                if not od.mapOvf then
                    od.mapOvf = true
                    local arrow = ovf:CreateTexture(nil, "OVERLAY")
                    arrow:SetAtlas("Azerite-PointingArrow")
                    arrow:SetSize(12, 8.5)
                    arrow:SetPoint("CENTER")
                    od.arrow = arrow
                    od.hover = SolidTex(ovf, "HIGHLIGHT", 1, 1, 1, 0.1)
                    od.hover:SetAllPoints(ovf)
                end
                local function FadeOvfArt()
                    local keep = { [od.arrow] = true }
                    if od.hover then keep[od.hover] = true end
                    WSkin.FadeRegions(ovf, keep)
                    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
                        local fn = ovf[g]; local t = fn and fn(ovf); if t and not keep[t] and t.SetAlpha then t:SetAlpha(0) end
                    end
                end
                FadeOvfArt()
                if not od.hoverHooked then
                    od.hoverHooked = true
                    ovf:HookScript("OnEnter", FadeOvfArt)
                    ovf:HookScript("OnLeave", FadeOvfArt)
                end
            end
        end
        nd.reflow = RefreshMapNav
        RefreshMapNav()
        if not nd.addBtnHook and type(_G.NavBar_AddButton) == "function" then
            nd.addBtnHook = true
            hooksecurefunc("NavBar_AddButton", function(bar)
                if bar == nav then RefreshMapNav() end
            end)
        end
    end

    local spt = f.SidePanelToggle
    if spt then
        if spt.CloseButton then WSkin.PageButton(spt.CloseButton, "<") end
        if spt.OpenButton then WSkin.PageButton(spt.OpenButton, ">") end
    end

    ---------------------------------------------------------------------------
    --  Quest log panel
    ---------------------------------------------------------------------------
    local qm = _G.QuestMapFrame
    if qm then
        if qm.VerticalSeparator then qm.VerticalSeparator:SetAlpha(0) end
        if qm.Background then qm.Background:SetAlpha(0) end

        local qs = _G.QuestScrollFrame
        if qs then
            for _, k in ipairs({ "Edge", "Background", "Center" }) do
                local t = qs[k]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            if qs.BorderFrame then qs.BorderFrame:SetAlpha(0) end
            if qs.Contents and qs.Contents.Separator then
                qs.Contents.Separator:SetAlpha(0)
            end
            local sh = qs.Contents and qs.Contents.StoryHeader
            if sh then
                if sh.TopFiligree then sh.TopFiligree:SetAlpha(0) end
                if sh.Divider then sh.Divider:SetAlpha(0) end
            end
            if qs.SearchBox then WSkin.EditBox(qs.SearchBox) end
            if qs.ScrollBar then WSkin.ScrollBar(qs.ScrollBar) end
            -- Collapsible section headers: pooled, re-skinned on every quest
            -- log update.
            local function SkinQuestHeaders()
                for _, poolKey in ipairs({ "headerFramePool",
                                           "campaignHeaderFramePool",
                                           "campaignHeaderMinimalFramePool" }) do
                    local pool = qs[poolKey]
                    if pool and pool.EnumerateActive then
                        local kind = (poolKey == "campaignHeaderFramePool" and "campaign")
                            or (poolKey == "headerFramePool" and "header")
                            or "minimal"
                        pcall(function()
                            for btn in pool:EnumerateActive() do
                                SkinQuestHeader(btn, kind)
                            end
                        end)
                    end
                end
                -- ONE divider only: the topmost regular header marks the
                -- campaign/regular boundary, all others hide theirs.
                local hp = qs.headerFramePool
                if hp and hp.EnumerateActive then
                    pcall(function()
                        local topBtn, topY
                        for btn in hp:EnumerateActive() do
                            local t = btn.GetTop and btn:GetTop()
                            if t and not issecretvalue(t)
                                and (not topY or t > topY) then
                                topY = t
                                topBtn = btn
                            end
                        end
                        if topBtn then
                            for btn in hp:EnumerateActive() do
                                local bd2 = FFD[btn]
                                local div = bd2 and bd2.divider
                                if div then div:SetShown(btn == topBtn) end
                            end
                        end
                    end)
                end
            end
            SkinQuestHeaders()
            if type(_G.QuestLogQuests_Update) == "function"
                and not GetFFD(qs).qhHook then
                GetFFD(qs).qhHook = true
                hooksecurefunc("QuestLogQuests_Update", SkinQuestHeaders)
            end
        end

        -- Midnight nests the details frame under QuestsFrame; older layouts had
        -- it directly on QuestMapFrame, so both paths are checked.
        local det = qm.DetailsFrame or (qm.QuestsFrame and qm.QuestsFrame.DetailsFrame)
        if det then
            if det.BorderFrame then det.BorderFrame:SetAlpha(0) end
            if det.SealMaterialBG then det.SealMaterialBG:SetAlpha(0) end
            WSkin.FadeRegions(det)
            WSkin.Register(det, true)
            if det.BackFrame then
                WSkin.FadeRegions(det.BackFrame)
                WSkin.Register(det.BackFrame, true)
                if det.BackFrame.BackButton then WSkin.Button(det.BackFrame.BackButton) end
            end
            for _, k in ipairs({ "AbandonButton", "ShareButton", "TrackButton" }) do
                local b = det[k]
                if b then
                    WSkin.FadeRegions(b)
                    WSkin.Button(b)
                end
            end
            local rfc = det.RewardsFrameContainer
            if rfc and rfc.RewardsFrame then
                WSkin.FadeRegions(rfc.RewardsFrame)
                WSkin.Register(rfc.RewardsFrame, true)
                -- Rewards backdrop: solid #050505 base + the guild sidebar card
                -- texture over it, full size. Stored under protected keys so a
                -- Restrip never fades them.
                local rd = GetFFD(rfc)
                if not rd.bg then
                    local base = rfc:CreateTexture(nil, "BACKGROUND", nil, -7)
                    base:SetColorTexture(0.0196, 0.0196, 0.0196, 1)   -- #050505 @ 100%
                    base:SetAllPoints(rfc)
                    rd.bg = base
                    local card = rfc:CreateTexture(nil, "BACKGROUND", nil, -6)
                    card:SetAtlas("Ui-Dialog-New-Background")
                    card:SetTexCoord(0, 1, 0, 1)
                    card:SetAlpha(0.5)
                    card:SetAllPoints(rfc)
                    rd.fill = card
                end
            end
            -- Quest detail text: section headers (title / description /
            -- objectives / rewards) = quest yellow; body text + pooled
            -- objective lines = white. Re-applied per map quest display.
            local function StyleQuestText()
                for _, n in ipairs({ "QuestInfoTitleHeader", "QuestInfoDescriptionHeader",
                                     "QuestInfoObjectivesHeader" }) do
                    local fs = _G[n]
                    if fs and fs.SetTextColor then fs:SetTextColor(1, 0.82, 0) end
                end
                local rw = _G.QuestInfoRewardsFrame
                if rw then
                    WhitenTextIn(rw)  -- catch nested spell/effect + SimpleHTML reward blurbs
                    if rw.Header and rw.Header.SetTextColor then rw.Header:SetTextColor(1, 0.82, 0) end
                end
                -- Reward tiles in the MAP / quest log. Blizzard ships a SECOND
                -- rewards frame for this panel -- MapQuestInfoRewardsFrame,
                -- built from the Small item button template -- so the quest
                -- pack's work on QuestInfoRewardsFrame never reaches here and
                -- every reward in the log stayed stock. Both are walked because
                -- which one the map populates has moved between builds.
                --
                -- Same treatment as the NPC window: drop the QuestItemBorder
                -- plate, white the name, square the icon, and give it back the
                -- rarity as a SQUARE border rather than Blizzard's rounded one.
                for _, rf in ipairs({ _G.MapQuestInfoRewardsFrame, rw }) do
                    if rf and rf.RewardButtons then
                        for _, btn in ipairs(rf.RewardButtons) do
                            WSkin.QuestRewardTile(btn)
                        end
                    end
                    if rf then
                        -- Same as the NPC window: strip the rings, THEN square.
                        -- Squaring alone left the gold coin wearing its border
                        -- while the currency tiles beside it were clean.
                        for _, k in ipairs({ "MoneyFrame", "XPFrame", "HonorFrame",
                                             "SkillPointFrame", "PlayerTitleFrame" }) do
                            local sub = rf[k]
                            if sub then
                                for _, ak in ipairs({ "NameFrame", "IconBorder", "IconOverlay",
                                                      "IconOverlay2", "IconBorder2", "Border" }) do
                                    local t = sub[ak]
                                    if t and t.SetAlpha and t.IsObjectType
                                       and t:IsObjectType("Texture") then
                                        t:SetAlpha(0)
                                    end
                                end
                                if sub.Icon then
                                    WSkin.SquareIcon(sub.Icon, nil)
                                elseif sub.GetRegions then
                                    local regs = { sub:GetRegions() }
                                    for ri = 1, #regs do
                                        local r = regs[ri]
                                        if r and r.IsObjectType and r:IsObjectType("Texture")
                                           and r:GetAlpha() > 0 then
                                            WSkin.SquareIcon(r, nil)
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                for _, n in ipairs({ "QuestInfoDescriptionText", "QuestInfoObjectivesText",
                                     "QuestInfoGroupSize" }) do
                    local fs = _G[n]
                    if fs and fs.SetTextColor then fs:SetTextColor(1, 1, 1) end
                end
                local of = _G.QuestInfoObjectivesFrame
                if of and of.Objectives then
                    for _, obj in ipairs(of.Objectives) do
                        if obj and obj.SetTextColor then obj:SetTextColor(1, 1, 1) end
                    end
                end
            end
            if not GetFFD(det).questTextHook and type(_G.QuestInfo_Display) == "function" then
                GetFFD(det).questTextHook = true
                hooksecurefunc("QuestInfo_Display", function(_, parentFrame)
                    -- MAP only (parent chain reaches QuestMapFrame):
                    -- QuestInfo_Display also drives the NPC quest window, which
                    -- must not be touched.
                    if not parentFrame then return end
                    local p, isMap = parentFrame, false
                    for _i = 1, 8 do
                        if p == qm then isMap = true break end
                        p = p.GetParent and p:GetParent()
                        if not p then break end
                    end
                    if not isMap then return end
                    StyleQuestText()
                    -- Re-assert next frame: Blizzard colors objectives after this call.
                    if C_Timer then C_Timer.After(0, StyleQuestText) end
                end)
            end
            if qm:IsShown() then StyleQuestText() end
        end
        local dsf = _G.QuestMapDetailsScrollFrame
        if dsf and dsf.ScrollBar then WSkin.ScrollBar(dsf.ScrollBar) end

        local co = qm.QuestsFrame and qm.QuestsFrame.CampaignOverview
        if co then
            if co.BorderFrame then co.BorderFrame:SetAlpha(0) end
            WSkin.FadeRegions(co)
            WSkin.Register(co, true)
            if co.ScrollFrame and co.ScrollFrame.ScrollBar then
                WSkin.ScrollBar(co.ScrollFrame.ScrollBar)
            end
        end

        if qm.QuestSessionManagement then
            WSkin.FadeRegions(qm.QuestSessionManagement)
            WSkin.Register(qm.QuestSessionManagement, true)
        end

        -- 11.1 side tabs (quests / events / map legend)
        for _, k in ipairs({ "QuestsTab", "EventsTab", "MapLegendTab" }) do
            SkinMapSideTab(qm[k])
        end
        -- Chain seat: box edge flush with the window edge (measured once on the
        -- first laid-out show), gaps 8px tighter down the chain.
        local function SeatSideTabs()
            local gd2 = GetFFD(qm)
            if gd2.sideSeated then return end
            local qt = qm.QuestsTab
            local icon = qt and qt.Icon
            local qmR = qm.GetRight and qm:GetRight()
            local iL = icon and icon.GetLeft and icon:GetLeft()
            if not qmR or not iL then return end
            gd2.sideSeated = true
            local dx = math.floor((qmR - (iL - 5)) + 0.5) + 2
            if dx ~= 0 then
                local np = qt:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = qt:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
                end
                if ok then
                    qt:ClearAllPoints()
                    for i = 1, #pts do
                        local t = pts[i]
                        qt:SetPoint(t[1], t[2], t[3], t[4], t[5])
                    end
                end
            end
            for _, k2 in ipairs({ "EventsTab", "MapLegendTab" }) do
                local tb = qm[k2]
                if tb then
                    local td2 = GetFFD(tb)
                    if not td2.gapAdj then
                        local p, rel, rp, x, y = tb:GetPoint(1)
                        if p then
                            td2.gapAdj = true
                            tb:ClearAllPoints()
                            tb:SetPoint(p, rel, rp, x or 0, (y or 0) + 8)
                        end
                    end
                end
            end
        end
        SeatSideTabs()
        if not GetFFD(qm).sideSeatHook then
            GetFFD(qm).sideSeatHook = true
            qm:HookScript("OnShow", function()
                if C_Timer then
                    C_Timer.After(0, SeatSideTabs)
                else
                    SeatSideTabs()
                end
            end)
        end

        local ev = qm.EventsFrame
        if ev then
            -- Direct region fade also kills this pane's stray yellow box texture.
            WSkin.FadeRegions(ev)
            WSkin.Register(ev, true)
            if ev.TitleText then WSkin.Font(ev.TitleText); WSkin.White(ev.TitleText) end
            if ev.BorderFrame then ev.BorderFrame:SetAlpha(0) end
            if ev.ScrollBox and ev.ScrollBox.Background then ev.ScrollBox.Background:SetAlpha(0) end
            if ev.ScrollBar then WSkin.ScrollBar(ev.ScrollBar) end
            -- Row styling via the acquired-frame callback: headers get the
            -- house plate + white label, event tiles the flat white hover.
            if ev.ScrollBox and _G.ScrollUtil
                and _G.ScrollUtil.AddAcquiredFrameCallback
                and not GetFFD(ev).rowCb then
                GetFFD(ev).rowCb = true
                local function StyleEventRow(_, row, elementData)
                    if not row or type(elementData) ~= "table" then return end
                    local et = elementData.data and elementData.data.entryType
                    local rd = GetFFD(row)
                    if et == 1 or et == 3 then
                        if row.Background and row.Background.SetAlpha then
                            row.Background:SetAlpha(0)
                        end
                        if not rd.plate then
                            rd.plate = SolidTex(row, "BACKGROUND", 1, 1, 1, 0.05)
                            rd.plate:SetAllPoints(row)
                        end
                        if row.Label and row.Label.SetTextColor then
                            WSkin.White(row.Label)
                        end
                    else
                        if row.Highlight and row.Highlight.SetColorTexture then
                            row.Highlight:SetColorTexture(1, 1, 1, 0.1)
                            row.Highlight:SetAllPoints(row)
                        end
                    end
                end
                pcall(_G.ScrollUtil.AddAcquiredFrameCallback,
                    ev.ScrollBox, StyleEventRow, ev, true)
            end
        end

        local ml = qm.MapLegend
        if ml then
            if ml.TitleText then WSkin.Font(ml.TitleText); WSkin.White(ml.TitleText) end
            if ml.BorderFrame then ml.BorderFrame:SetAlpha(0) end
            local mls = ml.ScrollFrame
            if mls then
                if mls.Background then mls.Background:SetAlpha(0) end
                if mls.Center then mls.Center:SetAlpha(0) end
                if mls.ScrollBar then WSkin.ScrollBar(mls.ScrollBar) end
            end
        end
    end

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then WSkin.Restrip() end
    end))
end

WSkin.RegisterWindow({
    key = "worldmap",
    addons = { Blizzard_WorldMap = true },
    apply = Skin_WorldMap,
})
end

-------------------------------------------------------------------------------
--  Micro Menu & Bags. The glyph IS the button's Normal/Pushed/Disabled atlas,
--  so it is never hidden: raised plate goes, bevel ring cropped off, a flat
--  box frames it. Micro buttons are SECURE, so every visual write is
--  combat-guarded. Blizzard container frames are skipped entirely when the
--  EllesmereUI Bags addon is active (they never show).
-------------------------------------------------------------------------------
do
local MICRO_BUTTONS = {
    "CharacterMicroButton", "ProfessionMicroButton", "PlayerSpellsMicroButton",
    "AchievementMicroButton", "QuestLogMicroButton", "GuildMicroButton",
    "LFDMicroButton", "CollectionsMicroButton", "EJMicroButton",
    "StoreMicroButton", "MainMenuMicroButton", "HelpMicroButton",
    "HousingMicroButton",
}
-- WoW Forever keeps several micro buttons retail folded away or renamed (spellbook
-- and talents split out, socials and PvP as their own buttons). Add them so the
-- Forever pass skins the whole row; missing/forbidden buttons are skipped per-button.
if EllesmereUI.IS_FOREVER then
    for _, n in ipairs({ "SpellbookMicroButton", "TalentMicroButton", "SocialsMicroButton", "PVPMicroButton", "LegacyMicroButton" }) do
        MICRO_BUTTONS[#MICRO_BUTTONS + 1] = n
    end
end
local MICRO_DECO  = { "Background", "PushedBackground", "FlashBorder", "Shadow", "PushedShadow", "Border", "Backdrop" }
local MICRO_TRIM  = 0.08
local MICRO_INSET = 1
local MICRO_GAP   = 2
local MICRO_BG_A  = 0.45

local function TrimMicroTex(tex, box)
    if not tex or not tex.SetTexCoord then return end
    if tex.SetDrawLayer then tex:SetDrawLayer("ARTWORK") end
    if MICRO_TRIM > 0 then tex:SetTexCoord(MICRO_TRIM, 1 - MICRO_TRIM, MICRO_TRIM, 1 - MICRO_TRIM) end
    tex:ClearAllPoints()
    tex:SetPoint("TOPLEFT", box, "TOPLEFT", MICRO_INSET, -MICRO_INSET)
    tex:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -MICRO_INSET, MICRO_INSET)
end

local function SkinMicroButtonInner(btn)
        for _, k in ipairs(MICRO_DECO) do
            local r = btn[k]
            if r and r.SetAlpha then r:SetAlpha(0) end
        end
        local d = GetFFD(btn)
        if not d.box then
            local box = CreateFrame("Frame", nil, btn)
            box:SetPoint("TOPLEFT", MICRO_GAP, -MICRO_GAP)
            box:SetPoint("BOTTOMRIGHT", -MICRO_GAP, MICRO_GAP)
            local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -8)
            bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, MICRO_BG_A)
            bg:SetPoint("TOPLEFT", box, "TOPLEFT", 0, 0)
            bg:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 0, 0)
            WSkin.AddBorder(box)
            d.box, d.bg = box, bg
            local hl = btn.GetHighlightTexture and btn:GetHighlightTexture()
            if hl and hl.SetColorTexture then
                hl:SetColorTexture(1, 1, 1, 0.1)
                if hl.SetTexCoord then hl:SetTexCoord(0, 1, 0, 1) end
                hl:ClearAllPoints()
                hl:SetPoint("TOPLEFT", box, "TOPLEFT", 0, 0)
                hl:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 0, 0)
            end
        end
        if btn.GetNormalTexture then TrimMicroTex(btn:GetNormalTexture(), d.box) end
        if btn.GetPushedTexture then TrimMicroTex(btn:GetPushedTexture(), d.box) end
        if btn.GetDisabledTexture then TrimMicroTex(btn:GetDisabledTexture(), d.box) end
        if btn.Portrait then TrimMicroTex(btn.Portrait, d.box) end
end

-- Named wrapper so the hot UpdateMicroButtons path allocates no closure per call (13 buttons x every fire = real GC churn otherwise).
local function SkinMicroButton(btn)
    if not btn or btn:IsForbidden() then return end
    pcall(SkinMicroButtonInner, btn)
end

local _microHook = false
local function Skin_MicroMenu()
    if InCombatLockdown() then return end
    for _, name in ipairs(MICRO_BUTTONS) do SkinMicroButton(_G[name]) end
    -- WoW Forever's MicroMenu keeps a Blizzard container strip (BackgroundArt +
    -- BorderArt); on retail the EllesmereUI Bags addon hides the container, so it
    -- never shows. Fade that art so the flat buttons do not sit inside an ornate
    -- frame. Alpha only -- never :Hide() the Edit-Mode-owned container.
    if EllesmereUI.IS_FOREVER and _G.MicroMenu then
        local mm = _G.MicroMenu
        if mm.BackgroundArt and mm.BackgroundArt.SetAlpha then mm.BackgroundArt:SetAlpha(0) end
        if mm.BorderArt and mm.BorderArt.SetAlpha then mm.BorderArt:SetAlpha(0) end
    end
    if not _microHook and _G.UpdateMicroButtons then
        _microHook = true
        -- UpdateMicroButtons fires several times per frame on routine events:
        -- debounce collapses each burst into ONE repaint instead of re-trimming all 13 buttons per fire.
        local repaint = WSkin.Debounce(function()
            if InCombatLockdown() then return end
            for _, name in ipairs(MICRO_BUTTONS) do SkinMicroButton(_G[name]) end
        end)
        hooksecurefunc("UpdateMicroButtons", repaint)
    end
end

-- Registered on both clients. On WoW Forever this also covers the legacy micro
-- buttons appended to MICRO_BUTTONS above, so the whole row matches the house look.
WSkin.RegisterWindow({
    key = "micromenu",
    apply = function()
        -- Micro buttons are secure: if this runs mid-combat (reload during a fight), defer the pass to end of combat.
        if InCombatLockdown() then
            ns.CombatQueue.Defer("MicroMenuSkin", function() pcall(Skin_MicroMenu) end)
            return
        end
        pcall(Skin_MicroMenu)
    end,
})
end

-------------------------------------------------------------------------------
--  Dressing Room (DressUpFrame). Chrome + action buttons; the 3D model scene
--  and custom-set detail panel stay stock content.
-------------------------------------------------------------------------------
do
local _dressHooked = false
local function Skin_DressUp()
    local f = _G.DressUpFrame
    if not f then return end
    WSkin.Shell("dressup", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "DressUpFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    for _, k in ipairs({ "Bg", "Background" }) do
        if f[k] and f[k].SetAlpha then f[k]:SetAlpha(0) end
    end
    -- Window backdrop is the global DressUpFrameBg, not a parentKey.
    if _G.DressUpFrameBg and _G.DressUpFrameBg.SetAlpha then _G.DressUpFrameBg:SetAlpha(0) end
    -- Model sits inside DressUpFrameInset, which carries its OWN backdrop (Bg)/border (NineSlice), separate from the window's.
    local inset = f.Inset or _G.DressUpFrameInset
    if inset then WSkin.Inset(inset) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.DressUpFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    -- 3D model area's backdrop+border sit on CHILD frames the shell's region
    -- fade cannot reach (textures directly on the window only). Fade the flat
    -- model background and model scene's own textures/border; the model renders via actors, so it stays.
    if f.ModelBackground and f.ModelBackground.SetAlpha then f.ModelBackground:SetAlpha(0) end
    local ms = f.ModelScene
    if ms then
        WSkin.FadeRegions(ms)
        if ms.NineSlice then WSkin.FadeNineSlice(ms.NineSlice) end
        WSkin.Register(ms, true)
    end
    -- Max/Min button: spellbook-style +/- glyph (collapse/expand chevrons).
    local mm = f.MaximizeMinimizeFrame
    if mm then
        SkinProfMaxMin(mm.MinimizeButton, "UI-QuestTrackerButton-Secondary-Collapse")
        SkinProfMaxMin(mm.MaximizeButton, "UI-QuestTrackerButton-Secondary-Expand")
    end
    -- Action buttons: flat treatment + white labels. Reset/Cancel are globals, Link/Toggle are parentKeys.
    local function SkinBtn(b)
        if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
    end
    SkinBtn(_G.DressUpFrameResetButton)
    SkinBtn(_G.DressUpFrameCancelButton)
    SkinBtn(f.LinkButton)
    -- ToggleCustomSetDetailsButton (opens the appearance list) stays fully
    -- stock. Saved-outfit dropdown 10% smaller and 4px down (child save button
    -- rides along), save button 3px taller. Blizzard re-anchors the dropdown
    -- per view (minimize/maximize), so re-apply the offset on every SetPoint (reentry-guarded), not once.
    local dd = f.CustomSetDropdown or _G.DressUpFrameCustomSetDropdown
    if dd then
        WSkin.Dropdown(dd)
        local ddd = GetFFD(dd)
        if not ddd.scaled then
            ddd.scaled = true
            dd:SetScale(0.9)
        end
        if not ddd.shiftHook then
            ddd.shiftHook = true
            local guard = false
            hooksecurefunc(dd, "SetPoint", function(self)
                if guard then return end
                guard = true
                local p, rel, rp, x, y = self:GetPoint(1)
                if p then
                    self:ClearAllPoints()
                    self:SetPoint(p, rel, rp, x or 0, (y or 0) - 4)
                end
                guard = false
            end)
            local p, rel, rp, x, y = dd:GetPoint(1)
            if p then dd:SetPoint(p, rel, rp, x or 0, y or 0) end
        end
        local sb = dd.SaveButton
        if sb then
            SkinBtn(sb)
            local sbd = GetFFD(sb)
            if not sbd.heightBumped and sb.GetHeight then
                sbd.heightBumped = true
                sb:SetHeight(sb:GetHeight() + 3)
            end
        end
    end
    -- Outfit selection list: fade its framed chrome, theme the scrollbar.
    local ssp = f.SetSelectionPanel
    if ssp then
        if ssp.NineSlice then WSkin.FadeNineSlice(ssp.NineSlice) end
        if ssp.Bg and ssp.Bg.SetAlpha then ssp.Bg:SetAlpha(0) end
        WSkin.ScrollBarsIn(ssp)
    end
    -- Custom-set details panel: replace ONLY its border. Fade OVERLAY/BORDER
    -- layer art but spare the named black/class backdrops by identity, then
    -- seat a themed border sized to the backdrop so it hugs content, not the padded frame edge.
    local dp = f.CustomSetDetailsPanel
    if dp then
        local dd = GetFFD(dp)
        if not dd.bordered then
            dd.bordered = true
            local keep = {}
            if dp.BlackBackground then keep[dp.BlackBackground] = true end
            if dp.ClassBackground then keep[dp.ClassBackground] = true end
            local regions = { dp:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and not keep[r] and r.IsObjectType and r:IsObjectType("Texture") then
                    local layer = r:GetDrawLayer()
                    if layer == "OVERLAY" or layer == "BORDER" then r:SetAlpha(0) end
                end
            end
            if dp.NineSlice then WSkin.FadeNineSlice(dp.NineSlice) end
            local bg = dp.BlackBackground or dp.ClassBackground
            if bg then
                local host = CreateFrame("Frame", nil, dp)
                host:SetAllPoints(bg)
                dd.borderHost = host
                WSkin.AddBorder(host)
            end
        end
        WSkin.ScrollBarsIn(dp)
    end
    -- Blizzard re-shows window chrome (NineSlice/Bg/model backdrop) on every open, so re-run the FULL skin on show, not just a Restrip.
    if not _dressHooked then
        _dressHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_DressUp() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "dressup",
    apply = Skin_DressUp,
})
end

-------------------------------------------------------------------------------
--  Transmogrifier (TransmogFrame). Chrome + action controls; the model,
--  transmog slot buttons and embedded appearance list stay stock content.
-------------------------------------------------------------------------------
do
local _transmogHooked = false
local function Skin_Transmog()
    local f = _G.TransmogFrame
    if not f then return end
    WSkin.Shell("transmog", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "TransmogFrame")   -- close + paging + controls
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Inset then WSkin.Inset(f.Inset) end
    for _, k in ipairs({ "Bg", "Background" }) do
        if f[k] and f[k].SetAlpha then f[k]:SetAlpha(0) end
    end
    if _G.TransmogFrameBg and _G.TransmogFrameBg.SetAlpha then _G.TransmogFrameBg:SetAlpha(0) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.TransmogFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    if f.ApplyButton then WSkin.Button(f.ApplyButton); WSkin.WhiteButtonLabel(f.ApplyButton) end
    local od = f.OutfitDropdown
    if od then
        WSkin.Dropdown(od)
        if od.SaveButton then WSkin.Button(od.SaveButton); WSkin.WhiteButtonLabel(od.SaveButton) end
    end
    -- Save Outfit button: flat treatment, but the label mirrors the native
    -- enabled/disabled state (white when clickable, gray when not); a plain
    -- WhiteButtonLabel would leave a disabled button reading as active.
    local oc = f.OutfitCollection
    if oc and oc.SaveOutfitButton then
        local b = oc.SaveOutfitButton
        WSkin.Button(b)
        -- Borderless + 2px shorter (this button only).
        local PPb = EllesmereUI.PP
        if PPb and PPb.GetBorders and PPb.HideBorder and PPb.GetBorders(b) then
            PPb.HideBorder(b)
        end
        local bd0 = GetFFD(b)
        if not bd0.slimmed then
            bd0.slimmed = true
            local h = b:GetHeight()
            if h and h > 2 then b:SetHeight(h - 2) end
        end
        local lab = b.Text or (b.GetFontString and b:GetFontString())
        if lab then
            local function reflect()
                if b:IsEnabled() then WSkin.White(lab) else lab:SetTextColor(0.5, 0.5, 0.5) end
            end
            local bd = GetFFD(b)
            if not bd.stateHook then
                bd.stateHook = true
                b:HookScript("OnEnable", reflect)
                b:HookScript("OnDisable", reflect)
            end
            reflect()
        end
    end
    -- Right-side appearance browser: flatten the tab headers (standard
    -- lighter-active look), left-align the Sources filter label on the items
    -- and sets views, and raise the header row above stock.
    local wc = f.WardrobeCollection
    if wc then
        if wc.TabHeaders then
            local children = { wc.TabHeaders:GetChildren() }
            for i = 1, #children do
                local tab = children[i]
                if tab and tab.GetObjectType and tab:GetObjectType() == "Button" then
                    WSkin.Tab(tab)
                    -- Blizzard's active-line effect is a SelectedHighlight
                    -- CHILD frame that the tab region sweep cannot reach;
                    -- container alpha suppresses it and its textures.
                    if tab.SelectedHighlight and tab.SelectedHighlight.SetAlpha then
                        tab.SelectedHighlight:SetAlpha(0)
                    end
                end
            end
            local th = wc.TabHeaders
            if not GetFFD(th).raised then
                local np = th:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = th:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + 6 }
                end
                if ok then
                    GetFFD(th).raised = true
                    th:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; th:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            end
        end
        local tc = wc.TabContent
        if tc then
            for _, k in ipairs({ "ItemsFrame", "SetsFrame" }) do
                local sub = tc[k]
                if sub and sub.FilterButton then LeftAlignFilterLabel(sub.FilterButton) end
            end
            local csf = tc.CustomSetsFrame
            if csf and csf.NewCustomSetButton then
                WSkin.Button(csf.NewCustomSetButton)
                WSkin.WhiteButtonLabel(csf.NewCustomSetButton)
            end
            local sif = tc.SituationsFrame
            if sif and sif.DefaultsButton then
                WSkin.Button(sif.DefaultsButton)
                WSkin.WhiteButtonLabel(sif.DefaultsButton)
            end
            -- Swap Blizzard's content border for the themed one. Frame rect runs
            -- a few px past the visible list, but its Background region spans
            -- the true content area, so the border seats on a host pinned to that.
            local bd = tc.Border
            if bd then
                if bd.IsObjectType and bd:IsObjectType("Texture") then
                    bd:SetAlpha(0)
                else
                    WSkin.FadeRegions(bd)
                    WSkin.Register(bd, true)
                    if bd.SetAlpha then bd:SetAlpha(0) end
                end
            end
            local tcd = GetFFD(tc)
            if not tcd.borderHost then
                local host = CreateFrame("Frame", nil, tc)
                host:SetAllPoints(tc.Background or tc)
                tcd.borderHost = host
                WSkin.AddBorder(host)
            end
        end
    end
    -- Blizzard re-shows the window chrome on open (as with DressUpFrame), so
    -- re-run the full skin on show.
    if not _transmogHooked then
        _transmogHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Transmog() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "transmog",
    addons = { Blizzard_Transmog = true },
    apply = Skin_Transmog,
})
end

-------------------------------------------------------------------------------
--  Merchant (MerchantFrame). Shell + tabs + item tiles as flat cards (mail-row
--  treatment); repair/sell-junk icon buttons and the buyback money display stay stock content.
-------------------------------------------------------------------------------
do
-- Hide Blizzard's native pagination and 10-slot grid permanently, via the
-- achievements-pack Kill pattern: a reentry-safe hooksecurefunc re-hiding on
-- every Blizzard Show (MerchantFrame_Update re-Shows tiles each pass), NEVER a
-- method overwrite on a Blizzard frame table. Registry lives on WSkin so re-runs of Skin_Merchant cannot double-hook.
local function KillFrameShow(frame)
    if not frame then return end
    local killed = WSkin._merchantKilledShow
    if not killed then
        killed = setmetatable({}, { __mode = "k" })
        WSkin._merchantKilledShow = killed
    end
    if killed[frame] then frame:Hide() return end
    killed[frame] = true
    frame:Hide()
    hooksecurefunc(frame, "Show", function(self) self:Hide() end)
end

local function HideNativeMerchantGrid()
    for i = 1, 12 do
        local item = _G["MerchantItem" .. i]
        if item then
            item:SetAlpha(0)
            KillFrameShow(item)
        end
    end

    local controls = {
        _G.MerchantPrevPageButton,
        _G.MerchantNextPageButton,
        _G.MerchantPageText
    }
    for _, ctrl in ipairs(controls) do
        KillFrameShow(ctrl)
    end
end

-- Build the ScrollFrame (once).
local function CreateMerchantScrollList(parent)
    local sf = CreateFrame("ScrollFrame", "WSkinMerchantScrollFrame", parent, "UIPanelScrollFrameTemplate")
    -- Fits inside MerchantFrame, leaving room for repair/buyback buttons.
    sf:SetPoint("TOPLEFT", parent, "TOPLEFT", 20, -70)
    sf:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -32, 80)

    local child = CreateFrame("Frame", "WSkinMerchantScrollChild", sf)
    child:SetPoint("TOPLEFT")
    child:SetPoint("TOPRIGHT")
    child:SetSize(1, 1)
    sf:SetScrollChild(child)

    sf.rows = {}
    return sf, child
end

-- Same as the default UI's version, with frameName pointed at our own buttons.
function EUI_MerchantFrame_UpdateAltCurrency(index, indexOnPage, canAfford, prefix)
	local itemCount = GetMerchantItemCostInfo(index);
	local frameName = (prefix or "EUI_MerchantItem")..indexOnPage.."AltCurrencyFrame";
	local usedCurrencies = 0;
	local width = 0;

	-- update Alt Currency Frame with itemValues
	if ( itemCount > 0 ) then
		for i=1, MAX_ITEM_COST do
			local itemTexture, itemValue, itemLink = GetMerchantItemCostItem(index, i);
			if ( itemTexture ) then
				usedCurrencies = usedCurrencies + 1;
				local button = _G[frameName.."Item"..usedCurrencies];
				button.index = index;
				button.item = i;
				button.itemLink = itemLink;
				AltCurrencyFrame_Update(frameName.."Item"..usedCurrencies, itemTexture, itemValue, canAfford);
				width = width + button:GetWidth();
				if ( usedCurrencies > 1 ) then
					-- button spacing;
					width = width + 4;
				end
				button:Show();
			end
		end
		for i = usedCurrencies + 1, MAX_ITEM_COST do
			_G[frameName.."Item"..i]:Hide();
		end
	else
		for i=1, MAX_ITEM_COST do
			_G[frameName.."Item"..i]:Hide();
		end
	end
	return width;
end

local function SkinMerchantListItem(item)
    if not item or item:IsForbidden() then return end

    item.bg = item.bg or item:CreateTexture(nil, "BACKGROUND", nil, -7)
    item.bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
    item.bg:SetPoint("TOPLEFT", 0, 0)
    item.bg:SetPoint("BOTTOMRIGHT", 0, 0)
    WSkin.AddBorder(item)

    item.SlotTexture:SetSize(item:GetHeight(), item:GetHeight())
    item.SlotTexture:ClearAllPoints()
    item.SlotTexture:SetPoint("LEFT", item, "LEFT", 0, 0)
    item.SlotTexture:SetTexCoord(0, 1, 0, 1)

    item.highlight = item.highlight or item.ItemButton:CreateTexture(nil, "HIGHLIGHT")
    item.highlight:SetColorTexture(1, 1, 1, 0.1)
    item.highlight:SetAllPoints(item.bg)

    -- Buy button spans the whole row in list mode.
    item.ItemButton:SetSize(item:GetWidth(), item:GetHeight())
    item.ItemButton.PushedTexture:SetTexture(nil)
    item.ItemButton.NormalTexture:SetTexture(nil)
    item.ItemButton.HighlightTexture:SetTexture(item.highlight)

    -- Quality ring: STRIPPED, not repositioned onto the icon as it used to be.
    -- It is ROUNDED, and in list mode it was being stretched to the full icon
    -- square, so the round art was at its most obvious here.
    --
    -- The rarity comes back as a SQUARE border reading that same ring. Anchored
    -- to SlotTexture because THAT is the icon in list mode -- the row repurposes
    -- Blizzard's empty-slot art (`row.SlotTexture:SetTexture(texture)` in
    -- UpdateCustomMerchantList) rather than using the item button's own icon.
    --
    -- Registered against the ItemButton, so the color is read from
    -- ItemButton.IconBorder and the repaint hook lands on the frame Blizzard
    -- actually calls SetItemButtonQuality on.
    item.ItemButton.IconBorder:SetAlpha(0)
    WSkin.QualityBorder(item.ItemButton, item.SlotTexture)
    item.ItemButton.IconOverlay:ClearAllPoints()
    item.ItemButton.IconOverlay:SetPoint("CENTER", item.SlotTexture, "CENTER", 0, 0)
    item.ItemButton.IconOverlay:SetSize(item.SlotTexture:GetWidth(), item.SlotTexture:GetHeight())

    -- Quest item overlay, repositioned onto the icon.
    item.ItemButton.IconQuestTexture:SetTexture(TEXTURE_ITEM_QUEST_BANG);
    item.ItemButton.IconQuestTexture:ClearAllPoints()
    item.ItemButton.IconQuestTexture:SetPoint("CENTER", item.SlotTexture, "CENTER", 0, 0)
    item.ItemButton.IconQuestTexture:SetSize(item.SlotTexture:GetWidth(), item.SlotTexture:GetHeight())

    -- Item stack: bottom right of the icon.
    item.ItemButton.Count:ClearAllPoints()
    item.ItemButton.Count:SetPoint("BOTTOMRIGHT", item.SlotTexture, "BOTTOMRIGHT", -2, 2)

    -- Item stock: top left of the icon.
    item.ItemButton.Stock:ClearAllPoints()
    item.ItemButton.Stock:SetPoint("TOPLEFT", item.SlotTexture, "TOPLEFT", 2, -2)

    -- Item name. Its position is set dynamically in UpdateCustomMerchantList so
    -- it never collides with the money or alt-currency frame; overlong text is
    -- truncated with an ellipsis.
    _G[item:GetName().."NameFrame"]:Hide()
    item.Name:ClearAllPoints()
    item.Name:SetPoint("LEFT", item.SlotTexture, "RIGHT", 10, 0)
    item.Name:SetMaxLines(1)
    item.Name:SetJustifyH("LEFT")
end

-- Flag/Hide Owned Items (Merchant card). The code sits after the Expand Vendor UI
-- section; this table stays empty, and the list and the grid skip it, until the
-- setting is first on (SetOwnedActive).
local owned = {}

local function UpdateCustomMerchantList(sf, child)
    local isBuyback = MerchantFrame.selectedTab == 2
    local numItems = isBuyback and GetNumBuybackItems() or GetMerchantNumItems()

    local rowHeight = (EllesmereUIDB and EllesmereUIDB.merchantListRowHeight) or 32
    local rowSpacing = 4
    local playerMoney = GetMoney()
    local MAX_MONEY_DISPLAY_WIDTH = 120

    for i = 1, numItems do
        local row = sf.rows[i]
        if not row then
            row = CreateFrame("Button", "EUI_MerchantItem"..i, child, "MerchantItemTemplate")
            row:SetSize(sf:GetWidth(), rowHeight)
            if i == 1 then
                row:SetPoint("TOPLEFT", child, "TOPLEFT", 0, 0)
            else
                row:SetPoint("TOPLEFT", sf.rows[i-1], "BOTTOMLEFT", 0, -rowSpacing)
            end

            SkinMerchantListItem(row)
            sf.rows[i] = row
        end

        local name, texture, price, quantity, numAvailable, isPurchasable, isUsable, extendedCost, isBound, isQuestStartItem

        if isBuyback then
            name, texture, price, quantity, numAvailable, isUsable, isBound = GetBuybackItemInfo(i)
            isPurchasable = true -- buyback items are always purchasable
        else
            local info = C_MerchantFrame.GetItemInfo(i)
            if info then
                if info.currencyID then
                    name, texture, numAvailable = CurrencyContainerUtil.GetCurrencyContainerInfo(info.currencyID, info.numAvailable, info.name, info.texture, nil);
                else
                    name, texture, numAvailable = info.name, info.texture, info.numAvailable
                end

                price, quantity, isPurchasable, isUsable, extendedCost, isQuestStartItem =
                    info.price, info.stackCount, info.isPurchasable, info.isUsable, info.hasExtendedCost, info.isQuestStartItem
            end
        end

        if name then
            local itemLink = isBuyback and GetBuybackItemLink(i) or GetMerchantItemLink(i)

            row.Name:SetText(name)
            row.SlotTexture:SetTexture(texture)

            row.ItemButton:SetID(i)
            row.ItemButton.link = itemLink
            row.ItemButton.name = name
            row.ItemButton.texture = texture
            row.ItemButton.price = ((extendedCost and (price > 0)) or not extendedCost) and price or nil
            row.ItemButton.extendedCost = (extendedCost and type(price) == "number") or nil
            row.ItemButton.hasItem = true
            row.ItemButton.showNonrefundablePrompt = not C_MerchantFrame.IsMerchantItemRefundable(i)

            -- Text color and reagent quality overlay.
            MerchantFrameItem_UpdateQuality(row, row.ItemButton.link, isBound)

            SetItemButtonCount(row.ItemButton, quantity)
            SetItemButtonStock(row.ItemButton, numAvailable)

            if isQuestStartItem then
				row.ItemButton.IconQuestTexture:Show();
			else
				row.ItemButton.IconQuestTexture:Hide();
			end

            -- Money & currency cost.
            local moneyFrame = _G["EUI_MerchantItem"..i.."MoneyFrame"]
            local altCurrencyFrame = _G["EUI_MerchantItem"..i.."AltCurrencyFrame"]
            local canAfford = true
            if isBuyback then
                canAfford = playerMoney >= price
            else
                canAfford = CanAffordMerchantItem(i)
            end

            -- Reset dynamic anchors to prevent layout conflicts.
            row.Name:ClearAllPoints()
            row.Name:SetPoint("LEFT", row.SlotTexture, "RIGHT", 10, 0)
            moneyFrame:ClearAllPoints()
            altCurrencyFrame:ClearAllPoints()

            if (extendedCost and (price <= 0)) then
                -- Case 1: Alt currency only
                local altCurrencyWidth = EUI_MerchantFrame_UpdateAltCurrency(i, i, canAfford)
                altCurrencyFrame:SetWidth(altCurrencyWidth)

                altCurrencyFrame:SetPoint("RIGHT", row, "RIGHT", -10, 0)

                altCurrencyFrame:Show()
                moneyFrame:Hide()

                row.Name:SetPoint("RIGHT", altCurrencyFrame, "LEFT", -10, 0)
            elseif (extendedCost and (price > 0)) then
                -- Case 2: Both Money and Alt currency
                local altCurrencyWidth = EUI_MerchantFrame_UpdateAltCurrency(i, i, canAfford)
                altCurrencyFrame:SetWidth(altCurrencyWidth)

                MoneyFrame_SetMaxDisplayWidth(moneyFrame, MAX_MONEY_DISPLAY_WIDTH - altCurrencyWidth)
                MoneyFrame_Update(moneyFrame:GetName(), price)

                local color = (canAfford == false) and "gray" or nil
                SetMoneyFrameColor(moneyFrame:GetName(), color)

                -- altCurrencyWidth can be 0 (no alt-currency cost) even when
                -- hasExtendedCost is true: fall back to the case 3 anchors.
                if altCurrencyWidth > 0 then
                    -- Both exist: anchor money to alt currency.
                    altCurrencyFrame:SetPoint("RIGHT", row, "RIGHT", -10, 0)
                    moneyFrame:SetPoint("RIGHT", altCurrencyFrame, "LEFT", -5, 0)
                    row.Name:SetPoint("RIGHT", altCurrencyFrame, "LEFT", -10, 0)
                    altCurrencyFrame:Show()
                else
                    -- Money only: fall back to case 3.
                    moneyFrame:SetPoint("RIGHT", row, "RIGHT", 3, 0)
                    row.Name:SetPoint("RIGHT", moneyFrame, "LEFT", -10, 0)
                    altCurrencyFrame:Hide()
                end
                moneyFrame:Show()
            else
                -- Case 3: Money only
                MoneyFrame_SetMaxDisplayWidth(moneyFrame, MAX_MONEY_DISPLAY_WIDTH)
                MoneyFrame_Update(moneyFrame:GetName(), price)

                local color = (canAfford == false) and "gray" or nil
                SetMoneyFrameColor(moneyFrame:GetName(), color)

                moneyFrame:SetPoint("RIGHT", row, "RIGHT", 3, 0)

                altCurrencyFrame:Hide()
                moneyFrame:Show()

                row.Name:SetPoint("RIGHT", moneyFrame, "LEFT", -10, 0)
            end

            local merchantItemID = GetMerchantItemID(i)
            local isHeirloom = merchantItemID and C_Heirloom.IsItemHeirloom(merchantItemID)
			local isKnownHeirloom = isHeirloom and C_Heirloom.PlayerHasHeirloom(merchantItemID)

            local redTint = (not isUsable and not isHeirloom) or (not isBuyback and not isPurchasable)

            -- Fade if not usable / affordable / an already-known heirloom.
            row.SlotTexture:SetDesaturated(not isBuyback and isKnownHeirloom)
            if not isBuyback and (numAvailable == 0 or isKnownHeirloom) then
                if redTint then
                    row.SlotTexture:SetVertexColor(0.5, 0, 0)
                else
                    row.SlotTexture:SetVertexColor(0.5, 0.5, 0.5)
                end
            elseif redTint then
                row.SlotTexture:SetVertexColor(1, 0, 0)
            else
                row.SlotTexture:SetVertexColor(1, 1, 1)
            end
            if owned.markRow then owned.markRow(row, i, isBuyback) end

            row:Show()
        else
            row:Hide()
        end
    end

    for i = numItems + 1, #sf.rows do
        sf.rows[i]:Hide()
    end
end

-- Options toggle entry point: re-sync row height.
EllesmereUI._Merchant_RefreshRowHeight = function()
    local f = _G.MerchantFrame
    if not f then return end
    if not EllesmereUIDB.merchantShowAsList or not (f.wSkinScrollFrame and f.wSkinScrollChild) then return end

    local rowHeight = (EllesmereUIDB and EllesmereUIDB.merchantListRowHeight) or 32
    -- Rows are cached, so resize each existing one; rows created later pick up
    -- the new height by default.
    for _, row in ipairs(f.wSkinScrollFrame.rows or {}) do
        row:SetHeight(rowHeight)
        SkinMerchantListItem(row)
    end

    -- Force a full update when changed while the merchant frame is open.
    if f:IsVisible() then
        UpdateCustomMerchantList(f.wSkinScrollFrame, f.wSkinScrollChild)
    end
end

-- Vendor item tile: parchment gone, flat card, white name, squared icon.
local function SkinMerchantTile(item)
    if not item or item:IsForbidden() then return end
    local d = GetFFD(item)
    if not d.bg then
        WSkin.FadeRegions(item)
        local bg = item:CreateTexture(nil, "BACKGROUND", nil, -7)
        bg:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        bg:SetPoint("TOPLEFT", 2, -1)
        bg:SetPoint("BOTTOMRIGHT", -2, 1)
        d.bg = bg
        WSkin.AddBorder(item)
    end
    local name = item.GetName and item:GetName()
    -- Blizzard repaints the slot/tile art per page flip; re-fade each pass,
    -- sparing our card fill.
    local keep = { [d.bg] = true }
    WSkin.FadeRegions(item, keep)
    local nameFS = item.Name or (name and _G[name .. "Name"])
    if nameFS then
        -- Font AND color untouched, so Blizzard's item-quality coloring holds;
        -- only the 2-line wrap/truncate is applied.
        if nameFS.SetWordWrap then nameFS:SetWordWrap(true) end
        if nameFS.SetMaxLines then nameFS:SetMaxLines(2) end
    end
    local btn = item.ItemButton or (name and _G[name .. "ItemButton"])
    -- true: vendor tiles take the square RARITY border. Mail, which shares this
    -- helper, keeps Blizzard's rounded ring.
    if btn then SkinMailItemButton(btn, true) end

    -- CENTRE THE ICON IN THE ROW.
    --
    -- MerchantItemTemplate is 44px tall and anchors its ItemButton TOPLEFT to
    -- the row, but the button is only ~37px -- so the icon sits against the top
    -- with a 7px gap underneath, about 3-4px high of centre. Blizzard's slot
    -- and name-plate art hid that; the flat card this pack draws spans the full
    -- row, so the icon reads as top-heavy against it.
    --
    -- Re-anchored to LEFT rather than nudged by a fixed offset, so it stays
    -- centred whatever height the row ends up. Done ONCE -- the tiles are
    -- re-skinned on every page flip and re-anchoring per pass is pointless.
    if btn and btn.SetPoint then
        local bd = GetFFD(btn)
        if not bd.rowCentred then
            bd.rowCentred = true
            btn:ClearAllPoints()
            btn:SetPoint("LEFT", item, "LEFT", 0, 0)
        end
    end
end

-- Lift a tile's currency display 6px above Blizzard's seat. Blizzard re-anchors
-- these inside MerchantFrame_Update (depends on price vs extended cost), wiping
-- a one-shot capture per update: hook SetPoint and re-apply relative to the
-- LIVE just-set position, SYNCHRONOUSLY (deferring a frame renders at
-- Blizzard's spot then visibly shifts). Single-anchor, so the reentry guard alone prevents a double-lift.
local function LiftMerchantCurrency(fr)
    if not fr or GetFFD(fr).liftHook then return end
    GetFFD(fr).liftHook = true
    local applying = false
    local function Apply()
        if applying then return end
        local np = fr:GetNumPoints() or 0
        local pts, ok = {}, np > 0
        for i = 1, np do
            local p, rel, rp, x, y = fr:GetPoint(i)
            if not p then ok = false break end
            pts[i] = { p, rel, rp, x or 0, (y or 0) + 6 }
        end
        if ok then
            applying = true
            fr:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; fr:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            applying = false
        end
    end
    hooksecurefunc(fr, "SetPoint", Apply)
    Apply()
end

-- Bottom-left icon buttons (repair item/repair all/guild repair/sell junk):
-- pictured icon is the button's FIRST texture region, cropped from a shared
-- sheet, so texcoords MUST be kept (never SquareIcon). Fade the box art
-- around it, seat flat fill + themed border + white hover.
local function SkinMerchantIconButton(btn)
    if not btn or btn:IsForbidden() then return end
    local d = GetFFD(btn)
    local icon = btn.Icon or select(1, btn:GetRegions())
    if not d.bg then
        local fill = btn:CreateTexture(nil, "BACKGROUND", nil, -8)
        fill:SetColorTexture(Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA)
        fill:SetAllPoints(btn)
        d.bg = fill
        local hover = btn:CreateTexture(nil, "HIGHLIGHT")
        hover:SetColorTexture(1, 1, 1, 0.1)
        hover:SetAllPoints(btn)
        d.hover = hover
        if icon and icon.ClearAllPoints then
            icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT", 1, -1)
            icon:SetPoint("BOTTOMRIGHT", -1, 1)
        end
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture",
                         "GetDisabledTexture", "GetHighlightTexture" }) do
        local t = btn[g] and btn[g](btn)
        if t and t ~= icon and t.SetAlpha then t:SetAlpha(0) end
    end
    local regions = { btn:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= icon and r ~= d.bg and r ~= d.hover
           and r.IsObjectType and r:IsObjectType("Texture") then
            r:SetAlpha(0)
        end
    end
end

-------------------------------------------------------------------------------
--  Expand Vendor UI (Merchant card): the sell tab shows a grid of the chosen columns x
--  rows (EllesmereUIDB.merchantCols / merchantRows) instead of Blizzard's
--  2 x 5 page. Nothing is built or hooked until the setting is first on
--  (EnsureExpand). Blizzard's native 10-tile page stays Blizzard's and is only
--  hidden while the grid is up (the buyback tab keeps it); tiles of the same
--  template take its place, filled with MerchantFrame_UpdateMerchantInfo's
--  logic. The frame widens and grows to hold the grid, and the pager steps one
--  grid-full at a time. The native 2 x 5 size is Blizzard's own layout, so it
--  needs none of this. Excluded with Show As List.
--  "Hidden" means parked under a hidden holder rather than Hide(): the native
--  tiles stay shown to Blizzard and to addons that decorate them (price
--  displays, overlays), so they are already current when the grid comes down.
-------------------------------------------------------------------------------
local EX_COL_STEP, EX_ROW_STEP = 165, 52   -- tile 153 wide + Blizzard's 12 gap; 44 tall + 8 gap
local EX_LEFT, EX_TOP = 11, -72            -- MerchantItem1's seat after the skin's 3px shift
local EX_NATIVE_PER_PAGE = 10
local EX_NATIVE_COLS, EX_NATIVE_ROWS = 2, 5
local EX_MAX_COLS, EX_MAX_ROWS = 6, 10
local EX_FRAME_PAD = 6                     -- native 336 wide = 2 columns + 6
local EX_PREFIX = "EUI_MerchantPage"
local MAX_MONEY_DISPLAY_WIDTH_EX = 120
-- buttons: the grid tiles' item buttons (a split open on one of them is the grid's).
local ex = { page = 1, tiles = {}, buttons = {}, cols = EX_NATIVE_COLS, perPage = 0 }

local function ExGrid()
    local db = EllesmereUIDB
    local cols = math.floor(tonumber(db and db.merchantCols) or EX_NATIVE_COLS)
    local rows = math.floor(tonumber(db and db.merchantRows) or EX_NATIVE_ROWS)
    return math.min(EX_MAX_COLS, math.max(EX_NATIVE_COLS, cols)),
           math.min(EX_MAX_ROWS, math.max(EX_NATIVE_ROWS, rows))
end

local function ExpandOn()
    local db = EllesmereUIDB
    if not db or db.merchantExpand ~= true or db.merchantShowAsList or db.reskinMerchant == false then
        return false
    end
    local cols, rows = ExGrid()
    return cols ~= EX_NATIVE_COLS or rows ~= EX_NATIVE_ROWS
end

local function ExpandActive()
    local f = _G.MerchantFrame
    return (ExpandOn() and f and (f.selectedTab or 1) == 1) and true or false
end
EllesmereUI._Merchant_ExpandActive = ExpandActive
EllesmereUI._Merchant_ExpandPerPage = function() return ex.perPage end

local function EX_NumPages()
    -- Owned items hidden from the grid (Flag/Hide Owned Items) do not count.
    local list = owned.visible and owned.visible()
    return math.max(1, math.ceil((list and #list or GetMerchantNumItems()) / math.max(1, ex.perPage)))
end

local function EX_Place(t, i)
    local f = _G.MerchantFrame
    local col = (i - 1) % ex.cols
    local row = math.floor((i - 1) / ex.cols)
    t:ClearAllPoints()
    t:SetPoint("TOPLEFT", f, "TOPLEFT", EX_LEFT + col * EX_COL_STEP, EX_TOP - row * EX_ROW_STEP)
end

local function EX_GetTile(i)
    local t = ex.tiles[i]
    if t then return t end
    local f = _G.MerchantFrame
    t = CreateFrame("Frame", EX_PREFIX .. i, f, "MerchantItemTemplate")
    EX_Place(t, i)
    SkinMerchantTile(t)
    LiftMerchantCurrency(_G[EX_PREFIX .. i .. "MoneyFrame"])
    LiftMerchantCurrency(_G[EX_PREFIX .. i .. "AltCurrencyFrame"])
    ex.tiles[i] = t
    ex.buttons[t.ItemButton] = true
    return t
end

local function EX_FillTile(tile, slot, index, numItems)
    local btn = tile.ItemButton
    local money = _G[EX_PREFIX .. slot .. "MoneyFrame"]
    local alt = _G[EX_PREFIX .. slot .. "AltCurrencyFrame"]
    local info = index <= numItems and C_MerchantFrame.GetItemInfo(index) or nil
    if not info then
        btn.price = nil
        btn.hasItem = nil
        btn.name = nil
        btn:SetID(0)
        tile:Hide()
        return
    end

    local itemName, texture, numAvailable = info.name, info.texture, info.numAvailable
    if info.currencyID then
        itemName, texture, numAvailable = CurrencyContainerUtil.GetCurrencyContainerInfo(
            info.currencyID, info.numAvailable, info.name, info.texture, nil)
    end

    local canAfford = CanAffordMerchantItem(index)
    local link = GetMerchantItemLink(index)
    tile.Name:SetText(itemName)
    SetItemButtonCount(btn, info.stackCount)
    SetItemButtonStock(btn, numAvailable)
    SetItemButtonTexture(btn, texture)

    btn.name = itemName
    btn.link = link
    btn.texture = texture
    if info.hasExtendedCost and info.price <= 0 then
        btn.price = nil
        btn.extendedCost = true
        EUI_MerchantFrame_UpdateAltCurrency(index, slot, canAfford, EX_PREFIX)
        alt:ClearAllPoints()
        alt:SetPoint("BOTTOMLEFT", EX_PREFIX .. slot .. "NameFrame", "BOTTOMLEFT", 0, 31)
        money:Hide()
        alt:Show()
    elseif info.hasExtendedCost then
        btn.price = info.price
        btn.extendedCost = true
        local altWidth = EUI_MerchantFrame_UpdateAltCurrency(index, slot, canAfford, EX_PREFIX)
        MoneyFrame_SetMaxDisplayWidth(money, MAX_MONEY_DISPLAY_WIDTH_EX - altWidth)
        MoneyFrame_Update(money:GetName(), info.price)
        SetMoneyFrameColor(money:GetName(), canAfford == false and "gray" or nil)
        alt:ClearAllPoints()
        alt:SetPoint("LEFT", money:GetName(), "RIGHT", -14, 0)
        alt:Show()
        money:Show()
    else
        btn.price = info.price
        btn.extendedCost = nil
        MoneyFrame_SetMaxDisplayWidth(money, MAX_MONEY_DISPLAY_WIDTH_EX)
        MoneyFrame_Update(money:GetName(), info.price)
        SetMoneyFrameColor(money:GetName(), canAfford == false and "gray" or nil)
        alt:Hide()
        money:Show()
    end

    if info.isQuestStartItem then
        btn.IconQuestTexture:SetTexture(TEXTURE_ITEM_QUEST_BANG)
        btn.IconQuestTexture:Show()
    else
        btn.IconQuestTexture:Hide()
    end
    MerchantFrameItem_UpdateQuality(tile, link)

    local itemID = GetMerchantItemID(index)
    local isHeirloom = itemID and C_Heirloom.IsItemHeirloom(itemID)
    local isKnownHeirloom = isHeirloom and C_Heirloom.PlayerHasHeirloom(itemID)
    btn.showNonrefundablePrompt = not C_MerchantFrame.IsMerchantItemRefundable(index)
    btn.hasItem = true
    btn:SetID(index)
    btn:Show()
    tile:Show()

    local tintRed = not info.isPurchasable or (not info.isUsable and not isHeirloom)
    SetItemButtonDesaturated(btn, isKnownHeirloom)
    local r, g, b = 1, 1, 1
    if numAvailable == 0 or isKnownHeirloom then
        if tintRed then r, g, b = 0.5, 0, 0 else r, g, b = 0.5, 0.5, 0.5 end
    elseif tintRed then
        r, g, b = 0.9, 0, 0
    end
    SetItemButtonTextureVertexColor(btn, r, g, b)
    SetItemButtonNormalTextureVertexColor(btn, r, g, b)
    if owned.markTile then owned.markTile(tile, index) end
end

local EX_Update

-- A split open on one of the grid's tiles would act on whatever now holds its
-- index. Close it through the shared helpers; with a key still held in it, report
-- false so the caller skips the change rather than leave the split on the wrong
-- item. A split on anything else (a bag slot) is not the grid's to close.
local function EX_ReleaseSplit()
    local ssf = StackSplitFrame
    local owner = ssf and ssf:IsShown() and ssf.owner
    if owner and ex.buttons[owner] then
        if not EllesmereUI.StackSplitFor(owner) then return false end
        EllesmereUI.TakeStackSplit()
    end
    return true
end

local function EX_Flip(dir)
    local want = math.min(math.max(ex.page + dir, 1), EX_NumPages())
    if want == ex.page then return end
    if not EX_ReleaseSplit() then return end
    ex.page = want
    PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
    EX_Update()
end

local function EX_MakePageButton(f, kind, glyph, point, x)
    local b = CreateFrame("Button", nil, f)
    b:SetSize(32, 32)
    b:SetPoint("CENTER", f, point, x, 96)
    b:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. kind .. "Page-Up")
    b:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. kind .. "Page-Down")
    b:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. kind .. "Page-Disabled")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    b:SetScript("OnClick", function() EX_Flip(kind == "Prev" and -1 or 1) end)
    SkinLabeledPageButton(b, glyph, glyph == ">" and 2 or nil)
    return b
end

local function EX_UpdatePager(f, numPages)
    if not ex.prev then
        ex.prev = EX_MakePageButton(f, "Prev", "<", "BOTTOMLEFT", 25)
        ex.next = EX_MakePageButton(f, "Next", ">", "BOTTOMRIGHT", -26)
        ex.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        ex.text:SetPoint("BOTTOM", f, "BOTTOM", 0, 86)
        WSkin.Font(ex.text)
        WSkin.White(ex.text)
    end
    local show = numPages > 1
    ex.prev:SetShown(show)
    ex.next:SetShown(show)
    ex.text:SetShown(show)
    if not show then return end
    ex.prev:SetEnabled(ex.page > 1)
    ex.next:SetEnabled(ex.page < numPages)
    ex.text:SetFormattedText("%d / %d", ex.page, numPages)
end

-- Move the native page under the hidden holder (park) or back to its parent.
local function EX_ParkNative(park)
    for i = 1, EX_NATIVE_PER_PAGE do
        local n = _G["MerchantItem" .. i]
        if n then
            local parked = n:GetParent() == ex.holder
            if park and not parked then
                ex.nativeParent = ex.nativeParent or n:GetParent()
                n:SetParent(ex.holder)
            elseif not park and parked then
                n:SetParent(ex.nativeParent)
            end
        end
    end
end

local function EX_Deactivate(f)
    if not ex.active then return end
    ex.active = false
    for i = 1, #ex.tiles do ex.tiles[i]:Hide() end
    if ex.prev then ex.prev:Hide(); ex.next:Hide(); ex.text:Hide() end
    if ex.nativeW and f:GetWidth() ~= ex.nativeW then f:SetWidth(ex.nativeW) end
    if ex.nativeH and f:GetHeight() ~= ex.nativeH then f:SetHeight(ex.nativeH) end
    local bb = _G.MerchantBuyBackItem
    if bb and ex.bbPoint then
        local pt = ex.bbPoint
        bb:ClearAllPoints()
        bb:SetPoint(pt[1], pt[2], pt[3], pt[4], pt[5])
    end
    EX_ParkNative(false)
    -- Switched off on the sell tab: show the pager the way Blizzard decides it.
    -- Blizzard keeps its text and enabled state current while it is hidden.
    if not ExpandOn() and f:IsShown() and (f.selectedTab or 1) == 1 and GetMerchantNumItems() > MERCHANT_ITEMS_PER_PAGE then
        for _, c in ipairs(ex.pager) do c:Show() end
    end
    if owned.syncButton then owned.syncButton(f, false) end
    -- Item levels went to the grid's tiles while it was up.
    if EllesmereUIDB.merchantShowItemLevel then EllesmereUI._Merchant_RefreshItemLevels() end
end

EX_Update = function()
    local f = _G.MerchantFrame
    if not f or not ex.hooked then return end
    if not ExpandActive() then EX_Deactivate(f) return end
    if not f:IsShown() then return end

    ex.active = true
    local cols, rows = ExGrid()
    ex.perPage = cols * rows
    if not ex.nativeW then ex.nativeW, ex.nativeH = f:GetWidth(), f:GetHeight() end
    -- The most-recent-buyback slot hangs off MerchantItem10, which is parked and
    -- stays at row 5; keep its native offset from the Sell All Junk button, which
    -- rides the frame's bottom edge, so it follows the grid.
    local bb, junk = _G.MerchantBuyBackItem, _G.MerchantSellAllJunkButton
    if bb and junk then
        if not ex.bbPoint and bb:GetNumPoints() > 0 and bb:GetLeft() and junk:GetLeft() then
            local p, rel, rp, x, y = bb:GetPoint(1)
            ex.bbPoint = { p, rel, rp, x or 0, y or 0 }
            ex.bbDX = bb:GetLeft() - junk:GetLeft()
            ex.bbDY = bb:GetTop() - junk:GetTop()
        end
        if ex.bbDX then
            bb:ClearAllPoints()
            bb:SetPoint("TOPLEFT", junk, "TOPLEFT", ex.bbDX, ex.bbDY)
        end
    end
    local w = cols * EX_COL_STEP + EX_FRAME_PAD
    local h = ex.nativeH + (rows - EX_NATIVE_ROWS) * EX_ROW_STEP
    if f:GetWidth() ~= w then f:SetWidth(w) end
    if f:GetHeight() ~= h then f:SetHeight(h) end
    EX_ParkNative(true)
    for _, c in ipairs(ex.pager) do c:Hide() end

    if ex.cols ~= cols then
        ex.cols = cols
        for i = 1, #ex.tiles do EX_Place(ex.tiles[i], i) end
    end

    local numItems = GetMerchantNumItems()
    local numPages = EX_NumPages()
    if ex.page > numPages then ex.page = numPages end
    local base = (ex.page - 1) * ex.perPage
    -- With the owned items hidden, the slots take the next merchant indexes.
    local list = owned.visible and owned.visible()
    for i = 1, ex.perPage do
        local index = list and (list[base + i] or numItems + 1) or base + i
        EX_FillTile(EX_GetTile(i), i, index, numItems)
    end
    for i = ex.perPage + 1, #ex.tiles do ex.tiles[i]:Hide() end
    EX_UpdatePager(f, numPages)
    if owned.syncButton then owned.syncButton(f, true) end

    -- Item levels read each button's ID, which a flip just changed.
    if EllesmereUIDB.merchantShowItemLevel then EllesmereUI._Merchant_RefreshItemLevels() end
    -- Bulk Buy closes its window once its tile shows another item; it checks on
    -- MerchantFrame_Update, which a flip does not run.
    if EllesmereUI._Merchant_BulkBuyRepaint then EllesmereUI._Merchant_BulkBuyRepaint() end
end
-- GET_ITEM_INFO_RECEIVED comes in a burst while a vendor's items load: one refill
-- per frame. Built here, at load, so no skin callback wraps it.
ex.updateSoon = WSkin.Debounce(EX_Update)

local function EnsureExpand()
    if ex.hooked then return end
    local f = _G.MerchantFrame
    if not f then return end
    ex.hooked = true
    ex.holder = CreateFrame("Frame", nil, f)
    ex.holder:Hide()
    -- Blizzard re-Shows the native pager on every update; keep it down while
    -- the grid is up (hidden, not parked: Blizzard's wheel handler pages
    -- through a shown pager). Show hooks only, no method overwrites.
    local function HideIfActive(self)
        if ExpandActive() then self:Hide() end
    end
    ex.pager = { _G.MerchantPrevPageButton, _G.MerchantNextPageButton, _G.MerchantPageText }
    for _, c in ipairs(ex.pager) do
        hooksecurefunc(c, "Show", HideIfActive)
    end
    hooksecurefunc("MerchantFrame_Update", EX_Update)
    -- Fires when an uncached item resolves; the native pass would only refill its own tiles.
    hooksecurefunc("MerchantFrame_UpdateItemQualityBorders", ex.updateSoon)
    f:HookScript("OnShow", function() ex.page = 1 end)
    f:HookScript("OnMouseWheel", function(_, delta)
        if ExpandActive() then EX_Flip(delta > 0 and -1 or 1) end
    end)
end

-- Options entry point (toggle, columns, rows).
EllesmereUI._Merchant_RefreshExpand = function()
    local f = _G.MerchantFrame
    if not f or not f:IsShown() then return end   -- the next show picks it up
    if ExpandOn() then EnsureExpand() end
    EX_Update()
end

-------------------------------------------------------------------------------
--  Flag/Hide Owned Items (Merchant card, EllesmereUIDB.merchantMarkOwned; needs
--  the Merchant skin). A vendor item the player already has is flagged in every
--  layout: a red wash over its tile or row and a red icon, as Blizzard tints
--  what a character cannot use. Under Expand Vendor UI a header button also
--  hides them (EllesmereUIDB.merchantHideKnown): the grid is ours, so its slots
--  take the next merchant indexes. Blizzard's native 2 x 5 page and the list keep
--  every item, flagged only.
--  Nothing is hooked or registered until the setting is first on; events only
--  while it is on (SetOwnedActive).
--  Everything is drawn with textures of our own kept in weak tables, never as
--  fields on a Blizzard frame, and Blizzard's frames are only read.
-------------------------------------------------------------------------------
local OWNED_WASH_ALPHA = 0.22
local OWNED_TINT_LIT, OWNED_TINT_DIM = 0.9, 0.5   -- red channel, like Blizzard's unusable tint

local ownedWash   = setmetatable({}, { __mode = "k" })   -- tile or row -> our frame holding its red wash
local ownedTinted = setmetatable({}, { __mode = "k" })   -- item button or row -> "btn" / "row"
local knownCache  = {}                                   -- item ID -> true / false
local knownList   = {}                                   -- merchant indexes the grid shows
local ownedCount  = 0                                    -- owned items the vendor sells
local listN, listFilter                                  -- what knownList was built for; nil: build again

local function OwnedOn()
    local db = EllesmereUIDB
    return db and db.merchantMarkOwned == true and db.reskinMerchant ~= false or false
end

-- The game's "Collected (%d/%d)" as a pattern: its numbers (%d or %1$d) match
-- any number, everything else literally.
local PET_COLLECTED = ITEM_PET_KNOWN:gsub("%%%d?%$?d", "\001")
PET_COLLECTED = "^" .. PET_COLLECTED:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0"):gsub("\001", "%%d+") .. "$"

-- An item the player already has: its tooltip reads "Already known" (recipe,
-- mount, toy...) or "Collected (x/y)" (a companion pet already in the journal).
-- Cached by item ID, since the vendor's filter re-maps the indexes with no
-- event. An item whose data has not loaded is not cached: returns false, true.
local function MerchantItemKnown(index)
    local id = GetMerchantItemID(index)
    if not id then return false end
    local known = knownCache[id]
    if known ~= nil then return known end
    if not C_Item.IsItemDataCachedByID(id) then return false, true end
    known = false
    local tip = C_TooltipInfo.GetMerchantItem(index)
    for _, line in ipairs(tip and tip.lines or {}) do
        local text = line.leftText
        if text and (text == ITEM_SPELL_KNOWN or text:find(PET_COLLECTED)) then
            known = true
            break
        end
    end
    knownCache[id] = known
    return known
end

-- One walk over the vendor's items fills both the grid's list and the count,
-- kept until the cache, the item count or the filter changes. A walk that met
-- an item still loading is done again on the next call.
local function BuildOwnedList()
    local n, filter = GetMerchantNumItems(), GetMerchantFilter()
    if n == listN and filter == listFilter then return end
    wipe(knownList)
    ownedCount = 0
    local pending = false
    for i = 1, n do
        local known, loading = MerchantItemKnown(i)
        if known then
            ownedCount = ownedCount + 1
        else
            knownList[#knownList + 1] = i
            if loading then pending = true end
        end
    end
    if pending then
        listN, listFilter = nil, nil
    else
        listN, listFilter = n, filter
    end
end

local function SetOwnedWash(frame, on, inset)
    local holder = ownedWash[frame]
    if on then
        if not holder then
            -- A frame of our own: the skin's per-update pass fades the tile's
            -- own textures. Under the tile's item button.
            holder = CreateFrame("Frame", nil, frame)
            holder:SetFrameLevel(frame:GetFrameLevel())
            holder:SetPoint("TOPLEFT", inset, -inset / 2)
            holder:SetPoint("BOTTOMRIGHT", -inset, inset / 2)
            local wash = holder:CreateTexture(nil, "BACKGROUND")
            wash:SetAllPoints()
            wash:SetColorTexture(0.9, 0.15, 0.15, OWNED_WASH_ALPHA)
            ownedWash[frame] = holder
        end
        holder:Show()
    elseif holder then
        holder:Hide()
    end
end

-- A flagged tile: its icon goes red, kept dark where Blizzard already dimmed it.
local function MarkOwnedTile(tile, index)
    local known = index and owned.on and MerchantItemKnown(index) or false
    SetOwnedWash(tile, known, 2)
    if not known then return end
    local btn = tile.ItemButton
    if not btn then return end
    local icon = btn.icon or btn.Icon
    local dim = icon and (icon:GetVertexColor()) < 0.7
    local r = dim and OWNED_TINT_DIM or OWNED_TINT_LIT
    SetItemButtonTextureVertexColor(btn, r, 0, 0)
    SetItemButtonNormalTextureVertexColor(btn, r, 0, 0)
    ownedTinted[btn] = "btn"
end

-- A flagged list row: the row's icon (the slot texture) goes red.
local function MarkOwnedRow(row, index, isBuyback)
    local known = not isBuyback and owned.on and MerchantItemKnown(index) or false
    SetOwnedWash(row, known, 0)
    if not known then return end
    local slot = row.SlotTexture
    if slot then
        local dim = (slot:GetVertexColor()) < 0.7
        slot:SetVertexColor(dim and OWNED_TINT_DIM or 1, 0, 0)
    end
    ownedTinted[row] = "row"
end

-- Setting turned off: the washes go, and the tints we set go back to plain.
owned.clear = function()
    for _, holder in pairs(ownedWash) do holder:Hide() end
    for frame, kind in pairs(ownedTinted) do
        if kind == "btn" then
            SetItemButtonTextureVertexColor(frame, 1, 1, 1)
            SetItemButtonNormalTextureVertexColor(frame, 1, 1, 1)
        elseif frame.SlotTexture then
            frame.SlotTexture:SetVertexColor(1, 1, 1)
        end
        ownedTinted[frame] = nil
    end
end

-- Blizzard's native 2 x 5 page, after each of its updates (the grid and the list
-- flag their own tiles as they fill them). The hook stays once installed: it
-- returns at once while the setting is off.
local function MarkOwnedNative()
    if not owned.on then return end
    if EllesmereUIDB.merchantShowAsList or ExpandActive() then return end
    local sell = (MerchantFrame.selectedTab or 1) == 1
    for i = 1, EX_NATIVE_PER_PAGE do
        local tile = _G["MerchantItem" .. i]
        local btn = tile and tile.ItemButton
        if btn then
            local index = sell and tile:IsShown() and btn:GetID() or 0
            MarkOwnedTile(tile, index > 0 and index or nil)
        end
    end
end

-- The merchant indexes the grid shows with the owned items hidden; nil when they
-- are not hidden (every item shows).
local function OwnedVisible()
    if not (owned.on and EllesmereUIDB.merchantHideKnown) then return nil end
    BuildOwnedList()
    return knownList
end

-- The header button (Expand Vendor UI only), anchored once: left of Blizzard's
-- filter, or the window's right edge without one.
local function BuildOwnedButton(f)
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetHeight(22)
    WSkin.Button(b)
    WSkin.StateButtonLabel(b)
    local filter = f.FilterDropdown
    if filter then
        b:SetPoint("RIGHT", filter, "LEFT", -8, 0)
    else
        b:SetPoint("TOPRIGHT", f, "TOPRIGHT", -11, -30)
    end
    b:SetScript("OnClick", function()
        if not EX_ReleaseSplit() then return end
        EllesmereUIDB.merchantHideKnown = not EllesmereUIDB.merchantHideKnown
        ex.page = 1
        EX_Update()
    end)
    b:SetScript("OnEnter", function(self)
        EllesmereUI.ShowWidgetTooltip(self, EllesmereUI.L("Click to hide the items you already have, or to show them again."))
    end)
    b:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
    return b
end

local function SyncOwnedButton(f, active)
    local b = owned.button
    if not (active and owned.on) then
        if b then b:Hide() end
        return
    end
    if not b then
        b = BuildOwnedButton(f)
        owned.button = b
    end
    BuildOwnedList()
    local hiding = EllesmereUIDB.merchantHideKnown == true
    b:SetFormattedText(hiding and EllesmereUI.L("Show Owned (%d)") or EllesmereUI.L("Hide Owned (%d)"), ownedCount)
    b:SetWidth(b:GetFontString():GetStringWidth() + 24)
    b:SetEnabled(ownedCount > 0 or hiding)
    b:Show()
end

-- Repaint whatever layout is up (the setting changed, or what is owned did).
local function OwnedRedraw()
    local f = MerchantFrame
    if not f:IsShown() then return end
    if ExpandActive() then
        EX_Update()
    elseif EllesmereUIDB.merchantShowAsList then
        if f.wSkinScrollFrame then UpdateCustomMerchantList(f.wSkinScrollFrame, f.wSkinScrollChild) end
    else
        MarkOwnedNative()
    end
end
-- Built at load, so no skin callback wraps it. The collection events come in
-- bursts: one repaint per frame.
local ownedRedrawSoon = WSkin.Debounce(OwnedRedraw)

-- While the setting is on, MERCHANT_SHOW / MERCHANT_CLOSED; while a vendor is
-- open, also what can make an item owned. The cache lasts one visit.
local OWNED_COLLECTION_EVENTS = { "NEW_MOUNT_ADDED", "NEW_PET_ADDED", "NEW_TOY_ADDED", "NEW_RECIPE_LEARNED" }
local ownedEvents = CreateFrame("Frame")

local function WatchCollection(on)
    for _, e in ipairs(OWNED_COLLECTION_EVENTS) do
        if on then ownedEvents:RegisterEvent(e) else ownedEvents:UnregisterEvent(e) end
    end
end

ownedEvents:SetScript("OnEvent", function(_, event)
    if event == "MERCHANT_SHOW" then
        WatchCollection(true)
        return
    end
    wipe(knownCache)
    listN, listFilter = nil, nil
    if event == "MERCHANT_CLOSED" then
        WatchCollection(false)
        return
    end
    ownedRedrawSoon()
end)

local function SetOwnedActive(on)
    if (owned.on or false) == on then return end
    owned.on = on
    if on then
        if not owned.hooked then
            owned.hooked = true
            owned.markRow, owned.markTile = MarkOwnedRow, MarkOwnedTile
            owned.visible, owned.syncButton = OwnedVisible, SyncOwnedButton
            hooksecurefunc("MerchantFrame_Update", MarkOwnedNative)
        end
        ownedEvents:RegisterEvent("MERCHANT_SHOW")
        ownedEvents:RegisterEvent("MERCHANT_CLOSED")
        WatchCollection(MerchantFrame:IsShown())
    else
        ownedEvents:UnregisterAllEvents()
        wipe(knownCache)
        listN, listFilter = nil, nil
        owned.clear()
    end
end

-- Options entry point (toggle).
EllesmereUI._Merchant_RefreshOwned = function()
    SetOwnedActive(OwnedOn())
    OwnedRedraw()
end

local _merchantHooked = false
local function Skin_Merchant()
    local f = _G.MerchantFrame
    if not f then return end
    WSkin.Shell("merchant", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "MerchantFrame")   -- close + FilterDropdown
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Inset then WSkin.Inset(f.Inset) end
    if _G.MerchantFrameBg then _G.MerchantFrameBg:SetAlpha(0) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.MerchantNameText
    if title then WSkin.Font(title); WSkin.White(title) end

    -- Money / alt-currency wells along the bottom.
    for _, n in ipairs({ "MerchantMoneyInset", "MerchantExtraCurrencyInset" }) do
        if _G[n] then WSkin.Inset(_G[n]) end
    end
    for _, n in ipairs({ "MerchantMoneyBg", "MerchantExtraCurrencyBg" }) do
        local el = _G[n]
        if el then WSkin.FadeRegions(el); WSkin.Register(el, true) end
    end

    if EllesmereUIDB.merchantShowAsList then
        HideNativeMerchantGrid()

        if not f.wSkinScrollFrame then
            local sf, child = CreateMerchantScrollList(f)
            f.wSkinScrollFrame = sf
            f.wSkinScrollChild = child
        end
    else
        -- Item tiles (10 merchant, buyback page reuses up to 12) plus the most-recent-buyback slot on the merchant tab.
        for i = 1, 12 do SkinMerchantTile(_G["MerchantItem" .. i]) end
        SkinMerchantTile(_G.MerchantBuyBackItem)
        -- Main grid 3px lower: MerchantItem1 is the chain root, so one shift
        -- moves the grid (MerchantBuyBackItem anchors separately and stays put). One-shot, all points preserved.
        local it1 = _G.MerchantItem1
        if it1 and not GetFFD(it1).shifted then
            local np = it1:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = it1:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 3 }
            end
            if ok then
                GetFFD(it1).shifted = true
                it1:ClearAllPoints()
                for i = 1, #pts do local t = pts[i]; it1:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            end
        end
        -- Currency text/icons ride 10px higher on every tile (not the buyback slot).
        for i = 1, 12 do
            LiftMerchantCurrency(_G["MerchantItem" .. i .. "MoneyFrame"])
            LiftMerchantCurrency(_G["MerchantItem" .. i .. "AltCurrencyFrame"])
        end

        SkinLabeledPageButton(_G.MerchantPrevPageButton, "<")
        SkinLabeledPageButton(_G.MerchantNextPageButton, ">", 2)
    end

    -- Bottom-left icon buttons (guild repair only exists in a guild).
    for _, n in ipairs({ "MerchantRepairItemButton", "MerchantRepairAllButton",
                         "MerchantGuildBankRepairButton", "MerchantSellAllJunkButton" }) do
        SkinMerchantIconButton(_G[n])
    end
    if _G.MerchantPageText then WSkin.Font(_G.MerchantPageText); WSkin.White(_G.MerchantPageText) end

    -- Tabs
    local mTabs = {}
    for i = 1, 2 do
        local tab = _G["MerchantFrameTab" .. i]
        if tab then WSkin.Tab(tab); mTabs[#mTabs + 1] = tab end
    end
    WSkin.NormalizeTabRow(mTabs)

    if OwnedOn() then SetOwnedActive(true) end
    if ExpandOn() then
        EnsureExpand()
        EX_Update()
    end

    if not _merchantHooked then
        _merchantHooked = true
        -- Blizzard re-textures tiles on every page flip/tab swap/vendor open, so re-run the (idempotent) tile pass on its repaint.
        if type(_G.MerchantFrame_Update) == "function" then
            hooksecurefunc("MerchantFrame_Update", WSkin.Debounce(function()
                if f:IsVisible() then
                    if EllesmereUIDB.merchantShowAsList and f.wSkinScrollFrame then
                        UpdateCustomMerchantList(f.wSkinScrollFrame, f.wSkinScrollChild)
                    else
                        for i = 1, 12 do SkinMerchantTile(_G["MerchantItem" .. i]) end
                        SkinMerchantTile(_G.MerchantBuyBackItem)
                    end
                end
            end))
        end
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Merchant() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "merchant",
    apply = Skin_Merchant,
})
end

-------------------------------------------------------------------------------
--  Merchant item-level overlay (QoL, independent of the Merchant reskin). Item
--  level top-left of each vendor tile for weapons/armor when
--  EllesmereUIDB.merchantShowItemLevel is set. Buttons carry their merchant
--  slot index as their ID (set by MerchantFrame_Update), so the link resolves
--  straight from GetMerchantItemLink.
-------------------------------------------------------------------------------
do
local MERCHANT_ILVL_WEAPON = Enum.ItemClass.Weapon
local MERCHANT_ILVL_ARMOR  = Enum.ItemClass.Armor

local function UpdateMerchantItemLevels()
    local f = _G.MerchantFrame
    if not f then return end
    local show = EllesmereUIDB and EllesmereUIDB.merchantShowItemLevel == true
    local onSellTab = (f.selectedTab or 1) == 1
    local numItems
    local prefix = "MerchantItem"
    if EllesmereUIDB.merchantShowAsList then
        -- GetNumBuybackItems is irrelevant: text only shows on the sell tab.
        numItems = GetMerchantNumItems()
        prefix = "EUI_MerchantItem"
    elseif EllesmereUI._Merchant_ExpandActive() then
        numItems = EllesmereUI._Merchant_ExpandPerPage()
        prefix = "EUI_MerchantPage"
    else
        numItems = 12
    end
    local render = show and onSellTab and f:IsVisible()
    for i = 1, numItems do
        local btn = _G[prefix .. i .. "ItemButton"]
        if btn then
            -- FontString ref lives in the engine FFD, NEVER on Blizzard's button
            -- table. Read without creating, so the disabled path costs one weak-table lookup per slot.
            local fd = FFD[btn]
            local fs = fd and fd.merchantILvl
            if not render then
                if fs then fs:SetText("") end
            else
                if not fs then
                    fs = btn:CreateFontString(nil, "OVERLAY", nil, 7)
                    if EllesmereUIDB.merchantShowAsList then
                        fs:SetPoint("TOPLEFT", _G["EUI_MerchantItem" .. i .. "SlotTexture"], "TOPLEFT", 1, -1)
                    else
                        fs:SetPoint("TOPLEFT", btn, "TOPLEFT", 1, -1)
                    end
                    local path = (EllesmereUI.GetFontPath()) or "Fonts\\FRIZQT__.TTF"
                    local flag = (EllesmereUI.SlugFlag("OUTLINE, SLUG")) or "OUTLINE"
                    fs:SetFont(path, 12, flag)
                    GetFFD(btn).merchantILvl = fs
                end
                fs:SetText("")
                local index = btn:GetID()
                local link = index and index > 0 and GetMerchantItemLink(index)
                if link then
                    local _, _, _, _, _, classID = C_Item.GetItemInfoInstant(link)
                    if classID == MERCHANT_ILVL_WEAPON or classID == MERCHANT_ILVL_ARMOR then
                        local ilvl = C_Item.GetDetailedItemLevelInfo(link)
                        if ilvl and ilvl > 0 then
                            fs:SetText(ilvl)
                            local quality = select(3, C_Item.GetItemInfo(link))
                            local c = EllesmereUI.GetItemLevelColor(link, quality)
                            fs:SetTextColor(c.r or 1, c.g or 1, c.b or 1, 1)
                        end
                    end
                end
            end
        end
    end
end

local _merchantILvlHooked = false
local function EnsureMerchantILvlHook()
    if _merchantILvlHooked then return end
    _merchantILvlHooked = true
    if type(_G.MerchantFrame_Update) == "function" then
        hooksecurefunc("MerchantFrame_Update", WSkin.Debounce(UpdateMerchantItemLevels))
    end
end

-- The MerchantFrame_Update hook renders item levels: installed once the toggle
-- is on and left in place (cheap -- only fires while a merchant is up, and the
-- updater no-ops when off). Must NOT be gated on MerchantFrame:IsVisible():
-- MERCHANT_SHOW fires BEFORE Blizzard shows the frame, so IsVisible() is false
-- and the hook would never install. GET_ITEM_INFO_RECEIVED fires on every
-- item-cache resolve suite-wide, so it is registered ONLY while a merchant is
-- open (explicit flag, not visibility) AND the toggle is on.
local mILvlBoot = CreateFrame("Frame")
local _merchantOpen = false
local function SyncMerchantILvlEvents()
    local on = EllesmereUIDB and EllesmereUIDB.merchantShowItemLevel == true
    if on then EnsureMerchantILvlHook() end
    if on and _merchantOpen then
        mILvlBoot:RegisterEvent("GET_ITEM_INFO_RECEIVED")
    else
        mILvlBoot:UnregisterEvent("GET_ITEM_INFO_RECEIVED")
    end
end

-- Options toggle entry point: re-sync listeners, then render or clear.
EllesmereUI._Merchant_RefreshItemLevels = function()
    SyncMerchantILvlEvents()
    UpdateMerchantItemLevels()
end

mILvlBoot:RegisterEvent("MERCHANT_SHOW")
mILvlBoot:RegisterEvent("MERCHANT_CLOSED")
mILvlBoot:SetScript("OnEvent", function(_, event)
    if event == "MERCHANT_SHOW" then
        _merchantOpen = true
        SyncMerchantILvlEvents()
        UpdateMerchantItemLevels()
    elseif event == "MERCHANT_CLOSED" then
        _merchantOpen = false
        SyncMerchantILvlEvents()
    else -- GET_ITEM_INFO_RECEIVED: an item's data resolved while shopping
        UpdateMerchantItemLevels()
    end
end)
end

-------------------------------------------------------------------------------
--  Class / Profession Trainer (ClassTrainerFrame, Blizzard_TrainerUI). Flat
--  chrome, squared skill-row icons, flat train button. Native availability
--  text color is KEPT (green/red/gray), never forced white, as with rarity.
-------------------------------------------------------------------------------
do
-- One skill row: squared icon, font-only text (Blizzard's availability color
-- kept), box art off, flat selection + hover washes.
local function SkinTrainerRow(row)
    if not row or row:IsForbidden() then return end
    if row.icon then WSkin.SquareIcon(row.icon, row) end
    if row.name then WSkin.Font(row.name) end
    if row.subText then WSkin.Font(row.subText) end
    local nt = row.GetNormalTexture and row:GetNormalTexture()
    if nt and nt.SetAlpha then nt:SetAlpha(0) end
    if row.disabledBG and row.disabledBG.SetAlpha then row.disabledBG:SetAlpha(0) end
    if row.selectedTex and row.selectedTex.SetColorTexture then
        row.selectedTex:SetColorTexture(1, 1, 1, 0.15)
    end
    local hl = row.GetHighlightTexture and row:GetHighlightTexture()
    if hl and hl.SetColorTexture then hl:SetColorTexture(1, 1, 1, 0.1) end
end

local _trainerHooked = false
local function Skin_Trainer()
    local f = _G.ClassTrainerFrame
    if not f then return end
    WSkin.Shell("trainer", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "ClassTrainerFrame")   -- close + FilterDropdown + scrollbar
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.ClassTrainerFrameBg then _G.ClassTrainerFrameBg:SetAlpha(0) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.ClassTrainerFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    -- Insets: top content panel (Bg+NineSlice carry leftover Blizzard chrome) and bottom well.
    local topInset = _G.ClassTrainerFrameInset or f.Inset
    if topInset then WSkin.Inset(topInset) end
    local inset = f.BottomInset or _G.ClassTrainerFrameBottomInset
    if inset then WSkin.Inset(inset) end
    if f.FilterDropdown then LeftAlignFilterLabel(f.FilterDropdown) end
    local tb = _G.ClassTrainerTrainButton
    if tb then
        WSkin.Button(tb)
        local tfs = tb.GetFontString and tb:GetFontString()
        if tfs then WSkin.White(tfs) end
    end
    -- Quality of Life's Train All button beside it (our own frame, made the
    -- first time that option is on; each show of the window picks it up).
    local trainAll = _G.EUI_TrainAllButton
    if trainAll then
        WSkin.Button(trainAll)
        WSkin.StateButtonLabel(trainAll)
    end
    -- Top "current profession" tab: strip Blizzard chrome (bg+NineSlice), keep
    -- the profession icon, wash the guild sidebar card texture over the WHOLE
    -- tab at 50%, border the icon tight. NOT restrip-registered (would fade the icon+card being kept).
    local step = _G.ClassTrainerFrameSkillStepButton
    if step then
        local sdt = GetFFD(step)
        local icon = step.icon or step.Icon
        if step.NineSlice then WSkin.FadeNineSlice(step.NineSlice) end
        local shl = _G.ClassTrainerFrameSkillStepButtonHighlight
        -- Kept out of the fade: the selection and hover textures (the step's
        -- click feedback, recoloured below) and the lock.
        local keep = {}
        if icon then keep[icon] = true end
        if sdt.tabTex then keep[sdt.tabTex] = true end
        if step.selectedTex then keep[step.selectedTex] = true end
        if shl then keep[shl] = true end
        if step.lock then keep[step.lock] = true end
        WSkin.FadeRegions(step, keep)
        -- Full window width, 15px taller (measured one-shot keeping the current top; retried on show until rects exist).
        if not sdt.resized then
            local st, ft, h = step:GetTop(), f:GetTop(), step:GetHeight()
            if st and ft and h then
                sdt.resized = true
                local dy = (st - ft) + 5   -- 5px up
                step:ClearAllPoints()
                step:SetPoint("TOPLEFT", f, "TOPLEFT", 0, dy)
                step:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, dy)
                step:SetHeight(h + 15)
            end
        end
        -- Full-tab background: the guild sidebar card atlas at 50%.
        if not sdt.tabTex then
            local t = step:CreateTexture(nil, "BACKGROUND", nil, -2)
            t:SetAtlas("Ui-Dialog-New-Background")
            t:SetTexCoord(0, 1, 0, 1)
            t:SetVertexColor(1, 1, 1, 1)
            t:SetAlpha(0.5)
            t:SetAllPoints(step)
            sdt.tabTex = t
        end
        -- Profession icon: squared with a 1px border hugging its edges.
        if icon then WSkin.SquareIcon(icon, step) end
        if step.selectedTex and step.selectedTex.SetColorTexture then
            step.selectedTex:SetColorTexture(1, 1, 1, 0.15)
        end
        if shl and shl.SetColorTexture then shl:SetColorTexture(1, 1, 1, 0.1) end
    end
    -- Skill rank status bar (profession trainers only).
    local sbar = _G.ClassTrainerStatusBar
    if sbar then
        WSkin.FadeRegions(sbar)
        WSkin.ApplyBarFill(sbar)
        if sbar.rankText then WSkin.Font(sbar.rankText); WSkin.White(sbar.rankText) end
    end
    local sb = f.ScrollBox
    if sb then
        if sb.ForEachFrame and sb:IsVisible() then sb:ForEachFrame(SkinTrainerRow) end
        if not GetFFD(sb).rowHook then
            GetFFD(sb).rowHook = true
            hooksecurefunc(sb, "Update", WSkin.Debounce(function()
                if sb.ForEachFrame and sb:IsVisible() then sb:ForEachFrame(SkinTrainerRow) end
            end))
        end
    end

    if not _trainerHooked then
        _trainerHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Trainer() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "trainer",
    addons = { Blizzard_TrainerUI = true },
    apply = Skin_Trainer,
})
end

-------------------------------------------------------------------------------
--  Delves Companion (Blizzard_DelvesCompanionConfiguration LoD addon):
--  portrait frame with three option slots (combat role + two trinkets), a
--  "Show Abilities" button, and the paginated ability-list popout. Both frames
--  live in the same addon and share the "delves" winKey.
-------------------------------------------------------------------------------
do
-- One pooled option-slot flyout button: drop the gold border, square the icon.
local function SkinDelvesOptionButton(btn)
    if not btn or btn:IsForbidden() then return end
    if btn.Border and btn.Border.SetAlpha then btn.Border:SetAlpha(0) end
    local icon = btn.Icon or btn.icon
    if icon then WSkin.SquareIcon(icon, btn) end
end

-- One option slot's flyout list (the popout shown when the slot is clicked):
-- flat panel + slim scrollbar + squared icons on its pooled buttons.
local function SkinDelvesOptionSlot(slot)
    if not slot or slot:IsForbidden() then return end
    local list = slot.OptionsList
    if not list then return end
    WSkin.Panel(list)
    WSkin.ScrollBarsIn(list)
    local sb = list.ScrollBox
    if sb then
        if sb.ForEachFrame and sb:IsVisible() then pcall(sb.ForEachFrame, sb, SkinDelvesOptionButton) end
        if sb.Update and not GetFFD(sb).rowHook then
            GetFFD(sb).rowHook = true
            hooksecurefunc(sb, "Update", function(box)
                if box.ForEachFrame then pcall(box.ForEachFrame, box, SkinDelvesOptionButton) end
            end)
        end
    end
end

local _delvesAbilityHooked = false
local function Skin_DelvesCompanion()
    local f = _G.DelvesCompanionConfigurationFrame
    if f then
        WSkin.Shell("delves", f)
        WSkin.RemovePortrait(f)
        WSkin.CommonChrome(f)
        if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
        if f.Bg and f.Bg.SetAlpha then f.Bg:SetAlpha(0) end
        -- Leftover Blizzard border sub-frame: our atlas border replaces it, alpha 0 inherits to all its edge children.
        if f.Border and f.Border.SetAlpha then f.Border:SetAlpha(0) end
        -- Brann's portrait and XP ring poke above the window top and natively
        -- draw OVER the dialog border. Our atlas border rides a child frame at
        -- +6, so lift them past it or the border line cuts across the art (level badge already sits at 100).
        local overBorder = f:GetFrameLevel() + 7
        if f.CompanionPortraitFrame and f.CompanionPortraitFrame.SetFrameLevel then
            f.CompanionPortraitFrame:SetFrameLevel(overBorder)
        end
        if f.CompanionExperienceRingFrame and f.CompanionExperienceRingFrame.SetFrameLevel then
            f.CompanionExperienceRingFrame:SetFrameLevel(overBorder + 1)
        end
        -- Close button natively anchors to the corner of the now-alpha-0
        -- DialogBorder sub-frame, leaving the X flush with the window edge.
        -- Seat it like every other shell: centered on the 25px top bar with right spacing.
        local cb = f.CloseButton
        if cb and not GetFFD(cb).reseated then
            GetFFD(cb).reseated = true
            cb:ClearAllPoints()
            cb:SetPoint("CENTER", f, "TOPRIGHT", -14, -12)
        end
        local title = (f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
        if title then WSkin.Font(title); WSkin.White(title) end
        local ab = f.CompanionConfigShowAbilitiesButton
        if ab then
            WSkin.Button(ab)
            local lab = ab.GetFontString and ab:GetFontString()
            if lab then WSkin.White(lab) end
        end
        SkinDelvesOptionSlot(f.CompanionCombatRoleSlot)
        SkinDelvesOptionSlot(f.CompanionUtilityTrinketSlot)
        SkinDelvesOptionSlot(f.CompanionCombatTrinketSlot)
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_DelvesCompanion() end
        end))
    end

    -- Companion ability list popout (same addon), opened from Show Abilities.
    local al = _G.DelvesCompanionAbilityListFrame
    if al then
        WSkin.Shell("delves", al)
        WSkin.RemovePortrait(al)
        WSkin.CommonChrome(al)
        if al.NineSlice then WSkin.FadeNineSlice(al.NineSlice) end
        if al.Border and al.Border.SetAlpha then al.Border:SetAlpha(0) end
        local atitle = (al.TitleContainer and al.TitleContainer.TitleText) or al.TitleText
        if atitle then WSkin.Font(atitle); WSkin.White(atitle) end
        if al.DelvesCompanionRoleDropdown then WSkin.Dropdown(al.DelvesCompanionRoleDropdown) end
        local pc = al.DelvesCompanionAbilityListPagingControls
        if pc then
            if pc.PrevPageButton then WSkin.PageButton(pc.PrevPageButton, "<", 13) end
            if pc.NextPageButton then WSkin.PageButton(pc.NextPageButton, ">", 13) end
        end
        -- Ability tiles repaint on page flips: square their icons each rebuild.
        if not _delvesAbilityHooked and al.UpdatePaginatedButtonDisplay then
            _delvesAbilityHooked = true
            hooksecurefunc(al, "UpdatePaginatedButtonDisplay", function(self)
                if not self.buttons then return end
                for _, b in next, self.buttons do
                    local icon = b.Icon or b.icon
                    if icon then WSkin.SquareIcon(icon, b) end
                end
            end)
        end
        WSkin.HookShow(al, WSkin.Debounce(function()
            if al:IsVisible() then Skin_DelvesCompanion() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "delves",
    addons = { Blizzard_DelvesCompanionConfiguration = true },
    apply = Skin_DelvesCompanion,
})
end

-------------------------------------------------------------------------------
--  Gossip (GossipFrame) -- NPC dialog window. Base UI, always loaded.
-------------------------------------------------------------------------------
do
local function SkinGossipOption(btn)
    if not btn or btn:IsForbidden() then return end
    -- Recolor ONLY: gossip text keeps Blizzard's native font (color-only widget font policy). Never WSkin.Font here.
    if btn.GreetingText then WSkin.White(btn.GreetingText); RecolorDarkText(btn.GreetingText) end
    local fs = btn.GetFontString and btn:GetFontString()
    if fs then WSkin.White(fs); RecolorDarkText(fs) end
    -- The NPC greeting body is a FontString nested inside the element (neither
    -- the named GreetingText field nor the button label), so it slips past both
    -- checks above and renders black on the dark panel. Whiten every FontString
    -- in the row subtree and rewrite embedded link colors; the debounced
    -- ScrollBox.Update hook re-asserts this after each Blizzard recolor.
    WhitenTextIn(btn)
end

local _gossipHooked = false
local function Skin_Gossip()
    local f = _G.GossipFrame
    if not f then return end
    WSkin.Shell("gossip", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "GossipFrame")   -- close + scrollbar
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.GossipFrameBg then _G.GossipFrameBg:SetAlpha(0) end
    -- QuestLog atlas washed over the frame at 50%: sublevel -6 sits above the
    -- shell backdrop (-8/-7) and below the title bar (-5)+content. Stored under the protected "fill" key so a Restrip never fades it.
    if not GetFFD(f).fill then
        local qbg = f:CreateTexture(nil, "BACKGROUND", nil, -6)
        qbg:SetAtlas("QuestLog-main-background", false)
        qbg:SetAllPoints(f)
        qbg:SetAlpha(0.5)
        GetFFD(f).fill = qbg
    end
    -- NPC scene/parchment background is re-textured per NPC, so self-guard the fade against its SetAtlas/SetTexture repaints.
    local bgTex = f.Background
    if bgTex and bgTex.SetAlpha then
        bgTex:SetAlpha(0)
        if not GetFFD(bgTex).atlasHook then
            GetFFD(bgTex).atlasHook = true
            hooksecurefunc(bgTex, "SetAtlas", function() bgTex:SetAlpha(0) end)
            if bgTex.SetTexture then
                hooksecurefunc(bgTex, "SetTexture", function() bgTex:SetAlpha(0) end)
            end
        end
    end
    local inset = f.Inset or _G.GossipFrameInset
    if inset then WSkin.Inset(inset) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.GossipFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    local gp = f.GreetingPanel
    if gp then
        if gp.GoodbyeButton then
            WSkin.Button(gp.GoodbyeButton)
            local gfs = gp.GoodbyeButton.GetFontString and gp.GoodbyeButton:GetFontString()
            if gfs then WSkin.White(gfs) end
        end
        local sb = gp.ScrollBox
        if sb then
            if sb.ForEachFrame and sb:IsVisible() then sb:ForEachFrame(SkinGossipOption) end
            if not GetFFD(sb).rowHook then
                GetFFD(sb).rowHook = true
                hooksecurefunc(sb, "Update", WSkin.Debounce(function()
                    if sb.ForEachFrame and sb:IsVisible() then sb:ForEachFrame(SkinGossipOption) end
                end))
            end
        end
    end
    -- Friendship rep bar (some NPCs): thin black notches, white text.
    local fsb = f.FriendshipStatusBar
    if fsb then
        for i = 1, 4 do
            local notch = fsb["Notch" .. i]
            if notch and notch.SetColorTexture then notch:SetColorTexture(0, 0, 0, 1) end
        end
        local ft = fsb.Text or (fsb.GetFontString and fsb:GetFontString())
        if ft then WSkin.Font(ft); WSkin.White(ft) end
    end

    if not _gossipHooked then
        _gossipHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Gossip() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "gossip",
    apply = Skin_Gossip,
})
end

-------------------------------------------------------------------------------
--  Quest (QuestFrame): the NPC quest dialog (detail/progress/reward/greeting
--  panels). Base UI, always loaded. Matches the gossip window: dark shell,
--  faded parchment, yellow headers+white body, flat action buttons. Helpers
--  are NESTED to keep the file's chunk-local count under the Lua 5.1 cap.
-------------------------------------------------------------------------------
do
local _questHooked = false
local function Skin_Quest()
    local f = _G.QuestFrame
    if not f then return end
    WSkin.Shell("quest", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "QuestFrame")   -- close button + centered title
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Inset then WSkin.Inset(f.Inset) end

    -- Title bar / NPC name.
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.QuestFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    if _G.QuestFrameNpcNameText then
        WSkin.Font(_G.QuestFrameNpcNameText); WSkin.White(_G.QuestFrameNpcNameText)
    end

    -- Panels + scroll frames: fade every parchment texture (FadeRegions alphas
    -- Textures only, never FontStrings, so body text survives), register for restrip, slim the scrollbars.
    for _, pn in ipairs({ "QuestFrameDetailPanel", "QuestFrameProgressPanel",
                          "QuestFrameRewardPanel", "QuestFrameGreetingPanel" }) do
        local p = _G[pn]
        if p then
            WSkin.FadeRegions(p)
            WSkin.Register(p, true)
            if p.NineSlice then WSkin.FadeNineSlice(p.NineSlice) end
        end
    end
    for _, sn in ipairs({ "QuestDetailScrollFrame", "QuestProgressScrollFrame",
                          "QuestRewardScrollFrame", "QuestGreetingScrollFrame",
                          "QuestDetailScrollChildFrame", "QuestRewardScrollChildFrame" }) do
        local s = _G[sn]
        if s then
            WSkin.FadeRegions(s)
            WSkin.Register(s, true)
            if s.ScrollBar then WSkin.ScrollBar(s.ScrollBar) end
        end
    end
    -- Quest scroll viewport up 40px, 30px taller. CalReseat preserves every
    -- anchor point (no width collapse) and is idempotent; height bump needs its
    -- own FFD guard since SetHeight is cumulative and the skin re-runs on every show.
    for _, sn in ipairs({ "QuestDetailScrollFrame", "QuestProgressScrollFrame",
                          "QuestRewardScrollFrame", "QuestGreetingScrollFrame" }) do
        local s = _G[sn]
        if s then
            CalReseat(s, 40)
            local d = GetFFD(s)
            if not d.heightBumped and s.GetHeight and s.SetHeight then
                local h = s:GetHeight()
                if h and h > 0 then
                    d.heightBumped = true
                    s:SetHeight(h + 30)
                end
            end
        end
    end

    -- Action buttons: flat block + state-aware label (color-only, keeps Blizz font).
    for _, bn in ipairs({ "QuestFrameAcceptButton", "QuestFrameDeclineButton",
                          "QuestFrameCompleteButton", "QuestFrameGoodbyeButton",
                          "QuestFrameCompleteQuestButton", "QuestFrameCancelButton",
                          "QuestFrameGreetingGoodbyeButton" }) do
        local b = _G[bn]
        if b then WSkin.Button(b); WSkin.StateButtonLabel(b) end
    end

    -- Shared QuestInfo body/header coloring (detail+reward panels). QuestInfo*
    -- frames are GLOBAL and reparent between the NPC window and the map, so
    -- only recolor when displayed into THIS window; the world-map pack owns the map case (colors match either way).
    local function StyleQuestNPCText()
        for _, n in ipairs({ "QuestInfoTitleHeader", "QuestInfoDescriptionHeader",
                             "QuestInfoObjectivesHeader" }) do
            local fs = _G[n]
            if fs and fs.SetTextColor then fs:SetTextColor(1, 0.82, 0) end
        end
        local rw = _G.QuestInfoRewardsFrame
        for _, n in ipairs({ "QuestInfoDescriptionText", "QuestInfoObjectivesText",
                             "QuestInfoGroupSize", "QuestInfoRewardText", "QuestInfoQuestType" }) do
            local fs = _G[n]
            if fs and fs.SetTextColor then fs:SetTextColor(1, 1, 1) end
        end
        if rw then
            WhitenTextIn(rw)  -- nested spell/effect + SimpleHTML blurbs the fields below miss
            for _, k in ipairs({ "ItemChooseText", "ItemReceiveText",
                                 "PlayerTitleText", "SpellLearnText" }) do
                local fs = rw[k]
                if fs and fs.SetTextColor then fs:SetTextColor(1, 1, 1) end
            end
            if rw.XPFrame and rw.XPFrame.ReceiveText and rw.XPFrame.ReceiveText.SetTextColor then
                rw.XPFrame.ReceiveText:SetTextColor(1, 1, 1)
            end
            -- Reward item tiles: drop the parchment name plate, white the name,
            -- square the icon. SquareIcon carries its own masked-texture guard
            -- (SetTexCoord on a masked texture is a hard Lua error), so a
            -- reward that Blizzard masks is left native rather than skipped
            -- by a test here.
            --
            -- Blizzard's own rings are stripped -- IconBorder is a ROUNDED
            -- quality ring, and leaving it on defeats the square crop
            -- underneath, which is why these tiles kept looking unchanged.
            --
            -- The rarity it carried comes back as a SQUARE border: the tile
            -- gets WSkin.QualityBorder (via SquareIcon's `quality` flag), which
            -- reads the color back off that same stripped ring and repaints
            -- whenever SetItemButtonQuality touches the button. Alpha 0 does
            -- not affect the read -- the ring's SHOWN state and vertex color
            -- are what carry the quality.
            if rw.RewardButtons then
                for _, btn in ipairs(rw.RewardButtons) do
                    WSkin.QuestRewardTile(btn)
                end
            end

            -- REWARD BUTTONS ARE CREATED LAZILY, and populated AFTER creation.
            -- QuestInfo_GetRewardButton builds RewardButtons[index] the first
            -- time an index is needed, so a quest with an extra tile ("This
            -- quest may have additional rewards") produces a button after this
            -- pass has already run.
            --
            -- Hooked on QuestInfo_Display rather than on the accessor. The
            -- accessor hands the button back BEFORE Blizzard fills it in, so
            -- skinning there lands too early: the rarity border stuck (it
            -- repaints itself off SetItemButtonQuality) but the name plate came
            -- straight back when the tile was populated. Display runs the whole
            -- build, so by the time it returns every tile exists AND is filled.
            --
            -- Both frames are walked because which one is populated has moved
            -- between builds. Installed once.
            if not WSkin.__questRewardHook and type(_G.QuestInfo_Display) == "function" then
                WSkin.__questRewardHook = true
                hooksecurefunc("QuestInfo_Display", function()
                    WSkin.QuestRewardTiles(_G.QuestInfoRewardsFrame)
                    WSkin.QuestRewardTiles(_G.MapQuestInfoRewardsFrame)
                end)
            end
            -- The single "you will also receive" tiles (money, XP, honor and
            -- the currency rows) are separate frames from RewardButtons.
            -- Money / XP / honor tiles get the SAME treatment as the item
            -- reward tiles: strip the rings, then square. Squaring alone left
            -- the gold coin wearing its border while the currency tiles beside
            -- it were clean.
            --
            -- The icon is .Icon on most of these; the money tile names it
            -- differently on some builds, so fall back to the frame's own
            -- texture regions and square whichever one is not the plate art.
            for _, k in ipairs({ "MoneyFrame", "XPFrame", "HonorFrame",
                                 "SkillPointFrame", "PlayerTitleFrame" }) do
                local sub = rw[k]
                if sub then
                    for _, ak in ipairs({ "NameFrame", "IconBorder", "IconOverlay",
                                          "IconOverlay2", "IconBorder2", "Border" }) do
                        local t = sub[ak]
                        if t and t.SetAlpha and t.IsObjectType and t:IsObjectType("Texture") then
                            t:SetAlpha(0)
                        end
                    end
                    if sub.Icon then
                        WSkin.SquareIcon(sub.Icon, nil)
                    elseif sub.GetRegions then
                        local regs = { sub:GetRegions() }
                        for ri = 1, #regs do
                            local r = regs[ri]
                            if r and r.IsObjectType and r:IsObjectType("Texture")
                               and r:GetAlpha() > 0 then
                                WSkin.SquareIcon(r, nil)
                            end
                        end
                    end
                end
            end
            if rw.Header and rw.Header.SetTextColor then rw.Header:SetTextColor(1, 0.82, 0) end
        end
        local of = _G.QuestInfoObjectivesFrame
        if of and of.Objectives then
            for _, obj in ipairs(of.Objectives) do
                if obj and obj.SetTextColor then obj:SetTextColor(1, 1, 1) end
            end
        end
    end

    -- One greeting-panel quest title button: keep the icon, white the text.
    -- Available quests bake a |cff000000 code into the string that SetTextColor cannot override, so rewrite it to white in place.
    local function SkinQuestGreetingButton(btn)
        if not btn or btn:IsForbidden() then return end
        if btn.Icon and btn.Icon.SetDrawLayer then btn.Icon:SetDrawLayer("ARTWORK") end
        local fs = btn.GetFontString and btn:GetFontString()
        if fs then
            WSkin.Font(fs); WSkin.White(fs)
            local txt = fs.GetText and fs:GetText()
            if txt and txt:find("|cff000000", 1, true) then
                fs:SetText((txt:gsub("|cff000000", "|cffffffff")))
            end
        end
    end
    -- Greeting text + section labels + quest title buttons. Blizzard re-applies the
    -- dark parchment material color in the greeting panel's OnShow AFTER our skin, so
    -- re-white on every show (hooked below), not once here. The greeting paragraph's
    -- global is the bare "GreetingText" (QuestFrame.xml), NOT QuestGreetingText.
    local function StyleQuestGreeting()
        if _G.GreetingText then WSkin.White(_G.GreetingText); RecolorDarkText(_G.GreetingText) end
        for _, n in ipairs({ "CurrentQuestsText", "AvailableQuestsText" }) do
            local fs = _G[n]
            if fs then WSkin.White(fs); RecolorDarkText(fs) end
        end
        local gp = _G.QuestFrameGreetingPanel
        if gp and gp.titleButtonPool then
            for btn in gp.titleButtonPool:EnumerateActive() do
                SkinQuestGreetingButton(btn)
            end
        end
    end

    if _G.GreetingText then WSkin.Font(_G.GreetingText) end
    for _, n in ipairs({ "CurrentQuestsText", "AvailableQuestsText" }) do
        local fs = _G[n]
        if fs then WSkin.Font(fs) end
    end
    if _G.QuestGreetingFrameHorizontalBreak and _G.QuestGreetingFrameHorizontalBreak.SetAlpha then
        _G.QuestGreetingFrameHorizontalBreak:SetAlpha(0)
    end
    StyleQuestGreeting()

    -- Progress panel static text.
    if _G.QuestProgressTitleText then
        WSkin.Font(_G.QuestProgressTitleText); _G.QuestProgressTitleText:SetTextColor(1, 0.82, 0)
    end
    if _G.QuestProgressText then WSkin.Font(_G.QuestProgressText); WSkin.White(_G.QuestProgressText) end

    if not _questHooked then
        _questHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Quest() end
        end))
        -- Greeting rows repopulate on QUEST_GREETING / QUEST_LOG_UPDATE.
        local gp = _G.QuestFrameGreetingPanel
        if gp then gp:HookScript("OnShow", WSkin.Debounce(StyleQuestGreeting)) end
        if type(_G.QuestFrameGreetingPanel_OnShow) == "function" then
            hooksecurefunc("QuestFrameGreetingPanel_OnShow", function()
                StyleQuestGreeting()
                if C_Timer then C_Timer.After(0, StyleQuestGreeting) end
            end)
        end
        -- Body text: Blizzard re-colors on each display, so re-assert in the
        -- hook and again next frame (objectives are colored after this).
        if type(_G.QuestInfo_Display) == "function" then
            hooksecurefunc("QuestInfo_Display", function(_, parentFrame)
                if not parentFrame then return end
                local p, isQuest = parentFrame, false
                for _i = 1, 8 do
                    if p == f then isQuest = true break end
                    p = p.GetParent and p:GetParent()
                    if not p then break end
                end
                if not isQuest then return end
                StyleQuestNPCText()
                if C_Timer then C_Timer.After(0, StyleQuestNPCText) end
            end)
        end
        if type(_G.QuestFrameProgressItems_Update) == "function" then
            hooksecurefunc("QuestFrameProgressItems_Update", function()
                local ri = _G.QuestProgressRequiredItemsText
                if ri and ri.SetTextColor then ri:SetTextColor(1, 0.82, 0) end
                local rm = _G.QuestProgressRequiredMoneyText
                if rm and rm.SetTextColor then rm:SetTextColor(1, 1, 1) end
            end)
        end
    end
    StyleQuestNPCText()
end

WSkin.RegisterWindow({
    key = "quest",
    apply = Skin_Quest,
})
end

-------------------------------------------------------------------------------
--  Inspect Recipe (InspectRecipeFrame, Blizzard_Professions): the small recipe
--  preview from a linked recipe / inspected crafter.
-------------------------------------------------------------------------------
do
local _inspectRecipeHooked = false
local function Skin_InspectRecipe()
    local f = _G.InspectRecipeFrame
    if not f then return end
    WSkin.Shell("inspectrecipe", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "InspectRecipeFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.InspectRecipeFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    -- Recipe background/art stays stock; form chrome only.
    local sf = f.SchematicForm
    if sf and sf.NineSlice then WSkin.FadeNineSlice(sf.NineSlice) end
    if not _inspectRecipeHooked then
        _inspectRecipeHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_InspectRecipe() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "inspectrecipe",
    addons = { Blizzard_Professions = true },
    apply = Skin_InspectRecipe,
})
end

-------------------------------------------------------------------------------
--  Auction House (AuctionHouseFrame, Blizzard_AuctionHouseUI): shell, tabs,
--  search bar, category rail, list panels + column headers, buy/sell inputs +
--  action buttons, token panel, buy dialog, multisell progress. List item
--  icons and item-display buttons stay stock content. Visual-only throughout
--  (alpha/FFD); the commerce paths are NEVER touched.
-------------------------------------------------------------------------------
do
local _ahHooked = false
local function Skin_AuctionHouse()
    local f = _G.AuctionHouseFrame
    if not f then return end
    WSkin.Shell("auctionhouse", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)   -- close button, SearchBox/FilterButton, scrollbars
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    for _, k in ipairs({ "MoneyFrameBorder", "MoneyFrameInset" }) do
        local el = f[k]
        if el then
            WSkin.FadeRegions(el)
            if el.NineSlice then WSkin.FadeNineSlice(el.NineSlice) end
            WSkin.Register(el, true)
        end
    end

    local function WhiteBtn(b)
        if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
    end
    -- State-driven action buttons (bid/buyout/cancel): label mirrors the native
    -- enabled/disabled state instead of reading white while disabled.
    local function StateBtn(b)
        if b then WSkin.Button(b); WSkin.StateButtonLabel(b) end
    end
    -- Money edit box: the classic template's box art is GLOBAL-suffixed
    -- (<name>Left/Middle/Right), which the engine's keyed fade misses, so it sits over our fill and reads unskinned.
    local function MoneyBox(eb)
        if not eb then return end
        WSkin.EditBox(eb)
        local n = eb.GetName and eb:GetName()
        if n then
            for _, suf in ipairs({ "Left", "Middle", "Right" }) do
                local t = _G[n .. suf]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
        end
    end
    local function MoneyInputs(mi)
        if not mi then return end
        MoneyBox(mi.GoldBox)
        MoneyBox(mi.SilverBox)
    end
    -- Click-to-sort column headers, guild-roster treatment: 3-slice art
    -- cleared, flat plate, white label, standard hover. Headers pool/rebuild per list refresh, re-runs from RefreshScrollFrame hook.
    local function Headers(list)
        local hc = list and list.HeaderContainer
        if not hc then return end
        -- Top-anchored views (browse, all-auctions, bids, sell lists) seat their
        -- header row against the STATIC wash top, never a moving target, so a
        -- hidden list refreshing mid-view-swap cannot mis-seat. Item-detail
        -- views keep Blizzard's stock header position below their item display.
        -- Measured, epsilon-gated, converges. Lists may carry a washRef override
        -- (sell tab: 50/50 right-half wash); default is the rail wash.
        local wash2 = GetFFD(list).washRef or GetFFD(f).wash
        if GetFFD(list).seatTop and wash2 and wash2.GetTop then
            local wt0, ht0 = wash2:GetTop(), hc:GetTop()
            if wt0 and ht0 and math.abs((wt0 - 2) - ht0) > 0.5 then
                local dy0 = (wt0 - 2) - ht0
                local np = hc:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = hc:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + dy0 }
                end
                if ok then
                    hc:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; hc:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            end
        end
        -- Per-list sort strip: rides THIS list's header row (2px above),
        -- spanning the wash's width. Parented to the list, so shows/hides with its own view: no shared strip, no cross-view state.
        local sd = GetFFD(list)
        if not sd.strip then
            local sTex = list:CreateTexture(nil, "BACKGROUND", nil, 1)
            sTex:SetColorTexture(0.02, 0.02, 0.02, 0.5)
            sTex:SetHeight(24)
            sd.strip = sTex
            -- Also stored under a PROTECTED key: the strip is a region OF the
            -- list, so the list's restrip registration would fade our own strip
            -- on every global Restrip pass.
            sd.fill = sTex
        end
        -- Re-assert alpha: any fade pass that caught the strip zeroed the region
        -- alpha (the color's own 50% lives in SetColorTexture).
        sd.strip:SetAlpha(1)
        -- Seat-top views ride the header row. Detail views anchor to the LIST
        -- TOP instead: their "top bar" row sits there, while their
        -- HeaderContainer can be vestigial and parked far down the list
        -- (commodities view), dragging the strip down with it.
        local anchorTo, ay = hc, 2
        if not GetFFD(list).seatTop then anchorTo, ay = list, 0 end
        local wl0 = wash2 and wash2.GetLeft and wash2:GetLeft()
        local wr0 = wash2 and wash2.GetRight and wash2:GetRight()
        local al0 = anchorTo:GetLeft()
        if wl0 and wr0 and al0 then
            sd.strip:ClearAllPoints()
            sd.strip:SetPoint("TOPLEFT", anchorTo, "TOPLEFT", wl0 - al0, ay)
            sd.strip:SetPoint("TOPRIGHT", anchorTo, "TOPLEFT", wr0 - al0, ay)
        end
        local children = { hc:GetChildren() }
        for i = 1, #children do
            local col = children[i]
            if col and col.GetObjectType and col:GetObjectType() == "Button" then
                local hd = GetFFD(col)
                if not hd.bg then
                    for _, k2 in ipairs({ "Left", "Middle", "Right" }) do
                        local t2 = col[k2]
                        if t2 and t2.SetTexture then t2:SetTexture("") end
                    end
                    WSkin.FadeRegions(col)
                    -- Invisible plate: the full-width sort strip is the row's
                    -- ONE background (a filled plate would STACK on the 50%
                    -- strip and read darker wherever a column sits). The
                    -- texture stays only as the skinned-guard + keep marker.
                    local bg = SolidTex(col, "BACKGROUND", 0.02, 0.02, 0.02, 0)
                    bg:SetPoint("TOPLEFT", 1, -1)
                    bg:SetPoint("BOTTOMRIGHT", -1, 1)
                    hd.bg = bg
                    local hov = SolidTex(col, "HIGHLIGHT", 1, 1, 1, 0.1)
                    hov:SetAllPoints(col)
                    hd.hover = hov
                    WSkin.Register(col, true)
                end
                local fs = col.GetFontString and col:GetFontString()
                if fs then WSkin.White(fs) end
                -- Hover wash spans the full sort-strip height (the button is
                -- shorter): re-seat against the strip's live rect each pass.
                -- Visual only; the hit rect stays Blizzard's.
                local strip = GetFFD(list).strip
                if hd.hover and strip and strip.GetTop then
                    local st, sbot = strip:GetTop(), strip:GetBottom()
                    local ct, cbot = col:GetTop(), col:GetBottom()
                    if st and sbot and ct and cbot then
                        hd.hover:ClearAllPoints()
                        hd.hover:SetPoint("TOPLEFT", col, "TOPLEFT", 0, st - ct)
                        hd.hover:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT", 0, sbot - cbot)
                    end
                end
            end
        end
    end
    -- Refresh corner: the house refresh glyph; quantity goes white.
    local function SkinRefresh(rf)
        if not rf then return end
        if rf.TotalQuantity then WSkin.White(rf.TotalQuantity) end
        WSkin.RefreshGlyph(rf.RefreshButton)
    end
    -- List panel: framed chrome off, slim scrollbar, headers when present.
    -- seatTop: top-anchored views seat header row at the wash top; item-detail views keep stock header position.
    local function List(list, hasHeader, seatTop)
        if not list then return end
        local ld = GetFFD(list)
        ld.seatTop = seatTop and true or nil
        -- Spare our own strip: it is a region of this list, and an unspared
        -- fade here (every skin pass) blanks the sort bar.
        WSkin.FadeRegions(list, ld.strip and { [ld.strip] = true } or nil)
        if list.NineSlice then WSkin.FadeNineSlice(list.NineSlice) end
        WSkin.Register(list, true)
        WSkin.ScrollBarsIn(list)
        SkinRefresh(list.RefreshFrame)
        if hasHeader then
            Headers(list)
            if list.RefreshScrollFrame and not GetFFD(list).hdrHook then
                GetFFD(list).hdrHook = true
                hooksecurefunc(list, "RefreshScrollFrame", function(l) Headers(l) end)
            end
            -- The strip's anchors need live rects: a pass run while the view was hidden
            -- leaves it unanchored (invisible), so re-run on the list's own show.
            if not GetFFD(list).hdrShowHook then
                GetFFD(list).hdrShowHook = true
                list:HookScript("OnShow", WSkin.Debounce(function() Headers(list) end))
            end
        end
    end
    -- Item display plate (buy/sell/auctions detail): chrome off; the item
    -- button stays stock content.
    local function ItemDisplay(host)
        local idp = host and host.ItemDisplay
        if not idp then return end
        WSkin.FadeRegions(idp)
        if idp.NineSlice then WSkin.FadeNineSlice(idp.NineSlice) end
        WSkin.Register(idp, true)
    end
    -- Sell panel: inputs, duration dropdown, post button, buyout checkbox.
    -- Sell-tab inputs run 5px shorter (scoped here, SellFrame only serves the two sell views).
    local function SlimInput(eb)
        if not eb or GetFFD(eb).slimmed then return end
        GetFFD(eb).slimmed = true
        local h = eb:GetHeight()
        if h and h > 5 then eb:SetHeight(h - 5) end
    end
    local function SellFrame(sf)
        if not sf then return end
        WSkin.FadeRegions(sf)
        WSkin.Register(sf, true)
        ItemDisplay(sf)
        if sf.QuantityInput then
            if sf.QuantityInput.InputBox then
                WSkin.EditBox(sf.QuantityInput.InputBox)
                SlimInput(sf.QuantityInput.InputBox)
            end
            WhiteBtn(sf.QuantityInput.MaxButton)
        end
        for _, pk in ipairs({ "PriceInput", "SecondaryPriceInput" }) do
            local mi = sf[pk] and sf[pk].MoneyInputFrame
            if mi then
                MoneyInputs(mi)
                SlimInput(mi.GoldBox)
                SlimInput(mi.SilverBox)
            end
        end
        if sf.Duration and sf.Duration.Dropdown then WSkin.Dropdown(sf.Duration.Dropdown) end
        WhiteBtn(sf.PostButton)
        local bmc = sf.BuyoutModeCheckButton
        if bmc then
            WSkin.Checkbox(bmc)
            -- Do NOT resize this checkbox: an explicit resize inside Blizzard's
            -- sell-form layout pass makes box + label vanish once an item is
            -- placed. Label rides 6px right (one-shot, points preserved).
            local lab = bmc.Text or (bmc.GetFontString and bmc:GetFontString())
            if lab and not GetFFD(lab).shifted then
                local np = lab:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = lab:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + 6, y or 0 }
                end
                if ok then
                    GetFFD(lab).shifted = true
                    lab:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; lab:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            end
        end
    end

    -- Search bar: search button white; favorites star keeps its art (professions
    -- favorites-button treatment). Filter dropdown matches search button's
    -- height, label pinned left, active-filter clear X is the house glyph lifted above the dropdown's border strips.
    local sb = f.SearchBar
    if sb then
        WhiteBtn(sb.SearchButton)
        -- Favorites button: the star is its Icon key here (the professions
        -- version keeps it in the Normal texture, hence no restore). Favoriting
        -- re-raises the button's state art, so every non-Icon texture gets a
        -- self-guarding fade, re-hidden the moment Blizzard re-textures/shows it.
        local fsb = sb.FavoritesSearchButton
        if fsb then
            WSkin.Button(fsb, { "Icon" })
            local fd2 = GetFFD(fsb)
            if not fd2.favPinned then
                fd2.favPinned = true
                local regions = { fsb:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r ~= fsb.Icon and r ~= fd2.bg and r ~= fd2.hover
                       and r.IsObjectType and r:IsObjectType("Texture") then
                        r:SetAlpha(0)
                        for _, m in ipairs({ "SetAtlas", "SetTexture", "Show" }) do
                            if type(r[m]) == "function" then
                                hooksecurefunc(r, m, function(rr) rr:SetAlpha(0) end)
                            end
                        end
                    end
                end
            end
        end
        local fb = sb.FilterButton
        if fb then
            LeftAlignFilterLabel(fb)
            local sbtn = sb.SearchButton
            local h = sbtn and sbtn.GetHeight and sbtn:GetHeight()
            if h and h > 0 and fb.SetHeight then fb:SetHeight(h) end
            SkinFilterResetX(fb.ClearFiltersButton, fb)
        end
    end

    -- Category rail: framed chrome off; pooled buttons restyle from the setup
    -- hook below (white selection/hover washes, never accent). Rail's TOP edge drops 10px (bottom stays), chained buttons pull 1px into each other.
    local cats = f.CategoriesList
    if cats then
        WSkin.FadeRegions(cats)
        if cats.NineSlice then WSkin.FadeNineSlice(cats.NineSlice) end
        WSkin.Register(cats, true)
        WSkin.ScrollBarsIn(cats)
        if not GetFFD(cats).topShift then
            local np = cats:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = cats:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - (p:find("TOP", 1, true) and 10 or 0) }
            end
            if ok then
                GetFFD(cats).topShift = true
                cats:ClearAllPoints()
                for i = 1, #pts do local t = pts[i]; cats:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            end
        end
    end
    -- Rail row spacing -1: the rail is a ScrollBox, so spacing lives in the
    -- scroll view's PADDING (per-button anchor surgery is a no-op, the view
    -- recomputes positions). Official padding setter, pcall-isolated, then a full update relays out the visible rows. One-shot.
    local function TightenCatButtons()
        if not cats or GetFFD(cats).spacingSet then return end
        local box = cats.ScrollBox
        local view = box and box.GetView and box:GetView()
        if not (view and view.SetPadding) then return end
        GetFFD(cats).spacingSet = true
        pcall(function()
            local t, b, l, r = 0, 0, 0, 0
            local pad = view.GetPadding and view:GetPadding()
            if pad then
                t = (pad.GetTop and pad:GetTop()) or 0
                b = (pad.GetBottom and pad:GetBottom()) or 0
                l = (pad.GetLeft and pad:GetLeft()) or 0
                r = (pad.GetRight and pad:GetRight()) or 0
            end
            view:SetPadding(t, b, l, r, -1)
            if box.FullUpdate then box:FullUpdate(true) end
        end)
    end
    TightenCatButtons()

    -- Zone lines, guild-window treatment: 1-physical-px 0.15 separators at the
    -- top seam (below search row), rail's right edge and bottom seam, plus a 2%
    -- white wash over the results region. All on OUR OWN host frame (direct f
    -- regions are wiped by the shell's region fade on every re-skin pass); the
    -- vertical line and wash anchor to CategoriesList (a stable container) so they track the rail.
    local ad = GetFFD(f)
    if not ad.zoneLines and cats then
        ad.zoneLines = true
        local px = 1
        do
            local PPx = EllesmereUI.PP
            local es = f:GetEffectiveScale()
            if PPx and PPx.perfect and es and es > 0 then px = PPx.perfect / es end
        end
        local host = CreateFrame("Frame", nil, f)
        host:SetAllPoints(f)
        host:SetFrameLevel(f:GetFrameLevel())
        ad.zoneHost = host
        local topSep = host:CreateTexture(nil, "ARTWORK")
        topSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        topSep:SetHeight(px)
        topSep:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -77)
        topSep:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -77)
        local botSep = host:CreateTexture(nil, "ARTWORK")
        botSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        botSep:SetHeight(px)
        botSep:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 30)
        botSep:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30)
        -- RAIL-based wash+divider (buy+auctions tabs: left sidebar column), on
        -- their own sub-host so the SELL tab (no rail, 50/50 split) can swap in
        -- its own set; visibility driven from the displayMode sync below.
        local railHost = CreateFrame("Frame", nil, host)
        railHost:SetAllPoints(host)
        railHost:SetFrameLevel(host:GetFrameLevel())
        ad.railHost = railHost
        -- The wash (and everything anchored to it) rides the rail's top, which
        -- sits 10px lower for the link shift, so lift the zone's top back up and keep the results area flush with the top divider.
        local wash = railHost:CreateTexture(nil, "BACKGROUND")
        wash:SetColorTexture(1, 1, 1, 0.02)
        wash:SetPoint("TOPLEFT", cats, "TOPRIGHT", 2 + px, 5)
        wash:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30 + px)
        -- The sort strip is PER LIST (created in Headers, riding each list's own
        -- header row): a single shared moving strip bleeds across views, since
        -- hidden lists refreshing while another view lowered it would seat against the wrong position.
        ad.zonePx = px         -- one physical pixel, for wash-edge math
        ad.wash = wash         -- header seats + strip widths measure this
        -- Left border of the washed region: flush with the WASH's top AND
        -- bottom (rail frame runs lower than the wash, so its bottom corner is the wrong anchor).
        local sideSep = railHost:CreateTexture(nil, "ARTWORK")
        sideSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        sideSep:SetWidth(px)
        sideSep:SetPoint("TOPLEFT", wash, "TOPLEFT", -px, 0)
        sideSep:SetPoint("BOTTOMLEFT", wash, "BOTTOMLEFT", -px, 0)
        -- SELL-tab zone: 50/50 split, center divider, wash over the right half
        -- only. Hidden until the displayMode sync shows it.
        local sellHost = CreateFrame("Frame", nil, host)
        sellHost:SetAllPoints(host)
        sellHost:SetFrameLevel(host:GetFrameLevel())
        sellHost:Hide()
        ad.sellHost = sellHost
        local sellWash = sellHost:CreateTexture(nil, "BACKGROUND")
        sellWash:SetColorTexture(1, 1, 1, 0.02)
        sellWash:SetPoint("TOPLEFT", f, "TOP", px - 30, -77 - px)
        sellWash:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30 + px)
        ad.sellWash = sellWash
        local sellSep = sellHost:CreateTexture(nil, "ARTWORK")
        sellSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        sellSep:SetWidth(px)
        sellSep:SetPoint("TOPLEFT", sellWash, "TOPLEFT", -px, 0)
        sellSep:SetPoint("BOTTOMLEFT", sellWash, "BOTTOMLEFT", -px, 0)
    end

    -- Bottom clamp: rail+list frames natively run BELOW the bottom divider, so
    -- pull each element's bottom edge up to the seam. Measured, guarded
    -- one-shot per element, re-attempted every pass until rects exist. Elements
    -- with a BOTTOM anchor get it raised; pure height-sized ones shrink instead.
    local function ClampBottom(el)
        if not el or GetFFD(el).botClamped then return end
        local fb, eb2 = f:GetBottom(), el:GetBottom()
        if not (fb and eb2) then return end
        local dy = (fb + 30 + (ad.zonePx or 1)) - eb2
        if dy < 0.5 then GetFFD(el).botClamped = true; return end
        local np = el:GetNumPoints() or 0
        local pts, ok, touched = {}, np > 0, false
        for i = 1, np do
            local p, rel, rp, x, y = el:GetPoint(i)
            if not p then ok = false break end
            local isBottom = p:find("BOTTOM", 1, true) and true or false
            if isBottom then touched = true end
            pts[i] = { p, rel, rp, x or 0, (y or 0) + (isBottom and dy or 0) }
        end
        if ok and touched then
            GetFFD(el).botClamped = true
            el:ClearAllPoints()
            for i = 1, #pts do local t2 = pts[i]; el:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
        elseif ok then
            local h = el:GetHeight()
            if h and h > dy then
                GetFFD(el).botClamped = true
                el:SetHeight(h - dy)
            end
        end
    end
    ClampBottom(cats)

    -- Browse results (Buy tab).
    local br = f.BrowseResultsFrame
    if br then List(br.ItemList, true, true) end
    if br then ClampBottom(br.ItemList) end

    -- Commodities buy view.
    local cbf = f.CommoditiesBuyFrame
    if cbf then
        WhiteBtn(cbf.BackButton)
        -- Back button 3px lower (one-shot, all points preserved).
        if cbf.BackButton and not GetFFD(cbf.BackButton).dropped then
            local bb = cbf.BackButton
            local np = bb:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = bb:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 3 }
            end
            if ok then
                GetFFD(bb).dropped = true
                bb:ClearAllPoints()
                for i = 1, #pts do local t = pts[i]; bb:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            end
        end
        -- Commodities uses the SIDE-BY-SIDE layout (buy panel left, price list
        -- right, NO sort captions), so no header/strip (a wash-wide strip would
        -- cut across the buy panel). Only item-buy (display above, headered list below) gets the strip.
        List(cbf.ItemList, false)
        local bd = cbf.BuyDisplay
        if bd then
            WSkin.FadeRegions(bd)
            WSkin.Register(bd, true)
            ItemDisplay(bd)
            local qib = bd.QuantityInput and bd.QuantityInput.InputBox
            if qib then
                WSkin.EditBox(qib)
                if not GetFFD(qib).slimmed then
                    GetFFD(qib).slimmed = true
                    local h = qib:GetHeight()
                    if h and h > 5 then qib:SetHeight(h - 5) end
                end
            end
            StateBtn(bd.BuyButton)
        end
    end

    -- Single-item buy view.
    local ibf = f.ItemBuyFrame
    if ibf then
        WhiteBtn(ibf.BackButton)
        if ibf.BuyoutFrame then StateBtn(ibf.BuyoutFrame.BuyoutButton) end
        if ibf.BidFrame then
            StateBtn(ibf.BidFrame.BidButton)
            -- Bid button rides 20px right on the bottom bar (one-shot).
            local bb = ibf.BidFrame.BidButton
            if bb and not GetFFD(bb).shiftedX then
                local np = bb:GetNumPoints() or 0
                local pts, ok = {}, np > 0
                for i = 1, np do
                    local p, rel, rp, x, y = bb:GetPoint(i)
                    if not p then ok = false break end
                    pts[i] = { p, rel, rp, (x or 0) + 20, y or 0 }
                end
                if ok then
                    GetFFD(bb).shiftedX = true
                    bb:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; bb:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            end
        end
        ItemDisplay(ibf)
        List(ibf.ItemList, true)
    end
    local function ReFadeMoney()
        for _, n in ipairs({ "AuctionHouseFrameGold", "AuctionHouseFrameSilver",
                             "BidAmountGold", "BidAmountSilver" }) do
            MoneyBox(_G[n])
        end
    end
    ReFadeMoney()
    -- Bid views initialize their money-box art on THEIR show, and sub-view
    -- swaps never re-fire the window's OnShow (the re-skin driver), so re-fade
    -- from the views' own OnShow.
    for _, host2 in ipairs({ ibf, f.AuctionsFrame or _G.AuctionHouseFrameAuctionsFrame }) do
        if host2 and not GetFFD(host2).moneyHook then
            GetFFD(host2).moneyHook = true
            host2:HookScript("OnShow", WSkin.Debounce(ReFadeMoney))
            if host2.BidFrame and host2.BidFrame.HookScript then
                host2.BidFrame:HookScript("OnShow", WSkin.Debounce(ReFadeMoney))
            end
        end
    end

    -- Sell tab.
    SellFrame(f.ItemSellFrame)
    SellFrame(f.CommoditiesSellFrame)
    List(f.ItemSellList, true, true)
    List(f.CommoditiesSellList, true, true)
    -- Sell lists measure against the sell tab's 50/50 wash, not the rail one.
    if f.ItemSellList then GetFFD(f.ItemSellList).washRef = ad.sellWash end
    if f.CommoditiesSellList then GetFFD(f.CommoditiesSellList).washRef = ad.sellWash end
    local tsf = f.WoWTokenSellFrame
    if tsf then
        WSkin.FadeRegions(tsf)
        WSkin.Register(tsf, true)
        ItemDisplay(tsf)
        WhiteBtn(tsf.PostButton)
        if tsf.DummyItemList then
            WSkin.FadeRegions(tsf.DummyItemList)
            WSkin.Register(tsf.DummyItemList, true)
            WSkin.ScrollBarsIn(tsf)
        end
    end

    -- My auctions tab.
    local af = f.AuctionsFrame or _G.AuctionHouseFrameAuctionsFrame
    if af then
        WSkin.FadeRegions(af)
        WSkin.Register(af, true)
        ItemDisplay(af)
        -- Selected-item spot: the guild-sidebar tile sheet behind it.
        local idp = af.ItemDisplay
        if idp then
            local idd = GetFFD(idp)
            if not idd.card then
                local card = idp:CreateTexture(nil, "BACKGROUND", nil, -5)
                card:SetAtlas("Ui-Dialog-New-Background")
                card:SetPoint("TOPLEFT", idp, "TOPLEFT", 0, 0)
                card:SetPoint("BOTTOMRIGHT", idp, "BOTTOMRIGHT", 0, 0)
                card:SetAlpha(0.5)
                idd.card = card
            end
        end
        if af.BuyoutFrame then StateBtn(af.BuyoutFrame.BuyoutButton) end
        if af.BidFrame then StateBtn(af.BidFrame.BidButton) end
        StateBtn(af.CancelAuctionButton)
        List(af.CommoditiesList, true)
        List(af.ItemList, true)
        List(af.SummaryList, false)
        List(af.AllAuctionsList, true, true)
        List(af.BidsList, true, true)
        -- Auctions sidebar (SummaryList): its rows are a SEPARATE ScrollBox
        -- pool that the buy tab's category-rail setup hook never touches, so
        -- they get the same tile treatment here (flat card + border, white
        -- label, washes spanning the full tile).
        local sum = af.SummaryList
        local sumBox = sum and sum.ScrollBox
        if sumBox and not GetFFD(sum).rowHook then
            GetFFD(sum).rowHook = true
            local function SkinSummaryRow(row)
                if not row or (row.IsForbidden and row:IsForbidden()) then return end
                -- Rows run narrower than the column: match the box width,
                -- re-asserted per Update pass once the view lays out.
                local bw = sumBox.GetWidth and sumBox:GetWidth()
                if bw and bw > 1 and row.GetWidth and math.abs((row:GetWidth() or 0) - bw) > 1 then
                    row:SetWidth(bw)
                end
                local rd = GetFFD(row)
                if not rd.bg then
                    local bg = row:CreateTexture(nil, "BACKGROUND", nil, -3)
                    bg:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                    bg:SetPoint("TOPLEFT", 1, -1)
                    bg:SetPoint("BOTTOMRIGHT", -1, 1)
                    rd.bg = bg
                    WSkin.AddBorder(row)
                    -- NEVER restrip-register content rows: a global Restrip
                    -- (any window's show pass, e.g. opening bags during the
                    -- sell flow) would fade the item ICON and the
                    -- hover/selection washes. The Update hook is their upkeep.
                end
                if row.HighlightTexture then
                    row.HighlightTexture:SetColorTexture(1, 1, 1, 0.1)
                    row.HighlightTexture:ClearAllPoints()
                    row.HighlightTexture:SetAllPoints(row)
                end
                if row.SelectedHighlight then
                    row.SelectedHighlight:SetColorTexture(1, 1, 1, 0.15)
                    row.SelectedHighlight:ClearAllPoints()
                    row.SelectedHighlight:SetAllPoints(row)
                end
                if row.Text then WSkin.White(row.Text) end
            end
            hooksecurefunc(sumBox, "Update", WSkin.Debounce(function()
                if sumBox.ForEachFrame and sumBox:IsVisible() then
                    sumBox:ForEachFrame(SkinSummaryRow)
                end
            end))
            -- Initial pass only once the box has a view: ForEachFrame on an
            -- uninitialized ScrollBox errors inside Blizzard's code at addon
            -- load. The Update hook covers everything after init.
            if sumBox.ForEachFrame and sumBox.GetView and sumBox:GetView() then
                pcall(sumBox.ForEachFrame, sumBox, SkinSummaryRow)
            end
        end
        -- Measured seats (rects exist only once the auctions view lays out, so
        -- each is a guarded one-shot retried from af's OnShow): SummaryList
        -- column matches the buy rail's exact edges (sidebar tiles line up
        -- between tabs); main lists span the full washed region and sit lower.
        local function SeatSummary()
            if not sum or GetFFD(sum).seated then return end
            local cl2, cr2 = cats and cats:GetLeft(), cats and cats:GetRight()
            local sl2, sr2 = sum:GetLeft(), sum:GetRight()
            if not (cl2 and cr2 and sl2 and sr2) then return end
            GetFFD(sum).seated = true
            local dxL, dxR = cl2 - sl2, cr2 - sr2
            local np = sum:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = sum:GetPoint(i)
                if not p then ok = false break end
                local dx = p:find("RIGHT", 1, true) and dxR or dxL
                pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
            end
            if ok then
                sum:ClearAllPoints()
                for i = 1, #pts do local t2 = pts[i]; sum:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
            end
        end
        local function SeatMainList(l)
            if not l or GetFFD(l).seated then return end
            local fr2 = f:GetRight()
            local cr2 = cats and cats:GetRight()
            local ll2, lr2 = l:GetLeft(), l:GetRight()
            if not (fr2 and cr2 and ll2 and lr2) then return end
            GetFFD(l).seated = true
            local dxL = (cr2 + 2 + (ad.zonePx or 1)) - ll2
            local dxR = fr2 - lr2
            local np = l:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = l:GetPoint(i)
                if not p then ok = false break end
                local dx = p:find("RIGHT", 1, true) and dxR or dxL
                pts[i] = { p, rel, rp, (x or 0) + dx, (y or 0) - 7 }
            end
            if ok then
                l:ClearAllPoints()
                for i = 1, #pts do local t2 = pts[i]; l:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
            end
        end
        -- Item rows' white backing spans the full washed width: (a) the
        -- ScrollBox reserves a right gutter, so stretch it to the list's right
        -- edge (slim scrollbar overlays fine); (b) row backing/hover textures
        -- are sized to TABLE COLUMNS, not the row, so stretch every row-level
        -- texture to the row (cell content on child frames untouched). Rows pool, so this runs per Update.
        local function WidenRows(l)
            local box2 = l and l.ScrollBox
            if not box2 then return end
            if not GetFFD(box2).widened then
                local lr3, br3 = l:GetRight(), box2:GetRight()
                if lr3 and br3 and lr3 > br3 then
                    GetFFD(box2).widened = true
                    local np = box2:GetNumPoints() or 0
                    local pts, ok = {}, np > 0
                    for i = 1, np do
                        local p, rel, rp, x, y = box2:GetPoint(i)
                        if not p then ok = false break end
                        pts[i] = { p, rel, rp,
                            (x or 0) + (p:find("RIGHT", 1, true) and (lr3 - br3) or 0), y or 0 }
                    end
                    if ok then
                        box2:ClearAllPoints()
                        for i = 1, #pts do local t2 = pts[i]; box2:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
                    end
                end
            end
            if not GetFFD(box2).rowStretch then
                GetFFD(box2).rowStretch = true
                local function StretchRow(row)
                    if not row or (row.IsForbidden and row:IsForbidden()) then return end
                    if GetFFD(row).stretched then return end
                    GetFFD(row).stretched = true
                    local regions = { row:GetRegions() }
                    for i = 1, #regions do
                        local r = regions[i]
                        if r and r.IsObjectType and r:IsObjectType("Texture") then
                            r:ClearAllPoints()
                            r:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
                            r:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)
                        end
                    end
                end
                hooksecurefunc(box2, "Update", WSkin.Debounce(function()
                    if box2.ForEachFrame and box2:IsVisible() then
                        box2:ForEachFrame(StretchRow)
                    end
                end))
                -- Same uninitialized-ScrollBox guard as the summary rows.
                if box2.ForEachFrame and box2.GetView and box2:GetView() then
                    pcall(box2.ForEachFrame, box2, StretchRow)
                end
            end
        end
        local function SeatAuctionsTab()
            SeatSummary()
            SeatMainList(af.AllAuctionsList)
            SeatMainList(af.BidsList)
            WidenRows(af.AllAuctionsList)
            WidenRows(af.BidsList)
            -- These also run past the bottom divider (the seat drops them
            -- further). Deferred a frame: clamping against same-frame stale
            -- rects mis-measures right after the seats moved anchors. Summary
            -- ScrollBox also stretches to the reseated list's edges here since widening the LIST doesn't move its own stock anchors.
            local function clamp()
                ClampBottom(af.AllAuctionsList)
                ClampBottom(af.BidsList)
                ClampBottom(af.SummaryList)
                if sum and sumBox and not GetFFD(sumBox).stretched then
                    local ll2, lr2 = sum:GetLeft(), sum:GetRight()
                    local bl2, br2 = sumBox:GetLeft(), sumBox:GetRight()
                    if ll2 and lr2 and bl2 and br2 then
                        GetFFD(sumBox).stretched = true
                        local np = sumBox:GetNumPoints() or 0
                        local pts, ok = {}, np > 0
                        for i = 1, np do
                            local p, rel, rp, x, y = sumBox:GetPoint(i)
                            if not p then ok = false break end
                            local dx = p:find("RIGHT", 1, true) and (lr2 - br2) or (ll2 - bl2)
                            pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
                        end
                        if ok then
                            sumBox:ClearAllPoints()
                            for i = 1, #pts do
                                local t2 = pts[i]
                                sumBox:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5])
                            end
                        end
                    end
                end
            end
            if C_Timer then C_Timer.After(0, clamp) else clamp() end
        end
        SeatAuctionsTab()
        if not GetFFD(af).seatHook then
            GetFFD(af).seatHook = true
            af:HookScript("OnShow", WSkin.Debounce(SeatAuctionsTab))
        end
        -- Sub-tabs: dark-active (spellbook look), 1px lower. Only the chain
        -- root moves; NormalizeTabRow re-chains the rest off it.
        local afTabs = {}
        for _, n in ipairs({ "AuctionHouseFrameAuctionsFrameAuctionsTab",
                             "AuctionHouseFrameAuctionsFrameBidsTab" }) do
            local t = _G[n]
            if t then WSkin.Tab(t, { darkActive = true }); afTabs[#afTabs + 1] = t end
        end
        local root = afTabs[1]
        if root and not GetFFD(root).dropped then
            local np = root:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = root:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 1 }
            end
            if ok then
                GetFFD(root).dropped = true
                root:ClearAllPoints()
                for i = 1, #pts do local t2 = pts[i]; root:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
            end
        end
        WSkin.NormalizeTabRow(afTabs)
    end

    -- WoW Token results panel.
    local tr = f.WoWTokenResults
    if tr then
        WSkin.FadeRegions(tr)
        WSkin.Register(tr, true)
        WhiteBtn(tr.Buyout)
        WSkin.ScrollBarsIn(tr)
        local td = tr.TokenDisplay
        if td then
            WSkin.FadeRegions(td)
            if td.NineSlice then WSkin.FadeNineSlice(td.NineSlice) end
            WSkin.Register(td, true)
        end
        local tut = tr.GameTimeTutorial
        if tut then
            if tut.NineSlice then WSkin.FadeNineSlice(tut.NineSlice) end
            if tut.Bg and tut.Bg.SetAlpha then tut.Bg:SetAlpha(0) end
            if tut.CloseButton then WSkin.CloseButton(tut.CloseButton) end
            if tut.RightDisplay then
                WhiteBtn(tut.RightDisplay.StoreButton)
                if tut.RightDisplay.Label then WSkin.White(tut.RightDisplay.Label) end
            end
            if tut.LeftDisplay and tut.LeftDisplay.Label then WSkin.White(tut.LeftDisplay.Label) end
        end
    end

    -- Confirm-purchase dialog: its border is a CHILD frame (Bg/edge pieces),
    -- out of reach of the panel's own region fade, so suppress it wholesale.
    local dlg = f.BuyDialog
    if dlg then
        WSkin.Panel(dlg)
        if dlg.Border then
            WSkin.FadeNineSlice(dlg.Border)
            WSkin.Register(dlg.Border, true)
        end
        WhiteBtn(dlg.BuyNowButton)
        WhiteBtn(dlg.CancelButton)
    end

    -- Multisell progress popup: house bar (flat fill on a dark trough).
    local ms = _G.AuctionHouseMultisellProgressFrame
    if ms then
        WSkin.FadeRegions(ms)
        WSkin.Register(ms, true)
        local pb = ms.ProgressBar
        if pb then
            local pd = GetFFD(pb)
            local fill = pb.GetStatusBarTexture and pb:GetStatusBarTexture()
            local regions = { pb:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r ~= fill and r ~= pd.bg and r.IsObjectType
                   and r:IsObjectType("Texture") and r:GetDrawLayer() ~= "HIGHLIGHT" then
                    r:SetAlpha(0)
                end
            end
            if pb.SetStatusBarTexture then
                pb:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
                WSkin.ApplyBarFill(pb)
            end
            if not pd.bg then
                local trough = pb:CreateTexture(nil, "BACKGROUND", nil, -1)
                trough:SetColorTexture(0.12, 0.12, 0.12, 0.85)
                trough:SetAllPoints(pb)
                pd.bg = trough
            end
            if pb.Text then WSkin.White(pb.Text) end
        end
    end

    -- Bottom tabs (Buy / Sell / My Auctions). The AH has NO PanelTemplates /
    -- selectedTabID tab state -- selection IS its displayMode -- so the
    -- engine's checks all miss and no tab reads as active. Sync the FFD
    -- selection override from the display mode instead (tab.displayMode
    -- compared by reference), refreshed on every SetDisplayMode.
    -- Reassert Buy's own anchor before chaining Sell/Auctions off it below --
    -- another addon can leave it repositioned after closing its own AH skin.
    if _G.AuctionHouseFrameBuyTab then
        _G.AuctionHouseFrameBuyTab:ClearAllPoints()
        _G.AuctionHouseFrameBuyTab:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 20, -28)
    end
    local ahTabs = {}
    for _, n in ipairs({ "AuctionHouseFrameBuyTab", "AuctionHouseFrameSellTab",
                         "AuctionHouseFrameAuctionsTab" }) do
        local t = _G[n]
        if t then WSkin.Tab(t); ahTabs[#ahTabs + 1] = t end
    end
    WSkin.NormalizeTabRow(ahTabs)
    local function SyncTabSel()
        if type(f.GetDisplayMode) ~= "function" then return end
        local ok, dm = pcall(f.GetDisplayMode, f)
        if not ok or dm == nil then return end
        local any = false
        for _, t in ipairs(ahTabs) do
            if t.displayMode ~= nil then
                any = true
                GetFFD(t).selOverride = (t.displayMode == dm)
            end
        end
        if any then WSkin.UpdateAllTabs() end
        -- Zone swap: rail wash/divider on buy + auctions, the 50/50 center set
        -- on sell. Placing an item flips displayMode to a sell SUB-mode
        -- (item-sell / commodities-sell) that no longer equals the tab's own
        -- mode, so any visible sell view also counts as "on the sell tab",
        -- keeping its underline lit through the sub-modes.
        local sellTab = _G.AuctionHouseFrameSellTab
        local isSell = sellTab and sellTab.displayMode ~= nil and sellTab.displayMode == dm
        if not isSell then
            for _, k in ipairs({ "ItemSellFrame", "CommoditiesSellFrame", "WoWTokenSellFrame" }) do
                local v = f[k]
                if v and v:IsShown() then isSell = true break end
            end
        end
        if ad.railHost then ad.railHost:SetShown(not isSell) end
        if ad.sellHost then ad.sellHost:SetShown(isSell and true or false) end
        if isSell and sellTab and not GetFFD(sellTab).selOverride then
            GetFFD(sellTab).selOverride = true
            WSkin.UpdateAllTabs()
        end
    end
    if type(f.SetDisplayMode) == "function" and not ad.dmHook then
        ad.dmHook = true
        hooksecurefunc(f, "SetDisplayMode", WSkin.Debounce(SyncTabSel))
    end
    SyncTabSel()

    if not _ahHooked then
        _ahHooked = true
        -- Pooled category rail buttons: the standard sidebar tile (flat card +
        -- border + white label, achievements-rail treatment) with Blizzard's
        -- selected/highlight textures recolored to the house white washes.
        -- Re-runs from Blizzard's setup function since the rows pool.
        if type(_G.AuctionHouseFilterButton_SetUp) == "function" then
            hooksecurefunc("AuctionHouseFilterButton_SetUp", function(button)
                if not button or button:IsForbidden() then return end
                local d = GetFFD(button)
                if not d.bg then
                    local bg = button:CreateTexture(nil, "BACKGROUND", nil, -3)
                    bg:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                    bg:SetPoint("TOPLEFT", 1, -1)
                    bg:SetPoint("BOTTOMRIGHT", -1, 1)
                    d.bg = bg
                    WSkin.AddBorder(button)
                    -- No restrip registration: it would fade the recolored
                    -- selection/hover washes on any global Restrip pass. The
                    -- SetUp hook is these buttons' upkeep.
                end
                if button.NormalTexture then button.NormalTexture:SetAlpha(0) end
                -- Selection/hover washes span the FULL tile; Blizzard sizes
                -- them to the old art, short of the button edges.
                if button.SelectedTexture then
                    button.SelectedTexture:SetColorTexture(1, 1, 1, 0.15)
                    button.SelectedTexture:ClearAllPoints()
                    button.SelectedTexture:SetAllPoints(button)
                end
                if button.HighlightTexture then
                    button.HighlightTexture:SetColorTexture(1, 1, 1, 0.1)
                    button.HighlightTexture:ClearAllPoints()
                    button.HighlightTexture:SetAllPoints(button)
                end
                local fs = button.Text or (button.GetFontString and button:GetFontString())
                if fs then WSkin.White(fs) end
            end)
            hooksecurefunc("AuctionHouseFilterButton_SetUp", WSkin.Debounce(TightenCatButtons))
        end
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_AuctionHouse() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "auctionhouse",
    addons = { Blizzard_AuctionHouseUI = true },
    apply = Skin_AuctionHouse,
})
end

-------------------------------------------------------------------------------
--  Macros (MacroFrame, Blizzard_MacroUI). Shell + tabs + action buttons +
--  text/icon wells; the icon grid and selected-macro icon stay stock content.
-------------------------------------------------------------------------------
do
-- Icon grid slot art at 50%: every texture but the icon, hover and selection.
-- Runs per grid button on each ScrollBox Update (every frame while scrolling),
-- so it walks GetRegions' returns directly instead of building a table.
local function DimSlotArt(btn, ...)
    for i = 1, select("#", ...) do
        local r = (select(i, ...))
        if r and r ~= btn.Icon and r ~= btn.Highlight
           and r ~= btn.SelectedTexture
           and r.IsObjectType and r:IsObjectType("Texture") then
            r:SetAlpha(0.5)
        end
    end
end
local function DimSlot(btn) DimSlotArt(btn, btn:GetRegions()) end

-- Name-and-icon picker popup (IconSelectorPopupFrameTemplate): house panel,
-- themed name input + buttons + type dropdown, white texts, icon grid slot art
-- at 50% (matching the main selector grid). Used by the Macro popup and the
-- Equipment Manager popup: backdrop(p) lays the frame's own backdrop, reskin
-- is the caller's entry point, re-run on every show (HookShow is once per frame).
local function Skin_IconSelectorPopup(p, backdrop, reskin)
    backdrop(p)
    if p.NineSlice then WSkin.FadeNineSlice(p.NineSlice) end
    if p.Bg and p.Bg.SetAlpha then p.Bg:SetAlpha(0) end
    local bb = p.BorderBox
    if bb then
        WSkin.FadeRegions(bb)
        if bb.NineSlice then WSkin.FadeNineSlice(bb.NineSlice) end
        WSkin.Register(bb, true)
        local eb = bb.IconSelectorEditBox
        if eb then
            WSkin.EditBox(eb)
            local n = eb.GetName and eb:GetName()
            if n then
                for _, suf in ipairs({ "Left", "Middle", "Right" }) do
                    local t = _G[n .. suf]
                    if t and t.SetAlpha then t:SetAlpha(0) end
                end
            end
        end
        for _, k in ipairs({ "OkayButton", "CancelButton" }) do
            local b = bb[k]
            if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
        end
        for _, k in ipairs({ "IconTypeDropdown", "IconFilterDropdown" }) do
            if bb[k] then WSkin.Dropdown(bb[k]) end
        end
        for _, k in ipairs({ "EditBoxHeaderText", "IconSelectionText", "SelectedIconText" }) do
            local fs = bb[k]
            if fs then WSkin.Font(fs); WSkin.White(fs) end
        end
    end
    local grid = p.IconSelector
    local gBox = grid and (grid.ScrollBox or (grid.ForEachFrame and grid))
    if grid then
        WSkin.FadeRegions(grid)
        WSkin.Register(grid, true)
        WSkin.ScrollBarsIn(p)
    end
    if gBox then
        local gd = GetFFD(p)
        if not gd.iconDim then
            gd.iconDim = function()
                if gBox.ForEachFrame and gBox:IsVisible() then
                    gBox:ForEachFrame(DimSlot)
                end
            end
            hooksecurefunc(gBox, "Update", WSkin.Debounce(gd.iconDim))
        end
        if gBox.GetView and gBox:GetView() then pcall(gd.iconDim) end
    end
    -- Built only while the frame has no show hook (HookShow keeps the first).
    if not GetFFD(p).showHook then
        WSkin.HookShow(p, WSkin.Debounce(function()
            if p:IsVisible() then reskin() end
        end))
    end
end

-- Macro popup (MacroPopupFrame): uses the shared icon selector popup skin.
local function Skin_MacroPopup()
    local p = _G.MacroPopupFrame
    if not p then return end
    Skin_IconSelectorPopup(p, WSkin.Panel, Skin_MacroPopup)
end

local _macroHooked = false
local function Skin_Macros()
    local f = _G.MacroFrame
    if not f then return end
    WSkin.Shell("macros", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "MacroFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Inset then WSkin.Inset(f.Inset) end
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.MacroFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end

    for _, n in ipairs({ "MacroSaveButton", "MacroCancelButton", "MacroDeleteButton",
                         "MacroNewButton", "MacroExitButton", "MacroEditButton" }) do
        local b = _G[n]
        if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
    end

    local mTabs = {}
    for i = 1, 2 do
        local t = _G["MacroFrameTab" .. i]
        if t then WSkin.Tab(t, { darkActive = true }); mTabs[#mTabs + 1] = t end
    end
    -- Left-align the row: the chain root reseats so its left edge sits 12px
    -- from the window's left (measured one-shot, rect-gated, retried by the
    -- show re-run). Tab2 chains off it via the seam normalization.
    local mt1 = mTabs[1]
    if mt1 and not GetFFD(mt1).leftAligned then
        local fl, tl = f:GetLeft(), mt1:GetLeft()
        if fl and tl then
            local dx = (fl + 12) - tl
            local np = mt1:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = mt1:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, (x or 0) + dx, y or 0 }
            end
            if ok then
                GetFFD(mt1).leftAligned = true
                mt1:ClearAllPoints()
                for i = 1, #pts do local t2 = pts[i]; mt1:SetPoint(t2[1], t2[2], t2[3], t2[4], t2[5]) end
            end
        end
    end
    WSkin.NormalizeTabRow(mTabs)

    -- Icon selector grid panel: framed chrome off, slim scrollbar; the icon
    -- buttons themselves stay stock.
    local sel = f.MacroSelector
    if sel then
        local seld = GetFFD(sel)
        WSkin.FadeRegions(sel)
        if sel.ScrollBox then
            WSkin.FadeRegions(sel.ScrollBox)
            WSkin.Register(sel.ScrollBox, true)
        end
        WSkin.Register(sel, true)
        WSkin.ScrollBarsIn(sel)
        -- Grid buttons are pooled: halve each slot's backdrop art (every
        -- texture that is not the icon, hover or selection), re-asserted per
        -- Update. Absolute alpha, so it never compounds.
        local sBox = sel.ScrollBox
        if sBox then
            if not seld.iconDim then
                seld.iconDim = function()
                    if sBox.ForEachFrame and sBox:IsVisible() then
                        sBox:ForEachFrame(DimSlot)
                    end
                end
                hooksecurefunc(sBox, "Update", WSkin.Debounce(seld.iconDim))
            end
            if sBox.GetView and sBox:GetView() then pcall(seld.iconDim) end
        end
    end

    -- Macro body text well: input-style near-black fill + themed border.
    local tb = _G.MacroFrameTextBackground
    if tb then
        local td = GetFFD(tb)
        WSkin.FadeRegions(tb)
        if tb.NineSlice then WSkin.FadeNineSlice(tb.NineSlice) end
        WSkin.Register(tb, true)
        if not td.bg then
            local fill = tb:CreateTexture(nil, "BACKGROUND", nil, -6)
            fill:SetColorTexture(0.02, 0.02, 0.02, 1)
            fill:SetAllPoints(tb)
            td.bg = fill
            WSkin.AddBorder(tb)
        end
    end
    if _G.MacroFrameSelectedMacroName then
        WSkin.Font(_G.MacroFrameSelectedMacroName)
        WSkin.White(_G.MacroFrameSelectedMacroName)
    end
    if _G.MacroFrameCharLimitText then WSkin.White(_G.MacroFrameCharLimitText) end
    if _G.MacroFrameScrollFrame then WSkin.ScrollBarsIn(_G.MacroFrameScrollFrame) end

    -- Layout nudges (one-shot, points preserved): the selected-macro cluster
    -- between the icon grid and the text well rides up 7px, shifting ONLY
    -- members anchored OUTSIDE the cluster so chained ones cannot double-move;
    -- the text well rises 3px (its scrollframe/input ride inside).
    local function ShiftOnce(el, dx, dy, cluster)
        if not el or GetFFD(el).nudged then return end
        local np = el:GetNumPoints() or 0
        local pts, ok = {}, np > 0
        for i = 1, np do
            local p, rel, rp, x, y = el:GetPoint(i)
            if not p then ok = false break end
            if cluster and rel and cluster[rel] then return end   -- chained inside: rides its root
            pts[i] = { p, rel, rp, (x or 0) + dx, (y or 0) + dy }
        end
        if ok then
            GetFFD(el).nudged = true
            el:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; el:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
        end
    end
    local cluster = {}
    for _, el in ipairs({ _G.MacroFrameSelectedMacroButton, _G.MacroFrameSelectedMacroName,
                          _G.MacroEditButton, _G.MacroFrameEnterMacroText }) do
        if el then cluster[el] = true end
    end
    for el in pairs(cluster) do ShiftOnce(el, 0, 7, cluster) end
    ShiftOnce(tb, 0, 3)
    -- Save +1 / Cancel +5 from stock. Pair-guarded: if Cancel chains off Save
    -- it rides along instead of double-shifting.
    local scPair = {}
    if _G.MacroSaveButton then scPair[_G.MacroSaveButton] = true end
    if _G.MacroCancelButton then scPair[_G.MacroCancelButton] = true end
    ShiftOnce(_G.MacroSaveButton, 0, 1, scPair)
    ShiftOnce(_G.MacroCancelButton, 0, 5, scPair)

    Skin_MacroPopup()

    if not _macroHooked then
        _macroHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Macros() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "macros",
    addons = { Blizzard_MacroUI = true },
    apply = Skin_Macros,
})

-- Equipment Manager popup (GearManagerPopupFrame, built with PaperDollFrame at load)
-- wears the sheet's own shell under the sheet's "charsheet" key, so it follows that
-- card's on/off, style and Modern swap. Blizzard Default keeps the stock popup, like
-- the sheet itself, and so does WoW Forever. The sheet skin raises the popup's icon
-- grid a strata above the shell (PreSkinCharacterSheet).
local GEAR_SHELL_OPTS = { noTopBar = true }
local function GearPopupBackdrop(f) WSkin.Shell("charsheet", f, GEAR_SHELL_OPTS) end
local function Skin_GearPopup()
    if EllesmereUI.IS_FOREVER or ns.CharSheetStock() then return end
    local p = _G.GearManagerPopupFrame
    if not p then return end
    Skin_IconSelectorPopup(p, GearPopupBackdrop, Skin_GearPopup)
end

WSkin.RegisterWindow({
    key = "charsheet",
    apply = Skin_GearPopup,
})
end

-------------------------------------------------------------------------------
--  Blizzard Options (SettingsPanel). Chrome only: shell, close X, search,
--  bottom buttons, top tabs, category rail, list scrollbars. Per-setting
--  controls (checkboxes, sliders, dropdowns in the list) stay stock -- that
--  surface is huge and taint-adjacent. SettingsPanel.CloseButton is the bottom
--  TEXT button, so CommonChrome (which would X-glyph any .CloseButton) is NOT
--  used here; the pieces run individually.
-------------------------------------------------------------------------------
do
local _settingsHooked = false
local function Skin_Settings()
    local f = _G.SettingsPanel
    if not f then return end
    WSkin.Shell("settings", f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Bg and f.Bg.SetAlpha then f.Bg:SetAlpha(0) end
    if f.ClosePanelButton then WSkin.CloseButton(f.ClosePanelButton) end
    if f.SearchBox then WSkin.EditBox(f.SearchBox) end
    for _, k in ipairs({ "ApplyButton", "CloseButton" }) do
        local b = f[k]
        if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
    end
    local sTabs = {}
    for _, k in ipairs({ "GameTab", "AddOnsTab" }) do
        local t = f[k]
        if t then WSkin.Tab(t, { darkActive = true }); sTabs[#sTabs + 1] = t end
    end
    WSkin.NormalizeTabRow(sTabs)
    -- These tabs repaint their state art on hover/click, so pin every Blizzard
    -- texture with self-guarding fades, sparing our pieces by identity.
    -- Selection is not exposed the standard way either, so drive the FFD override from clicks plus isSelected when Blizzard provides it.
    local function SyncSettingsTabs(clicked)
        for _, t in ipairs(sTabs) do
            local td = GetFFD(t)
            if clicked then
                td.selOverride = (t == clicked)
            elseif t.isSelected ~= nil then
                td.selOverride = t.isSelected and true or false
            elseif td.selOverride == nil then
                td.selOverride = (t == sTabs[1])   -- Game tab default
            end
        end
        WSkin.UpdateAllTabs()
    end
    for _, t in ipairs(sTabs) do
        local td = GetFFD(t)
        if not td.pinned then
            td.pinned = true
            local regions = { t:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r ~= td.bg and r ~= td.activeHL and r ~= td.underline
                   and r.IsObjectType and r:IsObjectType("Texture") then
                    r:SetAlpha(0)
                    for _, m in ipairs({ "SetAtlas", "SetTexture", "Show" }) do
                        if type(r[m]) == "function" then
                            hooksecurefunc(r, m, function(rr) rr:SetAlpha(0) end)
                        end
                    end
                end
            end
            t:HookScript("OnClick", function(self) SyncSettingsTabs(self) end)
        end
    end
    -- Every selection path funnels through SetCurrentCategory as a NAMED method
    -- call (reopen reset, tab clicks, rail clicks, OpenToCategory), and the
    -- category's categorySet maps 1:1 onto the tabs. OnTabSelected is NOT
    -- hookable here: the tabsGroup captured it by REFERENCE at OnLoad, so a
    -- method wrapper never runs. Click-only tracking is also insufficient -- a reopen silently resets the panel to Game and strands the override.
    local fd = GetFFD(f)
    if not fd.catSelHooked then
        fd.catSelHooked = true
        hooksecurefunc(f, "SetCurrentCategory", function(_, category)
            local cs = category and category.categorySet
            if cs == nil then return end
            for _, t in ipairs(sTabs) do
                GetFFD(t).selOverride = (t.categorySet == cs)
            end
            WSkin.UpdateAllTabs()
        end)
    end
    SyncSettingsTabs()

    -- Category rail: chrome off; pooled rows lose only their backdrop art
    -- (select/hover washes stay Blizzard's).
    local cl = f.CategoryList
    if cl then
        WSkin.FadeRegions(cl)
        if cl.NineSlice then WSkin.FadeNineSlice(cl.NineSlice) end
        WSkin.Register(cl, true)
        WSkin.ScrollBarsIn(cl)
        local clBox = cl.ScrollBox
        if clBox then
            local cld = GetFFD(cl)
            if not cld.fadeRows then
                -- Box captured in the closure: Debounce invokes with NO args, so taking it as a parameter would leave it nil.
                cld.fadeRows = function()
                    if clBox.ForEachFrame and clBox:IsVisible() then
                        clBox:ForEachFrame(function(child)
                            if child.Background and child.Background.SetAlpha then
                                child.Background:SetAlpha(0)
                            end
                        end)
                    end
                end
                hooksecurefunc(clBox, "Update", WSkin.Debounce(cld.fadeRows))
            end
            -- Run on EVERY skin pass: the box populates at login and the first
            -- open fires no Update, so hook-only fading leaves the first view stock until a tab swap forces a rebuild.
            if clBox.GetView and clBox:GetView() then pcall(cld.fadeRows) end
        end
    end

    -- Settings list container: chrome off, defaults button, slim scrollbar.
    local ct = f.Container
    if ct then
        WSkin.FadeRegions(ct)
        WSkin.Register(ct, true)
        local sl = ct.SettingsList
        if sl then
            WSkin.FadeRegions(sl)
            if sl.NineSlice then WSkin.FadeNineSlice(sl.NineSlice) end
            WSkin.Register(sl, true)
            WSkin.ScrollBarsIn(sl)
            local hdr = sl.Header
            if hdr then
                if hdr.DefaultsButton then
                    WSkin.Button(hdr.DefaultsButton)
                    WSkin.WhiteButtonLabel(hdr.DefaultsButton)
                end
                if hdr.Title then WSkin.Font(hdr.Title); WSkin.White(hdr.Title) end
            end
        end
    end

    if not _settingsHooked then
        _settingsHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_Settings() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "settings",
    apply = Skin_Settings,
})
end

-------------------------------------------------------------------------------
--  AddOn List (AddonList). Shell + buttons + dropdown/search + force-load
--  checkbox; pooled rows get the house checkbox and white title from
--  Blizzard's row initializer.
-------------------------------------------------------------------------------
do
local _addonListHooked = false
local function Skin_AddonList()
    local f = _G.AddonList
    if not f then return end
    WSkin.Shell("addonlist", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "AddonList")   -- close X, SearchBox, Dropdown, scrollbar
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if f.Inset then WSkin.Inset(f.Inset) end
    -- NO text coloring anywhere in this window: Blizzard owns every label color (title, buttons, checkbox labels, row texts).
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.AddonListTitleText
    if title then WSkin.Font(title) end
    for _, k in ipairs({ "EnableAllButton", "DisableAllButton", "OkayButton", "CancelButton" }) do
        local b = f[k]
        if b then WSkin.Button(b) end
    end
    if f.ForceLoad then
        WSkin.Checkbox(f.ForceLoad, { stockCheck = true })
        -- Tight border: the standard checkbox border spans the whole button, ~2px outside the dark box, so re-border a host pinned to the fill instead.
        local fld = GetFFD(f.ForceLoad)
        if not fld.tightBorder and fld.bg then
            fld.tightBorder = true
            local PPb = EllesmereUI.PP
            if PPb and PPb.GetBorders and PPb.HideBorder and PPb.GetBorders(f.ForceLoad) then
                PPb.HideBorder(f.ForceLoad)
            end
            local host = CreateFrame("Frame", nil, f.ForceLoad)
            host:SetAllPoints(fld.bg)
            host:SetFrameLevel(f.ForceLoad:GetFrameLevel())
            WSkin.AddBorder(host)
        end
    end

    -- Bottom bar: shell top bar's exact black 0.5 over the button row, on its own child frame so the shell's region fades never touch it.
    local ald = GetFFD(f)
    if not ald.botBar then
        local bhost = CreateFrame("Frame", nil, f)
        bhost:SetAllPoints(f)
        bhost:SetFrameLevel(f:GetFrameLevel())
        local bar = bhost:CreateTexture(nil, "BACKGROUND", nil, -5)
        bar:SetColorTexture(0, 0, 0, 0.5)
        bar:SetPoint("BOTTOMLEFT")
        bar:SetPoint("BOTTOMRIGHT")
        bar:SetHeight(30)
        ald.botBar = bar
    end
    -- The addon list must stop at the bar's top edge (measured one-shot,
    -- rect-gated, retried by the show re-run).
    local abox = f.ScrollBox
    if abox and not GetFFD(abox).botClamped then
        local fb, bb2 = f:GetBottom(), abox:GetBottom()
        if fb and bb2 then
            local dy = (fb + 30) - bb2
            if dy > 0.5 then
                local np = abox:GetNumPoints() or 0
                local pts, ok, touched = {}, np > 0, false
                for i = 1, np do
                    local p, rel, rp, x, y = abox:GetPoint(i)
                    if not p then ok = false break end
                    local isBottom = p:find("BOTTOM", 1, true) and true or false
                    if isBottom then touched = true end
                    pts[i] = { p, rel, rp, x or 0, (y or 0) + (isBottom and dy or 0) }
                end
                if ok and touched then
                    GetFFD(abox).botClamped = true
                    abox:ClearAllPoints()
                    for i = 1, #pts do local t = pts[i]; abox:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
                end
            else
                GetFFD(abox).botClamped = true
            end
        end
    end

    if not _addonListHooked then
        _addonListHooked = true
        -- Pooled rows: house checkbox only. ALL row text colors (title, status,
        -- reload, load-button label) stay Blizzard's.
        if type(_G.AddonList_InitAddon) == "function" then
            hooksecurefunc("AddonList_InitAddon", function(entry)
                if not entry or (entry.IsForbidden and entry:IsForbidden()) then return end
                if entry.Enabled then WSkin.Checkbox(entry.Enabled, { stockCheck = true }) end
                if entry.LoadAddonButton and not GetFFD(entry.LoadAddonButton).skinned then
                    WSkin.Button(entry.LoadAddonButton)
                end
            end)
        end
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_AddonList() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "addonlist",
    apply = Skin_AddonList,
})
end

-------------------------------------------------------------------------------
--  Crafting Orders, customer side (ProfessionsCustomerOrdersFrame,
--  Blizzard_ProfessionsCustomerOrders). Near-identical layout to the auction
--  house, so it replicates the AH treatments: zone lines+wash on the browse
--  view, tile rail, AH search bar, per-list sort strips with full-height
--  hovers, refresh glyph, state-aware action buttons, global-suffix money boxes.
-------------------------------------------------------------------------------
do
local _craftHooked = false
local function Skin_CraftOrders()
    local f = _G.ProfessionsCustomerOrdersFrame
    if not f then return end
    WSkin.Shell("craftorders", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    for _, k in ipairs({ "MoneyFrameBorder", "MoneyFrameInset" }) do
        local el = f[k]
        if el then
            WSkin.FadeRegions(el)
            if el.NineSlice then WSkin.FadeNineSlice(el.NineSlice) end
            WSkin.Register(el, true)
        end
    end

    local function WhiteBtn(b)
        if b then WSkin.Button(b); WSkin.WhiteButtonLabel(b) end
    end
    local function StateBtn(b)
        if b then WSkin.Button(b); WSkin.StateButtonLabel(b) end
    end
    local function MoneyBox(eb)
        if not eb then return end
        WSkin.EditBox(eb)
        local n = eb.GetName and eb:GetName()
        if n then
            for _, suf in ipairs({ "Left", "Middle", "Right" }) do
                local t = _G[n .. suf]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
        end
        -- Tip gold/silver inputs run 6px shorter (one-shot).
        if not GetFFD(eb).slimmed then
            GetFFD(eb).slimmed = true
            local h = eb:GetHeight()
            if h and h > 6 then eb:SetHeight(h - 6) end
        end
    end
    -- AH sort headers: invisible plates over a 50% near-black strip riding the
    -- header row. Strip spans the LIST's width here (no shared per-list wash
    -- rect). White labels, hover stretched to the strip, strip spared from our fades via identity + the fill key.
    local function Headers(list)
        local hc = list and list.HeaderContainer
        if not hc then return end
        local sd = GetFFD(list)
        if not sd.strip then
            local sTex = list:CreateTexture(nil, "BACKGROUND", nil, 1)
            sTex:SetColorTexture(0.02, 0.02, 0.02, 0.5)
            sTex:SetHeight(24)
            sd.strip = sTex
            sd.fill = sTex
        end
        sd.strip:SetAlpha(1)
        local ll0, lr0 = list:GetLeft(), list:GetRight()
        local hl0 = hc:GetLeft()
        if ll0 and lr0 and hl0 then
            sd.strip:ClearAllPoints()
            sd.strip:SetPoint("TOPLEFT", hc, "TOPLEFT", ll0 - hl0, 2)
            sd.strip:SetPoint("TOPRIGHT", hc, "TOPLEFT", lr0 - hl0, 2)
        end
        local children = { hc:GetChildren() }
        for i = 1, #children do
            local col = children[i]
            if col and col.GetObjectType and col:GetObjectType() == "Button" then
                local hd = GetFFD(col)
                if not hd.bg then
                    for _, k2 in ipairs({ "Left", "Middle", "Right" }) do
                        local t2 = col[k2]
                        if t2 and t2.SetTexture then t2:SetTexture("") end
                    end
                    WSkin.FadeRegions(col)
                    local bg = SolidTex(col, "BACKGROUND", 0.02, 0.02, 0.02, 0)
                    bg:SetPoint("TOPLEFT", 1, -1)
                    bg:SetPoint("BOTTOMRIGHT", -1, 1)
                    hd.bg = bg
                    local hov = SolidTex(col, "HIGHLIGHT", 1, 1, 1, 0.1)
                    hov:SetAllPoints(col)
                    hd.hover = hov
                end
                local fs = col.GetFontString and col:GetFontString()
                if fs then WSkin.White(fs) end
                local strip = sd.strip
                if hd.hover and strip and strip.GetTop then
                    local st, sbot = strip:GetTop(), strip:GetBottom()
                    local ct, cbot = col:GetTop(), col:GetBottom()
                    if st and sbot and ct and cbot then
                        hd.hover:ClearAllPoints()
                        hd.hover:SetPoint("TOPLEFT", col, "TOPLEFT", 0, st - ct)
                        hd.hover:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT", 0, sbot - cbot)
                    end
                end
            end
        end
    end
    local function List(list)
        if not list then return end
        local ld = GetFFD(list)
        WSkin.FadeRegions(list, ld.strip and { [ld.strip] = true } or nil)
        if list.NineSlice then WSkin.FadeNineSlice(list.NineSlice) end
        WSkin.Register(list, true)
        WSkin.ScrollBarsIn(list)
        Headers(list)
        if not ld.hdrShowHook then
            ld.hdrShowHook = true
            list:HookScript("OnShow", WSkin.Debounce(function() Headers(list) end))
        end
    end

    local ad = GetFFD(f)
    local browse = f.BrowseOrders
    -- Zone lines (AH treatment): top/bottom seams on the window; rail-edge
    -- divider+2% wash are parented to the BROWSE view so they vanish with it (my-orders+form have no rail).
    if not ad.zoneLines and browse and browse.CategoryList then
        ad.zoneLines = true
        local px = 1
        do
            local PPx = EllesmereUI.PP
            local es = f:GetEffectiveScale()
            if PPx and PPx.perfect and es and es > 0 then px = PPx.perfect / es end
        end
        ad.zonePx = px
        local host = CreateFrame("Frame", nil, f)
        host:SetAllPoints(f)
        host:SetFrameLevel(f:GetFrameLevel())
        local topSep = host:CreateTexture(nil, "ARTWORK")
        topSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        topSep:SetHeight(px)
        topSep:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -77)
        topSep:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -77)
        ad.topSep = topSep
        local botSep = host:CreateTexture(nil, "ARTWORK")
        botSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        botSep:SetHeight(px)
        botSep:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 30)
        botSep:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30)
        local railHost = CreateFrame("Frame", nil, browse)
        railHost:SetAllPoints(browse)
        railHost:SetFrameLevel(browse:GetFrameLevel())
        local cl2 = browse.CategoryList
        local wash = railHost:CreateTexture(nil, "BACKGROUND")
        wash:SetColorTexture(1, 1, 1, 0.02)
        wash:SetPoint("TOPLEFT", cl2, "TOPRIGHT", px, 2)   -- 2px wider than the AH gap; top 3px lower
        wash:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30 + px)
        ad.wash = wash
        local sideSep = railHost:CreateTexture(nil, "ARTWORK")
        sideSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        sideSep:SetWidth(px)
        sideSep:SetPoint("TOPLEFT", wash, "TOPLEFT", -px, 0)
        sideSep:SetPoint("BOTTOMLEFT", wash, "BOTTOMLEFT", -px, 0)
        -- FORM zone: split-section wash on the right + vertical divider,
        -- mirroring the AH sell tab, seated a few px right of the recipe favorite star. Hidden until the order form shows.
        local formHost = CreateFrame("Frame", nil, host)
        formHost:SetAllPoints(host)
        formHost:SetFrameLevel(host:GetFrameLevel())
        formHost:Hide()
        ad.formHost = formHost
        local formWash = formHost:CreateTexture(nil, "BACKGROUND")
        formWash:SetColorTexture(1, 1, 1, 0.02)
        -- TOPLEFT is seated later (needs the panel rect); center keeps it valid.
        formWash:SetPoint("TOPLEFT", f, "TOP", 0, -77 - px)
        formWash:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30 + px)
        ad.formWash = formWash
        local formSep = formHost:CreateTexture(nil, "ARTWORK")
        formSep:SetColorTexture(0.15, 0.15, 0.15, 1)
        formSep:SetWidth(px)
        formSep:SetPoint("TOPLEFT", formWash, "TOPLEFT", -px, 0)
        formSep:SetPoint("BOTTOMLEFT", formWash, "BOTTOMLEFT", -px, 0)
    end
    -- Rail 2px wider: left edge out only, so the divider and wash anchored off
    -- the right edge do not move. One-shot, points preserved.
    local cl0 = browse and browse.CategoryList
    if cl0 and not GetFFD(cl0).widened then
        local np = cl0:GetNumPoints() or 0
        local pts, ok = {}, np > 0
        for i = 1, np do
            local p, rel, rp, x, y = cl0:GetPoint(i)
            if not p then ok = false break end
            pts[i] = { p, rel, rp, (x or 0) - (p:find("LEFT", 1, true) and 2 or 0), y or 0 }
        end
        if ok then
            GetFFD(cl0).widened = true
            cl0:ClearAllPoints()
            for i = 1, #pts do local t = pts[i]; cl0:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
        end
    end
    -- Top divider rides the ACTIVE view's top bar: browse wash top on Browse,
    -- My Orders list header top on My Orders (browse wash is hidden there, its
    -- rect is stale). Re-measured every pass while that anchor is visible (a
    -- one-shot could latch a stale early measurement), frame-anchored at full width so it holds across tab swaps.
    if ad.topSep then
        local ft = f:GetTop()
        local topY, off
        if ad.wash and ad.wash:IsVisible() then
            topY, off = ad.wash:GetTop(), 4          -- +4px wash visual-flush offset
        else
            local mo0 = f.MyOrdersPage
            local hc = mo0 and mo0:IsVisible() and mo0.OrderList and mo0.OrderList.HeaderContainer
            local hct = hc and hc:GetTop()
            if hct then topY, off = hct + 2, 0 end   -- +2 = the header strip's own lift above hc
        end
        if ft and topY then
            local y = (topY - ft) + (ad.zonePx or 1) + off
            ad.topSep:ClearAllPoints()
            ad.topSep:SetPoint("TOPLEFT", f, "TOPLEFT", 0, y)
            ad.topSep:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, y)
        end
    end

    -- Seat the form split divider a few px right of the recipe favorite star.
    -- One-shot, retried per pass until the form has laid out (its OnShow hook re-runs this).
    do
        local rp = f.Form and f.Form.RightPanelBackground
        if ad.formWash and ad.topSep and rp and not ad.formSeated then
            local rl, flx = rp:GetLeft(), f:GetLeft()
            if rl and flx then
                ad.formSeated = true
                -- Top rides the top divider's bottom edge (flush, live); X is
                -- the panel boundary + 6 (topSep BOTTOMLEFT X == frame left).
                ad.formWash:ClearAllPoints()
                ad.formWash:SetPoint("TOPLEFT", ad.topSep, "BOTTOMLEFT", (rl - flx) + 6, 0)
                ad.formWash:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 30 + (ad.zonePx or 1))
            end
        end
    end

    if browse then
        -- Re-run on tab show so the top divider re-seats to the browse wash
        -- when switching back from My Orders; bottom-tab switches do not
        -- otherwise re-trigger the skin.
        if not ad.browseShowHook then
            ad.browseShowHook = true
            browse:HookScript("OnShow", WSkin.Debounce(function() Skin_CraftOrders() end))
        end
        -- Search bar: AH treatment verbatim.
        local sb = browse.SearchBar
        if sb then
            WhiteBtn(sb.SearchButton)
            if sb.FavoritesSearchButton then
                WSkin.Button(sb.FavoritesSearchButton, { "Icon" })
                for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture" }) do
                    local t = sb.FavoritesSearchButton[g] and sb.FavoritesSearchButton[g](sb.FavoritesSearchButton)
                    if t and t.SetAlpha then t:SetAlpha(1) end
                end
            end
            local fb = sb.FilterDropdown or sb.FilterButton
            if fb then
                LeftAlignFilterLabel(fb)
                local sbtn = sb.SearchButton
                local h = sbtn and sbtn.GetHeight and sbtn:GetHeight()
                if h and h > 0 and fb.SetHeight then fb:SetHeight(h) end
                SkinFilterResetX(fb.ResetButton or fb.ClearFiltersButton, fb)
            end
        end
        -- Category rail: chrome off + pooled rows as sidebar tiles (AH rail
        -- treatment). NOT restrip-registered; the Update hook is upkeep.
        local cl = browse.CategoryList
        if cl then
            WSkin.FadeRegions(cl)
            if cl.NineSlice then WSkin.FadeNineSlice(cl.NineSlice) end
            WSkin.Register(cl, true)
            WSkin.ScrollBarsIn(cl)
            -- Rail row spacing -1 via the scroll view's padding (AH rail
            -- treatment); per-row anchor surgery is a no-op on ScrollBox rows.
            if not GetFFD(cl).spacingSet then
                local box0 = cl.ScrollBox
                local view0 = box0 and box0.GetView and box0:GetView()
                if view0 and view0.SetPadding then
                    GetFFD(cl).spacingSet = true
                    pcall(function()
                        local t, b, l, r = 0, 0, 0, 0
                        local pad = view0.GetPadding and view0:GetPadding()
                        if pad then
                            t = (pad.GetTop and pad:GetTop()) or 0
                            b = (pad.GetBottom and pad:GetBottom()) or 0
                            l = (pad.GetLeft and pad:GetLeft()) or 0
                            r = (pad.GetRight and pad:GetRight()) or 0
                        end
                        view0:SetPadding(t, b, l, r, -1)
                        if box0.FullUpdate then box0:FullUpdate(true) end
                    end)
                end
            end
            local clBox = cl.ScrollBox
            if clBox and not GetFFD(cl).rowHook then
                GetFFD(cl).rowHook = true
                local function SkinRailRow(row)
                    if not row or (row.IsForbidden and row:IsForbidden()) then return end
                    local rd = GetFFD(row)
                    if not rd.bg then
                        local bg = row:CreateTexture(nil, "BACKGROUND", nil, -3)
                        bg:SetColorTexture(Theme.bgR + 0.015, Theme.bgG + 0.015, Theme.bgB + 0.015, Theme.bgA)
                        bg:SetPoint("TOPLEFT", 1, -1)
                        bg:SetPoint("BOTTOMRIGHT", -1, 1)
                        rd.bg = bg
                        WSkin.AddBorder(row)
                    end
                    for _, k in ipairs({ "NormalTexture", "SelectedTexture", "SelectedHighlight" }) do
                        local t = row[k]
                        if t then
                            if k == "NormalTexture" then t:SetAlpha(0)
                            else
                                t:SetColorTexture(1, 1, 1, 0.15)
                                t:ClearAllPoints()
                                t:SetAllPoints(row)
                            end
                        end
                    end
                    if row.HighlightTexture then
                        row.HighlightTexture:SetColorTexture(1, 1, 1, 0.1)
                        row.HighlightTexture:ClearAllPoints()
                        row.HighlightTexture:SetAllPoints(row)
                    end
                    local fs = row.Text or (row.GetFontString and row:GetFontString())
                    if fs then WSkin.White(fs) end
                end
                local function SkinRailRows()
                    if clBox.ForEachFrame and clBox:IsVisible() then
                        clBox:ForEachFrame(SkinRailRow)
                    end
                end
                GetFFD(cl).railRows = SkinRailRows
                hooksecurefunc(clBox, "Update", WSkin.Debounce(SkinRailRows))
            end
            local rr = GetFFD(cl).railRows
            if rr and clBox and clBox.GetView and clBox:GetView() then pcall(rr) end
        end
        -- Results list; headers rebuild via SetupTable.
        List(browse.RecipeList)
        if browse.SetupTable and not GetFFD(browse).tableHook then
            GetFFD(browse).tableHook = true
            hooksecurefunc(browse, "SetupTable", WSkin.Debounce(function()
                Headers(browse.RecipeList)
            end))
        end
    end

    -- Order form (item-detail equivalent).
    local form = f.Form
    if form then
        -- Toggle the form split zone with the form and re-run the skin on show,
        -- so the divider seats once the panels have laid out.
        if not ad.formShowHook then
            ad.formShowHook = true
            local function SyncFormZone()
                if ad.formHost then ad.formHost:SetShown(form:IsShown() and true or false) end
            end
            form:HookScript("OnShow", WSkin.Debounce(function()
                SyncFormZone(); Skin_CraftOrders()
            end))
            form:HookScript("OnHide", SyncFormZone)
            SyncFormZone()
        end
        WhiteBtn(form.BackButton)
        for _, k in ipairs({ "RecipeHeader", "LeftPanelBackground", "RightPanelBackground" }) do
            local el = form[k]
            if el then
                if el.IsObjectType and el:IsObjectType("Texture") then
                    el:SetAlpha(0)
                else
                    WSkin.FadeRegions(el)
                    WSkin.Register(el, true)
                end
            end
        end
        if form.TrackRecipeCheckbox and form.TrackRecipeCheckbox.Checkbox then
            WSkin.Checkbox(form.TrackRecipeCheckbox.Checkbox, { borderInset = 2 })
        end
        if form.AllocateBestQualityCheckbox then WSkin.Checkbox(form.AllocateBestQualityCheckbox) end
        local ddRecip = form.OrderRecipientDropdown
        local tgtRecip = form.OrderRecipientTarget
        if tgtRecip then WSkin.EditBox(tgtRecip) end
        if ddRecip then WSkin.Dropdown(ddRecip) end
        -- Recipient dropdown + its "To:" target input drop 10px. Shift the target ONLY
        -- when it is not anchored to the dropdown, or it has already followed.
        local function ShiftDown10(fr)
            if not fr or GetFFD(fr).shift10 then return end
            local np = fr:GetNumPoints() or 0
            local pts, ok = {}, np > 0
            for i = 1, np do
                local p, rel, rp, x, y = fr:GetPoint(i)
                if not p then ok = false break end
                pts[i] = { p, rel, rp, x or 0, (y or 0) - 10 }
            end
            if ok then
                GetFFD(fr).shift10 = true
                fr:ClearAllPoints()
                for i = 1, #pts do local t = pts[i]; fr:SetPoint(t[1], t[2], t[3], t[4], t[5]) end
            end
        end
        ShiftDown10(ddRecip)
        if tgtRecip then
            local anchoredToDD = false
            for i = 1, (tgtRecip:GetNumPoints() or 0) do
                local _, rel = tgtRecip:GetPoint(i)
                if rel == ddRecip then anchoredToDD = true break end
            end
            if not anchoredToDD then ShiftDown10(tgtRecip) end
        end
        if form.MinimumQuality and form.MinimumQuality.Dropdown then
            WSkin.Dropdown(form.MinimumQuality.Dropdown)
        end
        local pay = form.PaymentContainer
        if pay then
            if pay.NoteEditBox then
                WSkin.FadeRegions(pay.NoteEditBox)
                WSkin.Register(pay.NoteEditBox, true)
                -- 50% black backing on the actual scrolling field: NoteEditBox
                -- is only a wrapper and its bounds do not cover the visible
                -- box. Protected "bg" key, so a Restrip never fades it.
                local seb = pay.NoteEditBox.ScrollingEditBox
                local sbox = seb and seb.ScrollBox
                if sbox and not GetFFD(sbox).bg then
                    local bg = sbox:CreateTexture(nil, "BACKGROUND", nil, -7)
                    bg:SetColorTexture(0, 0, 0, 0.5)
                    bg:SetAllPoints(sbox)
                    GetFFD(sbox).bg = bg
                end
            end
            if pay.TipMoneyInputFrame then
                MoneyBox(pay.TipMoneyInputFrame.GoldBox)
                MoneyBox(pay.TipMoneyInputFrame.SilverBox)
            end
            if pay.DurationDropdown then WSkin.Dropdown(pay.DurationDropdown) end
            StateBtn(pay.ListOrderButton)
            StateBtn(pay.CancelOrderButton)
        end
        local cls = form.CurrentListings
        if cls then
            WSkin.Panel(cls)
            if cls.CloseButton then WSkin.CloseButton(cls.CloseButton) end
            List(cls.OrderList)
        end
        local qd = form.QualityDialog
        if qd then
            WSkin.Panel(qd)
            if qd.Bg and qd.Bg.SetAlpha then qd.Bg:SetAlpha(0) end
            if qd.ClosePanelButton then WSkin.CloseButton(qd.ClosePanelButton) end
            WhiteBtn(qd.AcceptButton)
            WhiteBtn(qd.CancelButton)
            for i = 1, 3 do
                local c = qd["Container" .. i]
                if c and c.EditBox then WSkin.EditBox(c.EditBox) end
            end
        end
    end

    -- My orders page.
    local mo = f.MyOrdersPage
    if mo then
        -- Re-run on tab show so the top divider re-seats to this list's top;
        -- nothing else re-triggers the skin on a bottom-tab switch.
        if not ad.moShowHook then
            ad.moShowHook = true
            mo:HookScript("OnShow", WSkin.Debounce(function() Skin_CraftOrders() end))
        end
        WSkin.RefreshGlyph(mo.RefreshButton)
        List(mo.OrderList)
    end

    -- Bottom tabs (frame.Tabs table, AH-style). These carry NONE of the
    -- standard selection fields, so the engine's TabIsSelected() never matches
    -- and neither tab shows active. Selection here is purely which content page
    -- is shown, so sync the FFD override from BrowseOrders/MyOrdersPage
    -- visibility (mirroring the AH's displayMode SyncTabSel); runs every pass, re-triggered by the browse/mo OnShow hooks on every tab switch.
    local coTabs = {}
    if type(f.Tabs) == "table" then
        for _, t in ipairs(f.Tabs) do
            if t then WSkin.Tab(t); coTabs[#coTabs + 1] = t end
        end
    end
    WSkin.NormalizeTabRow(coTabs)
    for _, t in ipairs(coTabs) do
        local name = t.GetName and t:GetName()
        if name and name:find("BrowseTab", 1, true) then
            GetFFD(t).selOverride = (f.BrowseOrders and f.BrowseOrders:IsShown()) and true or false
        elseif name and name:find("OrdersTab", 1, true) then
            GetFFD(t).selOverride = (f.MyOrdersPage and f.MyOrdersPage:IsShown()) and true or false
        end
    end
    WSkin.UpdateAllTabs()

    if not _craftHooked then
        _craftHooked = true
        WSkin.HookShow(f, WSkin.Debounce(function()
            if f:IsVisible() then Skin_CraftOrders() end
        end))
    end
end

WSkin.RegisterWindow({
    key = "craftorders",
    addons = { Blizzard_ProfessionsCustomerOrders = true },
    apply = Skin_CraftOrders,
})
end

-------------------------------------------------------------------------------
--  Item Upgrades (ItemUpgradeFrame, Blizzard_ItemUpgradeUI). Flat shell,
--  squared upgrade slot, flat upgrade-track dropdown and action button, bottom
--  currency strip stripped of its plate art.
-------------------------------------------------------------------------------
do
local function Skin_ItemUpgrade()
    local f = _G.ItemUpgradeFrame
    if not f then return end
    -- bottomBar: the art kill below strips the plate behind the foot currency
    -- strip, so the shell's bottom band puts that footer back in the same
    -- black 0.5 as the title bar.
    WSkin.Shell("itemupgrade", f, { bottomBar = true })
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "ItemUpgradeFrame")   -- close, ItemInfo.Dropdown, scrollbars
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.ItemUpgradeFrameBg then _G.ItemUpgradeFrameBg:SetAlpha(0) end
    -- The backplates (TopBG/BottomBG) repaint to the SLOTTED ITEM'S QUALITY
    -- COLOR on every item change (the purple wash an epic leaves), re-showing
    -- art a plain SetAlpha(0) had hidden. Clear the window's art OUTRIGHT
    -- (SetTexture/SetAtlas "") so a re-tint has nothing to paint. Only DIRECT
    -- regions of the window are touched (content lives on child frames), our own shell textures spared.
    local fd = GetFFD(f)
    local keepArt = {}
    -- bottomBar is load-bearing here TWICE: KillArt clears every direct region
    -- of the window, and FadeBottomPlates fades any texture in the bottom 60px spanning over half the width -- exactly our own bottom band's shape.
    for _, k in ipairs({ "bg", "bgOverlay", "modernBg", "topBar", "bottomBar", "rightShade" }) do
        if fd[k] then keepArt[fd[k]] = true end
    end
    local function KillArt(r)
        if not r or keepArt[r] or not r.IsObjectType or not r:IsObjectType("Texture") then return end
        if r.SetAtlas then r:SetAtlas("") end
        if r.SetTexture then r:SetTexture("") end
        r:SetAlpha(0)
    end
    local regions = { f:GetRegions() }
    for i = 1, #regions do KillArt(regions[i]) end
    -- ItemUpgradeBg is its own keyed piece, so name it explicitly rather than leaving it to the region walk above.
    for _, k in ipairs({ "Bg", "TopBG", "BottomBG", "Background", "TopTileStreaks",
                         "ItemUpgradeBg" }) do
        KillArt(f[k])
    end
    -- The nine-slice is part of the quality-tinted chrome too, so its pieces are CLEARED rather than just alpha'd.
    if f.NineSlice then
        local regions2 = { f.NineSlice:GetRegions() }
        for i = 1, #regions2 do
            KillArt(regions2[i])
        end
    end
    if f.Inset then WSkin.Inset(f.Inset) end
    WSkin.FadeKeyedArt(f)
    WSkin.FadeArtIn(f)

    local title = (f.TitleContainer and f.TitleContainer.TitleText)
        or f.TitleText or _G.ItemUpgradeFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end

    -- Upgrade slot: gold frame off, icon squared inside a flat well so an EMPTY slot still reads as a slot.
    local ib = f.UpgradeItemButton
    if ib then
        for _, k in ipairs({ "ButtonFrame", "Border", "IconBorder", "SlotBackground",
                             "EmptySlot", "EmptyBackground" }) do
            local t = ib[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
        local ibd = GetFFD(ib)
        if not ibd.slotBg then
            local well = SolidTex(ib, "BACKGROUND", 0.02, 0.02, 0.02, 0.9)
            well:SetAllPoints(ib)
            ibd.slotBg = well
            WSkin.AddBorder(ib)
        end
        local icon = ib.Icon or ib.icon or ib.IconTexture
        if icon and icon.SetTexCoord then WSkin.SquareIcon(icon) end
    end

    -- Upgrade-track selector + any other pane art on the info block.
    local info = f.ItemInfo
    if info then
        if info.Dropdown then WSkin.Dropdown(info.Dropdown) end
        for _, k in ipairs({ "Bg", "Background", "Divider", "PillarLeft", "PillarRight" }) do
            local t = info[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
    end

    -- Bottom currency strip: NO plate of our own, amounts sit flat on the
    -- shell. Plate art is NOT keyed off the currencies container: it lives in
    -- its own wrapper frame, ItemUpgradeFramePlayerCurrenciesBorder, with
    -- Left/Middle/Right as CHILDREN. Fade the wrapper's whole subtree (textures
    -- only, so amounts survive) and register for repaint re-fades; a named
    -- `container.BorderLeft` lookup would miss the narrow end caps.
    local function FadeArtTree(host, depth)
        depth = depth or 0
        if not host or depth > 3 or host:IsForbidden() then return end
        -- Provenance gate: another addon parented into this window keeps its
        -- whole subtree. depth > 0, so an explicit root call always runs.
        if depth > 0 and WSkin.IsForeignFrame(host) then return end
        if host.IsObjectType and host:IsObjectType("Texture") then
            if host.SetAlpha then host:SetAlpha(0) end
            return
        end
        WSkin.FadeRegions(host)
        if host.NineSlice then WSkin.FadeNineSlice(host.NineSlice) end
        WSkin.Register(host, true)
        if not host.GetChildren then return end
        local children = { host:GetChildren() }
        for i = 1, #children do
            FadeArtTree(children[i], depth + 1)
        end
    end
    local pc = f.PlayerCurrencies or _G.ItemUpgradeFramePlayerCurrencies
    FadeArtTree(_G.ItemUpgradeFramePlayerCurrenciesBorder or (pc and pc.Border))
    -- Belt and braces: the pieces carry globals of their own too.
    for _, n in ipairs({ "ItemUpgradeFramePlayerCurrenciesBorderLeft",
                         "ItemUpgradeFramePlayerCurrenciesBorderMiddle",
                         "ItemUpgradeFramePlayerCurrenciesBorderRight" }) do
        local t = _G[n]
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    if pc then
        if pc.NineSlice then WSkin.FadeNineSlice(pc.NineSlice) end
        for _, k in ipairs({ "Background", "Bg", "BG" }) do
            local t = pc[k]
            if t and t.SetAlpha then t:SetAlpha(0) end
        end
    end
    for _, k in ipairs({ "BottomInset", "MoneyInset", "MoneyFrameInset", "MoneyFrameBorder" }) do
        local el = f[k] or _G["ItemUpgradeFrame" .. k]
        if el then
            if el.IsObjectType and el:IsObjectType("Texture") then el:SetAlpha(0)
            else WSkin.Inset(el) end
        end
    end

    -- Geometry sweep for the bottom plate, whoever owns it: names for this bar
    -- move between builds, so match on SHAPE -- any TEXTURE in the bottom 60px
    -- spanning more than half the window width is backing art (currency icons
    -- are far narrower, amounts are FontStrings, so both survive). Needs live rects, so it lands on show/update passes, not login.
    local function Num(v)
        if v == nil then return nil end
        if issecretvalue and issecretvalue(v) then return nil end
        return v
    end
    local function FadeBottomPlates(host, depth)
        depth = depth or 0
        if not host or depth > 5 or host:IsForbidden() then return end
        -- Provenance gate, doubly important here: the match below is a pure
        -- GEOMETRY heuristic (bottom 60px, over half the window wide) that
        -- would blank an addon's own bar parented into this frame.
        if depth > 0 and WSkin.IsForeignFrame(host) then return end
        local fb, fw = Num(f:GetBottom()), Num(f:GetWidth())
        if not fb or not fw then return end
        if host.GetRegions then
            local regions2 = { host:GetRegions() }
            for i = 1, #regions2 do
                local r = regions2[i]
                if r and not keepArt[r] and r.IsObjectType and r:IsObjectType("Texture")
                   and (r:GetAlpha() or 0) > 0 then
                    local rt, rw = Num(r:GetTop()), Num(r:GetWidth())
                    if rt and rw and rt < fb + 60 and rw > fw * 0.5 then r:SetAlpha(0) end
                end
            end
        end
        if not host.GetChildren then return end
        local children = { host:GetChildren() }
        for i = 1, #children do
            FadeBottomPlates(children[i], depth + 1)
        end
    end
    FadeBottomPlates(f)

    -- Action buttons: Upgrade button mirrors its enabled/disabled state -- it
    -- spends currency, so a permanently white label would read as active while unaffordable.
    WSkin.ButtonsIn(f)
    for _, k in ipairs({ "UpgradeButton", "ConfirmButton" }) do
        local b = f[k]
        if b then WSkin.Button(b); WSkin.StateButtonLabel(b) end
    end

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then Skin_ItemUpgrade(); WSkin.Restrip() end
    end))
    -- The quality repaint fires on item CHANGE, not on show, so OnShow alone
    -- leaves the first slotted item wearing Blizzard's backdrop until reopen.
    -- Listen for the upgrade events instead (debounced, registration pcall'd since the event set shifts between builds).
    if not fd.evt then
        local ev = CreateFrame("Frame")
        fd.evt = ev
        -- Gated on visibility, NO global WSkin.Restrip(): fires on every item
        -- change, Skin_ItemUpgrade already re-clears this window's art, and the global sweep allocates a table per registered frame suite-wide.
        ev:SetScript("OnEvent", WSkin.Debounce(function()
            local uf = _G.ItemUpgradeFrame
            if uf and uf:IsVisible() then Skin_ItemUpgrade() end
        end))
        for _, e in ipairs({ "ITEM_UPGRADE_MASTER_OPENED", "ITEM_UPGRADE_MASTER_UPDATE",
                             "ITEM_UPGRADE_MASTER_SET_ITEM", "ITEM_UPGRADE_MASTER_CLOSED",
                             "ITEM_INTERACTION_ITEM_SELECTION_UPDATED" }) do
            pcall(ev.RegisterEvent, ev, e)
        end
    end
end

WSkin.RegisterWindow({
    key = "itemupgrade",
    addons = { Blizzard_ItemUpgradeUI = true },
    apply = Skin_ItemUpgrade,
})
end

-------------------------------------------------------------------------------
--  Loot window (LootFrame). Base UI, always loaded. Portrait frame:
--  TitleContainer + NineSlice + the LootFrameTitleText global. Rows KEEP their
--  item quality colors -- names and rarity subtext are re-fonted, never
--  re-colored (same rule the merchant and trainer packs use).
-------------------------------------------------------------------------------
do
local lootSkinned = false
local LOOT_WHITE = { r = 1, g = 1, b = 1 }
local lootQualityRGB = { r = 1, g = 1, b = 1 }

-- The best quality among the slots still holding loot (a looted slot reads type None);
-- nil with none left or no loot at all (the Edit Mode preview).
local function BestLootQuality()
    local best
    for i = 1, GetNumLootItems() do
        if GetLootSlotType(i) ~= Enum.LootSlotType.None then
            local q = select(5, GetLootSlotInfo(i))
            if q and (not best or q > best) then best = q end
        end
    end
    return best
end

-- Quality mode's color for a best quality: Uncommon and up in their quality color, else (Poor
-- or Common only, or no loot) the Quality swatch's own color. Refills one table, read at once.
local function LootQualityColor(best)
    if not best or best < Enum.ItemQuality.Uncommon then
        return EllesmereUIDB.lootWindowBorderQualityColor or LOOT_WHITE
    end
    lootQualityRGB.r, lootQualityRGB.g, lootQualityRGB.b = C_Item.GetItemQualityColor(best)
    return lootQualityRGB
end

-- The window border's picked color, for Poor/Common icons under Icon Borders. nil while the border is Default.
local function LootWindowColor()
    local db = EllesmereUIDB
    if not (db and db.lootWindowBorderTexture) then return nil end
    local mode = db.lootWindowBorderColorMode or "custom"
    if mode == "accent" then return EllesmereUI.ELLESMERE_GREEN end
    if mode == "class" then
        local _, class = UnitClass("player")
        return class and RAID_CLASS_COLORS[class]
    end
    if mode == "quality" then return db.lootWindowBorderQualityColor or LOOT_WHITE end
    return db.lootWindowBorderColor or LOOT_WHITE
end

-- Quality mode follows the loot as it is taken: Blizzard hides a looted row with no list
-- update, so a frame of ours repaints the border when a cleared slot changes the best quality.
-- Registered only while the window shows in Quality mode; the loot's close lets it go.
local ApplyLootBorder
local lootQualityWatch, lootPaintedBest
local function SyncLootQualityWatch(on)
    if on then
        if not lootQualityWatch then
            lootQualityWatch = CreateFrame("Frame")
            lootQualityWatch:SetScript("OnEvent", function(self, event)
                if event == "LOOT_CLOSED" then
                    self:UnregisterAllEvents()
                elseif _G.LootFrame and BestLootQuality() ~= lootPaintedBest then
                    ApplyLootBorder(_G.LootFrame)
                end
            end)
        end
        lootQualityWatch:RegisterEvent("LOOT_SLOT_CLEARED")
        lootQualityWatch:RegisterEvent("LOOT_CLOSED")
    elseif lootQualityWatch then
        lootQualityWatch:UnregisterAllEvents()
    end
end

-- The Loot Window card's border style. Unset keeps the shell's window border untouched.
ApplyLootBorder = function(f)
    local d = GetFFD(f)
    local db = EllesmereUIDB
    if db and db.lootWindowBorderTexture then
        if d.atlasBorderFrame then d.atlasBorderFrame:Hide() end
        local quality = db.lootWindowBorderColorMode == "quality"
        local override
        if quality then
            lootPaintedBest = BestLootQuality()
            override = LootQualityColor(lootPaintedBest)
        end
        if EllesmereUI._applyBlizzardConfiguredBorder then
            EllesmereUI._applyBlizzardConfiguredBorder(f, "lootWindow", 1, override)
        end
        SyncLootQualityWatch(quality and f:IsShown())
        d.lootBorderOn = true
    elseif d.lootBorderOn then
        if d.atlasBorderFrame then d.atlasBorderFrame:Show() end
        if EllesmereUI._hideBlizzardConfiguredBorder then
            EllesmereUI._hideBlizzardConfiguredBorder(f)
        end
        SyncLootQualityWatch(false)
        d.lootBorderOn = nil
    end
end

local function Skin_Loot()
    local f = _G.LootFrame
    if not f then return end
    lootSkinned = true
    WSkin.Shell("loot", f)
    WSkin.RemovePortrait(f)
    WSkin.CommonChrome(f, "LootFrame")
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    if _G.LootFrameBg then _G.LootFrameBg:SetAlpha(0) end
    if f.Bg and f.Bg.SetAlpha then f.Bg:SetAlpha(0) end
    if f.Inset then WSkin.Inset(f.Inset) end
    WSkin.FadeKeyedArt(f)
    local title = (f.TitleContainer and f.TitleContainer.TitleText) or _G.LootFrameTitleText
    if title then WSkin.Font(title); WSkin.White(title) end
    WSkin.ScrollBarsIn(f)

    -- One loot row: squared icon, plate art off, flat hover. Fonts only on the
    -- text so quality coloring survives.
    local function SkinLootRow(row)
        if not row or row:IsForbidden() then return end
        local item = row.Item or row
        local icon = item.icon or item.Icon or item.IconTexture
            or (item.GetNormalTexture and item:GetNormalTexture())
        if icon and icon.SetTexCoord then
            -- SquareIcon WITHOUT its BorderRegion (those lines are neither
            -- recolorable nor pixel-snapped); the border here is our own.
            WSkin.SquareIcon(icon)
            -- Action-bar 5.5% zoom on top of the engine's 8% square crop, so
            -- loot icons read at the bars' zoom. LOCAL to loot rows; SquareIcon
            -- stays at 8% everywhere else. Re-asserted whenever Blizzard
            -- re-textures the icon: per-slot repopulation writes the texture
            -- directly without a ScrollBox Update, so a one-shot SetTexCoord can be overwritten. Post-hook only, args untouched.
            icon:SetTexCoord(0.135, 0.865, 0.135, 0.865)
            local icd = GetFFD(icon)
            if not icd.coordHook and icon.SetTexture then
                icd.coordHook = true
                hooksecurefunc(icon, "SetTexture", function(self)
                    self:SetTexCoord(0.135, 0.865, 0.135, 0.865)
                end)
            end

            -- Blizzard's slot frame (button's NormalTexture) draws a ring that
            -- swallowed the zoom visually; the roll-popup pack already hides its
            -- equivalent. Guarded against the icon fallback above, which can BE the normal texture on some templates.
            local nt = item.GetNormalTexture and item:GetNormalTexture()
            if nt and nt ~= icon and nt.SetAlpha then nt:SetAlpha(0) end

            -- 1px physical, pixel-perfect, quality-colored icon border. Strips
            -- live on a HOST FRAME of ours (child of the row, anchored to the
            -- icon) via PP.CreateBorder (integer physical thickness,
            -- snap-immune), so NOTHING is written onto Blizzard frames -- all state sits in FFD and PP's own registry.
            local PPb = EllesmereUI and (EllesmereUI.PanelPP or EllesmereUI.PP)
            local idd = GetFFD(item)
            if not idd.qBorder and PPb and PPb.CreateBorder and item.CreateTexture then
                local host = CreateFrame("Frame", nil, item)
                host:SetPoint("TOPLEFT", icon, "TOPLEFT", 0, 0)
                host:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT", 0, 0)
                host:SetFrameLevel(item:GetFrameLevel() + 2)
                PPb.CreateBorder(host, 0, 0, 0, 1, 1, "OVERLAY", 7)
                idd.qBorder = host
            end
            -- Quality color read from Blizzard's own ring: vertex-colored per
            -- quality and HIDDEN for poor/common drops, so hidden/absent maps
            -- to black as wanted. Re-read every pass (pooled rows change item
            -- between opens); the ring is hidden again after reading.
            if idd.qBorder and PPb and PPb.SetBorderColor then
                local ring = item.IconBorder
                local qr, qg, qb = 0, 0, 0
                local isQuality = false
                if ring and ring.IsShown and ring:IsShown() and ring.GetVertexColor then
                    local rr, rg, rb = ring:GetVertexColor()
                    -- Uncommon and up only: poor/common rings are achromatic
                    -- (gray/white) while every quality from green up is saturated, so a
                    -- chroma test filters them with no item-quality lookup.
                    if rr and (math.max(rr, rg, rb) - math.min(rr, rg, rb)) > 0.1 then
                        qr, qg, qb = rr, rg, rb
                        isQuality = true
                    end
                    ring:SetAlpha(0)
                end
                -- Loot Window card's Icon Borders: the picked style and size, still in the quality color.
                local db = EllesmereUIDB
                if db and db.lootIconBorder then
                    -- Poor/common take the window border's color (black while that border is Default).
                    if not isQuality then
                        local wc = LootWindowColor()
                        if wc then qr, qg, qb = wc.r, wc.g, wc.b end
                    end
                    local tex = db.lootIconBorderTexture or "solid"
                    local key = db.lootIconBorderThickness
                    local size = key and (EllesmereUI.BORDER_STEP_OF_LABEL[key] or 1) or 1
                    EllesmereUI.ApplyBorderStyle(idd.qBorder, size, qr, qg, qb, 1, tex,
                        db.lootIconBorderOffsetX, db.lootIconBorderOffsetY, nil, nil,
                        "blizzardSkin", key or "thin", nil,
                        EllesmereUI.BorderPx(db.lootIconBorderThicknessPx, size, tex))
                    idd.qStyled = true
                elseif idd.qStyled then
                    EllesmereUI.HideBorderStyle(idd.qBorder)
                    idd.qBorder:Show()
                    EllesmereUI.PP.UpdateBorder(idd.qBorder, 1, qr, qg, qb, 1)
                    EllesmereUI.PP.ShowBorder(idd.qBorder)
                    idd.qStyled = nil
                else
                    PPb.SetBorderColor(idd.qBorder, qr, qg, qb, 1)
                end
            end
        end
        for _, host in ipairs({ row, item }) do
            for _, k in ipairs({ "NameFrame", "Background", "Bg" }) do
                local t = host[k]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            -- Card STROKE textures ring the row card: BorderFrame carries
            -- Looting_ItemCard_Stroke_Normal, HighlightNameFrame / PushedNameFrame the
            -- ClickState variant Blizzard drives to 0.7 alpha on hover/click.
            -- State-driven alpha overwrites a plain SetAlpha(0), so clear the ART
            -- instead (a state driver can animate nothing). Re-cleared every pass
            -- in case a pooled row re-applies its template atlas; the 5% highlight backdrop is the replacement hover cue.
            for _, k in ipairs({ "BorderFrame", "PushedNameFrame", "HighlightNameFrame" }) do
                local t = host[k]
                if t and t.SetAlpha then
                    if t.SetAtlas then t:SetAtlas("") end
                    if t.SetTexture then t:SetTexture("") end
                    t:SetAlpha(0)
                end
            end
            -- The stack count KEEPS Blizzard's font: it is an outlined NUMBER
            -- font drawn over the icon, and the panel face reads unreadable on a bright icon. Everything else is re-fonted.
            local countFS = host.Count or host.count
                or (host.GetName and host:GetName() and _G[host:GetName() .. "Count"])
            if host.GetRegions then
                local regions = { host:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r ~= countFS and r.IsObjectType and r:IsObjectType("FontString") then
                        WSkin.Font(r)
                    end
                end
            end
            local hl = host.GetHighlightTexture and host:GetHighlightTexture()
            if hl and hl.SetColorTexture then
                if host == item then
                    -- Item tile hover: flat white backdrop over the whole tile
                    -- instead of Blizzard's hover ring. BLEND explicitly
                    -- (highlights default to ADD, reading as a glow), re-asserted
                    -- via SetAtlas/SetTexture post-hooks since per-slot repopulation re-arts the highlight with no ScrollBox Update.
                    local hld = GetFFD(hl)
                    local function flat(self)
                        self:SetColorTexture(1, 1, 1, 0.08)
                        self:SetBlendMode("BLEND")
                    end
                    flat(hl)
                    hl:SetTexCoord(0, 1, 0, 1)
                    -- Anchored to the ROW, not the item button: the backdrop
                    -- lifts the whole card, of which the icon slot is only a
                    -- corner. Texture stays in the item's highlight slot, so it still shows exactly while hovered.
                    hl:ClearAllPoints()
                    hl:SetAllPoints(row)
                    if not hld.flatHook then
                        hld.flatHook = true
                        hooksecurefunc(hl, "SetAtlas", flat)
                        hooksecurefunc(hl, "SetTexture", flat)
                    end
                else
                    hl:SetColorTexture(1, 1, 1, 0.1)
                end
            end
        end
    end

    local box = f.ScrollBox
    -- Item list 5px lower, ONCE per session: Skin_Loot re-runs on every open,
    -- and an unguarded relative shift walks the box down 5px per loot.
    if box and box.GetNumPoints then
        local sd = GetFFD(box)
        if not sd.shifted then
            sd.shifted = true
            local n = box:GetNumPoints()
            local pts = {}
            for i = 1, n do pts[i] = { box:GetPoint(i) } end
            if n > 0 then
                box:ClearAllPoints()
                for i = 1, n do
                    local pt = pts[i]
                    box:SetPoint(pt[1], pt[2], pt[3], pt[4] or 0, (pt[5] or 0) - 5)
                end
            end
        end
    end
    if box and box.ForEachFrame then
        pcall(box.ForEachFrame, box, SkinLootRow)
        local bd = GetFFD(box)
        if box.Update and not bd.rowHook then
            bd.rowHook = true
            hooksecurefunc(box, "Update", function(b)
                pcall(b.ForEachFrame, b, SkinLootRow)
            end)
        end
    end

    ApplyLootBorder(f)

    WSkin.HookShow(f, WSkin.Debounce(function()
        if f:IsVisible() then Skin_Loot(); WSkin.Restrip() end
    end))
end

EllesmereUI._Loot_RefreshBorder = function()
    local f = _G.LootFrame
    if not (lootSkinned and f) then return end
    -- Open: a full pass also restyles the icon borders. Closed: the next open does that.
    if f:IsShown() then Skin_Loot() else ApplyLootBorder(f) end
end

WSkin.RegisterWindow({
    key = "loot",
    apply = Skin_Loot,
})
end

-------------------------------------------------------------------------------
--  Loot toasts (the "You received" alert popups). NOT a window: alert frames
--  are POOLED and recycled, so there is no single frame to skin at login.
--  Frames are reached through the alert subsystems' object pools and re-skinned
--  whenever a toast fires (idempotent + FFD-guarded).
-------------------------------------------------------------------------------
do
local function Skin_LootToast()
    -- Native size/layout of the money toast template, captured from the first
    -- money toast seen; item toasts are resized/re-anchored to match (frame
    -- size, icon size, icon inset, icon-to-text gap, text centering). Offsets stored in FRAME UNITS (effective scale divided out at capture).
    local moneyToastH, moneyToastW, moneyIconH
    local moneyIconL, moneyIconCy, moneyTextGap, moneyTextCy

    -- The reference is PERSISTED (EllesmereUIDB.lootToastMoneyRef): sessions see
    -- item toasts long before any gold toast, and the fallback sizing is visibly
    -- off. One gold toast ever seen seeds every later session, and the live
    -- capture keeps refreshing it, so a template change self-corrects on the
    -- next gold drop. A CACHE, not a setting -- NOT in the profile-export allowlist.
    do
        local c = EllesmereUIDB and EllesmereUIDB.lootToastMoneyRef
        if type(c) == "table" then
            moneyToastH, moneyToastW, moneyIconH = c.h, c.w, c.iconH
            moneyIconL, moneyIconCy = c.iconL, c.iconCy
            moneyTextGap, moneyTextCy = c.textGap, c.textCy
        end
    end

    -- Flatten the toast's ornate art to a house panel. Only frames that look like a loot toast are touched; other alert styles are left alone.
    local function SkinToast(t)
        if not t or type(t) ~= "table" or not t.IsForbidden or t:IsForbidden() then return end
        -- Shape test: a text label is the reliable marker (this template
        -- carries .Background+.ItemName). Icon must NOT be required -- its key varies, and gating on it misses the loot toast entirely.
        local label = t.ItemName or t.Label or t.Title
        if not (type(label) == "table" and label.GetText) then return end
        local icon = t.Icon or t.icon or (t.lootItem and t.lootItem.Icon)
        local d = GetFFD(t)
        if not d.bg then
            -- Full style-aware shell so a toast follows the window setting:
            -- modern_blizz atlas+black overlay on "eui", flat user color on
            -- "modern", swapping live. No top bar (toast has no title row), but the atlas frame IS kept for its soft edge vignette.
            WSkin.Shell("loottoast", t, { noTopBar = true })
        end
        -- Decorative art off, icon kept. SetAlpha(0) is NOT enough: a toast
        -- fades in through an ANIMATION that drives alpha every frame and wins
        -- over our write. Clear the TEXTURE instead (an animation can animate
        -- nothing). Re-run per toast: Blizzard's setup re-applies atlases every time a pooled frame is reused.
        local keep = {}
        if icon then keep[icon] = true end
        -- Every texture the shell owns, or the art kill below would wipe our
        -- own backdrop along with Blizzard's.
        for _, k in ipairs({ "bg", "bgOverlay", "modernBg", "topBar", "bottomBar", "selBar" }) do
            if d[k] then keep[d[k]] = true end
        end
        -- Frames of OURS hanging off the toast (shell atlas border, PP border
        -- container): the recursion below would clear their textures too.
        local PPt = EllesmereUI and (EllesmereUI.PanelPP or EllesmereUI.PP)
        local ourBorder = PPt and PPt.GetBorders and PPt.GetBorders(t)
        local function KillArt(host, depth)
            depth = depth or 0
            if not host or depth > 2 or not host.IsForbidden or host:IsForbidden() then return end
            if host == d.atlasBorderFrame or host == ourBorder then return end
            -- Provenance gate: this clears textures OUTRIGHT (SetAtlas /
            -- SetTexture "" then alpha 0), unrecoverable for a foreign frame.
            if depth > 0 and WSkin.IsForeignFrame(host) then return end
            if host.GetRegions then
                local regions = { host:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and not keep[r] and r.IsObjectType and r:IsObjectType("Texture") then
                        if r.SetAtlas then r:SetAtlas("") end
                        if r.SetTexture then r:SetTexture("") end
                        r:SetAlpha(0)
                    end
                end
            end
            if not host.GetChildren then return end
            local children = { host:GetChildren() }
            for i = 1, #children do
                KillArt(children[i], depth + 1)
            end
        end
        KillArt(t)
        if icon and icon.SetTexCoord then WSkin.SquareIcon(icon, t) end

        -- User scale (options slider), both toast types. MUST run before the
        -- pixel-grid strip solve below, so onePx reflects the final scale.
        local sc = (EllesmereUIDB and EllesmereUIDB.lootToastScale) or 1
        if t.SetScale and t.GetScale and t:GetScale() ~= sc then t:SetScale(sc) end

        -- Tighter ITEM toasts, sized to the money toast. Money frame (.Amount)
        -- keeps its native tighter template and is the height reference; item
        -- toasts adopt it once a money toast has been seen (-16px fallback
        -- until then) and lose 6px of icon. Bases captured on first sight, shrink re-asserted every pass since Blizzard repaints a pooled frame on reuse.
        local isMoney = t.Amount ~= nil
        if not d.baseH and t.GetHeight then
            local h = t:GetHeight()
            if h and h > 16 then d.baseH = h end
        end
        if not d.baseW and t.GetWidth then
            local w = t:GetWidth()
            if w and w > 50 then d.baseW = w end
        end
        if isMoney then
            -- Live values always win over the cached seed: money frames are
            -- never resized by us, so these reads are the native template.
            if d.baseH then moneyToastH = d.baseH end
            if d.baseW then moneyToastW = d.baseW end
            if icon and icon.GetHeight then
                local ih = icon:GetHeight()
                if ih and ih > 6 then moneyIconH = ih end
            end
            -- "You received" header 2px down, matching the item toast nudge.
            local hdr = t.Label
            if hdr and hdr.GetPoint and hdr.ClearAllPoints then
                if not d.hdrPt then
                    local p, rel, rp, x, y = hdr:GetPoint(1)
                    if p then d.hdrPt = { p, rel, rp, x or 0, y or 0 } end
                end
                if d.hdrPt then
                    hdr:ClearAllPoints()
                    hdr:SetPoint(d.hdrPt[1], d.hdrPt[2], d.hdrPt[3], d.hdrPt[4], d.hdrPt[5] - 2)
                end
            end
            if icon and icon.GetLeft and t.GetLeft then
                local es = (t.GetEffectiveScale and t:GetEffectiveScale()) or 1
                local il, tl = icon:GetLeft(), t:GetLeft()
                local _, icy = icon:GetCenter()
                local _, tcy = t:GetCenter()
                if il and tl and icy and tcy and es > 0 then
                    moneyIconL = (il - tl) / es
                    moneyIconCy = (icy - tcy) / es
                    local amt = t.Amount
                    if amt and amt.GetLeft and icon.GetRight then
                        local al, ir = amt:GetLeft(), icon:GetRight()
                        local _, acy = amt:GetCenter()
                        if al and ir then moneyTextGap = (al - ir) / es end
                        if acy then moneyTextCy = (acy - icy) / es end
                    end
                end
            end
            -- Refresh the persisted reference with whatever was readable.
            if moneyToastH then
                if not EllesmereUIDB then EllesmereUIDB = {} end
                EllesmereUIDB.lootToastMoneyRef = {
                    h = moneyToastH, w = moneyToastW, iconH = moneyIconH,
                    iconL = moneyIconL, iconCy = moneyIconCy,
                    textGap = moneyTextGap, textCy = moneyTextCy,
                }
            end
        else
            if d.baseH and t.SetHeight then
                local target = moneyToastH or (d.baseH - 16)
                if target < d.baseH then t:SetHeight(target) end
            end
            if d.baseW and moneyToastW and t.SetWidth and moneyToastW ~= d.baseW then
                t:SetWidth(moneyToastW)
            end
            if icon and icon.GetSize and icon.SetSize then
                if not d.iconBaseW then
                    local iw, ih = icon:GetSize()
                    if iw and ih and iw > 6 and ih > 6 then d.iconBaseW, d.iconBaseH = iw, ih end
                end
                if d.iconBaseW then
                    local target = moneyIconH or (d.iconBaseH - 6)
                    if target < d.iconBaseH then icon:SetSize(target, target) end
                end
            end
            -- Mirror the money toast's internal layout: icon inset from the left
            -- edge, vertically centered like the coin; name text at the
            -- coin-to-amount gap, right edge kept so long names truncate
            -- instead of overflowing. Re-asserted per pass. On top of the
            -- mirrored offsets: icon 10px further left, item name 21px total (10 on the icon anchor, 11 off the gap), header 7px left.
            if moneyIconL and icon and icon.ClearAllPoints then
                icon:ClearAllPoints()
                icon:SetPoint("LEFT", t, "LEFT", moneyIconL - 10, moneyIconCy or 0)
                local nameFS = t.ItemName or (t.lootItem and t.lootItem.ItemName)
                if nameFS and nameFS.ClearAllPoints and moneyTextGap then
                    nameFS:ClearAllPoints()
                    nameFS:SetPoint("LEFT", icon, "RIGHT", moneyTextGap - 11, moneyTextCy or 0)
                    nameFS:SetPoint("RIGHT", t, "RIGHT", -8, moneyTextCy or 0)
                    if nameFS.SetJustifyH then nameFS:SetJustifyH("LEFT") end
                end
                local hdr = t.Label
                if hdr and hdr ~= nameFS and hdr.GetPoint and hdr.ClearAllPoints then
                    -- Base anchor captured once pre-shift, re-applied with the
                    -- offsets each pass (net 7px left, 2px down); if the header
                    -- rides the icon we moved left, compensate so the net horizontal shift stays put.
                    if not d.hdrPt then
                        local p, rel, rp, x, y = hdr:GetPoint(1)
                        if p then d.hdrPt = { p, rel, rp, x or 0, y or 0 } end
                    end
                    if d.hdrPt then
                        local dx = (d.hdrPt[2] == icon) and 3 or -7
                        hdr:ClearAllPoints()
                        hdr:SetPoint(d.hdrPt[1], d.hdrPt[2], d.hdrPt[3], d.hdrPt[4] + dx, d.hdrPt[5] - 2)
                    end
                end
            end
        end

        -- Rarity strip (item toasts default ON, money toasts opt-in). Icon's
        -- quality ring went out with the rest of the art, so this carries
        -- rarity in the tabs' accent-bar language. Color comes from the item
        -- NAME's own text color, already quality-set by Blizzard: no item
        -- lookup, correct for currency and gear alike. Re-read every pass since pooled frames are reused for other drops.
        if not d.selBar then
            -- The bar lives on its OWN host frame, not the toast: the shell's
            -- atlas border is a CHILD FRAME (frameLevel +6) and child frames
            -- draw over every parent texture regardless of layer, so a bar painted on the toast itself sits under the border art.
            local host = CreateFrame("Frame", nil, t)
            host:SetAllPoints(t)
            d.selBarHost = host
            local bar = host:CreateTexture(nil, "OVERLAY", nil, 7)
            -- Tab-underline pixel treatment: unsnapped, so a thin strip cannot
            -- round away at fractional scales.
            local PP = EllesmereUI and EllesmereUI.PanelPP
            if PP and PP.DisablePixelSnap then PP.DisablePixelSnap(bar) end
            d.selBar = bar
        end
        -- Above the atlas border, re-asserted per pass (the border frame's
        -- level derives from the toast's, which pooling can reflow).
        if d.selBarHost then
            local abf = d.atlasBorderFrame
            local lvl = (abf and abf.GetFrameLevel and abf:GetFrameLevel())
                or (t:GetFrameLevel() + 6)
            d.selBarHost:SetFrameLevel(lvl + 1)
        end
        -- Full-height rail flush with the frame's left edge. Alignment is
        -- solved on the PHYSICAL pixel grid: frame edges sit at fractional
        -- physical coordinates, so the strip's left/top/bottom snap to the
        -- nearest pixel column/row (position-class epsilon round, ties up --
        -- the house convention) and its width is a whole number of physical
        -- pixels. An unsnapped quad N physical px thick at a whole-pixel
        -- position rasterizes exactly N columns, flush with the shell's
        -- snapped fill: no seam, no drift. Re-solved every pass so scale
        -- changes and frame moves re-align it; falls back to plain corner anchors when the frame has no rect yet.
        local PPx = EllesmereUI and EllesmereUI.PP
        local esc = t.GetEffectiveScale and t:GetEffectiveScale()
        local onePx = (PPx and PPx.perfect and esc and esc > 0) and (PPx.perfect / esc) or 1
        local function snap(v) return math.floor(v / onePx + 0.5 + 0.001) * onePx end
        local l, b, w, h = t:GetRect()
        d.selBar:ClearAllPoints()
        if l and b and h and h > 0 then
            local dx = snap(l) - l
            d.selBar:SetPoint("TOPLEFT", t, "TOPLEFT", dx, snap(b + h) - (b + h))
            d.selBar:SetPoint("BOTTOMLEFT", t, "BOTTOMLEFT", dx, snap(b) - b)
        else
            d.selBar:SetPoint("TOPLEFT", t, "TOPLEFT", 0, 0)
            d.selBar:SetPoint("BOTTOMLEFT", t, "BOTTOMLEFT", 0, 0)
        end
        -- One physical pixel narrower than the ~3px base.
        d.selBar:SetWidth(math.max(1, math.floor(3 / onePx + 0.5) - 1) * onePx)
        -- Item toasts default ON (lootToastQualityStrip ~= false); money toasts
        -- are opt-in (lootToastQualityStripMoney) since gold has no rarity to signal, and their strip takes the header's gold color.
        local stripOn
        if isMoney then
            stripOn = EllesmereUIDB and EllesmereUIDB.lootToastQualityStripMoney == true
        else
            stripOn = not EllesmereUIDB or EllesmereUIDB.lootToastQualityStrip ~= false
        end
        d.selBar:SetShown(stripOn)
        if stripOn then
            local qr, qg, qb = label:GetTextColor()
            if qr then d.selBar:SetColorTexture(qr, qg, qb, 0.9) end
        end
        -- Count is deliberately absent: stack numbers sit over the icon in an
        -- outlined number font and stay Blizzard's, same as the loot rows.
        for _, k in ipairs({ "Label", "Title", "ItemName", "SubTitle" }) do
            local fs = t[k]
            if fs and fs.GetFont then WSkin.Font(fs) end   -- quality colors kept
        end
        WSkin.Register(t, keep)
        return true
    end

    -- Toast frames already found, so repeat passes never re-walk UIParent.
    -- Weak-keyed: a pool frame that goes away takes its entry with it.
    local known = setmetatable({}, { __mode = "k" })

    -- deep = also walk UIParent's children looking for NEW toast frames. Only
    -- the first pass of a burst needs that; the follow-ups re-skin what is
    -- already known, which is a handful of frames.
    local function SweepAlerts(deep)
        for f in pairs(known) do SkinToast(f) end
        local af = _G.AlertFrame
        if not af then return end
        local subs = af.alertFrameSubSystems
        if type(subs) == "table" then
            for _, sys in ipairs(subs) do
                local pool = sys and sys.alertFramePool
                if pool and pool.EnumerateActive then
                    local ok, iter = pcall(pool.EnumerateActive, pool)
                    if ok and iter then
                        for frame in iter do SkinToast(frame) end
                    end
                end
            end
        end
        if af.GetChildren then
            local children = { af:GetChildren() }
            for i = 1, #children do SkinToast(children[i]) end
        end
        -- The loot toast is parented to UIPARENT, not AlertFrame, and is
        -- anonymous (FULLSCREEN_DIALOG, carrying .Background+.ItemName), so
        -- walking AlertFrame alone never reaches it. Scan UIParent's children
        -- too, narrowed to SHOWN FULLSCREEN_DIALOG frames to stay cheap.
        --
        -- The PROVENANCE GATE IS LOAD-BEARING here more than anywhere else:
        -- this is the only sweep walking UIParent rather than inside a
        -- Blizzard window, and SkinToast's shape test is broad (any
        -- .ItemName/.Label/.Title that can GetText). Plenty of ADDON dialogs
        -- sit at FULLSCREEN_DIALOG with a .Title, ours included; without the gate this sweep silently blanks other addons' windows.
        --
        -- SECRECY: this walks EVERY UIParent child, so it meets frames this
        -- addon did not create, and a widget fed secret data hands back SECRET
        -- values from ordinary getters (comparing one throws in addon code).
        -- Nothing secret-aspected is ever a loot toast, so secret == skip.
        -- Both reads resolve into locals BEFORE any comparison -- a getter
        -- called mid-`and`-chain throws on the spot instead of skipping.
        local up = _G.UIParent
        if deep and up and up.GetChildren then
            local isSecret = issecretvalue
            local children = { up:GetChildren() }
            for i = 1, #children do
                local ch = children[i]
                if ch and ch.GetFrameStrata and ch.IsForbidden and not ch:IsForbidden() then
                    local strata, shown = ch:GetFrameStrata(), ch:IsShown()
                    if not (isSecret and (isSecret(strata) or isSecret(shown)))
                       and shown and strata == "FULLSCREEN_DIALOG"
                       and not WSkin.IsForeignFrame(ch, up) then
                        if SkinToast(ch) then known[ch] = true end
                    end
                end
            end
        end
    end

    -- Options entry point: re-sweep so a strip toggle lands on a toast that is
    -- already on screen (the next one would pick it up regardless).
    EllesmereUI._LootToast_Refresh = function() SweepAlerts(true) end

    local d = GetFFD(_G.AlertFrame or UIParent)
    if d.toastEvt then return end
    local ev = CreateFrame("Frame")
    d.toastEvt = ev
    -- Toasts are handed out by the pool, set up, then animated in over a few
    -- tenths of a second, and the setup can land AFTER the first pass. Sweep
    -- immediately and again across the animation window; only the FIRST pass walks UIParent, the rest re-skin the frames it found.
    local function Shallow() SweepAlerts(false) end
    local sweep = WSkin.Debounce(function()
        SweepAlerts(true)
        if C_Timer then
            C_Timer.After(0.05, Shallow)
            C_Timer.After(0.2, Shallow)
            C_Timer.After(0.5, Shallow)
        end
    end)
    ev:SetScript("OnEvent", sweep)
    -- Toast events ONLY. Never CURRENCY_DISPLAY_UPDATE: it fires on every
    -- currency change (quest turn-ins, vendoring, combat drops), far more often
    -- than a toast appears, and each fire costs a full sweep for nothing.
    -- TRANSMOG_COSMETIC_COLLECTION_SOURCE_ADDED is the "You Collected"
    -- appearance toast (NewCosmeticAlertFrameSystem). SweepAlerts already
    -- REACHED that frame -- it walks every alertFrameSubSystems pool, and the
    -- toast passes SkinToast's shape test via .Label/.Icon -- but nothing woke
    -- the sweep while one was on screen, so it lived and died stock.
    -- TRANSMOG_COLLECTION_SOURCE_ADDED is the same toast on the Trading Post
    -- path (AlertFrames.lua routes both into the same system).
    for _, e in ipairs({ "SHOW_LOOT_TOAST", "SHOW_LOOT_TOAST_UPGRADE",
                         "SHOW_PVP_FACTION_LOOT_TOAST", "SHOW_RATED_PVP_REWARD_TOAST",
                         "LOOT_ITEM_ROLL_WON",
                         "TRANSMOG_COSMETIC_COLLECTION_SOURCE_ADDED",
                         "TRANSMOG_COLLECTION_SOURCE_ADDED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
    SweepAlerts(true)
end

WSkin.RegisterWindow({
    key = "loottoast",
    apply = Skin_LootToast,
})
end


-------------------------------------------------------------------------------
--  Social UI (12.1 friends window: SocialUIFrame, Blizzard_SocialUI).
--
--  CHROME ONLY: window shell, border, title, close button, Battle.net bar, and
--  the per-tab controls (search box, filter dropdown, action button).
--  Deliberately 100% stock: side tab icons (LargeSideTabButtonTemplate), every
--  ScrollBox/ScrollBar/pooled list row (friend/ally/quick-join content is owned by the friends module).
--
--  ENUMERATIVE on purpose: NO CommonChrome/ControlsIn/ButtonsIn/ScrollBarsIn
--  sweeps anywhere, since those walk the frame tree into list content and the tab strip. Every target below is named.
--
--  Helpers and constants hang off SP, inside this pack's own do...end block
--  (see the note at the top of the file on the 200-local limit).
-------------------------------------------------------------------------------
do
local SP = {
    CONTENT_KEYS = {
        "FriendsList", "RecentAlliesList", "QuickJoinFrame",
        "FriendRequestsList", "RecruitAFriendFrame", "RaidFrame",
    },

    -- Blizzard ships the search box at 20 tall, filter dropdown at 30; both meet in the middle so the filter row reads as one strip.
    CONTROL_H  = 26,
    FILTER_PAD = 10,   -- left inset of the (now left-aligned) Filter label

    -- Hamburger is a 34px plate around a native-size atlas: shrink the plate, shrink the glyph less.
    MENU_BTN_SZ  = 28,
    MENU_ICON_SZ = 16,
    MENU_ICON_Y  = -1,   -- glyph nudged down inside the plate

    -- Filter dropdown's right edge, measured from the window's right edge:
    -- content frames sit at BOTTOMRIGHT -2, FilterBar spans them, dropdown
    -- inset RIGHT -10 inside that. WSkin.Dropdown/Button fill SetAllPoints, so frame edges are the visual edges.
    DD_RIGHT_INSET = 12,

    -- SearchBar sits at LEFT+15 inside FilterBar, and FilterBar shares a left
    -- edge with the Battle.net bar's ControlsContainer, so reusing 15 lines the
    -- status dropdown up with the search box exactly (Blizzard ships it at 65).
    STATUS_X = 15,
}

-- Geometry only, split out from the skin pass: these frames inherit
-- UserScaledFrameTemplate, and TextSizeManager re-derives their size from the
-- baseHeight KeyValue whenever text scale changes, so a one-shot resize silently reverts. Re-applied every pass.
function SP.LayoutFilterBar(cf)
    local fb = cf.FilterBar
    if not fb then return end

    local sb = fb.SearchBar
    if sb and sb.SetHeight then sb:SetHeight(SP.CONTROL_H) end

    local dd = fb.SearchFilterDropdown
    if dd then
        if dd.SetHeight then dd:SetHeight(SP.CONTROL_H) end
        -- Blizzard anchors the label to TOP with no left point, which centers
        -- it regardless of its LEFT justification. Re-anchor to the left edge.
        local txt = dd.Text
        if txt then
            txt:ClearAllPoints()
            txt:SetPoint("LEFT", dd, "LEFT", SP.FILTER_PAD, 0)
            txt:SetJustifyH("LEFT")
        end
    end
end

-- Right-align the Battle.net bar's hamburger with the filter dropdown below
-- it. They live in different containers (content frame stretches to the
-- window's right edge, ControlsContainer only spans the 413px Battle.net bar),
-- so there is no shared inset: offset must be measured and RE-measured whenever the window width changes (side windows resize it).
function SP.AlignMenuButton(f)
    local cc = f.BattleNetBar and f.BattleNetBar.ControlsContainer
    local btn = cc and cc.BattleNetMenuButton
    if not btn then return end

    local ccRight, winRight = cc:GetRight(), f:GetRight()
    if not ccRight or not winRight then return end
    if issecretvalue(ccRight) or issecretvalue(winRight) then return end

    -- Keep the vertical anchor on ControlsContainer (stays centered in the
    -- bar), shift only x: anchoring straight to the window would drag the button to the window's vertical center.
    local dx = (winRight - SP.DD_RIGHT_INSET) - ccRight
    btn:ClearAllPoints()
    btn:SetPoint("RIGHT", cc, "RIGHT", dx, 0)
end

function SP.SkinContentFrame(cf)
    if not cf or cf:IsForbidden() then return end

    -- Geometry runs every pass; the skinning below only once.
    SP.LayoutFilterBar(cf)

    local d = GetFFD(cf)
    if d.socialContent then return end
    d.socialContent = true

    -- Blizzard's perks-divider art brackets the list area: flatten it so the shell reads clean (content frame's OWN regions, not the ScrollBox's).
    if cf.TopDivider then cf.TopDivider:SetAlpha(0) end
    if cf.BottomDivider then cf.BottomDivider:SetAlpha(0) end

    local fb = cf.FilterBar
    if fb then
        if fb.SearchBar then WSkin.EditBox(fb.SearchBar) end
        if fb.SearchFilterDropdown then WSkin.Dropdown(fb.SearchFilterDropdown) end
    end

    if cf.ActionButton then
        WSkin.Button(cf.ActionButton)
        WSkin.WhiteButtonLabel(cf.ActionButton)
    end

    -- cf.ScrollBox / cf.ScrollBar / cf.LoadingSpinner: intentionally stock.
end

function SP.Apply()
    local f = _G.SocialUIFrame
    if not f then return end
    -- The Friends List stock styles (Style page) keep Blizzard's whole Social
    -- window, its frame included; the Window Skins card is blocked meanwhile.
    local fr = EllesmereUI._ModuleNS and EllesmereUI._ModuleNS.EllesmereUIFriends
    if fr and fr.FR_Style and fr.FR_Style() ~= "eui" then return end

    WSkin.Shell("socialui", f)
    WSkin.RemovePortrait(f)
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end

    -- Window-level art.
    if f.TopFade then f.TopFade:SetAlpha(0) end
    if f.BottomFade then f.BottomFade:SetAlpha(0) end
    if f.TopTileStreaks then f.TopTileStreaks:SetAlpha(0) end
    if f.Bg then f.Bg:SetAlpha(0) end

    local title = (f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if title then
        WSkin.Font(title)
        WSkin.White(title)
    end

    local cb = f.CloseButton
        or (f.TitleContainer and f.TitleContainer.CloseButton)
        or (f.GetName and _G[(f:GetName() or "") .. "CloseButton"])
    if cb then WSkin.CloseButton(cb) end

    -- Battle.net bar: flatten the plate art, skin status dropdown and the square menu button (icon KEPT, only thing identifying it).
    local bar = f.BattleNetBar
    if bar then
        if bar.Background then bar.Background:SetAlpha(0) end
        local cc = bar.ControlsContainer
        if cc then
            if cc.BattleNetBackground then cc.BattleNetBackground:SetAlpha(0) end

            local osd = cc.OnlineStatusDropdown
            if osd then
                WSkin.Dropdown(osd)
                -- Blizzard anchors this at LEFT+65. ControlsContainer shares a
                -- left edge with the content frame's FilterBar, so matching SearchBar's own LEFT inset lines the two up exactly.
                osd:ClearAllPoints()
                osd:SetPoint("LEFT", cc, "LEFT", SP.STATUS_X, 0)
            end

            local menuBtn = cc.BattleNetMenuButton
            if menuBtn then
                WSkin.Button(menuBtn, { "Icon" })
                menuBtn:SetSize(SP.MENU_BTN_SZ, SP.MENU_BTN_SZ)
                -- The glyph is useAtlasSize in XML, so it ignores the button
                -- and needs an explicit size to grow inside the smaller plate.
                if menuBtn.Icon then
                    menuBtn.Icon:SetSize(SP.MENU_ICON_SZ, SP.MENU_ICON_SZ)
                    -- Re-seat off the XML's bare CENTER. AdjustPointsOffset (the
                    -- mixin's press feedback) shifts whatever points are current, so it keeps working against this one.
                    menuBtn.Icon:ClearAllPoints()
                    menuBtn.Icon:SetPoint("CENTER", menuBtn, "CENTER", 0, SP.MENU_ICON_Y)
                    -- Strip the atlas's gold tint to match the chrome. One-shot
                    -- is enough: the mixin only nudges the icon's OFFSET on mouse down/up, never its color.
                    menuBtn.Icon:SetDesaturated(true)
                    menuBtn.Icon:SetVertexColor(1, 1, 1)
                end
            end

            local tag = cc.PersonalBattleTagDisplay
            if tag and tag.DisplayText then WSkin.White(tag.DisplayText) end
        end
    end

    local function SkinContentFrames()
        for _, key in ipairs(SP.CONTENT_KEYS) do
            SP.SkinContentFrame(f[key])
        end
        SP.AlignMenuButton(f)
    end
    SkinContentFrames()

    -- Content frames exist only for tabs the client supports, and the set can
    -- change when a social system is toggled server-side, so re-run on show
    -- (SkinContentFrame is idempotent per frame).
    WSkin.HookShow(f, function()
        SkinContentFrames()
        -- First open: window has not laid out yet, GetRight returns nil and alignment no-ops; re-run once it has.
        C_Timer.After(0, function() SP.AlignMenuButton(f) end)
    end)

    -- NO SetWidth/SetSize hooks here. SocialUIFrame is UIPanel-managed and
    -- resizes itself via SetUIPanelAttribute+UpdateUIPanelPositions when a side
    -- window opens; hooking its sizers puts our code inside the panel
    -- manager's own path, tainting it and killing ToggleUIPanel (the Friends
    -- keybind silently dies). Realigning on show is enough -- only a side window moves the right edge, and that reshows the frame anyway.
end

WSkin.RegisterWindow({
    key = "socialui",
    -- Gates the whole pack to clients that ship the Social UI: where the addon
    -- does not exist, IsAddOnLoaded is false and apply never runs.
    addons = { Blizzard_SocialUI = true },
    apply = SP.Apply,
})
end

---------
--  Loot rolls, group invites and the ready check.
--
--  Four small packs sharing one block: lootroll (group loot roll popups:
--  need/greed/DE/pass), loothistory ("Loot Rolls" window, GroupLootHistoryFrame),
--  groupinvite ("You have been invited to a group", both invite dialogs),
--  readycheck (the ready prompt + the initiator's response list).
--
--  Helpers and constants hang off LP, inside this block's do...end (see the
--  note at the top of the file on the 200-local limit).
-------------------------------------------------------------------------------
do
local LP = {
    FLAT = "Interface\\Buttons\\WHITE8X8",

    -- Plate / border art that lives one level down from a frame's own regions,
    -- so the shell's region fade never reaches it.
    ART_KEYS = {
        "NameFrame", "Border", "BorderFrame", "Background", "Bg",
        "Decoration", "Frame", "Backdrop",
    },
    ICON_ART_KEYS = { "IconBorder", "NormalTexture", "Border", "IconQuestTexture" },
    ROW_ART_KEYS  = {
        "NameFrame", "BorderFrame", "HighlightNameFrame", "PushedNameFrame",
        "IconQuestTexture",
    },
    INVITE_BTN_KEYS = { "AcceptButton", "DeclineButton", "AcknowledgeButton" },

    -- Progress fills that are a TEXTURE rather than a StatusBar (the loot
    -- history roll timer is one) cannot go through WSkin.ApplyBarFill, which
    -- drives SetStatusBarColor. Same behaviour, one shared looks callback.
    vertexFills = setmetatable({}, { __mode = "k" }),
}

-- Popup shell: full window treatment minus the title row. Style-aware backdrop
-- (modern_blizz atlas on "eui", flat user color on "modern", swapping live)
-- plus WSkin.AtlasBorder, the same soft-edged frame the Loot Rolls window and
-- loot toasts carry. Only the 25px title bar is skipped (none of these frames
-- has a title). Idempotent: Shell re-runs its region fade every call but builds textures once, so re-calling doubles as repaint catch-up.
function LP.Shell(winKey, frame)
    WSkin.Shell(winKey, frame, { noTopBar = true })
end

-- Alpha a list of named art keys. TEXTURES ONLY, and the type test is
-- load-bearing: several of these names are a Texture on one template and a
-- FRAME on another ("Border" is a NineSlice on portrait windows), and
-- SetAlpha(0) on a frame takes its whole subtree (on the invite dialog that blanks the role icon and the buttons).
function LP.FadeKeys(frame, keys)
    if not frame then return end
    for i = 1, #keys do
        local t = frame[keys[i]]
        if t and t.IsObjectType then
            if t:IsObjectType("Texture") then
                t:SetAlpha(0)
            elseif t.TopEdge or t.TopLeftCorner then
                -- The frame IS a NineSlice (pure border art), so fading it
                -- whole is right. ONLY this shape: WSkin.FadeNineSlice ends by
                -- alpha-ing the frame handed to it, blanking the subtree of anything that merely CONTAINS one.
                WSkin.FadeNineSlice(t)
            end
        end
    end
end

-- Re-font a frame's own FontString regions, leaving their COLOR alone: item
-- names and roll results are quality/state colored by Blizzard, never
-- overwritten. `skip` is a stack COUNT -- an outlined number font drawn over an icon, unreadable in the panel face.
function LP.FontRegions(frame, skip)
    if not frame or not frame.GetRegions then return end
    local regions = { frame:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r ~= skip and r.IsObjectType and r:IsObjectType("FontString") then WSkin.Font(r) end
    end
end

function LP.ApplyVertexFill(tex)
    if not tex or not tex.SetVertexColor then return end
    LP.vertexFills[tex] = true
    local r, g, b, a = WSkin.BarFillColor()
    tex:SetVertexColor(r, g, b, a)
end
WSkin.OnLooksChanged(function()
    local r, g, b, a = WSkin.BarFillColor()
    for tex in pairs(LP.vertexFills) do
        if tex.SetVertexColor then tex:SetVertexColor(r, g, b, a) end
    end
end)

-- Run fn(frame) as soon as a named Blizzard frame exists: immediately if it
-- already does, otherwise on the ADDON_LOADED that creates it. Which dialogs
-- are base UI vs load-on-demand has moved between expansions, so none is assumed present at login.
function LP.WhenFrameExists(name, fn)
    if _G[name] then fn(_G[name]); return end
    local ev = CreateFrame("Frame")
    ev:RegisterEvent("ADDON_LOADED")
    ev:SetScript("OnEvent", function(self)
        local fr = _G[name]
        if fr then
            self:UnregisterAllEvents()
            fn(fr)
        end
    end)
end

-- Any StatusBar -> flat fill in the user's bar-fill color over a near-black trough. Re-asserted every pass since Blizzard re-applies the bar's own art on reuse.
function LP.Bar(bar)
    if not bar or bar:IsForbidden() or not bar.SetStatusBarTexture then return end
    local d = GetFFD(bar)
    bar:SetStatusBarTexture(LP.FLAT)
    local fill = bar.GetStatusBarTexture and bar:GetStatusBarTexture()
    if fill and fill ~= d.fill then
        d.fill = fill
        -- Fade the bar's frame art, never the fill itself: GetRegions() on a
        -- StatusBar includes the fill, so an unguarded FadeRegions blanks it.
        WSkin.FadeRegions(bar, { [fill] = true })
        WSkin.Register(bar, { [fill] = true })
    end
    if not d.bg then
        local bg = SolidTex(bar, "BACKGROUND", 0, 0, 0, 0.55)
        bg:SetAllPoints(bar)
        d.bg = bg
    end
    WSkin.ApplyBarFill(bar)
end

-------------------------------------------------------------------------------
--  Loot roll popups (GroupLootFrame1..N inside GroupLootContainer). The
--  CONTAINER is deliberately UNTOUCHED: a bottom managed column frame whose
--  position belongs to the shared frame placer (EllesmereUI.SetFramePlacer:
--  the Shifter's saved spot, else the Cooldown Manager's, else Blizzard's own
--  column spot); writing its layout flags from here taints the managed-layout
--  pass.
-------------------------------------------------------------------------------
function LP.SkinRollFrame(f)
    if not f or f:IsForbidden() then return end
    LP.Shell("lootroll", f)
    LP.FadeKeys(f, LP.ART_KEYS)

    -- Item icon: squared + a 1px RARITY-colored frame.
    -- Roll BUTTONS (dice/coin/transmog/pass) KEEP Blizzard's glyphs: they are the popup's identity and no house equivalent reads as fast.
    local host = f.IconFrame or f.Item
    local icon = (host and (host.Icon or host.icon)) or f.Icon
    if host then
        LP.FadeKeys(host, LP.ICON_ART_KEYS)
        local nt = host.GetNormalTexture and host:GetNormalTexture()
        if nt and nt.SetAlpha then nt:SetAlpha(0) end
    end
    -- The ONE surface with no ring to read. GroupLootFrame_OnShow does not use
    -- SetItemButtonQuality at all: it picks an ATLAS whose NAME encodes the
    -- quality (GetAtlasDataForLootBorderItemQuality), so there is no vertex
    -- color anywhere to recover. The roll API hands over the quality directly,
    -- which is both cheaper and exact -- and the frame is re-skinned on every
    -- START_LOOT_ROLL and container update, so a pooled frame taking a new
    -- item repaints without needing the SetItemButtonQuality hook.
    --
    -- Bordered only if the crop actually happened: SquareIcon leaves a MASKED
    -- icon native, and a square border round a masked shape is the same
    -- mistake as a square crop.
    if icon and icon.SetTexCoord and WSkin.SquareIcon(icon, nil) then
        local qr, qg, qb = 0, 0, 0
        if f.rollID and type(_G.GetLootRollItemInfo) == "function" then
            local _, _, _, quality = GetLootRollItemInfo(f.rollID)
            if type(quality) == "number" then
                local cr, cg, cb
                if C_Item and C_Item.GetItemQualityColor then
                    cr, cg, cb = C_Item.GetItemQualityColor(quality)
                elseif GetItemQualityColor then
                    cr, cg, cb = GetItemQualityColor(quality)
                end
                -- Same uncommon-and-up rule the other surfaces get from
                -- WSkin.RingQuality, applied to the same chroma test so a
                -- common drop looks identical across all of them.
                if type(cr) == "number"
                   and (math.max(cr, cg, cb) - math.min(cr, cg, cb)) > 0.1 then
                    qr, qg, qb = cr, cg, cb
                end
            end
        end
        WSkin.QualityBorder(host or f, icon, qr, qg, qb)
    end

    -- Blizzard parks both timers one frame level BELOW the window so the
    -- window's own art frames them (GroupLootFrame_OnLoad; BonusRollFrame_OnLoad
    -- for the Bonus Roll's, which lives on PromptFrame). The shell backdrop is
    -- drawn on the window, so under it a bar all but vanishes: each rides one
    -- level above the window instead (the roll buttons' level).
    local level = f:GetFrameLevel() + 1
    local timer = f.Timer or f.Bar or f.StatusBar
    if timer and not timer:IsForbidden() then
        LP.Bar(timer)
        timer:SetFrameLevel(level)
    end
    local prompt = f.PromptFrame
    local ptimer = prompt and prompt.Timer
    if ptimer and not ptimer:IsForbidden() then
        LP.Bar(ptimer)
        ptimer:SetFrameLevel(level)
    end

    -- Name keeps its item-quality color; only the face changes.
    if f.Name then WSkin.Font(f.Name) end
end

function LP.SkinAllRolls()
    local c = _G.GroupLootContainer
    local maxN = (c and c.maxIndex) or 4
    if type(maxN) ~= "number" or maxN < 4 then maxN = 4 end
    for i = 1, maxN do LP.SkinRollFrame(_G["GroupLootFrame" .. i]) end
    if c and type(c.rollFrames) == "table" then
        for _, rf in pairs(c.rollFrames) do LP.SkinRollFrame(rf) end
    end
end

function LP.ApplyLootRoll()
    -- Every hook lands on the NEXT frame, never inside Blizzard's own call:
    -- GroupLootContainer_Update runs as part of the managed-layout pass, and creating textures from inside it puts our code in that stack.
    local resweep = WSkin.Debounce(LP.SkinAllRolls)

    if type(_G.GroupLootContainer_AddFrame) == "function" then
        hooksecurefunc("GroupLootContainer_AddFrame", resweep)
    end
    if type(_G.GroupLootContainer_Update) == "function" then
        hooksecurefunc("GroupLootContainer_Update", resweep)
    end
    -- No script hook on the container itself: it only shows inside
    -- GroupLootContainer_Update (hooked above), and code run from its OnShow
    -- would leave the rest of that update, the managed-layout pass, under our taint.

    -- Fallback for clients where those two globals have gone: the roll event itself is what puts a frame on screen.
    local ev = CreateFrame("Frame")
    ev:RegisterEvent("START_LOOT_ROLL")
    ev:SetScript("OnEvent", resweep)

    LP.SkinAllRolls()
end

WSkin.RegisterWindow({
    key = "lootroll",
    apply = LP.ApplyLootRoll,
})

-------------------------------------------------------------------------------
--  The Loot Rolls window (GroupLootHistoryFrame).
--
--  DOCTRINE: a skin must NEVER be the thing that triggers a ScrollBox-backed
--  frame's FIRST layout. Touching this window's geometry from the load pass
--  poisons ScrollBox.updateLock, which ScrollBoxListMixin:Update reads on its
--  first line; from then on every Update taints its own execution and
--  re-stamps the lock, invisible to taintLog since no global is involved. The
--  cure is purely TIMING: arm the frame's first OnShow and skin there.
--
--  ENUMERATIVE on purpose: no CommonChrome, no ControlsIn/ButtonsIn sweeps -- those walk the whole tree, and the tree here is pooled loot rows.
-------------------------------------------------------------------------------
function LP.SkinHistoryRow(row)
    if not row or row:IsForbidden() then return end

    -- Housing drops ride a wooden frame overlay that fights the flat look.
    -- Checked every pass (pooled rows change item between shows), read via WSkin.TexHay, which is secret-value safe.
    local ov = row.IconOverlay
    if ov then
        local hay = WSkin.TexHay(ov)
        ov:SetAlpha((hay and hay:find("housing-item-wood-frame", 1, true)) and 0 or 1)
    end

    local d = GetFFD(row)
    if d.rowSkinned then return end
    d.rowSkinned = true

    if row.BackgroundArtFrame then
        WSkin.FadeRegions(row.BackgroundArtFrame)
        WSkin.Register(row.BackgroundArtFrame, true)
        local wash = SolidTex(row.BackgroundArtFrame, "BACKGROUND", 1, 1, 1, 0.02)
        wash:SetAllPoints(row.BackgroundArtFrame)
        GetFFD(row.BackgroundArtFrame).bg = wash
    end
    LP.FadeKeys(row, LP.ROW_ART_KEYS)

    local item = row.Item
    if item then
        LP.FadeKeys(item, LP.ICON_ART_KEYS)
        local nt = item.GetNormalTexture and item:GetNormalTexture()
        if nt and nt.SetAlpha then nt:SetAlpha(0) end
        local icon = item.icon or item.Icon
        if icon and icon.SetTexCoord then WSkin.SquareIcon(icon, item) end
    end

    -- Item name and winner line: face only. Colors stay Blizzard's (quality on the name, green on "won/passed" state).
    local countFS = row.Count or row.count or (item and (item.Count or item.count))
    LP.FontRegions(row, countFS)
    for _, k in ipairs({ "Text", "PlayerName", "Name", "RollResult" }) do
        local fs = row[k]
        if fs and fs ~= countFS and fs.GetFont then WSkin.Font(fs) end
    end
end

function LP.SkinHistoryRows(f)
    local box = f.ScrollBox
    if not (box and box.ForEachFrame) then return end
    pcall(box.ForEachFrame, box, LP.SkinHistoryRow)
    local bd = GetFFD(box)
    if box.Update and not bd.rowHook then
        bd.rowHook = true
        hooksecurefunc(box, "Update", function(b)
            pcall(b.ForEachFrame, b, LP.SkinHistoryRow)
        end)
    end
end

-- The resize grab at the window's foot: Blizzard's gold grip flattened to three house rules.
function LP.SkinResizeGrip(rb)
    if not rb or rb:IsForbidden() then return end
    local d = GetFFD(rb)
    if d.grip then return end
    d.grip = true
    -- Blizzard parks the grip BELOW the window's bottom edge where it is
    -- effectively invisible, so pull it 2px inside the frame. It is a wide flat
    -- grab-BAR (32x12): keep it horizontally CENTERED like the native design,
    -- grow it proportionally so the aspect ratio holds. Guarded one-time, so repeat skin passes cannot re-shift it.
    local host = rb:GetParent()
    if host then
        rb:ClearAllPoints()
        rb:SetPoint("BOTTOM", host, "BOTTOM", 0, 2)
    end
    local w0, h0 = rb:GetSize()
    if w0 and w0 > 0 and h0 and h0 > 0 then
        rb:SetSize(w0 + 8, h0 * ((w0 + 8) / w0))
    end
    for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture" }) do
        local fn = rb[g]
        local t = fn and fn(rb)
        if t and t.SetAlpha then t:SetAlpha(0) end
    end
    WSkin.FadeRegions(rb)
    -- Grip glyph scaled with the bigger button (18/15/12, not 10/7/4). NOT an
    -- atlas: three hand-drawn WHITE8X8 lines, hover brightening the glyph
    -- (0.3->0.8) rather than washing the button with a highlight block.
    -- PIXEL-PERFECT: each line is EXACTLY one physical pixel thick with pixel
    -- snapping OFF (an unsnapped quad N physical px thick rasterizes exactly N
    -- rows at ANY fractional position, so lines never blur or vanish as the
    -- window moves), spacing ENTIRELY in physical pixels (1px lines, 3px gap,
    -- 4px pitch) so the glyph renders identically at every UI scale.
    local lines = {}
    local PPx = EllesmereUI and EllesmereUI.PP
    local esc = rb.GetEffectiveScale and rb:GetEffectiveScale()
    local onePx = (PPx and PPx.perfect and esc and esc > 0) and (PPx.perfect / esc) or 1
    local pitch = onePx * 4
    local w = 18
    for i = 1, 3 do
        local line = SolidTex(rb, "OVERLAY", 1, 1, 1, 1)
        if PPx and PPx.DisablePixelSnap then PPx.DisablePixelSnap(line) end
        line:SetAlpha(0.3)
        line:SetSize(w, onePx)
        line:SetPoint("CENTER", rb, "CENTER", 0, pitch * (2 - i))
        lines[i] = line
        w = w - 3
    end
    rb:HookScript("OnEnter", function()
        for i = 1, #lines do lines[i]:SetAlpha(0.8) end
    end)
    rb:HookScript("OnLeave", function()
        for i = 1, #lines do lines[i]:SetAlpha(0.3) end
    end)
end

function LP.ApplyHistory()
    local f = _G.GroupLootHistoryFrame
    if not f or f:IsForbidden() then return end

    WSkin.Shell("loothistory", f)

    local d = GetFFD(f)
    if d.histSkinned then
        LP.SkinHistoryRows(f)
        return
    end
    d.histSkinned = true

    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    LP.FadeKeys(f, { "Bg", "Background", "Border" })
    WSkin.FadeKeyedArt(f)

    local close = f.ClosePanelButton or f.CloseButton
        or (f.TitleContainer and f.TitleContainer.CloseButton)
    if close then WSkin.CloseButton(close) end

    local title = (f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if title then
        WSkin.Font(title)
        WSkin.White(title)
        -- Centered on the shell's top bar, not the frame: portrait template anchors the title relative to art just removed.
        if d.topBar and title.ClearAllPoints then
            title:ClearAllPoints()
            title:SetPoint("CENTER", d.topBar, "CENTER", 0, 0)
            if title.SetJustifyH then title:SetJustifyH("CENTER") end
        end
    end

    if f.EncounterDropdown then WSkin.Dropdown(f.EncounterDropdown) end

    -- Roll timer. Its Fill is a TEXTURE, not a status bar, so it needs the vertex-color path and has to survive the frame's own region fade.
    local timer = f.Timer
    if timer then
        local td = GetFFD(timer)
        local fill = timer.Fill
        local keep = fill and { [fill] = true } or nil
        WSkin.FadeRegions(timer, keep)
        WSkin.Register(timer, keep)
        -- No backdrop, no border: just the colored fill over the window. Bar
        -- rides the encounter dropdown's WIDTH (left/right edges pinned to it)
        -- with template height and vertical gap taken from the live layout (runs on first OnShow, so the frame is laid out).
        if not td.skinned then
            td.skinned = true
            local dd = f.EncounterDropdown
            if dd and dd.GetBottom and timer.GetTop then
                local gap = 6
                local ddBottom, tTop = dd:GetBottom(), timer:GetTop()
                if ddBottom and tTop then gap = ddBottom - tTop end
                local h = timer:GetHeight()
                -- 2px overhang each side: the FILL is left-anchored 2px inside
                -- the frame with a matching right-side track inset, so the
                -- frame overhangs the dropdown by exactly that inset and the fill lands flush with its edges.
                timer:ClearAllPoints()
                timer:SetPoint("TOPLEFT", dd, "BOTTOMLEFT", -2, -gap)
                timer:SetPoint("TOPRIGHT", dd, "BOTTOMRIGHT", 2, -gap)
                if h and h > 0 then timer:SetHeight(h) end
            end
        end
        if fill then
            td.fill = fill
            fill:SetTexture(LP.FLAT)
            LP.ApplyVertexFill(fill)
        end
    end

    -- WowTrimScrollBar, not MinimalScrollBar: trough and arrow caps live on
    -- child frames WSkin.ScrollBar never reaches, so the engine's deep-fading variant is the right primitive.
    local sb = f.ScrollBar
    if sb then
        if ns.ASkin and ns.ASkin.ScrollBar then ns.ASkin.ScrollBar(sb) else WSkin.ScrollBar(sb) end
    end

    LP.SkinResizeGrip(f.ResizeButton)
    LP.SkinHistoryRows(f)
end

WSkin.RegisterWindow({
    key = "loothistory",
    apply = function()
        LP.WhenFrameExists("GroupLootHistoryFrame", function(f)
            WSkin.HookShow(f, LP.ApplyHistory)
            -- Should never be up at login, but if it is, skinning now is the
            -- same post-hoc moment the OnShow path gives.
            if f:IsShown() then LP.ApplyHistory() end
        end)
    end,
})

-- Blizzard's button label is auto-sized: the box is exactly the string width,
-- so it carries no slack. At a fractional effective scale the stored width can
-- land a float hair UNDER the string it holds (Accept 46.499996 for a 46.5px
-- string, Decline a clean 48.0) and WoW breaks the last glyph onto a second
-- line. Which strings land on an unlucky value follows the typeface, not the
-- word length, so the global font swap decides who is hit. Pinning the label to
-- the button gives it 118px instead of 47: centered text looks identical and
-- can no longer wrap. One-shot per label.
function LP.PinButtonLabel(b)
    if not b or (b.IsForbidden and b:IsForbidden()) then return end
    local fs = b.Text or (b.GetFontString and b:GetFontString())
    if not fs then return end
    local d = GetFFD(fs)
    if d.labelPinned then return end
    d.labelPinned = true
    fs:ClearAllPoints()
    fs:SetPoint("LEFT", b, "LEFT", 2, 0)
    fs:SetPoint("RIGHT", b, "RIGHT", -2, 0)
    if fs.SetWordWrap then fs:SetWordWrap(false) end
end

-------------------------------------------------------------------------------
--  Group invite popups. Two frames, one setting, because they are one thing to
--  the player: LFGListInviteDialog (premade-group leader accepted your
--  application: group title, activity, your role, Accept/Decline) and
--  LFGInvitePopup (invited to a group finder party, with role checks).
--
--  EUI_BlizzardSkin_Dialogs.lua also skins LFGListInviteDialog, gated on
--  EllesmereUIDB.reskinQueuePopup (a plain truthiness test, unlike the Queue
--  Popup's `~= false`, so it only runs for users who toggled the option ON).
--  When it does, it lays a flat BACKGROUND texture at sublevel 0 over this
--  shell's backdrop (-8/-7/-6). WSkin.Shell's region fade clears it: this
--  OnShow hook installs later so it runs second, and the older skin is one-shot.
-------------------------------------------------------------------------------
function LP.SkinInvite(fr, roleChecks)
    if not fr or fr:IsForbidden() then return end
    local d = GetFFD(fr)

    -- The role glyph ("Your Role: Damage") is a REGION OF THE DIALOG, in the
    -- same region list as the border art the shell blanket-fades, so without
    -- this it disappears with the frame. Found by INSPECTING each texture, not
    -- by key name: the holding key has moved between templates (RoleIcon/Icon/
    -- an anonymous region) and a wrong guess fails silently. Survivors are
    -- parked on two of WSkin's PROTECT_KEYS slots (caret/arrow, unused here),
    -- the engine's supported "keep this texture" list, honored by both Shell's initial fade and every later Restrip pass.
    if not d.caret then
        d.caret = fr.RoleIcon or fr.Icon or fr.PortraitTexture
        if fr.GetRegions then
            local regions = { fr:GetRegions() }
            for i = 1, #regions do
                local r = regions[i]
                if r and r ~= d.caret and r.IsObjectType and r:IsObjectType("Texture") then
                    local hay = WSkin.TexHay(r)
                    if hay and (WSkin.TexIsIcon(hay)
                        or hay:find("role", 1, true) or hay:find("icon", 1, true)) then
                        if not d.caret then d.caret = r
                        elseif not d.arrow then d.arrow = r end
                    end
                end
            end
        end
    end

    LP.Shell("groupinvite", fr)

    if fr.NineSlice then WSkin.FadeNineSlice(fr.NineSlice) end
    LP.FadeKeys(fr, { "Bg", "BG", "Background", "Border" })
    WSkin.FadeKeyedArt(fr)

    for _, k in ipairs(LP.INVITE_BTN_KEYS) do
        local b = fr[k]
        if b then
            WSkin.Button(b)
            WSkin.StateButtonLabel(b)
            LP.PinButtonLabel(b)
        end
    end
    -- Templates naming their buttons globally rather than off the frame (LFGInvitePopupAcceptButton / ...DeclineButton).
    local n = fr.GetName and fr:GetName()
    if n then
        for _, k in ipairs(LP.INVITE_BTN_KEYS) do
            local b = _G[n .. k]
            if b then
                WSkin.Button(b)
                WSkin.StateButtonLabel(b)
                LP.PinButtonLabel(b)
            end
        end
    end
    -- Any 3-slice the two lists missed. Depth-capped and foreign-frame gated by the primitive itself.
    WSkin.ButtonsIn(fr)

    if roleChecks then
        for _, role in ipairs({ "Tank", "Healer", "DPS" }) do
            local rb = _G["LFGInvitePopupRoleButton" .. role] or fr[role .. "Button"]
            local cb = rb and (rb.checkButton or rb.CheckButton)
            if cb then WSkin.Checkbox(cb, { borderInset = 4 }) end
        end
    end

    -- The group's title and the inviter's name are other players' writing: a font
    -- family, set before the region walk (which keeps a string's family).
    if fr.GroupName then WSkin.FontFamily(fr.GroupName) end
    if n and _G[n .. "Text"] then WSkin.FontFamily(_G[n .. "Text"]) end
    LP.FontRegions(fr)
end

WSkin.RegisterWindow({
    key = "groupinvite",
    apply = function()
        local function Wire(name, roleChecks)
            LP.WhenFrameExists(name, function(fr)
                local function apply() LP.SkinInvite(fr, roleChecks) end
                WSkin.HookShow(fr, apply)
                if fr:IsShown() then apply() end
            end)
        end
        Wire("LFGListInviteDialog", false)
        Wire("LFGInvitePopup", true)
    end,
})

-------------------------------------------------------------------------------
--  Ready check. Two frames, one setting -- and the names are actively
--  misleading, so read Blizzard_FrameXML/Mainline/ReadyCheck.xml before
--  touching this. ReadyCheckListenerFrame is NOT a listener and NOT a response
--  list: it is a CHILD of ReadyCheckFrame, setAllPoints to it, and it owns
--  every visible piece of the popup -- Bg, NineSlice, TitleContainer,
--  PortraitContainer, ReadyCheckFrameText, and both Yes/No buttons.
--  ReadyCheckFrame itself is an empty 323x100 container with no art at all.
--
--  ShowReadyCheck() then does this:
--
--      if UnitIsUnit("player", initiator) then ReadyCheckListenerFrame:Hide()
--      else                                    ReadyCheckListenerFrame:Show()
--
--  So the person who STARTED the check is shown the bare outer frame and
--  nothing else. Anything drawn on ReadyCheckFrame is a block only they see.
--  The shell therefore belongs on the listener, never on the outer frame.
--
--  The portrait is ReadyCheckPortrait, inside the listener's PortraitContainer
--  -- one level down from the listener's own regions, so the shell's blanket
--  region fade never reaches it and it needs no protection slot.
--
--  Both frames are skinned from their own OnShow, never from the login pass:
--  a skin must never be what triggers a frame's first layout.
-------------------------------------------------------------------------------
LP.RC_PAD      = 24   -- side padding kept clear of the message
LP.RC_MAX_GROW = 2    -- hard ceiling: never wider than twice Blizzard's own width
LP.RC_TEXT_Y   = -30  -- message top offset (Blizzard's -37; see FitReadyCheck)
LP.RC_BTN_GAP  = 12   -- gap between Ready and Not Ready
LP.RC_BTN_Y    = 16   -- button row off the panel bottom (Blizzard's own value)

-- Capture a region's offset from the frame's TOP anchor (center-x delta, top
-- delta, half width) so it can be re-anchored later without guessing Blizzard's
-- own points. The half width is what lets a GROUP of regions be re-centered
-- from stored numbers alone, with no second measuring pass.
-- Returns nil while the layout has no usable geometry yet -- the caller then
-- skips this pass and captures on the next show, rather than freezing garbage.
function LP.CaptureTopOffset(region, fr)
    local rl, rr, rt = region:GetLeft(), region:GetRight(), region:GetTop()
    local fl, fRight, ft = fr:GetLeft(), fr:GetRight(), fr:GetTop()
    if not (rl and rr and rt and fl and fRight and ft) then return nil end
    for _, v in ipairs({ rl, rr, rt, fl, fRight, ft }) do
        if issecretvalue(v) then return nil end
    end
    return ((rl + rr) / 2) - ((fl + fRight) / 2), rt - ft, (rr - rl) / 2
end

-- Geometry pass, run on every show and whenever the portrait is toggled.
--
--  1. WIDTH. Blizzard sizes this popup for a bare name, so on most realms
--     "<name>-<realm> has initiated a ready check." wraps mid-sentence. The
--     message is measured and the frame grown to fit it on one line -- always
--     recomputed from the ORIGINAL width, so a long name cannot leave the popup
--     permanently wide, and capped so a pathological one wraps instead of
--     running off the screen.
--  2. CENTERING, and ONLY with the portrait hidden. Blizzard insets message,
--     title and buttons to clear the glyph; with it up that inset is load-
--     bearing (centering the message runs it under the artwork), with it hidden
--     it is a lopsided hole on the left. So all three keep Blizzard's own offset
--     while the glyph is up and go dead center once it is gone.
function LP.FitReadyCheck()
    local fr = _G.ReadyCheckFrame
    if not fr or fr:IsForbidden() then return end
    local d = FFD[fr]
    local fs = d and d.rcText
    if not fs then return end

    if not d.rcBaseW then
        local w = fr:GetWidth()
        if not w or w <= 0 or issecretvalue(w) then return end
        d.rcBaseW = w
    end

    if not d.rcTextDX then
        local dx, dy = LP.CaptureTopOffset(fs, fr)
        if not dy then return end
        d.rcTextDX, d.rcTextDY = dx, dy
    end
    -- Own guard, not folded into the one above: a title whose geometry is not
    -- ready yet would otherwise never be captured once the message succeeded.
    -- A true offset of 0 still guards correctly -- 0 is truthy in Lua.
    if d.rcTitle and not d.rcTitleDX then
        d.rcTitleDX, d.rcTitleDY = LP.CaptureTopOffset(d.rcTitle, fr)
    end
    local need = fs.GetStringWidth and fs:GetStringWidth()
    if not need or issecretvalue(need) then return end

    -- EVERYTHING is centered, because the portrait is gone (SkinReadyCheckList
    -- removes it). Blizzard insets the title, message and button row to the
    -- right to clear a glyph that is no longer drawn, and left alone that reads
    -- as a lopsided hole down the left side of the panel. No inset is reserved
    -- in the wrap box either -- the full width is usable now.
    local pad  = LP.RC_PAD * 2
    local want = math.max(d.rcBaseW, math.min(need + pad, d.rcBaseW * LP.RC_MAX_GROW))
    -- A protected frame anchored to the popup makes it protected too, and in
    -- combat its SetWidth is then blocked: it keeps the width it has, and the
    -- message wraps inside that.
    local locked = InCombatLockdown()
    if locked then
        local p = fr:IsProtected()
        locked = issecretvalue(p) or p
    end
    if locked then
        local w = fr:GetWidth()
        want = (w and not issecretvalue(w) and w > 0) and w or d.rcBaseW
    else
        fr:SetWidth(want)
    end
    fs:SetWidth(want - pad)
    fs:ClearAllPoints()
    -- RC_TEXT_Y, not Blizzard's -37: a long "<Name>-<Realm> has initiated a
    -- ready check." wraps to TWO lines and the second one runs into the button
    -- row. The message moves UP rather than the buttons moving down -- the
    -- buttons sit RC_BTN_Y off the bottom edge and have no room to give.
    fs:SetPoint("TOP", fr, "TOP", 0, LP.RC_TEXT_Y)

    if d.rcTitle and d.rcTitleDY then
        d.rcTitle:ClearAllPoints()
        d.rcTitle:SetPoint("TOP", fr, "TOP", 0, d.rcTitleDY)
    end

    -- Anchored symmetrically about the panel's BOTTOM rather than replayed from
    -- Blizzard's own offsets. Blizzard puts Ready at BOTTOMRIGHT->BOTTOM x=+11
    -- and Not Ready at BOTTOMLEFT->BOTTOM x=+22, which sits the pair's midpoint
    -- ~16px right of center -- the same portrait inset the text carries, and the
    -- most visible one, because a shifted pair shows as unequal margins on each
    -- side. Half the gap from the middle each keeps the gap even AND centers the
    -- row, and it tracks the SetWidth above for free.
    local yes, no = d.rcBtns and d.rcBtns[1], d.rcBtns and d.rcBtns[2]
    if yes and no then
        local half = LP.RC_BTN_GAP / 2
        yes:ClearAllPoints()
        yes:SetPoint("BOTTOMRIGHT", fr, "BOTTOM", -half, LP.RC_BTN_Y)
        no:ClearAllPoints()
        no:SetPoint("BOTTOMLEFT", fr, "BOTTOM", half, LP.RC_BTN_Y)
    end
end

function LP.SkinReadyCheck(fr)
    if not fr or fr:IsForbidden() then return end
    local d = GetFFD(fr)

    -- NO SHELL ON THIS FRAME. ReadyCheckFrame is a bare 323x100 container: the
    -- background, NineSlice, TitleContainer, portrait, message and BOTH buttons
    -- are all children of ReadyCheckListenerFrame, which is setAllPoints to it.
    -- ShowReadyCheck() HIDES that child for the initiator, so Blizzard shows the
    -- person who started the check a completely artless frame. A backdrop here
    -- is therefore a black block that ONLY the initiator ever sees -- the rest
    -- of the group has the listener's own skin covering it.
    --
    -- The listener carries the shell instead (LP.SkinReadyCheckList). This stays
    -- as the fallback for a template that ever drops the child and puts the art
    -- back on the outer frame.
    if not _G.ReadyCheckListenerFrame then
        LP.Shell("readycheck", fr)
    end

    if fr.NineSlice then WSkin.FadeNineSlice(fr.NineSlice) end
    LP.FadeKeys(fr, LP.ART_KEYS)
    WSkin.FadeKeyedArt(fr)

    -- Yes/No are UIPanelButtons named off the frame on some templates and
    -- globally (ReadyCheckFrameYesButton) on others; both paths are cheap and idempotent.
    local n = fr.GetName and fr:GetName()
    local btns = d.rcBtns or {}
    for _, k in ipairs({ "YesButton", "NoButton" }) do
        local b = fr[k] or (n and _G[n .. k])
        if b then
            WSkin.Button(b)
            WSkin.StateButtonLabel(b)
            if not d.rcBtns then btns[#btns + 1] = b end
        end
    end
    d.rcBtns = btns
    WSkin.ButtonsIn(fr)

    -- The message names the player who started the check: a font family, set
    -- before the region walk (which keeps a string's family).
    if n and _G[n .. "Text"] then WSkin.FontFamily(_G[n .. "Text"]) end
    LP.FontRegions(fr)

    -- Message + title for the geometry pass below. Resolved here, where the
    -- frame is in hand, and parked on FFD so the pass itself needs no lookups.
    --
    -- The title is looked up on the LISTENER first. TitleContainer is a child
    -- of that frame, not of this one, and its TitleText is an unnamed parentKey
    -- -- so every lookup rooted at ReadyCheckFrame (fr.TitleContainer,
    -- fr.TitleText, _G.ReadyCheckFrameTitleText) misses, silently, and the
    -- title simply never gets positioned. The fr.* paths stay as the fallback
    -- for a template that moves it back out.
    local host = _G.ReadyCheckListenerFrame or fr
    d.rcText = d.rcText or (n and _G[n .. "Text"]) or fr.Text
    d.rcTitle = d.rcTitle
        or (host.TitleContainer and host.TitleContainer.TitleText)
        or host.TitleText
        or (fr.TitleContainer and fr.TitleContainer.TitleText)
        or fr.TitleText
        or (n and _G[n .. "TitleText"])

    -- A second ready check started while the first is still up re-uses a SHOWN
    -- frame, so OnShow never fires and the width would keep the previous name's
    -- measurement. The message being written is the reliable signal.
    if d.rcText and not d.rcTextHooked then
        d.rcTextHooked = true
        for _, setter in ipairs({ "SetText", "SetFormattedText" }) do
            if d.rcText[setter] then hooksecurefunc(d.rcText, setter, LP.FitReadyCheck) end
        end
    end

    -- Last, and after the re-font: the message is measured here, so it has to
    -- be carrying its final face and size.
    LP.FitReadyCheck()
end

-- The prompt's BODY, despite the name -- see the block comment above. This is
-- the frame that actually carries the popup's art, so it is the one that gets
-- the shell. It is shown to everyone EXCEPT the initiator, which is precisely
-- what keeps the skin off the initiator's screen.
function LP.SkinReadyCheckList(fr)
    if not fr or fr:IsForbidden() then return end

    -- Keeps its title row, so no noTopBar here: the black strip is what the
    -- title then sits on (WSkin.CommonChrome re-centers it there).
    WSkin.Shell("readycheck", fr)

    if fr.NineSlice then WSkin.FadeNineSlice(fr.NineSlice) end
    LP.FadeKeys(fr, LP.ART_KEYS)
    WSkin.FadeKeyedArt(fr)

    -- Header art lives on the title container, one level down from the frame's
    -- own regions, so the shell fade never reaches it. Textures only -- the
    -- title FontString is a region of the same container.
    local tc = fr.TitleContainer
    if tc then
        WSkin.FadeRegions(tc)
        WSkin.Register(tc, true)
        LP.FontRegions(tc)
    end

    -- Portrait REMOVED, and with no option to bring it back. Blizzard's corner
    -- portrait is a PortraitFrameTemplate device: drawn half outside the panel
    -- and relying on the ornate ring art to nest into. Once the shell strips
    -- that art the circle just floats off the left edge. Nothing is lost -- the
    -- initiator's name is already in the message text -- and FitReadyCheck
    -- centers the panel's contents on the strength of it being gone.
    WSkin.RemovePortrait(fr)

    -- Title and message explicitly whitened: both are GameFontNormal, so they
    -- come up Blizzard gold against the shell instead of matching every other
    -- skinned window.
    local title = fr.TitleContainer and fr.TitleContainer.TitleText
    if title then WSkin.White(title) end
    local body = _G.ReadyCheckFrameText
    if body then WSkin.White(body) end

    WSkin.CommonChrome(fr)
    -- The message (a region of this frame) names the player who started the
    -- check: its font family before the region walk.
    if body then WSkin.FontFamily(body) end
    LP.FontRegions(fr)

    -- The geometry pass keys off ReadyCheckFrame, and its capture needs the
    -- message laid out -- which it now is, on the frame that actually owns it.
    LP.FitReadyCheck()
end

WSkin.RegisterWindow({
    key = "readycheck",
    apply = function()
        local function Wire(name, fn)
            LP.WhenFrameExists(name, function(fr)
                local function apply() fn(fr) end
                WSkin.HookShow(fr, apply)
                -- A ready check running through a reload puts one of these on
                -- screen before we ever see an OnShow.
                if fr:IsShown() then apply() end
            end)
        end
        Wire("ReadyCheckFrame", LP.SkinReadyCheck)
        Wire("ReadyCheckListenerFrame", LP.SkinReadyCheckList)
    end,
})

-------------------------------------------------------------------------------
--  BNet toast (BNToastFrame): a friend coming online or going offline, plus
--  broadcasts and club invites. Alert-system driven like the loot toasts, but a
--  SINGLETON rather than a pool instance, so it takes a plain window
--  registration instead of their pool sweep. TAINT: clicking it opens a
--  Battle.net whisper, whose target is a SECRET string, so nothing here writes a
--  Lua field onto the frame.
-------------------------------------------------------------------------------
function LP.SkinBNetToast(f)
    if not f or f:IsForbidden() then return end
    local icon = f.IconTexture

    -- The Blizzard art is a BACKDROP (BACKDROP_TOAST_12_12), and
    -- BackdropTemplateMixin lays its pieces out as ordinary regions ON THE
    -- FRAME via NineSliceUtil, so the shell fade reaches them. No SetBackdrop
    -- call is needed, and none is made: that would re-enter Blizzard code.
    -- No top bar, same as the loot toast -- there is no title row to sit on.
    WSkin.Shell("bnettoast", f, { noTopBar = true })

    -- The shell faded every region including the toast-type icon. Bring it
    -- back and keep it out of later restrip passes. It is NOT squared:
    -- IconTexture is a SetTexCoord crop out of one sheet, re-picked per toast
    -- type, and WSkin.SquareIcon would overwrite those coordinates.
    if icon then
        icon:SetAlpha(1)
        WSkin.Register(f, { [icon] = true })
    end

    -- Blizzard flair burst. SetAlpha(0) is not enough: the texture carries its
    -- OWN alpha animation, which drives alpha every frame and wins over our
    -- write (same shape as the loot toast art). Clear the texture instead.
    local glow = f.glow
    if glow then
        if glow.SetAtlas then glow:SetAtlas("") end
        if glow.SetTexture then glow:SetTexture("") end
        glow:SetAlpha(0)
    end

    -- Font only, never color: ShowToast recolors these per toast type (account
    -- name blue, status grey, some of it as an inline color code), and the
    -- stock colors read correctly on the dark shell. Font families: the lines
    -- show a friend's names and broadcast, in any script.
    for _, k in ipairs({ "TopLine", "MiddleLine", "BottomLine", "DoubleLine" }) do
        WSkin.FontFamily(f[k])
    end

    if f.CloseButton then WSkin.CloseButton(f.CloseButton) end

    -- Hover panel for a truncated broadcast. Inherits TooltipBackdropTemplate,
    -- so the house panel replaces a real tooltip backdrop.
    local tip = f.TooltipFrame
    if tip then
        WSkin.Panel(tip)
        if tip.NineSlice then WSkin.FadeNineSlice(tip.NineSlice) end
        if tip.Text then WSkin.FontFamily(tip.Text) end
    end
end

WSkin.RegisterWindow({
    key = "bnettoast",
    apply = function()
        LP.WhenFrameExists("BNToastFrame", function(f)
            local pass = WSkin.Debounce(function() LP.SkinBNetToast(f) end)
            -- Blizzard repaints nothing on the frame between toasts, but the
            -- pass is idempotent and one debounced call per toast is cheap
            -- insurance against a future template change.
            WSkin.HookShow(f, pass)
            LP.SkinBNetToast(f)
        end)
    end,
})
end

-------------------------------------------------------------------------------
--  Queue frames, ready popups and choice windows.
--
--  Five packs sharing one block: queuestatus (the panel the LFG eye shows on
--  hover), readycheck, pvpscoreboard, delvepicker (the Delves TIER PICKER --
--  a DIFFERENT frame from the "delves" companion window further up) and
--  playerchoice (the Abundance / "how will you aid" weekly choice windows).
--
--  Helpers and constants hang off HP, inside this block's do...end (see the
--  note at the top of the file on the 200-local limit).
--
--  WIDGET TREES ARE OFF LIMITS. The delve picker's "Map Properties" row
--  (.DelveModifiersWidgetContainer) and its scenic backdrop
--  (.DelveBackgroundWidgetContainer) are UIWidgetContainerTemplate frames.
--  Widget values are SECRET inside instanced content, and an insecure write
--  anywhere in that tree resurfaces later as "attempt to compare a secret
--  number value" out of LayoutFrame when a widget set is laid out. Both
--  subtrees stay fully native, and HP.IsWidget fails CLOSED -- a probe that
--  throws counts as a widget -- so an unrecognised container is skipped rather
--  than skinned.
-------------------------------------------------------------------------------
do
local HP = {
    FLAT = "Interface\\Buttons\\WHITE8X8",

    -- Plate / frame art living one level down from a frame's own regions,
    -- where the shell's region fade never reaches it.
    ART_KEYS = {
        "Background", "Bg", "BG", "Border", "BorderFrame", "Backdrop",
        "Decoration", "DividingLine", "Divider", "bottomArt", "background",
    },

    -- The scoreboard's inset is eight separately-named corner/edge tiles
    -- rather than a NineSlice, so FadeRegions cannot recognise them as a set.
    INSET_KEYS = {
        "InsetBorderTopLeft", "InsetBorderTopRight", "InsetBorderBottomLeft",
        "InsetBorderBottomRight", "InsetBorderTop", "InsetBorderBottom",
        "InsetBorderLeft", "InsetBorderRight",
    },

    -- Keys whose presence anywhere in a frame's parent chain marks it as part
    -- of a UI widget set. Same probe list the quest tracker's guard uses.
    WIDGET_KEYS = {
        "OnAcquireWidget", "widgetPools", "widgetSetID", "widgetContainer",
        "widgetType",
    },

    -- NineSlicePanelTemplate's eight EDGE pieces. Center is deliberately absent:
    -- on DialogBorderTemplate the middle is a separate tiled .Bg parchment that
    -- we keep, so fading a "center" here would blank the panel.
    NINESLICE_PIECES = {
        "TopLeftCorner", "TopRightCorner", "BottomLeftCorner", "BottomRightCorner",
        "TopEdge", "BottomEdge", "LeftEdge", "RightEdge",
    },

    -- Every ring/plate stacked on a reward tile's icon. All of these defeat a
    -- square crop: IconBorder is Blizzard's ROUNDED quality ring, the overlays
    -- are the same shape, and NameFrame is the parchment plate behind the name.
    -- One inset for every close button we own, so the X sits in the same
    -- place regardless of how far a window's rect overhangs its panel.
    -- Inset of the close button from the frame's top-right, INSIDE
    -- WSkin.AtlasBorder's drawn line. Two dials because the atlas's padding is
    -- not square: sharing one number moved the X down as far as it moved it
    -- left, and it was already sitting too low.
    --   X: larger = further LEFT (further from the right edge)
    --   Y: larger = further DOWN
    CLOSE_INSET_X = -2,
    CLOSE_INSET_Y = -3,

    REWARD_ART = {
        "IconBorder", "IconOverlay", "IconOverlay2", "IconBorder2", "NameFrame",
    },
}

-- Plain indexed read, passed BY ARGUMENT to pcall. The obvious spelling here is
-- pcall(function() return t[k] end), but that allocates a fresh closure per
-- probe -- up to 25 of them per IsWidget call, on a path that runs for every
-- option of every choice window.
function HP.RawGet(t, k)
    return t[k]
end

-- Children as a TABLE, taken ONCE, and pcall-able by argument. Never
-- select(i, f:GetChildren()) in a loop: that rebuilds the entire vararg every
-- iteration, which is O(n^2) and has caused a real CPU complaint here before.
function HP.Kids(f)
    return { f:GetChildren() }
end

-- Same idea for REGIONS, and it is the only way to reach art that Blizzard
-- declared inline with no name and no parentKey -- the trade window's enchant
-- glyph being the case that forced it. pcall-able by argument for the usual
-- reason: a field access on a forbidden or widget-backed frame can throw.
function HP.Regions(f)
    return { f:GetRegions() }
end

-- Fail-CLOSED widget test: walks up to `depth` parents looking for any widget
-- marker. Every read is pcall'd because a widget frame fed secret data can
-- throw from an ordinary field access, and a probe that THROWS counts as a
-- widget. Cheap: the chains here are 3-5 deep and each pass is per-show.
function HP.IsWidget(frame, depth)
    local cur, hops = frame, 0
    while cur and hops <= (depth or 5) do
        for i = 1, #HP.WIDGET_KEYS do
            local ok, val = pcall(HP.RawGet, cur, HP.WIDGET_KEYS[i])
            if not ok then return true end
            if val ~= nil then return true end
        end
        local ok2, parent = pcall(cur.GetParent, cur)
        if not ok2 then return true end
        cur = parent
        hops = hops + 1
    end
    return false
end

-- Popup/window shell. Idempotent: Shell re-runs its region fade every call but
-- builds its textures once, so re-calling doubles as repaint catch-up.
function HP.Shell(winKey, frame, opts)
    if not frame or frame:IsForbidden() then return end
    WSkin.Shell(winKey, frame, opts)
end

-- Alpha a list of named art keys. TEXTURES ONLY, and the type test is
-- load-bearing: several of these names are a Texture on one template and a
-- FRAME on another ("Border" is a NineSlice on portrait windows), and
-- SetAlpha(0) on a frame takes its whole subtree with it.
function HP.FadeKeys(frame, keys)
    if not frame then return end
    for i = 1, #keys do
        local t = frame[keys[i]]
        if t and t.IsObjectType then
            if t:IsObjectType("Texture") then
                t:SetAlpha(0)
            elseif t.TopEdge or t.TopLeftCorner then
                WSkin.FadeNineSlice(t)
            end
        end
    end
end

-- Re-font a frame's own FontString regions. `white` also forces the color;
-- without it the existing color is kept (quality/faction coloring is content).
function HP.FontRegions(frame, white)
    if not frame or not frame.GetRegions then return end
    local regions = { frame:GetRegions() }
    for i = 1, #regions do
        local r = regions[i]
        if r and r.IsObjectType and r:IsObjectType("FontString") then
            if white then WSkin.White(r) else WSkin.Font(r) end
        end
    end
end

-- Run fn(frame) as soon as a named Blizzard frame exists: immediately if it
-- already does, otherwise on the ADDON_LOADED that creates it. Which of these
-- dialogs are base UI vs load-on-demand has moved between expansions, so none
-- is assumed present at login.
function HP.WhenFrameExists(name, fn)
    if _G[name] then fn(_G[name]); return end
    local ev = CreateFrame("Frame")
    ev:RegisterEvent("ADDON_LOADED")
    ev:SetScript("OnEvent", function(self)
        local fr = _G[name]
        if fr then
            self:UnregisterAllEvents()
            fn(fr)
        end
    end)
end

-- Skin again on each re-show. One debounced pass per frame, early-outing while
-- hidden so a hide/show burst costs nothing.
--
-- Deliberately does NOT run fn() itself: every caller already makes one
-- explicit pass before wiring this up, and running it here too made the first
-- pass happen TWICE for every window (caught by the header-row GetChildren
-- counter, which saw two walks for one apply).
function HP.OnShow(frame, fn)
    if not frame then return end
    local d = GetFFD(frame)
    if d.hpShow then return end
    d.hpShow = true
    frame:HookScript("OnShow", WSkin.Debounce(function()
        if frame:IsVisible() then fn() end
    end))
end

-- Post-hook a mixin method on a frame instance, once.
function HP.HookMethod(frame, method, fn)
    if not frame or type(frame[method]) ~= "function" then return false end
    local d = GetFFD(frame)
    d.hpHooks = d.hpHooks or {}
    if d.hpHooks[method] then return true end
    d.hpHooks[method] = true
    hooksecurefunc(frame, method, fn)
    return true
end

-- Any StatusBar -> flat fill in the user's bar-fill color over a near-black
-- trough. Re-asserted every pass: Blizzard re-applies a bar's own art on reuse.
function HP.Bar(bar)
    if not bar or bar:IsForbidden() or not bar.SetStatusBarTexture then return end
    local d = GetFFD(bar)
    bar:SetStatusBarTexture(HP.FLAT)
    local fill = bar.GetStatusBarTexture and bar:GetStatusBarTexture()
    if fill and fill ~= d.fill then
        d.fill = fill
        -- GetRegions() on a StatusBar includes the fill, so an unguarded
        -- FadeRegions blanks the very thing we just installed.
        WSkin.FadeRegions(bar, { [fill] = true })
        WSkin.Register(bar, { [fill] = true })
    end
    if not d.bg then
        local bg = SolidTex(bar, "BACKGROUND", 0, 0, 0, 0.55)
        bg:SetAllPoints(bar)
        d.bg = bg
    end
    WSkin.ApplyBarFill(bar)
end

-- Close button: skinned AND re-anchored to one house position.
--
-- Blizzard anchors each window's X to that window's own rect, and those rects
-- overhang the VISIBLE panel by different amounts per frame (PlayerChoice pins
-- it at a bare TOPRIGHT, the delve picker insets it), so the X lands a
-- different distance from the panel edge in every window. Re-anchoring to a
-- fixed inset is what makes them agree.
--
-- One-shot per button: Blizzard re-runs its own SetPoint on some layouts, but
-- re-applying every pass would fight a window that legitimately moves its X.
function HP.CloseButton(frame, btn)
    if not frame or not btn or btn:IsForbidden() then return end
    WSkin.CloseButton(btn)
    -- Blizzard's close button carries its own .Border texture, which survives
    -- WSkin.CloseButton and rings the X with leftover frame art. Confirmed by a
    -- /framestack over the X: PlayerChoiceFrame.CloseButton.Border drawing at
    -- level 510, right under the cursor. Cleared, not alpha'd -- these buttons
    -- get re-textured per texture kit.
    for _, k in ipairs({ "Border", "BorderArt", "Background", "Bg" }) do
        local t = btn[k]
        if t and t.IsObjectType and t:IsObjectType("Texture") then
            if t.SetAtlas then t:SetAtlas("") end
            if t.SetTexture then t:SetTexture("") end
            t:SetAlpha(0)
        end
    end

    -- Pin to the FRAME's TOPRIGHT at +3,+3 on every PlayerChoice layout.
    --
    -- Two /framestacks settled this. The 4-option window anchors its X at
    -- TOPRIGHT +3,+3 and looks right; the 3-option window anchors the SAME
    -- button to the SAME point at -9,-9 and sits wrong. Blizzard varies the
    -- OFFSET per layout, not the reference -- so the frame was always the
    -- correct thing to anchor to, and copying the good layout's numbers is what
    -- makes them agree.
    --
    -- Two earlier attempts failed for instructive reasons, both recorded so
    -- they are not retried: a flat -4,-4 off the frame (wrong constant, put the
    -- X off the panel), and anchoring to NineSlice (that layout HAS no
    -- NineSlice -- it uses BorderOverlay -- so the re-anchor silently skipped
    -- and Blizzard's -9,-9 stood).
    -- Inset inside OUR OWN atlas border.
    --
    -- A /framestack on the panel's visible corner named it: the border there is
    -- WSkin.AtlasBorder's AdventureMap_TopBorder texture, anchored 0,0 to the
    -- frame rect. So the panel edge IS the frame edge -- the drawn line just
    -- sits inside the atlas's transparent padding. Every Blizzard frame chased
    -- before this (NineSlice, BorderOverlay, the frame at Blizzard's own
    -- offsets) was irrelevant, because none of them draws that corner.
    --
    -- CLOSE_INSET_X/Y are the tunables: how far in from the frame the atlas's
    -- line falls on each axis. -4 was tried and left the X outside the line.
    -- RE-ASSERTED EVERY PASS, not one-shot. PlayerChoiceFrame re-anchors its
    -- own close button during setup, so a single application at skin time is
    -- silently overwritten and the X never moves at all -- which is exactly the
    -- symptom: not "wrong offset", but "no change whatsoever". Pass() runs on
    -- show and on both SetupOptions paths, i.e. precisely when Blizzard
    -- re-lays it out.
    if btn.SetPoint then
        btn:ClearAllPoints()
        btn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -HP.CLOSE_INSET_X, -HP.CLOSE_INSET_Y)
    end
end

-- Button + label, with Blizzard's own frame art removed FIRST.
--
-- WSkin.Button strips the old Left/Middle/Right texture trio, but modern
-- UIPanelButtonTemplate draws its frame as a NINESLICE instead -- which
-- survives, so the house border lands on top of Blizzard's and every button
-- reads as double-bordered. Fading the NineSlice is what makes it single.
function HP.Button(b)
    if not b or b:IsForbidden() then return end
    -- ONCE PER BUTTON. SkinChoiceOption reaches the same button by two routes
    -- (the OptionButtonsContainer child walk AND the named-key loop), and each
    -- skin pass lays another border -- which is the actual double border, not
    -- Blizzard's art surviving.
    local d = GetFFD(b)
    if d.hpButton then return end
    d.hpButton = true
    -- UIPanelButtonTemplate frames itself with Left/Middle/Right textures
    -- (UI-Panel-Button-Up), NOT a NineSlice. Cleared explicitly so a stray
    -- reapply cannot bring Blizzard's frame back under ours.
    for _, k in ipairs({ "Left", "Middle", "Right" }) do
        local t = b[k]
        if t and t.SetTexture then
            if t.SetAtlas then t:SetAtlas("") end
            t:SetTexture("")
            t:SetAlpha(0)
        end
    end
    if b.NineSlice then WSkin.FadeNineSlice(b.NineSlice) end
    WSkin.Button(b)
    WSkin.WhiteButtonLabel(b)
end

-- Square an icon and give it the house border. Masked icons are left native by
-- WSkin.SquareIcon itself (SetTexCoord on a masked texture is a hard error).
--
-- Pass a parent ONLY for item icons. Atlas glyph art (role icons, faction
-- marks) must not come through here at all: SetTexCoord fights the atlas's own
-- coordinates, and the border boxes empty slots.
function HP.Icon(icon, parent)
    if not icon then return end
    WSkin.SquareIcon(icon, parent or icon:GetParent())
end

-- One reward tile: square the icon, strip every ring stacked on it, and put
-- the rarity back as a SQUARE border.
--
-- Keeping .IconBorder was a deliberate call at first, on the grounds that it
-- carries item QUALITY -- and it was wrong. It is a ROUNDED ring, so it is
-- exactly the "border" that kept coming back in screenshot after screenshot,
-- and it defeats the square crop underneath it. NameFrame (the parchment
-- plate) goes for the same reason.
--
-- Dropping the rarity cue ENTIRELY was the follow-on call, and that was wrong
-- too (reversed 2026-08-14 on maintainer request): "quality still reads from the
-- tooltip" meant hovering every tile to see what mattered. The ring stays
-- stripped, but it is now the SOURCE the square border reads its color from,
-- so the rarity is back without the rounded art coming with it.
function HP.SkinRewardTile(btn)
    if not btn then return end
    for i = 1, #HP.REWARD_ART do
        local t = btn[HP.REWARD_ART[i]]
        if t and t.SetAlpha and t.IsObjectType and t:IsObjectType("Texture") then
            t:SetAlpha(0)
        end
    end
    if btn.Name and btn.Name.SetTextColor then btn.Name:SetTextColor(1, 1, 1) end
    WSkin.SquareIcon(btn.Icon, btn, true)
end

-- Square the icons of a ScrollBox's currently-materialised rows.
--
-- NO border is added and Blizzard's is stripped: passing a parent to SquareIcon
-- draws an EUI border, and .IconBorder is a rounded quality ring. Between them
-- that is two borders on something that was asked to be a square icon.
--
-- ForEachFrame is the ScrollBox's own API for "the rows that exist right now".
-- Preferred over walking children because a WowScrollBoxList keeps its rows
-- under a ScrollTarget child, so GetChildren on the box returns the scaffolding
-- rather than the rows.
function HP.SquareRewards(sb)
    if not sb then return end
    local function Square(row)
        if row and row.Icon then HP.SkinRewardTile(row) end
    end
    if type(sb.ForEachFrame) == "function" and pcall(sb.ForEachFrame, sb, Square) then
        return
    end
    local okKids, kids = pcall(HP.Kids, sb)
    if not okKids then return end
    for i = 1, #kids do
        local ch = kids[i]
        if ch and ch.Icon then
            Square(ch)
        elseif ch then
            -- One level deeper: the ScrollTarget holding the pooled rows.
            local okInner, inner = pcall(HP.Kids, ch)
            if okInner then
                for j = 1, #inner do Square(inner[j]) end
            end
        end
    end
end

-------------------------------------------------------------------------------
--  Queue status panel (QueueStatusFrame): what the minimap LFG eye shows on
--  hover. Inherits TooltipBackdropTemplate, so the shell replaces a genuine
--  tooltip backdrop rather than a window frame.
--
--  Entries are POOLED (statusEntriesPool of QueueStatusEntryTemplate) and
--  rebuilt by QueueStatusFrameMixin:Update, so the skin hangs off that hook
--  and walks only the ACTIVE entries -- typically one or two.
-------------------------------------------------------------------------------
-- Role icons are left FULLY NATIVE. They are ATLAS textures
-- (UI-LFG-RoleIcon-Generic), so the square-icon treatment was wrong twice over:
-- SetTexCoord fights the atlas's own coordinates, and the house border it draws
-- boxed every role glyph -- including ones with no art for the current queue
-- type, which showed up as an empty square floating in the panel corner.
-- Only the COUNT gets house text.
function HP.SkinRoleCount(rc)
    if not rc then return end
    if rc.Count then WSkin.White(rc.Count) end
end

function HP.SkinQueueEntry(entry)
    if not entry or entry:IsForbidden() then return end
    -- Title stays accent-colored by Blizzard for eligibility state; the rest
    -- goes white so the panel reads as one block of house text. The title can
    -- be a premade group's name: a font family.
    if entry.Title then WSkin.FontFamily(entry.Title) end
    for _, k in ipairs({ "Status", "SubTitle", "TimeInQueue", "AverageWait", "ExtraText" }) do
        local fs = entry[k]
        if fs then WSkin.White(fs) end
    end
    -- RoleIcon1/2/3 are deliberately untouched, same reason as SkinRoleCount:
    -- atlas art, and bordering them boxes empty slots.
    for _, k in ipairs({ "TanksFound", "HealersFound", "DamagersFound" }) do
        HP.SkinRoleCount(entry[k])
    end
    -- Assigned spec badge: Blizzard draws it as a circle (CircleMask) inside a
    -- minimap tracking border. The mask makes SetTexCoord illegal, so the icon
    -- is left native and only the brass border goes.
    local spec = entry.AssignedSpec
    if spec and spec.Border then spec.Border:SetAlpha(0) end
    -- Separator between stacked entries -> thin house rule.
    local sep = entry.EntrySeparator
    if sep and sep.SetColorTexture then
        sep:SetColorTexture(1, 1, 1, 0.12)
        if sep.SetAtlas then sep:SetAtlas("") end
    end
end

function HP.ApplyQueueStatus()
    local f = _G.QueueStatusFrame
    if not f or f:IsForbidden() then return end
    HP.Shell("queuestatus", f, { noTopBar = true })
    if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
    HP.FadeKeys(f, HP.ART_KEYS)

    local function Pass()
        local pool = f.statusEntriesPool
        if not (pool and pool.EnumerateActive) then return end
        local ok, iter = pcall(pool.EnumerateActive, pool)
        if not ok or not iter then return end
        for entry in iter do HP.SkinQueueEntry(entry) end
    end
    Pass()
    -- Update rebuilds the entry list; it is the only thing that changes what
    -- is on screen, so nothing else needs polling.
    HP.HookMethod(f, "Update", WSkin.Debounce(function()
        if f:IsVisible() then Pass() end
    end))
end

WSkin.RegisterWindow({
    key = "queuestatus",
    addons = { Blizzard_QueueStatusFrame = true },
    apply = function()
        HP.WhenFrameExists("QueueStatusFrame", function() HP.ApplyQueueStatus() end)
    end,
})

-------------------------------------------------------------------------------
--  Delves difficulty picker (DelvesDifficultyPickerFrame,
--  Blizzard_DelvesDifficultyPicker): the tier picker with the reward list.
--
--  NOT the "delves" pack further up -- that one is the companion
--  configuration window in Blizzard_DelvesCompanionConfiguration.
--
--  The "Map Properties" icon row and the scenic backdrop are
--  UIWidgetContainerTemplate frames. They are named here only to be SKIPPED;
--  nothing in this function may write into either subtree.
-------------------------------------------------------------------------------
function HP.ApplyDelvePicker()
    local f = _G.DelvesDifficultyPickerFrame
    if not f or f:IsForbidden() then return end

    local function Pass()
        -- FOUR TARGETED CHANGES, by maintainer call. The full window shell was
        -- built, shown to him and REJECTED, so there is deliberately no
        -- HP.Shell, no region fade and no font pass here: Blizzard's
        -- background, title, scenario label, description, scenic art, reward
        -- text and challenge grid all stay exactly as shipped.
        --   1. ornate dialog border -> EUI's window border
        --   2. close button        -> EUI's X
        --   3. tier dropdown + Enter button
        --   4. "Chance to receive" icons squared
        -- Resist re-adding anything else here; the restraint IS the request.

        -- DialogBorderTemplate is a NineSlicePanelTemplate plus a tiled .Bg
        -- parchment. Only the eight border PIECES are faded, never the Border
        -- FRAME itself: WSkin.FadeNineSlice alphas the container too, which
        -- would take .Bg with it and leave the panel see-through.
        local brd = f.Border
        if brd then
            for i = 1, #HP.NINESLICE_PIECES do
                local t = brd[HP.NINESLICE_PIECES[i]]
                if t and t.SetAlpha then t:SetAlpha(0) end
            end
            WSkin.AtlasBorder(f)
        end
        HP.CloseButton(f, f.CloseButton)

        if f.Dropdown then WSkin.Dropdown(f.Dropdown) end
        if f.EnterDelveButton then HP.Button(f.EnterDelveButton) end

        local rc = f.DelveRewardsContainerFrame
        if rc and not HP.IsWidget(rc, 2) then HP.SquareRewards(rc.ScrollBox) end
        -- .DelveModifiersWidgetContainer / .DelveBackgroundWidgetContainer:
        -- deliberately untouched, see the block header.
    end

    Pass()
    HP.OnShow(f, Pass)
    -- Switching tier re-lays the reward list.
    HP.HookMethod(f, "CheckAndSetDisplayMode", WSkin.Debounce(function()
        if f:IsVisible() then Pass() end
    end))
    -- Scrolling ACQUIRES fresh row frames from the pool, so squaring only on
    -- show would leave anything scrolled into view uncropped.
    local rc0 = f.DelveRewardsContainerFrame
    if rc0 and rc0.ScrollBox then
        HP.HookMethod(rc0.ScrollBox, "Update", WSkin.Debounce(function()
            if f:IsVisible() then HP.SquareRewards(rc0.ScrollBox) end
        end))
    end
end

WSkin.RegisterWindow({
    key = "delvepicker",
    addons = { Blizzard_DelvesDifficultyPicker = true },
    apply = function()
        HP.WhenFrameExists("DelvesDifficultyPickerFrame", function() HP.ApplyDelvePicker() end)
    end,
})

-------------------------------------------------------------------------------
--  Player choice windows (PlayerChoiceFrame, Blizzard_PlayerChoice): the
--  Abundance harvest picker and the weekly "how will you aid ..." windows are
--  the same frame with two different option layouts --
--  PlayerChoiceNormalOptionTemplate (columns) and
--  PlayerChoiceNormalOptionGridTemplate (the grid variant).
--
--  Blizzard drives this frame's art from a TEXTURE KIT chosen per choice, so
--  every option is re-textured on each SetupOptions pass and a one-shot skin
--  would survive exactly one window. Both setup paths are hooked.
--
--  Option ARTWORK (the scene image on each card) is content and stays; only
--  the parchment plate, header and button chrome are replaced.
-------------------------------------------------------------------------------
-- The reputation / progress bars on a choice option ("Friendly", "Revered" on
-- the weekly cartel picker) are UI WIDGETS: PlayerChoiceBaseOptionTemplate owns
-- a .WidgetContainer inheriting UIWidgetContainerTemplate, and each option calls
-- RegisterForWidgetSet on it. They can NEVER be skinned in place -- that is the
-- secret-value rule, and it is why HP.IsWidget already refuses to descend into
-- them. Instead they are handed to the HUD cover system, which draws an
-- EUI-owned bar anchored over Blizzard's without writing to it.
--
-- Handed over rather than discovered: the cover system's own sweep only walks
-- UIParent's direct children, and these containers are two levels inside a
-- window.
function HP.AdoptOptionWidgets(opt)
    local adopt = EllesmereUI._HUDWidgetAdopt
    if type(adopt) ~= "function" then return end
    for _, k in ipairs({ "WidgetContainer" }) do
        local okC, wc = pcall(HP.RawGet, opt, k)
        if okC and wc then adopt(wc) end
    end
end

function HP.SkinChoiceOption(opt)
    if not opt then return end
    -- BEFORE the widget test: this option's own frame is ordinary, only its
    -- WidgetContainer child is a widget tree, and the container is exactly what
    -- we want to register.
    HP.AdoptOptionWidgets(opt)
    -- IsWidget FIRST, before any unguarded call on the frame. Every read it
    -- makes is pcall'd, so a frame whose field access throws is classified as a
    -- widget and skipped; calling opt:IsForbidden() ahead of it would throw on
    -- that same frame and take the whole pass down with it.
    if HP.IsWidget(opt, 2) then return end
    local okF, forbidden = pcall(opt.IsForbidden, opt)
    if not okF or forbidden then return end
    HP.FadeKeys(opt, HP.ART_KEYS)
    if opt.NineSlice then WSkin.FadeNineSlice(opt.NineSlice) end

    -- Header plate + title.
    local hdr = opt.Header
    if hdr then
        HP.FadeKeys(hdr, HP.ART_KEYS)
        if hdr.Text then WSkin.White(hdr.Text) end
        HP.FontRegions(hdr, true)
    end
    if opt.OptionText then WSkin.White(opt.OptionText) end
    if opt.Title then WSkin.White(opt.Title) end

    -- Body text frames keep Blizzard's inline coloring (the requirement lines
    -- are red/green on purpose), so re-font without recoloring.
    local tf = opt.OptionButtonsContainer or opt.Text
    if tf then HP.FontRegions(tf) end

    -- Choice buttons ("Harvest", "Choose Quest", ...).
    -- The container's children are WRAPPER frames, not the buttons: the real
    -- one is a level deeper at <wrapper>.Button. A /framestack over a
    -- "Work for ..." button showed
    -- OptionButtonsContainer.<wrapper>.Button.Middle still drawing, because a
    -- walk that only tested the wrappers for GetObjectType()=="Button" found
    -- nothing and skinned nothing. What looked like a double border was
    -- Blizzard's own button art, never touched.
    local bc = opt.OptionButtonsContainer
    if bc and bc.GetChildren then
        local kids = { bc:GetChildren() }
        for i = 1, #kids do
            local w = kids[i]
            if w then
                if w.GetObjectType and w:GetObjectType() == "Button" then
                    HP.Button(w)
                end
                local okB, inner = pcall(HP.RawGet, w, "Button")
                if okB and inner and inner.GetObjectType
                   and inner:GetObjectType() == "Button" then
                    HP.Button(inner)
                end
            end
        end
    end
    for _, k in ipairs({ "OptionButton", "Button", "ConfirmationButton" }) do
        local b = opt[k]
        if b and b.GetObjectType and b:GetObjectType() == "Button" then
            HP.Button(b)
        end
    end

    -- Reward icons (item / currency rows under each option).
    local rewards = opt.Rewards or opt.RewardsFrame
    if rewards and rewards.GetChildren then
        local kids = { rewards:GetChildren() }
        for i = 1, #kids do
            local r = kids[i]
            if r and not r:IsForbidden() then
                HP.Icon(r.Icon, r)
                if r.Name then WSkin.Font(r.Name) end
            end
        end
    end
end

function HP.ApplyPlayerChoice()
    local f = _G.PlayerChoiceFrame
    if not f or f:IsForbidden() then return end

    local function Pass()
        HP.Shell("playerchoice", f)
        HP.FadeKeys(f, HP.ART_KEYS)
        if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
        -- Close button: skinned AND re-stripped every pass. PlayerChoice drives
        -- its art from a per-choice TEXTURE KIT, so Blizzard re-applies the
        -- button's own textures when the window is set up -- a one-shot skin
        -- gets painted over on the next choice. The Border key is a separate
        -- frame on UIPanelCloseButton and survives a plain region fade.
        HP.CloseButton(f, f.CloseButton)
        if f.Title then WSkin.White(f.Title) end
        if f.Header then
            HP.FadeKeys(f.Header, HP.ART_KEYS)
            HP.FontRegions(f.Header, true)
        end
        -- PlayerChoiceFrame owns a WidgetContainer of its own, above the
        -- options; same cover treatment as the per-option ones.
        HP.AdoptOptionWidgets(f)

        -- Options come from `optionPools`, a FramePoolCollection -- NOT a
        -- parentArray. The first build looked for f.Options and then fell back
        -- to walking children for an .OptionButtonsContainer key that does not
        -- exist, so it found NOTHING: no option was ever skinned and, worse, no
        -- option WidgetContainer was ever handed to the cover system, which is
        -- why the reputation bars stayed stock.
        local pools = f.optionPools
        local done = false
        if pools then
            -- EnumerateActive covers every pool in the collection, so both the
            -- column and grid option templates are picked up in one pass.
            if type(pools.EnumerateActive) == "function" then
                local okE, iter = pcall(pools.EnumerateActive, pools)
                if okE and iter then
                    for opt in iter do HP.SkinChoiceOption(opt) end
                    done = true
                end
            end
            if not done and type(pools.EnumerateActiveByTemplate) == "function"
               and f.optionFrameTemplate then
                local okT, iter2 = pcall(pools.EnumerateActiveByTemplate, pools,
                                         f.optionFrameTemplate)
                if okT and iter2 then
                    for opt in iter2 do HP.SkinChoiceOption(opt) end
                    done = true
                end
            end
        end
        if not done and f.GetChildren then
            -- Last resort: an option is any child carrying a WidgetContainer.
            local kids = { f:GetChildren() }
            for i = 1, #kids do
                local ch = kids[i]
                local okW, wc = pcall(HP.RawGet, ch, "WidgetContainer")
                if okW and wc then HP.SkinChoiceOption(ch) end
            end
        end
    end

    Pass()
    HP.OnShow(f, Pass)
    -- Both layout paths re-texture every option from the texture kit, so both
    -- must re-skin. Debounced: SetupOptions and AlignOptionHeights can fire
    -- several times for one window.
    local restrip = WSkin.Debounce(function()
        if f:IsVisible() then Pass() end
    end)
    HP.HookMethod(f, "SetupOptions", restrip)
    HP.HookMethod(f, "SetupOptionsAsGrid", restrip)
    HP.HookMethod(f, "SetupFrame", restrip)
end

WSkin.RegisterWindow({
    key = "playerchoice",
    addons = { Blizzard_PlayerChoice = true },
    apply = function()
        HP.WhenFrameExists("PlayerChoiceFrame", function() HP.ApplyPlayerChoice() end)
    end,
})

-------------------------------------------------------------------------------
--  Stack split popup (StackSplitFrame): the quantity box that opens over the
--  merchant window on a shift-click / right-click buy.
--
--  Registered under the MERCHANT key rather than one of its own -- it is the
--  merchant window's own popup as far as the user is concerned, and a second
--  registration on an existing key is the same shape charsheet and
--  professionsbook already use.
--
--  Blizzard swaps between two BACKGROUND textures depending on whether the item
--  is sold singly or in bundles (SingleItem vs MultiItem, chosen in ChooseFrameType), and
--  re-shows whichever it picked on each open. Both are faded every pass rather
--  than once, or the first multi-digit split brings the brass money-frame art
--  back on a window that has already been skinned.
-------------------------------------------------------------------------------
function HP.ApplyStackSplit()
    local f = _G.StackSplitFrame
    if not f or f:IsForbidden() then return end

    local function Pass()
        HP.Shell("merchant", f, { noTopBar = true })
        HP.FadeKeys(f, HP.ART_KEYS)
        if f.SingleItemSplitBackground then f.SingleItemSplitBackground:SetAlpha(0) end
        if f.MultiItemSplitBackground then f.MultiItemSplitBackground:SetAlpha(0) end
        if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end

        -- GIVE THE COUNT ITS FIELD BACK.
        --
        -- StackSplitFrame has NO EditBox -- the count is a FontString and the
        -- frame takes digits through enableKeyboard/OnKeyDown. What made it
        -- READ as a typeable field in Blizzard's version was
        -- SingleItemSplitBackground, the money-frame plate behind the number,
        -- and this pack fades that (correctly -- it is stock art). Fading it
        -- without replacing it left the count floating between two arrows with
        -- nothing to say it accepts input.
        --
        -- So the plate comes back in the house style: flat panel + 1px edge,
        -- sized to the text rather than to the old art, which was far wider
        -- than the number it framed.
        if f.StackSplitText and f.LeftButton and f.RightButton then
            local d = GetFFD(f)
            if not d.splitField then
                -- SPANS THE GAP BETWEEN THE ARROWS, not the text.
                --
                -- Anchoring to StackSplitText gave a box that hugged the digit:
                -- the string is justifyH="RIGHT" and anchored to the frame's
                -- RIGHT at x=-50, so its rect is narrow and sits off-centre
                -- (right edge lands at CENTER+36 while the arrows are at
                -- CENTER-59 and CENTER+64). A field has to be the whole gap.
                --
                -- Anchored to the BUTTONS rather than hardcoding those offsets,
                -- so it still fits if Blizzard moves them, and the LEFT/RIGHT
                -- anchors centre it vertically on the arrow row for free.
                -- SEARCH-BOX LOOK, matched to WSkin.EditBox: a near-black
                -- 0.02 fill under the THEMED grey border, not the flat black
                -- edge the item tiles use. Black reads as an outline drawn
                -- round a number; the grey edge is what makes a rectangle look
                -- like something you can type into. Aesthetic only -- the frame
                -- already takes digits through enableKeyboard, so there is no
                -- EditBox to build.
                local bg = f:CreateTexture(nil, "BACKGROUND", nil, -6)
                bg:SetColorTexture(0.02, 0.02, 0.02, 1)
                bg:SetPoint("LEFT", f.LeftButton, "RIGHT", 5, 0)
                bg:SetPoint("RIGHT", f.RightButton, "LEFT", -5, 0)
                bg:SetHeight(22)
                d.splitField = bg
                WSkin.QualityBorder(f, bg,
                    Theme.brdR or 0.2, Theme.brdG or 0.2, Theme.brdB or 0.2)

                if f.StackSplitText.SetJustifyH then
                    f.StackSplitText:SetJustifyH("CENTER")
                end
            end
            -- A bundle shows two lines, the stacks over the total; Blizzard's
            -- anchors for them already straddle the arrow row. A single count
            -- goes in the MIDDLE of the field: stock right-justifies it against
            -- an offset that only made sense with the old money-frame plate, and
            -- ChooseFrameType puts that anchor back on every open.
            if f.isMultiStack then
                d.splitField:SetHeight(44)
            else
                d.splitField:SetHeight(22)
                f.StackSplitText:ClearAllPoints()
                f.StackSplitText:SetPoint("CENTER", d.splitField, "CENTER", 0, 0)
            end
        end

        if f.StackSplitText then WSkin.White(f.StackSplitText) end
        if f.StackItemCountText then WSkin.White(f.StackItemCountText) end
        for _, k in ipairs({ "OkayButton", "CancelButton" }) do
            local b = f[k]
            if b then HP.Button(b) end
        end
        -- The two arrows are plain Buttons carrying Normal/Pushed/Disabled
        -- money-frame textures rather than a template, so WSkin.Button has
        -- nothing to strip. Recolor the art in place: white at rest, dimmed
        -- when disabled, which keeps the disabled state readable.
        for _, k in ipairs({ "LeftButton", "RightButton" }) do
            local b = f[k]
            if b then
                for _, getter in ipairs({ "GetNormalTexture", "GetPushedTexture",
                                          "GetDisabledTexture", "GetHighlightTexture" }) do
                    local t = b[getter] and b[getter](b)
                    if t and t.SetVertexColor then t:SetVertexColor(1, 1, 1) end
                end
                local dis = b.GetDisabledTexture and b:GetDisabledTexture()
                if dis and dis.SetVertexColor then dis:SetVertexColor(0.4, 0.4, 0.4) end
            end
        end
    end

    Pass()
    -- Every open runs ChooseFrameType (both clients open the box only through
    -- OpenStackSplitFrame), and so does a shift-click on another item while the
    -- box is up, which fires no OnShow. It swaps the two backdrops, resizes the
    -- frame and re-anchors the count, so the pass follows it, one frame later.
    HP.HookMethod(f, "ChooseFrameType", WSkin.Debounce(function()
        if f:IsVisible() then Pass() end
    end))
end

WSkin.RegisterWindow({
    key = "merchant",
    apply = function()
        HP.WhenFrameExists("StackSplitFrame", function() HP.ApplyStackSplit() end)
    end,
})

-------------------------------------------------------------------------------
--  Trade window (TradeFrame).
--
--  A ButtonFrameTemplate window of two mirrored halves -- theirs on the left,
--  yours on the right -- each with 6 item slots plus one ENCHANT slot, its own
--  insets, and a money row. Yours is editable (MoneyInputFrameTemplate, three
--  edit boxes); theirs is read-only.
--
--  BOTH PORTRAITS GO, as on every other window pack. Two are in play:
--    - TradeFrame's ButtonFrameTemplate CORNER portrait is removed as always.
--      It is drawn half outside the panel and floats free once the frame art
--      is gone.
--    - TradeFrame.RecipientOverlay.portrait -- the trade partner's face -- is
--      removed by HP.TradeHidePortrait. Blizzard anchors that overlay above
--      the frame's top edge and lets its metal corner atlas bridge the
--      overhang, so with the atlas gone there is nowhere for it to sit that
--      does not read as pasted onto the title row; the partner's name is
--      already in the header.
-------------------------------------------------------------------------------

-- Frame art that is NOT reachable through the shell's own region fade: the
-- divider between the two halves and the recipient's tinted backdrop are
-- globals parented to TradeFrame, not regions of it.
-- THE CURRENCY ROW: STRIP BLIZZARD'S SURROUND, ADD NOTHING.
--
-- Two different things got conflated when this was "stripped" the first time:
--   - DRAWING an EUI box on the row -- that was the reskin attempt, it is gone
--     and stays gone;
--   - FADING Blizzard's own surround (the money insets and the gold-edged
--     recipient box) -- that is just stray chrome removal, and pulling it out
--     left an outlined panel and a gold box sitting on a dark window.
-- The second is back. The three g/s/c boxes keep their bevels because they are
-- forbidden and genuinely cannot be touched; everything AROUND them can be,
-- and is.

-- Frame art that is NOT reachable through the shell's own region fade: the
-- divider between the two halves and the recipient's tinted backdrop are
-- globals parented to TradeFrame, not regions of it.
HP.TRADE_EDGE = {
    "TradeRecipientBotLeftCorner", "TradeRecipientLeftBorder", "TradeRecipientBG",
    -- Named in a /framestack over the live window, not in the source dump's
    -- layout: the frame's own backdrop, still drawn under everything.
    "TradeFrameBg",
    -- The recipient's money surround, a ThinGoldEdgeTemplate FRAME (not a
    -- texture). Pulled out with the currency work and that was wrong: it is
    -- not part of skinning the row, it is a gold-edged box sitting on a dark
    -- panel, and dropping it put Blizzard's gold outline back on the top
    -- right. Fading the frame is safe -- it holds the edge art only, and the
    -- money AMOUNT lives in TradeRecipientMoneyFrame, a sibling.
    "TradeRecipientMoneyBg",
}

-- Hoisted rather than written inline in the pass: both of these run on EVERY
-- window open, and a table literal in the loop header builds a fresh table
-- each time for no reason.
HP.TRADE_TEXTS = {
    -- The two names first: HP.TradeTexts gives them font families
    "TradeFramePlayerNameText", "TradeFrameRecipientNameText",
    "TradeFramePlayerEnchantText", "TradeFrameRecipientEnchantText",
}
HP.TRADE_PORTRAIT_KEYS = { "portrait", "portraitFrame" }

HP.TRADE_INSETS = {
    -- ButtonFrameTemplate's own panel. Its bottom edge sits at y=+26, right
    -- above the Trade/Cancel row, and it is what drew the stray line across
    -- the bottom of the window -- it is `$parentInset` on the TEMPLATE, so it
    -- is not in the Trade* naming scheme and was missed on the first pass.
    "TradeFrameInset",
    "TradeRecipientItemsInset", "TradeRecipientEnchantInset",
    "TradePlayerItemsInset", "TradePlayerEnchantInset",
    -- The money surrounds. Their ART is faded like every other inset; nothing
    -- is DRAWN in their place -- that is the line between removing Blizzard's
    -- chrome and reskinning a row that cannot be reskinned.
    "TradePlayerInputMoneyInset", "TradeRecipientMoneyInset",
}

-- A flat dark panel with a 1px black edge, built once per host and anchored to
-- `region`. The house look for a BOX -- the same weight as a squared icon's
-- edge, which is what these name plates were asked to match.
function HP.TradeBox(host, region, inset)
    if not host or not region then return end
    -- IsForbidden on BOTH, and it is not belt-and-braces. This CREATES a
    -- texture on `host` and anchors it to `region`, and either call THROWS on a
    -- forbidden object rather than no-opping. The pack is pcall-isolated at the
    -- window level, so one throw here takes out every remaining step of the
    -- pass -- the buttons, the close button and the portrait all run after the
    -- money row -- and the result reads as a half-skinned window rather than an
    -- obvious failure. That is exactly how this shipped broken once.
    --
    -- WSkin.EditBox, which this replaced for the money row, carries the same
    -- guard and was quietly skipping the object; dropping to a raw
    -- CreateTexture is what turned a silent skip into an error.
    if host.IsForbidden and host:IsForbidden() then return end
    if region.IsForbidden and region:IsForbidden() then return end
    local d = GetFFD(host)
    if not d.tradeBox then
        local bg = host:CreateTexture(nil, "BACKGROUND", nil, -6)
        bg:SetColorTexture(0.04, 0.04, 0.04, 0.9)
        d.tradeBox = bg
    end
    local i = inset or 0
    d.tradeBox:ClearAllPoints()
    d.tradeBox:SetPoint("TOPLEFT", region, "TOPLEFT", i, -i)
    d.tradeBox:SetPoint("BOTTOMRIGHT", region, "BOTTOMRIGHT", -i, i)
    -- Explicit BLACK through the quality helper: it is the 1px pixel-snapped
    -- edge, and unlike BorderRegion it hands back a frame so the box can be
    -- re-anchored or hidden later.
    WSkin.QualityBorder(host, d.tradeBox, 0, 0, 0)
end

-- One trade slot: an empty-slot backdrop, a NAME PLATE, a name string and a
-- standard ItemButton.
function HP.SkinTradeSlot(slot)
    if not slot or slot:IsForbidden() then return end
    local n = slot.GetName and slot:GetName()
    -- The 64x64 empty-slot socket art, faded: with the panel's own frame art
    -- gone it reads as a stray bevel behind a square icon.
    local st = slot.SlotTexture or (n and _G[n .. "SlotTexture"])
    if st and st.SetAlpha then st:SetAlpha(0) end

    -- THE NAME PLATE. UI-QuestItemNameFrame, 124x64 of rounded parchment art
    -- around a 37px row -- most of what still read as Blizzard on this window,
    -- because it has NO parentKey and is only reachable as $parentNameFrame.
    -- Replaced with the same flat box + 1px edge the icons carry.
    local nameFrame = n and _G[n .. "NameFrame"]
    -- Guarded HERE, where it is first touched. SkinTradeSlot alphas this before
    -- handing it to TradeBox, so a forbidden plate throws on the SetAlpha and
    -- takes the remaining slots with it -- TradeBox's own guard never gets a
    -- look in.
    if nameFrame and nameFrame.IsForbidden and nameFrame:IsForbidden() then
        nameFrame = nil
    end
    if nameFrame then
        nameFrame:SetAlpha(0)
        -- Inset vertically: the art is 64 tall around a 37px row, so tracking
        -- its rect exactly would draw a box half again as tall as the slot.
        HP.TradeBox(slot, nameFrame, 14)
    end

    -- Name keeps Blizzard's item-quality COLOR -- that is content, not chrome.
    local nameFS = slot.Name or (n and _G[n .. "Name"])
    if nameFS then WSkin.Font(nameFS) end

    -- THE ENCHANT GLYPH. Slot 7 on each side carries an extra texture that has
    -- NO NAME and NO parentKey -- a bare 62x62 UI-TradeFrame-EnchantIcon
    -- declared inline on TradeRecipientItem7/TradePlayerItem7 -- so no
    -- key-based sweep can ever reach it. At 62px over a 37px slot it hangs well
    -- outside the squared box and is the reason the enchant rows read as chunky
    -- next to the clean slots above.
    --
    -- Found by walking the slot's REGIONS, which is the only way to see an
    -- anonymous one, and everything we own is spared by object identity rather
    -- than by name. The row keeps its "Will not be traded" caption, so nothing
    -- is lost by dropping the glyph.
    local d = GetFFD(slot)
    local okR, regs = pcall(HP.Regions, slot)
    if okR and regs then
        for i = 1, #regs do
            local r = regs[i]
            if r and r ~= d.tradeBox and r.IsObjectType and r:IsObjectType("Texture")
               and r.SetAlpha and not (r.IsForbidden and r:IsForbidden()) then
                r:SetAlpha(0)
            end
        end
    end

    local btn = slot.ItemButton or (n and _G[n .. "ItemButton"])
    -- true: square icon plus the square RARITY border, the same call the
    -- merchant grid makes. Reused rather than reimplemented -- this is a
    -- file-scope local declared far above, so it is in scope here.
    if btn then SkinMailItemButton(btn, true) end
end

-- REMOVED ENTIRELY, on request, after several rounds of trying to make it sit
-- well. Both portraits on this window now go:
--   - TradeFrame's ButtonFrameTemplate CORNER portrait, via WSkin.RemovePortrait
--     in the shell phase, as on every other window;
--   - TradeFrame.RecipientOverlay, the trade partner's face, here.
--
-- Blizzard anchors that overlay 7px ABOVE the frame's top edge and lets its
-- metal corner atlas bridge the overhang, so with the atlas gone there is
-- nowhere for it to sit that does not read as pasted onto the title row. The
-- name is already in the header; the picture was not earning its place.
--
-- ALPHA, never Hide: house rule is that Blizzard frames are not shown or
-- hidden, only made invisible.
function HP.TradeHidePortrait()
    local f = _G.TradeFrame
    local ov = f and f.RecipientOverlay
    if not ov or (ov.IsForbidden and ov:IsForbidden()) then return end
    for _, k in ipairs(HP.TRADE_PORTRAIT_KEYS) do
        local t = ov[k]
        if t and t.SetAlpha and not (t.IsForbidden and t:IsForbidden()) then
            t:SetAlpha(0)
        end
    end
end

function HP.ApplyTrade()
    local f = _G.TradeFrame
    if not f or f:IsForbidden() then return end

    -- PHASE-ISOLATED, and this window earned it. The engine pcalls each WINDOW,
    -- so one throw anywhere in a pass takes out every step after it -- which
    -- happened twice in two rounds here, both times a FORBIDDEN object (every
    -- method on one throws), and both times the symptom was a half-skinned
    -- window with nothing obvious to point at rather than a clean failure.
    --
    -- Each phase below runs in its own pcall, so a bad object costs THAT phase
    -- and nothing after it. Built ONCE and kept in FFD: the pass re-runs on
    -- every window open, and rebuilding the closures each time is needless
    -- churn.
    local fd = GetFFD(f)
    if not fd.tradePhases then
        fd.tradeFailed = {}
        fd.tradePhases = {
            function()
                HP.Shell("trade", f)
                -- The metal frame. NineSlice is a CHILD FRAME, not a region,
                -- so the shell's region fade never reaches it -- a /framestack
                -- over the live window found it still drawing
                -- !UI-Frame-Metal-EdgeLeft at level 500, on top of everything.
                if f.NineSlice then WSkin.FadeNineSlice(f.NineSlice) end
                -- The CORNER portrait only. The recipient's is its own phase
                -- and is deliberately not part of this.
                WSkin.RemovePortrait(f)
                if f.TitleContainer then HP.FontRegions(f.TitleContainer, true) end
            end,
            function() HP.TradeEdges() end,
            function() HP.TradeSlots() end,
            function() HP.TradeTexts() end,
            function()
                HP.Button(_G.TradeFrameTradeButton)
                HP.Button(_G.TradeFrameCancelButton)
                HP.CloseButton(f, f.CloseButton or _G.TradeFrameCloseButton)
            end,
            function() HP.TradeHidePortrait() end,
            -- Behavior, not chrome, but it rides the phase list for the
            -- same crash isolation. No-op after its first run.
            function() HP.TradeAlertFix() end,
        }
    end

    local function Pass()
        local ph, failed = fd.tradePhases, fd.tradeFailed
        for i = 1, #ph do
            local ok, err = pcall(ph[i])
            -- Reported ONCE per phase. A forbidden object stays forbidden, and
            -- an error thrown on every window open is spam rather than a
            -- diagnostic -- but swallowing it entirely would hide a real bug,
            -- so the first one still goes through the normal error handler.
            if not ok and err and not failed[i] then
                failed[i] = true
                geterrorhandler()(err)
            end
        end
    end

    Pass()
    -- Re-run on show: the slots are repopulated per trade, and Blizzard
    -- re-textures an ItemButton every time its slot changes hands.
    HP.OnShow(f, Pass)
end

function HP.TradeEdges()
        for i = 1, #HP.TRADE_EDGE do
            local t = _G[HP.TRADE_EDGE[i]]
            -- Per-ITEM guard, not just per-phase. One forbidden texture must
            -- not stop the rest of the list -- phase isolation would still
            -- leave the other three pieces of divider art up.
            if t and t.SetAlpha and not (t.IsForbidden and t:IsForbidden()) then
                t:SetAlpha(0)
            end
        end
        for i = 1, #HP.TRADE_INSETS do
            local ins = _G[HP.TRADE_INSETS[i]]
            if ins then WSkin.Inset(ins) end
        end
end

-- 7 slots a side: 6 items and the enchant slot, which is slot 7 on both halves
-- rather than a separately named frame.
function HP.TradeSlots()
        for i = 1, 7 do
            HP.SkinTradeSlot(_G["TradePlayerItem" .. i])
            HP.SkinTradeSlot(_G["TradeRecipientItem" .. i])
        end
end

-- THE CHANGE GLOW FOLLOWS THE ITEM. A drag between trade slots is a REMOVE
-- then an ADD (OnDragStart and OnReceiveDrag both call ClickTradeButton), so
-- two slots change and TradeFrame_AlertItemIfChanged lights the wrong one:
-- the emptied slot alerts, and the filled one stays silent while its itemKey
-- is nil -- Blizzard skips a slot's first item, and the enchant slot behind
-- "Will not be traded" is almost always in that state. Latched per side: a
-- slot going empty arms its side, the next slot on that side to gain an item
-- consumes the latch. side -> the Alert frame left glowing on the empty slot.
HP.tradeVacated = {}

-- Named so the state above can be dropped between trades. Slot 7 is the
-- enchant slot on both halves.
HP.TRADE_ALERT_BUTTONS = {}
for i = 1, 7 do
    HP.TRADE_ALERT_BUTTONS[#HP.TRADE_ALERT_BUTTONS + 1] = "TradePlayerItem" .. i .. "ItemButton"
    HP.TRADE_ALERT_BUTTONS[#HP.TRADE_ALERT_BUTTONS + 1] = "TradeRecipientItem" .. i .. "ItemButton"
end

-- Stop() alone lands the alpha at 0 only if the group is still running;
-- zeroing it too covers a stop between steps, which is when this is called.
function HP.TradeAlertStop(alert)
    if not alert or (alert.IsForbidden and alert:IsForbidden()) then return end
    if alert.ItemIconAlertAnim then alert.ItemIconAlertAnim:Stop() end
    if alert.LoopFlipbook then alert.LoopFlipbook:SetAlpha(0) end
end

-- Which half a button is on, read off its name: the two halves use otherwise
-- identical templates and share this one alert function, and a partner
-- rearranging their offer must not steal the glow off yours.
function HP.TradeButtonSide(btn)
    local n = btn and btn.GetName and btn:GetName()
    if not n then return end
    if n:find("TradePlayerItem", 1, true) == 1 then return "player" end
    if n:find("TradeRecipientItem", 1, true) == 1 then return "recipient" end
end

-- Only a MOVE is redirected: an item that leaves the offer for good never gets
-- its latch consumed, so its removal glow survives. That is a CHANGE warning,
-- not the accept state (TradeHighlightPlayer/Recipient, left stock below).
-- Blizzard's oldItemKey is gone by the time a post-hook runs, hence the shadow
-- flag -- which also makes a button's FIRST sighting quiet, so a /reload
-- mid-trade initializes instead of alerting on all fourteen slots.
function HP.OnTradeItemAlert(btn, itemID)
    if not btn or (btn.IsForbidden and btn:IsForbidden()) then return end
    local side = HP.TradeButtonSide(btn)
    if not side then return end
    local d = GetFFD(btn)
    local had = d.tradeHadItem
    -- Blizzard's own emptiness test: an empty slot reports 0, not nil.
    local has = (itemID or 0) > 0
    d.tradeHadItem = has
    if had and not has then
        HP.tradeVacated[side] = btn.Alert
    elseif has and not had then
        local src = HP.tradeVacated[side]
        if not src then return end
        HP.tradeVacated[side] = nil
        -- Source first: dropping an item back where it came from makes src and
        -- the destination the same frame, so the restart has to win.
        HP.TradeAlertStop(src)
        local alert = btn.Alert
        if alert and alert.ItemIconAlertAnim and not (alert.IsForbidden and alert:IsForbidden()) then
            alert.ItemIconAlertAnim:Restart()
        end
    end
end

-- Dropped with the window. A trade cancelled with items still in its slots
-- would otherwise leave them flagged as filled, and the next trade's first
-- update would read as an emptying and arm the latch against nothing.
function HP.TradeAlertReset()
    wipe(HP.tradeVacated)
    for i = 1, #HP.TRADE_ALERT_BUTTONS do
        local btn = _G[HP.TRADE_ALERT_BUTTONS[i]]
        if btn then GetFFD(btn).tradeHadItem = nil end
    end
end

-- Once per session, from the pack because this window has no other owner.
function HP.TradeAlertFix()
    if HP.tradeAlertHooked then return end
    if type(_G.TradeFrame_AlertItemIfChanged) ~= "function" then return end
    HP.tradeAlertHooked = true
    hooksecurefunc("TradeFrame_AlertItemIfChanged", function(btn, itemID)
        -- Inside Blizzard's event handler: a throw would surface as an error
        -- in their update, not ours.
        pcall(HP.OnTradeItemAlert, btn, itemID)
    end)
    local f = _G.TradeFrame
    if f and not f:IsForbidden() then
        f:HookScript("OnHide", function() pcall(HP.TradeAlertReset) end)
    end
end

-- Both player names and both "Will not be traded" enchant captions. White,
-- because they sit on the panel rather than on an item.
-- The two names take font families (a player's name, in any script).
function HP.TradeTexts()
        for i, n in ipairs(HP.TRADE_TEXTS) do
            local fs = _G[n]
            if fs then
                if i <= 2 then WSkin.FontFamily(fs) else WSkin.Font(fs) end
                WSkin.White(fs)
            end
        end
end

-- THE CURRENCY ROW IS LEFT ENTIRELY ALONE -- there is no HP.TradeMoney.
--
-- Nothing in it can be touched. Settled with /euitrade against the live client
-- after five rounds:
--
--   TradePlayerInputMoneyFrame            FORBIDDEN
--   TradePlayerInputMoneyFrameGold        FORBIDDEN
--   TradePlayerInputMoneyFrameGoldMiddle  FORBIDDEN  <- the bevel ART itself
--   TradeFramePlayerInputMoneyFrame*      MISSING
--
-- Every method on a forbidden object throws, so the frame, the three edit boxes
-- and the textures drawing their bevels are all out of reach. The
-- `TradeFramePlayerInputMoneyFrame...` names read off a /framestack are not
-- globals at all, which is what most of those rounds were chasing.
--
-- The inset behind the row was the one reachable object, and boxing it just put
-- an EUI border around three Blizzard boxes -- rejected on sight. It still gets
-- its art faded via HP.TRADE_INSETS like every other inset, and that is all.
--
-- Do not try again unless /euitrade starts reporting something reachable.

-- THE ACCEPT HIGHLIGHT IS LEFT ENTIRELY ALONE.
--
-- Two attempts, both worse than stock. Squaring it to a 1px outline lost the
-- green wash that IS the signal; replacing the wash with a flat fill across the
-- highlight frame tinted the whole column, because these frames sit ABOVE the
-- item slots -- so the green landed on top of every slot instead of framing the
-- area the way Blizzard's edge glow does.
--
-- It is a transient state indicator that was already legible, and it is the one
-- thing on this window that has to read instantly. Left stock deliberately: do
-- not re-skin it without a way to see the result first.

WSkin.RegisterWindow({
    key = "trade",
    apply = function()
        HP.WhenFrameExists("TradeFrame", function() HP.ApplyTrade() end)
    end,
})

-------------------------------------------------------------------------------
--  NO SECURE TRANSFER DIALOG PACK -- it cannot be skinned.
--
--  "Are you sure you want to accept this trade?" (SecureTransferDialog) looks
--  ordinary in a /framestack, but Blizzard_SecureTransferUI.toc carries
--  `## UseSecureEnvironment: 1`, so every frame that addon creates is FORBIDDEN
--  to other addons -- same mechanism as ForbiddenNamePlate. A pack was written
--  for it and did precisely nothing: the standard `f:IsForbidden()` guard at
--  the top returned immediately, silently, with no error and nothing in the
--  frame stack to show for it.
--
--  CHECK THE .TOC FIRST. `UseSecureEnvironment: 1` is visible before a line of
--  code is written and settles the question outright -- cheaper than a
--  framestack, and far cheaper than a pack plus an options card.
-------------------------------------------------------------------------------

end

-------------------------------------------------------------------------------
--  Battleground flag carriers (ArenaEnemyMatchFrame1..5, Blizzard_Deprecated_
--  ArenaUI): Blizzard's old arena frames, which now show only in battlegrounds,
--  for the carriers of flags and orbs. Each one is a SECURE unit button in a
--  right-side MANAGED column, so this pack is visual-only: no script hook on
--  the buttons or their container (code run in their show path would leave
--  the managed-layout pass under our taint), and never a Show, Hide, SetPoint
--  or SetSize on a frame of theirs. Built once at login. Moving the column is
--  the Shifter's (an Unlock Mode mover written in the restricted environment).
--
--  Dressed as the house unit frames are: the bar pair flat inside one 1px
--  black border with a 1px line at the bars' seam, health in the carrier's
--  class colour and power in its power colour (both from the Colors page),
--  and the spec icon square at the bars' end in place of Blizzard's class
--  circle and round badge (both at alpha 0). Blizzard paints the health bar
--  its default green on every value change and update and the power bar its
--  type's colour on every power update; ours goes back on after those writes
--  only, so the grey of a carrier out of sight or offline stays. In instanced
--  PvP the class token is secret: it goes to C_ClassColor and the colour to
--  SetStatusBarColor, both of which take secrets, and is never compared.
--
--  Kept as Blizzard draws them: the faction icon, the cast bar's fill (its
--  atlas carries the cast type, uninterruptible included, and that type is
--  secret in combat) and the heal prediction segments.
-------------------------------------------------------------------------------
do
local FC = {
    FLAT = "Interface\\Buttons\\WHITE8X8",
    -- Blizzard's frame art, the black wash behind its bars, the class circle
    -- and the spec icon's badge and ring.
    ART = { "Texture", "Background", "ClassPortrait", "SpecPortrait", "SpecBorder" },
    BAR_TEXTS = {
        "HealthBarText", "HealthBarTextLeft", "HealthBarTextRight",
        "ManaBarText", "ManaBarTextLeft", "ManaBarTextRight",
    },
}

-- ok, r, g, b: unit's class colour from the Colors page, or Blizzard's shade
-- of it while the class token is secret. ok is plain; r, g, b may be secret,
-- so they only ever go to a setter.
function FC.ClassRGB(unit)
    local _, token = UnitClass(unit)
    if type(token) ~= "string" then return false end
    if not issecretvalue(token) then
        local c = EllesmereUI.GetClassColor(token)
        return true, c.r, c.g, c.b
    end
    local ok, r, g, b = EllesmereUI.GetClassColorForRestrictedUnit(unit, token)
    if ok then return true, r, g, b end
    local c = C_ClassColor.GetClassColor(token)
    if c then return true, c.r, c.g, c.b end
    return false
end

-- Every colour write on a health bar of ours: Blizzard's default green is
-- taken over by the class colour, any other write is kept.
function FC.HealthColor(bar, r, g, b)
    local d = FFD[bar]
    if not d or d.fcPaint then return end
    if issecretvalue(r) or issecretvalue(g) or issecretvalue(b) then return end
    if r ~= 0 or g ~= 1 or b ~= 0 then return end
    local ok, cr, cg, cb = FC.ClassRGB(d.fcUnit)
    if not ok then return end
    d.fcPaint = true
    bar:SetStatusBarColor(cr, cg, cb)
    d.fcPaint = false
end

-- The pre-10.0 power-type update these frames still use puts Blizzard's bar
-- texture back on every call, and the type's colour (white under the atlas
-- some types draw with). A power bar of ours goes flat again after it, in the
-- power colour from the Colors page, or the colour the atlas carried for a
-- type the page has none for.
function FC.ManaType(bar)
    local d = bar and FFD[bar]
    if not (d and d.fcMana) then return end
    bar:SetStatusBarTexture(FC.FLAT)
    if bar.lockColor then return end
    local token = bar.powerToken
    if type(token) ~= "string" or issecretvalue(token) then return end
    local c = EllesmereUI.GetPowerColor(token)
    if not c then
        c = PowerBarColor and PowerBarColor[token]
        if not (c and c.atlas) then return end
    end
    bar:SetStatusBarColor(c.r, c.g, c.b)
end

-- A bar of ours: flat fill. unit is the class colour's source for a health
-- bar (a pet's is its owner); nil marks the power bar.
function FC.Bar(bar, unit)
    if not bar or bar:IsForbidden() then return end
    local d = GetFFD(bar)
    if d.fcBar then return end
    d.fcBar = true
    if not unit then
        d.fcMana = true
        FC.ManaType(bar)
        return
    end
    d.fcUnit = unit
    bar:SetStatusBarTexture(FC.FLAT)
    hooksecurefunc(bar, "SetStatusBarColor", FC.HealthColor)
    FC.HealthColor(bar, bar:GetStatusBarColor())
end

-- The frame round a bar pair: a backing of ours under the bars at the
-- button's own level (the house fill for the EllesmereUI style, the Modern
-- colour for Modern; the shell registry swaps them live), and on a frame of
-- ours above the bars a 1px black border over their outer pixel. seam: the
-- bars touch, so a 1px line marks where.
function FC.Frame(owner, top, bottom, seam)
    local d = GetFFD(owner)
    if d.fcEdge then return d.fcEdge end
    local PP = EllesmereUI.PP
    local back = CreateFrame("Frame", nil, owner)
    back:SetPoint("TOPLEFT", top, "TOPLEFT")
    back:SetPoint("BOTTOMRIGHT", bottom, "BOTTOMRIGHT")
    back:SetFrameLevel(owner:GetFrameLevel())
    local bg = SolidTex(back, "BACKGROUND", Theme.bgR, Theme.bgG, Theme.bgB, Theme.bgA, -8)
    bg:SetAllPoints(back)
    WSkin.AdoptShell("flagcarrier", back, bg)
    local edge = CreateFrame("Frame", nil, owner)
    edge:SetAllPoints(back)
    edge:SetFrameLevel(math.max(top:GetFrameLevel(), bottom:GetFrameLevel()) + 1)
    PP.CreateBorder(edge, 0, 0, 0, 1, 1, "OVERLAY", 7)
    if seam then
        local line = CreateFrame("Frame", nil, edge)
        line:SetAllPoints(bottom)
        PP.CreateBorder(line, 0, 0, 0, 1, 1, "OVERLAY", 7)
        local c = PP.GetBorders(line)
        if c then
            c._hideBottom, c._hideLeft, c._hideRight = true, true, true
            PP.SetBorderSize(line, 1)
        end
    end
    d.fcEdge = edge
    return edge
end

-- The spec icon, square and joined to the bar pair's right edge, following
-- Blizzard's spec texture (now at alpha 0) whatever writes it: a carrier with
-- no spec shows none.
function FC.PaintSpec(box, tex, file)
    if type(file) == "nil" then
        box:Hide()
        return
    end
    tex:SetTexture(file)
    box:Show()
end

function FC.SpecIcon(owner, edge, spec, size)
    local d = GetFFD(owner)
    if d.fcSpec then return end
    local PP = EllesmereUI.PP
    local box = CreateFrame("Frame", nil, owner)
    box:SetSize(size, size)
    box:SetPoint("TOPLEFT", edge, "TOPRIGHT")
    box:SetFrameLevel(edge:GetFrameLevel())
    local tex = box:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints(box)
    tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    -- The bar pair's right edge is the icon's left one.
    PP.CreateBorder(box, 0, 0, 0, 1, 1, "OVERLAY", 7)
    local c = PP.GetBorders(box)
    if c then
        c._hideLeft = true
        PP.SetBorderSize(box, 1)
    end
    d.fcSpec = box
    hooksecurefunc(spec, "SetTexture", function(_, file) FC.PaintSpec(box, tex, file) end)
    FC.PaintSpec(box, tex, spec:GetTexture())
end

-- The trinket slot shows all the time, often empty: its icon is cropped
-- square, and its border shows only while Blizzard has an icon in it. The
-- border sits over the slot's cooldown swipe.
function FC.Trinket(cc)
    if not (cc and cc.Icon) then return end
    local d = GetFFD(cc)
    if d.fcEdge then return end
    WSkin.SquareIcon(cc.Icon)
    local edge = CreateFrame("Frame", nil, cc)
    edge:SetAllPoints(cc)
    edge:SetFrameLevel(cc:GetFrameLevel() + 3)
    EllesmereUI.PP.CreateBorder(edge, 0, 0, 0, 1, 1, "OVERLAY", 7)
    d.fcEdge = edge
    hooksecurefunc(cc.Icon, "SetTexture", function(_, file) edge:SetShown(type(file) ~= "nil") end)
    edge:SetShown(type(cc.Icon:GetTexture()) ~= "nil")
end

function FC.SkinPet(pet, unit)
    if not pet or pet:IsForbidden() then return end
    local name = pet:GetName()
    if not name then return end
    local art = _G[name .. "Texture"]
    if art then art:SetAlpha(0) end
    local hb, mb = _G[name .. "HealthBar"], _G[name .. "ManaBar"]
    FC.Bar(hb, unit)
    FC.Bar(mb)
    -- A gap parts the pet's bars already.
    if hb and mb then FC.Frame(pet, hb, mb) end
end

function FC.SkinFrame(f)
    if not f or f:IsForbidden() then return end
    local name = f:GetName()
    local d = GetFFD(f)
    if not name or d.fcSkinned then return end
    d.fcSkinned = true
    local unit = "arena" .. f:GetID()

    for _, suffix in ipairs(FC.ART) do
        local t = _G[name .. suffix]
        if t then t:SetAlpha(0) end
    end
    local hb, mb = _G[name .. "HealthBar"], _G[name .. "ManaBar"]
    FC.Bar(hb, unit)
    FC.Bar(mb)
    if hb and mb then
        local edge = FC.Frame(f, hb, mb, true)
        local spec = _G[name .. "SpecPortrait"]
        if spec then FC.SpecIcon(f, edge, spec, hb:GetHeight() + mb:GetHeight()) end
    end

    -- Name white like the windows' titles; the bar texts keep their color. A
    -- player's name, in any script: a font family.
    local nameFS = _G[name .. "Name"]
    if nameFS then
        WSkin.FontFamily(nameFS)
        WSkin.White(nameFS)
    end
    for _, suffix in ipairs(FC.BAR_TEXTS) do WSkin.Font(_G[name .. suffix]) end

    FC.Trinket(f.CC)
    local cast = f.CastingBar
    if cast and not cast:IsForbidden() then
        EllesmereUI.PP.CreateBorder(cast, 0, 0, 0, 1, 1, "OVERLAY", 7)
        if cast.Icon then WSkin.SquareIcon(cast.Icon, cast) end
        if cast.Text then WSkin.Font(cast.Text) end
    end

    FC.SkinPet(f.petFrame, unit)
end

function FC.Apply()
    for i = 1, (MAX_ARENA_ENEMIES or 5) do
        FC.SkinFrame(_G["ArenaEnemyMatchFrame" .. i])
    end
    if not FC.hooked and UnitFrameManaBar_UpdateTypeOld then
        FC.hooked = true
        hooksecurefunc("UnitFrameManaBar_UpdateTypeOld", FC.ManaType)
    end
end

WSkin.RegisterWindow({
    key = "flagcarrier",
    -- Loaded with the game on both clients; a client without it never runs the pack.
    addons = { Blizzard_Deprecated_ArenaUI = true },
    apply = FC.Apply,
})
end
