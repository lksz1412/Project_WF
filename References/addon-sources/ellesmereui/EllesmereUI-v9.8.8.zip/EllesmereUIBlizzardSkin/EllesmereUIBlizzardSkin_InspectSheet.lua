if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  Themed Inspect Sheet
--  Mirrors the Character Sheet skinning for inspected characters.
--  Shared helpers (EllesmereUI.GetUpgradeTrack, EllesmereUI.GetEnchantText)
--  are exported by CharacterSheet and loaded before this file.
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...
local skinned = false
local GetItemInfo = C_Item.GetItemInfo
local GetItemInfoInstant = C_Item.GetItemInfoInstant

-- External weak-keyed lookup table for frame state (prevents tainting Blizzard frames)
local FFD, GetFFD = EllesmereUI.NewFrameData()

-- Equipment slot lists
local EUI_ALL_SLOTS = {
    "InspectHeadSlot", "InspectNeckSlot", "InspectShoulderSlot", "InspectBackSlot",
    "InspectChestSlot", "InspectShirtSlot", "InspectTabardSlot", "InspectWristSlot",
    "InspectHandsSlot", "InspectWaistSlot", "InspectLegsSlot", "InspectFeetSlot",
    "InspectTrinket0Slot", "InspectTrinket1Slot", "InspectFinger0Slot", "InspectFinger1Slot",
    "InspectMainHandSlot", "InspectSecondaryHandSlot",
    "InspectRangedSlot",  -- WoW Forever only (nil on retail)
}

-- Slot grid layout mapping
local slotGridMap = {
    InspectHeadSlot = {col = 0, row = 0},
    InspectNeckSlot = {col = 0, row = 1},
    InspectShoulderSlot = {col = 0, row = 2},
    InspectBackSlot = {col = 0, row = 3},
    InspectChestSlot = {col = 0, row = 4},
    InspectShirtSlot = {col = 0, row = 5},
    InspectTabardSlot = {col = 0, row = 6},
    InspectWristSlot = {col = 0, row = 7},
    InspectHandsSlot = {col = 1, row = 0},
    InspectWaistSlot = {col = 1, row = 1},
    InspectLegsSlot = {col = 1, row = 2},
    InspectFeetSlot = {col = 1, row = 3},
    InspectFinger0Slot = {col = 1, row = 4},
    InspectFinger1Slot = {col = 1, row = 5},
    InspectTrinket0Slot = {col = 1, row = 6},
    InspectTrinket1Slot = {col = 1, row = 7},
    InspectMainHandSlot = {slot = "MainHand"},
    InspectSecondaryHandSlot = {slot = "SecondaryHand"},
    InspectRangedSlot = {slot = "Ranged"},  -- WoW Forever only
}

-- Drop every label a previous styling pass left on this slot. The widgets
-- are parked in per-slot cache fields and reused by the next pass: the
-- client never frees frames or font strings, so recreating them on every
-- pass would grow the widget count for the rest of the session.
local function EUI_ClearSlotLabels(slot)
    local d = GetFFD(slot)
    if d.iLvlText then d.iLvlText:Hide(); d.cachedILvlText = d.iLvlText; d.iLvlText = nil end
    if d.enchantText then d.enchantText:Hide(); d.cachedEnchantText = d.enchantText; d.enchantText = nil end
    if d.enchantHoverFrame then d.enchantHoverFrame:Hide(); d.cachedEnchantHover = d.enchantHoverFrame; d.enchantHoverFrame = nil end
    if d.upgradeText then d.upgradeText:Hide(); d.cachedUpgradeText = d.upgradeText; d.upgradeText = nil end
    if d.dpsText then d.dpsText:Hide(); d.cachedDpsText = d.dpsText; d.dpsText = nil end
end

-- WoW Forever: the slot text as that client's character sheet shows it. The
-- item level sits where this sheet's own Show Item Level says
-- (inspectItemLevelPos: heading the first line beside the slot unless set,
-- or inside the slot icon; inspectShowItemLevel false is Never). With Show
-- Item Stats on (inspectShowItemStats, off unless true) that line carries
-- the item's stats and a weapon's damage per second sits under it; the
-- enchant name comes under those. Text runs right of the left column and of
-- the ranged slot, left of the right column and of the main hand, and
-- stacks above the off hand, whose sides are taken. A label exists only for
-- what the settings show, so the lines close up. The stats line is the
-- slot's upgradeText and the damage line its dpsText.
local FV_EX, FV_GAP, FV_LINE = 5, 3, 13  -- text edge off the slot, item level to stats, weapon line pitch
local FV_WY = 7                          -- the outer weapon slots' first line, above the slot's centre
local FV_WEAPON = { InspectMainHandSlot = "L", InspectSecondaryHandSlot = "T", InspectRangedSlot = "R" }

-- One line of a slot's text, reused from the slot's cache; nothing for "".
local function ForeverLine(d, cacheKey, overlay, text, path, size, flags, shadow, c)
    if text == "" then return nil end
    local fs = d[cacheKey] or overlay:CreateFontString(nil, "OVERLAY")
    EllesmereUI.PrimeFontShadow(fs, shadow)
    fs:SetFont(path, size, flags)
    fs:SetWordWrap(false)
    fs:SetWidth(0)
    fs:SetText(text)
    fs:SetTextColor(c.r, c.g, c.b, 0.8)
    fs:ClearAllPoints()
    fs:Show()
    return fs
end

-- Returns true while the item's data or its enchant line has not arrived.
local function ForeverSlotLabels(slot, slotName, slotID, unit, itemLink, overlay, isRightColumn)
    local d = GetFFD(slot)
    local itemID = GetInventoryItemID(unit, slotID)
    if not (itemID and C_Item.IsItemDataCachedByID(itemID)) then
        if itemID then C_Item.RequestLoadItemDataByID(itemID) end
        return true
    end
    local db = EllesmereUIDB or {}
    local path = EllesmereUI.GetFontPath("blizzardSkin") or STANDARD_TEXT_FONT
    local _, _, quality = GetItemInfo(itemLink)
    local c = EllesmereUI.GetItemLevelColor(itemLink, quality)
    local side = FV_WEAPON[slotName] or (isRightColumn and "L" or "R")
    local weapon = FV_WEAPON[slotName] ~= nil

    -- Item level, in the item's colour; inside an icon it is always outlined.
    local ilvl
    local level = db.inspectShowItemLevel ~= false and C_Item.GetDetailedItemLevelInfo(itemLink)
    local iconPoint, iconY = ns.ForeverIlvlIcon(db.inspectItemLevelPos or "beside")
    if level and level > 0 then
        local layer = GetFFD(InspectFrame).ilvlOverlay or overlay
        ilvl = d.cachedILvlText or layer:CreateFontString(nil, "OVERLAY")
        EllesmereUI.PrimeFontShadow(ilvl, db.charSheetItemLevelShadow)
        ilvl:SetFont(path, db.charSheetItemLevelSize or 11,
            (iconPoint or db.charSheetItemLevelOutline) and EllesmereUI.SlugFlag("OUTLINE, SLUG") or "")
        ilvl:SetWordWrap(false)
        ilvl:SetText(level)
        ilvl:SetTextColor(c.r, c.g, c.b, 0.9)
        ilvl:ClearAllPoints()
        if iconPoint then ilvl:SetPoint(iconPoint, slot, iconPoint, 0, iconY) end
        ilvl:Show()
        d.iLvlText = ilvl
    end
    local head = not iconPoint and ilvl or nil  -- the item level when it heads the first line

    -- Stats (or armor) and a weapon's damage per second, in the item's colour
    -- unless the upgrade track has a colour of its own.
    local showStats = db.inspectShowItemStats == true
    local sc = db.charSheetUpgradeTrackUseColor and db.charSheetUpgradeTrackColor or c
    local size = db.charSheetUpgradeTrackSize or 11
    local flags = db.charSheetUpgradeTrackOutline and EllesmereUI.SlugFlag("OUTLINE, SLUG") or ""
    local stats = ForeverLine(d, "cachedUpgradeText", overlay, showStats and ns.ForeverStatText(itemLink) or "",
        path, size, flags, db.charSheetUpgradeTrackShadow, sc)
    d.upgradeText = stats
    local dps = weapon and ForeverLine(d, "cachedDpsText", overlay, showStats and ns.ForeverDpsText(itemLink) or "",
        path, size, flags, db.charSheetUpgradeTrackShadow, sc) or nil
    d.dpsText = dps

    -- Enchant name: plain, or outlined and tinted from the item's colour
    -- under Colored Text; capped at 45% of the gap between the two columns.
    local ench, pending = nil, false
    if db.inspectShowEnchants ~= false then
        local raw = EllesmereUI.GetEnchantText(slotID, unit) or ""
        if raw == "" then
            -- An enchanted item whose tooltip has not arrived: no label yet.
            local linkEnchant = tonumber(itemLink:match("item:%d+:(%d+)"))
            pending = linkEnchant ~= nil and linkEnchant ~= 0
        else
            ench = d.cachedEnchantText or overlay:CreateFontString(nil, "OVERLAY")
            local esize = db.inspectEnchantSize or db.charSheetEnchantSize or 9
            if db.inspectEnchantNames then
                ench:SetFont(path, esize, EllesmereUI.SlugFlag("OUTLINE, SLUG"))
                ench:SetTextColor(c.r + (1 - c.r) * 0.5, c.g + (1 - c.g) * 0.5, c.b + (1 - c.b) * 0.5, 0.9)
            else
                ench:SetFont(path, esize, "")
                ench:SetTextColor(1, 1, 1, 0.8)
            end
            local lr = _G.InspectHeadSlot and _G.InspectHeadSlot:GetRight()
            local rl = _G.InspectHandsSlot and _G.InspectHandsSlot:GetLeft()
            local maxW = 0
            if lr and rl and not (issecretvalue and (issecretvalue(lr) or issecretvalue(rl))) and rl > lr then
                maxW = (rl - lr) * 0.45
            end
            ench:SetWordWrap(false)
            ench:SetWidth(maxW)
            ench:SetText(ns.ForeverEnchantName(raw))
            ench:ClearAllPoints()
            ench:Show()
            d.enchantText = ench
        end
    end

    if side == "T" then
        -- Upward from the slot, centred: the enchant, the damage, the first line.
        local y = 3
        if ench then
            ench:SetPoint("BOTTOM", slot, "TOP", 0, y)
            ench:SetJustifyH("CENTER")
            y = y + ench:GetStringHeight() + 1
        end
        if dps then
            dps:SetPoint("BOTTOM", slot, "TOP", 0, y)
            y = y + dps:GetStringHeight() + 1
        end
        if head and stats then
            local w = head:GetStringWidth() + FV_GAP + stats:GetStringWidth()
            head:SetPoint("BOTTOMLEFT", slot, "TOP", -w / 2, y)
            stats:SetPoint("BOTTOMLEFT", head, "BOTTOMRIGHT", FV_GAP, 0)
        elseif head or stats then
            (head or stats):SetPoint("BOTTOM", slot, "TOP", 0, y)
        end
        return pending
    end

    local point, rel, x = "LEFT", "RIGHT", FV_EX
    if side == "L" then point, rel, x = "RIGHT", "LEFT", -FV_EX end
    -- The outer weapon slots' lines stop short of the window's edge.
    if weapon then
        local hi, lo
        if side == "L" then
            hi, lo = slot:GetLeft(), InspectFrame:GetLeft()
        else
            hi, lo = InspectFrame:GetRight(), slot:GetRight()
        end
        if hi and lo and not (issecretvalue and (issecretvalue(hi) or issecretvalue(lo))) then
            local room = hi - lo - FV_EX - 6
            if room > 0 then
                if stats then
                    stats:SetWidth(math.max(1, room - (head and head:GetStringWidth() + FV_GAP or 0)))
                    stats:SetJustifyH(point)
                end
                if dps then dps:SetWidth(room); dps:SetJustifyH(point) end
                if ench and ench:GetWidth() > room then ench:SetWidth(room) end
            end
        end
    end
    local y = weapon and FV_WY or 10
    if head then
        head:SetPoint(point, slot, rel, x, y)
        if stats then stats:SetPoint(point, head, rel, x < 0 and -FV_GAP or FV_GAP, 0) end
    elseif stats then
        stats:SetPoint(point, slot, rel, x, y)
    end
    -- A weapon's lines stack down from the first; any other slot's enchant
    -- keeps its spot under the first line.
    local enchY = -5
    if weapon then
        if head or stats then y = y - FV_LINE end
        if dps then
            dps:SetPoint(point, slot, rel, x, y)
            y = y - FV_LINE
        end
        enchY = math.min(y, -3) - 2
    end
    if ench then
        ench:SetPoint(point, slot, rel, x, enchY)
        ench:SetJustifyH(point)
    end
    return pending
end

-- Returns true when the slot's item or tooltip data has not arrived yet (its
-- labels wait for it: RefreshSlotStyles reads the slot again as it comes).
local function EUI_UpdateSlotStyle(slotName, slotID, textOverlayFrame, isRightColumn)
    local slot = _G[slotName]
    if not slot or not textOverlayFrame then return end
    local pending = false

    -- Blizzard reuses the SAME global slot frames (InspectHeadSlot etc) for
    -- every target, so a label belongs to whoever was inspected last until
    -- something clears it. The create-once guards below are no-ops while a
    -- stale label exists, which left the previous target's numbers sitting
    -- next to the new target's icons. Only RefreshSlotStyles used to clear,
    -- so a sheet opened without a following INSPECT_READY (the client already
    -- had that unit cached) kept the old values indefinitely -- the reported
    -- "shows the first player's item levels". Clear here instead, so EVERY
    -- styling pass rebuilds from the live item link no matter who calls.
    EUI_ClearSlotLabels(slot)

    local skipLabels = (slotName == "InspectShirtSlot" or slotName == "InspectTabardSlot")
    -- WoW Forever's ranged slot sits right of the off hand, so there the off
    -- hand's labels stack above it (the ranged slot's go right, as by default).
    local above = slotName == "InspectSecondaryHandSlot" and InspectRangedSlot ~= nil

    local inspectUnit = InspectFrame and InspectFrame.unit
    if not inspectUnit then return end

    local fontPath = EllesmereUI.GetFontPath("blizzardSkin") or STANDARD_TEXT_FONT
    local itemLink = GetInventoryItemLink(inspectUnit, slotID)
    GetFFD(slot).itemLink = itemLink

    local borderR, borderG, borderB = 0.4, 0.4, 0.4
    if itemLink then
        local rarity = C_Item.GetItemQualityByID(itemLink)
        if rarity then
            borderR, borderG, borderB = C_Item.GetItemQualityColor(rarity)
        end
    end

    if EllesmereUI and EllesmereUI.PanelPP then
        EllesmereUI.PanelPP.SetBorderColor(slot, borderR, borderG, borderB, 1)
    end
    GetFFD(slot).border = true

    -- WoW Forever lays its slot text out as that client's character sheet does.
    if ns.ForeverStatText then
        if not itemLink or skipLabels then return false end
        return ForeverSlotLabels(slot, slotName, slotID, inspectUnit, itemLink, textOverlayFrame, isRightColumn)
    end

    -- Item level label (font size matches CharacterSheet)
    if itemLink and not GetFFD(slot).iLvlText and not skipLabels then
        -- GetItemInfo's itemLevel is the cached base level, wrong for upgrade-track
        -- pieces; the detailed level reads the link's bonus IDs.
        local _, _, quality, baseIlvl = GetItemInfo(itemLink)
        local ilvl = C_Item.GetDetailedItemLevelInfo(itemLink) or baseIlvl
        if ilvl and ilvl > 0 then
            local itemLevelSize = EllesmereUIDB and EllesmereUIDB.charSheetItemLevelSize or 11
            local ilvlText = GetFFD(slot).cachedILvlText or textOverlayFrame:CreateFontString(nil, "OVERLAY")
            ilvlText:SetFont(fontPath, itemLevelSize, "")
            ilvlText:SetTextColor(1, 1, 1, 0.8)
            ilvlText:SetJustifyH("CENTER")
            ilvlText:ClearAllPoints()

            if above then
                ilvlText:SetPoint("BOTTOM", slot, "TOP", 0, 3)
            elseif slotName == "InspectMainHandSlot" then
                ilvlText:SetPoint("CENTER", slot, "LEFT", -15, 10)
            elseif slotName == "InspectSecondaryHandSlot" then
                ilvlText:SetPoint("CENTER", slot, "RIGHT", 15, 10)
            elseif isRightColumn then
                ilvlText:SetPoint("CENTER", slot, "LEFT", -15, 10)
            else
                ilvlText:SetPoint("CENTER", slot, "RIGHT", 15, 10)
            end

            ilvlText:SetText(ilvl)

            local displayColor = EllesmereUI.GetItemLevelColor(itemLink, quality)
            ilvlText:SetTextColor(displayColor.r, displayColor.g, displayColor.b, 0.9)
            ilvlText:Show()

            GetFFD(slot).iLvlText = ilvlText
        else
            pending = true
        end
    end

    -- Enchant label: its icon (the name on hover), or under Text the name
    -- itself, outlined and tinted from the item level's color, as on the
    -- character sheet (a missing enchant keeps its red icon). WoW Forever's
    -- enchants carry no icon, so the name always shows there (plain unless
    -- Colored Text), named as that client's character sheet names it.
    local enchantText = itemLink and not GetFFD(slot).enchantText and not skipLabels
        and EllesmereUI.GetEnchantText(slotID, inspectUnit)
    -- An enchanted item whose tooltip has not arrived reads as no enchant:
    -- no label until it does, never the red missing-enchant icon.
    if enchantText == "" then
        local linkEnchant = tonumber(itemLink:match("item:%d+:(%d+)"))
        if linkEnchant and linkEnchant ~= 0 then
            pending = true
            enchantText = nil
        end
    end
    if enchantText then
        local iconOnly, tooltipText, _, hasEnchant = ns.ParseEnchantLabel(enchantText, slotID, itemLink, inspectUnit)
        if ns.ForeverEnchantName then tooltipText = ns.ForeverEnchantName(enchantText) end

        local showEnchants = (not EllesmereUIDB) or (EllesmereUIDB.inspectShowEnchants ~= false)
        local styled = EllesmereUIDB and EllesmereUIDB.inspectEnchantNames
        local useName = (styled or EllesmereUI.IS_FOREVER) and hasEnchant and tooltipText and tooltipText ~= ""
        local labelText = useName and tooltipText or iconOnly

        if showEnchants and labelText and labelText ~= "" then
            -- The inspect sheet's own size, else the character sheet's
            local enchantSize = (EllesmereUIDB and (EllesmereUIDB.inspectEnchantSize or EllesmereUIDB.charSheetEnchantSize)) or 9
            local enchantLabel = GetFFD(slot).cachedEnchantText or textOverlayFrame:CreateFontString(nil, "OVERLAY")
            if useName and styled then
                enchantLabel:SetFont(fontPath, enchantSize, EllesmereUI.SlugFlag("OUTLINE, SLUG"))
                local _, _, quality = GetItemInfo(itemLink)
                local c = EllesmereUI.GetItemLevelColor(itemLink, quality)
                enchantLabel:SetTextColor(c.r + (1 - c.r) * 0.5, c.g + (1 - c.g) * 0.5, c.b + (1 - c.b) * 0.5, 0.9)
            else
                enchantLabel:SetFont(fontPath, enchantSize, "")
                enchantLabel:SetTextColor(1, 1, 1, 0.8)
            end
            -- A name is capped at 45% of the gap between the two columns, so
            -- it never runs over the model or into the other column (cut
            -- short; the full name stays on the hover).
            local maxW
            if useName then
                local lr = _G.InspectHeadSlot and _G.InspectHeadSlot:GetRight()
                local rl = _G.InspectHandsSlot and _G.InspectHandsSlot:GetLeft()
                if lr and rl and not (issecretvalue and (issecretvalue(lr) or issecretvalue(rl)))
                    and rl > lr then
                    maxW = (rl - lr) * 0.45
                end
            end
            enchantLabel:SetWordWrap(false)
            enchantLabel:SetWidth(maxW or 0)
            enchantLabel:ClearAllPoints()

            -- Justified toward its slot, so a capped name hugs it
            if above then
                local lvlText = GetFFD(slot).iLvlText
                enchantLabel:SetPoint("BOTTOM", lvlText or slot, "TOP", 0, lvlText and 1 or 3)
                enchantLabel:SetJustifyH("CENTER")
            elseif slotName == "InspectMainHandSlot" then
                enchantLabel:SetPoint("RIGHT", slot, "LEFT", -5, -5)
                enchantLabel:SetJustifyH("RIGHT")
            elseif slotName == "InspectSecondaryHandSlot" then
                enchantLabel:SetPoint("LEFT", slot, "RIGHT", 5, -5)
                enchantLabel:SetJustifyH("LEFT")
            elseif isRightColumn then
                enchantLabel:SetPoint("RIGHT", slot, "LEFT", -5, -5)
                enchantLabel:SetJustifyH("RIGHT")
            else
                enchantLabel:SetPoint("LEFT", slot, "RIGHT", 5, -5)
                enchantLabel:SetJustifyH("LEFT")
            end

            enchantLabel:SetText(labelText)
            enchantLabel:Show()
            GetFFD(slot).enchantText = enchantLabel

            local hoverFrame = GetFFD(slot).cachedEnchantHover or CreateFrame("Frame", nil, textOverlayFrame)
            hoverFrame:SetSize(20, 20)
            hoverFrame:SetFrameLevel(textOverlayFrame:GetFrameLevel() + 20)
            hoverFrame:ClearAllPoints()
            if above then
                hoverFrame:SetPoint("CENTER", enchantLabel, "CENTER", 0, 0)
            elseif slotName == "InspectMainHandSlot" then
                hoverFrame:SetPoint("RIGHT", slot, "LEFT", -5, -5)
            elseif slotName == "InspectSecondaryHandSlot" then
                hoverFrame:SetPoint("LEFT", slot, "RIGHT", 5, -5)
            elseif isRightColumn then
                hoverFrame:SetPoint("RIGHT", slot, "LEFT", -5, -5)
            else
                hoverFrame:SetPoint("LEFT", slot, "RIGHT", 5, -5)
            end
            hoverFrame:EnableMouse(true)

            hoverFrame:SetScript("OnEnter", function()
                if tooltipText and tooltipText ~= "" and EllesmereUI.ShowWidgetTooltip then
                    EllesmereUI.ShowWidgetTooltip(hoverFrame, tooltipText)
                end
            end)
            hoverFrame:SetScript("OnLeave", function()
                EllesmereUI.HideWidgetTooltip()
            end)
            hoverFrame:Show()

            GetFFD(slot).enchantHoverFrame = hoverFrame
        end
    end

    -- Upgrade track label (font size matches CharacterSheet)
    if itemLink and not GetFFD(slot).upgradeText and GetFFD(slot).iLvlText and not skipLabels then
        local upgradeTrackSize = EllesmereUIDB and EllesmereUIDB.charSheetUpgradeTrackSize or 11
        local upgradeText, upgradeColor = EllesmereUI.GetUpgradeTrack(itemLink)
        if upgradeText and upgradeText ~= "" then
            local upgradeLabel = GetFFD(slot).cachedUpgradeText or textOverlayFrame:CreateFontString(nil, "OVERLAY")
            upgradeLabel:SetFont(fontPath, upgradeTrackSize, "")
            upgradeLabel:SetTextColor(upgradeColor.r, upgradeColor.g, upgradeColor.b, 0.8)
            upgradeLabel:SetJustifyH("CENTER")
            upgradeLabel:ClearAllPoints()

            if above then
                upgradeLabel:SetPoint("LEFT", GetFFD(slot).iLvlText, "RIGHT", 3, 0)
            elseif slotName == "InspectMainHandSlot" then
                upgradeLabel:SetPoint("RIGHT", GetFFD(slot).iLvlText, "LEFT", -3, 0)
            elseif slotName == "InspectSecondaryHandSlot" then
                upgradeLabel:SetPoint("LEFT", GetFFD(slot).iLvlText, "RIGHT", 3, 0)
            elseif isRightColumn then
                upgradeLabel:SetPoint("RIGHT", GetFFD(slot).iLvlText, "LEFT", -3, 0)
            else
                upgradeLabel:SetPoint("LEFT", GetFFD(slot).iLvlText, "RIGHT", 3, 0)
            end

            upgradeLabel:SetText("(" .. upgradeText .. ")")
            upgradeLabel:Show()
            GetFFD(slot).upgradeText = upgradeLabel
        end
    end
    return pending
end

-- Apply tab visibility: show labels only on Tab 1
-- Similar to ApplyTabVisibility in CharacterSheet.lua
-- Takes a boolean parameter: true = show labels (Tab 1), false = hide labels (Tab 2/3)
local function ApplyTabVisibility(showLabels)
    local frame = InspectFrame
    if not frame then return end

    -- Show/hide individual labels based on settings
    local showItemLevel = (not EllesmereUIDB) or (EllesmereUIDB.inspectShowItemLevel ~= false)
    -- WoW Forever: the stats and damage lines exist only while Show Item
    -- Stats is on (the track's key is retail's alone)
    local showUpgradeTrack = ns.ForeverStatText ~= nil
        or (not EllesmereUIDB) or (EllesmereUIDB.inspectShowUpgradeTrack ~= false)
    local showEnchants = (not EllesmereUIDB) or (EllesmereUIDB.inspectShowEnchants ~= false)

    for slotName, _ in pairs(slotGridMap) do
        local slot = _G[slotName]
        if slot then
            -- Only show labels if on Tab 1 and settings allow
            if GetFFD(slot).iLvlText then
                GetFFD(slot).iLvlText:SetShown(showLabels and showItemLevel)
            end
            if GetFFD(slot).upgradeText then
                GetFFD(slot).upgradeText:SetShown(showLabels and showUpgradeTrack)
            end
            -- WoW Forever: a weapon's damage line goes with its stats
            if GetFFD(slot).dpsText then
                GetFFD(slot).dpsText:SetShown(showLabels and showUpgradeTrack)
            end
            if GetFFD(slot).enchantText then
                GetFFD(slot).enchantText:SetShown(showLabels and showEnchants)
            end
            -- Its hover spot too, or the other tabs keep an invisible tooltip
            if GetFFD(slot).enchantHoverFrame then
                GetFFD(slot).enchantHoverFrame:SetShown(showLabels and showEnchants)
            end
        end
    end

    -- Hide/show avg ilvl + M+ score
    local frame = InspectFrame
    if frame then
        if GetFFD(frame).avgIlvlText then GetFFD(frame).avgIlvlText:SetShown(showLabels) end
        if GetFFD(frame).mPlusScoreText then GetFFD(frame).mPlusScoreText:SetShown(showLabels) end
    end
end

-- Calculate average item level from inspected player
local function CalculateAverageItemLevel()
    if not InspectFrame or not InspectFrame.unit then
        return 0
    end

    local unit = InspectFrame.unit

    -- Use the proper WoW API for getting inspect item level
    if C_PaperDollInfo and C_PaperDollInfo.GetInspectItemLevel then
        local ilvl = C_PaperDollInfo.GetInspectItemLevel(unit)
        if ilvl and ilvl > 0 then
            return ilvl
        end
    end

    return 0
end

local function SkinInspectSheet()
    if skinned then return end
    skinned = true

    local frame = InspectFrame
    if not frame then return end


    local FRAME_BG_R, FRAME_BG_G, FRAME_BG_B = 0.03, 0.045, 0.05

    -- Create custom background texture FIRST before hiding anything
    if GetFFD(frame).bg then
        GetFFD(frame).bg:Show()
    else
        local bg, bgOverlay = ns.SheetBackdrop(frame)
        GetFFD(frame).bg = bg
        GetFFD(frame).bgOverlay = bgOverlay
        -- Follows the Character Sheet window's style pick (the two share one
        -- enable + style setting).
        if ns.WSkin and ns.WSkin.AdoptShell then
            ns.WSkin.AdoptShell("charsheet", frame, bg, GetFFD(frame).bgOverlay)
        end
    end

    -- Standard window-reskin border (the AdventureMap_TopBorder atlas texture),
    -- same as the character sheet and every other skinned Blizzard window.
    if ns.WSkin and ns.WSkin.AtlasBorder then ns.WSkin.AtlasBorder(frame) end

    -- Hide Blizzard backgrounds and borders
    for _, elem in ipairs({frame.NineSlice, frame.Background, frame.TitleBg,
                           frame.TopTileStreaks, frame.Portrait, frame.Bg,
                           InspectModelFrameBackgroundOverlay,
                           InspectModelFrameBorderRight, InspectModelFrameBorderLeft,
                           InspectModelFrameBorderBottom, InspectModelFrameBorderTop}) do
        if elem then elem:Hide() end
    end


    -- Hide Blizzard Bg textures (our atlas bg covers everything)
    if InspectFrameBg then InspectFrameBg:SetAlpha(0) end
    if InspectFrameInset and InspectFrameInset.Bg then InspectFrameInset.Bg:SetAlpha(0) end

    -- Create model background (matches character sheet: character-bg.png, no glow/gradient)
    -- Deferred until InspectModelFrame exists (created lazily by Blizzard)
    local function TryCreateModelBg()
        if GetFFD(frame).modelBgFrame then return end
        local myModel = _G.InspectModelFrame
        if not myModel then return end
        local bgFrame = CreateFrame("Frame", nil, myModel)
        bgFrame:SetFrameLevel(math.max(1, myModel:GetFrameLevel() - 1))
        bgFrame:ClearAllPoints()
        -- Match the Character sheet: span the backdrop across the full gear
        -- width (left gear column to right gear column) and down to the model
        -- bottom, so character-bg.png covers the whole gear + model area. The
        -- inspect model sits at Blizzard's default center spot, so its right edge
        -- stops short of the right gear; anchor the right edge to the right gear
        -- column instead. Falls back progressively if the slots are not up yet.
        local headSlot  = _G.InspectHeadSlot
        local handsSlot = _G.InspectHandsSlot
        if headSlot and handsSlot then
            bgFrame:SetPoint("TOPLEFT", headSlot, "TOPLEFT", -8, 10)
            bgFrame:SetPoint("RIGHT", handsSlot, "RIGHT", 8, 0)
            bgFrame:SetPoint("BOTTOM", myModel, "BOTTOM", 0, -18)
        elseif headSlot then
            bgFrame:SetPoint("TOPLEFT", headSlot, "TOPLEFT", -8, 10)
            bgFrame:SetPoint("BOTTOMRIGHT", myModel, "BOTTOMRIGHT", 0, -18)
        else
            bgFrame:SetPoint("TOPLEFT", myModel, "TOPLEFT", -8, 10)
            bgFrame:SetPoint("BOTTOMRIGHT", myModel, "BOTTOMRIGHT", 0, -18)
        end
        local bgTex = bgFrame:CreateTexture(nil, "BACKGROUND")
        bgTex:SetAllPoints(bgFrame)
        bgTex:SetTexture("Interface\\AddOns\\EllesmereUIBlizzardSkin\\Media\\character-bg.png")
        bgTex:SetAlpha(1)

        GetFFD(frame).modelBg      = bgTex
        GetFFD(frame).modelBgFrame = bgFrame
    end
    TryCreateModelBg()
    -- Retry on show in case model frame wasn't ready on first skin.
    -- Staggered retries: Blizzard creates InspectModelFrame lazily
    -- after the inspect target is set, which can take multiple frames.
    -- HookScript only once to prevent accumulation on repeated reskins.
    if not GetFFD(frame)._modelBgHooked then
        GetFFD(frame)._modelBgHooked = true
        frame:HookScript("OnShow", function()
            C_Timer.After(0, TryCreateModelBg)
            C_Timer.After(0.2, TryCreateModelBg)
            C_Timer.After(0.5, TryCreateModelBg)
        end)
    end

    -- Hide portrait (separate handling to ensure it's fully hidden)
    if InspectFramePortrait then
        InspectFramePortrait:Hide()
        InspectFramePortrait:SetAlpha(0)
    end

    -- Hide TopTileStreaks explicitly
    if frame.TopTileStreaks then
        frame.TopTileStreaks:Hide()
        frame.TopTileStreaks:SetAlpha(0)
    end

    -- Hide InspectModelScene ControlFrame (similar to CharacterModelScene in CharacterSheet)
    if InspectModelScene then
        if InspectModelScene.ControlFrame then
            InspectModelScene.ControlFrame:SetAlpha(0)
            InspectModelScene.ControlFrame:EnableMouse(false)
        end
    end

    -- Hide individual control buttons and textures
    local controlButtons = {
        "InspectModelFrameControlFrameZoomInButton",
        "InspectModelFrameControlFrameZoomOutButton",
        "InspectModelFrameControlFramePanButton",
        "InspectModelFrameControlFrameRotateLeftButton",
        "InspectModelFrameControlFrameRotateRightButton",
        "InspectModelFrameControlFrameRotateResetButton",
        "InspectModelFrameControlFrameLeft",
        "InspectModelFrameControlFrameMiddle",
        "InspectModelFrameControlFrameRight",
    }
    for _, buttonName in ipairs(controlButtons) do
        local btn = _G[buttonName]
        if btn then
            btn:SetAlpha(0)
            btn:EnableMouse(false)
        end
    end

    -- Hide InspectModelFrameBorder edges and corners explicitly
    for _, border in ipairs({InspectModelFrameBorderBottom, InspectModelFrameBorderLeft,
                             InspectModelFrameBorderTop, InspectModelFrameBorderRight,
                             InspectModelFrameBorderBottomRight, InspectModelFrameBorderBottomLeft,
                             InspectModelFrameBorderTopRight, InspectModelFrameBorderTopLeft,
                             InspectModelFrameBorderBottom2}) do
        if border then
            border:Hide()
            border:SetAlpha(0)
        end
    end

    -- Hide InspectModelFrameBackgroundOverlay explicitly
    if InspectModelFrameBackgroundOverlay then
        InspectModelFrameBackgroundOverlay:Hide()
        InspectModelFrameBackgroundOverlay:SetAlpha(0)
    end

    -- Hide InspectFrameInset.NineSlice (borders) but keep the frame for background
    if InspectFrameInset then
        if InspectFrameInset.NineSlice then
            InspectFrameInset.NineSlice:Hide()
            InspectFrameInset.NineSlice:SetAlpha(0)
        end
    end

    -- Hide InspectModelFrameBackground corners
    for _, corner in ipairs({InspectModelFrameBackgroundTopLeft, InspectModelFrameBackgroundTopRight,
                             InspectModelFrameBackgroundBotLeft, InspectModelFrameBackgroundBotRight}) do
        if corner then
            corner:Hide()
            corner:SetAlpha(0)
        end
    end

    if frame.PaperDollFrame and frame.PaperDollFrame.InnerBorder then
        for _, name in ipairs({"Top", "Bottom", "Left", "Right", "TopLeft", "TopRight", "BottomLeft", "BottomRight"}) do
            if frame.PaperDollFrame.InnerBorder[name] then
                frame.PaperDollFrame.InnerBorder[name]:Hide()
            end
        end
    end

    -- Hide PVP Frame background elements. Frames other addons parent in here
    -- are theirs to draw (see WSkin.IsForeignFrame), and the WoW Forever PvP
    -- frame keeps all of its content in one unnamed child, MainInfoFrame.
    local IsForeign = ns.WSkin and ns.WSkin.IsForeignFrame
    if InspectPVPFrame then
        local content = InspectPVPFrame.MainInfoFrame
        local children = { InspectPVPFrame:GetChildren() }
        for i = 1, #children do
            local child = children[i]
            if child and child ~= content and not child:GetName()
               and not (IsForeign and IsForeign(child, InspectPVPFrame)) then
                child:Hide()
            end
        end
    end

    -- Hide Guild Frame background elements
    if InspectGuildFrame then
        local children = { InspectGuildFrame:GetChildren() }
        for i = 1, #children do
            local child = children[i]
            if child and not child:GetName()
               and not (IsForeign and IsForeign(child, InspectGuildFrame)) then
                child:Hide()
            end
        end
    end

    -- Hide unnamed decoration frames in main InspectFrame
    local children = { frame:GetChildren() }
    for i = 1, #children do
        local child = children[i]
        if child and not child:GetName() and child:GetObjectType() == "Frame"
           and not (IsForeign and IsForeign(child, frame)) then
            -- Only hide if it's not one of our known frames and not the TitleFrame or title parent
            local isTitleFrame = (frame.TitleFrame and child == frame.TitleFrame)
            local isTitleParent = (_G.inspectFrameTitleText and child == _G.inspectFrameTitleText:GetParent())
            if child ~= frame.PaperDollFrame and child ~= InspectPVPFrame and child ~= InspectGuildFrame
               and not isTitleFrame and not isTitleParent then
                child:Hide()
            end
        end
    end

    -- Add pixel-perfect border to the frame
    if EllesmereUI and EllesmereUI.PanelPP then
        EllesmereUI.PanelPP.CreateBorder(frame, 0.2, 0.2, 0.2, 1, 1, "OVERLAY", 7)
    end

    -- Style close button
    local closeBtn = frame.CloseButton or _G.InspectFrameCloseButton
    if closeBtn and ns.WSkin and ns.WSkin.CloseButton then ns.WSkin.CloseButton(closeBtn) end

    -- Restyle Blizzard's Talents + View (dressing room) buttons in place.
    -- User clicks the actual Blizzard button so the secure handler fires
    -- natively with no addon taint in the call stack.
    do
        local fontPath = EllesmereUI.GetFontPath("blizzardSkin") or STANDARD_TEXT_FONT
        -- Narrower beside Forever's three-slot weapon row.
        local BTN_W, BTN_H = InspectRangedSlot and 76 or 90, 21
        local BTN_Y = 8

        local function RestyleButton(btn, labelText, anchor, anchorPoint, xOff)
            if not btn then return end
            local ffd = GetFFD(btn)
            if ffd.restyled then return end
            ffd.restyled = true

            btn:ClearAllPoints()
            btn:SetPoint(anchor, frame, anchorPoint, xOff, BTN_Y)
            btn:SetSize(BTN_W, BTN_H)
            btn:SetFrameLevel(frame:GetFrameLevel() + 20)

            -- Standard Blizzard-window-skin button look: dark fill + theme
            -- border + hover highlight. WSkin.Button fades the native textures.
            if ns.WSkin and ns.WSkin.Button then ns.WSkin.Button(btn) end

            -- Hide the native label (the View button is a dressing-room icon,
            -- not "Transmog") and draw our own, white like other skinned buttons.
            for _, region in ipairs({ btn:GetRegions() }) do
                if region.GetObjectType and region:GetObjectType() == "FontString" then
                    region:SetTextColor(0, 0, 0, 0)
                end
            end
            local label = btn:CreateFontString(nil, "OVERLAY")
            label:SetFont(fontPath, 10, "")
            label:SetPoint("CENTER", btn, "CENTER", 0, 0)
            label:SetJustifyH("CENTER")
            label:SetText(labelText)
            -- A translated label wider than the button shrinks to fit (never under 8), then is cut.
            local room = BTN_W - 6
            local textW = label:GetStringWidth()
            if textW and textW > room then
                label:SetFont(fontPath, math.max(8, math.floor(10 * room / textW)), "")
            end
            label:SetWidth(room)
            label:SetWordWrap(false)
            label:SetTextColor(1, 1, 1, 1)
            ffd.label = label

            btn:SetAlpha(1)
            btn:EnableMouse(true)
            btn:Show()
        end

        -- Suppress other unnamed buttons in InspectPaperDollItemsFrame.
        -- Never touch buttons other addons parent in here (theirs to run).
        local paperDollItemsFrame = InspectPaperDollItemsFrame
        if paperDollItemsFrame then
            local IsForeignBtn = ns.WSkin and ns.WSkin.IsForeignFrame
            -- Retail only: WoW Forever's inspect window has no Talents button.
            local talentsBtn = paperDollItemsFrame.InspectTalents
            local children2 = { paperDollItemsFrame:GetChildren() }
            for i = 1, #children2 do
                local child = children2[i]
                if child and child:GetObjectType() == "Button" and not child:GetName()
                   and child ~= talentsBtn
                   and not (IsForeignBtn and IsForeignBtn(child, paperDollItemsFrame)) then
                    child:SetAlpha(0)
                    child:EnableMouse(false)
                end
            end
            RestyleButton(talentsBtn, EllesmereUI.L("Talents"), "BOTTOMRIGHT", "BOTTOMRIGHT", -7)
        end

        -- WoW Forever: Blizzard keeps the View button hidden there, and it
        -- stays hidden (the room left of the main hand is its text's).
        if not EllesmereUI.IS_FOREVER then
            local blizViewBtn = InspectPaperDollFrame and InspectPaperDollFrame.ViewButton
            RestyleButton(blizViewBtn, EllesmereUI.L("Transmog"), "BOTTOMLEFT", "BOTTOMLEFT", 10)
        end
    end

    -- Hide slot wrapper frames
    for _, slotName in ipairs(EUI_ALL_SLOTS) do
        local frameName = slotName .. "Frame"
        if _G[frameName] then
            _G[frameName]:Hide()
        end
    end

    -- Show actual slot buttons and style them
    for _, slotName in ipairs(EUI_ALL_SLOTS) do
        local slot = _G[slotName]
        -- WoW Forever: the slot dress of that client's character sheet (the
        -- bronze frame off, a grey square and a 2px border coloured by the
        -- item in EUI_UpdateSlotStyle).
        if slot and ns.ForeverSkinSlot then
            slot:Show()
            ns.ForeverSkinSlot(slot, slotName)
            local parent = slot:GetParent()
            if parent then parent:Show() end
        elseif slot then
            slot:Show()

            -- Hide ALL unnamed Texturen in den Slots (die Dekoration)
            local regions = { slot:GetRegions() }
            for i = 1, #regions do
                local region = regions[i]
                if region and region:IsObjectType("Texture") then
                    local regionName = region:GetName()
                    -- Hide nur unnamed Texturen (nicht die Icon)
                    if not regionName or regionName ~= (slotName .. "IconTexture") then
                        region:SetAlpha(0)
                    end
                end
            end

            -- Hide Blizzard border and textures
            if slot.IconBorder then
                slot.IconBorder:Hide()
            end
            if slot.IconOverlay then
                slot.IconOverlay:Hide()
            end
            if slot.IconOverlay2 then
                slot.IconOverlay2:Hide()
            end

            -- Crop icon
            if slot.icon then
                local z = (EllesmereUIDB and EllesmereUIDB.charSheetIconZoom) or 0.07
                slot.icon:SetTexCoord(z, 1 - z, z, 1 - z)
            end

            local normalTexture = _G[slotName .. "NormalTexture"]
            if normalTexture then
                normalTexture:Hide()
            end

            -- Get item rarity for border color
            local itemLink = GetInventoryItemLink("inspect", slot:GetID())
            local borderR, borderG, borderB = 0.4, 0.4, 0.4  -- Default gray
            if itemLink then
                local _, _, rarity = GetItemInfo(itemLink)
                if rarity then
                    borderR, borderG, borderB = C_Item.GetItemQualityColor(rarity)
                end
            end

            -- Add rarity-colored border
            if EllesmereUI and EllesmereUI.PanelPP then
                EllesmereUI.PanelPP.CreateBorder(slot, borderR, borderG, borderB, 1, 2, "OVERLAY", 7)
            end

            local parent = slot:GetParent()
            if parent then
                parent:Show()
            end
        end
    end

    -- Grid layout: 2 columns, 8 rows
    local cellWidth = 280
    local cellHeight = 41
    local gridStartX = 10
    local gridStartY = -60

    -- Create overlay frame for text labels (above items, transparent, no mouse input)
    -- Reuse existing overlay to prevent frame multiplication on repeated reskins
    local textOverlayFrame = GetFFD(frame).textOverlayFrame
    if not textOverlayFrame then
        textOverlayFrame = CreateFrame("Frame", "EUI_InspectSheet_TextOverlay", frame)
        textOverlayFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
        textOverlayFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
        textOverlayFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
        textOverlayFrame:EnableMouse(false)
        GetFFD(frame).textOverlayFrame = textOverlayFrame
    end
    textOverlayFrame:SetAlpha(GetFFD(frame).textHidden and 0 or 1)
    textOverlayFrame:Show()

    -- WoW Forever: the item levels' own layer, above the slot buttons (the
    -- overlay above sits under them), so a level can sit inside its icon. A
    -- child of the slots' frame: it goes with them on the other tabs.
    if ns.ForeverStatText and InspectPaperDollItemsFrame then
        local layer = GetFFD(frame).ilvlOverlay
        if not layer then
            layer = CreateFrame("Frame", nil, InspectPaperDollItemsFrame)
            layer:SetAllPoints(InspectPaperDollItemsFrame)
            GetFFD(frame).ilvlOverlay = layer
        end
        layer:SetFrameLevel((_G.InspectHeadSlot and _G.InspectHeadSlot:GetFrameLevel() or 100) + 5)
        layer:SetAlpha(GetFFD(frame).textHidden and 0 or 1)
    end

    -- Top-left eyeball toggle: temporarily hides all item slot text (item level,
    -- upgrade track, enchants) by alpha-ing the shared overlay. Session-only,
    -- matches the CharacterSheet eyeball. State lives in FFD so it survives the
    -- frequent inspect re-skins (the SetAlpha above re-applies it each pass).
    if not GetFFD(frame).textEyeBtn then
        local EYE_VISIBLE   = EllesmereUI.EYE_VISIBLE_ICON
        local EYE_INVISIBLE = EllesmereUI.EYE_INVISIBLE_ICON
        local eyeBtn = CreateFrame("Button", "EUI_InspectSheet_TextEyeBtn", frame)
        eyeBtn:SetSize(20, 20)
        eyeBtn:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -6)
        eyeBtn:SetFrameLevel(frame:GetFrameLevel() + 20)
        eyeBtn:SetAlpha(0.4)
        local eyeTex = eyeBtn:CreateTexture(nil, "OVERLAY")
        eyeTex:SetAllPoints()
        eyeTex:SetTexture(GetFFD(frame).textHidden and EYE_INVISIBLE or EYE_VISIBLE)
        eyeBtn:SetScript("OnClick", function()
            local hidden = not GetFFD(frame).textHidden
            GetFFD(frame).textHidden = hidden
            eyeTex:SetTexture(hidden and EYE_INVISIBLE or EYE_VISIBLE)
            if GetFFD(frame).textOverlayFrame then
                GetFFD(frame).textOverlayFrame:SetAlpha(hidden and 0 or 1)
            end
            if GetFFD(frame).ilvlOverlay then
                GetFFD(frame).ilvlOverlay:SetAlpha(hidden and 0 or 1)
            end
        end)
        eyeBtn:SetScript("OnEnter", function(self)
            self:SetAlpha(0.8)
            EllesmereUI.ShowWidgetTooltip(self, GetFFD(frame).textHidden and "Show Item Text" or "Hide Item Text", { width = 135 })
        end)
        eyeBtn:SetScript("OnLeave", function(self)
            self:SetAlpha(0.4)
            EllesmereUI.HideWidgetTooltip()
        end)
        GetFFD(frame).textEyeBtn = eyeBtn
    end

    -- Position slots and style them
    if InspectPaperDollItemsFrame then
        for slotName, gridPos in pairs(slotGridMap) do
            local slot = _G[slotName]
            if slot then
                -- Skip weapon slots (they have no col/row, positioned separately)
                if not gridPos.col then
                    -- Still style them, but don't position
                    local isRightColumn = false
                    EUI_UpdateSlotStyle(slotName, slot:GetID(), textOverlayFrame, isRightColumn)
                else
                    slot:ClearAllPoints()
                    local xOffset = gridStartX + (gridPos.col * cellWidth)
                    local yOffset = gridStartY - (gridPos.row * cellHeight)
                    slot:SetPoint("TOPLEFT", InspectPaperDollItemsFrame, "TOPLEFT", xOffset, yOffset)

                    -- Style the slot with borders, ilvl, enchants (right column = col 1)
                    local isRightColumn = gridPos.col == 1
                    EUI_UpdateSlotStyle(slotName, slot:GetID(), textOverlayFrame, isRightColumn)
                end
            end
        end
    end

    -- Position weapon slots at bottom (matches CharacterSheet pattern --
    -- hardcoded offset, no GetWidth which can return a secret value).
    if InspectMainHandSlot and InspectSecondaryHandSlot then
        InspectMainHandSlot:ClearAllPoints()
        InspectMainHandSlot:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", InspectRangedSlot and 104 or 128, 10)
        InspectSecondaryHandSlot:ClearAllPoints()
        InspectSecondaryHandSlot:SetPoint("TOPLEFT", InspectMainHandSlot, "TOPRIGHT", 12, 0)
        -- Forever only: a third weapon slot, the row recentred for it.
        if InspectRangedSlot then
            InspectRangedSlot:ClearAllPoints()
            InspectRangedSlot:SetPoint("TOPLEFT", InspectSecondaryHandSlot, "TOPRIGHT", 12, 0)
        end
    end

    -- Average item level + M+ score, centered below the title/level text.
    -- Anchored to frame TOP so they sit below the character info header.
    do
        local fontPath = EllesmereUI.GetFontPath("blizzardSkin") or STANDARD_TEXT_FONT

        -- Text overlay frame above model bg and fade
        if not GetFFD(frame).textOverlay then
            local txo = CreateFrame("Frame", nil, frame)
            txo:SetAllPoints(frame)
            txo:SetFrameLevel((_G.InspectModelFrame and _G.InspectModelFrame:GetFrameLevel() or frame:GetFrameLevel()) + 5)
            txo:EnableMouse(false)
            GetFFD(frame).textOverlay = txo
        end
        local txo = GetFFD(frame).textOverlay
        txo:Show()

        if not GetFFD(frame).avgIlvlText then
            local ilvlFS = txo:CreateFontString(nil, "OVERLAY")
            ilvlFS:SetFont(fontPath, 16, "")
            ilvlFS:SetTextColor(0.6, 0.2, 1, 1)
            ilvlFS:SetJustifyH("CENTER")
            -- Under Blizzard's level line wherever the client draws it (WoW
            -- Forever puts it lower and larger than retail).
            local levelText = _G.InspectLevelText
            if levelText then
                ilvlFS:SetPoint("TOP", levelText, "BOTTOM", 0, -3)
            else
                ilvlFS:SetPoint("TOP", frame, "TOP", 0, -43)
            end
            GetFFD(frame).avgIlvlText = ilvlFS
        end

        if not GetFFD(frame).mPlusScoreText then
            local mpFS = txo:CreateFontString(nil, "OVERLAY")
            mpFS:SetFont(fontPath, 12, "")
            mpFS:SetTextColor(0.8, 0.8, 0.8, 1)
            mpFS:SetJustifyH("CENTER")
            mpFS:SetPoint("TOP", GetFFD(frame).avgIlvlText, "BOTTOM", 0, -2)
            GetFFD(frame).mPlusScoreText = mpFS
        end

        local avg = CalculateAverageItemLevel()
        if avg and avg > 0 then
            GetFFD(frame).avgIlvlText:SetFormattedText("%.2f", avg)
            GetFFD(frame).avgIlvlText:Show()
        else
            GetFFD(frame).avgIlvlText:Hide()
        end

        local inspectUnit = frame.unit
        local mpScore = 0
        if inspectUnit and C_PlayerInfo and C_PlayerInfo.GetPlayerMythicPlusRatingSummary then
            local summary = C_PlayerInfo.GetPlayerMythicPlusRatingSummary(inspectUnit)
            if summary and summary.currentSeasonScore then
                mpScore = summary.currentSeasonScore
            end
        end
        if mpScore > 0 then
            local hex = ns.GetMPScoreHex(mpScore)
            GetFFD(frame).mPlusScoreText:SetFormattedText("M+ Score: |cff%s%d|r", hex, math.floor(mpScore))
            GetFFD(frame).mPlusScoreText:Show()
        else
            GetFFD(frame).mPlusScoreText:Hide()
        end
    end

    -- Style Tabs (InspectFrameTab1, 2, 3)
    local fontPath = EllesmereUI.GetFontPath("blizzardSkin") or STANDARD_TEXT_FONT
    local EG = EllesmereUI.ELLESMERE_GREEN or { r = 0.51, g = 0.784, b = 1 }
    local FRAME_BG_R, FRAME_BG_G, FRAME_BG_B = 0.03, 0.045, 0.05

    local inspTabs = {}
    for i = 1, 3 do
        local tab = _G["InspectFrameTab" .. i]
        if tab then
            inspTabs[#inspTabs + 1] = tab
            -- Remove Blizzard textures
            local regions = { tab:GetRegions() }
            for j = 1, #regions do
                local region = regions[j]
                if region and region:IsObjectType("Texture") then
                    region:SetTexture("")
                    if region.SetAtlas then region:SetAtlas("") end
                end
            end

            if tab.Left then tab.Left:SetTexture("") end
            if tab.Middle then tab.Middle:SetTexture("") end
            if tab.Right then tab.Right:SetTexture("") end
            if tab.LeftDisabled then tab.LeftDisabled:SetTexture("") end
            if tab.MiddleDisabled then tab.MiddleDisabled:SetTexture("") end
            if tab.RightDisabled then tab.RightDisabled:SetTexture("") end

            local hl = tab:GetHighlightTexture()
            if hl then hl:SetTexture("") end

            -- Add custom background (matches character sheet tab color)
            if not GetFFD(tab).bg then
                GetFFD(tab).bg = tab:CreateTexture(nil, "BACKGROUND")
                GetFFD(tab).bg:SetAllPoints()
                GetFFD(tab).bg:SetColorTexture(0.043, 0.031, 0.027, 1)
            else
                GetFFD(tab).bg:Show()
                GetFFD(tab).bg:SetColorTexture(0.043, 0.031, 0.027, 1)
            end

            -- Add active highlight
            if not GetFFD(tab).activeHL then
                local activeHL = tab:CreateTexture(nil, "ARTWORK", nil, -6)
                activeHL:SetAllPoints()
                activeHL:SetColorTexture(1, 1, 1, 0.02)
                activeHL:SetBlendMode("ADD")
                activeHL:Hide()
                GetFFD(tab).activeHL = activeHL
            else
                -- The Blizzard-texture strip loop above clears EVERY one of the
                -- tab's texture regions, including this one, on each re-skin
                -- (inspect re-skins on every INSPECT_READY as data streams in).
                -- Restore the fill, or the active-tab highlight blanks out --
                -- the same reason the background is re-colored above.
                GetFFD(tab).activeHL:SetColorTexture(1, 1, 1, 0.02)
                GetFFD(tab).activeHL:SetBlendMode("ADD")
            end

            -- Replace Blizzard label with custom font
            local blizLabel = tab:GetFontString()
            local labelText = blizLabel and blizLabel:GetText() or ("Tab " .. i)
            if blizLabel then blizLabel:SetTextColor(0, 0, 0, 0) end
            tab:SetPushedTextOffset(0, 0)

            if not GetFFD(tab).label then
                local label = tab:CreateFontString(nil, "OVERLAY")
                label:SetFont(fontPath, 9, nil)
                label:SetPoint("CENTER", tab, "CENTER", 0, 0)
                label:SetJustifyH("CENTER")
                label:SetText(labelText)
                GetFFD(tab).label = label

                hooksecurefunc(tab, "SetText", function(_, newText)
                    if newText and label then label:SetText(newText) end
                end)
            end

            -- Add underline for active tab
            if not GetFFD(tab).underline then
                local underline = tab:CreateTexture(nil, "OVERLAY", nil, 6)
                if EllesmereUI and EllesmereUI.PanelPP and EllesmereUI.PanelPP.DisablePixelSnap then
                    EllesmereUI.PanelPP.DisablePixelSnap(underline)
                    underline:SetHeight(EllesmereUI.PanelPP.mult or 1)
                else
                    underline:SetHeight(1)
                end
                underline:SetPoint("BOTTOMLEFT", tab, "BOTTOMLEFT", 0, 0)
                underline:SetPoint("BOTTOMRIGHT", tab, "BOTTOMRIGHT", 0, 0)
                underline:SetColorTexture(EG.r or 0.51, EG.g or 0.784, EG.b or 1, 1)
                EllesmereUI.RegAccent({ type = "solid", obj = underline, a = 1 })
                underline:Hide()
                GetFFD(tab).underline = underline
            else
                -- Same strip-loop restore as activeHL above: re-apply the accent
                -- fill so the active-tab underline does not blank out on re-skin.
                GetFFD(tab).underline:SetColorTexture(EG.r or 0.51, EG.g or 0.784, EG.b or 1, 1)
            end
        end
    end
    if ns.WSkin and ns.WSkin.NormalizeTabRow then ns.WSkin.NormalizeTabRow(inspTabs) end

    -- Update tab visuals on show
    local function UpdateTabVisuals()
        local isTab1 = (frame.selectedTab or 1) == 1

        -- Show model background only on Tab 1
        if GetFFD(frame).modelBg then
            GetFFD(frame).modelBg:SetShown(isTab1)
        end
        if GetFFD(frame).modelBgGlow then
            GetFFD(frame).modelBgGlow:SetShown(isTab1)
        end

        -- Show Talents/Transmog buttons only on Tab 1 (Character sheet)
        if GetFFD(frame).talentsBtn then
            GetFFD(frame).talentsBtn:SetShown(isTab1)
        end
        if GetFFD(frame).transmogBtn then
            GetFFD(frame).transmogBtn:SetShown(isTab1)
        end
        -- The item text eyeball only has slots to act on on Tab 1
        if GetFFD(frame).textEyeBtn then
            GetFFD(frame).textEyeBtn:SetShown(isTab1)
        end

        -- Update label visibility with ApplyTabVisibility - only show on Tab 1
        ApplyTabVisibility(isTab1)

        for i = 1, 3 do
            local tab = _G["InspectFrameTab" .. i]
            if tab then
                local isActive = (frame.selectedTab or 1) == i
                -- Ensure background is always visible
                if GetFFD(tab).bg then
                    GetFFD(tab).bg:Show()
                end
                if GetFFD(tab).label then
                    GetFFD(tab).label:SetTextColor(1, 1, 1, isActive and 1 or 0.5)
                end
                if GetFFD(tab).underline then
                    GetFFD(tab).underline:SetShown(isActive)
                end
                if GetFFD(tab).activeHL then
                    GetFFD(tab).activeHL:SetShown(isActive)
                end
            end
        end
    end

    -- Hook to update tabs when they change (once only). Every switch goes
    -- through InspectSwitchTabs: the bottom tabs on retail, the side tabs on
    -- WoW Forever and Blizzard's own resets to the character tab.
    if frame.HookScript and not GetFFD(frame)._tabHooked then
        GetFFD(frame)._tabHooked = true
        frame:HookScript("OnShow", function()
            UpdateTabVisuals()
        end)
        if _G.InspectSwitchTabs then
            hooksecurefunc("InspectSwitchTabs", function()
                UpdateTabVisuals()
            end)
        end
    end

    UpdateTabVisuals()

    -- Scale fully owned by Blizzard (SetScale on secure panels taints
    -- UIParentPanelManager execution context).
    frame:SetFrameStrata("HIGH")

    -- Center the title within the frame (406px wide). Hardcoded to avoid
    -- frame:GetWidth() which can return a secret value and cause taint.
    if frame.TitleContainer then
        frame.TitleContainer:Show()
        frame.TitleContainer:SetAlpha(1)
        frame.TitleContainer:SetFrameStrata("HIGH")
        frame.TitleContainer:SetFrameLevel(20)
        frame.TitleContainer:ClearAllPoints()
        frame.TitleContainer:SetWidth(406)
        frame.TitleContainer:SetPoint("TOP", frame, "TOP", 0, 0)

        local children2 = { frame.TitleContainer:GetChildren() }
        for i = 1, #children2 do
            local child = children2[i]
            if child and child:GetObjectType() == "FontString" then
                child:SetJustifyH("CENTER")
            end
        end
    end

end

-- Replicates stock Blizzard's Inspect-docks-beside-Character layout, since
-- nothing here pairs the two otherwise and InspectFrame's live model bleeds
-- through CharacterFrame's when they overlap. Docking beside CharacterFrame
-- removes the overlap, so no strata/z-order fight is needed -- a strata write
-- on a protected frame is an insecure, tainting write, so we never do one.
local DOCK_MARGIN = 4

-- InspectFrame can be a protected frame, and a plain ClearAllPoints/SetPoint on
-- a protected frame taints its tree. Reposition through a SecureHandler
-- restricted-environment snippet instead: it executes securely and never
-- taints. The handler is parented to UIParent, so self:GetParent() inside the
-- snippet IS UIParent and the frame anchors relative to UIParent. Combat-gated,
-- since secure repositioning of a protected frame is blocked in combat.
local securePositioner = CreateFrame("Frame", nil, UIParent, "SecureHandlerBaseTemplate")
local function SecureSetPoint(frame, point, relPoint, x, y)
    if InCombatLockdown() then return false end
    securePositioner:SetFrameRef("f", frame)
    securePositioner:SetAttribute("p", point)
    securePositioner:SetAttribute("rp", relPoint)
    securePositioner:SetAttribute("x", x)
    securePositioner:SetAttribute("y", y)
    securePositioner:Execute([[
        local f = self:GetFrameRef("f")
        if not f then return end
        f:ClearAllPoints()
        f:SetPoint(self:GetAttribute("p"), self:GetParent(), self:GetAttribute("rp"), self:GetAttribute("x"), self:GetAttribute("y"))
    ]])
    return true
end

local function ShifterPinned(name)
    return EllesmereUIDB and EllesmereUIDB.shifterPositions
        and EllesmereUIDB.shifterPositions[name] ~= nil
end

-- Reposition `mover` immediately beside `anchor`, on whichever side has screen room.
-- Room is compared in SCREEN-ABSOLUTE units (each frame's coords normalized through ITS
-- OWN effective scale), so a scaled or edge-pinned anchor never shoves the mover off
-- screen and back into an overlap. A protected mover goes through SecureSetPoint (never
-- a raw SetPoint -> taint); since that only anchors to UIParent, the beside-anchor
-- target is converted to a UIParent- CENTER offset.
local function DockBeside(mover, anchor)
    if not mover or not anchor then return end
    local as  = anchor:GetEffectiveScale() or 1
    local ms  = mover:GetEffectiveScale() or 1
    local ues = UIParent:GetEffectiveScale() or 1
    local wAbs = (mover:GetWidth() or 0) * ms
    local leftRoom  = (anchor:GetLeft() or 0) * as
    local rightRoom = (GetScreenWidth() or 0) * ues - (anchor:GetRight() or 0) * as
    local dockLeft = leftRoom >= wAbs + DOCK_MARGIN * ms or leftRoom >= rightRoom

    if mover:IsProtected() then
        if InCombatLockdown() then return end
        local hAbs = (mover:GetHeight() or 0) * ms
        local absCenterX
        if dockLeft then
            absCenterX = leftRoom - DOCK_MARGIN * ms - wAbs / 2
        else
            absCenterX = (anchor:GetRight() or 0) * as + DOCK_MARGIN * ms + wAbs / 2
        end
        local absCenterY = (anchor:GetTop() or 0) * as - hAbs / 2
        local ucx, ucy = UIParent:GetCenter()
        if ucx and ms > 0 then
            SecureSetPoint(mover, "CENTER", "CENTER",
                (absCenterX - ucx * ues) / ms,
                (absCenterY - ucy * ues) / ms)
        end
    else
        mover:ClearAllPoints()
        if dockLeft then
            mover:SetPoint("TOPRIGHT", anchor, "TOPLEFT", -DOCK_MARGIN, 0)
        else
            mover:SetPoint("TOPLEFT", anchor, "TOPRIGHT", DOCK_MARGIN, 0)
        end
    end
end

-- Each window's pre-dock anchor, captured the first time WE move it so it can be
-- put back once its partner is gone. Keyed in an external table (never written
-- onto the Blizzard frame -> no taint). _ignoreSP guards the SetPoint hooks
-- against our own repositioning.
local _savedPoint = {}
local _moved = {}
local _ignoreSP = false

local function CapturePoint(frame)
    if not frame or _savedPoint[frame] then return end
    local p, rel, rp, x, y = frame:GetPoint(1)
    if p then _savedPoint[frame] = { p, rel, rp, x, y } end
end

local function RestorePoint(frame)
    local p = _savedPoint[frame]
    if not p or not frame then return end
    if frame:IsProtected() then
        -- Secure restore reproduces the native anchor only when it was
        -- UIParent-relative (the usual case for a top-level panel; a nil
        -- relativeTo defaults to the parent, UIParent, inside the snippet).
        if p[2] == nil or p[2] == UIParent then
            SecureSetPoint(frame, p[1], p[3], p[4], p[5])
        end
    else
        frame:ClearAllPoints()
        frame:SetPoint(p[1], p[2], p[3], p[4], p[5])
    end
end

-- Keep the Inspect and Character windows from overlapping while both are open. The
-- INSPECT window is held still and the CHARACTER sheet is the one that docks beside it.
-- If the user has pinned the character sheet with the Shifter, that is respected (it
-- stays put) and the inspect window yields instead; if both are pinned, neither moves.
local function RefreshDock()
    local insp, cf = InspectFrame, _G.CharacterFrame
    if not insp or not cf then return end
    if EllesmereUIDB and (EllesmereUIDB.themedInspectSheet == false or EllesmereUI.BlizzWindowSkinsKilled()) then return end

    if not (insp:IsShown() and cf:IsShown()) then
        _ignoreSP = true
        if _moved[cf]   then _moved[cf]   = nil; RestorePoint(cf);   _savedPoint[cf]   = nil end
        if _moved[insp] then _moved[insp] = nil; RestorePoint(insp); _savedPoint[insp] = nil end
        _ignoreSP = false
        return
    end

    local mover, anchor
    if not ShifterPinned("CharacterFrame") then
        mover, anchor = cf, insp
    elseif not ShifterPinned("InspectFrame") then
        mover, anchor = insp, cf
    else
        return
    end

    _ignoreSP = true
    CapturePoint(mover)
    _moved[mover] = true
    DockBeside(mover, anchor)
    _ignoreSP = false
end

-- Main function to apply themed inspect sheet
local function ApplyThemedInspectSheet()
    if EllesmereUIDB and (EllesmereUIDB.themedInspectSheet == false or EllesmereUI.BlizzWindowSkinsKilled()) then
        return
    end

    if InspectFrame then
        SkinInspectSheet()
        -- Show labels on Tab 1
        ApplyTabVisibility((InspectFrame.selectedTab or 1) == 1)
    end
end

-- Persistently hide NineSlice borders
local function EnsureInspectNineSliceHidden()
    if EllesmereUIDB and (EllesmereUIDB.themedInspectSheet == false or EllesmereUI.BlizzWindowSkinsKilled()) then return end
    if not InspectFrame then return end

    local frame = InspectFrame

    -- Hide InspectFrame.NineSlice
    if frame.NineSlice then
        frame.NineSlice:Hide()
        frame.NineSlice:SetAlpha(0)
    end

    -- Hide InspectFrameInset.NineSlice (borders). The inset is left transparent
    -- so the window's modern_blizz bg + 0.62 black overlay show through, matching
    -- the character sheet. Filling it with a solid color stacked a second dark
    -- layer behind the model.
    if InspectFrameInset and InspectFrameInset.NineSlice then
        InspectFrameInset.NineSlice:Hide()
        InspectFrameInset.NineSlice:SetAlpha(0)
    end
end

-- Register with parent addon
if EllesmereUI then
    EllesmereUI.ApplyThemedInspectSheet = ApplyThemedInspectSheet

    -- Register hooks when Blizzard_InspectUI loads (it's load-on-demand,
    -- so InspectFrame doesn't exist at PLAYER_LOGIN)
    local initFrame = CreateFrame("Frame")
    local _inspHooked = false

    local function HookInspectFrame()
        if _inspHooked or not InspectFrame then return end
        _inspHooked = true

        InspectFrame:HookScript("OnShow", function()
            skinned = false
            ApplyThemedInspectSheet()
            RefreshDock()
            C_Timer.After(0.1, function()
                if not InspectFrame or not InspectFrame:IsShown() then return end
                if EllesmereUI._refreshInspectItemLevelVisibility then
                    EllesmereUI._refreshInspectItemLevelVisibility()
                end
                if EllesmereUI._refreshInspectUpgradeTrackVisibility then
                    EllesmereUI._refreshInspectUpgradeTrackVisibility()
                end
                if EllesmereUI._refreshInspectEnchantsVisibility then
                    EllesmereUI._refreshInspectEnchantsVisibility()
                end
            end)
        end)

        InspectFrame:HookScript("OnHide", function()
            skinned = false
            RefreshDock()
        end)

        -- When the inspect window itself moves (Shifter drag, Blizzard relayout),
        -- the docked character sheet follows it, so re-pair on its SetPoint too.
        hooksecurefunc(InspectFrame, "SetPoint", function()
            if not _ignoreSP then RefreshDock() end
        end)

        -- CharacterFrame is core UI, already loaded here (unlike InspectFrame).
        -- OnShow/OnHide re-pair; the SetPoint hook catches Blizzard's own panel
        -- relayout (which otherwise blinks the sheet back to its default spot).
        if _G.CharacterFrame then
            _G.CharacterFrame:HookScript("OnShow", RefreshDock)
            _G.CharacterFrame:HookScript("OnHide", RefreshDock)
            hooksecurefunc(_G.CharacterFrame, "SetPoint", function()
                if not _ignoreSP then RefreshDock() end
            end)
        end

        local nineSliceHiddenFrame = CreateFrame("Frame")
        nineSliceHiddenFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
        nineSliceHiddenFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")
        nineSliceHiddenFrame:SetScript("OnEvent", function(self, event, ...)
            if InspectFrame and InspectFrame:IsShown() then
                EnsureInspectNineSliceHidden()
            end
        end)

        InspectFrame:HookScript("OnShow", EnsureInspectNineSliceHidden)
    end

    initFrame:RegisterEvent("PLAYER_LOGIN")
    initFrame:RegisterEvent("ADDON_LOADED")
    initFrame:SetScript("OnEvent", function(self, event, arg1)
        if event == "PLAYER_LOGIN" then
            HookInspectFrame()
        elseif event == "ADDON_LOADED" and arg1 == "Blizzard_InspectUI" then
            self:UnregisterEvent("ADDON_LOADED")
            HookInspectFrame()
        end
    end)

    -- Slots whose item or tooltip data had not arrived are read again as it
    -- does: item and tooltip data events, registered only while a slot waits,
    -- for at most WAIT_SECS from this inspect's first incomplete read (a new
    -- INSPECT_READY starts a new wait), one pass per burst.
    local WAIT_SECS = 5
    local waitStart, retryTimer
    local RefreshSlotStyles  -- forward
    local dataWatch = CreateFrame("Frame")
    local function StopWait()
        dataWatch:UnregisterAllEvents()
    end
    local function EquippedByInspected(itemID)
        local unit = InspectFrame and InspectFrame.unit
        if not unit or not itemID then return false end
        for slotName in pairs(slotGridMap) do
            local slot = _G[slotName]
            if slot and GetInventoryItemID(unit, slot:GetID()) == itemID then return true end
        end
        return false
    end
    dataWatch:SetScript("OnEvent", function(_, event, arg1)
        if retryTimer then return end
        if event == "GET_ITEM_INFO_RECEIVED" and not EquippedByInspected(arg1) then return end
        retryTimer = C_Timer.NewTimer(0.12, function()
            retryTimer = nil
            if InspectFrame and InspectFrame:IsShown() then RefreshSlotStyles() else StopWait() end
        end)
    end)

    -- Function to refresh all slot styles when inspect data changes
    RefreshSlotStyles = function()
        if not InspectPaperDollItemsFrame then return end
        if not InspectFrame then return end
        local textOverlayFrame = GetFFD(InspectFrame).textOverlayFrame
        if not textOverlayFrame then return end

        local pending = false
        for slotName, gridPos in pairs(slotGridMap) do
            local slot = _G[slotName]
            if slot then
                -- Label clearing now lives in EUI_UpdateSlotStyle, so it covers
                -- ApplyThemedInspectSheet's styling pass too, not just this one.
                GetFFD(slot).border = false
                -- Re-style (right column = col 1)
                local isRightColumn = gridPos.col == 1
                if EUI_UpdateSlotStyle(slotName, slot:GetID(), textOverlayFrame, isRightColumn) then
                    pending = true
                end
            end
        end
        local now = GetTime()
        if pending and now - (waitStart or now) < WAIT_SECS then
            waitStart = waitStart or now
            dataWatch:RegisterEvent("GET_ITEM_INFO_RECEIVED")
            dataWatch:RegisterEvent("TOOLTIP_DATA_UPDATE")
        else
            StopWait()
        end
        -- Update label visibility after all slots have been styled
        local frame = InspectFrame
        if frame then
            ApplyTabVisibility(InspectPaperDollItemsFrame and InspectPaperDollItemsFrame:IsShown())
        end
    end

    -- Options refresher for the enchant display: restyles every slot of a
    -- shown sheet; a hidden one restyles on its next show.
    function EllesmereUI._refreshInspectSlotLabels()
        if not (InspectFrame and InspectFrame:IsShown()) then return end
        if EllesmereUIDB and (EllesmereUIDB.themedInspectSheet == false or EllesmereUI.BlizzWindowSkinsKilled()) then return end
        RefreshSlotStyles()
    end

    -- Also hook to INSPECT_READY to reskin when new inspection data arrives
    local inspectHook = CreateFrame("Frame")
    inspectHook:RegisterEvent("INSPECT_READY")
    inspectHook:SetScript("OnEvent", function(self, event, guid)
        if not InspectFrame or not InspectFrame:IsShown() then return end
        waitStart = nil  -- new inspect data: a fresh wait for what it still lacks
        skinned = false
        ApplyThemedInspectSheet()
        EnsureInspectNineSliceHidden()
        RefreshSlotStyles()
        local frame = InspectFrame
        if frame then
            ApplyTabVisibility(InspectPaperDollItemsFrame and InspectPaperDollItemsFrame:IsShown())
            -- Apply visibility settings after styling
            if EllesmereUI._refreshInspectItemLevelVisibility then
                EllesmereUI._refreshInspectItemLevelVisibility()
            end
            if EllesmereUI._refreshInspectUpgradeTrackVisibility then
                EllesmereUI._refreshInspectUpgradeTrackVisibility()
            end
            if EllesmereUI._refreshInspectEnchantsVisibility then
                EllesmereUI._refreshInspectEnchantsVisibility()
            end
            if EllesmereUI._refreshInspectAverageItemLevelVisibility then
                EllesmereUI._refreshInspectAverageItemLevelVisibility()
            end
        end
    end)

else
    -- EllesmereUI.Print not available here (EllesmereUI is nil)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff0000Error:|r EllesmereUI not found! Themed Inspect Sheet requires EllesmereUI.")
end

-- Initialize defaults
do
    local defaultStamp = CreateFrame("Frame")
    defaultStamp:RegisterEvent("ADDON_LOADED")
    defaultStamp:SetScript("OnEvent", function(self, _, addon)
        if addon ~= "EllesmereUI" then return end
        self:UnregisterAllEvents()
        if not EllesmereUIDB then EllesmereUIDB = {} end
        local defaults = {
            themedInspectSheet = true,
            inspectShowItemLevel = true,
            inspectShowUpgradeTrack = true,
            inspectShowEnchants = true,
        }
        for k, v in pairs(defaults) do
            if EllesmereUIDB[k] == nil then
                EllesmereUIDB[k] = v
            end
        end
    end)
end

-- Function to refresh item level visibility when toggle changes
function EllesmereUI._refreshInspectItemLevelVisibility()
    if not InspectFrame or not InspectPaperDollItemsFrame then return end

    local showItemLevel = (not EllesmereUIDB) or (EllesmereUIDB.inspectShowItemLevel ~= false)
    local isTab1 = InspectPaperDollItemsFrame and InspectPaperDollItemsFrame:IsShown()

    for slotName, _ in pairs(slotGridMap) do
        local slot = _G[slotName]
        if slot and GetFFD(slot).iLvlText then
            -- Only show if Tab 1 AND setting is enabled
            GetFFD(slot).iLvlText:SetShown(isTab1 and showItemLevel)
        end
    end
end

-- Function to refresh upgrade track visibility when toggle changes
function EllesmereUI._refreshInspectUpgradeTrackVisibility()
    if not InspectFrame or not InspectPaperDollItemsFrame then return end

    local showUpgradeTrack = ns.ForeverStatText ~= nil
        or (not EllesmereUIDB) or (EllesmereUIDB.inspectShowUpgradeTrack ~= false)
    local isTab1 = InspectPaperDollItemsFrame and InspectPaperDollItemsFrame:IsShown()

    for slotName, _ in pairs(slotGridMap) do
        local slot = _G[slotName]
        if slot and GetFFD(slot).upgradeText then
            -- Only show if Tab 1 AND setting is enabled
            GetFFD(slot).upgradeText:SetShown(isTab1 and showUpgradeTrack)
        end
        if slot and GetFFD(slot).dpsText then
            GetFFD(slot).dpsText:SetShown(isTab1 and showUpgradeTrack)
        end
    end
end

-- Function to refresh enchants visibility when toggle changes
function EllesmereUI._refreshInspectEnchantsVisibility()
    if not InspectFrame or not InspectPaperDollItemsFrame then return end

    local showEnchants = (not EllesmereUIDB) or (EllesmereUIDB.inspectShowEnchants ~= false)
    local isTab1 = InspectPaperDollItemsFrame and InspectPaperDollItemsFrame:IsShown()

    for slotName, _ in pairs(slotGridMap) do
        local slot = _G[slotName]
        if slot and GetFFD(slot).enchantText then
            -- Only show if Tab 1 AND setting is enabled (its hover spot too)
            GetFFD(slot).enchantText:SetShown(isTab1 and showEnchants)
            if GetFFD(slot).enchantHoverFrame then
                GetFFD(slot).enchantHoverFrame:SetShown(isTab1 and showEnchants)
            end
        end
    end
end
