if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUI_Conditions.lua
--  Conditional Overrides engine: condition definitions, the active-group
--  resolver, event wiring, and the keybind toggle. The value/unlock override
--  integration lives in EUI_SpecOverrides_Conditional.lua (it shares
--  EllesmereUI_SpecOverrides.lua's fkey helpers); this file only decides WHICH conditional group is active
--  and notifies the override system when that changes.
--
--  Resolution ladder (user-approved):
--    1. keybind  -- any group whose keybind toggle is ON (creation order
--                   breaks ties). Explicit user action outranks ambient state.
--    2. gamepad  -- WoW Forever's Gamepad interface style is on. An explicit
--                   input-mode switch, so it outranks every ambient tier
--                   below; the keybind toggle still wins. Never on retail.
--    3. darkmode -- every per-module Dark Mode is on except the Class
--                   Resource Bar's (it is excluded).
--                   Location-independent, so it applies inside AND outside
--                   instances; below keybind and gamepad (explicit actions
--                   still win).
--    3b. secondaryspec -- WoW Forever only: the secondary spec group is the
--                   active one (C_SpecializationInfo.GetActiveSpecGroup
--                   reads 2). The primary spec has no condition: it is the
--                   base. Location-independent, so below Dark Mode and above
--                   instance. Never on retail.
--    4. instance -- dungeon / raid / arena / battleground. Naturally mutually
--                   exclusive (the client reports one instance type). First
--                   group in creation order that checks the current type.
--    5. party    -- in a group that is not a raid, inside an instance or out.
--                   Below instance, so a group for the current instance type
--                   outranks it there. Only groups that check it can match.
--    6. solo     -- not in any group. Lowest priority.
--  Exactly one conditional group is active at a time, or none.
--
--  Condition flips NEVER happen in combat: flips are recomputed fresh at
--  PLAYER_REGEN_ENABLED (re-resolve, never replay -- the zone can change
--  twice during a fight).
-------------------------------------------------------------------------------

local L = function(s) return EllesmereUI.L(s) or s end

-------------------------------------------------------------------------------
--  Condition definitions (ordered display list for the picker UI; the
--  resolver's ladder below keeps its own order).
--  comingSoon entries render disabled in the picker and never match.
-------------------------------------------------------------------------------
-- The Dark Mode condition holds while every per-module Dark Mode is on
-- except the class resource bar's (the Dark Mode checkbox dropdown on
-- Global Settings > Colors; users commonly dark one without the other).
-- That is exactly what the old main "Dark Mode" toggle read.
local function _dmMainFilter(p) return p.id ~= "resourceBars" end
local function DarkModeMasterOn()
    return (EllesmereUI.IsDarkModeAllOn(_dmMainFilter)) or false
end

-- WoW Forever spec group: 1 primary, 2 secondary; nil elsewhere.
local function ActiveSpecGroup()
    if EllesmereUI.IS_FOREVER ~= true then return nil end
    local f = C_SpecializationInfo and C_SpecializationInfo.GetActiveSpecGroup
    return f and f() or nil
end

-- Dual spec learned (GetNumSpecGroups returns 2).
local function HasDualSpec()
    return (GetNumSpecGroups and GetNumSpecGroups() == 2) or false
end

EllesmereUI.CONDITIONS = {
    { id = "keybind",      label = "Keybind (out of combat)" },
    { id = "party",        label = "Party (in a group, not a raid)" },
    { id = "dungeon",      label = "Dungeon" },
    { id = "raid",         label = "Raid" },
    { id = "arena",        label = "Arena" },
    { id = "battleground", label = "Battleground" },
    { id = "solo",         label = "Solo (not in a group)" },
    -- requires: pickable in the condition picker only while it returns true
    -- (newly checking is refused and the row renders dimmed with the hint;
    -- UNchecking is always allowed so an existing group can never be
    -- trapped). Same predicate the resolver reads, so the picker never
    -- offers a condition that cannot currently hold.
    -- tooltip: shown on hover whenever the requirement hint is not.
    { id = "darkmode",     label = "Dark Mode",
      requires = DarkModeMasterOn,
      tooltip = "Active while Dark Mode is on.",
      requiresHint = "Check every Dark Mode in Global Settings > Colors, except Class Resource Bar, to use this condition." },
}
-- WoW Forever only: its Gamepad interface style has no retail counterpart
-- (PadGamepadUI reads false there), so retail lists no row or icon for it; a
-- group imported there with it checked simply never matches on it.
if EllesmereUI.IS_FOREVER == true then
    EllesmereUI.CONDITIONS[#EllesmereUI.CONDITIONS + 1] = { id = "gamepad", label = "Gamepad Mode",
        tooltip = "Active while WoW's gamepad interface is on." }
    EllesmereUI.CONDITIONS[#EllesmereUI.CONDITIONS + 1] = { id = "secondaryspec", label = "Secondary Spec",
        requires = HasDualSpec,
        tooltip = "Active while your secondary spec is active.",
        requiresHint = "Learn Dual Specialization to use this condition." }
end

local INSTANCE_COND = {
    party = "dungeon",
    raid  = "raid",
    arena = "arena",
    pvp   = "battleground",
}

-------------------------------------------------------------------------------
--  Group store: profile.condOverrideGroups (array, creation order = priority
--  order within a tier). Mirrors profile.specOverrideGroups:
--    { id, name, icon = { kind, key }, conds = { [condID] = true },
--      key = "ALT-X" | nil, keyOn = true|nil }
--  key/keyOn only meaningful when conds.keybind; keyOn persists (profile).
-------------------------------------------------------------------------------
local function GetProfileRoot()
    if not (EllesmereUIDB and EllesmereUI.GetProfilesDB) then return nil end
    local pdb = EllesmereUI.GetProfilesDB()
    local name = pdb.activeProfile or "Default"
    return pdb.profiles and pdb.profiles[name]
end

function EllesmereUI.Conditions_GetGroups(create)
    local prof = GetProfileRoot()
    if not prof then return nil end
    if not prof.condOverrideGroups then
        if not create then return nil end
        prof.condOverrideGroups = {}
    end
    return prof.condOverrideGroups
end

function EllesmereUI.Conditions_GroupById(gid)
    local groups = EllesmereUI.Conditions_GetGroups()
    if not groups then return nil end
    for _, g in ipairs(groups) do
        if g.id == gid then return g end
    end
    return nil
end

function EllesmereUI.Conditions_NewGroupId()
    -- PERSISTED counter, never max+1: deleted groups' per-gid value maps can survive on
    -- other groups' shared entries, and a reused id silently inherited the dead group's
    -- overrides. The counter seeds from max+1 once (legacy stores) and only ever grows.
    local prof = GetProfileRoot()
    local groups = EllesmereUI.Conditions_GetGroups(true)
    local maxId = 0
    for _, g in ipairs(groups or {}) do
        if type(g.id) == "number" and g.id > maxId then maxId = g.id end
    end
    if not prof then return maxId + 1 end
    local nextId = prof.condOverrideNextId or 0
    if nextId <= maxId then nextId = maxId end
    nextId = nextId + 1
    prof.condOverrideNextId = nextId
    return nextId
end

-------------------------------------------------------------------------------
--  Resolver
-------------------------------------------------------------------------------

-- Tier 5: the first group (creation order) that checks Party, while the player
-- is in a party (a group that is not a raid, as the visibility rules' In Party).
-- nil for every profile with no such group, so the other tiers resolve as if
-- this one were not there.
local function PartyGroup(groups)
    if not IsInGroup() or IsInRaid() then return nil end
    for _, g in ipairs(groups) do
        if g.conds and g.conds.party then return g end
    end
    return nil
end

--- The currently-ACTIVE conditional group per the ladder, or nil.
function EllesmereUI.Conditions_ActiveGroup()
    local groups = EllesmereUI.Conditions_GetGroups()
    if not groups or #groups == 0 then return nil end
    -- Tier 1: keybind toggles (explicit user action).
    for _, g in ipairs(groups) do
        if g.conds and g.conds.keybind and g.keyOn then return g end
    end
    -- Tier 2: WoW Forever's Gamepad interface style (an explicit input-mode
    -- switch, so it outranks the ambient tiers; always false on retail).
    if EllesmereUI.PadGamepadUI() then
        for _, g in ipairs(groups) do
            if g.conds and g.conds.gamepad then return g end
        end
    end
    -- Tier 3: every per-module Dark Mode but the Class Resource Bar's (it is
    -- deliberately excluded -- see DarkModeMasterOn above).
    -- Location-independent, so it is checked BEFORE the instance early-outs.
    if DarkModeMasterOn() then
        for _, g in ipairs(groups) do
            if g.conds and g.conds.darkmode then return g end
        end
    end
    -- Tier 3b: WoW Forever's secondary spec group (never on retail).
    if ActiveSpecGroup() == 2 then
        for _, g in ipairs(groups) do
            if g.conds and g.conds.secondaryspec then return g end
        end
    end
    -- Tier 4: instance type (client reports exactly one).
    local _, instanceType = IsInInstance()
    local cond = instanceType and INSTANCE_COND[instanceType]
    if cond then
        for _, g in ipairs(groups) do
            if g.conds and g.conds[cond] then return g end
        end
        -- In an instance: party can still apply, solo never does.
        return PartyGroup(groups)
    end
    -- Tier 5: party.
    local pg = PartyGroup(groups)
    if pg then return pg end
    -- Tier 6: solo.
    if not IsInGroup() then
        for _, g in ipairs(groups) do
            if g.conds and g.conds.solo then return g end
        end
    end
    return nil
end

-------------------------------------------------------------------------------
--  Flip machinery: flag-and-recompute, never replay. The override system's
--  transition handler (SpecOverrides_CondTransition) owns the actual
--  harvest/apply work and returns false when it cannot run yet (mid spec
--  transition, editing session open) -- the next event or the spec
--  pipeline's own Conditions_Recheck tail retries with fresh state.
-------------------------------------------------------------------------------
local _appliedGid = nil        -- gid of the conditional group currently applied
local _flipPending = false
local _establish = false       -- post profile-apply: apply-only, no harvests

-- Persisted mirror of the applied pointer (profile root). The applied conditional's
-- values are baked into the profile's saved module data, so the pointer must survive
-- with that data: after a /reload the runtime pointer reset to nil while live still
-- held the overlay, and every bank that then resolved the applied gid as nil re-banked
-- the overlay into the conditional DEFAULT maps -- permanent baseline loss on every
-- /reload or login with a conditional active.
local function PersistAppliedGid(gid)
    local prof = EllesmereUI.GetActiveProfileData()
    if prof then prof.condAppliedGid = gid end
end

function EllesmereUI.Conditions_AppliedGid()
    if _appliedGid ~= nil then return _appliedGid end
    -- Stale windows (fresh login, profile-apply MarkStale before the establish Recheck
    -- lands): fall back to the persisted pointer, validated against the active
    -- profile's groups (a hand-edited or imported store may point at a deleted group).
    local prof = EllesmereUI.GetActiveProfileData()
    local gid = prof and prof.condAppliedGid
    if gid and EllesmereUI.Conditions_GroupById(gid) then
        return gid
    end
    return nil
end

--- Profile apply swapped every store wholesale: the applied pointer refers
--- to the OLD profile's groups. Reset without a transition (the incoming
--- stores already hold their own persisted state) and let the follow-up
--- Recheck ESTABLISH against the new profile: apply-only (live is the
--- incoming raw data -- harvesting it would corrupt the new store) and
--- forced even when no conditional is active (the incoming unlock stores
--- may hold layer-valued data with a reset active pointer).
function EllesmereUI.Conditions_MarkStale()
    _appliedGid = nil
    _flipPending = false
    _establish = true
end

--- True between a profile apply and its (possibly combat-deferred)
--- establish Recheck. In that window live holds a MIXED state -- baseline
--- links restored over the incoming profile's layer-valued module data --
--- and layout harvests must refuse to bank it (a second in-combat boundary
--- otherwise baked the un-established state into baselineLayout).
function EllesmereUI.Conditions_EstablishPending()
    return _establish
end

function EllesmereUI.Conditions_Recheck()
    if InCombatLockdown() then
        _flipPending = true
        return
    end
    local g = EllesmereUI.Conditions_ActiveGroup()
    local gid = g and g.id or nil
    -- Effective applied state: the runtime pointer, or -- in the stale
    -- windows (fresh login, MarkStale-to-establish) -- the persisted pointer
    -- recording which conditional's values are baked into live data. Using
    -- the raw runtime pointer here treated a post-/reload overlay as "no
    -- conditional applied": the matching-condition login early-outed without
    -- adopting it, and the non-matching login handed the transition a nil
    -- oldGid, whose harvest banked the overlay into the DEFAULT maps.
    local applied = EllesmereUI.Conditions_AppliedGid()
    if gid == applied and not _establish then
        -- Adopt a persisted pointer into the runtime on the no-op path so
        -- later compares and MarkStale operate on live state.
        _appliedGid = applied
        return
    end
    -- An open unlock session never survives a layout-owner change (same rule
    -- as spec changes): discard-close first, then transition.
    if EllesmereUI._unlockModeSessionActive and EllesmereUI.ForceCloseUnlockDiscard then
        EllesmereUI.ForceCloseUnlockDiscard()
    end
    local handler = EllesmereUI.SpecOverrides_CondTransition
    if not handler then return end
    -- Consume the establish request BEFORE the handler runs: anything inside
    -- it (a nested RefreshAllAddons tail calls MarkStale) may raise a FRESH
    -- request, which must survive this call instead of being clobbered on
    -- success -- the next signal then converges values and pointer.
    local est = _establish
    _establish = false
    -- The options panel's Default Editing Mode is not a reason to defer, only one to
    -- step out of: the Dark Mode condition's inputs are all options widgets, so its
    -- flips are ALWAYS raised with that view up, and a deferred flip left the outgoing
    -- conditional applied (and reporting itself applied) until an unrelated event or a
    -- /reload -- silently filing the user's baseline edits into the override's maps in
    -- between. Establish transitions never harvest, so they run in place; only real
    -- flips need the roundtrip.
    local resumeView = false
    if not est and EllesmereUI.SpecOverrides_SuspendDefaultView then
        resumeView = EllesmereUI.SpecOverrides_SuspendDefaultView()
    end
    if resumeView then
        -- Leaving the view restores the spec's values and runs the touched
        -- modules' refreshers, and an unmapped module falls back to a full
        -- RefreshAllAddons -- whose tail re-enters this resolver and can
        -- converge the flip on its own. Re-read both ends so the handler
        -- never harvests live against an outgoing group it no longer holds.
        g = EllesmereUI.Conditions_ActiveGroup()
        gid = g and g.id or nil
        applied = EllesmereUI.Conditions_AppliedGid()
        if gid == applied then
            _appliedGid = applied
            EllesmereUI.SpecOverrides_ResumeDefaultView()
            return
        end
    end
    local ok, failed = handler(applied, gid, est)
    if ok then
        _appliedGid = gid
        PersistAppliedGid(gid)
    else
        -- Busy (spec transition / edit session / re-entrant refresh): keep
        -- the request and retry on the next signal.
        _establish = est or _establish
        _flipPending = true
    end
    -- Strictly AFTER the pointer advances: re-entering the view harvests
    -- through HarvestCurrent, which banks against the APPLIED gid. Not after a
    -- handler error: live may hold half-applied incoming values, and the harvest
    -- would bank them into the outgoing group's maps.
    if resumeView and not failed and EllesmereUI.SpecOverrides_ResumeDefaultView then
        EllesmereUI.SpecOverrides_ResumeDefaultView()
    end
end

-------------------------------------------------------------------------------
--  Keybind toggle: pooled hidden buttons + SetOverrideBindingClick, rebuilt
--  out of combat (regen-deferred), mirroring the Action Bars visibility
--  toggle. One key per group; presses in combat are ignored (the toggle is
--  "out of combat" by definition).
-------------------------------------------------------------------------------
local _keyBtnPool = {}

function EllesmereUI.Conditions_ToggleKey(gid)
    if InCombatLockdown() then return end
    local g = EllesmereUI.Conditions_GroupById(gid)
    if not g or not (g.conds and g.conds.keybind) then return end
    g.keyOn = not g.keyOn or nil
    EllesmereUI.Conditions_Recheck()
end

function EllesmereUI.Conditions_RebuildKeyBindings()
    if InCombatLockdown() then
        EllesmereUI.CombatQueue.Defer("ConditionsKeyBindings", EllesmereUI.Conditions_RebuildKeyBindings)
        return
    end
    for _, btn in ipairs(_keyBtnPool) do
        ClearOverrideBindings(btn)
    end
    local groups = EllesmereUI.Conditions_GetGroups()
    if not groups then return end
    local i = 0
    for _, g in ipairs(groups) do
        if g.conds and g.conds.keybind and g.key and g.key ~= "" then
            i = i + 1
            local btn = _keyBtnPool[i]
            if not btn then
                btn = CreateFrame("Button", "EUICondKeyBtn" .. i, UIParent)
                btn:Hide()
                _keyBtnPool[i] = btn
            end
            local gid = g.id
            btn:SetScript("OnClick", function() EllesmereUI.Conditions_ToggleKey(gid) end)
            SetOverrideBindingClick(btn, true, g.key, btn:GetName())
        end
    end
end

-------------------------------------------------------------------------------
--  Events. GROUP_ROSTER_UPDATE drives party and solo; PEW/zone drive instance flips;
--  the interface-style transition (WoW Forever) drives Gamepad Mode flips;
--  ACTIVE_TALENT_GROUP_CHANGED (WoW Forever) drives spec group flips; regen
--  drains combat-deferred rechecks. Registration order matters for the
--  regen drain: this file loads after EllesmereUI_Profiles.lua, so the spec
--  pipeline's regen branch runs first and our recompute sees settled state.
-------------------------------------------------------------------------------
local evFrame = CreateFrame("Frame")
evFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
evFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
evFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
evFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
-- The interface-style switch is WoW Forever's. Registering an event name the
-- client does not know errors at load, so the name is checked first (as the
-- Action Bars and Quest Tracker registrations do).
if EllesmereUI.IS_FOREVER == true
   and not (C_EventUtils and C_EventUtils.IsEventValid
            and not C_EventUtils.IsEventValid("INPUT_DEVICE_INTERFACE_TRANSITION")) then
    evFrame:RegisterEvent("INPUT_DEVICE_INTERFACE_TRANSITION")
end
-- Spec group swap (WoW Forever) drives the Secondary Spec flips.
if EllesmereUI.IS_FOREVER == true
   and not (C_EventUtils and C_EventUtils.IsEventValid
            and not C_EventUtils.IsEventValid("ACTIVE_TALENT_GROUP_CHANGED")) then
    evFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
end
evFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_ENABLED" then
        if _flipPending then
            _flipPending = false
            EllesmereUI.Conditions_Recheck()
        end
        return
    end
    if event == "INPUT_DEVICE_INTERFACE_TRANSITION" then
        -- The style is read one frame after the transition event. A recheck
        -- in combat flags itself and the regen drain above re-resolves.
        C_Timer.After(0, EllesmereUI.Conditions_Recheck)
        return
    end
    if event == "PLAYER_ENTERING_WORLD" then
        -- Bindings are per-profile data; re-assert after every load screen.
        EllesmereUI.Conditions_RebuildKeyBindings()
    end
    EllesmereUI.Conditions_Recheck()
end)
