if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUI_BlizzardParty.lua
--  Shared "Hide Blizzard Party Panel" feature.
--
--  Hides the Blizzard CompactRaidFrameManager -- the collapsed sidebar panel on
--  the left of the screen (ready check, role poll, raid world markers, etc.).
--  Lives in the parent so the QoL and Raid Frames modules drive the EXACT same
--  implementation and the same saved setting (EllesmereUIDB.hideBlizzardPartyFrame),
--  with no behaviour differing between the two toggles.
--
--  Default: whatever the user has saved; unset = shown (off).
--
--  Mechanism: reparent the manager to a hidden frame (Blizzard's own code does
--  not reparent it, so the hide holds). SetParent is blocked in combat, so a
--  change made in combat waits on the core's combat queue. When the setting is
--  off, the manager is reparented back to its original parent. Blizzard keeps
--  its shown state current meanwhile (shown only in a group), so the restore
--  never calls Show().
-------------------------------------------------------------------------------

local _partyHiddenParent
local _partyOrigParent

local function ApplyHideBlizzardPartyFrame()
    local shouldHide = EllesmereUIDB and EllesmereUIDB.hideBlizzardPartyFrame
    -- Never hidden this session and not wanted hidden: nothing to apply.
    if not shouldHide and not _partyOrigParent then return end
    local mgr = CompactRaidFrameManager
    if not mgr then return end
    if InCombatLockdown() then
        EllesmereUI.CombatQueue.Defer("BlizzardPartyPanel", ApplyHideBlizzardPartyFrame)
        return
    end

    if shouldHide then
        if not _partyHiddenParent then
            _partyHiddenParent = CreateFrame("Frame")
            _partyHiddenParent:Hide()
        end
        if not _partyOrigParent then
            _partyOrigParent = mgr:GetParent()
        end
        if mgr:GetParent() ~= _partyHiddenParent then
            mgr:SetParent(_partyHiddenParent)
        end
    elseif mgr:GetParent() ~= _partyOrigParent then
        mgr:SetParent(_partyOrigParent)
    end
end

EllesmereUI._applyHideBlizzardPartyFrame = ApplyHideBlizzardPartyFrame

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
initFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
initFrame:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_ENTERING_WORLD" then
        self:UnregisterEvent("PLAYER_ENTERING_WORLD")
    end
    ApplyHideBlizzardPartyFrame()
end)
