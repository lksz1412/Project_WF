if EUI_CLIENT_BLOCKED then return end -- pre-12.1 client failsafe (EllesmereUI_ClientGate.lua)
-------------------------------------------------------------------------------
--  EllesmereUI_VideoGuides.lua
--
--  Reusable VIDEO GUIDE popup engine: announcement-quality popups whose body
--  is a pre-selected read-only URL box (the only keystroke a user needs is
--  Ctrl+C) plus a single Okay button. Each guide brings its own unique top
--  art via an `art` callback drawing into the engine's header band.
--
--  API (EllesmereUI.VideoGuides):
--    Register(id, def) -- def = { title, blurb, url, footnote?, eyebrow?,
--                        accent?, height?, art = function(popup, ctx) }
--    Show(id)          -- show unconditionally (future section icons call this)
--    FireOnce(id)      -- first time ever: stamps seen + shows, returns true
--                        (callers use true to swallow the triggering click)
--    HasSeen(id)       -- reads the per-account seen map
--
--  Seen map: EllesmereUIDB.videoGuidesSeen[id] = true (per account, one flat
--  key for all guides forever). The shell (dimmer/popup/chrome) is built once
--  and reused; per-guide art containers are built once and swapped. Zero cost
--  at load: nothing is created until the first Show.
--
--  Guide #1 (settings_overrides) registers at the bottom of this file and is
--  fired by the spec-override toolbar glyph's first-ever click.
-------------------------------------------------------------------------------

local EllesmereUI = _G.EllesmereUI
if not EllesmereUI then return end

-- Suite-only: guides describe suite surfaces. Trigger sites nil-guard on
-- EllesmereUI.VideoGuides so standalone builds degrade to normal clicks.
local EUI_HOST_ADDON = ...
local IS_STANDALONE = type(EUI_HOST_ADDON) == "string" and EUI_HOST_ADDON:find("Standalone") ~= nil
if IS_STANDALONE then return end

local PP = EllesmereUI.PanelPP
local MakeBorder = EllesmereUI.MakeBorder

-- The override system's gold (used by guide art, exposed via ctx).
local GOLD = { r = 1, g = 0.82, b = 0.30 }

-- The 12.1 launch walkthrough video. ONE paste point: the launch announcement
-- popup (guide "midnight_121" below) and the What's New video banner
-- (EllesmereUIOptions/EUI__General_Options.lua, MakeVideoBannerCard) both read this.
EllesmereUI.MIDNIGHT_VIDEO_URL = "https://youtu.be/JadIGEr4Ixc"

local POPUP_W, POPUP_H = 470, 368
local ART_H = 88

local guides = {}      -- id -> def
local artFrames = {}   -- id -> built art container (band frame)

local function MarkSeen(id)
    if not EllesmereUIDB then EllesmereUIDB = {} end
    if not EllesmereUIDB.videoGuidesSeen then EllesmereUIDB.videoGuidesSeen = {} end
    EllesmereUIDB.videoGuidesSeen[id] = true
end

local function HasSeen(id)
    return (EllesmereUIDB and EllesmereUIDB.videoGuidesSeen
        and EllesmereUIDB.videoGuidesSeen[id]) or false
end

-- Right-pointing solid triangle: collapse the right edge of a color texture
-- to its vertical midpoint. Vertex indices: 1=UpperLeft, 2=LowerLeft,
-- 3=UpperRight, 4=LowerRight. Positive y offset is up.
local function MakeTriangle(parent, w, h, r, g, b, a)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetColorTexture(r, g, b, a or 1)
    PP.Size(t, w, h)
    t:SetVertexOffset(3, 0, -h / 2)
    t:SetVertexOffset(4, 0, h / 2)
    return t
end

-- Square play badge: dark chip, colored border (matches whatever art it sits
-- beside), white triangle nudged right for optical centering.
local function MakePlayBadge(parent, size, color)
    local badge = CreateFrame("Frame", nil, parent)
    badge:SetFrameLevel(parent:GetFrameLevel() + 3)
    PP.Size(badge, size, size)
    local chip = badge:CreateTexture(nil, "BACKGROUND")
    chip:SetAllPoints()
    chip:SetColorTexture(0.062, 0.050, 0.039, 0.95)
    MakeBorder(badge, color.r, color.g, color.b, 0.85, PP)
    local tri = MakeTriangle(badge, math.floor(size * 0.36), math.floor(size * 0.42), 1, 1, 1, 0.95)
    PP.Point(tri, "CENTER", badge, "CENTER", size * 0.05, 0)
    return badge
end

-------------------------------------------------------------------------------
--  Tutorial tips: small one-time play badges attached beside UI entry points
--  (nav rows, section headers). Clicking one opens its video guide and
--  retires the badge FOREVER (per account); until then it always shows.
--  Visual: a 16px play icon in the suite accent -- present but never in the way.
-------------------------------------------------------------------------------
local liveTips = {}   -- tipId -> tip frame (RefreshTips re-evaluates these)

local function TipSeen(id)
    return (EllesmereUIDB and EllesmereUIDB.tutorialTipsSeen
        and EllesmereUIDB.tutorialTipsSeen[id]) or false
end

local function MarkTipSeen(id)
    if not EllesmereUIDB then EllesmereUIDB = {} end
    if not EllesmereUIDB.tutorialTipsSeen then EllesmereUIDB.tutorialTipsSeen = {} end
    EllesmereUIDB.tutorialTipsSeen[id] = true
end

-------------------------------------------------------------------------------
--  Shell: built once, reused for every guide. `ui` holds every retintable /
--  retextable piece; `cur` is the accent table the hover closures read (the
--  shell outlives any single guide, so closures must never capture r,g,b).
-------------------------------------------------------------------------------
local ui        -- nil until first Show
local cur = { r = 0, g = 0, b = 0 }
local FONT

local function Dismiss()
    if not ui then return end
    ui.eb:ClearFocus()
    ui.dimmer:Hide()
    -- Per-guide dismiss hook (def.onDismiss): announcement guides use it to
    -- release the login popup chain (conflict check handoff). Runs on every
    -- close path: Okay, Escape, Enter, and outside click all land here.
    local cb = ui._onDismiss
    if cb then ui._onDismiss = nil; cb() end
end

local function BuildShell()
    if ui then return end
    FONT = EllesmereUI._font or ("Interface\\AddOns\\EllesmereUI\\media\\fonts\\Expressway.ttf")
    ui = {}

    -- Dimmer: eats stray clicks/wheel; clicking anywhere outside the panel
    -- closes the guide (the popup itself is mouse-enabled, so clicks over it
    -- never reach this handler). No bump: Show() scales both frames per open
    -- (the outline refits on show). Escape closes (the
    -- EditBox path handles it while focused; this covers an unfocused box).
    local dimmer, popup = EllesmereUI.BuildPopupShell("EUIVideoGuide", {
        w = POPUP_W, h = POPUP_H, onDimmerDown = Dismiss, onEscape = Dismiss,
    })
    ui.dimmer = dimmer
    ui.popup = popup

    -- Art band: full-bleed dark well flush to the top edge, accent rule
    -- underneath. Per-guide art containers are children created in SetGuide.
    local well = popup:CreateTexture(nil, "BACKGROUND", nil, 1)
    well:SetColorTexture(0.056, 0.045, 0.034, 1)
    PP.Point(well, "TOPLEFT", popup, "TOPLEFT", 0, 0)
    PP.Point(well, "TOPRIGHT", popup, "TOPRIGHT", 0, 0)
    well:SetHeight(ART_H)
    -- The popup's shape: the well's top corners follow the round outline.
    well:AddMaskTexture(popup._brd.bodyMask)
    ui.well = well
    local rule = popup:CreateTexture(nil, "BACKGROUND", nil, 2)
    PP.Point(rule, "TOPLEFT", popup, "TOPLEFT", 0, -ART_H)
    PP.Point(rule, "TOPRIGHT", popup, "TOPRIGHT", 0, -ART_H)
    rule:SetHeight(1)
    ui.rule = rule

    -- Eyebrow: play triangle + "VIDEO GUIDE"
    local eyebrow = popup:CreateFontString(nil, "OVERLAY")
    eyebrow:SetFont(FONT, 13, "")
    PP.Point(eyebrow, "TOP", popup, "TOP", 0, -(ART_H + 16))
    ui.eyebrow = eyebrow
    local tri = MakeTriangle(popup, 9, 10, 1, 1, 1, 0.9)
    PP.Point(tri, "RIGHT", eyebrow, "LEFT", -7, 0)
    ui.tri = tri

    -- Title
    local title = popup:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT, 25, "")
    title:SetTextColor(1, 1, 1, 1)
    PP.Point(title, "TOP", eyebrow, "BOTTOM", 0, -6)
    ui.title = title

    -- Blurb
    local blurb = popup:CreateFontString(nil, "OVERLAY")
    blurb:SetFont(FONT, 14, "")
    blurb:SetTextColor(1, 1, 1, 0.55)
    blurb:SetWidth(POPUP_W - 80)
    blurb:SetJustifyH("CENTER")
    blurb:SetWordWrap(true)
    PP.Point(blurb, "TOP", title, "BOTTOM", 0, -12)
    ui.blurb = blurb

    -- Optional bullet rows between the blurb and the URL well (def.bullets =
    -- up to two arrays of short labels; announcement guides list their hero
    -- topics here). Hidden and skipped by anchoring for plain guides.
    local bulletRow1 = popup:CreateFontString(nil, "OVERLAY")
    bulletRow1:SetFont(FONT, 13, "")
    bulletRow1:SetTextColor(1, 1, 1, 0.72)
    bulletRow1:SetJustifyH("CENTER")
    PP.Point(bulletRow1, "TOP", blurb, "BOTTOM", 0, -14)
    bulletRow1:Hide()
    ui.bulletRow1 = bulletRow1
    local bulletRow2 = popup:CreateFontString(nil, "OVERLAY")
    bulletRow2:SetFont(FONT, 13, "")
    bulletRow2:SetTextColor(1, 1, 1, 0.72)
    bulletRow2:SetJustifyH("CENTER")
    PP.Point(bulletRow2, "TOP", bulletRow1, "BOTTOM", 0, -8)
    bulletRow2:Hide()
    ui.bulletRow2 = bulletRow2

    -- URL well + read-only EditBox (always-selected; Ctrl+C is the point)
    local urlWell = CreateFrame("Frame", nil, popup)
    urlWell:SetFrameLevel(popup:GetFrameLevel() + 2)
    PP.Size(urlWell, 350, 34)
    PP.Point(urlWell, "TOP", blurb, "BOTTOM", 0, -18)
    local wbg = urlWell:CreateTexture(nil, "BACKGROUND")
    wbg:SetAllPoints()
    wbg:SetColorTexture(0.045, 0.035, 0.027, 1)
    -- Neutral border (never accent-tinted): the link-blue text carries the
    -- "this is the link" read on its own.
    ui.urlBrd = EllesmereUI.MakeRoundedBorder(urlWell, 1, 1, 1, 0.22, wbg)
    ui.urlWell = urlWell

    -- Hint under the well (also doubles as the Ctrl+C confirmation line)
    local hint = popup:CreateFontString(nil, "OVERLAY")
    hint:SetFont(FONT, 11, "")
    hint:SetTextColor(1, 1, 1, 0.45)
    PP.Point(hint, "TOP", urlWell, "BOTTOM", 0, -8)
    ui.hint = hint

    local eb = CreateFrame("EditBox", nil, urlWell)
    eb:SetAllPoints(urlWell)
    eb:SetMultiLine(false)
    eb:SetAutoFocus(false)
    eb:SetFont(FONT, 13, "")
    eb:SetJustifyH("CENTER")
    eb:SetTextInsets(12, 12, 0, 0)
    eb:SetTextColor(0.55, 0.75, 1.0, 1)   -- link blue
    eb:SetScript("OnMouseUp", function(self)
        C_Timer.After(0, function() self:SetFocus(); self:HighlightText() end)
    end)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    -- Read-only: typing/paste/cut restore the URL and re-select.
    eb:SetScript("OnChar", function(self)
        self:SetText(self._readOnly or ""); self:HighlightText()
    end)
    eb:SetScript("OnTextChanged", function(self, userInput)
        if userInput then self:SetText(self._readOnly or ""); self:HighlightText() end
    end)
    eb:SetScript("OnEscapePressed", function(self) Dismiss() end)
    eb:SetScript("OnEnterPressed", function(self) Dismiss() end)
    eb:SetScript("OnKeyDown", function(self, key)
        if key == "C" and IsControlKeyDown() then
            hint:SetText("Link copied - paste it into your browser")
            hint:SetTextColor(cur.r, cur.g, cur.b, 0.9)
        end
    end)
    ui.eb = eb

    -- Single centered Okay button (accent primary)
    local okBtn = CreateFrame("Button", nil, popup)
    okBtn:SetFrameLevel(popup:GetFrameLevel() + 2)
    PP.Size(okBtn, 160, 36)
    PP.Point(okBtn, "BOTTOM", popup, "BOTTOM", 0, 42)
    local okBg = okBtn:CreateTexture(nil, "BACKGROUND")
    okBg:SetAllPoints()
    okBg:SetColorTexture(0.077, 0.068, 0.058, 0.92)
    ui.okBrd = EllesmereUI.MakeRoundedBorder(okBtn, 1, 1, 1, 0.9, okBg)
    local okLbl = okBtn:CreateFontString(nil, "OVERLAY")
    okLbl:SetFont(FONT, 15, "")
    PP.Point(okLbl, "CENTER", okBtn, "CENTER", 0, 0)
    okLbl:SetText("Okay")
    ui.okLbl = okLbl
    ui.okBtn = okBtn
    okBtn:SetScript("OnEnter", function()
        okLbl:SetTextColor(cur.r, cur.g, cur.b, 1)
        ui.okBrd:SetColor(cur.r, cur.g, cur.b, 1)
    end)
    okBtn:SetScript("OnLeave", function()
        okLbl:SetTextColor(cur.r, cur.g, cur.b, 0.9)
        ui.okBrd:SetColor(cur.r, cur.g, cur.b, 0.9)
    end)
    okBtn:SetScript("OnClick", function() Dismiss() end)

    -- Footnote
    local footnote = popup:CreateFontString(nil, "OVERLAY")
    footnote:SetFont(FONT, 12, "")
    footnote:SetTextColor(1, 1, 1, 0.35)
    footnote:SetWidth(POPUP_W - 80)
    footnote:SetJustifyH("CENTER")
    PP.Point(footnote, "BOTTOM", popup, "BOTTOM", 0, 16)
    ui.footnote = footnote
end

--- Populates the shared shell for one guide: texts, accent retints, art swap.
local function SetGuide(id, def)
    local accent = def.accent or EllesmereUI.ELLESMERE_GREEN or { r = 0.05, g = 0.83, b = 0.62 }
    cur.r, cur.g, cur.b = accent.r, accent.g, accent.b

    -- Per-guide geometry, RESET to the defaults every call (the shell is
    -- shared, so a big announcement guide must not leak its size into the
    -- next plain guide). Width-dependent pieces re-measure here too.
    local w = def.width or POPUP_W
    local artH = def.artHeight or ART_H
    -- Per-guide vertical rhythm (def.gaps): every inter-element gap resets to
    -- the compact build-time default when unspecified, so plain guides keep
    -- their exact original layout and big announcements can breathe.
    local gaps = def.gaps or {}
    local gEyebrow  = gaps.eyebrow or 16
    local gTitle    = gaps.title or 6
    local gBlurb    = gaps.blurb or 12
    local gBullets  = gaps.bullets or 14
    local gBRows    = gaps.bulletRows or 8
    local gUrl      = gaps.url
    local gHint     = gaps.hint or 8
    PP.Size(ui.popup, w, def.height or POPUP_H)
    ui.well:SetHeight(artH)
    ui.rule:ClearAllPoints()
    PP.Point(ui.rule, "TOPLEFT", ui.popup, "TOPLEFT", 0, -artH)
    PP.Point(ui.rule, "TOPRIGHT", ui.popup, "TOPRIGHT", 0, -artH)
    ui.eyebrow:ClearAllPoints()
    PP.Point(ui.eyebrow, "TOP", ui.popup, "TOP", 0, -(artH + gEyebrow))
    ui.title:ClearAllPoints()
    PP.Point(ui.title, "TOP", ui.eyebrow, "BOTTOM", 0, -gTitle)
    ui.blurb:ClearAllPoints()
    PP.Point(ui.blurb, "TOP", ui.title, "BOTTOM", 0, -gBlurb)
    ui.bulletRow1:ClearAllPoints()
    PP.Point(ui.bulletRow1, "TOP", ui.blurb, "BOTTOM", 0, -gBullets)
    ui.bulletRow2:ClearAllPoints()
    PP.Point(ui.bulletRow2, "TOP", ui.bulletRow1, "BOTTOM", 0, -gBRows)
    ui.hint:ClearAllPoints()
    PP.Point(ui.hint, "TOP", ui.urlWell, "BOTTOM", 0, -gHint)
    ui.okBtn:ClearAllPoints()
    PP.Point(ui.okBtn, "BOTTOM", ui.popup, "BOTTOM", 0, gaps.button or 42)
    ui.footnote:ClearAllPoints()
    PP.Point(ui.footnote, "BOTTOM", ui.popup, "BOTTOM", 0, gaps.footnote or 16)
    ui.blurb:SetWidth(w - 80)
    ui.footnote:SetWidth(w - 80)
    PP.Size(ui.urlWell, def.urlWidth or 350, 34)
    ui.okLbl:SetText(EllesmereUI.L(def.okText or "Okay"))
    ui._onDismiss = def.onDismiss

    -- Bullet rows: accent-dotted short labels, up to two centered lines; the
    -- URL well re-anchors below them when present, back onto the blurb when not.
    ui.urlWell:ClearAllPoints()
    if def.bullets and def.bullets[1] then
        local hex = string.format("%02x%02x%02x",
            math.floor(accent.r * 255 + 0.5), math.floor(accent.g * 255 + 0.5), math.floor(accent.b * 255 + 0.5))
        local function Line(items)
            local parts = {}
            for i = 1, #items do
                parts[i] = "|cff" .. hex .. "\226\128\162|r " .. items[i]
            end
            return table.concat(parts, "    ")
        end
        ui.bulletRow1:SetText(Line(def.bullets[1]))
        ui.bulletRow1:Show()
        if def.bullets[2] then
            ui.bulletRow2:SetText(Line(def.bullets[2]))
            ui.bulletRow2:Show()
            PP.Point(ui.urlWell, "TOP", ui.bulletRow2, "BOTTOM", 0, -(gUrl or 16))
        else
            ui.bulletRow2:Hide()
            PP.Point(ui.urlWell, "TOP", ui.bulletRow1, "BOTTOM", 0, -(gUrl or 16))
        end
    else
        ui.bulletRow1:Hide()
        ui.bulletRow2:Hide()
        PP.Point(ui.urlWell, "TOP", ui.blurb, "BOTTOM", 0, -(gUrl or 18))
    end

    ui.eyebrow:SetText(EllesmereUI.L(def.eyebrow or "VIDEO GUIDE"))
    ui.eyebrow:SetTextColor(accent.r, accent.g, accent.b, 0.9)
    ui.tri:SetColorTexture(accent.r, accent.g, accent.b, 0.9)
    ui.rule:SetColorTexture(accent.r, accent.g, accent.b, 0.35)
    ui.title:SetText(EllesmereUI.L(def.title or ""))
    ui.blurb:SetText(EllesmereUI.L(def.blurb or ""))
    ui.hint:SetText(EllesmereUI.L("Ctrl+C to copy, Escape to close"))
    ui.hint:SetTextColor(1, 1, 1, 0.45)
    ui.okLbl:SetTextColor(accent.r, accent.g, accent.b, 0.9)
    ui.okBrd:SetColor(accent.r, accent.g, accent.b, 0.9)
    ui.footnote:SetText(EllesmereUI.L(def.footnote or ""))

    ui.eb._readOnly = def.url or ""
    ui.eb:SetText(def.url or "")
    ui.eb:SetCursorPosition(0)

    -- Art swap: hide every built band, then build-once-and-show this one.
    for _, band in pairs(artFrames) do band:Hide() end
    if def.art then
        local band = artFrames[id]
        if not band then
            band = CreateFrame("Frame", nil, ui.popup)
            band:SetFrameLevel(ui.popup:GetFrameLevel() + 1)
            -- 2-unit inset keeps child-frame art off the popup's 1px border.
            PP.Point(band, "TOPLEFT", ui.popup, "TOPLEFT", 2, -2)
            PP.Point(band, "TOPRIGHT", ui.popup, "TOPRIGHT", -2, -2)
            band:SetHeight(artH - 2)
            artFrames[id] = band
            local ctx = {
                band = band,
                W = w - 4,
                H = artH - 2,
                PP = PP,
                MakeBorder = MakeBorder,
                FONT = FONT,
                accent = { r = accent.r, g = accent.g, b = accent.b },
                GOLD = GOLD,
                MakeTriangle = MakeTriangle,
                MakePlayBadge = function(parent, size, color)
                    return MakePlayBadge(parent, size, color or accent)
                end,
            }
            -- Art failures must never break the popup: plain well on error.
            local ok = pcall(def.art, ui.popup, ctx)
            if not ok then band:Hide() end
        end
        band:Show()
    end
end

local function Show(id)
    local def = guides[id]
    if not def then return false end
    -- The trigger's widget tooltip is still on screen at click time.
    EllesmereUI.HideWidgetTooltip()
    BuildShell()
    local ppScale = (EllesmereUI.GetPopupScale()) or 1
    ui.dimmer:SetScale(ppScale)
    ui.popup:SetScale(EllesmereUI.PopupBump(1.15))
    SetGuide(id, def)
    ui.dimmer:Show()
    -- A guide opened over another resizes and moves these without a new show.
    ui.urlBrd:Fit(); ui.okBrd:Fit()
    -- Pre-select the URL so the only keystroke needed is Ctrl+C.
    local eb = ui.eb
    C_Timer.After(0, function() eb:SetFocus(); eb:HighlightText() end)
    return true
end

--- Attaches a one-time tutorial tip badge to a region. tipId doubles as the
--- guide id shown on click (override via opts.guide). opts: point/relPoint/
--- x/y (default: inside the region's right edge), size (16), tooltip.
--- Idempotent per tipId; never builds a retired tip. Returns the tip frame.
local function AttachTip(region, tipId, opts)
    if not region or not tipId then return nil end
    local existing = liveTips[tipId]
    if existing then
        existing:SetShown(not TipSeen(tipId))
        return existing
    end
    if TipSeen(tipId) then return nil end
    opts = opts or {}
    local size = opts.size or 16

    local tip = CreateFrame("Button", nil, region)
    tip:SetFrameLevel(region:GetFrameLevel() + 5)
    PP.Size(tip, size, size)
    PP.Point(tip, opts.point or "RIGHT", region, opts.relPoint or "RIGHT",
        opts.x or -10, opts.y or 0)
    -- Bare accent-tinted play icon -- no chip background, no border. The
    -- button itself stays full-size as the click/hover target. RegAccent
    -- keeps the tint live when the accent color changes (dedupes by obj).
    local icon = tip:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture("Interface\\AddOns\\EllesmereUI\\media\\icons\\play.png")
    local EG = EllesmereUI.ELLESMERE_GREEN
    if EG then
        icon:SetVertexColor(EG.r, EG.g, EG.b, 1)
        EllesmereUI.RegAccent({ type = "vertex", obj = icon })
    else
        icon:SetVertexColor(1, 1, 1, 0.9)
    end

    -- Deliberately STATIC (no pulse): the badge stays on the UI until
    -- clicked, so it must read as a quiet help affordance the user consults
    -- on their own time -- never as a notification begging for a click.
    -- Slightly dimmed idle, full brightness on hover.
    tip:SetAlpha(0.8)

    local tipText = opts.tooltip or "Video Guide"
    tip:SetScript("OnEnter", function(self)
        self:SetAlpha(1)
        if EllesmereUI.ShowWidgetTooltip then
            EllesmereUI.ShowWidgetTooltip(self, (EllesmereUI.L(tipText)) or tipText)
        end
    end)
    tip:SetScript("OnLeave", function(self)
        EllesmereUI.HideWidgetTooltip()
        self:SetAlpha(0.8)
    end)
    tip:RegisterForClicks("LeftButtonUp")
    tip:SetScript("OnClick", function(self)
        -- One shot: retire forever, then open the guide.
        MarkTipSeen(tipId)
        EllesmereUI.HideWidgetTooltip()
        self:Hide()
        Show(opts.guide or tipId)
    end)

    liveTips[tipId] = tip
    return tip
end

--- Re-evaluates every attached tip (the /euivideos reset brings retired ones back).
local function RefreshTips()
    for id, tip in pairs(liveTips) do
        tip:SetShown(not TipSeen(id))
    end
end

EllesmereUI.VideoGuides = {
    Register = function(id, def) guides[id] = def end,
    Show = Show,
    HasSeen = HasSeen,
    -- Stamps BEFORE showing: a crash/reload mid-popup can never re-fire a
    -- once-ever guide (it stays reachable via Show).
    FireOnce = function(id)
        if HasSeen(id) then return false end
        if not guides[id] then return false end
        MarkSeen(id)
        return Show(id)
    end,
    AttachTip = AttachTip,
    RefreshTips = RefreshTips,
    TipsEnabled = function() return true end,   -- tips always show until clicked
}

-- Reset command: clears the seen state for every video guide popup and every
-- tutorial tip badge, so all of them show again as if never clicked. Live
-- badges on the current UI reappear immediately.
SLASH_EUIVIDEOS1 = "/euivideos"
SlashCmdList["EUIVIDEOS"] = function()
    if EllesmereUIDB then
        EllesmereUIDB.videoGuidesSeen = nil
        EllesmereUIDB.tutorialTipsSeen = nil
    end
    RefreshTips()
    print(EllesmereUI.L("|cff00ff98EllesmereUI:|r Video guides and tutorial tips reset. Badges are back; one-time popups will fire again."))
end

-------------------------------------------------------------------------------
--  Guide #0: the 12.1 launch announcement ("midnight_121")
--
--  The biggest popup the engine renders (wider shell, taller art band): a
--  one-time login announcement for EXISTING users pointing at the 12.1
--  walkthrough video, with the URL pre-selected so Ctrl+C is the only
--  keystroke needed. Fired by the loader at the bottom of this file; the
--  What's New page carries a matching full-width video banner.
-------------------------------------------------------------------------------
do
    local function ReleaseLaunchChain()
        EllesmereUI._launchVideoIntroPending = nil
        if EllesmereUIDB and EllesmereUIDB.firstInstallPopupShown and EllesmereUI._RunConflictCheck then
            C_Timer.After(0.3, EllesmereUI._RunConflictCheck)
        end
    end

    EllesmereUI.VideoGuides.Register("midnight_121", {
        eyebrow  = "IMPORTANT EUI VIDEO GUIDE",
        title    = "Everything New in 12.1",
        blurb    = "Patch 12.1 changes a lot, and EllesmereUI changed with it. This video walks you through the most important changes so you can jump straight back in. Copy the link below and watch it in your browser.",
        url      = EllesmereUI.MIDNIGHT_VIDEO_URL,
        footnote = "Watch anytime: the link also lives at the top of Patch Notes.",
        bullets  = {
            { "Quickdraw", "Chat Rewrite", "Buff Reminders" },
            { "Damage Meters", "Aura Filtering", "Player Aura Bars" },
        },
        -- Spacious rhythm for the launch announcement: the compact defaults
        -- are tuned for the small 470px guides and read cramped at this size.
        gaps = {
            eyebrow = 26, title = 10, blurb = 16,
            bullets = 24, bulletRows = 12, url = 24, hint = 10,
            button = 50, footnote = 20,
        },
        width    = 560,
        height   = 508,
        artHeight = 112,
        urlWidth = 420,
        okText   = "Got It",
        onDismiss = ReleaseLaunchChain,
        art = function(popup, ctx)
            local PPx, band = ctx.PP, ctx.band
            local EG = ctx.accent

            -- Centerpiece: the video-player mock -- accent-bordered frame with
            -- a progress bar mid-watch -- "playing" the full wordmark: accent
            -- "12.1" plus white "EUI Video Guide".
            local player = CreateFrame("Frame", nil, band)
            player:SetFrameLevel(band:GetFrameLevel() + 2)
            PPx.Size(player, 240, 78)
            PPx.Point(player, "CENTER", band, "CENTER", 0, 0)
            local pbg = player:CreateTexture(nil, "BACKGROUND")
            pbg:SetAllPoints()
            pbg:SetColorTexture(0.056, 0.045, 0.034, 1)
            ctx.MakeBorder(player, EG.r, EG.g, EG.b, 0.8, PPx)

            local hex = string.format("%02x%02x%02x",
                math.floor(EG.r * 255 + 0.5), math.floor(EG.g * 255 + 0.5), math.floor(EG.b * 255 + 0.5))
            local wordmark = player:CreateFontString(nil, "OVERLAY")
            wordmark:SetFont(ctx.FONT, 26, "")
            wordmark:SetTextColor(1, 1, 1, 0.95)
            PPx.Point(wordmark, "TOP", player, "TOP", 0, -14)
            wordmark:SetText("|cff" .. hex .. "12.1|r EUI Guide")

            -- Progress bar: track, accent fill mid-watch, white playhead spark.
            local track = CreateFrame("Frame", nil, player)
            track:SetFrameLevel(player:GetFrameLevel() + 1)
            PPx.Size(track, 216, 7)
            PPx.Point(track, "BOTTOM", player, "BOTTOM", 0, 12)
            local tbg = track:CreateTexture(nil, "BACKGROUND")
            tbg:SetAllPoints()
            tbg:SetColorTexture(1, 1, 1, 0.10)
            local fill = track:CreateTexture(nil, "ARTWORK")
            fill:SetColorTexture(EG.r, EG.g, EG.b, 0.85)
            PPx.Size(fill, 93, 7)
            PPx.Point(fill, "LEFT", track, "LEFT", 0, 0)
            local spark = track:CreateTexture(nil, "OVERLAY")
            spark:SetColorTexture(1, 1, 1, 0.95)
            PPx.Size(spark, 2, 13)
            PPx.Point(spark, "CENTER", fill, "RIGHT", 0, 0)

            -- Mirrored flanking streams: three play glyphs swelling toward
            -- the wordmark on each side (the "press play" pull).
            local defs = { { 16, 0.10 }, { 22, 0.16 }, { 28, 0.24 } }  -- outermost -> innermost
            for _, side in ipairs({ "LEFT", "RIGHT" }) do
                local off = 44
                for i = 1, 3 do
                    local sz, a = defs[i][1], defs[i][2]
                    local t = ctx.MakeTriangle(band, math.floor(sz * 0.8), sz, EG.r, EG.g, EG.b, a)
                    if side == "LEFT" then
                        PPx.Point(t, "LEFT", band, "LEFT", off, 0)
                    else
                        PPx.Point(t, "RIGHT", band, "RIGHT", -off, 0)
                    end
                    off = off + math.floor(sz * 0.8) + 10
                end
            end
        end,
    })

    ---------------------------------------------------------------------------
    --  Trigger: existing users only, once, at login. The new-vs-existing
    --  guarantee mirrors the retired announcement popups: at the parent
    --  ADDON_LOADED, EllesmereUIDB still reflects ONLY the previous session's
    --  data (children have not initialized their per-profile DBs yet), so a
    --  profile already carrying `addons` data = existing/upgrade user. Fresh
    --  installs are stamped seen at login and never see it. The pending flag
    --  holds the auto addon-conflict check (EllesmereUI.lua) until dismiss.
    ---------------------------------------------------------------------------
    local _decision

    local function ComputeDecision()
        -- RETIRED 2026-09-19: superseded by a newer login announcement (now
        -- EllesmereUI_KickTrackerPopup.lua) -- only the newest
        -- login announcement fires, so users upgrading across versions never
        -- see two intro popups back to back. The guide itself stays reachable
        -- from the Patch Notes video banner and /euivideos. Delete the next
        -- line to revive the login trigger.
        if true then return "done" end
        -- WoW Forever never gets the retail launch guide. A session the
        -- first-install picker owns is a fresh install whatever the profile
        -- store holds (the picker's loader runs first and seeds data on Forever).
        if EllesmereUI.IS_FOREVER or EllesmereUI._firstInstallPending then return "new" end
        if not EllesmereUIDB then return "new" end
        if HasSeen("midnight_121") then return "done" end
        local profiles = EllesmereUIDB.profiles
        if type(profiles) == "table" then
            for _, prof in pairs(profiles) do
                if type(prof) == "table" and type(prof.addons) == "table" and next(prof.addons) then
                    return "show"
                end
            end
        end
        return "new"
    end

    local loader = CreateFrame("Frame")
    loader:RegisterEvent("ADDON_LOADED")
    loader:RegisterEvent("PLAYER_LOGIN")
    loader:SetScript("OnEvent", function(self, event, addonName)
        if event == "ADDON_LOADED" then
            if addonName ~= "EllesmereUI" then return end
            self:UnregisterEvent("ADDON_LOADED")
            _decision = ComputeDecision()
            if _decision == "show" then
                EllesmereUI._launchVideoIntroPending = true
            end
        elseif event == "PLAYER_LOGIN" then
            self:UnregisterEvent("PLAYER_LOGIN")
            if _decision == "new" or EllesmereUI._firstInstallPending then
                -- Stamp fresh installs so the announcement never fires later.
                -- The picker's pending flag is the authority on "fresh", so a
                -- decision reached ahead of it still stands down here.
                MarkSeen("midnight_121")
                if EllesmereUI._launchVideoIntroPending then ReleaseLaunchChain() end
                return
            end
            if _decision ~= "show" then return end
            C_Timer.After(0.8, function()
                -- FireOnce stamps before showing (crash-safe); false = seen
                -- since the decision was made, so just release the chain.
                if not EllesmereUI.VideoGuides.FireOnce("midnight_121") then
                    ReleaseLaunchChain()
                end
            end)
        end
    end)
end

-------------------------------------------------------------------------------
--  Guide #1: Settings Overrides
--  Fired by the spec-override toolbar glyph's first-ever click (see the
--  OnClick in EUI_SpecOverrides_Popups.lua / SpecOverrides_SetupButton).
--  Guide #4 (override_default_edit) shares its art: the one-time warning
--  fired by the first BASE edit of a setting that has an override.
-------------------------------------------------------------------------------
do
    local MODERN_SPRITE = "Interface\\AddOns\\EllesmereUI\\media\\icons\\class-full\\modern.tga"
    local ART_COORDS = {
        { 0, 0.125, 0, 0.125 },         -- WARRIOR
        { 0, 0.125, 0.25, 0.375 },      -- PALADIN
        { 0.125, 0.25, 0.25, 0.375 },   -- DEATHKNIGHT
    }
    local OVERRIDES_VIDEO_URL = "https://youtu.be/8VKV26lrGSc"

    -- Shared art: ghost card behind a gold override-group card (tank class
    -- glyphs + gold name line) with a play badge beside it. Each guide id builds
    -- its own band from this, so both popups read as the same system.
    local function OverridesArt(popup, ctx)
        local PPx, band = ctx.PP, ctx.band
        -- Ghost card behind (the layered-overrides read).
        local ghost = CreateFrame("Frame", nil, band)
        ghost:SetFrameLevel(band:GetFrameLevel() + 1)
        PPx.Size(ghost, 150, 52)
        PPx.Point(ghost, "CENTER", band, "CENTER", -39, -6)
        local gbg = ghost:CreateTexture(nil, "BACKGROUND")
        gbg:SetAllPoints()
        gbg:SetColorTexture(0.104, 0.096, 0.089, 1)
        ctx.MakeBorder(ghost, 1, 1, 1, 0.08, PPx)

        -- Gold override-group card (tank class glyphs + gold name line).
        local card = CreateFrame("Frame", nil, band)
        card:SetFrameLevel(band:GetFrameLevel() + 2)
        PPx.Size(card, 150, 52)
        PPx.Point(card, "CENTER", band, "CENTER", -31, 2)
        local cbg = card:CreateTexture(nil, "BACKGROUND")
        cbg:SetAllPoints()
        cbg:SetColorTexture(0.121, 0.113, 0.106, 1)
        ctx.MakeBorder(card, ctx.GOLD.r, ctx.GOLD.g, ctx.GOLD.b, 0.85, PPx)

        local ICON, GAP = 20, 8
        local rowW = #ART_COORDS * ICON + (#ART_COORDS - 1) * GAP
        for k, c in ipairs(ART_COORDS) do
            local tex = card:CreateTexture(nil, "ARTWORK")
            PPx.Size(tex, ICON, ICON)
            PPx.Point(tex, "LEFT", card, "LEFT",
                (150 - rowW) / 2 + (k - 1) * (ICON + GAP), 5)
            tex:SetTexture(MODERN_SPRITE)
            tex:SetTexCoord(c[1], c[2], c[3], c[4])
        end
        local line = card:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(ctx.GOLD.r, ctx.GOLD.g, ctx.GOLD.b, 0.75)
        PPx.Size(line, 56, 3)
        PPx.Point(line, "BOTTOM", card, "BOTTOM", 0, 6)

        -- Play badge standing beside the card with a clear gap, border
        -- matching the card's gold: "watch the video about this system".
        local badge = ctx.MakePlayBadge(band, 44, ctx.GOLD)
        PPx.Point(badge, "LEFT", card, "RIGHT", 18, 0)
    end

    EllesmereUI.VideoGuides.Register("settings_overrides", {
        title = "Settings Overrides",
        blurb = "Settings Overrides are the most powerful system in EllesmereUI, and the deepest. A few minutes with this video will save you hours of working it out on your own.",
        url = OVERRIDES_VIDEO_URL,
        art = OverridesArt,
    })

    ---------------------------------------------------------------------------
    --  Guide #4: base edit of an overridden setting (one-time warning)
    --  Fired from EllesmereUI._NotifySettingWrite (EUI_SpecOverrides_Session.lua)
    --  the first time a Default Editing Mode edit lands on a gold-marked slot.
    --  Gold accent = the override system's own color; taller shell for the
    --  longer warning blurb (the OK button is bottom-anchored, so the extra
    --  height opens up between the URL hint and the button).
    ---------------------------------------------------------------------------
    EllesmereUI.VideoGuides.Register("override_default_edit", {
        eyebrow  = "OVERRIDES WARNING",
        accent   = GOLD,
        title    = "This Setting Has Overrides",
        blurb    = "You changed the default value of a setting that has overrides. Overrides keep their own values, so this change will not reach the specs or conditions they cover. To change it for an override, pick that override from the class glyph beside the module search bar and edit it there.",
        url      = OVERRIDES_VIDEO_URL,
        footnote = "Gold border settings have overrides. Hover info icon for details.",
        okText   = "I Understand",
        height   = 420,
        art      = OverridesArt,
    })
end

-------------------------------------------------------------------------------
--  Guide #2: Unlock Mode
--  Entry point: the tutorial tip badge on the Unlock Mode nav row (attached
--  in EllesmereUI.lua where the sidebar builds).
-------------------------------------------------------------------------------
do
    EllesmereUI.VideoGuides.Register("unlock_mode", {
        title = "Unlock Mode",
        blurb = "Unlock Mode is how you move and resize everything in EllesmereUI, and it is packed with tools: anchors, width matching, fallback anchors, per-group layouts. This video gets you fluent fast.",
        url = "https://youtu.be/h0zndXt-d_4",
        art = function(popup, ctx)
            local PPx, band = ctx.PP, ctx.band
            local EG = ctx.accent
            -- Two mover boxes (the unlock-mode read): a small one anchored to
            -- a large one, joined by an accent anchor line with an endpoint
            -- dot -- movers + anchors in one glance.
            local big = CreateFrame("Frame", nil, band)
            big:SetFrameLevel(band:GetFrameLevel() + 2)
            PPx.Size(big, 120, 46)
            PPx.Point(big, "CENTER", band, "CENTER", -58, 0)
            local bbg = big:CreateTexture(nil, "BACKGROUND")
            bbg:SetAllPoints()
            bbg:SetColorTexture(EG.r, EG.g, EG.b, 0.10)
            ctx.MakeBorder(big, EG.r, EG.g, EG.b, 0.7, PPx)
            -- Drag grip dots in the big mover's center.
            for k = 1, 3 do
                local dot = big:CreateTexture(nil, "ARTWORK")
                dot:SetColorTexture(1, 1, 1, 0.5)
                PPx.Size(dot, 3, 3)
                PPx.Point(dot, "CENTER", big, "CENTER", (k - 2) * 8, 0)
            end

            local small = CreateFrame("Frame", nil, band)
            small:SetFrameLevel(band:GetFrameLevel() + 2)
            PPx.Size(small, 56, 30)
            PPx.Point(small, "LEFT", big, "RIGHT", 26, 0)
            local sbg = small:CreateTexture(nil, "BACKGROUND")
            sbg:SetAllPoints()
            sbg:SetColorTexture(1, 1, 1, 0.05)
            ctx.MakeBorder(small, 1, 1, 1, 0.30, PPx)

            -- Anchor line joining them, with an endpoint dot on the small box.
            local line = band:CreateTexture(nil, "ARTWORK")
            line:SetColorTexture(EG.r, EG.g, EG.b, 0.8)
            PPx.Size(line, 26, 2)
            PPx.Point(line, "LEFT", big, "RIGHT", 0, 0)
            local anchorDot = band:CreateTexture(nil, "OVERLAY")
            anchorDot:SetColorTexture(EG.r, EG.g, EG.b, 1)
            PPx.Size(anchorDot, 6, 6)
            PPx.Point(anchorDot, "CENTER", small, "LEFT", 0, 0)

            -- Play badge beside the cluster.
            local badge = ctx.MakePlayBadge(band, 44)
            PPx.Point(badge, "LEFT", small, "RIGHT", 18, 0)
        end,
    })
end

-------------------------------------------------------------------------------
--  Guide #3: Cooldown Manager
--  Entry point: the tutorial tip badge in the sidebar, in the indent gutter
--  left of the "Cooldown Manager" label (attached in EllesmereUI.lua's
--  CreateAddonChildRow).
-------------------------------------------------------------------------------
do
    EllesmereUI.VideoGuides.Register("cooldown_manager", {
        title = "Cooldown Manager",
        blurb = "The Cooldown Manager can do far more than show cooldowns, it also has per-spell settings, bar glows, tracking bars and more! Check out some tips and tricks for getting more from it.",
        url = "https://youtu.be/AUNHEMzHw74",
        art = function(popup, ctx)
            local PPx, band = ctx.PP, ctx.band
            local EG = ctx.accent

            -- Three cooldown icon chips (the CDM read): the middle one lit
            -- with an accent border (the ready glow), the first keeping a
            -- dark lower half as a cooldown sweep still running.
            -- Cluster centering: the chips/bars block is BAR_W wide with the
            -- 44px play badge hanging 18px off its right edge, so seating the
            -- block's center at -(44+18)/2 centers block + badge as ONE unit.
            local ICON, GAP = 26, 7
            local BADGE, BADGE_GAP = 44, 18
            local baseX = -(BADGE + BADGE_GAP) / 2
            local chips = {}
            for k = 1, 3 do
                local chip = CreateFrame("Frame", nil, band)
                chip:SetFrameLevel(band:GetFrameLevel() + 2)
                PPx.Size(chip, ICON, ICON)
                PPx.Point(chip, "CENTER", band, "CENTER", baseX + (k - 2) * (ICON + GAP), 14)
                local cbg = chip:CreateTexture(nil, "BACKGROUND")
                cbg:SetAllPoints()
                if k == 2 then
                    cbg:SetColorTexture(EG.r * 0.22, EG.g * 0.22, EG.b * 0.22, 1)
                    ctx.MakeBorder(chip, EG.r, EG.g, EG.b, 0.9, PPx)
                else
                    cbg:SetColorTexture(0.104, 0.096, 0.089, 1)
                    ctx.MakeBorder(chip, 1, 1, 1, 0.15, PPx)
                end
                chips[k] = chip
            end
            local sweep = chips[1]:CreateTexture(nil, "ARTWORK")
            sweep:SetColorTexture(0, 0, 0, 0.6)
            PPx.Point(sweep, "BOTTOMLEFT", chips[1], "BOTTOMLEFT", 1, 1)
            PPx.Point(sweep, "BOTTOMRIGHT", chips[1], "BOTTOMRIGHT", -1, 1)
            sweep:SetHeight(11)

            -- Two tracking bars under the chips at different progress:
            -- accent fill + white spark each.
            local BAR_W = ICON * 3 + GAP * 2
            local function MakeBar(anchorTo, gapY, fillW)
                local bar = CreateFrame("Frame", nil, band)
                bar:SetFrameLevel(band:GetFrameLevel() + 2)
                PPx.Size(bar, BAR_W, 8)
                PPx.Point(bar, "TOP", anchorTo, "BOTTOM", 0, gapY)
                local wbg = bar:CreateTexture(nil, "BACKGROUND")
                wbg:SetAllPoints()
                wbg:SetColorTexture(0.104, 0.096, 0.089, 1)
                ctx.MakeBorder(bar, 1, 1, 1, 0.15, PPx)
                local fill = bar:CreateTexture(nil, "ARTWORK")
                fill:SetColorTexture(EG.r, EG.g, EG.b, 0.85)
                PPx.Size(fill, fillW, 6)
                PPx.Point(fill, "LEFT", bar, "LEFT", 1, 0)
                local spark = bar:CreateTexture(nil, "OVERLAY")
                spark:SetColorTexture(1, 1, 1, 0.9)
                PPx.Size(spark, 2, 12)
                PPx.Point(spark, "CENTER", fill, "RIGHT", 0, 0)
                return bar
            end
            local bar1 = MakeBar(chips[2], -7, 57)
            MakeBar(bar1, -5, 30)

            -- Play badge beside the cluster, centered on the cluster's vertical middle
            -- (chips sit at +14; chips + two bars span symmetrically around 0).
            local badge = ctx.MakePlayBadge(band, BADGE)
            PPx.Point(badge, "LEFT", chips[3], "RIGHT", BADGE_GAP, -14)
        end,
    })
end

-------------------------------------------------------------------------------
--  Guide #4: the presets website ("presets_website")
--
--  The in-game Popular Presets browser is retired; presets live on the
--  EllesmereUI website. Shown EVERY time (plain Show, never FireOnce) from
--  the Profiles page's Popular Presets card and the Presets top tab.
-------------------------------------------------------------------------------
-- ONE paste point for the website presets section (popup + any future banner).
EllesmereUI.PRESETS_URL = "https://ellesmereui.com/presets"

do
    EllesmereUI.VideoGuides.Register("presets_website", {
        eyebrow  = "ELLESMEREUI WEBSITE",
        title    = "Presets Have a New Home",
        blurb    = "Popular presets now live on the new EllesmereUI website including full previews, step-by-step install instructions, plus new presets added every day!",
        url      = EllesmereUI.PRESETS_URL,
        footnote = "Each preset's page includes its import string.",
        okText   = "Got It",
        art = function(popup, ctx)
            local PPx, band = ctx.PP, ctx.band
            local EG = ctx.accent

            -- A row of three preset "cards" (the website gallery read): each a
            -- mini tile with a title bar and two content lines, the center one
            -- lit with an accent border and accent title bar.
            local CARD_W, CARD_H, GAP = 64, 46, 12
            for k = 1, 3 do
                local isMid = (k == 2)
                local card = CreateFrame("Frame", nil, band)
                card:SetFrameLevel(band:GetFrameLevel() + 2)
                PPx.Size(card, CARD_W, CARD_H + (isMid and 8 or 0))
                PPx.Point(card, "CENTER", band, "CENTER", (k - 2) * (CARD_W + GAP), 0)
                local cbg = card:CreateTexture(nil, "BACKGROUND")
                cbg:SetAllPoints()
                cbg:SetColorTexture(0.056, 0.045, 0.034, 1)
                if isMid then
                    ctx.MakeBorder(card, EG.r, EG.g, EG.b, 0.85, PPx)
                else
                    ctx.MakeBorder(card, 1, 1, 1, 0.18, PPx)
                end

                local barTex = card:CreateTexture(nil, "ARTWORK")
                barTex:SetHeight(7)
                PPx.Point(barTex, "TOPLEFT", card, "TOPLEFT", 1, -1)
                PPx.Point(barTex, "TOPRIGHT", card, "TOPRIGHT", -1, -1)
                if isMid then
                    barTex:SetColorTexture(EG.r, EG.g, EG.b, 0.9)
                else
                    barTex:SetColorTexture(1, 1, 1, 0.16)
                end

                for l = 1, 2 do
                    local line = card:CreateTexture(nil, "ARTWORK")
                    PPx.Size(line, CARD_W - 16 - (l - 1) * 14, 3)
                    PPx.Point(line, "TOPLEFT", card, "TOPLEFT", 8, -(16 + (l - 1) * 8))
                    line:SetColorTexture(1, 1, 1, isMid and 0.35 or 0.18)
                end
            end
        end,
    })
end

-------------------------------------------------------------------------------
--  Guide #5: addons that need an update ("addon_update")
--
--  Shown by the options panel (EllesmereUI_Panel.lua), once per session, when
--  another addon tried to change EllesmereUI's own settings pages. Names those
--  addons and links the plugin guide for addon authors.
-------------------------------------------------------------------------------
-- ONE paste point for the plugin guide on GitHub.
EllesmereUI.PLUGINS_API_URL = "https://github.com/EllesmereGaming/EllesmereUI/blob/main/PLUGINS_API.md"

do
    local def = {
        url       = EllesmereUI.PLUGINS_API_URL,
        width     = 580,
        artHeight = 96,
        urlWidth  = 520,
        gaps = {
            eyebrow = 20, title = 8, blurb = 14,
            bullets = 18, bulletRows = 8, url = 20, hint = 8,
            button = 46, footnote = 18,
        },
        art = function(popup, ctx)
            local PPx, band = ctx.PP, ctx.band
            local EG = ctx.accent
            local function Box(w, h, x, y, edgeR, edgeG, edgeB, edgeA)
                local f = CreateFrame("Frame", nil, band)
                f:SetFrameLevel(band:GetFrameLevel() + 2)
                PPx.Size(f, w, h)
                PPx.Point(f, "CENTER", band, "CENTER", x, y)
                local bg = f:CreateTexture(nil, "BACKGROUND")
                bg:SetAllPoints()
                bg:SetColorTexture(0.056, 0.045, 0.034, 1)
                ctx.MakeBorder(f, edgeR, edgeG, edgeB, edgeA, PPx)
                return f
            end
            local function Bar(parent, w, h, x, y, r, g, b, a)
                local t = parent:CreateTexture(nil, "ARTWORK")
                t:SetColorTexture(r, g, b, a)
                PPx.Size(t, w, h)
                PPx.Point(t, "TOPLEFT", parent, "TOPLEFT", x, y)
                return t
            end

            -- The addon (a settings cog) plugging into a section of its own,
            -- below EllesmereUI's own rows in a mini settings panel.
            local tile = Box(50, 50, -104, 0, EG.r, EG.g, EG.b, 0.85)
            local cog = tile:CreateTexture(nil, "ARTWORK")
            cog:SetTexture("Interface\\AddOns\\EllesmereUI\\media\\icons\\cogs.png")
            cog:SetVertexColor(1, 1, 1, 0.85)
            PPx.Size(cog, 26, 26)
            PPx.Point(cog, "CENTER", tile, "CENTER", 0, 0)

            local arrow = ctx.MakeTriangle(band, 10, 12, EG.r, EG.g, EG.b, 0.9)
            PPx.Point(arrow, "CENTER", band, "CENTER", -60, 0)

            local panel = Box(170, 66, 44, 0, 1, 1, 1, 0.18)
            for i = 1, 3 do Bar(panel, 40, 4, 8, -(10 + (i - 1) * 8), 1, 1, 1, 0.18) end
            local own = CreateFrame("Frame", nil, panel)
            own:SetFrameLevel(panel:GetFrameLevel() + 1)
            PPx.Size(own, 46, 14)
            PPx.Point(own, "TOPLEFT", panel, "TOPLEFT", 5, -42)
            ctx.MakeBorder(own, EG.r, EG.g, EG.b, 0.85, PPx)
            Bar(own, 30, 4, 8, -5, EG.r, EG.g, EG.b, 0.9)
            Bar(panel, 1, 54, 58, -6, 1, 1, 1, 0.10)
            Bar(panel, 88, 4, 68, -12, 1, 1, 1, 0.16)
            Bar(panel, 70, 4, 68, -22, 1, 1, 1, 0.16)
            Bar(panel, 80, 4, 68, -32, 1, 1, 1, 0.16)
            Bar(panel, 60, 4, 68, -47, EG.r, EG.g, EG.b, 0.35)
        end,
    }
    EllesmereUI.VideoGuides.Register("addon_update", def)

    --- names: the addons' titles, sorted. One per bullet row (titles run
    --- long); the second row sums up any past the first two.
    function EllesmereUI.VideoGuides.ShowAddonUpdate(names)
        local n = #names
        def.eyebrow  = EllesmereUI.L("ADDON COMPATIBILITY")
        def.title    = n == 1 and EllesmereUI.Lf("%1$s Issue", names[1]) or EllesmereUI.L("Some Addons Need an Update")
        def.blurb    = EllesmereUI.L("To keep its settings safe, EllesmereUI now gives other addons their own section in the panel instead of letting them change its pages. The addons below haven't caught up yet, so those changes are hidden until they're updated. Everything else works as usual.")
        def.footnote = EllesmereUI.L("Addon authors: this guide shows how to add your settings to EllesmereUI.")
        def.okText   = EllesmereUI.L("Got It")
        local rows = { { names[1] } }
        if n == 2 then
            rows[2] = { names[2] }
        elseif n > 2 then
            rows[2] = { EllesmereUI.Lf("%1$s and %2$d more", names[2], n - 2) }
        end
        def.bullets = rows
        def.height = n > 1 and 481 or 460
        return EllesmereUI.VideoGuides.Show("addon_update")
    end
end
