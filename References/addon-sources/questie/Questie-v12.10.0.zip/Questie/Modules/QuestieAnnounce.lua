---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")

local Questie = _G.Questie
---@class QuestieAnnounce
local QuestieAnnounce = QuestieLoader:CreateModule("QuestieAnnounce")
local _QuestieAnnounce = {}
---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLink
local QuestieLink = QuestieLoader:ImportModule("QuestieLink")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local GetItemInfo = QuestieCompat.GetItemInfo

local itemCache = {} -- cache data since this happens on item looted it could happen a lot with auto loot
local alreadySentBandaid = {} -- TODO: rewrite the entire thing its a lost cause

-- === Below code borrowed from ShutUp to implement Questie logo swapping for chat messages ===

local ChatFrameAddMessageEventFilter = QuestieCompat.AddMessageEventFilter

---Registers a chat filter, retrying CreateSecureFiltersArray errors after a delay.
---@param event string
---@param filter function
local function SafeAddMessageEventFilter(event, filter)
    local success, err = pcall(function()
        ChatFrameAddMessageEventFilter(event, filter)
    end)
    if not success then
        if err and string.find(err, "CreateSecureFiltersArray") then
            C_Timer.After(0.1, function()
                SafeAddMessageEventFilter(event, filter)
            end)
        else
            Questie.Error("Failed to register chat filter for", event, ":", err)
        end
    end
end

local pattern = ""
local patternRU = ""

function QuestieAnnounce.LogoFilter(self, event, msg, author, ...)
    if msg:find(pattern) then
        return false, gsub(msg, pattern, "|TInterface\\Addons\\Questie\\Icons\\questie.png:0|t"), author, ...
    end
    -- Adding this check for messages sent by ruRU clients where {rt1} doesnt work (thanks Blizz)
    -- We want those to also be replaced with our Questie icon
    if msg:find(patternRU) then
        return false, gsub(msg, patternRU, "|TInterface\\Addons\\Questie\\Icons\\questie.png:0|t"), author, ...
    end
end

function QuestieAnnounce:InitializeLogoFilter()
    pattern = "{rt1}" .. " Questie%s?:"
     -- ruRU clients don't have {rt1} so we also want to filter these
    patternRU = "{звезда}" .. " Questie%s?:"
    SafeAddMessageEventFilter("CHAT_MSG_PARTY", QuestieAnnounce.LogoFilter)
    SafeAddMessageEventFilter("CHAT_MSG_PARTY_LEADER", QuestieAnnounce.LogoFilter)
    SafeAddMessageEventFilter("CHAT_MSG_RAID", QuestieAnnounce.LogoFilter)
    SafeAddMessageEventFilter("CHAT_MSG_RAID_LEADER", QuestieAnnounce.LogoFilter)
    SafeAddMessageEventFilter("CHAT_MSG_INSTANCE_CHAT", QuestieAnnounce.LogoFilter)
    SafeAddMessageEventFilter("CHAT_MSG_INSTANCE_CHAT_LEADER", QuestieAnnounce.LogoFilter)
end

-- === End logo swapping code block ===

local _GetAnnounceMarker

---@return string
_GetAnnounceMarker = function()
    local locale = l10n:GetUILocale()
    if IsInRaid() or IsInGroup() then
        if locale == "ruRU" then
            -- ruRU clients don't have {rt1} so we also want to filter these
            return "{звезда} Questie: ";
        elseif locale == "frFR" then
            return "{rt1} Questie : ";
        else
            return "{rt1} Questie: "
        end
    else
        return ""
    end
end

---@param questId QuestId
---@param objectiveText string @Complete accepted native wording, including any native progress counter.
function QuestieAnnounce:AnnounceObjectiveToChannel(questId, objectiveText)
    if _QuestieAnnounce:AnnounceEnabledAndPlayerInChannel() and Questie.db.profile.questAnnounceObjectives then
        local questLink = QuestieLink.GetNativeQuestLinkStringById(questId);
        local message = l10n("%s for %s!", objectiveText, questLink or "no quest name")

        local localMessage
        if Questie.db.profile.questAnnounceLocally == true then
            localMessage = l10n("%s for %s!", objectiveText, QuestieLink:GetQuestHyperLink(questId) or "no quest name")
        end

        _QuestieAnnounce:AnnounceToChannel(message, localMessage)
    end
end

---SendChatMessage rejects the |4singular:plural; grammar escape that Forever leaves in some localized objective text,
---for example frFR "Massacreur : 4/4 |4personnage tué:personnages tués;". Resolves it for the announced count.
---shortcut: only the 2-form (singular for 1) and 3-form (Slavic) rules, other languages fall back to the first form.
---@param text any
---@param count any
---@return any
local function _ResolveGrammarEscapes(text, count)
    if type(text) ~= "string" then
        return text
    end

    return (text:gsub("|4([^;]*);", function(forms)
        local candidates = {}
        for form in (forms .. ":"):gmatch("([^:]*):") do
            candidates[#candidates + 1] = form
        end

        local index = 1
        if type(count) == "number" then
            if #candidates == 2 then
                index = count == 1 and 1 or 2
            elseif #candidates == 3 then
                local lastDigit, lastTwoDigits = count % 10, count % 100
                if lastDigit == 1 and lastTwoDigits ~= 11 then
                    index = 1
                elseif lastDigit >= 2 and lastDigit <= 4 and (lastTwoDigits < 12 or lastTwoDigits > 14) then
                    index = 2
                else
                    index = 3
                end
            end
        end
        return candidates[index]
    end))
end

local _has_seen_incomplete = {}
local _has_sent_announce = {}

---@param questId QuestId
---@param objectiveIndex ObjectiveIndex @Original native index, not a dense display-row index.
---@param text string @Complete accepted native wording; never used as objective identity.
---@param numFulfilled number
---@param numRequired number
function QuestieAnnounce:ObjectiveChanged(questId, objectiveIndex, text, numFulfilled, numRequired)
    -- Native text changes with progress and can be identical across quests or objective slots.
    -- Keep the existing count-based trigger and once-announced policy, keyed by stable identity instead.
    local objectiveKey = questId .. ":" .. objectiveIndex
    if (numRequired ~= numFulfilled) then
        _has_seen_incomplete[objectiveKey] = true
    elseif _has_seen_incomplete[objectiveKey] and not _has_sent_announce[objectiveKey] then
        _has_seen_incomplete[objectiveKey] = nil
        _has_sent_announce[objectiveKey] = true
        QuestieAnnounce:AnnounceObjectiveToChannel(questId, _ResolveGrammarEscapes(text, numRequired))
    end
end

---@param questId QuestId
---@param itemId ItemId
function QuestieAnnounce:AnnounceQuestItemLootedToChannel(questId, itemId)
    if _QuestieAnnounce:AnnounceEnabledAndPlayerInChannel() and Questie.db.profile.questAnnounceItems then
        local questLink = QuestieLink.GetNativeQuestLinkStringById(questId);
        local itemLink = select(2, GetItemInfo(itemId))
        local message = l10n("Picked up %s which starts %s!", itemLink, questLink or "no quest name")

        local localMessage
        if Questie.db.profile.questAnnounceLocally == true then
            localMessage = l10n("Picked up %s which starts %s!", itemLink, QuestieLink:GetQuestHyperLink(questId) or "no quest name")
        end

        _QuestieAnnounce:AnnounceToChannel(message, localMessage)
        return true
    else
        return false
    end
end

---@param questId QuestId
---@param itemId ItemId
function _QuestieAnnounce:AnnounceSelf(questId, itemId)
    if Questie.db.profile.questieShutUp or Questie.db.profile.questAnnounceItems ~= true then
        return
    end

    local questHyperLink = QuestieLink:GetQuestHyperLink(questId);
    local itemLink = select(2, GetItemInfo(itemId));

    Questie:Print(l10n("You picked up %s which starts %s!", itemLink, questHyperLink or "no quest name"));
end

---@return boolean
local function _ShouldAnnounceToGroup()
    local channel = Questie.db.profile.questAnnounceChannel
    if channel == "both" then
        return IsInRaid() or IsInGroup()
    elseif channel == "raid" then
        return IsInRaid()
    elseif channel == "party" then
        return IsInGroup() and not IsInRaid()
    else
        return false
    end
end

---@return boolean
function _QuestieAnnounce:AnnounceEnabledAndPlayerInChannel()
    if Questie.db.profile.questAnnounceLocally == true then
        return true -- we always want to print if this option is enabled
    end
    return _ShouldAnnounceToGroup()
end

function _QuestieAnnounce.GetChatMessageChannel()
    if IsInRaid() then
        return "RAID"
    elseif IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        return "INSTANCE_CHAT"
    else
        return "PARTY"
    end
end

---@param message string
---@param localMessage? string
function _QuestieAnnounce:AnnounceToChannel(message, localMessage)
    Questie.Debug(Questie.DEBUG_DEVELOP, "[QuestieAnnounce] raw msg: ", message)
    if (not message) or alreadySentBandaid[message] or Questie.db.profile.questieShutUp then
        return
    end

    alreadySentBandaid[message] = true

    if Questie.db.profile.questAnnounceLocally == true then
        Questie:Print(localMessage)
    end

    if _ShouldAnnounceToGroup() then
        SendChatMessage(_GetAnnounceMarker() .. message, _QuestieAnnounce.GetChatMessageChannel())
    end
end

local playerNameCache
---@return string
local function _GetPlayerName()
    playerNameCache = GetUnitName("player", true)
    return playerNameCache
end

---@param text string
---@param notPlayerName string
---@param playerName string
function QuestieAnnounce:ItemLooted(text, notPlayerName, _, _, playerName)
    if (playerNameCache or _GetPlayerName()) == playerName or (string.len(playerName) == 0 and playerNameCache == notPlayerName) then
        local itemId = tonumber(string.match(text, "item:(%d+)"))
        if not itemId then return end
        local startQuestId = itemCache[itemId]
        -- startQuestId can have boolean false as value, need to compare to nil
        -- check QueryItemSingle because this event can fire before db init is complete
        if (startQuestId == nil) and QuestieDB.QueryItemSingle then
            startQuestId = QuestieDB.QueryItemSingle(itemId, "startQuest")
            -- filter 0 values away so itemCache value is a valid questId if it evaluates to true
            -- we do "or false" here because nil would mean not cached
            startQuestId = (startQuestId and startQuestId > 0) and startQuestId or false
            itemCache[itemId] = startQuestId
        end

        if startQuestId then
            if not QuestieAnnounce:AnnounceQuestItemLootedToChannel(startQuestId, itemId) then
                _QuestieAnnounce:AnnounceSelf(startQuestId, itemId)
            end
        end
    end
end

---@param questId QuestId
function QuestieAnnounce:AcceptedQuest(questId)
    if (_QuestieAnnounce:AnnounceEnabledAndPlayerInChannel()) and Questie.db.profile.questAnnounceAccepted then
        local questLink = QuestieLink.GetNativeQuestLinkStringById(questId)
        local message = l10n("Quest %s: %s", l10n("Accepted"), questLink or "no quest name")

        local localMessage
        if Questie.db.profile.questAnnounceLocally == true then
            localMessage = l10n("Quest %s: %s", l10n('Accepted'), QuestieLink:GetQuestHyperLink(questId) or "no quest name")
        end

        _QuestieAnnounce:AnnounceToChannel(message, localMessage)
    end
end

---@param questId QuestId
function QuestieAnnounce:AbandonedQuest(questId)
    if (_QuestieAnnounce:AnnounceEnabledAndPlayerInChannel()) and Questie.db.profile.questAnnounceAbandoned then
        local questLink = QuestieLink.GetNativeQuestLinkStringById(questId)
        local message = l10n("Quest %s: %s", l10n("Abandoned"), questLink or "no quest name")

        local localMessage
        if Questie.db.profile.questAnnounceLocally == true then
            localMessage = l10n("Quest %s: %s", l10n('Abandoned'), QuestieLink:GetQuestHyperLink(questId) or "no quest name")
        end

        _QuestieAnnounce:AnnounceToChannel(message, localMessage)
    end
end

---@param questId QuestId
function QuestieAnnounce:CompletedQuest(questId)
    if (_QuestieAnnounce:AnnounceEnabledAndPlayerInChannel()) and Questie.db.profile.questAnnounceCompleted then
        local questLink = QuestieLink.GetNativeQuestLinkStringById(questId)
        local message = l10n("Quest %s: %s", l10n("Completed"), questLink or "no quest name")

        local localMessage
        if Questie.db.profile.questAnnounceLocally == true then
            localMessage = l10n("Quest %s: %s", l10n('Completed'), QuestieLink:GetQuestHyperLink(questId) or "no quest name")
        end

        _QuestieAnnounce:AnnounceToChannel(message, localMessage)
    end
end

---@param questId QuestId
---@param breadcrumbQuestId QuestId
function QuestieAnnounce.IncompleteBreadcrumbQuest(questId, breadcrumbQuestId)
    local questLink = QuestieLink:GetQuestHyperLink(questId)
    local breadcrumbQuestLink = QuestieLink:GetQuestHyperLink(breadcrumbQuestId)

    local message = l10n("You have accepted %s without completing its breadcrumb quest %s", questLink or "no quest name", breadcrumbQuestLink or "no quest name")
    Questie:Print(message)
end