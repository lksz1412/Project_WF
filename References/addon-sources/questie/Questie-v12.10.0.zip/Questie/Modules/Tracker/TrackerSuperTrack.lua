---@class TrackerSuperTrack
local TrackerSuperTrack = QuestieLoader:CreateModule("TrackerSuperTrack")

---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")
---@type TrackerUtils
local TrackerUtils = QuestieLoader:ImportModule("TrackerUtils")
---@type QuestieQuest
local QuestieQuest = QuestieLoader:ImportModule("QuestieQuest")
---@type QuestieTracker
local QuestieTracker = QuestieLoader:ImportModule("QuestieTracker")
---@type QuestieCombatQueue
local QuestieCombatQueue = QuestieLoader:ImportModule("QuestieCombatQueue")

---Blizzard super tracks a newly accepted quest when no quest is super tracked, which moves the minimap arrow.
---It is already super tracked when QUEST_ACCEPTED fires, so it can be cleared right away.
---@param questId QuestId
function TrackerSuperTrack.OnQuestAccepted(questId)
    if Questie.db.profile.trackerFollowSuperTracking then
        return
    end

    if QuestieCompat.GetSuperTrackedQuestID() == questId then
        QuestieCompat.ClearSuperTrackedQuest()
    end
end

---Follows super tracking changes made outside Questie, e.g. on the Blizzard map or quest log.
---Changes Questie made itself already match its focus, so only the tracker is redrawn.
---Ignored unless the follow option is on.
function TrackerSuperTrack.OnSuperTrackingChanged()
    if (not Questie.db.profile.trackerFollowSuperTracking) then
        return
    end

    local questId = QuestieCompat.GetSuperTrackedQuestID()
    local focus = Questie.db.char.TrackerFocus

    if questId then
        if focus ~= questId then
            if TrackerUtils:FocusQuest(questId) then
                QuestieQuest.ToggleQuestNotes(false)
            elseif focus then
                -- Questie can not focus the new quest, so drop the old quest focus instead of showing it as focused.
                TrackerUtils:UnFocus()
                QuestieQuest.ToggleQuestNotes(true)
            end
        end
    elseif focus then
        TrackerUtils:UnFocus()
        QuestieQuest.ToggleQuestNotes(true)
    end

    -- The focus buttons also show Blizzard's super tracked quest, so every change needs a redraw.
    QuestieCombatQueue:Queue(function()
        QuestieTracker:Update()
    end)
end
