---@class addonTableBaganator
local addonTable = select(2, ...)
function addonTable.ItemViewCommon.Initialize()
  addonTable.ItemButtonUtil.UpdateSettings()

  xpcall(function()
    addonTable.InitializeOpenClose()
  end, CallErrorHandler)

  addonTable.NewItems = CreateFrame("Frame")
  Mixin(addonTable.NewItems, BaganatorItemViewCommonNewItemsTrackingMixin)
  addonTable.NewItems:OnLoad()
  addonTable.NewItems:SetScript("OnEvent", addonTable.NewItems.OnEvent)

  addonTable.BankTransferManager = CreateFrame("Frame")
  Mixin(addonTable.BankTransferManager, addonTable.BankTransferManagerMixin)
  addonTable.BankTransferManager:OnLoad()
  addonTable.BankTransferManager:SetScript("OnEvent", addonTable.BankTransferManager.OnEvent)
end
