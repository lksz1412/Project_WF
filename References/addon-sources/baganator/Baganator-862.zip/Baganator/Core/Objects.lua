---@class addonTableBaganator
local addonTable = select(2, ...)
Baganator = {API = { Constants = {} }}
addonTable.Core = {}
addonTable.Utilities = {}
addonTable.InventoryTracking = {}
addonTable.Search = {}
addonTable.ItemViewCommon = {
  Utilities = {}
}
addonTable.Gamepad = {}
addonTable.ViewManagement = {}
addonTable.SingleViews = {}
addonTable.CategoryViews = {}
addonTable.CustomiseDialog = {
  Components = {},
}
addonTable.API = {}
addonTable.Sorting = {}
addonTable.Transfers = {}
addonTable.Help = {}
addonTable.Skins = {}
addonTable.Compatibility = {}
addonTable.Dialogs = {}
