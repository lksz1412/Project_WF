﻿-- See: http://wow.curseforge.com/addons/xloot/localization/ to create or fix translations
local locales = {
	enUS = {
		ML_RANDOM = "Raid Roll",
		ML_SELF = "Self Loot",
		ML_BANKER = "Banker",
		ML_DISENCHANTER = "Disenchanter",
		RECIPIENTS = "Special Recipients",
		SPECIALROLLS = "Special Rolls",
		ITEM_AWARDED = "%s awarded: %s",
		CANDIDATE_UNAVAILABLE = "That player is no longer eligible to receive loot.",
		ITEM_UNAVAILABLE = "That item is no longer in the loot window.",
		ROLL_DISCARDED = "Raid roll discarded - no winner was assigned.",
	},
	-- Possibly localized
	ptBR = {

	},
	frFR = {

	},
	deDE = {

	},
	koKR = {

	},
	esMX = {

	},
	ruRU = {

	},
	zhCN = {

	},
	esES = {

	},
	zhTW = {

	},
}

-- Automatically inserted translations
-- Master

-- Master

-- Master
locales.deDE["BINDING_BANKER"] = "Setze Bankier"
locales.deDE["BINDING_DISENCHANTER"] = "Setze Entzauberer"
locales.deDE["ITEM_AWARDED"] = "%s erhielt: %s"
locales.deDE["ML_BANKER"] = "Bankier"
locales.deDE["ML_DISENCHANTER"] = "Entzauberer"
locales.deDE["ML_RANDOM"] = "Schlachtzugswurf"
locales.deDE["ML_SELF"] = "Eigenständiges Plündern"
locales.deDE["RECIPIENTS"] = "Spezieller Empfänger"
locales.deDE["SPECIALROLLS"] = "Spezielle Würfe"

-- Master

-- Master
locales.zhCN["BINDING_BANKER"] = "设置银行存放者"
locales.zhCN["BINDING_DISENCHANTER"] = "设置附魔分解者"
locales.zhCN["ITEM_AWARDED"] = "%s 获得了： %s"
locales.zhCN["ML_BANKER"] = "银行存放者"
locales.zhCN["ML_DISENCHANTER"] = "附魔分解者"
locales.zhCN["ML_RANDOM"] = "团队掷骰"
locales.zhCN["ML_SELF"] = "自己掷骰"
locales.zhCN["RECIPIENTS"] = "特殊接收者"
locales.zhCN["SPECIALROLLS"] = "特殊掷骰"

-- Master

-- Master
locales.zhTW["BINDING_BANKER"] = "設定存放銀行者"
locales.zhTW["BINDING_DISENCHANTER"] = "設定附魔分解者"
locales.zhTW["ITEM_AWARDED"] = "%s 給與: %s"
locales.zhTW["ML_BANKER"] = "銀行存放者"
locales.zhTW["ML_DISENCHANTER"] = "附魔分解者"
locales.zhTW["ML_RANDOM"] = "團隊擲骰"
locales.zhTW["ML_SELF"] = "自己拾取"
locales.zhTW["RECIPIENTS"] = "特殊接受者"
locales.zhTW["SPECIALROLLS"] = "特殊擲骰"


locales.ruRU["ML_RANDOM"] = "Рейдовый бросок"
locales.ruRU["ML_SELF"] = "Своя добыча"
locales.ruRU["ML_BANKER"] = "Банкир"
locales.ruRU["ML_DISENCHANTER"] = "Распылитель"
locales.ruRU["RECIPIENTS"] = "Особые получатели"
locales.ruRU["SPECIALROLLS"] = "Особые броски"
locales.ruRU["ITEM_AWARDED"] = "%s получает: %s"
locales.ruRU["CANDIDATE_UNAVAILABLE"] = "Этот игрок больше не может получить добычу."
locales.ruRU["ITEM_UNAVAILABLE"] = "Этого предмета больше нет в окне добычи."
locales.ruRU["ROLL_DISCARDED"] = "Рейдовый бросок отменён — победитель не назначен."

locales.koKR["ML_RANDOM"] = "공격대 주사위"
locales.koKR["RECIPIENTS"] = "특별 수령인"
locales.koKR["SPECIALROLLS"] = "특별 주사위"
locales.koKR["ML_SELF"] = "내가 획득"
locales.koKR["ML_BANKER"] = "은행 보관 담당자"
locales.koKR["ML_DISENCHANTER"] = "마력 추출 담당자"
locales.koKR["ITEM_AWARDED"] = "%s에게 분배: %s"
locales.koKR["CANDIDATE_UNAVAILABLE"] = "해당 플레이어는 더 이상 전리품을 받을 수 없습니다."
locales.koKR["ITEM_UNAVAILABLE"] = "해당 아이템이 더 이상 전리품 창에 없습니다."
locales.koKR["ROLL_DISCARDED"] = "공격대 주사위 분배가 취소되었습니다. 수령인이 지정되지 않았습니다."

XLoot:Localize("Master", locales)
