local addon, L = XLoot:NewModule("Monitor")

XLootMonitor = CreateFrame("Frame", "XLootMonitor", UIParent)
XLootMonitor.addon = addon

local print, opt, eframe, anchor = print
local MoneyString, FancyPlayerName, SafeSetFont = XLoot.MoneyString, XLoot.FancyPlayerName, XLoot.SafeSetFont
local table_insert, table_remove = table.insert, table.remove
local me = UnitName("player")

local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
local GetDetailedItemLevelInfo = C_Item and C_Item.GetDetailedItemLevelInfo or GetDetailedItemLevelInfo
local GetSpellTexture = C_Spell and C_Spell.GetSpellTexture or GetSpellTexture

local defaults = {
	profile = {
		anchor = {
			direction = "up",
			alignment = "left",
			visible = true,
			scale = 1.0,
			draggable = true,
			offset = 0,
			spacing = 2,
			x = UIParent:GetWidth() * .75,
			y = UIParent:GetHeight() * .15,
		},
		name_width = 50,
		gradients = false,
		quality_color = true,
		monitor_color_border = { .5, .5, .5, 1 },
		color_all_rows = false,
		quest_color = false,
		quest_color_class = false,
		monitor_color_quest = { 1, .8, .1, 1 },

		threshold_own = 2,
		threshold_other = 3,
		show_coin = false,
		show_system_coin = false,
		show_currency = true,
		currency_cap = false,
		show_crafted = false,
		show_reputation = false,
		show_reputation_loss = true,
		show_xp = false,
		show_honor = false,
		show_skill = false,

		show_totals = false,
		totals_delay = 0.5,
		use_altoholic = true,
		show_ilvl = false,

		fade_own = 10,
		fade_other = 5,
		rightclick_dismiss = false,
		suppress_loot_toasts = false,

		font = STANDARD_TEXT_FONT,
		font_size_loot = 12,
		font_size_quantity = 10,
		font_size_ilvl = 8,
		font_flag = "OUTLINE",
	}
}

local numberize = function(v)
	if v <= 9999 then return v end
	if v >= 1000000 then
		local value = string.format("%.1fm", v/1000000)
		return value
	elseif v >= 10000 then
		local value = string.format("%.0fk", v/1000)
		return value
	end
end

function addon:OnInitialize()
	eframe = CreateFrame("Frame")
	self:InitializeModule(defaults, eframe)
	XLoot:SetSlashCommand("xlm", self.SlashHandler)
	opt = self.db.profile
end

function addon:OnEnable()
	LibStub("LootEvents"):RegisterLootCallback(self.LOOT_EVENT)
	eframe:RegisterEvent("MODIFIER_STATE_CHANGED")
	eframe:RegisterEvent("PLAYER_ENTERING_WORLD")
	eframe:RegisterEvent("PLAYER_XP_UPDATE")
	eframe:RegisterEvent("PLAYER_LEVEL_UP")
	eframe:RegisterEvent("PLAYER_LEVEL_CHANGED")
	XLoot:MakeSkinner(self, {
		default = { gradient = opt.gradients },
		anchor = { r = .4, g = .4, b = .4, a = .6, gradient = false },
		anchor_pretty = { r = .6, g = .6, b = .6, a = .8 },
		item = { backdrop = false, gradient = opt.gradients },
		item_highlight = { type = "highlight", layer = "OVERLAY" },
		row_highlight = { type = "highlight" }
	})
	anchor = XLoot.Stack:CreateStaticStack(self.CreateRow, L.anchor, opt.anchor)
	self:Skin(anchor, XLoot.opt.skin_anchors and 'anchor_pretty' or 'anchor')
	XLoot.SuppressLootToasts("Monitor", opt.suppress_loot_toasts)
	XLoot.WantQuestLoot("Monitor", opt.quest_color)
end

function addon:ApplyOptions()
	opt = self.opt
	anchor:UpdateSVData(opt.anchor)
	XLoot.SuppressLootToasts("Monitor", opt.suppress_loot_toasts)
	XLoot.WantQuestLoot("Monitor", opt.quest_color)
	addon:Restack()
end

local function set_row_border(row)
	local c = opt.monitor_color_border
	row:SetBorderColor(c[1], c[2], c[3], c[4])
	row.icon_frame:SetBorderColor(c[1], c[2], c[3], c[4])
end

local function get_quest_color()
	if opt.quest_color_class then
		return XLoot.MyClassColor()
	end
	local c = opt.monitor_color_quest
	return c[1], c[2], c[3]
end

-- Retail can emit the named color form (|cnIQ4:) instead of eight hex digits, and neither pattern matches the other.
local function recolor_link(link, hex)
	local escape = '|c'..hex
	local out, hits = link:gsub('|c%x%x%x%x%x%x%x%x', escape, 1)
	if hits == 0 then
		out, hits = link:gsub('|cn[^:|]+:', escape, 1)
	end
	return hits > 0 and out or ('%s%s|r'):format(escape, link)
end

local events = {}
function events.item(player, link, num, preview_quest)
	if link and link:match("|Hitem:") then
		local name, _, quality, _, _, _, _, _, _, icon = GetItemInfo(link)
		if not name or type(quality) ~= "number" then
			return -- item not cached yet or malformed, not an error to report
		end
		local is_quest = opt.quest_color and (preview_quest or (player == me and XLoot.IsQuestLoot(link)))
		-- Quest items are nearly always Common or Poor, so the thresholds would hide the feature entirely.
		if not is_quest and (player == me and opt.threshold_own or opt.threshold_other) > quality then
			return
		end
		local r, g, b = C_Item.GetItemQualityColor(quality)
		local display = link
		if is_quest then
			r, g, b = get_quest_color()
			display = recolor_link(link, XLoot.ColorToHex(r, g, b))
		end
		local nr, ng, nb
		if player ~= me then
			player, nr, ng, nb = FancyPlayerName(player, select(2, UnitClass(player)), opt)
		else
			player = nil
		end
		local row = addon:AddRow(icon, (player and opt.fade_other or opt.fade_own), r, g, b)
		if not opt.quality_color and not is_quest then
			set_row_border(row)
		end
		local num = tonumber(num) or 1
		row:SetTexts(player, num > 1 and ("%sx%d"):format(display, num) or display, nil, nr, ng, nb)
		if opt.show_totals then
			row.timeToTotal = opt.totals_delay
		end
		if opt.show_ilvl and C_Item.IsEquippableItem(link) then
			local ilvl = GetDetailedItemLevelInfo(link)
			row.ilvl:SetText(ilvl)
		end
		row.item = link
	elseif link and link:match("|Hbattlepet:") then
		-- local _, speciesID, level, breedQuality, maxHealth, power, speed, battlePetID = strsplit(":", link)
	else
		-- print("Unknown or invalid link type")
		-- return false
	end
end

local function add_coin_row(copper)
	local row = addon:AddRow(C_CurrencyInfo.GetCoinIcon(copper), opt.fade_own, .5, .5, .5, .5, .5, .5)
	if not opt.quality_color and opt.color_all_rows then
		set_row_border(row)
	end
	row:SetTexts(nil, MoneyString(copper, XLoot.opt.value_coin_icons))
end

function events.coin(player, copper)
	if opt.show_coin then
		add_coin_row(copper)
	end
end

function events.systemcoin(player, copper)
	if opt.show_system_coin then
		add_coin_row(copper)
	end
end

-- MoP Classic's Conquest (390) and Valor (396) caps rise each week and are checked against this season's totalEarned, not the amount held
local progressive_caps = { [390] = true, [396] = true }

local function cap_tag(id, c)
	local held, max = c.useTotalEarnedForMaxQty and c.totalEarned or c.quantity, c.maxQuantity
	local week, week_max = c.quantityEarnedThisWeek, c.maxWeeklyQuantity
	if progressive_caps[tonumber(id)] then
		max, week, week_max = 0, c.totalEarned, c.maxQuantity
	end
	if (max or 0) > 0 and (held or 0) >= max then
		return (" |cffff4040(%s)|r"):format(L.capped)
	elseif (week_max or 0) > 0 and (week or 0) >= week_max then
		return (" |cffffa000(%s)|r"):format(L.weekly_cap)
	end
	return ""
end

function events.currency(id, num)
	-- The id is nil when a currency line has no currency link, which GetCurrencyInfo cannot take
	if id ~= nil and opt.show_currency then
		local num = tonumber(num) or 1
		local c = C_CurrencyInfo.GetCurrencyInfo(id)
		if c then
			local row = addon:AddRow(c.iconFileID, opt.fade_own, 1, 1, 1, 1, 1, 1)
			if not opt.quality_color and opt.color_all_rows then
				set_row_border(row)
			end
			local text = num > 1 and ("%s x%d"):format(c.name, num) or c.name
			if opt.currency_cap then
				text = text..cap_tag(id, c)
			end
			row:SetTexts(nil, text, c.quantity)
		end
	end
end

function events.crafted(link, num)
	if opt.show_crafted then
		events.item(me, link, num)
	end
end

local merge_rows = {}

local function chat_color(chat_type)
	local info = ChatTypeInfo and ChatTypeInfo[chat_type]
	if info and info.r then
		return info.r, info.g, info.b
	end
	return 1, 1, 1
end

local function signed(sign, amount)
	amount = math.floor(amount * 100 + .5) / 100
	if amount % 1 ~= 0 then
		return ("%s%.2f"):format(sign, amount)
	end
	return sign..FormatLargeNumber(amount)
end

local function stat_row(key, icon, amount, r, g, b)
	local row = merge_rows[key]
	if row then
		addon.RefreshRow(row, opt.fade_own)
	else
		row = addon:AddRow(icon, opt.fade_own, r, g, b)
		if not opt.quality_color and opt.color_all_rows then
			set_row_border(row)
		end
		row.merge_key, row.amount = key, nil
		merge_rows[key] = row
	end
	if amount then
		row.amount = (row.amount or 0) + amount
	end
	return row
end

local faction_icons = {
	Horde = "Interface\\Icons\\INV_BannerPVP_01",
	Alliance = "Interface\\Icons\\INV_BannerPVP_02",
}

function events.reputation(faction, amount, gained)
	if not opt.show_reputation or not (gained or opt.show_reputation_loss) then
		return
	end
	local r, g, b = 1, .1, .1
	if gained then
		r, g, b = chat_color("COMBAT_FACTION_CHANGE")
	end
	local icon = faction_icons[UnitFactionGroup("player")] or "Interface\\Icons\\INV_Misc_Ribbon_01"
	local row = stat_row((gained and "rep+" or "rep-")..faction, icon, amount, r, g, b)
	local text = row.amount and ("%s %s"):format(signed(gained and "+" or "-", row.amount), faction) or faction
	row:SetTexts(nil, text, nil, r, g, b)
end

function events.xp(amount)
	if opt.show_xp then
		local r, g, b = chat_color("COMBAT_XP_GAIN")
		local row = stat_row("xp", "Interface\\Icons\\INV_Misc_Book_11", amount, r, g, b)
		row:SetTexts(nil, ("%s %s"):format(signed("+", row.amount), XP), nil, r, g, b)
	end
end

function events.honor(amount)
	if opt.show_honor and amount and amount > 0 then
		local r, g, b = chat_color("COMBAT_HONOR_GAIN")
		local icon = "Interface\\PVPFrame\\PVPCurrency-Honor-"..(UnitFactionGroup("player") or "Neutral")
		local row = stat_row("honor", icon, amount, r, g, b)
		row:SetTexts(nil, ("%s %s"):format(signed("+", row.amount), HONOR), nil, r, g, b)
	end
end

function events.skill(name, rank)
	if opt.show_skill then
		local r, g, b = chat_color("SKILL")
		local icon = GetSpellTexture and GetSpellTexture(name) or "Interface\\Icons\\INV_Scroll_03"
		local row = stat_row("skill:"..name, icon, nil, r, g, b)
		row:SetTexts(nil, ("%s (%d)"):format(name, rank), nil, r, g, b)
	end
end

local xp_level, xp_now, xp_max, xp_pending

function addon.PLAYER_ENTERING_WORLD()
	if xp_pending then
		return
	end
	xp_level, xp_now, xp_max = UnitLevel("player"), UnitXP("player"), UnitXPMax("player")
end

local function check_xp()
	xp_pending = false
	local level, now = UnitLevel("player"), UnitXP("player")
	local gained
	if level == xp_level then
		-- XP wrapped before UnitLevel caught up, so wait for the level to land
		if now < xp_now then
			return
		end
		gained = now - xp_now
	elseif level == xp_level + 1 then
		gained = xp_max - xp_now + now
	end
	xp_level, xp_now, xp_max = level, now, UnitXPMax("player")
	if gained and gained > 0 then
		events.xp(gained)
	end
end

-- UnitLevel can lag the level-up events, so read level and XP together a frame later
function addon.PLAYER_XP_UPDATE()
	if xp_now and not xp_pending then
		xp_pending = true
		C_Timer.After(0, check_xp)
	end
end
addon.PLAYER_LEVEL_UP = addon.PLAYER_XP_UPDATE
addon.PLAYER_LEVEL_CHANGED = addon.PLAYER_XP_UPDATE

function addon.LOOT_EVENT(event, pattern, ...)
	if events[event] and events[event](...) == false then
		print("XLoot Monitor: Error handling event", event, pattern, ...)
	end
end

local mouse_focus
function addon:MODIFIER_STATE_CHANGED()
	if mouse_focus and mouse_focus:IsMouseOver() then
		mouse_focus:ShowTooltip()
	end
end

local pool, stack, active = {}, {}, false
stack[0] = anchor

local timer = 0
function addon.EframeUpdate(self, elapsed)
	timer = timer + elapsed
	-- RemoveRow table.removes from stack, so a forward pass would skip the row that shifts down.
	for i = #stack, 1, -1 do
		local row = stack[i]
		-- Deferred total calculation due to GetItemCount reliability
		local ttt = row.timeToTotal
		if ttt then
			ttt = ttt - elapsed
			if ttt <= 0 then
				ttt = nil
				local total
				if opt.use_altoholic and Altoholic then
					total = Altoholic:GetItemCount(Altoholic:GetIDFromLink(row.item))
				else
					total = C_Item.GetItemCount(row.item)
				end
				if total and total > 1 then
					row.total:SetText(numberize(total))
				end
			end
			row.timeToTotal = ttt
		end
		local remaining = row.expires - timer
		if remaining < 0 then
			row:SetAlpha(0)
			addon:RemoveRow(row)
		elseif remaining <= .5 then
			row:SetAlpha(remaining * 2)
		else
			-- Set every frame, since a first frame longer than the fade-in would leave a reused row at alpha 0
			local since = timer - row.started
			row:SetAlpha(since <= .5 and since * 2 or 1)
		end
	end
end

function addon:RemoveRow(row)
	row:Hide()
	if row.merge_key then
		merge_rows[row.merge_key] = nil
		row.merge_key = nil
	end
	for i,v in ipairs(stack) do
		if v == row then
			table_remove(stack, i)
			table_insert(pool, row)
			if stack[i] then
				anchor:AnchorChild(stack[i], stack[i-1])
			end
			break
		end
	end

	if #stack == 0 then
		active, timer = false, 0
		eframe:SetScript("OnUpdate", nil)
	end
end

function addon.RefreshRow(row, fade_time)
	row.expires = timer + fade_time
	row.started = math.min(row.started, timer - .5)
	row:SetAlpha(1)
end

function addon:AddRow(icon, fade_time, ir, ig, ib, rr, rg, rb)
	local row = table_remove(pool)
	if not row then
		row = self.CreateRow()
	end

	row.icon:SetTexture(icon)
	row.icon_frame:SetBorderColor(ir, ig, ib)
	row:SetBorderColor(rr or ir, rg or ig, rb or ib)
	row.expires = timer + fade_time
	row.started = timer
	row.item = nil
	row.timeToTotal = nil -- a right-click-dismissed row can be pooled mid-countdown, so clear it or the reused row ticks GetItemCount(nil)

	anchor:AnchorChild(row)
	table_insert(stack, 1, row)
	if stack[2] then
		anchor:AnchorChild(stack[2], row)
	end
	row:Show()

	if not active then
		active = true
		eframe:SetScript("OnUpdate", self.EframeUpdate)
	end
	return row
end

function addon:Restack()
	for i,v in ipairs(stack) do
		anchor:AnchorChild(v, i > 1 and stack[i-1] or nil)
		v:ApplyOptions()
	end
	-- Pooled rows are re-shown by AddRow without restyling, so they need the new options too.
	for _,v in ipairs(pool) do
		v:ApplyOptions()
	end
end

do
	local function ShowTooltip(self)
		if self.item then
			GameTooltip:SetOwner(self, 'ANCHOR_TOPLEFT', 28, 0)
			GameTooltip:SetHyperlink(self.item)
			CursorUpdate(self)
		end
	end

	local function OnEnter(self)
		mouse_focus = self
		if self._highlights then
			self.icon_frame:ShowHighlight()
		end
		self:ShowTooltip()
	end

	local function OnLeave(self)
		mouse_focus = nil
		if self._highlights then
			self.icon_frame:HideHighlight()
		end
		GameTooltip:Hide()
		ResetCursor()
	end

	-- A parent hide (Alt-Z, cinematics) hides the row without firing OnLeave, so clear the hover state it would otherwise strand.
	local function OnHide(self)
		if mouse_focus == self then
			mouse_focus = nil
			if self._highlights then
				self.icon_frame:HideHighlight()
			end
			GameTooltip:Hide()
			ResetCursor()
		end
	end

	local function OnClick(self, button)
		if button == "RightButton" and opt.rightclick_dismiss and not IsModifiedClick() then
			addon:RemoveRow(self)
		elseif IsModifiedClick() and self.item then
			HandleModifiedItemClick(self.item)
		end
	end

	local function FitToText(self)
		self:SetWidth(self.name:GetWidth() + self.text:GetWidth() + 8 + self.icon_frame:GetWidth())
	end

	local function SetTexts(self, name, text, total, nr, ng, nb, tr, tg, tb)
		self.name:SetText(name and name.." " or nil)
		self.text:SetText(text)
		self.ilvl:SetText()
		self.total:SetText(total and numberize(total) or "")
		self.name:SetVertexColor(nr or 1, ng or 1, nb or 1)
		self.text:SetVertexColor(nr or 1, ng or 1, nb or 1)
		if name then
			self.name:SetWidth(opt.name_width)
		else
			self.name:SetWidth(0)
		end
		self:FitToText()
	end

	local widgets = {
		{ "icon_frame", 0 },
		{ "name", 2 },
		{ "text", 0 },
	}

	local function ApplyOptions(self)
		local a, b, xmod = "LEFT", "RIGHT", 1
		if opt.anchor.alignment == "right" then
			a, b, xmod = b, a, -1
		end
		self.icon_frame:ClearAllPoints()
		self.icon_frame:SetPoint(a)

		self.name:ClearAllPoints()
		self.name:SetPoint(a, self.icon_frame, b, 2 * xmod, 0)
		self.name:SetJustifyH(a)
		SafeSetFont(self.name, opt.font, opt.font_size_loot, opt.font_flag)

		self.text:ClearAllPoints()
		self.text:SetPoint(a, self.name, b)
		self.text:SetJustifyH(a)
		SafeSetFont(self.text, opt.font, opt.font_size_loot, opt.font_flag)

		SafeSetFont(self.ilvl, opt.font, opt.font_size_ilvl, opt.font_flag)
		SafeSetFont(self.total, opt.font, opt.font_size_quantity, opt.font_flag)

		self:FitToText()
	end

	function addon.CreateRow()
		local frame = CreateFrame("Button", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate")
		frame:SetFrameLevel(anchor:GetFrameLevel())
		frame:SetHeight(24)
		frame:SetWidth(250)

		addon:Skin(frame)
		addon:Highlight(frame, "row_highlight")
		frame:SetHighlightColor(.8, .8, .8)

		frame:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		frame:SetScript("OnClick", OnClick)
		frame:SetScript("OnEnter", OnEnter)
		frame:SetScript("OnLeave", OnLeave)
		frame:SetScript("OnHide", OnHide)

		local icon_frame = CreateFrame("Frame", nil, frame, BackdropTemplateMixin and "BackdropTemplate")
		icon_frame:SetWidth(28)
		icon_frame:SetHeight(28)
		addon:Skin(icon_frame, "item")
		addon:Highlight(icon_frame, "item_highlight")
		frame.icon_frame = icon_frame

		local icon = icon_frame:CreateTexture(nil, "BACKGROUND")
		icon:SetPoint("TOPLEFT", 3, -3)
		icon:SetPoint("BOTTOMRIGHT", -3, 3)
		icon:SetTexCoord(.07,.93,.07,.93)
		frame.icon = icon

		local ilvl = icon_frame:CreateFontString(nil, "OVERLAY")
		ilvl:SetPoint("BOTTOM", icon_frame, "BOTTOM", 0, 0)
		ilvl:SetJustifyH("CENTER")
		frame.ilvl = ilvl

		frame.name = frame:CreateFontString(nil, "OVERLAY")

		frame.text = frame:CreateFontString(nil, "OVERLAY")

		local total = icon_frame:CreateFontString(nil, "OVERLAY")
		total:SetPoint("CENTER", icon_frame, "CENTER", 0, 0)
		total:SetJustifyH("CENTER")
		frame.total = total

		frame.FitToText = FitToText
		frame.SetTexts = SetTexts
		frame.ShowTooltip = ShowTooltip
		frame.ApplyOptions = ApplyOptions

		frame:ApplyOptions()

		return frame
	end
end

function addon:UpdateAnchors(...)
	if opt.anchor.visible then
		anchor:Show()
	else
		anchor:Hide()
	end
end

function addon.SlashHandler(msg)
	if anchor:IsShown() then
		anchor:Hide()
	else
		anchor:Show()
	end
end

local items = {
	{ 52722 },
	{ 31304 },
	{ 37254 },
	{ 13262 },
	{ 15487 },
	{ 72120 },
	{ 2589 }
}
local currencies = {
	81,
	1728
}
for i,v in ipairs(items) do
	GetItemInfo(v[1])
end

local players = {
	{ UnitName("player"), select(2, UnitClass('player')) },
	{ 'Player1', 'MAGE' },
	{ 'Player2', 'PRIEST' },
	{ 'Player3', 'WARRIOR' },
	{ 'Player4', 'SHAMAN' }
}

local random = math.random
local function random_player(is_me)
	return is_me and players[1][1] or players[random(2, 5)][1]
end

local function random_item_num(max)
	return random(1, 2) == 2 and random(1, max or 20) or 1
end

local function random_item_link()
	return select(2, GetItemInfo(items[random(1, #items)][1]))
end

local function test_item(event, is_me)
	addon.LOOT_EVENT('item', event, random_player(is_me), random_item_link(), random_item_num())
end

local function test_coin(event, is_me)
	addon.LOOT_EVENT('coin', event, random_player(is_me), random(1, 500000), "TODO")
end

local function test_currency(event)
	for _,id in ipairs(currencies) do
		addon.LOOT_EVENT('currency', event, id, random_item_num(5))
	end
end

local function test_quest_item(event, is_me)
	addon.LOOT_EVENT('item', event, random_player(is_me), random_item_link(), 1, true)
end

local function test_crafted(event)
	addon.LOOT_EVENT('crafted', event, random_item_link(), random_item_num())
end

local function test_reputation(event)
	addon.LOOT_EVENT('reputation', event, "Silvermoon Court", random(5, 50) * 10, true)
end

local function test_reputation_loss(event)
	addon.LOOT_EVENT('reputation', event, "Bloodsail Buccaneers", 25, false)
end

local function test_xp(event)
	addon.LOOT_EVENT('xp', event, random(100, 5000))
end

local function test_honor(event)
	addon.LOOT_EVENT('honor', event, random(5, 40))
end

local function test_skill(event)
	addon.LOOT_EVENT('skill', event, "Skinning", random(1, 300))
end

local function test_battlepet(event)
	addon.LOOT_EVENT('item', "LOOT_ITEM_PUSHED_SELF", random_player(true), "|cff0070dd|Hbattlepet:868:1:3:158:10:12:0x0000000000000000|h[Pandaren Water Spirit]|h|r", 1)
end

local tests = {
	{ test_item, "LOOT_ITEM" },
	{ test_item, "LOOT_ITEM_SELF", true },
	{ test_item, "LOOT_ITEM_MULTIPLE" },
	{ test_item, "LOOT_ITEM_SELF_MULTIPLE", true },
	{ test_item, "LOOT_ITEM_PUSHED_SELF", true },
	{ test_item, "LOOT_ITEM_PUSHED_SELF_MULTIPLE", true },
	{ test_quest_item, "LOOT_ITEM_SELF", true },
	{ test_coin, "LOOT_MONEY" },
	{ test_coin, "LOOT_MONEY_SPLIT", true },
	{ test_coin, "YOU_LOOT_MONEY", true },
	{ test_currency, "CURRENCY_GAINED" },
	{ test_currency, "CURRENCY_GAINED_MULTIPLE" },
	{ test_crafted, "LOOT_ITEM_CREATED_SELF" },
	{ test_crafted, "CURRENCY_GAINED_MULTIPLE" },
	{ test_reputation, "FACTION_STANDING_INCREASED" },
	{ test_reputation, "FACTION_STANDING_INCREASED" },
	{ test_reputation_loss, "FACTION_STANDING_DECREASED" },
	{ test_xp, "PLAYER_XP_UPDATE" },
	{ test_xp, "PLAYER_XP_UPDATE" },
	{ test_honor, "COMBATLOG_HONORAWARD" },
	{ test_skill, "SKILL_RANK_UP" },
	{ test_battlepet }

}

local queue, queueframe, tick, qactive = {}, CreateFrame("Frame"), 0, false

local function queue_update(self, elapsed)
	tick = tick + elapsed
	if tick > 0.5 then
		tick = 0
		local time = GetTime()
		for k,v in pairs(queue) do
			if v[1] < time then
				-- Drop the entry before running it, so a test that throws cannot wedge the queue open forever.
				queue[k] = nil
				v[2](select(3, unpack(v)))
			end
		end
		if not next(queue) then
			self:SetScript("OnUpdate", nil)
			qactive = false
		end
	end
end

function XLootMonitor.TestSettings()
	local now = GetTime()
	if not qactive then
		queueframe:SetScript("OnUpdate", queue_update)
		qactive = true
	end
	for i,v in ipairs(tests) do
		table.insert(queue, { now + i * .5, unpack(v) })
	end
end

XLoot:SetSlashCommand("xlmd", XLootMonitor.TestSettings)
