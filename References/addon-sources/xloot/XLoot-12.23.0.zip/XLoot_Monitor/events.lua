local lib = LibStub:NewLibrary("LootEvents", "3")
if not lib then return nil end
local print = print

local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo

local issecret = issecretvalue

--[[// Usage
	Callbacks receive (event, pattern, ...)
	LootEvents:RegisterLootCallback(func)
		event: 'item'
			player_name, item_link, num_items
		event: 'coin'
			player_name, total_copper, coin_string
		event: 'systemcoin'
			player_name, total_copper, coin_string
		event: 'currency'
			currency, num_currency
		event: 'crafted'
			item_link, num_items
		event: 'reputation'
			faction, amount (nil on lines without one), gained
		event: 'honor'
			amount
		event: 'skill'
			skill_name, rank
--]]

lib.callbacks = lib.callbacks or { loot = {} }
local lootcb = lib.callbacks.loot

local need_loot = next(lootcb) and true or false

function lib:RegisterLootCallback(func)
	table.insert(lootcb, func)
	need_loot = true
end

local current_pattern = nil
local function trigger_loot(event, ...)
	for _, func in ipairs(lootcb) do
		func(event, current_pattern, ...)
	end
end

local Deformat = XLoot.Deformat

local loot_patterns, system_patterns

local function Handler(text)
	if issecret and issecret(text) then return end
	if need_loot then
		for i, v in ipairs(loot_patterns) do
			local m1, m2, m3, m4 = Deformat(text, v[1])
			if m1 then
				current_pattern = v[1]
				return v[2](m1, m2, m3, m4)
			end
		end
	end
end

-- Whitelist-only - never route SYSTEM through Handler (LOOT_MONEY inverts to "(.-) loots (.-)" and would cross-match arbitrary system spam).
local function SystemHandler(text)
	if issecret and issecret(text) then return end
	if not need_loot then return end
	if not text:find('%d') then return end
	for i, v in ipairs(system_patterns) do
		local m1 = Deformat(text, v[1])
		if m1 then
			current_pattern = v[1]
			return v[2](m1)
		end
	end
end

local ParseCoinString = XLoot.ParseCoinString

if lib.frame then
	lib.frame:SetScript("OnEvent", function() return nil end)
end
lib.frame = CreateFrame("Frame")
local f = lib.frame
local events = {}
f:SetScript("OnEvent", function(_, e, ...) if events[e] then events[e](...) end end)
local function event(e, func)
	f:RegisterEvent(e)
	events[e] = func
end

event("CHAT_MSG_LOOT", Handler)
event("CHAT_MSG_MONEY", Handler)
event("CHAT_MSG_CURRENCY", Handler)
event("CHAT_MSG_SYSTEM", SystemHandler)

local player = UnitName('player')

loot_patterns = { }
do
	local function handler(str, func)
		assert(_G[str], "String does not exist", str)
		table.insert(loot_patterns, { _G[str], func, str })
	end

	local function loot(who, what, num)
		trigger_loot('item', who, what, num or 1)
	end

	local function loot_self(what, num)
		trigger_loot('item', player, what, num or 1)
	end

	local function coin(who, str)
		trigger_loot('coin', who, ParseCoinString(str), str)
	end

	local function coin_self(str)
		trigger_loot('coin', player, ParseCoinString(str), str)
	end

	handler('LOOT_ITEM_PUSHED_SELF_MULTIPLE', loot_self)
	handler('LOOT_ITEM_PUSHED_SELF', loot_self)
	handler('LOOT_ITEM_SELF_MULTIPLE', loot_self)

	-- Account for Russian locale using the same string for LOOT_MONEY as LOOT_ITEM_SELF
	if GetLocale() == "ruRU" then
		handler('LOOT_ITEM_SELF', function(what)
			if not what:match("|H") then -- No link, match coins
				coin_self(what)
			else
				loot_self(what)
			end
		end)
	else
		handler('LOOT_ITEM_SELF', loot_self)
		handler('YOU_LOOT_MONEY_GUILD', coin_self)
		handler('YOU_LOOT_MONEY', coin_self)
	end
	handler('LOOT_ITEM_MULTIPLE', loot)
	handler('LOOT_ITEM', loot)


	handler('LOOT_MONEY', coin)
	handler('LOOT_MONEY_SPLIT_GUILD', coin_self)
	handler('LOOT_MONEY_SPLIT', coin_self)

	local function currency(link, num)
		trigger_loot('currency', link:match('currency:(%d+)'), num or 1)
	end
	handler('CURRENCY_GAINED_MULTIPLE', currency)
	handler('CURRENCY_GAINED', currency)

	local function crafted(what, num)
		trigger_loot('crafted', what, num or 1)
	end
	handler('LOOT_ITEM_CREATED_SELF_MULTIPLE', crafted)
	handler('LOOT_ITEM_CREATED_SELF', crafted)
	handler('LOOT_ITEM_REFUND_MULTIPLE', loot_self)
	handler('LOOT_ITEM_REFUND', loot_self)
	handler('LOOT_MONEY_REFUND', coin_self)
	handler('LOOT_ITEM_WHILE_PLAYER_INELIGIBLE', loot)

end

system_patterns = { }
do
	local function handler(str, func)
		if _G[str] then -- absent on some flavors and locales, so skip cleanly
			table.insert(system_patterns, { _G[str], func, str })
		end
	end

	-- Reward gold ("Received %s.") is word-form on some flavors and coin-texture markup on others, so handle both.
	local function ParseCoinTexture(str)
		local g = tonumber(str:match("(%d+)%s*|T[^|]-Gold")) or 0
		local s = tonumber(str:match("(%d+)%s*|T[^|]-Silver")) or 0
		local c = tonumber(str:match("(%d+)%s*|T[^|]-Copper")) or 0
		return g*10000 + s*100 + c
	end

	local function system_coin(str)
		local copper = ParseCoinString(str)
		if copper == 0 then copper = ParseCoinTexture(str) end
		if copper > 0 then -- "Received %s." also matches non-money lines, which parse to 0
			trigger_loot('systemcoin', player, copper, str)
		end
	end

	handler('ERR_QUEST_REWARD_MONEY_S', system_coin)
end

local function match_patterns(patterns, text)
	for _, v in ipairs(patterns) do
		local m1, m2, m3 = Deformat(text, v[1])
		if m1 then
			current_pattern = v[1]
			v[2](m1, m2, m3)
			return true
		end
	end
end

local function FeedHandler(patterns, prepare)
	return function(text)
		if issecret and issecret(text) then return end
		if not need_loot then return end
		if not match_patterns(patterns, text) and prepare then
			match_patterns(patterns, prepare(text))
		end
	end
end

local function feed_pattern(list, str, func)
	if _G[str] then -- absent on some flavors, like the account-wide reputation lines
		table.insert(list, { _G[str], func, str })
	end
end

local bonus_tails = {}
for _, str in ipairs({ 'FACTION_STANDING_INCREASED_REFER_PART', 'FACTION_STANDING_INCREASED_ACH_PART', 'FACTION_STANDING_INCREASED_REST_PART' }) do
	if _G[str] then
		table.insert(bonus_tails, "%s*"..XLoot.InvertFormatString(_G[str]))
	end
end

-- The client can append bonus parts to a plain reputation line, which the anchored patterns would then miss
local function strip_bonus(text)
	for _, tail in ipairs(bonus_tails) do
		text = text:gsub(tail, "")
	end
	return text
end

local faction_patterns, honor_patterns, skill_patterns = {}, {}, {}
do
	local function gain(faction, amount)
		trigger_loot('reputation', faction, tonumber(amount), true)
	end

	local function loss(faction, amount)
		trigger_loot('reputation', faction, tonumber(amount), false)
	end

	local function faction(str, func)
		feed_pattern(faction_patterns, str, func)
	end

	faction('FACTION_STANDING_INCREASED', gain)
	faction('FACTION_STANDING_INCREASED_ACCOUNT_WIDE', gain)
	faction('FACTION_STANDING_INCREASED_ACH_BONUS', gain)
	faction('FACTION_STANDING_INCREASED_ACH_BONUS_ACCOUNT_WIDE', gain)
	faction('FACTION_STANDING_INCREASED_BONUS', gain)
	faction('FACTION_STANDING_INCREASED_DOUBLE_BONUS', gain)
	faction('FACTION_STANDING_INCREASED_GENERIC', gain)
	faction('FACTION_STANDING_INCREASED_GENERIC_ACCOUNT_WIDE', gain)
	faction('FACTION_STANDING_DECREASED', loss)
	faction('FACTION_STANDING_DECREASED_ACCOUNT_WIDE', loss)
	faction('FACTION_STANDING_DECREASED_GENERIC', loss)
	faction('FACTION_STANDING_DECREASED_GENERIC_ACCOUNT_WIDE', loss)

	-- MoP Classic awards fractional honor, and a comma decimal would defeat tonumber
	local function honor(amount)
		trigger_loot('honor', tonumber((amount:gsub(",", "."))))
	end

	feed_pattern(honor_patterns, 'COMBATLOG_HONORAWARD', honor)
	feed_pattern(honor_patterns, 'COMBATLOG_HONORGAIN', function(_, _, amount) honor(amount) end)
	feed_pattern(honor_patterns, 'COMBATLOG_HONORGAIN_EXHAUSTION1', function(_, _, amount) honor(amount) end)
	feed_pattern(honor_patterns, 'COMBATLOG_HONORGAIN_NO_RANK', function(_, amount) honor(amount) end)
	feed_pattern(honor_patterns, 'COMBATLOG_HONORGAIN_NO_RANK_EXHAUSTION1', function(_, amount) honor(amount) end)

	local function skill(name, rank)
		trigger_loot('skill', name, tonumber(rank))
	end

	feed_pattern(skill_patterns, 'SKILL_RANK_UP', skill)
	feed_pattern(skill_patterns, 'ERR_SKILL_UP_SI', skill)
end

local FactionHandler = FeedHandler(faction_patterns, strip_bonus)
local HonorHandler = FeedHandler(honor_patterns)
local SkillHandler = FeedHandler(skill_patterns)
event("CHAT_MSG_COMBAT_FACTION_CHANGE", FactionHandler)
event("CHAT_MSG_COMBAT_HONOR_GAIN", HonorHandler)
event("CHAT_MSG_SKILL", SkillHandler)

