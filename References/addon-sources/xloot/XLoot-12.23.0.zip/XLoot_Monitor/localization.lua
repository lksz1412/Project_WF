﻿-- See: http://wow.curseforge.com/addons/xloot/localization/ to create or fix translations
local locales = {
	enUS = {
		anchor = "Loot Monitor",
		capped = "capped",
		weekly_cap = "weekly cap",
	},
	-- Possibly localized
	ptBR = {

	},
	frFR = {

	},
	deDE = {

	},
	koKR = {

	},
	esMX = {

	},
	ruRU = {

	},
	zhCN = {

	},
	esES = {

	},
	zhTW = {

	},
}

-- Automatically inserted translations
-- Monitor

-- Monitor

-- Monitor
locales.deDE["anchor"] = "Beutemonitor"

-- Monitor

-- Monitor
locales.zhCN["anchor"] = "掷骰监控"

-- Monitor

-- Monitor
locales.zhTW["anchor"] = "拾取監控"


locales.ruRU["anchor"] = "Монитор добычи"
locales.ruRU["capped"] = "лимит"
locales.ruRU["weekly_cap"] = "недельный лимит"

locales.koKR["anchor"] = "전리품 모니터"
locales.koKR["capped"] = "한도 도달"
locales.koKR["weekly_cap"] = "주간 한도 도달"

XLoot:Localize("Monitor", locales)
