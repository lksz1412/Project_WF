﻿-- See: http://wow.curseforge.com/addons/xloot/localization/ to create or fix translations
local locales = {
	enUS = {
		Core = {
			panel_title = "Global options",
			details = "Skin is applied to all XLoot modules. Most other settings currently require a /reload to be applied. Please open a ticket with any issues.\nTo turn off a single module, disable it like any normal addon.",
			skin = "Skin",
			skin_desc = "Select skin to use. Includes Masque skins",
			skin_anchors = "Skin anchors",
			skin_anchors_desc = "Apply skin to anchors that XLoot uses",
			tooltip_sell = "Vendor sell price in tooltips",
			tooltip_sell_desc = "Add a vendor sell-price line to item tooltips, including the full value of a stack (e.g. 20 x 6s). Applies everywhere item tooltips appear.",
			value_coin_icons = "Coin icons",
			value_coin_icons_desc = "Show money as gold, silver, and copper coin icons instead of text. Applies to looted coins in the loot window and the Loot Monitor, the loot row sell price, and the Classic tooltip sell line. Off by default.",
			minimap_icon = "Minimap icon",
			minimap_icon_desc = "Show an XLoot coin button on the minimap. Left-click opens these options, right-click shows What's New, and Shift-click toggles Speedy auto-loot. Drag it to move it around the minimap. XLoot is also offered to broker displays like Titan Panel, ChocolateBar, and ElvUI datatexts whether or not this is on. Off by default.",
			whatsnew_show = "Show What's New now",
			whatsnew_show_desc = "Reopen the What's New summary for the current version.",
			whatsnew_mode = "After an update",
			whatsnew_mode_desc = "Choose how XLoot tells you about new features after an update: open the What's New popup automatically, post a quiet clickable link in chat, or show nothing.",
			reset_defaults = "Reset to Defaults",
			reset_defaults_desc = "Reset all XLoot settings in the current profile back to their defaults.",
			discord = "Join our Discord!",
			discord_desc = "Open a copyable invite link to the XLoot community Discord.",
			module_header = "Module options",
		},
		Frame = {
			panel_title = "Loot Frame",
			panel_desc = "Provides a adjustable loot frame",
			-- Group labels
			frame_options = "Frame settings",
			slot_options = "Loot slots",
			link_button = "Link all button",
			autolooting = "Auto-looting",
			colors = "Colors",

			-- Option labels
			autoloot_currency = "Auto loot currency",
			autoloot_currency_desc = "When to automatically loot currency",
			autoloot_quest = "Auto loot quest items",
			autoloot_quest_desc = "When to automatically loot quest items",
			autoloot_tradegoods = "Auto loot trade goods",
			autoloot_tradegoods_desc = "When to automatically loot any item of Trade Goods type",
			autoloot_gear = "Auto loot gear",
			autoloot_gear_desc = "When to automatically loot any equippable item (armor and weapons)",
			autoloot_gear_quality = "Minimum gear quality",
			autoloot_gear_quality_desc = "Only auto loot gear of this quality or higher (Poor means all gear)",
			autoloot_gear_minlevel = "Minimum gear item level",
			autoloot_gear_minlevel_desc = "Only auto loot gear at or above this item level (0 to ignore item level)",
			autoloot_value = "Auto loot by value",
			autoloot_value_desc = "When to automatically loot items worth at least the minimum price",
			autoloot_value_minprice = "Minimum price (gold)",
			autoloot_value_minprice_desc = "Only auto loot when the looted stack's total vendor value is at least this many gold (0 means any sellable item)",
			autoloot_quality = "Auto loot by quality",
			autoloot_quality_desc = "When to automatically loot any item at or above the minimum quality below, whatever its type",
			autoloot_quality_min = "Minimum quality",
			autoloot_quality_min_desc = "Only auto loot items of this quality or higher (Poor means everything)",
			autoloot_all = "Auto loot everything",
			speedy_autoloot = "Speedy auto-loot",
			speedy_autoloot_desc = "Vacuum every loot slot the instant loot is available, one item per server tick (paced to avoid the disconnect on big AoE piles) and without showing the loot window. Off by default. Ignores the per-item filters below unless \"Only speedy-loot filtered items\" is on. Hold your auto-loot-toggle modifier to skip Speedy and get the normal window for one loot. To switch it on or off without opening these options, type /xlspeedy, set the XLoot key binding, or Shift-click the minimap icon.",
			speedy_autoloot_respect_filters = "Only speedy-loot filtered items",
			speedy_autoloot_respect_filters_desc = "Instead of grabbing everything, Speedy loots only the items your filters below would auto loot -- just paced and without the window flash. Non-matching items still appear in the loot window.",
			speedy_autoloot_skip_fishing = "Leave fishing catches alone",
			speedy_autoloot_skip_fishing_desc = "Let fishing loot open the normal loot window instead of being speedy-looted. Speedy can empty the bobber before a fishing tracker addon has read the catch, so turn this on if one is missing fish. Everything else still speedy-loots as usual.",
			autoloot_list = "Auto loot listed items",
			autoloot_list_desc = "When to automatically loot listed items",
			autoloot_item_list = "Items to loot",
			autoloot_item_add = "Add items",
			autoloot_item_add_desc = "Type an item name to add it to the list, or click in the box and then shift-click an item. Separate several names with commas. Capital letters don't matter, and the small \"A\" button on loot window rows adds items too.",
			autoloot_item_remove = "Remove an item",
			autoloot_item_remove_desc = "Pick a listed item, then click Remove to take it off the list.",
			autoloot_item_remove_button = "Remove",
			-- frame_scale = "Frame scale",
			-- frame_alpha = "Frame alpha",
			frame_color_border = "Frame border color",
			frame_color_backdrop = "Frame backdrop color",
			frame_color_gradient = "Frame gradient color",
			frame_width_automatic = "Automatically expand frame",
			frame_width = "Frame width",
			old_close_button = "Use old close button",
			loot_highlight = "Highlight slots on mouseover",
			-- loot_alpha = "Slot alpha",
			loot_color_border = "Loot border color",
			loot_color_backdrop = "Loot backdrop color",
			loot_color_gradient = "Loot gradient color",
			loot_color_info = "Information text color",
			loot_color_quest = "Quest item color",
			loot_color_quest_desc = "The color quest items are painted. Only used while \"Color quest items\" is on and \"Use my class color\" is off.",
			loot_collapse = "Collapse looted slots",
			loot_icon_size = "Loot icon size",
			loot_row_height = "Loot row height",
			quality_color_frame = "Color frame border by top quality",
			quality_color_slot = "Color loot border by quality",
			quest_color_slot = "Color quest items",
			quest_color_slot_desc = "Paint the name and border of quest items in their own color so they stand out when the loot window opens. Covers both quest-type items and ordinary items your active quests ask you to collect. Overrides the quality coloring on those rows.",
			quest_color_class = "Use my class color",
			quest_color_class_desc = "Color quest items with your own class color instead of the color set in \"Quest item color\".",
			loot_texts_info = "Show detailed information",
			loot_texts_bind = "Show loot bind type",
			loot_texts_lock = "Show locked status",
			loot_texts_sell = "Show vendor sell price",
			loot_texts_sell_desc = "Display each item's total vendor sell value on the loot row",
			loot_texts_newlook = "Show new-appearance tag",
			loot_texts_newlook_desc = "Tag gear whose transmog appearance you haven't collected from any source yet with a cyan (new look). Retail only.",
			loot_texts_upgrade = "Show upgrade tag",
			loot_texts_upgrade_desc = "Tag looted weapons and armor with a green (upgrade) when their item level beats what you have equipped in that slot (same weapon/armor type).",
			loot_buttons_auto = "Autoloot shortcut",
			loot_buttons_auto_desc = "A button to add any item to your auto-looting list (See below)\nOnly shown when the item would be autolooted",
			font_size_info = "Loot information",
			font_size_bottombuttons = "Linkall/Close",
			font_flag_loot = "Font outline",
			font_flag_loot_desc = "Outline style for the item name and information text in the loot window.",
			font_flag = "Detail outline",
			font_flag_desc = "Outline style for the smaller loot-row texts: the stack count, the bind (BoE/BoP) tag, and the row buttons.",
			frame_snap = "Snap frame to mouse",
			frame_snap_offset_x = "Horizontal snap offset",
			frame_snap_offset_y = "Vertical snap offset",
			frame_grow_upwards = "Expand frame upwards",
			frame_draggable = "Loot frame draggable",
			linkall_threshold = "Minimum quality",
			linkall_threshold_desc = "Only link loot at this quality or higher.",
			linkall_channel = "Link channel",
			linkall_channel_desc = "The chat channel loot links are sent to.",
			linkall_channel_secondary = "Secondary channel",
			linkall_channel_secondary_desc = "An optional second channel that loot links are also sent to. Set to None to disable.",
			linkall_show = "Link button visibility",
			linkall_first_only = "Only link top item",
			linkall_auto = "Announce loot on open",
			linkall_auto_desc = "Automatically link loot to the default chat link channel when a loot window opens, using the quality threshold above. Each loot source is only announced once.",

			autolooting_text = "Everything in this section is XLoot's own auto-loot, a separate system from Blizzard's built-in Auto Loot (the game's own setting, in Esc > Options). XLoot can vacuum a whole corpse instantly (Speedy auto-loot) or auto-grab only the items matching your filters below. Avoid running it alongside Blizzard's Auto Loot: two systems looting the same corpse causes harmless 'that object is busy' warnings. Pick one to do your looting.",

			autolooting_list = "To automatically loot specific items, list them below.\n  Example: Linen Cloth,Ashbringer,Copper Ore",

			autolooting_details = "XLoot will choose the highest setting when deciding to loot a slot. This allows, for example, auto looting everything while solo yet only quest items and money while in a group.",

			show_slot_errors = "Looting errors in chat",
			show_slot_errors_desc = "Print a chat message when a loot item cannot be shown for some reason. Most of these should be able to be safely ignored.",
		},
		Group = {
			panel_title = "Group Loot",
			-- Group labels
			testing = "Testing",
			anchors = "Anchors",
			rolls = "Roll frames",
			roll_tracking = "What rolls to show",
			extra_info = "Details",

			-- Header labels
			expiration = "Expiration (in seconds)",

			-- Option labels
			test_settings = "Click to test settings",
			text_time = "Show time remaining",
			text_time_desc = "Displays seconds remaining to roll over item icon",
			text_ilvl = "Show item level",
			roll_highlight = "Highlight relevant rolls",
			roll_highlight_desc = "Recolors the roll window border when the drop is an upgrade or an appearance you have not collected, so you can tell at a glance whether to roll.",
			roll_highlight_upgrade = "Item level upgrades",
			roll_highlight_upgrade_desc = "Use a green border when the item's item level beats what you have equipped.",
			roll_highlight_newlook = "Uncollected appearances",
			roll_highlight_newlook_desc = "Use a blue border when you have not collected the item's appearance yet (retail only).",
			roll_urgency = "Urgent timer color",
			roll_urgency_desc = "Turns the roll countdown bar increasingly red as time runs out.",
			auto_roll = "Roll automatically",
			auto_roll_desc = "Automatically Need, Greed, or Pass on items you have a rule for. Shift-click a roll button on the roll window to set or clear that item's rule.",
			auto_roll_need = "Allow auto-Need",
			auto_roll_need_desc = "Also cast Need automatically. Off by default, so a rule can never Need an item for you without your say-so.",
			auto_roll_clear = "Clear all rules",
			auto_roll_clear_desc = "Remove every saved auto-roll rule.",
			autoroll = "Auto Roll",
			role_icon = "Show role icons",
			win_icon = "Show winning type icon",
			show_undecided = "List waiting players",
			show_undecided_desc = "List players who have not chosen how to roll",
			roll_width = "Roll frame width",
			roll_button_size = "Roll button size",
			roll_anchor_visible = "Roll anchor visible",
			roll_status = "Show roll results",
			roll_status_desc = "Show who rolled and who won on the roll window, read from the game's loot history. Hover a roll button to see who picked it and what they rolled. Retail only.",
			track_all = "Track all rolls",
			track_all_desc = "Keep every roll window open after you roll so you can watch the rolls come in and see the winner, instead of dismissing it right away.",
			track_player_roll = "Track items you roll on",
			track_player_roll_desc = "Keep a roll window open after you Need or Greed on it (but not when you Pass), so you can see how it turns out.",
			track_by_threshold = "Track items by minimum quality",
			track_by_threshold_desc = "Keep a roll window open after you roll only when the item is at least the quality selected below.",
			expire_won = "Won rolls",
			expire_won_desc = "Seconds a roll window stays up after you win the item.",
			expire_lost = "Lost/Passed rolls",
			expire_lost_desc = "Seconds a roll window stays up after you lose or pass on the item.",
			preview_show = "Show Preview",
			equip_prefix = "Show equippable prefix",
			equip_prefix_desc = "Prefixes item names to indicate if a item can be equipped or is a upgrade. (Upgrade prefix requires the Pawn addon)",
			prefix_equippable = "Equippable prefix",
			prefix_upgrade = "Upgrade prefix",
		},
		Monitor = {
			panel_title = "Loot Monitor",
			-- Group labels
			testing = "Testing",
			anchor = "Anchor",
			thresholds = "Quality thresholds",
			fading = "Row fade times (in seconds)",
			details = "Details",
			-- Option labels
			test_settings = "Click to test settings",
			visible = "Anchor visible",
			show_crafted = "Crafted",
			show_system_coin = "System gold",
			show_system_coin_desc = "Also show gold reported only as a system message (never as normal loot), such as world-quest rewards, quest turn-in gold, and reward containers like Sky Racer's Purse. Independent of the Money filter.",
			currency_cap = "Cap warning",
			currency_cap_desc = "Tag a currency row with (capped) or (weekly cap) once you reach that currency's limit, so you know further gains are going to waste. Currencies without a limit never get a tag.",
			show_reputation_desc = "Show the reputation you gain, such as \"+250 Silvermoon Court\". More gains with the same faction add up on its row while the row is still on screen. Uses the color your chat window gives reputation messages.",
			show_reputation_loss = "Reputation losses",
			show_reputation_loss_desc = "Also show the reputation you lose, in red, such as the Bloodsail Buccaneers standing you lose for killing pirates.",
			show_xp_desc = "Show the experience you gain from any source, including kills, quests, exploration and gathering. Gains add up on one row while it is still on screen. Uses the color your chat window gives experience messages.",
			show_honor_desc = "Show the honor you gain from honorable kills and PvP rewards. Gains add up on one row while it is still on screen. Uses the color your chat window gives honor messages.",
			show_skill = "Skill-ups",
			show_skill_desc = "Show a skill's new rank when it goes up, such as \"Skinning (51)\". Each skill keeps one row that updates while it is still on screen. Uses the color your chat window gives skill messages.",
			show_totals = "Show total items in inventory",
			totals_delay = "Totals delay",
			totals_delay_desc = "Time to wait before asking the game how many items you have, as the item events do not reliably match up to inventory counts",
			use_altoholic = "Include bank (Altoholic)",
			font_size_ilvl = "Item level",
			name_width = "Player name width",
			gradients = "Gradients",
			gradients_desc = "Adds soft gradient shading to the background of each monitor row. Visual only. Requires a UI reload to change.",
			quality_color = "Color rows by item quality",
			quality_color_desc = "Color loot row borders by item quality. Turn off to use your own border color, such as a class color to match the Loot Frame.",
			monitor_color_border = "Row border color",
			monitor_color_border_desc = "Border color for loot rows when quality coloring is turned off.",
			color_all_rows = "Color all rows",
			color_all_rows_desc = "Also apply your row border color to coin and currency rows, not just items, so the whole monitor matches.",
			quest_color = "Color quest items",
			quest_color_desc = "Paint the name and border of quest items in the loot feed so they stand out, the same way the loot window colors them. Covers both quest-type items and ordinary items your active quests ask you to collect, and overrides the quality coloring on those rows. Only your own loot is colored, and only items that pass through a loot window - a quest reward handed straight to your bags is not. Quest items are shown even when they fall below the quality thresholds above, so the feature still works on a default profile.",
			quest_color_class = "Use my class color",
			quest_color_class_desc = "Color quest items with your own class color instead of the color set in \"Quest item color\".",
			monitor_color_quest = "Quest item color",
			monitor_color_quest_desc = "The color quest items are painted in the loot feed. Only used while \"Color quest items\" is on and \"Use my class color\" is off.",
			rightclick_dismiss = "Right-click to dismiss rows",
			rightclick_dismiss_desc = "Right-click a monitor row to remove it early instead of waiting for it to fade. Remaining rows shift up to close the gap.",
			blizzard_alerts = "Blizzard loot alerts",
			suppress_loot_toasts = "Hide Blizzard loot pop-ups",
			suppress_loot_toasts_desc = "Suppress Blizzard's default loot toast pop-ups, the ones that slide in when you loot an item, coin, upgrade, or legendary (the blocks you see when opening lots of chests). XLoot's own Loot Monitor still shows everything, and non-loot alerts such as achievements, recipes, pets, mounts, and PvP honor are left alone. Off by default. Takes effect immediately, no reload needed.",
		},
		Toast = {
			panel_title = "Loot Toasts",
			-- Group labels
			testing = "Testing",
			anchor = "Anchor",
			filtering = "What to show",
			behavior = "Behavior",
			blizzard = "Blizzard alerts",
			mouse = "Mouse",
			font = "Font",
			-- Option labels
			enabled = "Enable loot toasts",
			enabled_desc = "Show a Blizzard-style pop-up toast when you receive notable loot. Off by default, so nothing changes until you turn it on. Toasts appear at the movable anchor and fade on their own.",
			test_settings = "Click to preview toasts",
			visible = "Anchor visible",
			threshold = "Minimum quality",
			threshold_desc = "Only show a toast for loot of this quality or higher, so common drops do not spam. Quest items can be shown separately below.",
			quest = "Quest items",
			quest_desc = "Also toast quest items, even when they are below the minimum quality.",
			ilvl = "Show item level",
			ilvl_desc = "Add the item level in front of the name, for gear.",
			max_active = "Max on screen",
			max_active_desc = "How many toasts may show at once. Extra loot waits in a queue and appears as older toasts fade.",
			fadeout_delay = "Time on screen",
			fadeout_delay_desc = "Seconds a toast stays before it fades. Hovering a toast pauses its fade.",
			vfx = "Spawn animation",
			vfx_desc = "Play the glow and shine flourish when a toast appears. Turn off for a plain fade in.",
			sfx = "Sound",
			sfx_desc = "Play a sound when a toast appears, with a distinct one for legendaries.",
			hide_blizzard = "Hide Blizzard's duplicate loot toast",
			hide_blizzard_desc = "Suppress Blizzard's default loot toast pop-ups so you do not see a duplicate next to XLoot's, the ones that slide in when you loot an item, coin, upgrade, or legendary. On by default while loot toasts are enabled. Non-loot alerts such as achievements, recipes, pets, mounts, and PvP honor are left alone. Takes effect immediately, no reload needed.",
			mouse_hover = "Tooltip on hover",
			mouse_hover_desc = "Show the item tooltip when you mouse over a toast, and pause its fade while hovered.",
			mouse_click_mode = "Clicks",
			mouse_click_mode_desc = "How toasts respond to clicks. Always is clickable but can block clicks meant for the UI behind it. Only with Shift held passes normal left-clicks through to whatever is behind, while right-click still dismisses and Shift-click still links. Never passes every click through. The anchor stays draggable in all modes.",
			click_always = "Always",
			click_modifier = "Only with Shift held",
			click_never = "Never (pass through)",
			color_border = "Color border by quality",
			color_border_desc = "Tint the toast border with the item quality color.",
			color_icon_border = "Color icon border by quality",
			color_icon_border_desc = "Tint the icon border with the item quality color.",
			color_name = "Color name by quality",
			color_name_desc = "Tint the item name text with the item quality color.",
			color_threshold = "Color only above quality",
			color_threshold_desc = "Only apply quality coloring to loot at this quality or higher.",
			font_flag = "Font outline",
			font_size = "Font size",
		},
		Master = {
			panel_title = "Loot Master",
			specialrecipients = "Special Recipients Menu",
			raidroll = "Special Rolls Menu",
			awardannounce = "Announce Item Distribution",
			confirm_qualitythreshold = "Minimum confirm quality",
			confirm_qualitythreshold_desc = "Items at this quality or higher ask for confirmation before being assigned. Never skips the prompt for everything, including epics and legendaries.",
			menu_roll = "Show raid roll",
			menu_disenchant = "Show disenchanter",
			menu_disenchanters = "Disenchant character names",
			menu_bank = "Show banker",
			menu_bankers = "Banker character names",
			menu_self = "Show self",
			award_qualitythreshold = "Minimum quality",
			award_qualitythreshold_desc = "Only announce awards for items at this quality or higher. Always announces every award, Never disables announcing.",
			award_channel = "Announce channel",
			award_channel_desc = "The chat channel award announcements are sent to. Highest available uses the widest group channel you can post to.",
			award_channel_secondary = "Secondary channel",
			award_channel_secondary_desc = "An optional second channel that award announcements are also sent to. Set to None to disable.",
			award_guildannounce = "Echo in guild chat",
			award_special = "Announce special recipients",
		},
		font = "Font",
		font_sizes = "Sizes",
		enter_to_save = "Press Enter to save a typed value.",
		font_size_loot = "Loot",
		font_size_quantity = "Quantity",
		font_flag = "Flag",
		font_flag_outline = "OUTLINE",
		font_flag_thickoutline = "THICKOUTLINE",
		font_flag_monochrome = "MONOCHROME",
		desc_channel_auto = "Highest available",
		growth_direction = "Growth direction",
		alignment = "Alignment",
		scale = "Scale",
		width = "Width",
		alpha = "Opacity",
		spacing = "Spacing",
		offset = "Offset",
		visible = "Visible",
		padding = "Padding",
		items_others = "Others' items",
		items_own = "Own items",
		up = "Up",
		down = "Down",
		left = "Left",
		right = "Right",
		top = "Top",
		bottom = "Bottom",
		minimum_quality = "Minimum quality",
		when_never = "Never",
		when_solo = "Solo",
		when_always = "Always",
		when_auto = "Automatic",
		when_group = "In groups",
		when_party = "In parties",
		when_raid = "In raids",
		whatsnew_mode_popup = "Popup window",
		whatsnew_mode_chat = "Chat link",
		whatsnew_mode_none = "None",
		profile = "Profile",
		profile_transfer = "Share settings",
		profile_export = "Export",
		profile_export_desc = "Show a settings string you can copy into XLoot on another game version, account, or computer. It carries every setting in this profile that differs from the defaults, for every XLoot module loaded here.",
		profile_import = "Import",
		profile_import_desc = "Paste a settings string exported from XLoot, then load it into a new profile or over the current one. Frame positions are fitted to this screen, and auto-roll rules only carry over between the same game version.",
		export_title = "Export XLoot settings",
		export_count = "Profile |cffffd200%s|r, settings changed from the defaults: %d.",
		export_empty = "Profile |cffffd200%s|r uses only default settings.",
		export_help = "Press Ctrl+C to copy the string below, then paste it into Import on the other client.",
		export_failed = "XLoot could not build a settings string.",
		import_title = "Import XLoot settings",
		import_help = "Paste a settings string exported from XLoot. Nothing changes until you press one of the buttons below.",
		import_summary = "From %s, profile |cffffd200%s|r, settings changed from the defaults: %d.",
		import_invalid = "This is not an XLoot settings string, or part of it is missing.",
		import_newer = "This string comes from a newer version of XLoot. Update XLoot here, then try again.",
		import_name = "New profile name",
		import_new = "Import as new profile",
		import_replace = "Replace current profile",
		import_name_missing = "Enter a name for the new profile.",
		import_name_taken = "A profile named |cffffd200%s|r already exists.",
		import_replace_confirm = "Replace every XLoot setting in profile |cffffd200%s|r with the imported ones?\n\nThis cannot be undone.",
		import_profile_changed = "The current profile changed, so nothing was replaced.",
		import_done = "Settings imported into profile |cffffd200%s|r.",
		import_missing = "Modules left out because they are not loaded here: %s.",
		import_dropped = "Settings left out because this game version does not have them: %d.",
		import_rules_skipped = "Auto-roll rules left out, since they only carry over within the same game version: %d.",
		import_offscreen = "Frame positions kept at their default spot because they would land off-screen: %d.",
		import_reload = "Type /reload to finish applying every setting.",
		game_retail = "Retail",
		game_classic_era = "Classic Era",
		game_tbc = "TBC Anniversary",
		game_mop = "MoP Classic",
		game_forever = "WoW Forever",
		game_unknown = "Unknown",
		message_reloadui_warning = "|c2244dd22%s|r: Changing |c2244dd22%s|r requires you to reload your UI before continuing to play: |c2244dd22/reload ui|r",
	},
	-- Possibly localized
	ptBR = {

	},
	frFR = {

	},
	deDE = {

	},
	koKR = {

	},
	esMX = {

	},
	ruRU = {

	},
	zhCN = {

	},
	esES = {

	},
	zhTW = {

	},
}

-- Automatically inserted translations
-- Options

-- Options

-- Options
locales.deDE["alpha"] = "Transparenz"
locales.deDE["confirm_reset_profile"] = "Dies wird alle Einstellungen für dieses Profil auf den Standard zurücksetzen. Bist du sicher?"
locales.deDE["desc_channel_auto"] = "Höchste Verfügbare"
locales.deDE["down"] = "Ab"
locales.deDE["font"] = "Schriftart"
locales.deDE["font_size_loot"] = "Beute"
locales.deDE["font_size_quantity"] = "Menge"
locales.deDE["font_sizes"] = "Größen"
locales.deDE["growth_direction"] = "Wachstumsrichtung"
locales.deDE["items_others"] = "Gegenstand anderer"
locales.deDE["items_own"] = "Eigene Gegenstände"
locales.deDE["minimum_quality"] = "Minimale Qualität"
locales.deDE["profile"] = "Profil"
locales.deDE["scale"] = "Skalierung"
locales.deDE["up"] = "Hoch"
locales.deDE["visible"] = "Sichtbar"
locales.deDE["when_always"] = "Immer"
locales.deDE["when_auto"] = "Automatisch"
locales.deDE["when_group"] = "In Gruppe"
locales.deDE["when_never"] = "Niemals"
locales.deDE["when_party"] = "In Gruppen"
locales.deDE["when_raid"] = "In Schlachtzügen"
locales.deDE["when_solo"] = "Solo"
locales.deDE["width"] = "Breite"

-- Options

-- Options
locales.zhCN["alpha"] = "透明度"
locales.zhCN["confirm_reset_profile"] = "这将重置此配置文件的全部选项。确定？"
locales.zhCN["desc_channel_auto"] = "最高可得"
locales.zhCN["down"] = "下"
locales.zhCN["font"] = "字体"
locales.zhCN["font_flag"] = "轮廓"
locales.zhCN["font_size_loot"] = "战利品"
locales.zhCN["font_size_quantity"] = "品质"
locales.zhCN["font_sizes"] = "大小"
locales.zhCN["growth_direction"] = "扩展方向"
locales.zhCN["items_others"] = "其他人的物品"
locales.zhCN["items_own"] = "自己的物品"
locales.zhCN["minimum_quality"] = "最低品质"
locales.zhCN["profile"] = "配置文件"
locales.zhCN["scale"] = "比例"
locales.zhCN["up"] = "上"
locales.zhCN["visible"] = "可见"
locales.zhCN["when_always"] = "总是"
locales.zhCN["when_auto"] = "自动"
locales.zhCN["when_group"] = "在队伍/团队中"
locales.zhCN["when_never"] = "从不"
locales.zhCN["when_party"] = "在队伍中"
locales.zhCN["when_raid"] = "在团队中"
locales.zhCN["when_solo"] = "单人"
locales.zhCN["width"] = "宽度"

-- Options
locales.esES["confirm_reset_profile"] = "Esto reseteará todas las opciones de este perfil. ¿Estás seguro?"
locales.esES["font"] = "Fuente"
locales.esES["font_size_loot"] = "Botín"
locales.esES["font_size_quantity"] = "Cantidad"
locales.esES["font_sizes"] = "Tamaños"
locales.esES["profile"] = "Perfil"
locales.esES["when_always"] = "Siempre"
locales.esES["when_auto"] = "Automático"
locales.esES["when_never"] = "Nunca"
locales.esES["when_solo"] = "Solo"

-- Options
locales.zhTW["alpha"] = "透明度"
locales.zhTW["bottom"] = "底部"
locales.zhTW["confirm_reset_profile"] = "將會重置此設定檔的所有設定。你確定要重置嗎？"
locales.zhTW["desc_channel_auto"] = "最高可得"
locales.zhTW["down"] = "下"
locales.zhTW["font"] = "字型"
locales.zhTW["font_flag"] = "標示"
locales.zhTW["font_size_loot"] = "戰利品"
locales.zhTW["font_size_quantity"] = "品質"
locales.zhTW["font_sizes"] = "大小"
locales.zhTW["growth_direction"] = "擴展方向"
locales.zhTW["items_others"] = "他人物品"
locales.zhTW["items_own"] = "自己物品"
locales.zhTW["minimum_quality"] = "最低品質"
locales.zhTW["padding"] = "填充"
locales.zhTW["profile"] = "設定檔"
locales.zhTW["scale"] = "比例"
locales.zhTW["top"] = "頂部"
locales.zhTW["up"] = "上"
locales.zhTW["visible"] = "可見"
locales.zhTW["when_always"] = "總是"
locales.zhTW["when_auto"] = "自動"
locales.zhTW["when_group"] = "隊伍/團隊中"
locales.zhTW["when_never"] = "從不"
locales.zhTW["when_party"] = "隊伍中"
locales.zhTW["when_raid"] = "團隊中"
locales.zhTW["when_solo"] = "單人"
locales.zhTW["width"] = "寬度"


-- Manually express subtables because apparently I'm the only one who thought to use namespaces the simple way

-- Core

-- Core

-- Core
locales.deDE["anchor_hide"] = "verstecken"
locales.deDE["skin_legacy"] = "XLoot: Legacy"
locales.deDE["skin_smooth"] = "XLoot: Smooth"
locales.deDE["skin_svelte"] = "XLoot: Svelte"

-- Core

-- Core
locales.zhCN["anchor_hide"] = "隐藏"
locales.zhCN["anchor_hide_desc"] = [=[在此位置锁定此模块
这将隐藏锚点
但可通过选项重新显示]=]
locales.zhCN["skin_legacy"] = "XLoot: Legacy"
locales.zhCN["skin_smooth"] = "XLoot: Smooth"
locales.zhCN["skin_svelte"] = "XLoot: Svelte"

-- Core

-- Core
locales.zhTW["anchor_hide"] = "隱藏"
locales.zhTW["anchor_hide_desc"] = [=[鎖定此模組在此位置上
這會隱藏此錨點,
但它可以藉由選項再次顯示]=]
locales.zhTW["skin_legacy"] = "XLoot: 傳統"
locales.zhTW["skin_smooth"] = "XLoot: 滑順"
locales.zhTW["skin_svelte"] = "XLoot: 苗條"


-- Frame

-- Frame
locales.frFR["bind_on_equip_short"] = "LqE"
locales.frFR["bind_on_pickup_short"] = "LqR"
locales.frFR["bind_on_use_short"] = "LqU"
locales.frFR["button_close"] = "Fermer"
locales.frFR["button_link"] = "Lien"
locales.frFR["linkall_threshold_missed"] = "Aucun butin ne correspond à votre seuil de qualité"

-- Frame
locales.deDE["bind_on_equip_short"] = "BoE"
locales.deDE["bind_on_pickup_short"] = "BoP"
locales.deDE["bind_on_use_short"] = "BoU"
locales.deDE["button_close"] = "Schließen"
locales.deDE["button_link"] = "Senden"
locales.deDE["linkall_threshold_missed"] = "Beute entspricht nicht deinen Qualitätsansprüchen"

-- Frame

-- Frame
locales.zhCN["bind_on_equip_short"] = "装备后绑定"
locales.zhCN["bind_on_pickup_short"] = "拾取后绑定"
locales.zhCN["bind_on_use_short"] = "使用后绑定"
locales.zhCN["button_close"] = "关闭"
locales.zhCN["button_link"] = "链接"
locales.zhCN["linkall_threshold_missed"] = "没有达到拾取品质门槛的物品"

-- Frame

-- Frame
locales.zhTW["bind_on_equip_short"] = "裝綁"
locales.zhTW["bind_on_pickup_short"] = "拾榜"
locales.zhTW["bind_on_use_short"] = "使綁"
locales.zhTW["button_close"] = "關閉"
locales.zhTW["button_link"] = "連結"
locales.zhTW["linkall_threshold_missed"] = "沒有達到品質門檻的戰利品"


-- Group
locales.ptBR["alert_anchor"] = "Aparecer Saques"

-- Group

-- Group
locales.deDE["alert_anchor"] = "Beute Popups"
locales.deDE["anchor"] = "Gruppenwürfe"
locales.deDE["undecided"] = "Unentschlossen"

-- Group
locales.esMX["alert_anchor"] = "Ventanas emergentes de botín"

-- Group
locales.zhCN["alert_anchor"] = "掷骰弹窗锚点"
locales.zhCN["anchor"] = "团队掷骰锚点"
locales.zhCN["undecided"] = "未决定的"

-- Group

-- Group
locales.zhTW["alert_anchor"] = "拾取彈出視窗定位"
locales.zhTW["anchor"] = "團體擲骰定位"
locales.zhTW["undecided"] = "未決"


-- Monitor

-- Monitor

-- Monitor
locales.deDE["anchor"] = "Beutemonitor"

-- Monitor

-- Monitor
locales.zhCN["anchor"] = "掷骰监控"

-- Monitor

-- Monitor
locales.zhTW["anchor"] = "拾取監控"


locales.ruRU["font"] = "Шрифт"
locales.ruRU["font_sizes"] = "Размеры"
locales.ruRU["enter_to_save"] = "Нажмите Enter, чтобы сохранить введённое значение."
locales.ruRU["font_size_loot"] = "Добыча"
locales.ruRU["font_size_quantity"] = "Количество"
locales.ruRU["font_flag"] = "Контур"
locales.ruRU["desc_channel_auto"] = "Максимально доступный"
locales.ruRU["growth_direction"] = "Направление роста"
locales.ruRU["alignment"] = "Выравнивание"
locales.ruRU["scale"] = "Масштаб"
locales.ruRU["width"] = "Ширина"
locales.ruRU["alpha"] = "Прозрачность"
locales.ruRU["spacing"] = "Интервал"
locales.ruRU["offset"] = "Смещение"
locales.ruRU["visible"] = "Видимый"
locales.ruRU["padding"] = "Отступ"
locales.ruRU["items_others"] = "Предметы других игроков"
locales.ruRU["items_own"] = "Ваши предметы"
locales.ruRU["up"] = "Вверх"
locales.ruRU["down"] = "Вниз"
locales.ruRU["left"] = "Слева"
locales.ruRU["right"] = "Справа"
locales.ruRU["top"] = "Сверху"
locales.ruRU["bottom"] = "Снизу"
locales.ruRU["minimum_quality"] = "Минимальное качество"
locales.ruRU["when_never"] = "Никогда"
locales.ruRU["when_solo"] = "В одиночку"
locales.ruRU["when_always"] = "Всегда"
locales.ruRU["when_auto"] = "Автоматически"
locales.ruRU["when_group"] = "В любой группе"
locales.ruRU["when_party"] = "В группе (не рейд)"
locales.ruRU["when_raid"] = "В рейде"
locales.ruRU["whatsnew_mode_popup"] = "Всплывающее окно"
locales.ruRU["whatsnew_mode_chat"] = "Ссылка в чате"
locales.ruRU["whatsnew_mode_none"] = "Нет"
locales.ruRU["profile"] = "Профиль"
locales.ruRU["message_reloadui_warning"] = "|c2244dd22%s|r: изменение |c2244dd22%s|r требует перезагрузки интерфейса, прежде чем продолжить игру: |c2244dd22/reload ui|r"
locales.ruRU.Core = {
	panel_title = "Общие настройки",
	details = "Скин применяется ко всем модулям XLoot. Для большинства остальных настроек сейчас требуется /reload. Если что-то работает неправильно, пожалуйста, создайте обращение.\nЧтобы отключить отдельный модуль, отключите его как обычный аддон.",
	skin = "Скин",
	skin_desc = "Выберите используемый скин. Включает скины Masque",
	skin_anchors = "Скин для якорей",
	skin_anchors_desc = "Применять скин к якорям, которые использует XLoot",
	tooltip_sell = "Цена продажи в подсказках",
	tooltip_sell_desc = "Добавляет в подсказки предметов строку с ценой продажи торговцу, включая стоимость всей стопки (например, 20 x 6с). Работает везде, где показываются подсказки предметов.",
	value_coin_icons = "Значки монет",
	minimap_icon = "Значок у миникарты",
	whatsnew_show = "Показать «Что нового»",
	whatsnew_show_desc = "Снова открыть сводку «Что нового» для текущей версии.",
	whatsnew_mode = "После обновления",
	whatsnew_mode_desc = "Выберите, как XLoot сообщает о новых возможностях после обновления: автоматически открывать окно «Что нового», выводить в чат ненавязчивую ссылку или ничего не показывать.",
	reset_defaults = "Сбросить по умолчанию",
	reset_defaults_desc = "Сбросить все настройки XLoot в текущем профиле к значениям по умолчанию.",
	discord = "Присоединяйтесь к нашему Discord!",
	discord_desc = "Открыть ссылку-приглашение в Discord-сообщество XLoot, которую можно скопировать.",
	module_header = "Настройки модулей",
	value_coin_icons_desc = "Показывать деньги значками золотых, серебряных и медных монет вместо текста. Применяется к полученным монетам в окне добычи и в мониторе добычи, к цене продажи в строке добычи и к строке цены продажи в подсказке Classic. По умолчанию выключено.",
	minimap_icon_desc = "Показывать у миникарты кнопку XLoot в виде монеты. ЛКМ открывает эти настройки, ПКМ показывает «Что нового», а Shift+ЛКМ переключает быстрый автолут. Перетащите её, чтобы переместить по краю миникарты. XLoot также доступен для брокерских панелей, таких как Titan Panel, ChocolateBar и инфотексты ElvUI, независимо от этой настройки. По умолчанию выключено.",
}
locales.ruRU.Frame = {
	panel_title = "Окно добычи",
	panel_desc = "Настраиваемое окно добычи",
	frame_options = "Настройки окна",
	slot_options = "Ячейки добычи",
	link_button = "Кнопка «Ссылки на всё»",
	autolooting = "Автолут",
	colors = "Цвета",
	autoloot_currency = "Автолут валюты",
	autoloot_currency_desc = "Когда автоматически брать валюту",
	autoloot_quest = "Автолут предметов для заданий",
	autoloot_quest_desc = "Когда автоматически брать предметы для заданий",
	autoloot_tradegoods = "Автолут хозяйственных товаров",
	autoloot_tradegoods_desc = "Когда автоматически брать любые предметы типа «Хозяйственные товары»",
	autoloot_gear = "Автолут экипировки",
	autoloot_gear_desc = "Когда автоматически брать любые предметы, которые можно надеть (доспехи и оружие)",
	autoloot_gear_quality = "Минимальное качество экипировки",
	autoloot_gear_quality_desc = "Автоматически брать только экипировку такого или более высокого качества (при значении «Низкое» берётся вся экипировка)",
	autoloot_gear_minlevel = "Минимальный уровень экипировки",
	autoloot_gear_minlevel_desc = "Автоматически брать только экипировку с таким или более высоким уровнем предмета (0 — не учитывать уровень предмета)",
	autoloot_value = "Автолут по цене",
	autoloot_value_desc = "Когда автоматически брать предметы стоимостью не ниже минимальной цены",
	autoloot_value_minprice = "Минимальная цена (золото)",
	autoloot_value_minprice_desc = "Автоматически брать, только если общая стоимость продажи торговцу взятой стопки составляет не менее указанного числа золота (0 — любой предмет, который можно продать)",
	autoloot_quality = "Автолут по качеству",
	autoloot_quality_desc = "Когда автоматически брать любой предмет не ниже указанного ниже минимального качества, независимо от его типа",
	autoloot_quality_min = "Минимальное качество",
	autoloot_quality_min_desc = "Автоматически брать предметы только такого или более высокого качества (при значении «Низкое» берётся всё)",
	autoloot_all = "Автолут всего",
	speedy_autoloot = "Быстрый автолут",
	speedy_autoloot_respect_filters = "Быстро брать только отфильтрованное",
	speedy_autoloot_respect_filters_desc = "Вместо того чтобы брать всё подряд, быстрый автолут забирает только предметы, которые взяли бы ваши фильтры ниже — просто быстрее и без вспышки окна. Остальные предметы по-прежнему показываются в окне добычи.",
	speedy_autoloot_skip_fishing = "Не трогать улов с рыбалки",
	speedy_autoloot_skip_fishing_desc = "Позволяет улову с рыбалки открываться в обычном окне добычи, а не забираться быстрым автолутом. Быстрый автолут может опустошить поплавок раньше, чем аддон для учёта рыбалки успеет прочитать улов, поэтому включите эту настройку, если такой аддон пропускает рыбу. Всё остальное по-прежнему берётся быстро.",
	autoloot_list = "Автолут предметов из списка",
	autoloot_list_desc = "Когда автоматически брать предметы из списка",
	autoloot_item_list = "Предметы для автолута",
	frame_color_border = "Цвет рамки окна",
	frame_color_backdrop = "Цвет фона окна",
	frame_color_gradient = "Цвет градиента окна",
	frame_width_automatic = "Автоматически расширять окно",
	frame_width = "Ширина окна",
	old_close_button = "Использовать старую кнопку закрытия",
	loot_highlight = "Подсвечивать ячейки при наведении",
	loot_color_border = "Цвет рамки добычи",
	loot_color_backdrop = "Цвет фона добычи",
	loot_color_gradient = "Цвет градиента добычи",
	loot_color_info = "Цвет текста информации",
	loot_color_quest = "Цвет предметов для заданий",
	loot_color_quest_desc = "Цвет, в который окрашиваются предметы для заданий. Используется, только когда включено «Окрашивать предметы для заданий» и выключено «Использовать цвет моего класса».",
	loot_collapse = "Сворачивать полученные ячейки",
	loot_icon_size = "Размер значка добычи",
	loot_row_height = "Высота строки добычи",
	quality_color_frame = "Окрашивать рамку окна по высшему качеству",
	quality_color_slot = "Окрашивать рамку добычи по качеству",
	quest_color_slot = "Окрашивать предметы для заданий",
	quest_color_slot_desc = "Окрашивает название и рамку предметов для заданий в особый цвет, чтобы они выделялись при открытии окна добычи. Охватывает как предметы типа «Задания», так и обычные предметы, которые нужны для ваших активных заданий. Заменяет окраску по качеству в этих строках.",
	quest_color_class = "Использовать цвет моего класса",
	quest_color_class_desc = "Окрашивать предметы для заданий в цвет вашего класса вместо цвета, заданного в «Цвет предметов для заданий».",
	loot_texts_info = "Показывать подробную информацию",
	loot_texts_bind = "Показывать тип привязки",
	loot_texts_lock = "Показывать статус блокировки",
	loot_texts_sell = "Показывать цену продажи",
	loot_texts_sell_desc = "Показывать в строке добычи общую стоимость продажи каждого предмета торговцу",
	loot_texts_newlook = "Показывать метку нового внешнего вида",
	loot_texts_newlook_desc = "Помечает голубой меткой (новый вид) экипировку, внешний вид которой для трансмогрификации вы ещё не собрали ни из какого источника. Только Retail.",
	loot_texts_upgrade = "Показывать метку улучшения",
	loot_texts_upgrade_desc = "Помечает зелёной меткой (улучшение) добытое оружие и доспехи, если их уровень предмета выше, чем у надетого в этой ячейке (того же типа оружия или доспехов).",
	loot_buttons_auto = "Ярлык автолута",
	loot_buttons_auto_desc = "Кнопка для добавления любого предмета в ваш список автолута (см. ниже)\nПоказывается, только когда предмет был бы взят автоматически",
	font_size_info = "Информация о добыче",
	font_size_bottombuttons = "Ссылка/Закрыть",
	font_flag_loot = "Контур шрифта",
	font_flag_loot_desc = "Стиль контура для названия предмета и информационного текста в окне добычи.",
	font_flag = "Контур деталей",
	font_flag_desc = "Стиль контура для мелких текстов строки добычи: количества в стопке, метки типа привязки (БоЕ/БоП) и кнопок строки.",
	frame_snap = "Привязывать окно к курсору мыши",
	frame_snap_offset_x = "Смещение по горизонтали",
	frame_snap_offset_y = "Смещение по вертикали",
	frame_grow_upwards = "Расширять окно вверх",
	frame_draggable = "Окно добычи можно перетаскивать",
	linkall_threshold = "Минимальное качество",
	linkall_threshold_desc = "Отправлять ссылки только на добычу такого или более высокого качества.",
	linkall_channel = "Канал для ссылок",
	linkall_channel_desc = "Канал чата, в который отправляются ссылки на добычу.",
	linkall_channel_secondary = "Дополнительный канал",
	linkall_channel_secondary_desc = "Необязательный второй канал, в который тоже отправляются ссылки на добычу. Выберите «Нет», чтобы отключить.",
	linkall_show = "Видимость кнопки ссылки",
	linkall_first_only = "Ссылка только на верхний предмет",
	linkall_auto = "Объявлять добычу при открытии",
	linkall_auto_desc = "Автоматически отправлять ссылки на добычу в канал чата по умолчанию при открытии окна добычи, используя порог качества выше. Каждый источник добычи объявляется только один раз.",
	autolooting_text = "Всё в этом разделе — собственный автолут XLoot, отдельная система от встроенного автолута Blizzard (настройка самой игры в Esc > Параметры). XLoot может мгновенно забрать всю добычу с цели (Быстрый автолут) или автоматически взять только предметы, подходящие под ваши фильтры ниже. Не используйте его одновременно с автолутом Blizzard: когда две системы забирают добычу с одной и той же цели, появляются безвредные предупреждения о том, что объект занят. Выберите что-то одно.",
	autolooting_list = "Чтобы автоматически брать определённые предметы, перечислите их ниже.\n  Пример: Льняная ткань,Испепелитель,Медная руда",
	autolooting_details = "XLoot выбирает наивысшую настройку при решении, брать ли ячейку. Это позволяет, например, брать всё автоматически в одиночку, но только предметы для заданий и деньги в группе.",
	show_slot_errors = "Ошибки добычи в чате",
	show_slot_errors_desc = "Выводить сообщение в чат, если предмет добычи по какой-то причине не удалось показать. Большинство таких сообщений можно безопасно игнорировать.",
	speedy_autoloot_desc = "Мгновенно забирает всю добычу, как только она становится доступной, по одному предмету за такт сервера (с паузами, чтобы не отключало от сервера при больших кучах добычи после массового убийства) и без показа окна добычи. По умолчанию выключено. Игнорирует приведённые ниже фильтры предметов, если не включено «Быстро брать только отфильтрованное». Удерживайте клавишу-модификатор переключения автолута, чтобы пропустить быстрый автолут и получить обычное окно для одной добычи. Чтобы включать и выключать его, не открывая эти настройки, введите /xlspeedy, задайте привязку клавиши XLoot или нажмите Shift+ЛКМ по значку у миникарты.",
}
locales.ruRU.Group = {
	panel_title = "Добыча группы",
	testing = "Проверка",
	anchors = "Якоря",
	rolls = "Окна бросков",
	roll_tracking = "Какие броски показывать",
	extra_info = "Подробности",
	expiration = "Время показа (в секундах)",
	test_settings = "Нажмите, чтобы проверить настройки",
	text_time = "Показывать оставшееся время",
	text_time_desc = "Показывает оставшиеся секунды поверх значка предмета",
	text_ilvl = "Показывать уровень предмета",
	roll_highlight = "Подсвечивать важные броски",
	roll_highlight_desc = "Меняет цвет рамки окна броска, если предмет — улучшение или внешний вид, которого у вас нет, чтобы сразу было видно, стоит ли бросать.",
	roll_highlight_upgrade = "Улучшения по уровню предмета",
	roll_highlight_upgrade_desc = "Зелёная рамка, если уровень предмета выше, чем у надетого.",
	roll_highlight_newlook = "Несобранные внешние виды",
	roll_highlight_newlook_desc = "Синяя рамка, если вы ещё не собрали внешний вид предмета (только Retail).",
	roll_urgency = "Срочный цвет таймера",
	roll_urgency_desc = "Полоса обратного отсчёта броска становится всё краснее по мере истечения времени.",
	auto_roll = "Бросать автоматически",
	auto_roll_desc = "Автоматически выбирать «Нужно», «Не откажусь» или «Пас» для предметов, на которые у вас есть правило. Shift+клик по кнопке броска в окне броска задаёт или удаляет правило для этого предмета.",
	auto_roll_need = "Разрешить авто-«Нужно»",
	auto_roll_need_desc = "Также автоматически выбирать «Нужно». По умолчанию выключено, поэтому правило никогда не выберет «Нужно» за вас без вашего ведома.",
	auto_roll_clear = "Очистить все правила",
	auto_roll_clear_desc = "Удалить все сохранённые правила автоброска.",
	autoroll = "Автобросок",
	role_icon = "Показывать значки ролей",
	win_icon = "Показывать значок победившего типа броска",
	show_undecided = "Список ожидающих игроков",
	show_undecided_desc = "Показывать список игроков, которые ещё не выбрали, как бросать",
	roll_width = "Ширина окна броска",
	roll_button_size = "Размер кнопок броска",
	roll_anchor_visible = "Якорь бросков виден",
	roll_status = "Показывать результаты бросков",
	roll_status_desc = "Показывать в окне броска, кто бросал и кто выиграл, по данным истории добычи игры. Только Retail.",
	track_all = "Отслеживать все броски",
	track_all_desc = "Оставлять каждое окно броска открытым после вашего броска, чтобы наблюдать за результатами и видеть победителя, а не закрывать его сразу.",
	track_player_roll = "Отслеживать предметы, на которые вы бросали",
	track_player_roll_desc = "Оставлять окно броска открытым после того, как вы выбрали «Нужно» или «Не откажусь» (но не «Пас»), чтобы увидеть, чем всё закончится.",
	track_by_threshold = "Отслеживать предметы по минимальному качеству",
	track_by_threshold_desc = "Оставлять окно броска открытым после вашего броска, только если качество предмета не ниже выбранного ниже.",
	expire_won = "Выигранные броски",
	expire_won_desc = "Сколько секунд окно броска остаётся на экране после того, как вы выиграли предмет.",
	expire_lost = "Проигранные/пропущенные броски",
	expire_lost_desc = "Сколько секунд окно броска остаётся на экране после того, как вы проиграли или выбрали «Пас».",
	preview_show = "Показать предпросмотр",
	equip_prefix = "Показывать префикс экипируемого",
	equip_prefix_desc = "Добавляет к названиям предметов префикс, показывающий, можно ли предмет надеть и является ли он улучшением. (Для префикса улучшения требуется аддон Pawn)",
	prefix_equippable = "Префикс экипируемого",
	prefix_upgrade = "Префикс улучшения",
}
locales.ruRU.Monitor = {
	panel_title = "Монитор добычи",
	testing = "Проверка",
	anchor = "Якорь",
	thresholds = "Пороги качества",
	fading = "Время исчезновения строк (в секундах)",
	details = "Подробности",
	test_settings = "Нажмите, чтобы проверить настройки",
	visible = "Якорь виден",
	show_crafted = "Созданное",
	show_system_coin = "Золото из системных сообщений",
	show_system_coin_desc = "Также показывать золото, о котором сообщается только системным сообщением (а не обычной добычей), например награды за локальные задания, золото за сдачу задания и кошельки с золотом (например, награда за гонки). Не зависит от фильтра денег.",
	show_totals = "Показывать общее число предметов в инвентаре",
	totals_delay = "Задержка итогов",
	totals_delay_desc = "Сколько ждать, прежде чем запрашивать у игры, сколько у вас предметов, так как события предметов не всегда точно совпадают со счётчиками инвентаря",
	use_altoholic = "Учитывать банк (Altoholic)",
	font_size_ilvl = "Уровень предмета",
	name_width = "Ширина имени игрока",
	gradients = "Градиенты",
	gradients_desc = "Добавляет мягкую градиентную заливку на фон каждой строки монитора. Только внешний вид. Для изменения требуется перезагрузка интерфейса.",
	quality_color = "Окрашивать строки по качеству предмета",
	quality_color_desc = "Окрашивать рамки строк добычи в цвет качества предмета. Выключите, чтобы использовать собственный цвет рамки, например цвет класса, чтобы совпадало с окном добычи.",
	monitor_color_border = "Цвет рамки строки",
	monitor_color_border_desc = "Цвет рамки строк добычи, когда окраска по качеству выключена.",
	color_all_rows = "Окрашивать все строки",
	color_all_rows_desc = "Также применять цвет рамки строк к строкам денег и валюты, а не только предметов, чтобы весь монитор выглядел единообразно.",
	quest_color = "Окрашивать предметы для заданий",
	quest_color_desc = "Окрашивает название и рамку предметов для заданий в ленте добычи, чтобы они выделялись, так же, как это делает окно добычи. Охватывает как предметы типа «Задания», так и обычные предметы, которые нужны для ваших активных заданий, и заменяет окраску по качеству в этих строках. Окрашивается только ваша добыча и только предметы, прошедшие через окно добычи — награда за задание, выданная прямо в сумки, не окрашивается. Предметы для заданий показываются, даже если их качество ниже порогов выше, поэтому функция работает и в профиле по умолчанию.",
	quest_color_class = "Использовать цвет моего класса",
	quest_color_class_desc = "Окрашивать предметы для заданий в цвет вашего класса вместо цвета, заданного в «Цвет предметов для заданий».",
	monitor_color_quest = "Цвет предметов для заданий",
	monitor_color_quest_desc = "Цвет, в который окрашиваются предметы для заданий в ленте добычи. Используется, только когда включено «Окрашивать предметы для заданий» и выключено «Использовать цвет моего класса».",
	rightclick_dismiss = "ПКМ, чтобы убрать строки",
	rightclick_dismiss_desc = "Щелчок правой кнопкой по строке монитора убирает её раньше, чем она исчезнет сама. Оставшиеся строки сдвигаются вверх, закрывая промежуток.",
	blizzard_alerts = "Оповещения о добыче Blizzard",
	suppress_loot_toasts = "Скрывать всплывающие окна добычи Blizzard",
	suppress_loot_toasts_desc = "Подавляет стандартные всплывающие уведомления о добыче Blizzard, которые выезжают при получении предмета, денег, улучшения или легендарного предмета (те блоки, что видны при открытии множества сундуков). Монитор добычи XLoot по-прежнему показывает всё, а оповещения не о добыче, такие как достижения, рецепты, питомцы, транспорт и честь PvP, не затрагиваются. По умолчанию выключено. Вступает в силу сразу, перезагрузка не нужна.",
	currency_cap = "Предупреждение о лимите",
	currency_cap_desc = "Помечать строку валюты тегом (лимит) или (недельный лимит), когда вы достигаете предела этой валюты, чтобы вы знали, что дальнейшие прибавки пропадут впустую. У валют без предела тега нет.",
	show_reputation_desc = "Показывать получаемую репутацию, например «+250 Хранители Времени». Новые прибавки к той же фракции суммируются в её строке, пока она ещё на экране. Использует цвет, которым ваше окно чата показывает сообщения о репутации.",
	show_reputation_loss = "Потеря репутации",
	show_reputation_loss_desc = "Также показывать потерю репутации красным цветом, например отношение с фракцией «Пираты Кровавого Паруса», которое вы теряете за убийство пиратов.",
	show_xp_desc = "Показывать получаемый опыт из любого источника: убийств, заданий, исследования и сбора ресурсов. Прибавки суммируются в одной строке, пока она ещё на экране. Использует цвет, которым ваше окно чата показывает сообщения об опыте.",
	show_honor_desc = "Показывать получаемую честь за почётные победы и награды в PvP. Прибавки суммируются в одной строке, пока она ещё на экране. Использует цвет, которым ваше окно чата показывает сообщения о чести.",
	show_skill = "Повышение навыков",
	show_skill_desc = "Показывать новый уровень навыка при его повышении, например «Снятие шкур (51)». Для каждого навыка остаётся одна строка, которая обновляется, пока она ещё на экране. Использует цвет, которым ваше окно чата показывает сообщения о навыках.",
}
locales.ruRU.Toast = {
	panel_title = "Уведомления о добыче",
	testing = "Проверка",
	anchor = "Якорь",
	filtering = "Что показывать",
	behavior = "Поведение",
	blizzard = "Оповещения Blizzard",
	mouse = "Мышь",
	font = "Шрифт",
	enabled = "Включить уведомления о добыче",
	enabled_desc = "Показывать всплывающее уведомление в стиле Blizzard при получении заметной добычи. По умолчанию выключено, поэтому ничего не изменится, пока вы не включите. Уведомления появляются у перемещаемого якоря и исчезают сами.",
	test_settings = "Нажмите для предпросмотра уведомлений",
	visible = "Якорь виден",
	threshold = "Минимальное качество",
	threshold_desc = "Показывать уведомление только для добычи такого или более высокого качества, чтобы обычные предметы не засоряли экран. Предметы для заданий можно показывать отдельно ниже.",
	quest = "Предметы для заданий",
	quest_desc = "Также показывать уведомления о предметах для заданий, даже если их качество ниже минимального.",
	ilvl = "Показывать уровень предмета",
	ilvl_desc = "Добавляет уровень предмета перед названием у экипировки.",
	max_active = "Максимум на экране",
	max_active_desc = "Сколько уведомлений может быть показано одновременно. Остальная добыча ждёт в очереди и появляется по мере исчезновения старых уведомлений.",
	fadeout_delay = "Время на экране",
	fadeout_delay_desc = "Сколько секунд уведомление остаётся на экране до исчезновения. Наведение курсора приостанавливает исчезновение.",
	vfx = "Анимация появления",
	vfx_desc = "Проигрывать эффект свечения и блеска при появлении уведомления. Выключите для простого плавного появления.",
	sfx = "Звук",
	sfx_desc = "Проигрывать звук при появлении уведомления; для легендарных предметов звук особый.",
	hide_blizzard = "Скрывать дублирующее уведомление Blizzard",
	hide_blizzard_desc = "Подавляет стандартные всплывающие уведомления о добыче Blizzard, чтобы рядом с уведомлениями XLoot не было дубликата: они выезжают при получении предмета, денег, улучшения или легендарного предмета. По умолчанию включено, пока включены уведомления о добыче. Оповещения не о добыче, такие как достижения, рецепты, питомцы, транспорт и честь PvP, не затрагиваются. Вступает в силу сразу, перезагрузка не нужна.",
	mouse_hover = "Подсказка при наведении",
	mouse_hover_desc = "Показывать подсказку предмета при наведении мыши на уведомление и приостанавливать его исчезновение, пока курсор над ним.",
	mouse_click_mode = "Клики",
	mouse_click_mode_desc = "Как уведомления реагируют на клики. «Всегда» — уведомления кликабельны, но могут перехватывать клики, предназначенные для интерфейса под ними. «Только с зажатым Shift» пропускает обычные левые клики к тому, что находится позади, при этом ПКМ по-прежнему закрывает уведомление, а Shift+клик по-прежнему отправляет ссылку. «Никогда» пропускает все клики. Якорь можно перетаскивать во всех режимах.",
	click_always = "Всегда",
	click_modifier = "Только с зажатым Shift",
	click_never = "Никогда (пропускать клики)",
	color_border = "Окрашивать рамку по качеству",
	color_border_desc = "Окрашивает рамку уведомления в цвет качества предмета.",
	color_icon_border = "Окрашивать рамку значка по качеству",
	color_icon_border_desc = "Окрашивает рамку значка в цвет качества предмета.",
	color_name = "Окрашивать название по качеству",
	color_name_desc = "Окрашивает текст названия предмета в цвет качества.",
	color_threshold = "Окрашивать только от качества",
	color_threshold_desc = "Применять окраску по качеству только к добыче такого или более высокого качества.",
	font_flag = "Контур шрифта",
	font_size = "Размер шрифта",
}
locales.ruRU.Master = {
	panel_title = "Ответственный за добычу",
	specialrecipients = "Меню особых получателей",
	raidroll = "Меню особых бросков",
	awardannounce = "Объявлять распределение предметов",
	confirm_qualitythreshold = "Минимальное качество для подтверждения",
	confirm_qualitythreshold_desc = "Для предметов такого или более высокого качества перед передачей запрашивается подтверждение. «Никогда» пропускает запрос для всего, включая эпические и легендарные предметы.",
	menu_roll = "Показывать рейдовый бросок",
	menu_disenchant = "Показывать распылителя",
	menu_disenchanters = "Имена персонажей-распылителей",
	menu_bank = "Показывать банкира",
	menu_bankers = "Имена персонажей-банкиров",
	menu_self = "Показывать себя",
	award_qualitythreshold = "Минимальное качество",
	award_qualitythreshold_desc = "Объявлять передачу только для предметов такого или более высокого качества. «Всегда» объявляет каждую передачу, «Никогда» отключает объявления.",
	award_channel = "Канал объявлений",
	award_channel_desc = "Канал чата, в который отправляются объявления о передаче. «Максимально доступный» использует самый широкий групповой канал, в который вы можете писать.",
	award_channel_secondary = "Дополнительный канал",
	award_channel_secondary_desc = "Необязательный второй канал, в который тоже отправляются объявления о передаче. Выберите «Нет», чтобы отключить.",
	award_guildannounce = "Дублировать в чат гильдии",
	award_special = "Объявлять особых получателей",
}

locales.koKR["alpha"] = "투명도"
locales.koKR["down"] = "아래"
locales.koKR["font"] = "글꼴"
locales.koKR["font_size_loot"] = "전리품"
locales.koKR["font_size_quantity"] = "수량"
locales.koKR["font_sizes"] = "크기"
locales.koKR["growth_direction"] = "확장 방향"
locales.koKR["minimum_quality"] = "최소 품질"
locales.koKR["profile"] = "프로필"
locales.koKR["scale"] = "크기 비율"
locales.koKR["up"] = "위"
locales.koKR["visible"] = "보기"
locales.koKR["when_always"] = "항상"
locales.koKR["when_auto"] = "자동"
locales.koKR["when_group"] = "그룹에서"
locales.koKR["when_never"] = "안 함"
locales.koKR["when_party"] = "파티에서"
locales.koKR["when_raid"] = "공격대에서"
locales.koKR["when_solo"] = "혼자일 때"
locales.koKR["width"] = "너비"
locales.koKR["enter_to_save"] = "입력한 값을 저장하려면 Enter를 누르세요."
locales.koKR["font_flag"] = "외곽선"
locales.koKR["font_flag_outline"] = "외곽선"
locales.koKR["font_flag_thickoutline"] = "두꺼운 외곽선"
locales.koKR["font_flag_monochrome"] = "단색"
locales.koKR["items_others"] = "다른 플레이어의 아이템"
locales.koKR["items_own"] = "내 아이템"
locales.koKR["desc_channel_auto"] = "사용 가능한 최상위 채널"
locales.koKR["alignment"] = "정렬"
locales.koKR["spacing"] = "간격"
locales.koKR["offset"] = "위치 보정"
locales.koKR["padding"] = "안쪽 여백"
locales.koKR["left"] = "왼쪽"
locales.koKR["right"] = "오른쪽"
locales.koKR["top"] = "위쪽"
locales.koKR["bottom"] = "아래쪽"
locales.koKR["whatsnew_mode_popup"] = "팝업 창"
locales.koKR["whatsnew_mode_chat"] = "채팅 링크"
locales.koKR["whatsnew_mode_none"] = "없음"
locales.koKR["profile_transfer"] = "설정 공유"
locales.koKR["profile_export"] = "내보내기"
locales.koKR["profile_import"] = "가져오기"
locales.koKR["export_title"] = "XLoot 설정 내보내기"
locales.koKR["export_count"] = "프로필 |cffffd200%s|r: 기본값에서 변경된 설정 %d개"
locales.koKR["export_empty"] = "프로필 |cffffd200%s|r은 기본 설정만 사용합니다."
locales.koKR["export_help"] = "Ctrl+C로 아래 문자열을 복사한 뒤 다른 클라이언트의 가져오기에 붙여넣으세요."
locales.koKR["export_failed"] = "XLoot 설정 문자열을 생성하지 못했습니다."
locales.koKR["import_title"] = "XLoot 설정 가져오기"
locales.koKR["import_help"] = "XLoot에서 내보낸 설정 문자열을 붙여넣으세요. 아래 버튼을 누르기 전까지 설정은 변경되지 않습니다."
locales.koKR["import_summary"] = "출처: %s, 프로필 |cffffd200%s|r, 기본값에서 변경된 설정 %d개"
locales.koKR["import_invalid"] = "XLoot 설정 문자열이 아니거나 일부 내용이 누락되었습니다."
locales.koKR["import_newer"] = "더 최신 버전의 XLoot에서 내보낸 문자열입니다. XLoot를 업데이트한 뒤 다시 시도하세요."
locales.koKR["import_name"] = "새 프로필 이름"
locales.koKR["import_new"] = "새 프로필로 가져오기"
locales.koKR["import_replace"] = "현재 프로필 덮어쓰기"
locales.koKR["import_name_missing"] = "새 프로필 이름을 입력하세요."
locales.koKR["import_name_taken"] = "|cffffd200%s|r 프로필이 이미 있습니다."
locales.koKR["import_replace_confirm"] = "프로필 |cffffd200%s|r의 모든 XLoot 설정을 가져온 설정으로 덮어쓸까요?\n\n이 작업은 되돌릴 수 없습니다."
locales.koKR["import_profile_changed"] = "현재 프로필이 변경되어 덮어쓰지 않았습니다."
locales.koKR["import_done"] = "프로필 |cffffd200%s|r에 설정을 가져왔습니다."
locales.koKR["import_missing"] = "현재 로드되지 않아 제외한 모듈: %s"
locales.koKR["import_dropped"] = "이 게임 버전에서 지원하지 않아 제외한 설정: %d개"
locales.koKR["import_rules_skipped"] = "같은 게임 버전에서만 이전할 수 있어 제외한 자동 주사위 규칙: %d개"
locales.koKR["import_offscreen"] = "화면 밖에 배치되어 기본 위치를 유지한 창: %d개"
locales.koKR["import_reload"] = "모든 설정을 적용하려면 /reload를 입력하세요."
locales.koKR["game_unknown"] = "알 수 없음"
locales.koKR["profile_export_desc"] = "다른 게임 버전, 계정 또는 컴퓨터의 XLoot로 복사할 설정 문자열을 표시합니다. 현재 로드된 모든 XLoot 모듈에서 이 프로필의 기본값과 다른 설정을 포함합니다."
locales.koKR["profile_import_desc"] = "XLoot에서 내보낸 설정 문자열을 새 프로필 또는 현재 프로필에 적용합니다. 창 위치는 현재 화면에 맞게 조정하며 자동 주사위 규칙은 같은 게임 버전 사이에서만 이전합니다."
locales.koKR["message_reloadui_warning"] = "|c2244dd22%s|r: |c2244dd22%s|r 변경 사항을 적용하려면 인터페이스를 다시 불러오세요: |c2244dd22/reload ui|r"
locales.koKR.Core = {}
locales.koKR.Core["panel_title"] = "공통 설정"
locales.koKR.Core["details"] = "스킨은 모든 XLoot 모듈에 적용됩니다. 그 밖의 설정 대부분은 /reload 후 적용됩니다. 문제가 있으면 제보해 주세요. 개별 모듈은 일반 애드온처럼 비활성화할 수 있습니다."
locales.koKR.Core["skin"] = "스킨"
locales.koKR.Core["skin_desc"] = "사용할 스킨을 선택합니다. Masque 스킨도 포함됩니다."
locales.koKR.Core["skin_anchors"] = "위치 조절 손잡이에 스킨 적용"
locales.koKR.Core["skin_anchors_desc"] = "XLoot 위치 조절 손잡이에 스킨을 적용합니다."
locales.koKR.Core["tooltip_sell"] = "툴팁에 상점 판매 가격 표시"
locales.koKR.Core["tooltip_sell_desc"] = "아이템 툴팁에 상점 판매 가격과 묶음 전체 가격(예: 20 x 6실버)을 추가합니다. 모든 아이템 툴팁에 적용됩니다."
locales.koKR.Core["value_coin_icons"] = "동전 아이콘"
locales.koKR.Core["value_coin_icons_desc"] = "금액을 글자 대신 금화, 은화, 동화 아이콘으로 표시합니다. 전리품 창과 기록의 획득 금액, 항목 판매 가격, 클래식 툴팁 판매 가격에 적용됩니다. 기본값은 꺼짐입니다."
locales.koKR.Core["minimap_icon"] = "미니맵 아이콘"
locales.koKR.Core["minimap_icon_desc"] = "미니맵에 XLoot 동전 버튼을 표시합니다. 좌클릭으로 설정, 우클릭으로 업데이트 내용을 열고 Shift+클릭으로 빠른 자동 획득을 전환합니다. 드래그하여 위치를 바꿀 수 있습니다. 이 설정과 관계없이 Titan Panel, ChocolateBar, ElvUI 등의 브로커 표시를 지원합니다. 기본값은 꺼짐입니다."
locales.koKR.Core["whatsnew_show"] = "업데이트 내용 보기"
locales.koKR.Core["whatsnew_show_desc"] = "현재 버전의 업데이트 내용을 다시 엽니다."
locales.koKR.Core["whatsnew_mode"] = "업데이트 후 알림 방식"
locales.koKR.Core["whatsnew_mode_desc"] = "업데이트 후 팝업을 자동으로 열거나 채팅에 클릭 가능한 링크를 표시하거나 알리지 않도록 선택합니다."
locales.koKR.Core["reset_defaults"] = "기본값으로 초기화"
locales.koKR.Core["reset_defaults_desc"] = "현재 프로필의 모든 XLoot 설정을 기본값으로 되돌립니다."
locales.koKR.Core["discord"] = "Discord 커뮤니티 참여"
locales.koKR.Core["discord_desc"] = "복사할 수 있는 XLoot Discord 커뮤니티 초대 링크를 엽니다."
locales.koKR.Core["module_header"] = "모듈 설정"
locales.koKR.Frame = {}
locales.koKR.Frame["panel_title"] = "전리품 창"
locales.koKR.Frame["panel_desc"] = "크기와 모양을 조절할 수 있는 전리품 창을 제공합니다."
locales.koKR.Frame["frame_options"] = "창 설정"
locales.koKR.Frame["slot_options"] = "전리품 항목"
locales.koKR.Frame["link_button"] = "전체 링크 버튼"
locales.koKR.Frame["autolooting"] = "자동 획득"
locales.koKR.Frame["colors"] = "색상"
locales.koKR.Frame["autoloot_currency"] = "화폐 자동 획득"
locales.koKR.Frame["autoloot_currency_desc"] = "화폐를 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_quest"] = "퀘스트 아이템 자동 획득"
locales.koKR.Frame["autoloot_quest_desc"] = "퀘스트 아이템을 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_tradegoods"] = "전문 기술 재료 자동 획득"
locales.koKR.Frame["autoloot_tradegoods_desc"] = "전문 기술 재료 유형의 아이템을 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_gear"] = "장비 자동 획득"
locales.koKR.Frame["autoloot_gear_desc"] = "착용 가능한 방어구와 무기를 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_gear_quality"] = "장비 최소 품질"
locales.koKR.Frame["autoloot_gear_quality_desc"] = "이 품질 이상의 장비만 자동으로 획득합니다. 하급은 모든 장비를 포함합니다."
locales.koKR.Frame["autoloot_gear_minlevel"] = "장비 최소 아이템 레벨"
locales.koKR.Frame["autoloot_gear_minlevel_desc"] = "이 아이템 레벨 이상의 장비만 자동으로 획득합니다. 0이면 레벨을 확인하지 않습니다."
locales.koKR.Frame["autoloot_value"] = "가격 기준 자동 획득"
locales.koKR.Frame["autoloot_value_desc"] = "최소 판매 가격 이상의 아이템을 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_value_minprice"] = "최소 판매 가격(골드)"
locales.koKR.Frame["autoloot_value_minprice_desc"] = "획득할 묶음의 상점 판매 총액이 이 골드 이상일 때만 자동으로 획득합니다. 0이면 판매 가능한 모든 아이템을 포함합니다."
locales.koKR.Frame["autoloot_quality"] = "품질 기준 자동 획득"
locales.koKR.Frame["autoloot_quality_desc"] = "유형에 관계없이 아래 최소 품질 이상의 아이템을 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_quality_min"] = "최소 품질"
locales.koKR.Frame["autoloot_quality_min_desc"] = "이 품질 이상의 아이템만 자동으로 획득합니다. 하급이면 모두 포함합니다."
locales.koKR.Frame["autoloot_all"] = "모든 전리품 자동 획득"
locales.koKR.Frame["speedy_autoloot"] = "빠른 자동 획득"
locales.koKR.Frame["speedy_autoloot_desc"] = "전리품 창을 표시하지 않고 전리품이 준비되는 즉시 서버 처리 주기마다 하나씩 획득합니다. 대량 획득 시 접속 종료를 방지하도록 간격을 둡니다. 기본값은 꺼짐입니다. 필터에 맞는 아이템만 획득하는 옵션을 켜지 않으면 아래 필터를 무시합니다. 자동 획득 전환 보조키를 누르면 해당 획득에서는 일반 창을 엽니다. /xlspeedy, XLoot 단축키 또는 미니맵 아이콘 Shift+클릭으로 전환할 수 있습니다."
locales.koKR.Frame["speedy_autoloot_respect_filters"] = "필터에 맞는 아이템만 빠르게 획득"
locales.koKR.Frame["speedy_autoloot_respect_filters_desc"] = "아래 자동 획득 필터에 맞는 아이템만 창 표시 없이 간격을 두고 획득합니다. 나머지는 전리품 창에 표시됩니다."
locales.koKR.Frame["speedy_autoloot_skip_fishing"] = "낚시 전리품은 빠른 자동 획득에서 제외"
locales.koKR.Frame["speedy_autoloot_skip_fishing_desc"] = "낚시에서는 일반 전리품 창을 엽니다. 낚시 기록 애드온이 물고기를 확인하기 전에 빠른 자동 획득이 찌를 비울 수 있으므로 기록이 누락되면 켜세요. 다른 전리품에는 영향을 주지 않습니다."
locales.koKR.Frame["autoloot_list"] = "목록의 아이템 자동 획득"
locales.koKR.Frame["autoloot_list_desc"] = "목록에 등록된 아이템을 자동으로 획득할 조건입니다."
locales.koKR.Frame["autoloot_item_list"] = "획득할 아이템"
locales.koKR.Frame["frame_color_border"] = "창 테두리 색상"
locales.koKR.Frame["frame_color_backdrop"] = "창 배경 색상"
locales.koKR.Frame["frame_color_gradient"] = "창 그라데이션 색상"
locales.koKR.Frame["frame_width_automatic"] = "창 너비 자동 확장"
locales.koKR.Frame["frame_width"] = "창 너비"
locales.koKR.Frame["old_close_button"] = "이전 닫기 버튼 사용"
locales.koKR.Frame["loot_highlight"] = "마우스를 올린 항목 강조"
locales.koKR.Frame["loot_color_border"] = "전리품 테두리 색상"
locales.koKR.Frame["loot_color_backdrop"] = "전리품 배경 색상"
locales.koKR.Frame["loot_color_gradient"] = "전리품 그라데이션 색상"
locales.koKR.Frame["loot_color_info"] = "상세 정보 글자 색상"
locales.koKR.Frame["loot_color_quest"] = "퀘스트 아이템 색상"
locales.koKR.Frame["loot_color_quest_desc"] = "퀘스트 아이템 색상 적용이 켜져 있고 내 직업 색상 사용이 꺼져 있을 때 사용할 색상입니다."
locales.koKR.Frame["loot_collapse"] = "획득한 항목의 빈 공간 정리"
locales.koKR.Frame["loot_icon_size"] = "전리품 아이콘 크기"
locales.koKR.Frame["loot_row_height"] = "전리품 항목 높이"
locales.koKR.Frame["quality_color_frame"] = "최고 품질에 따라 창 테두리 색상 적용"
locales.koKR.Frame["quality_color_slot"] = "품질에 따라 전리품 테두리 색상 적용"
locales.koKR.Frame["quest_color_slot"] = "퀘스트 아이템 색상 적용"
locales.koKR.Frame["quest_color_slot_desc"] = "퀘스트 유형 아이템과 진행 중인 퀘스트에서 요구하는 일반 아이템의 이름과 테두리에 별도 색상을 적용합니다. 해당 항목의 품질 색상보다 우선합니다."
locales.koKR.Frame["quest_color_class"] = "내 직업 색상 사용"
locales.koKR.Frame["quest_color_class_desc"] = "퀘스트 아이템에 지정 색상 대신 내 직업 색상을 적용합니다."
locales.koKR.Frame["loot_texts_info"] = "상세 정보 표시"
locales.koKR.Frame["loot_texts_bind"] = "아이템 귀속 유형 표시"
locales.koKR.Frame["loot_texts_lock"] = "잠김 상태 표시"
locales.koKR.Frame["loot_texts_sell"] = "상점 판매 가격 표시"
locales.koKR.Frame["loot_texts_sell_desc"] = "각 전리품 항목에 해당 아이템 묶음의 상점 판매 총액을 표시합니다."
locales.koKR.Frame["loot_texts_newlook"] = "미수집 외형 표시"
locales.koKR.Frame["loot_texts_newlook_desc"] = "아직 어떤 출처에서도 수집하지 않은 형상변환 외형에 청록색 표시를 추가합니다. 본 서버 전용입니다."
locales.koKR.Frame["loot_texts_upgrade"] = "장비 향상 표시"
locales.koKR.Frame["loot_texts_upgrade_desc"] = "현재 같은 부위에 착용한 동일 무기·방어구 유형의 장비보다 아이템 레벨이 높으면 녹색 표시를 추가합니다."
locales.koKR.Frame["loot_buttons_auto"] = "자동 획득 추가 버튼"
locales.koKR.Frame["loot_buttons_auto_desc"] = "아이템을 아래 자동 획득 목록에 추가하는 버튼입니다. 해당 아이템이 자동 획득 대상일 때만 표시됩니다."
locales.koKR.Frame["font_size_info"] = "전리품 상세 정보"
locales.koKR.Frame["font_size_bottombuttons"] = "전체 링크/닫기"
locales.koKR.Frame["font_flag_loot"] = "글꼴 외곽선"
locales.koKR.Frame["font_flag_loot_desc"] = "전리품 창의 아이템 이름과 상세 정보 글자에 적용할 외곽선입니다."
locales.koKR.Frame["font_flag"] = "상세 글자 외곽선"
locales.koKR.Frame["font_flag_desc"] = "묶음 수량, 귀속 표시, 항목 버튼 등 작은 글자에 적용할 외곽선입니다."
locales.koKR.Frame["frame_snap"] = "마우스 위치에 창 표시"
locales.koKR.Frame["frame_snap_offset_x"] = "마우스 기준 가로 보정"
locales.koKR.Frame["frame_snap_offset_y"] = "마우스 기준 세로 보정"
locales.koKR.Frame["frame_grow_upwards"] = "위쪽으로 창 확장"
locales.koKR.Frame["frame_draggable"] = "전리품 창 드래그 허용"
locales.koKR.Frame["linkall_threshold"] = "최소 품질"
locales.koKR.Frame["linkall_threshold_desc"] = "이 품질 이상의 전리품만 링크합니다."
locales.koKR.Frame["linkall_channel"] = "링크 채널"
locales.koKR.Frame["linkall_channel_desc"] = "전리품 링크를 보낼 대화 채널입니다."
locales.koKR.Frame["linkall_channel_secondary"] = "추가 채널"
locales.koKR.Frame["linkall_channel_secondary_desc"] = "전리품 링크를 함께 보낼 추가 채널입니다. 없음으로 설정하면 사용하지 않습니다."
locales.koKR.Frame["linkall_show"] = "링크 버튼 표시 조건"
locales.koKR.Frame["linkall_first_only"] = "맨 위 아이템만 링크"
locales.koKR.Frame["linkall_auto"] = "창을 열 때 전리품 알림"
locales.koKR.Frame["linkall_auto_desc"] = "전리품 창을 열면 위 최소 품질에 맞는 아이템을 기본 링크 채널에 자동으로 알립니다. 각 전리품 출처는 한 번만 알립니다."
locales.koKR.Frame["autolooting_text"] = "이 영역은 게임 설정의 기본 자동 전리품 획득과 별개인 XLoot 자동 획득입니다. 전체 전리품을 빠르게 획득하거나 아래 필터에 맞는 아이템만 획득할 수 있습니다. 기본 자동 획득과 함께 사용하면 같은 전리품을 동시에 처리하여 대상이 사용 중이라는 무해한 경고가 생길 수 있으므로 둘 중 하나를 사용하세요."
locales.koKR.Frame["autolooting_list"] = "자동으로 획득할 아이템 이름을 쉼표로 구분하여 입력하세요.\n예: 리넨 옷감,파멸의 인도자,구리 광석"
locales.koKR.Frame["autolooting_details"] = "XLoot는 각 항목에 적용 가능한 가장 높은 획득 조건을 사용합니다. 예를 들어 혼자일 때는 모두 획득하고 그룹에서는 퀘스트 아이템과 돈만 획득하도록 설정할 수 있습니다."
locales.koKR.Frame["show_slot_errors"] = "획득 오류를 채팅에 표시"
locales.koKR.Frame["show_slot_errors_desc"] = "전리품을 표시하지 못하면 채팅으로 알립니다. 대부분의 메시지는 무시해도 됩니다."
locales.koKR.Group = {}
locales.koKR.Group["panel_title"] = "그룹 전리품"
locales.koKR.Group["testing"] = "시험 표시"
locales.koKR.Group["anchors"] = "위치 조절 손잡이"
locales.koKR.Group["rolls"] = "주사위 창"
locales.koKR.Group["roll_tracking"] = "표시할 주사위"
locales.koKR.Group["extra_info"] = "상세 정보"
locales.koKR.Group["expiration"] = "결과 표시 시간(초)"
locales.koKR.Group["test_settings"] = "클릭하여 설정 시험"
locales.koKR.Group["text_time"] = "남은 시간 표시"
locales.koKR.Group["text_time_desc"] = "아이템 아이콘 위에 주사위 선택까지 남은 시간을 초 단위로 표시합니다."
locales.koKR.Group["text_ilvl"] = "아이템 레벨 표시"
locales.koKR.Group["roll_highlight"] = "관심 아이템 주사위 강조"
locales.koKR.Group["roll_highlight_desc"] = "장비 향상 또는 미수집 외형인 아이템의 주사위 창 테두리 색상을 바꿉니다."
locales.koKR.Group["roll_highlight_upgrade"] = "아이템 레벨 향상"
locales.koKR.Group["roll_highlight_upgrade_desc"] = "현재 장비보다 아이템 레벨이 높으면 녹색 테두리를 사용합니다."
locales.koKR.Group["roll_highlight_newlook"] = "미수집 외형"
locales.koKR.Group["roll_highlight_newlook_desc"] = "수집하지 않은 외형이면 파란색 테두리를 사용합니다. 본 서버 전용입니다."
locales.koKR.Group["roll_urgency"] = "마감 임박 시 색상 변경"
locales.koKR.Group["roll_urgency_desc"] = "시간이 줄어들수록 주사위 타이머 막대가 붉어집니다."
locales.koKR.Group["auto_roll"] = "자동 주사위"
locales.koKR.Group["auto_roll_desc"] = "규칙이 있는 아이템에 자동으로 입찰, 차비 또는 포기를 선택합니다. 주사위 창의 버튼을 Shift+클릭하여 해당 아이템 규칙을 설정하거나 삭제합니다."
locales.koKR.Group["auto_roll_need"] = "자동 입찰 허용"
locales.koKR.Group["auto_roll_need_desc"] = "입찰도 자동으로 선택합니다. 기본값은 꺼짐이며 허용하기 전에는 자동 입찰하지 않습니다."
locales.koKR.Group["auto_roll_clear"] = "모든 규칙 삭제"
locales.koKR.Group["auto_roll_clear_desc"] = "저장된 자동 주사위 규칙을 모두 삭제합니다."
locales.koKR.Group["autoroll"] = "자동 주사위"
locales.koKR.Group["role_icon"] = "역할 아이콘 표시"
locales.koKR.Group["win_icon"] = "획득자의 선택 유형 아이콘 표시"
locales.koKR.Group["show_undecided"] = "선택하지 않은 플레이어 표시"
locales.koKR.Group["show_undecided_desc"] = "아직 주사위 유형을 선택하지 않은 플레이어 목록을 표시합니다."
locales.koKR.Group["roll_width"] = "주사위 창 너비"
locales.koKR.Group["roll_button_size"] = "주사위 버튼 크기"
locales.koKR.Group["roll_anchor_visible"] = "주사위 위치 조절 손잡이 표시"
locales.koKR.Group["roll_status"] = "주사위 결과 표시"
locales.koKR.Group["roll_status_desc"] = "게임의 전리품 기록을 바탕으로 선택한 플레이어와 획득자를 표시합니다. 버튼에 마우스를 올리면 선택한 사람과 주사위 값을 확인할 수 있습니다. 본 서버 전용입니다."
locales.koKR.Group["track_all"] = "모든 주사위 추적"
locales.koKR.Group["track_all_desc"] = "선택한 뒤에도 모든 주사위 창을 유지하여 진행 상황과 획득자를 확인합니다."
locales.koKR.Group["track_player_roll"] = "내가 참여한 주사위 추적"
locales.koKR.Group["track_player_roll_desc"] = "입찰 또는 차비를 선택한 창을 유지하여 결과를 확인합니다. 포기한 창은 유지하지 않습니다."
locales.koKR.Group["track_by_threshold"] = "최소 품질에 따라 추적"
locales.koKR.Group["track_by_threshold_desc"] = "아래 품질 이상의 아이템만 선택 후에도 주사위 창을 유지합니다."
locales.koKR.Group["expire_won"] = "획득한 주사위"
locales.koKR.Group["expire_won_desc"] = "아이템을 획득한 뒤 주사위 창을 유지할 시간(초)입니다."
locales.koKR.Group["expire_lost"] = "미획득/포기한 주사위"
locales.koKR.Group["expire_lost_desc"] = "획득하지 못했거나 포기한 뒤 주사위 창을 유지할 시간(초)입니다."
locales.koKR.Group["preview_show"] = "미리 보기"
locales.koKR.Group["equip_prefix"] = "착용 가능 여부 접두어 표시"
locales.koKR.Group["equip_prefix_desc"] = "착용 가능 여부와 장비 향상을 아이템 이름 앞에 표시합니다. 장비 향상 접두어는 Pawn 애드온이 필요합니다."
locales.koKR.Group["prefix_equippable"] = "착용 가능 접두어"
locales.koKR.Group["prefix_upgrade"] = "장비 향상 접두어"
locales.koKR.Monitor = {}
locales.koKR.Monitor["panel_title"] = "전리품 기록"
locales.koKR.Monitor["testing"] = "시험 표시"
locales.koKR.Monitor["anchor"] = "위치 조절 손잡이"
locales.koKR.Monitor["thresholds"] = "최소 표시 품질"
locales.koKR.Monitor["fading"] = "항목 표시 시간(초)"
locales.koKR.Monitor["details"] = "상세 정보"
locales.koKR.Monitor["test_settings"] = "클릭하여 설정 시험"
locales.koKR.Monitor["visible"] = "위치 조절 손잡이 표시"
locales.koKR.Monitor["show_crafted"] = "제작한 아이템"
locales.koKR.Monitor["show_system_coin"] = "시스템 메시지의 골드 획득"
locales.koKR.Monitor["show_system_coin_desc"] = "일반 전리품이 아닌 시스템 메시지로만 보고되는 골드도 표시합니다. 전역 퀘스트, 퀘스트 완료 보상, 보상 주머니 등이 해당하며 돈 필터와 별도로 적용됩니다."
locales.koKR.Monitor["currency_cap"] = "획득 한도 경고"
locales.koKR.Monitor["currency_cap_desc"] = "화폐 한도에 도달하면 한도 도달 또는 주간 한도 도달 표시를 추가하여 추가 획득분이 낭비됨을 알립니다. 한도가 없는 화폐에는 표시하지 않습니다."
locales.koKR.Monitor["show_reputation_desc"] = "획득한 평판을 표시합니다. 같은 세력의 항목이 화면에 있는 동안 추가 획득량을 합산합니다. 채팅창의 평판 메시지 색상을 사용합니다."
locales.koKR.Monitor["show_reputation_loss"] = "평판 감소"
locales.koKR.Monitor["show_reputation_loss_desc"] = "감소한 평판도 빨간색으로 표시합니다."
locales.koKR.Monitor["show_xp_desc"] = "처치, 퀘스트, 탐험, 채집 등 모든 출처의 획득 경험치를 표시합니다. 항목이 화면에 있는 동안 합산하며 채팅창의 경험치 메시지 색상을 사용합니다."
locales.koKR.Monitor["show_honor_desc"] = "명예 승수와 PvP 보상으로 획득한 명예를 표시합니다. 항목이 화면에 있는 동안 합산하며 채팅창의 명예 메시지 색상을 사용합니다."
locales.koKR.Monitor["show_skill"] = "숙련도 상승"
locales.koKR.Monitor["show_skill_desc"] = "무두질 (51)처럼 상승한 기술의 새 숙련도를 표시합니다. 기술마다 한 항목을 유지하여 갱신하며 채팅창의 기술 메시지 색상을 사용합니다."
locales.koKR.Monitor["show_totals"] = "가방의 아이템 총수 표시"
locales.koKR.Monitor["totals_delay"] = "총수 확인 지연"
locales.koKR.Monitor["totals_delay_desc"] = "아이템 이벤트와 실제 가방 수량이 일치하지 않을 수 있어 총수를 확인하기 전에 기다리는 시간입니다."
locales.koKR.Monitor["use_altoholic"] = "은행 포함(Altoholic)"
locales.koKR.Monitor["font_size_ilvl"] = "아이템 레벨"
locales.koKR.Monitor["name_width"] = "플레이어 이름 너비"
locales.koKR.Monitor["gradients"] = "그라데이션"
locales.koKR.Monitor["gradients_desc"] = "각 항목 배경에 부드러운 그라데이션을 적용합니다. 외형만 바뀌며 변경 후 인터페이스를 다시 불러와야 합니다."
locales.koKR.Monitor["quality_color"] = "아이템 품질에 따라 항목 색상 적용"
locales.koKR.Monitor["quality_color_desc"] = "아이템 품질에 따라 테두리 색상을 적용합니다. 끄면 직접 지정한 테두리 색상을 사용합니다."
locales.koKR.Monitor["monitor_color_border"] = "항목 테두리 색상"
locales.koKR.Monitor["monitor_color_border_desc"] = "품질에 따른 색상 적용을 껐을 때 사용할 테두리 색상입니다."
locales.koKR.Monitor["color_all_rows"] = "모든 항목에 색상 적용"
locales.koKR.Monitor["color_all_rows_desc"] = "지정한 테두리 색상을 아이템뿐 아니라 돈과 화폐 항목에도 적용합니다."
locales.koKR.Monitor["quest_color"] = "퀘스트 아이템 색상 적용"
locales.koKR.Monitor["quest_color_desc"] = "퀘스트 유형 아이템과 진행 중인 퀘스트에서 요구하는 일반 아이템의 이름과 테두리에 별도 색상을 적용합니다. 품질 색상보다 우선합니다. 내가 전리품 창을 통해 획득한 아이템만 해당하며 가방으로 바로 지급되는 퀘스트 보상은 제외합니다. 퀘스트 아이템은 최소 표시 품질보다 낮아도 표시합니다."
locales.koKR.Monitor["quest_color_class"] = "내 직업 색상 사용"
locales.koKR.Monitor["quest_color_class_desc"] = "퀘스트 아이템에 지정 색상 대신 내 직업 색상을 적용합니다."
locales.koKR.Monitor["monitor_color_quest"] = "퀘스트 아이템 색상"
locales.koKR.Monitor["monitor_color_quest_desc"] = "퀘스트 아이템 색상 적용이 켜져 있고 내 직업 색상 사용이 꺼져 있을 때 사용할 색상입니다."
locales.koKR.Monitor["rightclick_dismiss"] = "우클릭으로 항목 숨기기"
locales.koKR.Monitor["rightclick_dismiss_desc"] = "항목을 우클릭하면 표시 시간이 끝나기 전에 숨깁니다. 나머지 항목은 빈 공간을 채우도록 이동합니다."
locales.koKR.Monitor["blizzard_alerts"] = "기본 전리품 알림"
locales.koKR.Monitor["suppress_loot_toasts"] = "기본 전리품 팝업 숨기기"
locales.koKR.Monitor["suppress_loot_toasts_desc"] = "아이템, 돈, 장비 향상, 전설 아이템 획득 시 표시되는 기본 팝업을 숨깁니다. XLoot 전리품 기록은 유지하며 업적, 제조법, 애완동물, 탈것, PvP 명예 등 다른 알림은 유지합니다. 기본값은 꺼짐이며 즉시 적용됩니다."
locales.koKR.Toast = {}
locales.koKR.Toast["panel_title"] = "전리품 알림"
locales.koKR.Toast["testing"] = "시험 표시"
locales.koKR.Toast["anchor"] = "위치 조절 손잡이"
locales.koKR.Toast["filtering"] = "표시할 항목"
locales.koKR.Toast["behavior"] = "동작"
locales.koKR.Toast["blizzard"] = "기본 알림"
locales.koKR.Toast["mouse"] = "마우스"
locales.koKR.Toast["font"] = "글꼴"
locales.koKR.Toast["enabled"] = "전리품 알림 사용"
locales.koKR.Toast["enabled_desc"] = "주요 전리품을 획득하면 기본 UI 스타일의 팝업을 표시합니다. 기본값은 꺼짐입니다. 이동 가능한 손잡이 위치에 표시된 뒤 자동으로 사라집니다."
locales.koKR.Toast["test_settings"] = "클릭하여 알림 미리 보기"
locales.koKR.Toast["visible"] = "위치 조절 손잡이 표시"
locales.koKR.Toast["threshold"] = "최소 품질"
locales.koKR.Toast["threshold_desc"] = "이 품질 이상의 전리품만 알림을 표시합니다. 퀘스트 아이템은 아래에서 별도로 표시할 수 있습니다."
locales.koKR.Toast["quest"] = "퀘스트 아이템"
locales.koKR.Toast["quest_desc"] = "최소 품질보다 낮은 퀘스트 아이템도 알림을 표시합니다."
locales.koKR.Toast["ilvl"] = "아이템 레벨 표시"
locales.koKR.Toast["ilvl_desc"] = "장비 이름 앞에 아이템 레벨을 표시합니다."
locales.koKR.Toast["max_active"] = "화면에 표시할 최대 개수"
locales.koKR.Toast["max_active_desc"] = "동시에 표시할 알림 수입니다. 나머지는 대기열에서 기다렸다가 기존 알림이 사라지면 표시됩니다."
locales.koKR.Toast["fadeout_delay"] = "화면 표시 시간"
locales.koKR.Toast["fadeout_delay_desc"] = "알림이 사라지기 전까지 표시할 시간(초)입니다. 마우스를 올리면 사라짐이 일시 정지됩니다."
locales.koKR.Toast["vfx"] = "등장 효과"
locales.koKR.Toast["vfx_desc"] = "알림 등장 시 빛나는 효과를 표시합니다. 끄면 단순한 페이드 인을 사용합니다."
locales.koKR.Toast["sfx"] = "효과음"
locales.koKR.Toast["sfx_desc"] = "알림이 표시되면 소리를 재생합니다. 전설 아이템은 별도 소리를 사용합니다."
locales.koKR.Toast["hide_blizzard"] = "기본 전리품 알림 중복 표시 방지"
locales.koKR.Toast["hide_blizzard_desc"] = "XLoot 알림과 중복되는 기본 아이템·돈·장비 향상·전설 전리품 팝업을 숨깁니다. 전리품 알림 사용 시 기본값은 켜짐입니다. 업적, 제조법, 애완동물, 탈것, PvP 명예 알림은 유지하며 즉시 적용됩니다."
locales.koKR.Toast["mouse_hover"] = "마우스를 올리면 툴팁 표시"
locales.koKR.Toast["mouse_hover_desc"] = "알림에 마우스를 올리면 아이템 툴팁을 표시하고 사라짐을 일시 정지합니다."
locales.koKR.Toast["mouse_click_mode"] = "클릭 동작"
locales.koKR.Toast["mouse_click_mode_desc"] = "항상은 클릭을 받지만 뒤쪽 UI의 클릭을 가로챌 수 있습니다. Shift를 누를 때만은 일반 좌클릭을 뒤로 통과시키며 우클릭 숨기기와 Shift+클릭 링크는 유지합니다. 사용 안 함은 모든 클릭을 통과시킵니다. 위치 조절 손잡이는 모든 모드에서 드래그할 수 있습니다."
locales.koKR.Toast["click_always"] = "항상"
locales.koKR.Toast["click_modifier"] = "Shift를 누를 때만"
locales.koKR.Toast["click_never"] = "사용 안 함(클릭 통과)"
locales.koKR.Toast["color_border"] = "품질에 따라 테두리 색상 적용"
locales.koKR.Toast["color_border_desc"] = "아이템 품질 색상을 알림 테두리에 적용합니다."
locales.koKR.Toast["color_icon_border"] = "품질에 따라 아이콘 테두리 색상 적용"
locales.koKR.Toast["color_icon_border_desc"] = "아이템 품질 색상을 아이콘 테두리에 적용합니다."
locales.koKR.Toast["color_name"] = "품질에 따라 이름 색상 적용"
locales.koKR.Toast["color_name_desc"] = "아이템 품질 색상을 이름에 적용합니다."
locales.koKR.Toast["color_threshold"] = "색상 적용 최소 품질"
locales.koKR.Toast["color_threshold_desc"] = "이 품질 이상의 전리품에만 품질 색상을 적용합니다."
locales.koKR.Toast["font_flag"] = "글꼴 외곽선"
locales.koKR.Toast["font_size"] = "글꼴 크기"
locales.koKR.Master = {}
locales.koKR.Master["panel_title"] = "전리품 담당자"
locales.koKR.Master["specialrecipients"] = "특별 수령인 메뉴"
locales.koKR.Master["raidroll"] = "특별 주사위 메뉴"
locales.koKR.Master["awardannounce"] = "아이템 분배 알림"
locales.koKR.Master["confirm_qualitythreshold"] = "분배 확인 최소 품질"
locales.koKR.Master["confirm_qualitythreshold_desc"] = "이 품질 이상의 아이템을 분배하기 전에 확인합니다. 안 함은 영웅 및 전설 아이템을 포함하여 모든 확인을 생략합니다."
locales.koKR.Master["menu_roll"] = "공격대 주사위 표시"
locales.koKR.Master["menu_disenchant"] = "마력 추출 담당자 표시"
locales.koKR.Master["menu_disenchanters"] = "마력 추출 담당 캐릭터 이름"
locales.koKR.Master["menu_bank"] = "은행 보관 담당자 표시"
locales.koKR.Master["menu_bankers"] = "은행 보관 담당 캐릭터 이름"
locales.koKR.Master["menu_self"] = "내가 획득 표시"
locales.koKR.Master["award_qualitythreshold"] = "최소 품질"
locales.koKR.Master["award_qualitythreshold_desc"] = "이 품질 이상의 아이템 분배만 알립니다. 항상은 모든 분배를 알리며 안 함은 알림을 끕니다."
locales.koKR.Master["award_channel"] = "알림 채널"
locales.koKR.Master["award_channel_desc"] = "분배 알림을 보낼 채널입니다. 사용 가능한 최상위 채널은 현재 메시지를 보낼 수 있는 가장 넓은 그룹 채널을 사용합니다."
locales.koKR.Master["award_channel_secondary"] = "추가 채널"
locales.koKR.Master["award_channel_secondary_desc"] = "분배 알림을 함께 보낼 추가 채널입니다. 없음으로 설정하면 사용하지 않습니다."
locales.koKR.Master["award_guildannounce"] = "길드 채팅에도 알림"
locales.koKR.Master["award_special"] = "특별 수령인 분배 알림"

XLoot:Localize("Options", locales)
