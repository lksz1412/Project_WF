--[[---------------------------------------
	Loot button click hook
	- row: Loot row
	- button: Mouse button
	- handled: True if any previous caller acted on event

	Hook like this:
	local XLootButtonOnClick_Orig = XLootButtonOnClick
	function XLootButtonOnClick(row, button, handled)
		if not handled and thing_i_want_to_check then
			handled = true
			dostuff()
		end
		XLootButtonOnClick_Orig(row, button, handled)
	end
--]]---------------------------------------

-- Include QDKP2 compatibility by request
function XLootButtonOnClick(row, button, handled)
	if not handled
		and QDKP2_IsManagingSession
		and IsAltKeyDown()
		and button == 'LeftButton'
		and GetLootSlotLink(row.slot)
		and QDKP2_IsManagingSession()
		and row.quality > GetLootThreshold()
		and (not QDKP2_BidM_isBidding())
	then
		pcall(QDKP2_BidM_StartBid, row.item)
		if QDKP2GUI_Roster then
			QDKP2GUI_Roster:ChangeList('bid')
			QDKP2GUI_Roster:Show()
		end
		return true
	end
	return handled
end

local addon, L = XLoot:NewModule("Frame")

XLootFrame = CreateFrame("Frame", "XLootFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
XLootFrame.addon = addon
local XLootFrame = XLootFrame

local opt

local LOOT_SLOT_NONE = LOOT_SLOT_NONE or Enum.LootSlotType.None
local LOOT_SLOT_ITEM = LOOT_SLOT_ITEM or Enum.LootSlotType.Item
local LOOT_SLOT_MONEY = LOOT_SLOT_MONEY or Enum.LootSlotType.Money
local LOOT_SLOT_CURRENCY = LOOT_SLOT_CURRENCY or Enum.LootSlotType.Currency

local GetContainerNumFreeSlots = C_Container and C_Container.GetContainerNumFreeSlots or GetContainerNumFreeSlots
-- Gate on the flavor, not the field: Classic ships the same BagIndex enum but container 5 is a bank bag there. Counted apart from the family loop because the reagent bag reports family 0.
local REAGENT_BAG = XLoot.IS_RETAIL_ENGINE and Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag or nil
local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
local SendChatMessage, SafeSetFont = XLoot.SendChatMessage, XLoot.SafeSetFont
local issecret = issecretvalue

local print, wprint = print, print
local function xprint(text)
	wprint(('%s: %s'):format('|c2244dd22XLoot|r', tostring(text)))
end

local BIND_ON_NONE = 0
local BIND_ON_PICKUP = 1
local BIND_ON_EQUIP = 2
local function GetItemInfoTable(link)
	-- Variable names match wowpedia documentation
	local name, link, rarity, level, minLevel, type, subType, stackCount, equipLoc, fileDataID, itemSellPrice, itemClassID, itemSubClassID, bindType, expacID, itemSetID, isCraftingReagent = GetItemInfo(link)
	if not name then return nil end
	-- But table names match common usage
	return {
		name = name,
		link = link,
		quality = rarity,
		level = level,
		minLevel = minLevel,
		typeName = type, -- type and subType are localized
		subTypeName = subType,
		stackCount = stackCount,
		equipLoc = equipLoc,
		icon = fileDataID,
		sellPrice = itemSellPrice,
		typeID = itemClassID, -- class and subClass are not
		subTypeID = itemSubClassID,
		bindType = bindType, -- NONE|PICKUP|EQUIP|?
		-- expacID = expacID,
		-- itemSetID = itemSetID,
		isCraftingReagent = isCraftingReagent
	}
end

-- string.lower only folds ASCII, so map accented Latin and Cyrillic capitals to their UTF-8 lowercase too.
local fold_utf8 = {}
for c = 0x80, 0x9E do
	if c ~= 0x97 then fold_utf8['\195' .. string.char(c)] = '\195' .. string.char(c + 0x20) end
end
for c = 0x80, 0x8F do fold_utf8['\208' .. string.char(c)] = '\209' .. string.char(c + 0x10) end
for c = 0x90, 0x9F do fold_utf8['\208' .. string.char(c)] = '\208' .. string.char(c + 0x20) end
for c = 0xA0, 0xAF do fold_utf8['\208' .. string.char(c)] = '\209' .. string.char(c - 0x20) end
fold_utf8['\197\146'] = '\197\147'
fold_utf8['\197\184'] = '\195\191'

local function ListKey(name)
	return (name:lower():gsub('[\195\197\208][\128-\191]', fold_utf8))
end

local defaults = {
	profile = {
		frame_scale = 1.0,
		frame_alpha = 1.0,

		quality_color_frame = false,
		quality_color_slot = true,
		quest_color_slot = false,
		quest_color_class = false,

		loot_texts_info = true,
		loot_texts_bind  = true,
		loot_texts_lock = true,
		loot_texts_sell = false,
		loot_texts_newlook = false,
		loot_texts_upgrade = false,

		loot_buttons_auto = true,

		font = STANDARD_TEXT_FONT,
		font_size_loot = 12,
		font_size_info = 10,
		font_size_quantity = 10,
		font_size_bottombuttons = 10,
		font_size_button_auto = 8,
		font_flag = "OUTLINE",
		font_flag_loot = "",

		loot_icon_size = 34,
		loot_row_height = 30,

		loot_highlight = true,

		loot_alpha = 1.0,
		loot_collapse = false,

		frame_snap = true,
		frame_snap_offset_x = 0,
		frame_snap_offset_y = 0,
		frame_grow_upwards = false, -- Actually means "Snap to bottom item"

		loot_padding_top = 10,
		loot_padding_left = 10,
		loot_padding_right = 10,
		loot_padding_bottom = 10,

		frame_width_automatic = true,
		frame_width = 150,

		frame_position_x = GetScreenWidth()/2,
		frame_position_y = GetScreenHeight()/2,

		autoloots = {
			currency = 'never',
			tradegoods = 'never',
			quest = 'never',
			gear = 'never',
			value = 'never',
			quality = 'never',
			list = 'solo',
			all = 'never',
		},

		autoloot_item_list = '',

		autoloot_gear_quality = 0, -- Quality 0 - 6, Poor - Artifact
		autoloot_gear_minlevel = 0,
		autoloot_value_minprice = 0, -- Gold, sellPrice is copper (x10000)
		autoloot_quality_min = 2, -- Quality 0 - 6, inert until the 'quality' when-state leaves 'never'

		speedy_autoloot = false,
		speedy_autoloot_respect_filters = false,
		speedy_autoloot_skip_fishing = false,

		frame_draggable = true,

		linkall_threshold = 2, -- Quality from 0 - 6, Poor - Artifact
		linkall_channel = 'RAID',
		linkall_channel_secondary = 'NONE',
		linkall_show = 'group',
		linkall_first_only = false,
		linkall_auto = 'never',

		old_close_button = false,

		frame_color_border = { .5, .5, .5, 1 },
		frame_color_backdrop = { 0, 0, 0, .7 },
		frame_color_gradient = { .5, .5, .5, .3 },
		loot_color_border = { .5, .5, .5, 1 },
		loot_color_backdrop = { 0, 0, 0, .9 },
		loot_color_gradient = { .5, .5, .5, .4 },
		loot_color_info = { .5, .5, .5, 1 },
		loot_color_quest = { 1, .8, .1, 1 },
		loot_color_button_auto = { .4, .8, .4, .6 },

		show_slot_errors = true,
	}
}

function addon:OnInitialize()
	self:InitializeModule(defaults, XLootFrame)
	opt = self.db.profile
	XLootFrame.opt = opt
end

function addon:OnEnable()
	XLootFrame:RegisterEvent("LOOT_READY")
	XLootFrame:RegisterEvent("LOOT_OPENED")
	XLootFrame:RegisterEvent("LOOT_CLOSED")
	XLootFrame:RegisterEvent("LOOT_SLOT_CLEARED")
	XLootFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
	XLootFrame:RegisterEvent("GROUP_ROSTER_UPDATE")

	LootFrame:UnregisterEvent("LOOT_OPENED")
	LootFrame:UnregisterEvent("LOOT_CLOSED")
	LootFrame:UnregisterEvent("LOOT_SLOT_CLEARED")

	-- Register for escape close
	table.insert(UISpecialFrames, "XLootFrame")

	-- No MasterLooterFrame reattach: retail master loot is back (12.0.5, CN-realm-only) on the new ScrollBox/MenuUtil flow, not our old hook.
end

local preview_loot = {
	{ 52722, false, true, true },
	{ 31304, true, false, false },
	{ 37254, true, false, false },
	{ 13262, true, false, false },
	{ 15487, false, false, false }
}

local preview_currency = {
	828,
	-- 1728,
	-- 1767,
}

for i=1,#preview_loot do
	XLootTooltip:SetItemByID(preview_loot[i][1])
	GetItemInfo(preview_loot[i][1])
end

function addon:ApplyOptions(in_options)
	opt, XLootFrame.opt = self.opt, self.opt
	if XLootFrame.built then
		XLootFrame:UpdateAppearance()
		XLootFrame:Update(true)
	end
	XLootFrame:ParseAutolootList()
	-- A profile change also lands here. The preview only exists once the options panel has been shown, and a failed build leaves the global half-built.
	if in_options and XLootFakeFrame and XLootFakeFrame.built then
		local Fake = XLootFakeFrame
		Fake.opt = opt
		Fake:UpdateAppearance()
		local slot, max_width, max_quality = 0, 0, 0
		wipe(Fake.slots)
		for i,v in ipairs(preview_loot) do
			local t = GetItemInfoTable(v[1])
			if t then
				t.quantity = 1
				t.slotType = LOOT_SLOT_ITEM
				t.preview_upgrade = (i == #preview_loot)
				t.preview_quest = (i == 2)
				slot = slot + 1
				local row = Fake.rows[slot]
				row.item = t.link
				row.quality = t.quality
				Fake.slots[slot] = row
				max_width = math.max(max_width, row:Update(t))
				max_quality = math.max(max_quality, t.quality)
			end
		end
		if C_CurrencyInfo then
			for i,id in ipairs(preview_currency) do
				local c = C_CurrencyInfo.GetCurrencyInfo(id)
				if c and c.name then
					local row =  Fake.rows[slot+i]
					max_width = math.max(max_width, row:Update({
						name = c.name,
						icon = c.iconFileID,
						quality = c.quality,
						slotType = LOOT_SLOT_CURRENCY,
						quantity = 5,
					}))
					Fake.slots[slot+i] = row
				end
			end
		end
		Fake:SizeAndColor(max_width, max_quality)
	end
end

function addon:OnOptionsShow(panel)
	local frame = XLootFakeFrame
	if not frame then
		frame = CreateFrame('Frame', 'XLootFakeFrame', panel, BackdropTemplateMixin and "BackdropTemplate")
		frame.fake = true
		frame.opt = XLootFrame.opt
		self:BuildLootFrame(frame)
		frame:SetPoint('TOPLEFT', panel, 'TOPRIGHT', 25, 25)
		self:ApplyOptions(true)
	end
	frame:Show()
end

function addon:OnOptionsHide(panel)
	XLootFakeFrame:Hide()
end

local IsGroupState = {
	always = function() return true end,
	never = function() return false end,
	raid = IsInRaid,
	group = IsInGroup,
	party = function() return IsInGroup() and not IsInRaid() end,
	solo = function() return not IsInGroup() end
}

local LinkLoot, LinkDropdown
do
	local output = { }
	-- Map a configured channel to one valid for the current group, or nil to skip. RAID_WARNING is privilege-gated and blocks as a protected call if auto-sent without raid lead or assist, so downgrade it.
	local function ResolveChannel(channel)
		if channel == 'RAID_WARNING' then
			if IsInRaid() then
				return (UnitIsGroupLeader('player') or UnitIsGroupAssistant('player')) and 'RAID_WARNING' or 'RAID'
			end
			return IsInGroup() and 'PARTY' or nil
		elseif channel == 'RAID' then
			return IsInRaid() and 'RAID' or (IsInGroup() and 'PARTY' or nil)
		elseif channel == 'PARTY' or channel == 'INSTANCE_CHAT' then
			return IsInGroup() and channel or nil
		end
		return channel
	end

	function LinkLoot(channel, silent)
		local output, key, buffer = output, 1
		local sf = string.format
		wipe(output)

		if UnitExists('target') then
			local target_name = UnitName('target')
			if not (issecret and issecret(target_name)) then
				output[1] = sf('%s:', target_name)
			end
		end

		local linkthreshold, reached = opt.linkall_threshold

		local first_only = opt.linkall_first_only

		for i=1, GetNumLootItems() do
			if GetLootSlotType(i) == LOOT_SLOT_ITEM then
				local _, _, quantity, _, rarity = GetLootSlotInfo(i)
				local link = GetLootSlotLink(i)
				if not (issecret and (issecret(link) or issecret(rarity) or issecret(quantity))) and rarity >= linkthreshold then
					reached = true
					buffer = sf('%s%s%s', (output[key] and output[key].." " or ""), (quantity > 1 and quantity.."x" or ""), link)
					if strlen(buffer) > 255 then
						key = key + 1
						output[key] = (quantity > 1 and quantity.."x" or "")..link
					else
						output[key] = buffer
					end
					if opt.linkall_first_only then
						break
					end
				end
			end
		end

		if not reached then
			if not silent then
				xprint(L.linkall_threshold_missed)
			end
			return false
		end
		local primary = ResolveChannel(channel)
		local secondary = opt.linkall_channel_secondary ~= 'NONE' and ResolveChannel(opt.linkall_channel_secondary) or nil
		for k, v in pairs(output) do
			v = v:gsub("\n", " ")
			if primary then SendChatMessage(v, primary) end
			if secondary then SendChatMessage(v, secondary) end
			output[k] = nil
		end

		return true
	end


	local function Click(dropdown, channel)
		LinkLoot(channel)
	end

	LinkDropdown = CreateFrame('Frame', 'XLootLinkDropdown')
	LinkDropdown.displayMode = 'MENU'
	local channels = {
		{ 'SAY', CHAT_MSG_SAY },
		{ 'PARTY', CHAT_MSG_PARTY },
		{ 'RAID', CHAT_MSG_RAID },
		{ 'RAID_WARNING', CHAT_MSG_RAID_WARNING },
		{ 'GUILD', CHAT_MSG_GUILD },
		{ 'OFFICER', CHAT_MSG_OFFICER },
	}
	local info = { }
	LinkDropdown.initialize = function(self, level)
		for i, c in ipairs(channels) do
			wipe(info)
			info.text = c[2]
			info.arg1 = c[1]
			info.func = Click
			info.notCheckable = 1
			UIDropDownMenu_AddButton(info, 1)
		end
	end
end

-- Reopening a partially looted corpse fires LOOT_OPENED again, so remember every source GUID and only auto-announce windows that contain a new one.
local HasNewLootSources
do
	local announced, count = {}, 0
	local function MarkSources(...)
		local fresh = false
		for i = 1, select('#', ...), 2 do
			local guid = select(i, ...)
			if guid and not (issecret and issecret(guid)) and not announced[guid] then
				if count >= 1000 then
					wipe(announced)
					count = 0
				end
				announced[guid] = true
				count = count + 1
				fresh = true
			end
		end
		return fresh
	end

	function HasNewLootSources()
		if not GetLootSourceInfo then return true end
		local fresh = false
		for slot = 1, GetNumLootItems() do
			if MarkSources(GetLootSourceInfo(slot)) then
				fresh = true
			end
		end
		return fresh
	end
end

local function OnDragStart()
	if opt.frame_draggable then
		XLootFrame:StartMoving()
	end
end

local function OnDragStop()
	XLootFrame:StopMovingOrSizing()
	opt.frame_position_x = XLootFrame:GetLeft()
	opt.frame_position_y = opt.frame_grow_upwards and XLootFrame:GetBottom() or XLootFrame:GetTop()
end

local function AdjustFontstringSize(self)
	local text = self:GetText()
	self:SetHeight(self:GetStringHeight())
	self:SetText(text)
end

local function Darken(mult, ...)
	local r, g, b, a = ...
	if type(r) == 'table' then
		r, g, b, a = unpack(r)
	end
	return r * mult, g * mult, b * mult, a or 1
end

local function GetColor(self, key, mult)
	local skin, raw, default, t = self.skin, rawget(self.opt, key), defaults.profile[key]
	assert(default, "No default color specified for key " .. key)
	if raw and (raw[1] ~= default[1] or raw[2] ~= default[2] or raw[3] ~= default[3] or raw[4] ~= default[4]) then
		t = raw
	elseif skin[key] then
		t = skin[key]
	else
		t = default
	end
	if mult then
		return Darken(mult, t)
	end
	return unpack(t)
end

local function QuestColor(owner)
	if owner.opt.quest_color_class then
		return XLoot.MyClassColor()
	end
	return GetColor(owner, 'loot_color_quest')
end


local mouse_focus
local BuildRow
do
	---@class XLootFrameRow: Button
	---@field text_name FontString
	---@field text_info FontString
	---@field text_quantity FontString
	---@field text_bind FontString
	---@field text_locked FontString
	---@field text_sell FontString
	---@field text_button_auto FontString
	---@field button_auto Button
	---@field frame_item Frame
	---@field texture_item Texture
	---@field texture_bang Texture
	---@field i integer
	---@field owner Frame
	local RowPrototype = XLoot.NewPrototype()
	local function smalltext(text)
		text:SetDrawLayer'OVERLAY'
		text:SetHeight(10)
		text:SetJustifyH'LEFT'
		text.text = text
	end

	local function textpoints(text, item, row, x)
		text:SetPoint('LEFT', item, 'RIGHT', x, 0)
		text:SetPoint('RIGHT', row, 'RIGHT', -4, 0)
	end

	function RowPrototype:OffsetText(text, y)
		text:SetPoint('TOP', self, 0, y)
	end

	function RowPrototype:SetBorderColor(r, g, b, a)
		self:_SetBorderColor(r, g, b, a or 1)
		self.frame_item:SetBorderColor(r, g, b, a or 1)
	end

	do
		local function Row_ShowTooltip_Inner(self)
			local f
			local type = GetLootSlotType(self.slot)
			if type == LOOT_SLOT_ITEM then
				f = GameTooltip.SetLootItem
			elseif type == LOOT_SLOT_CURRENCY then
				f = GameTooltip.SetLootCurrency
			else
				return nil
			end
			GameTooltip:SetOwner(self, 'ANCHOR_TOPLEFT', 32, 0)
			f(GameTooltip, self.slot)
			CursorUpdate(self)
		end

		function RowPrototype:ShowTooltip()
			pcall(Row_ShowTooltip_Inner, self)
		end
	end

	function RowPrototype:HighlightEnter()
		if self._highlights then
			self.frame_item:ShowHighlight()
		end
	end

	function RowPrototype:HighlightLeave()
		if self._highlights then
			self.frame_item:HideHighlight()
		end
	end

	function RowPrototype:OnEnter()
		self:HighlightEnter(self)
		mouse_focus = self
		self:ShowTooltip()
	end

	function RowPrototype:OnLeave()
		mouse_focus = nil
		self:HighlightLeave(self)
		GameTooltip:Hide()
		ResetCursor()
	end

	function RowPrototype:OnClick(button)
		if not XLootButtonOnClick(self, button) then
			if IsModifiedClick() then
				HandleModifiedItemClick(GetLootSlotLink(self.slot))
			elseif LootButton_OnClick then
				-- Classic master loot: feeding our row to Blizzard's handler sets LootFrame.selected* so XLoot_Master's MasterLooterFrame_Show hook can award the slot.
				LootButton_OnClick(self, button)
			else
				StaticPopup_Hide("CONFIRM_LOOT_DISTRIBUTION")
				LootSlot(self.slot)
				if EventRegistry then EventRegistry:TriggerEvent("LootFrame.ItemLooted") end
			end
		end
	end

	function RowPrototype:Auto_OnClick(button)
		self:Hide()
		if issecret and issecret(self.parent.item_name) then return end
		XLootFrame:AddToAutolootList(self.parent.item_name)
		self.parent:OnClick(button)
	end

	function RowPrototype:Auto_OnEnter()
		GameTooltip:SetOwner(self, 'ANCHOR_TOPLEFT')
		GameTooltip:SetText(L.button_auto_tooltip)
		GameTooltip:Show()
		self.text:SetTextColor(Darken(2, self.parent.owner:GetColor('loot_color_button_auto')))
	end

	function RowPrototype:Auto_OnLeave()
		GameTooltip:Hide()
		self.text:SetTextColor(self.parent.owner:GetColor('loot_color_button_auto'))
	end

	function RowPrototype:Auto_OnShow()
		self.parent.text_name:SetPoint('RIGHT', self, 'LEFT')
	end

	function RowPrototype:Auto_OnHide()
		self.parent.text_name:SetPoint('RIGHT', self.parent, 'RIGHT', -6, 0)
	end

	local resize_texts = {'text_name', 'text_info'}
	function RowPrototype:UpdateAppearance()
		local owner, opt = self.owner, self.owner.opt

		self:SetPoint('LEFT', opt.loot_padding_left, 0)
		self:SetPoint('RIGHT', -opt.loot_padding_right, 0)

		self:SetBorderColor(owner:GetColor('loot_color_border'))
		self:SetBackdropColor(owner:GetColor('loot_color_backdrop', 0.7))
		self:SetGradientColor(owner:GetColor('loot_color_gradient'))
		self.frame_item:SetGradientColor(owner:GetColor('loot_color_gradient'))
		self.text_info:SetTextColor(owner:GetColor('loot_color_info'))
		self.text_button_auto:SetTextColor(owner:GetColor('loot_color_button_auto'))
		self:SetAlpha(opt.loot_alpha)


		SafeSetFont(self.text_name, opt.font, opt.font_size_loot, opt.font_flag_loot)
		SafeSetFont(self.text_info, opt.font, opt.font_size_info, opt.font_flag_loot)
		SafeSetFont(self.text_sell, opt.font, opt.font_size_info, opt.font_flag)
		SafeSetFont(self.text_quantity, opt.font, opt.font_size_quantity, opt.font_flag)
		SafeSetFont(self.text_bind, opt.font, 8, opt.font_flag)
		SafeSetFont(self.text_locked, opt.font, 9, opt.font_flag)
		self.text_locked:SetText(LOCKED) -- Can't set text until font is set
		SafeSetFont(self.text_button_auto, opt.font, opt.font_size_button_auto, opt.font_flag)
		self.text_button_auto:SetText(L.button_auto)
		self.button_auto:SetWidth(self.text_button_auto:GetStringWidth()+4)
		self.button_auto:SetHeight(self.text_button_auto:GetStringHeight()+4)

		for i=1,#resize_texts do
			local fontstring = self[resize_texts[i]]
			local text = fontstring:GetText()
			fontstring:SetText("A")
			AdjustFontstringSize(fontstring)
			fontstring:SetText(text)
		end

		self.frame_item:SetWidth(opt.loot_icon_size)
		self.frame_item:SetHeight(opt.loot_icon_size)
		self:SetHeight(opt.loot_row_height)

		owner.row_height = self:GetHeight() + owner.skin.row_spacing

		if opt.loot_highlight then
			if not self._highlights then
				owner:Highlight(self, 'row_highlight')
				owner:Highlight(self.frame_item, 'item_highlight')
			end
			self:SetHighlightColor(.8, .8, .8, .8)
			self.frame_item:SetHighlightColor(.8, .8, .8, .8)
		elseif self._highlights then
			self:SetHighlightColor(0, 0, 0, 0)
			self.frame_item:SetHighlightColor(0, 0, 0, 0)
		end

		self.layout = nil
	end

	local binds = {
		[1] = ('|cffff4422%s|r '):format(L.bind_on_pickup_short),
		[2] = ('|cff44ff44%s|r '):format(L.bind_on_equip_short),
		[3] = ('|cff2244ff%s|r '):format(L.bind_on_use_short),
		-- account = 'BoA'
	}

	local NEW_LOOK = (' |cff66ccff%s|r'):format(L.new_look)
	local UPGRADE = (' |cff1eff00%s|r'):format(L.upgrade)

	function RowPrototype:Update(slotData)
		local r, g, b, hex, is_quest, quest_colored
		local owner = self:GetParent()
		local opt = owner.opt
		local text_info, text_name, text_bind = '', '', ''
		self.item_name = slotData.name

		local layout = 'simple'
		if slotData.slotType == LOOT_SLOT_ITEM then
			r, g, b, hex = C_Item.GetItemQualityColor(slotData.quality or 0)

			-- Keep is_quest narrow. Widening it would recolor the legacy orange subtitle with the feature off.
			is_quest = slotData.questID or slotData.isQuestItem
			if opt.quest_color_slot and not slotData.secret
				and (is_quest or slotData.preview_quest or XLoot.IsQuestObjectiveItem(slotData.name)) then
				quest_colored = true
				r, g, b = QuestColor(owner)
				hex = XLoot.ColorToHex(r, g, b)
			end

			text_name = slotData.secret and slotData.name or ('|c%s%s|r'):format(hex, slotData.name)

			if opt.loot_texts_newlook and not slotData.secret and slotData.link and XLoot.IsNewAppearance(slotData.link) then
				text_name = text_name..NEW_LOOK
			end

			if opt.loot_texts_upgrade and (slotData.preview_upgrade or (not slotData.secret and slotData.link and XLoot.IsIlvlUpgrade(slotData.link))) then
				text_name = text_name..UPGRADE
			end

			if opt.loot_texts_info then
				local equip = slotData.typeName == ENCHSLOT_WEAPON and ENCHSLOT_WEAPON or slotData.equipLoc ~= '' and _G[slotData.equipLoc] or ''
				local itemtype = (slotData.subTypeName == 'Junk' and slotData.quality > 0) and MISCELLANEOUS or slotData.subTypeName
				if itemtype then
					text_info = ((type(equip) == 'string' and equip ~= '') and equip..', ' or '') .. itemtype
					layout = 'detailed'
				end
			end

			if opt.loot_texts_bind and slotData.bindType then
				text_bind = binds[slotData.bindType] or ''
			end

		else
			r, g, b = .4, .4, .4
			local copper = XLoot.opt.value_coin_icons and slotData.slotType == LOOT_SLOT_MONEY and not slotData.secret
				and XLoot.ParseCoinString(slotData.name, true)
			if copper and copper > 0 then
				text_name = XLoot.MoneyString(copper, true)
			else
				text_name = slotData.secret and slotData.name or slotData.name:gsub('\n', ', ')
			end
		end

		self.text_name:SetText(text_name)
		self.text_info:SetText(text_info)
		self.text_bind:SetText(text_bind)
		self.text_quantity:SetText(slotData.quantity > 1 and slotData.quantity or nil)
		if opt.loot_texts_sell and slotData.slotType == LOOT_SLOT_ITEM and slotData.sellPrice and slotData.sellPrice > 0 then
			self.text_sell:SetText(XLoot.MoneyString(slotData.sellPrice * slotData.quantity, XLoot.opt.value_coin_icons))
		else
			self.text_sell:SetText()
		end
		if quest_colored then
			self.text_info:SetTextColor(r, g, b)
		elseif is_quest then
			self.text_info:SetTextColor(1, .8, .1)
		else
			self.text_info:SetTextColor(owner:GetColor('loot_color_info'))
		end
		local name_width = self.text_name:GetStringWidth()

		self.texture_item:SetTexture(slotData.icon)
		if slotData.locked and opt.loot_texts_lock then
			self.text_locked:Show()
		else
			self.text_locked:Hide()
		end

		if self.layout ~= layout then
			self.layout = layout
			if layout == 'simple' then
				self.text_name:SetPoint('LEFT', self.frame_item, 'RIGHT', 2, 0)
			else
				self.text_name:SetPoint('LEFT', self.frame_item, 'RIGHT', 2, (self.text_info:GetHeight()/2))
			end
		end

		if quest_colored then
			self:SetBorderColor(r, g, b)
		elseif opt.quality_color_slot then
			self:SetBorderColor(Darken(owner.skin.color_mod, r, g, b))
		else
			-- Rows are pooled and clear() leaves borders alone, so this arm must always repaint.
			self:SetBorderColor(owner:GetColor('loot_color_border'))
		end

		if slotData.questID then
			self.texture_bang:Show()
		else
			self.texture_bang:Hide()
		end

		if opt.loot_buttons_auto and (self.owner.fake or (opt.autoloots.list ~= 'never' and slotData.slotType == LOOT_SLOT_ITEM and not slotData.secret and not self.owner.auto_items[ListKey(slotData.name)])) then
			self.button_auto:Show()
			name_width = name_width + self.button_auto:GetWidth() - 6
		else
			self.button_auto:Hide()
		end

		if self.i == 1 then
			self:SetPoint('TOP', 0, -opt.loot_padding_top)
		else
			self:SetPoint('TOP', owner.rows[self.i-1], 'BOTTOM', 0, owner.skin.row_offset)
		end

		self:Show()

		local info_width = self.text_info:GetStringWidth() + 2
		local sell_width = self.text_sell:GetStringWidth()
		if sell_width > 0 then
			info_width = info_width + sell_width + 8
		end
		return max(info_width, name_width)
	end

	function BuildRow(frame, i)
		local frame_name, opt, fake = frame:GetName()..'Button'..i, frame.opt, frame.fake
		local row = CreateFrame('Button', not fake and frame_name or nil, frame, BackdropTemplateMixin and "BackdropTemplate")
		local item = CreateFrame('Frame', nil, row)
		local button_auto = CreateFrame('Button', nil, row)
		local tex = item:CreateTexture(not fake and frame_name..'IconTexture' or nil, 'BACKGROUND')
		local bang = item:CreateTexture(nil, 'OVERLAY')
		row.owner = frame
		row.frame_item = item
		row.texture_item = tex
		row.texture_bang = bang
		row.button_auto = button_auto
		row.i = i

		frame:Skin(row)
		frame:Skin(item, 'item')

		-- Apply prototype after skin to override method
		RowPrototype:New(row)
		---@cast row XLootFrameRow

		local name = row:CreateFontString(not fake and frame_name..'Text' or nil)
		local info = row:CreateFontString()
		local bind = item:CreateFontString()
		local quantity = item:CreateFontString()
		local locked = item:CreateFontString()
		local auto = button_auto:CreateFontString()
		local sell = row:CreateFontString()
		row.text_name = name
		row.text_info = info
		row.text_bind = bind
		row.text_locked = locked
		row.text_quantity = quantity
		row.text_button_auto = auto
		row.text_sell = sell

		smalltext(name)
		smalltext(info)
		smalltext(bind)
		smalltext(locked)
		smalltext(quantity)
		smalltext(auto)
		smalltext(sell)
		name:SetPoint('RIGHT', row, 'RIGHT', -6, 0)
		info:SetPoint('TOPLEFT', name, 'BOTTOMLEFT', 8, 0)
		info:SetPoint('RIGHT', row, 'RIGHT', -4, 0)
		sell:SetPoint('BOTTOMRIGHT', row, 'BOTTOMRIGHT', -6, 3)
		sell:SetJustifyH('RIGHT')
		textpoints(name, item, row, 2)
		textpoints(info, item, row, 8)
		info:SetPoint('TOP', name, 'BOTTOM')
		bind:SetPoint('BOTTOMLEFT', 2, 2)
		quantity:SetPoint('BOTTOMRIGHT', -2, 2)
		quantity:SetJustifyH('RIGHT')
		locked:SetPoint('CENTER')
		locked:SetTextColor(1, .2, .1)
		auto:SetPoint('CENTER')

		item:SetPoint('LEFT', 0, 0)
		tex:SetPoint('TOPLEFT', 3, -3)
		tex:SetPoint('BOTTOMRIGHT', -3, 3)
		tex:SetTexCoord(.07,.93,.07,.93)
		bang:SetPoint('BOTTOMRIGHT')
		bang:SetWidth(16)
		bang:SetHeight(16)
		bang:SetTexture([[Interface\Minimap\ObjectIcons.blp]])
		bang:SetTexCoord(1/8, 2/8, 1/8, 2/8)

		button_auto:SetPoint('TOPRIGHT', -2, -4)
		button_auto:SetScript('OnEnter', row.Auto_OnEnter)
		button_auto:SetScript('OnLeave', row.Auto_OnLeave)
		button_auto:SetScript('OnShow', row.Auto_OnShow)
		button_auto:SetScript('OnHide', row.Auto_OnHide)
		button_auto.parent = row
		button_auto.text = auto

		if fake then
			row:RegisterForClicks()
			row:SetScript('OnEnter', row.HighlightEnter)
			row:SetScript('OnLeave', row.HighlightLeave)
		else
			row:RegisterForDrag('LeftButton')
			row:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
			row:SetScript('OnDragStart', OnDragStart)
			row:SetScript('OnDragStop', OnDragStop)
			row:SetScript('OnClick', row.OnClick)
			row:SetScript('OnEnter', row.OnEnter)
			row:SetScript('OnLeave', row.OnLeave)
			button_auto:RegisterForClicks('LeftButtonUp')
			button_auto:SetScript('OnClick', row.Auto_OnClick)
		end

		row:UpdateAppearance()

		return row
	end
end

do
	local FramePrototype = XLoot.NewPrototype()
	function FramePrototype:SnapToCursor()
		local x, y = GetCursorPosition()
		local f = self
		local s = f:GetEffectiveScale()

		if opt.frame_snap then
			if not f:IsShown() then
				x = (x / s) - 25
				local sWidth, fWidth, uWidth = GetScreenWidth(), f:GetWidth(), UIParent:GetWidth()
				if uWidth > sWidth then sWidth = uWidth end
				if x + fWidth > sWidth then x = sWidth - fWidth end
				if x < 0 then x = 0 end
				x = x + opt.frame_snap_offset_x
			else
				x = f:GetLeft() or x
			end

			y = (y / s) + 25 * (opt.frame_grow_upwards and -1 or 1)
			local sHeight, fHeight, uHeight = GetScreenHeight(), f:GetHeight(), UIParent:GetHeight()
			if uHeight > sHeight then sHeight = uHeight end
			if y > sHeight then y = sHeight end
			if y - fHeight < 0 then y = fHeight end
			y = y + opt.frame_snap_offset_y
		else
			x = opt.frame_position_x or x
			y = opt.frame_position_y or y
		end

		f:ClearAllPoints()
		f:SetPoint((opt.frame_grow_upwards and "BOTTOMLEFT" or "TOPLEFT"), UIParent, "BOTTOMLEFT", x, y)
	end

	-- function FramePrototype:SetAlpha(alpha)
	-- 	self.backdrop:SetAlpha(alpha)
	-- end


	function FramePrototype:LinkClick(button)
		if button == 'RightButton' then
			ToggleDropDownMenu(1, nil, LinkDropdown, self)--, GetCursorPosition())
		else
			LinkLoot(self:GetParent().opt.linkall_channel)
		end
	end

	function FramePrototype:OnHide()
		if LootFrame_OnHide then
			-- Classic's handler also hides the master-loot picker but errors on its nil self, hence the pcall.
			pcall(LootFrame_OnHide)
		else
			CloseLoot()
		end
		for i,v in ipairs(self.rows) do
			v:Hide()
		end
	end

	local function BottomButton(frame, name, text, justify)
		local b = CreateFrame('Button', name, frame)
		b.text = b:CreateFontString(name..'Text', 'OVERLAY')
		SafeSetFont(b.text, frame.opt.font, frame.opt.font_size_bottombuttons)
		b.text:SetText('|c22AAAAAA'..text)
		b.text:SetJustifyH(justify)
		b.text:SetAllPoints(b)
		b:SetFrameLevel(8)
		b:SetHeight(16)
		b:SetHighlightTexture([[Interface\Buttons\UI-Panel-MinimizeButton-Highlight]])
		b:ClearAllPoints()
		b:SetPoint('BOTTOM', 0, 3)
		b:SetHitRectInsets(-4, -4, 3, -2)
		b:Show()
		return b
	end

	function FramePrototype:UpdateHeight()
		if self.row_height then
			self:SetHeight(
				((self.link:IsShown() or not opt.old_close_button) and 6 or 0)
				 + opt.loot_padding_top
				 + opt.loot_padding_bottom
				 + #self.slots * self.row_height)
		end
	end

	function FramePrototype:UpdateWidth(width_max)
		local width = self.opt.frame_width_automatic and (width_max + 70) or (self.opt.frame_width + 50)
		self:SetWidth(width)
		width = width * 0.5 - 10
		self.link:SetWidth(width)
		self.close:SetWidth(width)
	end

	function FramePrototype:UpdateLinkButton()
		local target, show, now = self.opt.linkall_channel, self.opt.linkall_show, false
		if show == 'auto' then
			if target == 'SAY' or
				((target == 'GUILD' or target == 'OFFICER') and IsInGuild()) or
				((target == 'RAID' or target == 'RAID_WARNING') and IsInRaid()) or
				(target == 'PARTY' and IsInGroup())
			then
				now = true
			end
		else
			now = IsGroupState[show]()
		end
		if now then
			self.link:Show()
		else
			self.link:Hide()
		end
	end

	function FramePrototype:SizeAndColor(max_width, max_quality)
		self:UpdateLinkButton()
		self:UpdateHeight()
		self:UpdateWidth(max_width)

		if self.opt.quality_color_frame then
			local r, g, b = C_Item.GetItemQualityColor(max_quality)
			self.overlay:SetBorderColor(r, g, b, 1)
		end
	end

	function FramePrototype:UpdateAppearance()
		self.skin = self:CurrentSkin()
		self.skin.row_offset = self.skin.row_spacing * -1

		self:SetScale(self.opt.frame_scale)
		self.overlay:SetAlpha(self.opt.frame_alpha)
		self.overlay:SetBorderColor(self:GetColor('frame_color_border'))
		self.overlay:SetGradientColor(self:GetColor('frame_color_gradient'))
		self.overlay:SetBackdropColor(self:GetColor('frame_color_backdrop', 0.7))

		for i, row in ipairs(self.rows) do
			row:UpdateAppearance()
		end

		if #self.slots > 0 and self.opt.frame_width_automatic then
			local max_width, max = 0, math.max
			for i, slot in ipairs(self.slots) do
				max_width = max(max_width, slot.text_name:GetStringWidth(), slot.text_info:GetStringWidth())
			end
			self:UpdateWidth(max_width)
		end

		if opt.old_close_button then
			self.close:Hide()
			self.old_close:Show()
		else
			self.close:Show()
			self.old_close:Hide()
		end

		SafeSetFont(self.close.text, opt.font, opt.font_size_bottombuttons)
		SafeSetFont(self.link.text, opt.font, opt.font_size_bottombuttons)
	end

	function addon:BuildLootFrame(f)
		local name = f:GetName()
		FramePrototype:New(f)
		f:SetFrameStrata('DIALOG')
		f:SetFrameLevel(5)
		f:EnableMouse(1)

		XLoot:MakeSkinner(f, {
			item = {
				backdrop = false
			},
			row_highlight = {
				type = 'highlight'
			},
			item_highlight = {
				type = 'highlight',
				layer = 'OVERLAY'
			}
		})


		-- Use a secondary frame for backdrop/border to allow the "frame" opacity to be changed
		local overlay = CreateFrame('Frame', nil, f, BackdropTemplateMixin and "BackdropTemplate")
		overlay:SetFrameLevel(5)
		overlay:SetAllPoints()
		f:Skin(overlay)
		f.overlay = overlay

		local link = BottomButton(f, name..'Link', L.button_link, 'CENTER')
		link:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
		link:SetPoint('LEFT', 6, 0)
		f.link = link

		local close = BottomButton(f, name..'Close', L.button_close, 'CENTER')
		close:SetPoint('RIGHT', -6, 0)
		f.close = close

		local x = CreateFrame("Button", nil, f)
		x:SetWidth(30)
		x:SetHeight(30)
		local xtex = [[Interface\Buttons\UI-Panel-MinimizeButton-]]
		x:SetNormalTexture(xtex..'Up')
		x:SetPushedTexture(xtex..'Down')
		x:SetHighlightTexture(xtex..'Highlight')
		x:SetPoint('TOPRIGHT', 3, 3)
		x:SetHitRectInsets(3, 3, 3, 3)
		x:SetFrameLevel(f:GetFrameLevel()+2)
		-- f:Skin(x)
		-- x:SetBorderColor(.7, .7, .7)
		f.old_close = x


		if not f.fake then
			f:SetMovable(1)
			f:RegisterForDrag('LeftButton')
			f:SetScript('OnDragStart', OnDragStart)
			f:SetScript('OnDragStop', OnDragStop)
			f:SetScript('OnHide', f.OnHide)
			link:SetScript('OnClick', f.LinkClick)

			-- WoW now shows an error if any parameter is passed, and OnClick passes one
			local function CloseLoot_Nil()
				CloseLoot()
			end

			close:SetScript('OnClick', CloseLoot_Nil)
			x:SetScript('OnClick', CloseLoot_Nil)
		end

		f.GetColor = GetColor

		f.rows = setmetatable({}, { __index = function(t, k)
			local row = BuildRow(f, k)
			t[k] = row
			return row
		end })

		f.slots_index = {}
		f.slots = {}

		f:UpdateAppearance()
		f.built = true
	end
end

local auto, auto_items = {}, {}

local function ListEntries(text)
	local names, seen = {}, {}
	-- Shift-clicked links arrive back to back with no comma, and reagent links carry a quality icon inside the brackets.
	text = text:gsub('|A.-|a', ''):gsub('|H.-|h%[(.-)%]|h', ',%1,'):gsub('|c%x%x%x%x%x%x%x%x', ''):gsub('|cn[^:]*:', ''):gsub('|r', '')
	for entry in text:gmatch('[^,]+') do
		local name = entry:match('^%s*(.-)%s*$')
		if name ~= '' and not seen[ListKey(name)] then
			seen[ListKey(name)] = true
			names[#names + 1] = name
		end
	end
	return names
end

local function NotifyOptions()
	local reg = LibStub("AceConfigRegistry-3.0", true)
	if reg then reg:NotifyChange("XLoot") end
end

function XLootFrame:ParseAutolootList()
	wipe(auto_items)
	for _, name in ipairs(ListEntries(opt.autoloot_item_list)) do
		auto_items[ListKey(name)] = true
	end
end

function XLootFrame.GetAutolootList()
	local names = ListEntries(opt.autoloot_item_list)
	table.sort(names, function(a, b) return ListKey(a) < ListKey(b) end)
	return names
end

function XLootFrame:AddToAutolootList(text)
	opt.autoloot_item_list = table.concat(ListEntries(opt.autoloot_item_list .. ',' .. text), ',')
	self:ParseAutolootList()
	NotifyOptions()
end

function XLootFrame:RemoveFromAutolootList(name)
	local key, kept = ListKey(name), {}
	for _, entry in ipairs(ListEntries(opt.autoloot_item_list)) do
		if ListKey(entry) ~= key then
			kept[#kept + 1] = entry
		end
	end
	opt.autoloot_item_list = table.concat(kept, ',')
	self:ParseAutolootList()
	NotifyOptions()
end

local auto_states = {
	always = true,
	group = true, -- Secretly "Always" shh
	never = false,
	solo = nil,
	party = nil,
	raid = nil
}


function addon:GROUP_ROSTER_UPDATE()
	auto_states.solo = not IsInGroup()
	auto_states.raid = IsInRaid()
	auto_states.party = not auto_states.raid
end

local function clear(slot)
	if not slot then return nil end
	slot.slot = nil
	slot.item = nil
	slot.quality = nil
	slot:Hide()
end

local function BoPRefresh()
	if type(XLootFrame.rows) == 'table' then
		for i, row in pairs(XLootFrame.rows) do
			clear(row)
		end
	end
	XLootFrame:Update(false, true)
end

local tremove = table.remove
local speedy = { queue = {}, attempted = {}, ticker = nil, leftover = nil, lastcount = nil }

-- Vacuuming under master loot would grab assignable drops.
local function SpeedyAllowed()
	if opt.speedy_autoloot_skip_fishing and IsFishingLoot() then return false end
	return not IsModifiedClick('AUTOLOOTTOGGLE') and not XLoot.GroupUsesMasterLoot()
end

local function SpeedyStop()
	if speedy.ticker then
		speedy.ticker:Cancel()
		speedy.ticker = nil
	end
	if speedy.leftover then
		speedy.leftover:Cancel()
		speedy.leftover = nil
	end
end

-- Bags filling mid-vacuum strand loot in the suppressed window, so reveal whatever is left once draining stops.
-- Only slots we actually queued count: the filtered path deliberately leaves the rest on the corpse, already drawn.
local function SpeedyLeftovers()
	speedy.leftover = nil
	for slot in pairs(speedy.attempted) do
		if LootSlotHasItem(slot) then
			BoPRefresh()
			return
		end
	end
end

local function SpeedyDrain()
	local slot = tremove(speedy.queue)
	if slot and LootSlotHasItem(slot) then
		LootSlot(slot)
	end
	if #speedy.queue == 0 then
		SpeedyStop()
		if C_Timer and C_Timer.NewTimer then
			speedy.leftover = C_Timer.NewTimer(0.3, SpeedyLeftovers)
		end
	end
end

local function SpeedyStart()
	if speedy.ticker or #speedy.queue == 0 then return end
	if C_Timer and C_Timer.NewTicker then
		-- One slot per tick, never a tight loop: a rapid-loot burst trips the server disconnect on big piles.
		speedy.ticker = C_Timer.NewTicker(0.03, SpeedyDrain)
	else
		while #speedy.queue > 0 do
			SpeedyDrain()
		end
	end
end

-- lastcount dedups the shared LOOT_READY/LOOT_OPENED pass. A real count change rebuilds the queue.
local function SpeedyVacuum()
	local n = GetNumLootItems()
	if n == 0 or speedy.lastcount == n then return end
	speedy.lastcount = n
	SpeedyStop()
	wipe(speedy.queue)
	wipe(speedy.attempted)
	for slot = 1, n do
		speedy.queue[slot] = slot
		speedy.attempted[slot] = true
	end
	SpeedyStart()
end

local _bag_slots = {}
-- Loot slots deferred by the filters because the item was not cached yet, reconsidered once BoPRefresh has it.
local auto_retry = {}
function XLootFrame:Update(no_snap, is_refresh, game_autoloot)
	local numloot = GetNumLootItems()
	if numloot == 0 then return nil end
	local max = math.max
	local speedy_paced = not is_refresh and opt.speedy_autoloot
		and opt.speedy_autoloot_respect_filters and SpeedyAllowed()
	-- Fishing skips the filter auto-loot too, or a matching fish is taken before the tracker reads it.
	local skip_fishing = opt.speedy_autoloot and opt.speedy_autoloot_skip_fishing and IsFishingLoot()
	if speedy_paced then
		wipe(speedy.queue)
		wipe(speedy.attempted)
	end
	-- Keeps auto_retry to slots the current first pass vetted, so a refresh can never route around the skips below.
	if not is_refresh then
		wipe(auto_retry)
	end

	if not self.built then
		addon:BuildLootFrame(self)
		self:ParseAutolootList()
		self.auto_items = auto_items
		addon:GROUP_ROSTER_UPDATE()
	end

	local rows, slots, slots_index = self.rows, wipe(self.slots), wipe(self.slots_index)
	local bag_slots, reagent_free

	local auto, auto_items = auto, auto_items
	for k,v in pairs(opt.autoloots) do
		auto[k] = auto_states[v]
	end

	local max_quality, max_width, our_slot, slot, need_refresh, retried = 0, 0, 0
	for slot = 1, numloot do
		local _, icon, name, quantity, currencyID, quality, locked, isQuestItem, questID, startsQuest = pcall(GetLootSlotInfo, slot)
		-- Already looted or erroring slot
		if not name then
			if not is_refresh and opt.show_slot_errors then
				xprint(L.slot_name_error:format(tostring(slot)))
			end

		elseif not icon then
			if not is_refresh and opt.show_slot_errors then
				xprint(L.slot_icon_error:format(tostring(slot)))
			end

		else
			local autoloot, secret, uncached = false, false, false
			local slotType, slotData = GetLootSlotType(slot)
			if slotType == LOOT_SLOT_ITEM then
				local link = GetLootSlotLink(slot)
				secret = issecret and issecret(link) or false
				slotData = not secret and GetItemInfoTable(link) or nil
				-- Item not in client cache yet: render from loot-slot data, refresh shortly
				if not slotData then
					slotData = { name = name, icon = icon, quality = quality, link = link, stackCount = 1, bindType = 0 }
					need_refresh, uncached = true, true
				end
				slotData.slotType = slotType
				slotData.quantity = quantity
				slotData.locked = locked
				slotData.isQuestItem = isQuestItem
				slotData.questID = questID
				slotData.startsQuest = startsQuest
				if secret then slotData.secret, slotData.quality, slotData.quantity, slotData.locked, slotData.isQuestItem, slotData.questID, slotData.startsQuest = true, nil, 1, nil, nil, nil, nil end
			else
				slotData = {
					name = name,
					icon = icon,
					slotType = slotType,
					quantity = quantity,
					quality = quality,
					locked = locked,
					bindType = 0
				}
				if issecret and issecret(name) then slotData.secret, slotData.quality, slotData.quantity, slotData.locked = true, nil, 1, nil end
			end

			-- When the game is already auto-looting it grabs the free items, so we just show the window for what is left (BoP confirms, read-only master-loot drops) instead of double-looting and stranding them.
			-- auto_retry only holds slots this same block vetted but could not judge, so the refresh reconsiders them without reopening the other skips.
			if (not is_refresh or auto_retry[slot]) and not secret and not locked and not game_autoloot and not skip_fishing then
				if (auto.all or auto.currency) and (slotType == LOOT_SLOT_MONEY or slotType == LOOT_SLOT_CURRENCY) then
					autoloot = true
				elseif (auto.all or auto.quest) and (isQuestItem or startsQuest) then
					autoloot = true
				elseif
					auto.all
					or (auto.list and slotType == LOOT_SLOT_ITEM and not (issecret and issecret(name)) and auto_items[ListKey(name)])
					or (auto.tradegoods and slotData.isCraftingReagent)
					or (auto.quality and slotType == LOOT_SLOT_ITEM and (slotData.quality or 0) >= opt.autoloot_quality_min)
					or (auto.gear
						and slotData.equipLoc and slotData.equipLoc ~= ''
						and (slotData.quality or 0) >= opt.autoloot_gear_quality
						and (C_Item.GetDetailedItemLevelInfo(slotData.link) or slotData.level or 0) >= opt.autoloot_gear_minlevel)
					or (auto.value
						and slotData.sellPrice and slotData.sellPrice > 0
						and slotData.sellPrice * quantity >= opt.autoloot_value_minprice * 10000)
				then
					if not bag_slots then
						bag_slots = wipe(_bag_slots)
						for i = 0, NUM_BAG_SLOTS do
							local open, family = GetContainerNumFreeSlots(i)
							if family then
								bag_slots[family] = bag_slots[family] and bag_slots[family] + open or open
							end
						end
						reagent_free = REAGENT_BAG and GetContainerNumFreeSlots(REAGENT_BAG) or 0
					end

					local family = C_Item.GetItemFamily(slotData.link)
					family = (family and family <= 4096) and family or 0
					if not (bag_slots[family] and bag_slots[family] > 0) then
						family = 0
					end
					if bag_slots[family] > 0 then
						autoloot = true
						bag_slots[family] = bag_slots[family] - 1

					elseif slotData.isCraftingReagent and reagent_free > 0 then
						autoloot = true
						reagent_free = reagent_free - 1

					else
						local partial = C_Item.GetItemCount(slotData.link) % slotData.stackCount
						if partial > 0 and (partial + quantity < slotData.stackCount) then
							autoloot = true
						end
					end
				end

				if autoloot then
					if speedy_paced then
						speedy.queue[#speedy.queue + 1] = slot
						speedy.attempted[slot] = true
					else
						need_refresh = true
						retried = is_refresh or retried
						LootSlot(slot)
					end
				end

				-- Only slots we did NOT act on: a LootSlot that leaves the item (BoP confirm, unique already owned, bags full) must fall through to a row, not be looted twice.
				auto_retry[slot] = (uncached and not autoloot) or nil
			end


			if not autoloot then
				our_slot = our_slot + 1
				local row = rows[our_slot]
				slots[our_slot] = row

				row.item = slotData.link
				row.quality = slotData.quality
				row.slot = slot
				row.frame_slot = our_slot
				row:SetID(slot)

				local width = row:Update(slotData)

				max_width = max(width, max_width)
				max_quality = max(slotData.quality or 0, max_quality)
			end
		end
	end

	if speedy_paced then
		SpeedyStart()
	end

	-- A retry pass loots slots whose row it also suppresses, so it must re-arm once in case the item stays put (BoP confirm, unique already owned). Bounded: the retry clears auto_retry, so the next pass cannot loot that slot again.
	if (not is_refresh and need_refresh) or retried then
		C_Timer.After(0.8, BoPRefresh)
	end

	if our_slot == 0 then
		return nil
	end

	self:SizeAndColor(max_width, max_quality)

	-- A refresh must not yank the window out from under the cursor, but a speedy-autoloot leftover sweep is a first show and has never been positioned.
	if not no_snap and (not is_refresh or not self:IsShown()) then
		self:SnapToCursor()
	end
	self:Show()
end

function addon:LOOT_CLOSED()
	SpeedyStop()
	wipe(speedy.queue)
	wipe(speedy.attempted)
	wipe(auto_retry)
	speedy.lastcount = nil
	if type(XLootFrame.rows) == 'table' then
		for i, row in pairs(XLootFrame.rows) do
			clear(row)
		end
		wipe(XLootFrame.slots)
	end
	XLootFrame:Hide()
	StaticPopup_Hide('LOOT_BIND')
	if UIDropDownMenu_GetCurrentDropDown() == LinkDropdown then
		CloseDropDownMenus()
	end
end

-- LOOT_READY fires before LOOT_OPENED, so vacuum here to start looting a frame earlier.
function addon:LOOT_READY()
	if opt.speedy_autoloot and not opt.speedy_autoloot_respect_filters
		and SpeedyAllowed() and GetNumLootItems() > 0 then
		SpeedyVacuum()
	end
end

function addon:LOOT_OPENED(autoLoot)
	local announce_when = IsGroupState[opt.linkall_auto]
	if announce_when and announce_when() and GetNumLootItems() > 0 and HasNewLootSources() then
		LinkLoot(opt.linkall_channel, true)
	end
	if opt.speedy_autoloot and not opt.speedy_autoloot_respect_filters
		and SpeedyAllowed() and GetNumLootItems() > 0 then
		if not XLootFrame:IsShown() and IsFishingLoot() then
			PlaySound(SOUNDKIT.FISHING_REEL_IN)
		end
		SpeedyVacuum()
		return
	end
	if GetNumLootItems() > 0 then
		if not XLootFrame:IsShown() and IsFishingLoot() then
			PlaySound(SOUNDKIT.FISHING_REEL_IN)
		end
		-- Normalize the LOOT_OPENED autoLoot arg: some older Classic clients pass 0/1, and 0 is truthy in Lua.
		XLootFrame:Update(nil, nil, autoLoot and autoLoot ~= 0)
	else
		PlaySound(SOUNDKIT.LOOT_WINDOW_OPEN_EMPTY)
		CloseLoot()
	end
end

function addon:LOOT_SLOT_CLEARED(slot)
	local slots = XLootFrame.slots
	-- Apparently auto-looting addons like EasyLoot will cause strange issues
	if slots == nil then
		return
	end
	for id, row in ipairs(slots) do
		if row.slot == slot then
			clear(row)
			if XLootFrame.opt.loot_collapse then
				local prev, next = slots[id-1], slots[id+1]
				if prev and next then
					next:SetPoint('TOP', prev, 'BOTTOM', nil, XLootFrame.skin.row_offset)
				elseif next then
					next:SetPoint('TOP', 0, -opt.loot_padding_top)
				end
				table.remove(slots, id)
				XLootFrame:UpdateHeight()
			end
		end
	end
end

-- Refreshes the shift-compare tooltip without an OnUpdate on every row
function addon:MODIFIER_STATE_CHANGED()
	if (GetNumLootItems() ~= 0) and mouse_focus and mouse_focus:IsMouseOver() then
		mouse_focus:ShowTooltip()
	end
end

