---@class XLootAddon
local XLoot = select(2, ...)

local function CompileLocales(locales)
	local L = locales[GetLocale()] and locales[GetLocale()] or locales.enUS
	if L ~= locales.enUS then
		setmetatable(L, { __index = locales.enUS })
		for k, v in pairs(L) do
			if type(v) == 'table' then
				setmetatable(v, { __index = locales.enUS[k] })
			end
		end
	end
	return L
end

-- locales expects table: { enUS = {...}, ... }
function XLoot:Localize(name, locales)
	-- We need to extract the root namespace due to how Curse is currently doing localizations.
	for _,t in pairs(locales) do
		if t[name] then
			for k, v in pairs(t[name]) do
				t[k] = v
			end
			t[name] = nil
		end
	end
	self["L_"..name] = CompileLocales(locales)
end

local locales = {
	enUS = {
		skin_svelte = "XLoot: Svelte",
		skin_legacy = "XLoot: Legacy",
		skin_smooth = "XLoot: Smooth",
		anchor_hide = "hide",
		minimap_click_left = "Left-click: Open options",
		minimap_click_right = "Right-click: What's New",
		minimap_click_shift = "Shift-click: Toggle Speedy auto-loot",
		speedy_state = "Speedy auto-loot: %s",
		state_on = "ON",
		state_off = "OFF",
		speedy_unavailable = "Speedy auto-loot needs the XLoot Frame module enabled.",
		speedy_usage = "Usage: /xlspeedy toggles Speedy auto-loot. /xlspeedy on or /xlspeedy off sets it directly.",
		binding_toggle_speedy = "Toggle Speedy auto-loot",
		options_after_combat = "Options will open when combat ends.",
		anchor_hide_desc = "Lock this module in position\nThis will hide the anchor,\nbut it can be shown again from the options",
		discord_popup = "Join the XLoot community for help, feedback, and updates.\n\nCopy the invite below (it's pre-selected — just press Ctrl+C):",
	},
	-- Possibly localized
	ptBR = {},
	frFR = {},
	deDE = {},
	koKR = {},
	esMX = {},
	ruRU = {},
	zhCN = {},
	esES = {},
	zhTW = {},
}

-- Automatically inserted translations
-- Core

-- Core

-- Core
locales.deDE["anchor_hide"] = "verstecken"
locales.deDE["skin_legacy"] = "XLoot: Legacy"
locales.deDE["skin_smooth"] = "XLoot: Smooth"
locales.deDE["skin_svelte"] = "XLoot: Svelte"

-- Core

-- Core
locales.zhCN["anchor_hide"] = "隐藏"
locales.zhCN["anchor_hide_desc"] = [=[在此位置锁定此模块
这将隐藏锚点
但可通过选项重新显示]=]
locales.zhCN["skin_legacy"] = "XLoot: Legacy"
locales.zhCN["skin_smooth"] = "XLoot: Smooth"
locales.zhCN["skin_svelte"] = "XLoot: Svelte"

-- Core

-- Core
locales.zhTW["anchor_hide"] = "隱藏"
locales.zhTW["anchor_hide_desc"] = [=[鎖定此模組在此位置上
這會隱藏此錨點,
但它可以藉由選項再次顯示]=]
locales.zhTW["skin_legacy"] = "XLoot: 傳統"
locales.zhTW["skin_smooth"] = "XLoot: 滑順"
locales.zhTW["skin_svelte"] = "XLoot: 苗條"


locales.ruRU["anchor_hide"] = "скрыть"
locales.ruRU["anchor_hide_desc"] = "Зафиксировать этот модуль на месте\nЭто скроет якорь,\nно его можно снова показать в настройках"
locales.ruRU["skin_legacy"] = "XLoot: Наследие"
locales.ruRU["skin_smooth"] = "XLoot: Плавный"
locales.ruRU["skin_svelte"] = "XLoot: Стройный"
locales.ruRU["minimap_click_left"] = "ЛКМ: открыть настройки"
locales.ruRU["minimap_click_right"] = "ПКМ: Что нового"
locales.ruRU["discord_popup"] = "Присоединяйтесь к сообществу XLoot, чтобы получить помощь, оставить отзыв и узнавать об обновлениях.\n\nСкопируйте приглашение ниже (оно уже выделено — просто нажмите Ctrl+C):"
locales.ruRU["minimap_click_shift"] = "Shift+ЛКМ: переключить быстрый автолут"
locales.ruRU["speedy_state"] = "Быстрый автолут: %s"
locales.ruRU["state_on"] = "ВКЛ"
locales.ruRU["state_off"] = "ВЫКЛ"
locales.ruRU["speedy_unavailable"] = "Для быстрого автолута нужно включить модуль XLoot Frame."
locales.ruRU["speedy_usage"] = "Использование: /xlspeedy переключает быстрый автолут. /xlspeedy on или /xlspeedy off включает или выключает его напрямую."
locales.ruRU["binding_toggle_speedy"] = "Переключить быстрый автолут"

locales.koKR["anchor_hide"] = "숨기기"
locales.koKR["anchor_hide_desc"] = "이 위치에 모듈을 고정하고\n위치 조절 손잡이를 숨깁니다.\n설정에서 다시 표시할 수 있습니다."
locales.koKR["minimap_click_left"] = "좌클릭: 설정 열기"
locales.koKR["minimap_click_right"] = "우클릭: 업데이트 내용 보기"
locales.koKR["minimap_click_shift"] = "Shift+클릭: 빠른 자동 획득 전환"
locales.koKR["speedy_state"] = "빠른 자동 획득: %s"
locales.koKR["state_on"] = "켜짐"
locales.koKR["state_off"] = "꺼짐"
locales.koKR["speedy_unavailable"] = "빠른 자동 획득을 사용하려면 XLoot Frame 모듈을 활성화해야 합니다."
locales.koKR["speedy_usage"] = "사용법: /xlspeedy로 빠른 자동 획득을 전환합니다. /xlspeedy on 또는 /xlspeedy off로 직접 켜거나 끌 수 있습니다."
locales.koKR["binding_toggle_speedy"] = "빠른 자동 획득 전환"
locales.koKR["options_after_combat"] = "전투가 끝나면 설정을 엽니다."
locales.koKR["discord_popup"] = "XLoot 커뮤니티에서 도움을 받고 의견과 업데이트 소식을 나누세요.\n\n아래 초대 링크는 이미 선택되어 있습니다. Ctrl+C로 복사하세요."

XLoot.L = CompileLocales(locales)
