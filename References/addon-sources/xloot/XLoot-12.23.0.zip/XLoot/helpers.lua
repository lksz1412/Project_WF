---@class XLootAddon
local XLoot = select(2, ...)
local buffer, print = {}, print

local table_insert, table_concat, string_format = table.insert, table.concat, string.format

local issecret = issecretvalue

local coin_table = {
	{ GOLD_AMOUNT, 0, "ffd700" },
	{ SILVER_AMOUNT, 0, "c7c7cf" },
	{ COPPER_AMOUNT, 0, "eda55f" }
}
for i,v in ipairs(coin_table) do
	v[4] = string_format("|cff%s%s|r", v[3], v[1])
end
function XLoot.CopperToString(copper)
	coin_table[1][2] = floor(copper / 10000)
	coin_table[2][2] = mod(floor(copper / 100), 100)
	coin_table[3][2] = mod(copper, 100)

	local buffer = wipe(buffer)
	for i,v in ipairs(coin_table) do
		local n = v[2]
		if n and n > 0 then
			table_insert(buffer, string_format(v[4], n))
		end
	end

	return table_concat(buffer, ", ")
end

local GetCoinTextureString = C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString or GetCoinTextureString
function XLoot.MoneyString(copper, icons)
	if icons and GetCoinTextureString then
		return GetCoinTextureString(copper)
	end
	return XLoot.CopperToString(copper)
end

local coin_patterns = {}
for i, v in ipairs(coin_table) do
	coin_patterns[i] = (v[1]:gsub("%%d", "(%%d+)"))
end

-- exact returns 0 when a digit is left unmatched, so a grouped "1,234 Gold" falls back instead of reading as 234 gold
function XLoot.ParseCoinString(str, exact)
	local g = str:match(coin_patterns[1]) or 0
	local s = str:match(coin_patterns[2]) or 0
	local c = str:match(coin_patterns[3]) or 0
	if exact then
		local rest = str
		for _, pattern in ipairs(coin_patterns) do
			rest = rest:gsub(pattern, "")
		end
		if rest:find("%d") then
			return 0
		end
	end
	return g*10000+s*100+c
end

-- Scanning tooltip must live outside the UIParent tree, or the tooltip refresh cycle perpetually re-processes dynamic content (weapon imbues, temp buffs, tradeable timers).
XLootTooltip = CreateFrame('GameTooltip', 'XLootTooltip', nil, 'GameTooltipTemplate')
local tooltip = XLootTooltip
tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

function XLoot.CanEquipItem(link)
	if issecret and issecret(link) then return false end
	if not C_Item.IsEquippableItem(link) then
		return false
	end
	-- Hiding drops the owner and an unowned tooltip fills no lines. Re-own only when lost, since SetOwner hides it and its OnHide closes shared tooltips.
	if not tooltip:IsOwned(WorldFrame) then
		tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")
	end
	tooltip:ClearLines()
	tooltip:SetHyperlink(link)
	for i=2, math.min(5, tooltip:NumLines()) do
		local line = _G["XLootTooltipTextRight"..i]
		if line and line:GetText() then
			local r, g, b = line:GetTextColor()
			local lr, lg, lb = _G["XLootTooltipTextLeft"..i]:GetTextColor()
			return (r > .8 and b > .8 and g > .8 and lr > .8 and lg > .8 and lb > .8) and true or false
		end
	end
end
function XLoot.IsPawnUpgrade(link)
	if not PawnIsItemIDAnUpgrade or (issecret and issecret(link)) then
		return false
	end
	local id = string.match(link, "item:(%d+)")
	return id and PawnIsItemIDAnUpgrade(id) and true or false
end

-- No single "do I own this appearance" API (no help from blizzard here lol): PlayerHasTransmog* is per-source, so OR the collected state across every source.
local C_TC = _G.C_TransmogCollection
local TC_GetItemInfo = C_TC and C_TC.GetItemInfo
local TC_GetAllSources = C_TC and C_TC.GetAllAppearanceSources
local TC_PlayerHasSource = C_TC and C_TC.PlayerHasTransmogItemModifiedAppearance
local GetItemInfoInstant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
if TC_GetItemInfo and TC_GetAllSources and TC_PlayerHasSource and GetItemInfoInstant then
	local CLASS_WEAPON, CLASS_ARMOR = 2, 4
	local CACHE_CAP = 256
	local appearance_cache, cache_count = {}, 0
	local invalidator
	local function ensure_invalidator()
		if invalidator then return end
		invalidator = CreateFrame('Frame')
		invalidator:RegisterEvent('TRANSMOG_COLLECTION_SOURCE_ADDED')
		invalidator:RegisterEvent('TRANSMOG_COLLECTION_SOURCE_REMOVED')
		invalidator:SetScript('OnEvent', function() wipe(appearance_cache); cache_count = 0 end)
	end
	function XLoot.IsNewAppearance(link)
		if not link then return false end
		local classID = select(6, GetItemInfoInstant(link))
		if classID ~= CLASS_WEAPON and classID ~= CLASS_ARMOR then return false end
		local appearanceID, sourceID = TC_GetItemInfo(link)
		if not appearanceID or not sourceID or sourceID == 0 then return false end
		-- false is a real cached verdict, so test presence with ~= nil
		local cached = appearance_cache[sourceID]
		if cached ~= nil then return cached end
		local sources = TC_GetAllSources(appearanceID)
		if not sources then return false end -- transient nil: bail without caching a guess
		ensure_invalidator()
		local isNew = true
		for i = 1, #sources do
			if TC_PlayerHasSource(sources[i]) then
				isNew = false
				break
			end
		end
		if cache_count >= CACHE_CAP then wipe(appearance_cache); cache_count = 0 end
		appearance_cache[sourceID] = isNew
		cache_count = cache_count + 1
		return isNew
	end
else
	function XLoot.IsNewAppearance() return false end
end

-- Equip location -> the inventory slot(s) it competes with. Multi-slot types (rings/trinkets/1H weapons) win if they beat any one.
local UPGRADE_SLOTS = {
	INVTYPE_HEAD = { INVSLOT_HEAD },
	INVTYPE_NECK = { INVSLOT_NECK },
	INVTYPE_SHOULDER = { INVSLOT_SHOULDER },
	INVTYPE_CHEST = { INVSLOT_CHEST },
	INVTYPE_ROBE = { INVSLOT_CHEST },
	INVTYPE_WAIST = { INVSLOT_WAIST },
	INVTYPE_LEGS = { INVSLOT_LEGS },
	INVTYPE_FEET = { INVSLOT_FEET },
	INVTYPE_WRIST = { INVSLOT_WRIST },
	INVTYPE_HAND = { INVSLOT_HAND },
	INVTYPE_FINGER = { INVSLOT_FINGER1, INVSLOT_FINGER2 },
	INVTYPE_TRINKET = { INVSLOT_TRINKET1, INVSLOT_TRINKET2 },
	INVTYPE_CLOAK = { INVSLOT_BACK },
	INVTYPE_WEAPON = { INVSLOT_MAINHAND, INVSLOT_OFFHAND },
	INVTYPE_2HWEAPON = { INVSLOT_MAINHAND },
	INVTYPE_WEAPONMAINHAND = { INVSLOT_MAINHAND },
	INVTYPE_WEAPONOFFHAND = { INVSLOT_OFFHAND },
	INVTYPE_HOLDABLE = { INVSLOT_OFFHAND },
	INVTYPE_SHIELD = { INVSLOT_OFFHAND },
	-- Ranged items use the ranged slot on Era, TBC and Forever but the main hand from MoP on. The subtype match skips the slot that cannot hold one.
	INVTYPE_RANGED = { INVSLOT_MAINHAND, INVSLOT_RANGED },
	INVTYPE_RANGEDRIGHT = { INVSLOT_MAINHAND, INVSLOT_RANGED },
	INVTYPE_THROWN = { INVSLOT_RANGED },
	INVTYPE_RELIC = { INVSLOT_RANGED },
}
local GetDetailedItemLevelInfo = (C_Item and C_Item.GetDetailedItemLevelInfo) or GetDetailedItemLevelInfo
local GetInventoryItemLink = GetInventoryItemLink
local RequestLoadItemDataByID = C_Item and C_Item.RequestLoadItemDataByID
if GetDetailedItemLevelInfo and GetItemInfoInstant and GetInventoryItemLink then
	local CLASS_WEAPON, CLASS_ARMOR = 2, 4
	function XLoot.IsIlvlUpgrade(link)
		if not link then return false end
		local itemID, _, _, equipLoc, _, classID, subclassID = GetItemInfoInstant(link)
		if classID ~= CLASS_WEAPON and classID ~= CLASS_ARMOR then return false end
		local slots = equipLoc and UPGRADE_SLOTS[equipLoc]
		if not slots then return false end
		local lootedIlvl = GetDetailedItemLevelInfo(link)
		if not lootedIlvl or lootedIlvl == 0 then
			-- ilvl not cached yet, so warm it and skip this pass rather than risk a wrong tag
			if itemID and RequestLoadItemDataByID then RequestLoadItemDataByID(itemID) end
			return false
		end
		-- Only when an equipped slot holds the SAME weapon/armor subtype at lower ilvl: proves the player can use it, so no false tag on unusable gear.
		for i = 1, #slots do
			local equipped = GetInventoryItemLink('player', slots[i])
			if equipped and select(7, GetItemInfoInstant(equipped)) == subclassID then
				local equippedIlvl = GetDetailedItemLevelInfo(equipped)
				if equippedIlvl and lootedIlvl > equippedIlvl then return true end
			end
		end
		return false
	end
else
	function XLoot.IsIlvlUpgrade() return false end
end
local URGENCY_START, URGENCY_FULL = 0.3, 0.1
local URGENT_R, URGENT_G, URGENT_B = 1, 0.15, 0.15
function XLoot.TimeFractionColor(fraction, r, g, b)
	if fraction >= URGENCY_START then return r, g, b end
	local t = fraction <= URGENCY_FULL and 1
		or (URGENCY_START - fraction) / (URGENCY_START - URGENCY_FULL)
	return r + (URGENT_R - r) * t, g + (URGENT_G - g) * t, b + (URGENT_B - b) * t
end

local white = { r = 1, g = 1, b = 1 }
-- Read the globals live: class color addons install CUSTOM_CLASS_COLORS after we load.
function XLoot.ClassColor(class)
	return (_G.CUSTOM_CLASS_COLORS and _G.CUSTOM_CLASS_COLORS[class])
		or (_G.RAID_CLASS_COLORS and _G.RAID_CLASS_COLORS[class])
		or white
end

function XLoot.MyClassColor()
	local c = XLoot.ClassColor(select(2, UnitClass('player')))
	return c.r, c.g, c.b
end

local function ColorByte(v)
	v = floor((v or 0) * 255 + 0.5)
	return v < 0 and 0 or (v > 255 and 255 or v)
end

-- Eight chars with a leading ff: this substitutes for GetItemQualityColor's escape, which callers use whole.
function XLoot.ColorToHex(r, g, b)
	return string_format('ff%02x%02x%02x', ColorByte(r), ColorByte(g), ColorByte(b))
end

-- A saved font can outlive the addon that shipped it. A missing file raises, and a string left with no font throws on SetText, so fall back without touching the saved choice.
function XLoot.SafeSetFont(fontstring, font, size, flags)
	if not pcall(fontstring.SetFont, fontstring, font, size, flags) or not fontstring:GetFont() then
		fontstring:SetFont(STANDARD_TEXT_FONT, size, flags)
	end
end

local dimensions = {
	HEALER = '48:64',
	DAMAGER = '16:32',
	TANK = '32:48'
}
function XLoot.FancyPlayerName(name, class, opt)
	local c = XLoot.ClassColor(class)
	local role = 'NONE'
	if UnitGroupRolesAssigned then
		role = UnitGroupRolesAssigned(name)
	end
	local short, realm = UnitName(name)
	-- These can go secret for a name outside the group, such as a player who left mid-roll, and comparing a secret throws.
	if issecret and (issecret(role) or (short and issecret(short)) or (realm and issecret(realm))) then
		return name, c.r, c.g, c.b
	end
	if short then
		name = short
	end
	if realm and realm ~= "" then
		name = name.."*"
	end
	if role ~= 'NONE' and opt and opt.role_icon then
		name = string_format('\124TInterface\\LFGFRAME\\LFGROLE:12:12:-1:0:64:16:%s:0:16\124t%s', dimensions[role], name)
	end
	return name, c.r, c.g, c.b
end

-- Loot method: the string GetLootMethod() global is gone on modern Classic/retail and Enum.LootMethod is absent on some older flavors, so probe the C_PartyInfo enum first and fall back to the global. Both return method, masterlooterPartyID, masterlooterRaidID.
local MASTER_LOOT = Enum and Enum.LootMethod and Enum.LootMethod.Masterlooter
local C_GetLootMethod = C_PartyInfo and C_PartyInfo.GetLootMethod
local function MasterLootInfo()
	if MASTER_LOOT and C_GetLootMethod then
		local method, party_id, raid_id = C_GetLootMethod()
		return method == MASTER_LOOT, party_id, raid_id
	end
	if GetLootMethod then
		local method, party_id, raid_id = GetLootMethod()
		return method == 'master', party_id, raid_id
	end
	-- Last resort while a loot window is open: a candidate list only exists under master loot.
	return GetMasterLootCandidate and GetMasterLootCandidate(1, 1) ~= nil or false
end

function XLoot.GroupUsesMasterLoot()
	return (MasterLootInfo()) and true or false
end

function XLoot.IsMasterLooter()
	local isMaster, party_id, raid_id = MasterLootInfo()
	if not isMaster then return false end
	if raid_id then
		return UnitIsUnit('player', 'raid'..raid_id)
	elseif party_id then
		return party_id == 0
	end
	return false
end

XLoot.SendChatMessage = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage

-- Numeric segment-by-segment compare, since a string compare sorts "12.10.0" below "12.9.0". Returns 1, -1, or 0.
function XLoot.CompareVersions(a, b)
	local ai, bi = tostring(a or ""):gmatch("%d+"), tostring(b or ""):gmatch("%d+")
	while true do
		local a_part, b_part = ai(), bi()
		if not a_part and not b_part then return 0 end
		local an, bn = tonumber(a_part) or 0, tonumber(b_part) or 0
		if an ~= bn then
			return an > bn and 1 or -1
		end
	end
end

-- Shared Blizzard loot-toast suppression, reference-counted so Monitor and Toast can each request it without
-- clobbering the other. The AddAlert wrapper is installed once and never restored, so toggling a source off can
-- not clobber another addon's later hook. LegendaryItemAlertSystem is retail-only. MoP routes legendaries through
-- LootAlertSystem.
do
	local requesters = {}
	local hooked = {}
	local systems = { "LootAlertSystem", "MoneyWonAlertSystem", "LootUpgradeAlertSystem", "LegendaryItemAlertSystem" }
	local function suppressing()
		return next(requesters) ~= nil
	end
	function XLoot.SuppressLootToasts(source, want)
		requesters[source] = want or nil
		if not suppressing() then return end
		for _, name in ipairs(systems) do
			local system = _G[name]
			if system and system.AddAlert and not hooked[name] then
				hooked[name] = true
				local original = system.AddAlert
				system.AddAlert = function(...)
					if suppressing() then return end
					return original(...)
				end
			end
		end
	end
end


local temp_list, template = {},
[[local string_match = string.match
return function(message)
	local pcall_status, m1, m2, m3, m4, m5 = pcall(string_match, message, [=[^%s$]=])
	assert(pcall_status, "Please report this on XLoot's GitHub issues page", message, [=[^%s$]=], m1)
	return %s
end]]

local match, gsub, insert = string.match, string.gsub, table.insert
local function invert(pattern)
	local inverted, arglist = pattern, nil
	inverted = gsub(inverted, "%(", "%%(")
	inverted = gsub(inverted, "%)", "%%)")
	inverted = gsub(inverted, "%-", "%%-")
	inverted = gsub(inverted, "%+", "%%+")
	inverted = gsub(inverted, "%.", "%%.")
	-- Account for reordered replacements
	local k = match(inverted, '%%(%d)%$')
	if k then
		local i, list = 1, wipe(temp_list)
		while k ~= nil do
			inverted = gsub(inverted, "(%%%d%$.)", "(.-)", 1)
			list[tonumber(k)] = 'm'..i
			k, i = match(inverted, "%%(%d)%$"), i + 1
		end
		arglist = table.concat(list, ", ")
	else
		inverted = gsub(inverted, "%%d", "(%%d+)")
		inverted = gsub(inverted, "%%s", "(.-)")
		-- Float specifiers like %.1f, whose dot was escaped above
		inverted = gsub(inverted, "%%%%%.%d*f", "([%%d%%.,]+)")
		arglist = "m1, m2, m3, m4, m5"
	end
	return inverted, arglist
end

local invert_cache = {}
function XLoot.Deformat(str, pattern)
	if issecret and issecret(str) then return end
	local func = invert_cache[pattern]
	if not func then
		local inverted, arglist = invert(pattern)
		func = loadstring(template:format(inverted, inverted, arglist))()
		invert_cache[pattern] = func
	end
	return func(str)
end
XLoot.InvertFormatString = invert

local quest_objective_items, quest_objectives_stale = {}, true
local MAX_QUEST_LOG_SCAN = 200

local function ObjectiveItemName(text)
	local needed = _G.QUEST_ITEMS_NEEDED
	local name = needed and XLoot.Deformat(text, needed)
	if name then return name end
	local found = _G.QUEST_OBJECTS_FOUND
	return found and XLoot.Deformat(text, found)
end

local function AddQuestObjectiveItem(text)
	local name = text and ObjectiveItemName(text)
	if name and name ~= '' then
		quest_objective_items[name] = true
	end
end

local function RebuildQuestObjectiveItems()
	quest_objectives_stale = false
	wipe(quest_objective_items)
	local QuestLog = _G.C_QuestLog
	if QuestLog and QuestLog.GetNumQuestLogEntries and QuestLog.GetInfo and QuestLog.GetQuestObjectives then
		for i = 1, (QuestLog.GetNumQuestLogEntries()) do
			local info = QuestLog.GetInfo(i)
			if info and not info.isHeader and info.questID then
				local objectives = QuestLog.GetQuestObjectives(info.questID)
				for _, objective in ipairs(objectives or {}) do
					if objective.type == 'item' then
						AddQuestObjectiveItem(objective.text)
					end
				end
			end
		end
	elseif _G.GetQuestLogTitle and _G.GetNumQuestLeaderBoards and _G.GetQuestLogLeaderBoard then
		-- GetNumQuestLogEntries counts only rows the log is showing, so collapsing a header would hide quests.
		for i = 1, MAX_QUEST_LOG_SCAN do
			local title, _, _, is_header = _G.GetQuestLogTitle(i)
			if not title then break end
			if not is_header then
				for j = 1, _G.GetNumQuestLeaderBoards(i) do
					local text, objective_type = _G.GetQuestLogLeaderBoard(j, i)
					if objective_type == 'item' then
						AddQuestObjectiveItem(text)
					end
				end
			end
		end
	end
end

-- The loot API's quest flag only covers Quest-type items, so match the log's own item objectives too.
function XLoot.IsQuestObjectiveItem(name)
	if not name then return false end
	if quest_objectives_stale then
		pcall(RebuildQuestObjectiveItems)
	end
	return quest_objective_items[name] or false
end

local quest_watcher = CreateFrame("Frame")
quest_watcher:RegisterEvent("QUEST_LOG_UPDATE")
quest_watcher:SetScript("OnEvent", function() quest_objectives_stale = true end)

-- Quest verdicts shared with the loot feed, which only sees a chat message and cannot ask the loot API itself.
-- Scanned in the core, not the Frame module, because that ships as a sibling addon a user can disable and
-- because speedy auto-loot never opens a window for its scan to run.
do
	local wanted, seen, count = {}, {}, 0
	local TTL, SWEEP = 30, 64

	local function ItemKey(link)
		return link and link:match('item:(%d+)')
	end

	function XLoot.WantQuestLoot(source, want)
		wanted[source] = want or nil
	end

	local function Mark(link)
		local key = ItemKey(link)
		if not key then return end
		local now = GetTime()
		if count >= SWEEP then
			count = 0
			for k, t in pairs(seen) do
				if now - t > TTL then seen[k] = nil else count = count + 1 end
			end
		end
		if not seen[key] then count = count + 1 end
		seen[key] = now
	end

	function XLoot.IsQuestLoot(link)
		local key = ItemKey(link)
		local t = key and seen[key]
		return (t and GetTime() - t <= TTL) or false
	end

	local scanned = 0
	local function Scan()
		if not next(wanted) then return end
		local n = GetNumLootItems()
		-- LOOT_READY and LOOT_OPENED both land on one window, and speedy auto-loot drains from the first.
		if n == 0 or scanned == n then return end
		local incomplete = false
		for slot = 1, n do
			local link = GetLootSlotLink(slot)
			if link and not (issecret and issecret(link)) then
				local ok, _, name, _, _, _, _, isQuestItem, questID = pcall(GetLootSlotInfo, slot)
				if not ok or not name then
					incomplete = true
				-- A secret cannot be indexed, keyed or even tested for truth, so screen every field before use.
				elseif not (issecret and (issecret(name) or issecret(isQuestItem) or issecret(questID)))
					and (isQuestItem or questID or XLoot.IsQuestObjectiveItem(name)) then
					Mark(link)
				end
			end
		end
		-- A slot the server had not filled in yet earns another pass on LOOT_OPENED.
		scanned = incomplete and 0 or n
	end

	local scanner = CreateFrame("Frame")
	scanner:RegisterEvent("LOOT_READY")
	scanner:RegisterEvent("LOOT_OPENED")
	scanner:RegisterEvent("LOOT_CLOSED")
	scanner:SetScript("OnEvent", function(_, event)
		if event == "LOOT_CLOSED" then
			scanned = 0
		else
			Scan()
		end
	end)
end

