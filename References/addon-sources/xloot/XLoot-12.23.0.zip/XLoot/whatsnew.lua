-- XLoot is currently maintained by Wheelbarrel00.
-- Originally created by Xuerian.

local XLoot = select(2, ...)

-- Newest first. Array order is the display order, so we never sort version strings.
local updates = {
	{
		version = "12.23.0",
		date = "2026-11-13",
		changes = {
			{
				label = "See and manage your auto-loot list",
				type = "feature",
				option = "Loot Frame > Auto-looting",
				description = "Every item on your auto-loot list now shows under the Add items box, and the Remove an item dropdown and Remove button take one off. To add, type a name or several names separated by commas into Add items, or click in it and shift-click an item, then press Enter. Suggested by Carolina.",
			},
			{
				label = "Auto-loot list ignores capital letters",
				type = "improvement",
				option = "Loot Frame > Auto-looting",
				description = "\"linen cloth\" now matches Linen Cloth. This works for Russian and accented letters too.",
			},
			{
				label = "Roll bar buttons and text sit centered",
				type = "bugfix",
				description = "On retail and WoW Forever, the item name and the Transmog and Pass roll counts on group loot roll bars sat too low, and the Transmog and Pass buttons hung below the bar. Reported by Sythalin.",
			},
			{
				label = "Shift-clicked items in the auto-loot list now loot",
				type = "bugfix",
				description = "An item shift-clicked into the auto-loot list was saved as a full item link that never matched, so it was never auto-looted. Items already saved that way now work without adding them again.",
			},
		},
	},
	{
		version = "12.22.0",
		date = "2026-11-07",
		changes = {
			{
				label = "Share your settings between game versions",
				type = "feature",
				option = "Profile > Share settings",
				description = "Export turns your XLoot settings into a string you can copy, and Import loads one, so you can carry your setup from retail to WoW Forever or a Classic flavor, or to another account or computer. Import it as a new profile or over the current one. Frame positions are fitted to the new screen. Auto-roll rules carry over only between the same game version, since each game version has its own items. Suggested by Benjiwow.",
			},
		},
	},
	{
		version = "12.21.0",
		date = "2026-10-30",
		changes = {
			{
				label = "See who rolled on the roll window",
				type = "feature",
				option = "Group Loot > What rolls to show",
				description = "With Show roll results on, hover Need, Greed, Transmog or Pass on a roll window to see who picked it, in their class color, with their roll number once the game has one. The list updates as rolls come in. Hover the roll bar itself to see everyone at once, even after you have rolled. Retail and WoW Forever. Off by default. Try /xlgd to preview. Suggested by AlexGotcha.",
			},
			{
				label = "A missing font no longer breaks XLoot",
				type = "bugfix",
				description = "If a font chosen in XLoot's options no longer existed, such as one from an addon you removed, the loot window could fail to open, errors piled up, and Reset to Defaults reported one too. XLoot now uses the game's default font until that font is back, and keeps your choice. Reported by Nesetalis.",
			},
		},
	},
	{
		version = "12.20.0",
		date = "2026-10-20",
		changes = {
			{
				label = "Speedy auto-loot quick toggle",
				type = "feature",
				option = "Loot Frame > Auto-looting",
				description = "Turn Speedy auto-loot on or off without opening the options: type /xlspeedy, set the XLoot key binding, or Shift-click the minimap icon. Every toggle confirms ON or OFF in chat, so you always know where it stands. Suggested by RoadBlock.",
			},
			{
				label = "Coin icons for looted coins",
				type = "improvement",
				option = "Global options",
				description = "The Coin icons option now also shows looted coins in the loot window and the Loot Monitor as gold, silver, and copper icons, not just item sell prices. Off by default. Reported by Benjiwow.",
			},
		},
	},
	{
		version = "12.19.0",
		date = "2026-10-19",
		changes = {
			{
				label = "Reputation in the loot feed",
				type = "feature",
				option = "Loot Monitor > Filters",
				description = "The loot feed can show the reputation you gain, such as \"+250 Silvermoon Court\", so you can see how fast it climbs. Gains with the same faction add up on one row while it is still on screen. Losses show in red, and have their own switch if you would rather not see them. Off by default. Suggested by Benjiwow.",
			},
			{
				label = "Experience, honor and skill-ups in the loot feed",
				type = "feature",
				option = "Loot Monitor > Filters",
				description = "Three more switches show the experience you gain from any source, the honor you earn, and a skill's new rank when it goes up. Each one adds up on a single row while it is on screen, in the color your chat window gives the same message. Off by default.",
			},
			{
				label = "Currency cap warning",
				type = "feature",
				option = "Loot Monitor > Filters",
				description = "Currency rows can carry a \"(capped)\" or \"(weekly cap)\" tag once you reach that currency's limit, so you know further gains are going to waste. Off by default.",
			},
		},
	},
	{
		version = "12.17.0",
		date = "2026-08-30",
		changes = {
			{
				label = "Color quest items in the loot feed",
				type = "feature",
				option = "Loot Monitor > Colors",
				description = "The loot feed now colors quest items the same way the loot window does, finishing what 12.16.0 started. The item name, the row border and the icon border all take the color, and you can pick any color you like or use your class color instead. It covers both quest-type items and the ordinary drops your active quests ask you to collect. Quest items are shown even when they fall below your quality thresholds, so it works without having to lower them. Only your own loot is colored. Off by default. Suggested by Kharris.",
			},
		},
	},
	{
		version = "12.16.0",
		date = "2026-08-20",
		changes = {
			{
				label = "Color quest items",
				type = "feature",
				option = "Loot Frame > Colors",
				description = "Quest items can take a color of their own on both the item name and the row border, so they stand out the moment the loot window opens. Pick any color you like, or use your class color instead. It covers both quest-type items and the ordinary drops your active quests ask you to collect, since the game's own quest flag only marks the first kind. Off by default. The loot feed will get the same treatment in a following update. Suggested by Kharris.",
			},
		},
	},
	{
		version = "12.15.0",
		date = "2026-08-16",
		changes = {
			{
				label = "Leave fishing catches alone",
				type = "feature",
				option = "Loot Frame > Auto-looting",
				description = "Speedy auto-loot can empty a fishing bobber faster than a fishing tracker addon can read the catch, so those addons quietly missed fish. A new switch under Speedy auto-loot leaves fishing loot for the normal loot window, while everything else still auto-loots exactly as before. Off by default. Reported by Addonman.",
			},
		},
	},
	{
		version = "12.14.0",
		date = "2026-08-02",
		changes = {
			{
				label = "Minimap icon and broker support",
				type = "feature",
				option = "Global options > Minimap icon",
				description = "XLoot can now sit on your minimap as a coin button. Left-click opens the options, right-click shows What's New, and you can drag it around the minimap edge. XLoot also offers itself to broker displays like Titan Panel, ChocolateBar, and ElvUI datatexts, whether or not the minimap icon is on. Off by default.",
			},
			{
				label = "Auto-loot filters work on first-seen items",
				type = "bugfix",
				description = "The gear, value, and trade goods filters need item details the game has not downloaded the first time an item drops, so they quietly skipped every new item until you had seen it once that session. XLoot now takes a second look once the details arrive. Speedy auto-loot also no longer strands filtered items without a row, and the loot window no longer opens in the wrong place afterwards.",
			},
		},
	},
	{
		version = "12.13.0",
		date = "2026-07-16",
		changes = {
			{
				label = "Roll results on retail",
				type = "feature",
				option = "Group Loot > What rolls to show",
				description = "The Group Loot roll window can show who rolled and who won again on retail. Roll counts build on the Need, Greed, and Transmog buttons, then the window names the winner in their class color, or shows Pass: All if nobody wanted it. Retail closes your roll the moment you choose but does not decide it until everyone has rolled, so the window now waits for the result and shows the current leader while it waits. Off by default. Try /xlgd to preview.",
			},
			{
				label = "Retail roll timer bars start full",
				type = "bugfix",
				description = "Fresh retail roll windows could start with a partly filled timer bar. XLoot was reading a value in Blizzard's roll event as its own resumed-roll flag, which replaced the roll's real length with an assumed one.",
			},
		},
	},
	{
		version = "12.12.0",
		date = "2026-07-11",
		changes = {
			{
				label = "Loot toasts",
				type = "feature",
				option = "Loot Toasts",
				description = "A new optional module pops a Blizzard-style toast when you receive notable loot, with the icon, name, count, and quality border. Plenty to tune - quality threshold, item level, how many show at once, time on screen, sound and animation, and how they respond to the mouse. Off by default. Try /xltd to preview. Thanks to HOPE for the request.",
			},
			{
				label = "Item values as coin icons",
				type = "feature",
				option = "XLoot options",
				description = "Item values can show as gold, silver, and copper coin icons instead of plain text, on the loot row sell price and the Classic tooltip. Off by default. Thanks to 1Holy-Z for the request.",
			},
			{
				label = "Bonus Roll restored on retail",
				type = "bugfix",
				description = "The retail Bonus Roll (coin-spin) frame was being hidden by XLoot's roll-frame suppression. It shows again. Thanks to Itamae and RoadBlock.",
			},
			{
				label = "Auto-announce channel fix",
				type = "bugfix",
				description = "Announcing loot to a Raid Warning channel outside a raid could silently fail. XLoot now downgrades or skips channels you cannot post to. Thanks to Itamae.",
			},
		},
	},
	{
		version = "12.11.1",
		date = "2026-07-10",
		changes = {
			{
				label = "Roll frames now appear on Classic zone-ins",
				type = "bugfix",
				description = "Group Loot roll frames could go missing when an item was not cached yet, like zoning into a dungeon with rolls already in progress. The roll now waits for the item to load and retries instead of being dropped until a reload. Thanks to RoadBlock for the fix and testing.",
			},
			{
				label = "Group Loot test preview works on Classic",
				type = "bugfix",
				description = "The roll test button drew nothing on Classic because its sample items only existed on retail. It now uses items that exist on Classic clients. Thanks to RoadBlock for the item set.",
			},
			{
				label = "No more doubled default roll frames",
				type = "bugfix",
				description = "Blizzard's own loot roll frames no longer show up next to XLoot's after a reload or zone-in during an active roll.",
			},
			{
				label = "AddOns list category and icon",
				type = "improvement",
				description = "XLoot and its modules now group together under a category with an icon in the game's addon list. Thanks to RoadBlock for the suggestion.",
			},
		},
	},
	{
		version = "12.11.0",
		date = "2026-07-08",
		changes = {
			{
				label = "Announce loot on open",
				type = "feature",
				option = "Loot Frame > Link all button",
				description = "Automatically link a loot window's contents to your chat channel when it opens, using the same quality threshold as the Link all button. Each loot source is announced only once, so reopening a corpse won't repeat it.",
			},
			{
				label = "Urgent roll timer",
				type = "feature",
				option = "Group Loot > Details",
				description = "The roll countdown can ramp to red as time runs out, reddening the whole row border so a roll about to expire is easy to catch at a glance.",
			},
			{
				label = "Clearer, more reliable What's New notices",
				type = "bugfix",
				description = "Version notices now compare numerically, so 12.10.0 no longer sorts below 12.9.0, and they never re-notify or forget notes after a downgrade.",
			},
			{
				label = "Scanning-tooltip refresh fix",
				type = "bugfix",
				description = "Stopped a tooltip refresh loop that could perpetually re-process items with dynamic tooltips like weapon enchants and temporary buffs. Thanks to RoadBlock.",
			},
			{
				label = "Clearer auto-loot help text",
				type = "improvement",
				option = "Loot Frame > Auto-looting",
				description = "The auto-loot section now makes clear it is XLoot's own auto-loot, separate from Blizzard's built-in Auto Loot, and that running both can cause \"that object is busy\" warnings.",
			},
		},
	},
	{
		version = "12.10.0",
		date = "2026-07-07",
		changes = {
			{
				label = "Highlight upgrades and new looks on roll frames",
				type = "feature",
				option = "Group Loot > Details",
				description = "The roll window border can turn green when a drop is an item-level upgrade for you, or blue when it's an appearance you haven't collected yet, so you can tell at a glance whether to roll.",
			},
			{
				label = "Per-item auto-roll",
				type = "feature",
				option = "Group Loot > Auto Roll",
				description = "Shift-click Need, Greed, or Pass on a roll window to set a rule for that item, and matching drops then roll for you automatically, bind-on-pickup prompts included. Auto-Need is behind its own opt-in.",
			},
			{
				label = "Loot window no longer vanishes with double auto-loot",
				type = "bugfix",
				description = "When Blizzard auto loot and XLoot's own auto-loot were both on, the loot window could fail to appear for items that still needed it, like bind-on-pickup confirmations. Thanks to Kai for the report and repro.",
			},
		},
	},
	{
		version = "12.9.0",
		date = "2026-07-05",
		changes = {
			{
				label = "New-appearance \"(new look)\" tag",
				type = "feature",
				option = "Loot Frame > Loot slots",
				description = "Marks looted weapons and armor whose transmog appearance you haven't collected yet, so you never vendor or disenchant a fresh look by mistake.",
			},
			{
				label = "Upgrade \"(upgrade)\" tag",
				type = "feature",
				option = "Loot Frame > Loot slots",
				description = "Marks looted gear with a higher item level than what you already have equipped in that slot.",
			},
			{
				label = "Vendor sell price in tooltips",
				type = "feature",
				option = "Global options",
				description = "On the Classic flavors, item tooltips can show the vendor sell price, including a stack's full value.",
			},
			{
				label = "Test button for Group Loot",
				type = "feature",
				option = "Group Loot > Testing",
				description = "Preview roll frames while you adjust their look, like the Loot Monitor's test button.",
			},
		},
	},
	{
		version = "12.8.1",
		date = "2026-07-03",
		notes = "|cffffd100Sorry for the popup!|r\nI wanted to make sure everyone sees this: you can now get these update notes as a quiet, clickable link in chat instead of a popup. Switch it under |cffffffff/xloot|r > |cffffffffAfter an update|r (choose |cffffffffChat link|r), or tick \"Don't show these again\" below to turn them off.",
		changes = {
			{
				label = "Fixed a group-join error on Classic",
				type = "bugfix",
				description = "XLoot Group no longer throws a Lua error when you join a group on Burning Crusade and other Classic clients. Thanks to Kai for the report.",
			},
		},
	},
	{
		version = "12.8.0",
		date = "2026-07-02",
		changes = {
			{
				label = "Auto-loot by rarity",
				type = "feature",
				option = "Loot Frame > Auto-looting",
				description = "Auto-loot everything at or above a quality you choose, like greens and better.",
			},
			{
				label = 'Show "system message" gold',
				type = "feature",
				option = "Loot Monitor > Filters",
				description = "Adds gold that only shows as a system message, such as world-quest rewards and gold purses (Sky Racer's Purse).",
			},
			{
				label = "Hide Blizzard's loot pop-ups",
				type = "feature",
				option = "Loot Monitor > Blizzard loot alerts",
				description = "Silence the default loot toasts that pile up when you open lots of chests, and let XLoot's Monitor handle it.",
			},
			{
				label = "Right-click to dismiss, longer display",
				type = "feature",
				option = "Loot Monitor > Details / Row fade times",
				description = "Right-click a Monitor row to clear it early, and keep loot on screen far longer if you like.",
			},
			{
				label = "Loot-frame font outline",
				type = "feature",
				option = "Loot Frame > Font",
				description = "A new outline option for the item-name text.",
			},
		},
	},
}

local WHATSNEW_VERSION = updates[1].version
local POPUP_TITLE = "What's New in XLoot"

local HEADING = "|cffffd100"
local VERSION_HEADING = "|cffffffff"
local WHERE = "|cff808080"
local STOP = "|r"

local POPUP_INTRO = HEADING.."New settings start OFF"..STOP.."\n"
	.."Anything below that adds a setting stays off until you switch it on in |cffffffff/xloot|r. Everything else applies right away."

local POPUP_FOOTER = HEADING.."Thanks for using XLoot!"..STOP.."\n"
	.."Found a bug or have an idea? Use the Discord button below. You can turn this popup off any time in /xloot."

local function unseen_releases()
	local seen = XLoot.db and XLoot.db.global and XLoot.db.global.whatsnew_seen
	-- The AceDB default is an empty string, so both nil and "" mean a fresh install: latest only, not the whole backlog.
	if not seen or seen == "" then
		return { updates[1] }
	end
	local out = {}
	-- Ordered compare, not an exact match: a downgrade or a pruned entry would otherwise dump the whole backlog.
	for _, release in ipairs(updates) do
		if XLoot.CompareVersions(release.version, seen) <= 0 then break end
		out[#out + 1] = release
	end
	if #out == 0 then
		out[1] = updates[1]  -- caught up but opened manually, never show an empty popup
	end
	return out
end

local function build_body(releases)
	local has_features = false
	for _, release in ipairs(releases) do
		for _, change in ipairs(release.changes) do
			if change.type ~= "bugfix" then
				has_features = true
				break
			end
		end
		if has_features then break end
	end
	local blocks = has_features and { POPUP_INTRO } or {}
	local show_versions = #releases > 1
	for _, release in ipairs(releases) do
		if show_versions then
			local header = VERSION_HEADING.."XLoot "..release.version..STOP
			if release.date then
				header = header.." "..WHERE.."("..release.date..")"..STOP
			end
			blocks[#blocks + 1] = header
		end
		if release.notes then
			blocks[#blocks + 1] = release.notes
		end
		for _, change in ipairs(release.changes) do
			local lines = { HEADING..change.label..STOP }
			if change.option then
				lines[#lines + 1] = WHERE..change.option..STOP
			end
			lines[#lines + 1] = change.description
			blocks[#blocks + 1] = table.concat(lines, "\n")
		end
	end
	blocks[#blocks + 1] = POPUP_FOOTER
	return table.concat(blocks, "\n\n")
end

-- Seen means seen this version OR NEWER, and marking never moves backward, so a downgrade neither re-notifies nor forgets the newer notes.
local function already_seen()
	local seen = XLoot.db and XLoot.db.global and XLoot.db.global.whatsnew_seen
	return seen ~= nil and XLoot.CompareVersions(seen, WHATSNEW_VERSION) >= 0
end

local function mark_seen()
	if XLoot.db and XLoot.db.global then
		local seen = XLoot.db.global.whatsnew_seen
		if not seen or XLoot.CompareVersions(WHATSNEW_VERSION, seen) > 0 then
			XLoot.db.global.whatsnew_seen = WHATSNEW_VERSION
		end
	end
end

local function already_announced()
	local announced = XLoot.db and XLoot.db.global and XLoot.db.global.whatsnew_announced
	return announced ~= nil and XLoot.CompareVersions(announced, WHATSNEW_VERSION) >= 0
end

local function mark_announced()
	if XLoot.db and XLoot.db.global then
		local announced = XLoot.db.global.whatsnew_announced
		if not announced or XLoot.CompareVersions(WHATSNEW_VERSION, announced) > 0 then
			XLoot.db.global.whatsnew_announced = WHATSNEW_VERSION
		end
	end
end

local function announce_chat()
	DEFAULT_CHAT_FRAME:AddMessage("|c2244dd22XLoot|r updated to "..WHATSNEW_VERSION.." — |Haddon:XLoot:whatsnew|h|cffffd100[See what's new]|r|h")
end

-- Custom chat hyperlink (|Haddon:XLoot:whatsnew|h). Blizzard ignores the unknown
-- type, so we open the popup ourselves when ours is clicked.
hooksecurefunc("SetItemRef", function(link)
	if link == "addon:XLoot:whatsnew" then
		XLoot:ShowWhatsNew()
	end
end)

local function make_button(parent, width, text, r, g, b)
	local btn = CreateFrame("Button", nil, parent, BackdropTemplateMixin and "BackdropTemplate")
	btn:SetSize(width, 26)
	local bg = btn:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(r, g, b, 0.95)
	btn.text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	btn.text:SetPoint("CENTER")
	btn.text:SetText(text)
	return btn
end

local frame
local function build()
	if frame then return frame end

	local releases = unseen_releases()

	local f = CreateFrame("Frame", "XLootWhatsNewFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
	f:SetSize(520, 490)
	f:SetPoint("CENTER")
	-- Above the options window's DIALOG strata so it isn't hidden behind it.
	f:SetFrameStrata("FULLSCREEN_DIALOG")
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	f:SetClampedToScreen(true)
	f:Hide()

	f:SetBackdrop({
		-- Solid fill, the tooltip background texture stays see-through even at full backdrop alpha
		bgFile = "Interface\\Buttons\\WHITE8X8",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true, tileSize = 16, edgeSize = 14,
		insets = { left = 4, right = 4, top = 4, bottom = 4 },
	})
	f:SetBackdropColor(0.03, 0.03, 0.03, 1)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	f.title:SetPoint("TOPLEFT", 16, -14)
	f.title:SetText(#releases > 1 and POPUP_TITLE or (POPUP_TITLE.." "..releases[1].version))

	f.byline = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.byline:SetPoint("BOTTOMRIGHT", -14, 74)
	f.byline:SetJustifyH("RIGHT")
	f.byline:SetText("|cff808080Maintained by Wheelbarrel00 · originally by Xuerian|r")

	local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
	scroll:SetPoint("TOPLEFT", 14, -44)
	scroll:SetPoint("BOTTOMRIGHT", -34, 94)
	local body = CreateFrame("Frame", nil, scroll)
	body:SetSize(scroll:GetWidth(), 1)
	scroll:SetScrollChild(body)
	f.body = body:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.body:SetPoint("TOPLEFT", 0, 0)
	f.body:SetPoint("TOPRIGHT", 0, 0)
	f.body:SetJustifyH("LEFT")
	f.body:SetJustifyV("TOP")
	f.body:SetSpacing(3)
	f.body:SetText(build_body(releases))
	body:SetHeight(f.body:GetStringHeight() + 12)

	-- Mark seen on an explicit close (button, X, or Escape) but NOT when an ancestor
	-- hide (cinematic, Alt-Z) fires OnHide while our own shown flag is still set.
	-- OnHide is set after the initial Hide above so building never marks it prematurely.
	f:SetScript("OnHide", function(self) if not self:IsShown() then mark_seen() end end)
	table.insert(UISpecialFrames, "XLootWhatsNewFrame")

	local function dismiss()
		f:Hide()
	end

	f.close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	f.close:SetPoint("TOPRIGHT", -4, -4)
	f.close:SetScript("OnClick", dismiss)

	f.dontShow = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
	f.dontShow:SetSize(22, 22)
	f.dontShow:SetPoint("BOTTOMLEFT", 14, 46)
	f.dontShow.text = f.dontShow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.dontShow.text:SetPoint("LEFT", f.dontShow, "RIGHT", 2, 0)
	f.dontShow.text:SetText("Don't show these again")
	f.dontShow:SetScript("OnShow", function(self) self:SetChecked(XLoot.opt.whatsnew_mode == "none") end)
	f.dontShow:SetScript("OnClick", function(self)
		XLoot.opt.whatsnew_mode = self:GetChecked() and "none" or "popup"
		local reg = LibStub("AceConfigRegistry-3.0", true)
		if reg then reg:NotifyChange("XLoot") end
	end)
	f.dontShow:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText("Stops What's New notices entirely. You can turn them back on in /xloot.", nil, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	f.dontShow:SetScript("OnLeave", function() GameTooltip:Hide() end)

	f.optBtn = make_button(f, 150, "XLoot options", 0.10, 0.10, 0.10)
	f.optBtn:SetPoint("BOTTOMLEFT", 14, 14)
	f.optBtn:SetScript("OnClick", function()
		dismiss()
		XLoot:ShowOptionPanel(XLoot)
	end)

	f.gotBtn = make_button(f, 110, "Got it", 0.16, 0.34, 0.14)
	f.gotBtn:SetPoint("BOTTOMRIGHT", -14, 14)
	f.gotBtn:SetScript("OnClick", dismiss)

	f.discordBtn = make_button(f, 150, "Join our Discord!", 0.10, 0.10, 0.10)
	f.discordBtn:SetPoint("BOTTOM", 0, 14)
	f.discordBtn:SetScript("OnClick", function() XLoot:ShowDiscord() end)

	frame = f
	return f
end

function XLoot:ShowWhatsNew()
	build():Show()
end

function XLoot:CheckWhatsNew()
	if not self.opt then return end
	if self.opt.whatsnew == false then          -- migrate the pre-mode opt-out to "None"
		self.opt.whatsnew_mode, self.opt.whatsnew = "none", nil
	end
	local mode = self.opt.whatsnew_mode
	if mode == "none" then return end
	local chat = mode == "chat"
	if (chat and already_announced()) or (not chat and already_seen()) then return end
	C_Timer.After(3, function()
		if not self.opt or self.opt.whatsnew_mode == "none" then return end
		if self.opt.whatsnew_mode == "chat" then
			if not already_announced() then
				announce_chat()
				mark_announced()
			end
		elseif not already_seen() then
			self:ShowWhatsNew()
		end
	end)
end

