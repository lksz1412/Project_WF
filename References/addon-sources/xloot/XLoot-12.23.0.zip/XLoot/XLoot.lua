---@class XLootAddon: AceAddon
local XLoot = LibStub("AceAddon-3.0"):NewAddon(select(2, ...), "XLoot")
_G.XLoot = XLoot
local L = XLoot.L
local print, wprint = print, print

_G.BINDING_NAME_XLOOT_TOGGLE_SPEEDY = L.binding_toggle_speedy

local defaults = {
	profile = {
		skin = "smooth",
		skin_anchors = false,
		tooltip_sell = false,
		value_coin_icons = false,
		minimap_icon = false,
		minimap = { hide = true },
		whatsnew_mode = "popup",
	},
	global = {
		whatsnew_seen = "",
		whatsnew_announced = "",
	}
}

XLoot.DISCORD_URL = "https://discord.gg/vm8K2WfQUE"

-- Forever runs the retail engine but reports its own project ID, WOW_PROJECT_CAMELOT, since build 70170.
XLoot.IS_RETAIL_ENGINE = WOW_PROJECT_ID == WOW_PROJECT_MAINLINE or WOW_PROJECT_ID == WOW_PROJECT_CAMELOT

StaticPopupDialogs["XLOOT_DISCORD"] = {
	text = L.discord_popup,
	button1 = CLOSE,
	hasEditBox = true,
	editBoxWidth = 220,
	OnShow = function(self)
		local eb = self.editBox or self.EditBox
		if eb then
			eb:SetText(XLoot.DISCORD_URL)
			eb:HighlightText()
			eb:SetFocus()
			eb:SetScript("OnEscapePressed", function(b) b:GetParent():Hide() end)
			eb:SetScript("OnTextChanged", function(b)
				if b:GetText() ~= XLoot.DISCORD_URL then
					b:SetText(XLoot.DISCORD_URL)
					b:HighlightText()
				end
			end)
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
	preferredIndex = 3,
}

function XLoot:ShowDiscord()
	StaticPopup_Show("XLOOT_DISCORD")
end

local _NewModule = XLoot.NewModule
---@return XLootModule module
---@return table localization
function XLoot:NewModule(module_name, ...)
	local new = _NewModule(self, module_name, ...)
	return new, self["L_"..module_name]
end

local _GetModule = XLoot.GetModule
function XLoot:GetModule(module_name, ...)
	return module_name == "Core" and XLoot or _GetModule(self, module_name, ...)
end

local function SetEventHandler(addon, frame)
	if not frame then
		frame = CreateFrame("Frame")
		addon.eframe = frame
	end
	frame:SetScript("OnEvent", function(self, event, ...)
		if addon[event] then
			addon[event](addon, ...)
		end
	end)
end

XLoot.slash_commands = {}
function XLoot:SetSlashCommand(slash, func)
	local key = "XLOOT_"..slash
	_G["SLASH_"..key.."1"] = "/"..slash
	_G.SlashCmdList[key] = func
end

local options_after_combat

function XLoot:ShowOptionPanel(module)
	-- Blizzard blocks addons from opening the Settings panel in combat.
	if InCombatLockdown() then
		if not options_after_combat then
			options_after_combat = CreateFrame("Frame")
			options_after_combat:SetScript("OnEvent", function(frame)
				frame:UnregisterEvent("PLAYER_REGEN_ENABLED")
				-- Opening wipes the unapplied changes of a Settings panel the player opened during combat.
				if not (SettingsPanel and SettingsPanel:IsShown()) then
					XLoot:ShowOptionPanel(frame.module)
				end
			end)
		end
		if not options_after_combat:IsEventRegistered("PLAYER_REGEN_ENABLED") then
			print("|c2244dd22XLoot|r "..L.options_after_combat)
		end
		options_after_combat.module = module
		options_after_combat:RegisterEvent("PLAYER_REGEN_ENABLED")
		return
	end
	if not XLootOptions then
		C_AddOns.EnableAddOn("XLoot_Options")
		local loaded, reason = C_AddOns.LoadAddOn("XLoot_Options")
		if not loaded or not XLootOptions then
			wprint(("|c2244dd22XLoot|r could not load its options panel (%s)."):format(reason or "XLoot_Options loaded but did not initialize"))
			return
		end
	end
	XLootOptions:OpenPanel(module)
end

local function SpeedyProfile()
	local frame = XLoot:GetModule("Frame", true)
	return frame and frame.db and frame.db.profile
end

function XLoot.SpeedyAutolootText()
	local profile = SpeedyProfile()
	if profile then
		local state = profile.speedy_autoloot and ("|cff20ff20%s|r"):format(L.state_on) or ("|cffff4040%s|r"):format(L.state_off)
		return L.speedy_state:format(state)
	end
end

function XLoot:ToggleSpeedyAutoloot(on)
	local profile = SpeedyProfile()
	if not profile then
		print("|c2244dd22XLoot|r "..L.speedy_unavailable)
		return
	end
	if on == nil then
		on = not profile.speedy_autoloot
	end
	profile.speedy_autoloot = on
	local registry = LibStub("AceConfigRegistry-3.0", true)
	if registry then
		registry:NotifyChange("XLoot")
	end
	print("|c2244dd22XLoot|r "..self:SpeedyAutolootText())
end

function XLoot:ApplyOptions(in_options)
	self.opt = self.db.profile
	XLoot:SetSkin(self.opt.skin)
	for _,v in ipairs(XLoot.skinners) do
		v:Reskin()
	end
	for k,v in pairs(XLoot.modules) do
		if v.db then
			v.opt = v.db.profile
		end
		if v.ApplyOptions then
			v:ApplyOptions(in_options)
		end
	end
	self:UpdateMinimapIcon()
end

---@class XLootModule: AceAddon
local XLootModule = {
	opt = {},
	InitializeModule = function(self, defaults, frame)
		local module_name = self:GetName()
		self.db = XLoot.db:RegisterNamespace(module_name, defaults)
		self.opt = self.db.profile

		function self.ShowOptions()
			XLoot:ShowOptionPanel(self)
		end
		XLoot:SetSlashCommand(("XLoot"..module_name):lower(), self.ShowOptions)
		self:SetEventHandler(frame)
	end,
	SetEventHandler = SetEventHandler,
}
XLoot:SetDefaultModulePrototype(XLootModule)

function XLoot.Prototype_New(self, new)
	local new = new or {}
	for k,v in pairs(self) do
		if k ~= "New" and k ~= "_New" then
			if new[k] ~= nil then
				new['_'..k] = new[k]
			end
			rawset(new, k, v)
		end
	end
	return new
end

function XLoot.NewPrototype()
	return { New = XLoot.Prototype_New, _New = XLoot.Prototype_New }
end

-- Not registered as "ApplyOptions" directly: CallbackHandler passes the event name as the first argument, which ApplyOptions would read as a truthy in_options.
function XLoot:ProfileChanged()
	self:ApplyOptions(true)
end

function XLoot:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("XLootADB", defaults, true)
	self.opt = self.db.profile
	self.db.RegisterCallback(self, "OnProfileChanged", "ProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "ProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "ProfileChanged")
	self:SkinsOnInitialize()
end

function XLoot:OnEnable()
	for _,name in ipairs({ "XLoot1.0", "XLootGroup", "XLootMaster", "XLootMonitor" }) do
		if C_AddOns.IsAddOnLoaded(name) then
			C_AddOns.DisableAddOn(name)
			wprint(("|c2244dd22XLoot|r now includes |c2244dd22%s|r - the old version will be disabled on next load, and no longer needs to be installed."):format(name))
		end
	end

	-- Loaded at login rather than on demand: a packaged build ships Options as a LoadOnDemand sibling, and its OnEnable is what registers XLoot in the Blizzard Settings AddOns list.
	C_AddOns.EnableAddOn("XLoot_Options")
	C_AddOns.LoadAddOn("XLoot_Options")
	self:SetSlashCommand("xloot", function() self:ShowOptionPanel(self) end)
	self:SetSlashCommand("xlspeedy", function(msg)
		msg = (msg or ""):lower():match("^%s*(.-)%s*$")
		if msg == "" then
			self:ToggleSpeedyAutoloot()
		elseif msg == "on" or msg == "off" then
			self:ToggleSpeedyAutoloot(msg == "on")
		else
			print("|c2244dd22XLoot|r "..L.speedy_usage)
		end
	end)

	self:SetupMinimapIcon()
	self:CheckWhatsNew()
end

