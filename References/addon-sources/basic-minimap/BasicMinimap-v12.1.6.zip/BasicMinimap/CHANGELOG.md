# BasicMinimap

## [v12.1.6](https://github.com/funkydude/BasicMinimap/tree/v12.1.6) (2026-10-22)
[Full Changelog](https://github.com/funkydude/BasicMinimap/compare/v12.1.5...v12.1.6) [Previous Releases](https://github.com/funkydude/BasicMinimap/releases)

- Cleanups  
