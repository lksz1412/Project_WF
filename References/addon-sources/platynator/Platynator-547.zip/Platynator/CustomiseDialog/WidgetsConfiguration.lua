---@class addonTablePlatynator
local addonTable = select(2, ...)

local LSM = LibStub("LibSharedMedia-3.0")

local textureHeight = 20

local function GetLabelsValues(allAssets, filter, showName, widthMod)
  widthMod = widthMod or 1
  local labels, values = {}, {}

  local allKeys = GetKeysArray(allAssets)
  table.sort(allKeys, function(a, b)
    local aGroup, bGroup = allAssets[a].group, allAssets[b].group
    local aOrder, bOrder = allAssets[a].order or 0, allAssets[b].order or 0
    if aOrder then
      if aGroup == bGroup then
        return aOrder < bOrder
      else
        return aGroup < bGroup
      end
    end
    return a < b
  end)

  for _, key in ipairs(allKeys) do
    if not filter or filter(allAssets[key]) then
      local details = allAssets[key]
      local height = textureHeight
      local width = details.width * height/details.height * widthMod
      if width > 180 then
        height = 180/width * height
        width = 180
      end
      local text = "|T".. (details.preview or details.file or details.horizontal) .. ":" .. (height - 1) .. ":" .. (width - 1) .. "|t"
      if details.text then
        text = text .. " " .. details.text
      end
      if showName then
        text = text .. " " ..  (key:gsub("Platy: ", ""))
      end
      if details.isTransparent then
        text = addonTable.Locales.NONE
      end
      if details.mode == addonTable.Assets.Mode.Special then
        text = text .. " " .. addonTable.Locales.SPECIAL_BRACKETS
      end

      table.insert(labels, text)
      table.insert(values, key)
    end
  end

  return labels, values
end

local function GetLabelsValuesBackgrounds()
  local labels, values = {}, {}
  local assets = LSM:List("statusbar")

  local height = textureHeight
  local width = addonTable.Assets.BarBordersSize.width * height / addonTable.Assets.BarBordersSize.height

  local mouseAssets = tFilter(assets, function(a) return a:match("^MM: ") end, true)
  table.sort(mouseAssets)
  for _, key in ipairs(mouseAssets) do
    local file = LSM:Fetch("statusbar", key)
    local text = "|T".. file .. ":" .. (height - 1) .. ":" .. (width - 1) .. "|t " .. (key:gsub("MM: ", ""))
    if key == "MM: Solid Transparency" then
      text = addonTable.Locales.NONE
    end

    table.insert(labels, text)
    table.insert(values, key)
  end

  local otherAssets = tFilter(assets, function(a) return not a:match("^MM: ") end, true)
  table.sort(otherAssets)
  for _, key in ipairs(otherAssets) do
    local file = LSM:Fetch("statusbar", key)
    local text = "|T".. file .. ":" .. (height - 1) .. ":" .. (width - 1) .. "|t [Custom] " .. key

    table.insert(labels, text)
    table.insert(values, key)
  end

  return labels, values
end

local function GetLabelsValuesBorders()
  local labels, values = {}, {}
  local assets = LSM:List("ninesliceborder")

  local height = textureHeight

  local mouseAssets = tFilter(assets, function(a) return a:match("^MM: ") end, true)
  table.sort(mouseAssets)
  for _, key in ipairs(mouseAssets) do
    local file = LSM:Fetch("nineslice", LSM:Fetch("ninesliceborder", key).nineslice).file
    local text = "|T".. file .. ":" .. (height - 1) .. ":" .. (height - 1) .. "|t " .. (key:gsub("MM: ", ""))
    if key == "MM: Transparent" then
      text = addonTable.Locales.NONE
    end

    table.insert(labels, text)
    table.insert(values, key)
  end

  local otherAssets = tFilter(assets, function(a) return not a:match("^MM: ") end, true)
  table.sort(otherAssets)
  for _, key in ipairs(otherAssets) do
    local border = LSM:Fetch("ninesliceborder", key)
    local slice = LSM:Fetch("nineslice", border.nineslice)
    if slice then
      local file = slice.file
      local text = "|T".. file .. ":" .. (height - 1) .. ":" .. (height - 1) .. "|t [Custom] " .. key

      table.insert(labels, text)
      table.insert(values, key)
    end
  end

  return labels, values
end

local function GetLabelsValuesHighlightsAnimated()
  local labels, values = {}, {}

  local height = textureHeight - 1
  local width = addonTable.Assets.BarBordersSize.width * height / addonTable.Assets.BarBordersSize.height

  local allKeys = tFilter(GetKeysArray(addonTable.Assets.Highlights), function(a)
    local assetDetails = addonTable.Assets.Highlights[a]
    return assetDetails.kind and assetDetails.kind:match("^animated")
  end, true)

  table.sort(allKeys)

  for _, key in ipairs(allKeys) do
    local file = addonTable.Assets.Highlights[key].preview
    local text = "|T".. file .. ":" .. height .. ":" .. width .. "|t " .. (key:gsub("Platy: ", ""))

    table.insert(labels, text)
    table.insert(values, {sliced = nil, asset = key})
  end

  return labels, values
end

local function GetLabelsValuesHighlightsNotAnimated()
  local labels, values = {}, {}
  local slicedAssets = LSM:List("nineslice")
  local regularAssets = LSM:List("platynator/sizedtexture")

  local mouseSlicedAssets = tFilter(slicedAssets, function(a) return a:match("^MM: ") end, true)
  local mouseRegularAssets = tFilter(regularAssets, function(a) return a:match("^MM: ") end, true)

  local together = {}
  for _, key in ipairs(mouseSlicedAssets) do
    table.insert(together, {sliced = true, asset = key})
  end
  for _, key in ipairs(mouseRegularAssets) do
    table.insert(together, {sliced = false, asset = key})
  end
  table.sort(together, function(a, b)
    return a.asset < b.asset
  end)

  local height = textureHeight - 1

  local seen = {}

  for _, keyDetails in ipairs(together) do
    seen[keyDetails.asset] = true
    if keyDetails.sliced then
      if keyDetails.asset ~= "MM: Transparent" then
        local assetDetails = LSM:Fetch("nineslice", keyDetails.asset)
        assert(assetDetails)
        local width = assetDetails.previewWidth * height/assetDetails.previewHeight
        local text = "|T".. assetDetails.file .. ":" .. height .. ":" .. width .. "|t " .. (keyDetails.asset:gsub("MM: ", ""))

        table.insert(labels, text)
        table.insert(values, {sliced = true, asset = keyDetails.asset})
      end
    else
      local details = LSM:Fetch("platynator/sizedtexture", keyDetails.asset)
      assert(details)

      local width = details.width * height/details.height
      if width > 180 then
        height = 180/width * height
        width = 180
      end

      local text = "|T".. details.file .. ":" .. height .. ":" .. width .. "|t " .. (keyDetails.asset:gsub("MM: ", ""))

      table.insert(labels, text)
      table.insert(values, {sliced = false, asset = keyDetails.asset})
    end
  end

  for _, key in ipairs(slicedAssets) do
    if not seen[key] then
      local file = LSM:Fetch("nineslice", key).file
      local text = "|T".. file .. ":" .. height .. ":" .. height .. "|t [Custom] " .. key

      table.insert(labels, text)
      table.insert(values, {sliced = true, asset = key})
    end
  end

  for _, key in ipairs(regularAssets) do
    if not seen[key] then
      local details = LSM:Fetch("platynator/sizedtexture", key)
      assert(details)

      local width = details.width * height/details.height
      if width > 180 then
        height = 180/width * height
        width = 180
      end

      local text = "|T".. details.file .. ":" .. height .. ":" .. width .. "|t [Custom] " .. key

      table.insert(labels, text)
      table.insert(values, {sliced = false, asset = key})
    end
  end

  return labels, values
end

local function GetLabelsValuesSparks()
  local labels, values = {}, {}
  local regularAssets = LSM:List("spark")

  local mouseRegularAssets = tFilter(regularAssets, function(a) return a:match("^MM: ") end, true)
  table.sort(mouseRegularAssets)

  local height = textureHeight - 1

  local seen = {}

  for _, asset in ipairs(mouseRegularAssets) do
    seen[asset] = true
    local details = LSM:Fetch("spark", asset)
    assert(details)

    local width = details.width * height/(125/8)
    if width > 180 then
      height = 180/width * height
      width = 180
    end

    local text = "|T".. details.file .. ":" .. height .. ":" .. width .. "|t " .. (asset:gsub("MM: ", ""))

    if asset == "MM: Transparency" then
      text = addonTable.Locales.NONE
    end

    table.insert(labels, text)
    table.insert(values, asset)
  end

  for _, key in ipairs(regularAssets) do
    if not seen[key] then
      local details = LSM:Fetch("spark", key)
      assert(details)

      local width = details.width * height/(125/8)
      if width > 180 then
        height = 180/width * height
        width = 180
      end

      local text = "|T".. details.file .. ":" .. height .. ":" .. width .. "|t [Custom] " .. key

      table.insert(labels, text)
      table.insert(values, {sliced = false, asset = key})
    end
  end

  return labels, values
end

local multipleValuesDisplay = {
  label = addonTable.Locales.MULTIPLE_VALUES_DISPLAY,
  kind = "dropdown",
  getInitData = function(_)
    return {
      "11 (22)",
      "11 | 22",
      "11 - 22",
      "11 22",
    }, {
        "%s (%s)",
        "%s | %s",
        "%s - %s",
        "%s %s",
      }
  end,
  setter = function(details, value)
    details.formatMultiple = value
  end,
  getter = function(details)
    return details.formatMultiple
  end
}

local energyTypes = {
  {
    label = addonTable.Locales.ENERGY,
    kind = "checkbox",
    setter = function(details, value)
      details.powerTypes.energy = value
    end,
    getter = function(details)
      return details.powerTypes.energy
    end,
  },
  {
    label = addonTable.Locales.MANA,
    kind = "checkbox",
    setter = function(details, value)
      details.powerTypes.mana = value
    end,
    getter = function(details)
      return details.powerTypes.mana
    end,
  },
  {
    label = addonTable.Locales.RAGE,
    kind = "checkbox",
    setter = function(details, value)
      details.powerTypes.rage = value
    end,
    getter = function(details)
      return details.powerTypes.rage
    end,
  },
}
local energyMobs = {
  {
    label = addonTable.Locales.BOSS,
    kind = "checkbox",
    setter = function(details, value)
      details.mobTypes.boss = value
    end,
    getter = function(details)
      return details.mobTypes.boss
    end,
  },
  {
    label = addonTable.Locales.MINIBOSS,
    kind = "checkbox",
    setter = function(details, value)
      details.mobTypes.miniboss = value
    end,
    getter = function(details)
      return details.mobTypes.miniboss
    end,
  },
}

local defaultHighlight = {
  label = addonTable.Locales.GENERAL,
  entries = {
    {
      label = addonTable.Locales.HEIGHT,
      kind = "slider",
      min = 50, max = 600,
      valuePattern = "%d%%",
      setter = function(details, value)
        details.height = value / 100
      end,
      getter = function(details)
        return details.height * 100
      end,
    },
    {
      label = addonTable.Locales.WIDTH,
      kind = "slider",
      min = 15, max = 300,
      valuePattern = "%d%%",
      setter = function(details, value)
        details.width = value / 100
      end,
      getter = function(details)
        return details.width * 100
      end,
    },
    {
      label = addonTable.Locales.VISUAL,
      kind = "dropdown",
      getInitData = function(details)
        if details.kind:match("^animated") then
          return GetLabelsValuesHighlightsAnimated()
        else
          return GetLabelsValuesHighlightsNotAnimated()
        end
      end,
      setter = function(details, value)
        details.sliced = value.sliced
        details.asset = value.asset
      end,
      getter = function(details)
        if details.kind:match("^animated") then
          return {asset = details.asset}
        else
          return {sliced = details.sliced, asset = details.asset}
        end
      end
    },
    {
      label = addonTable.Locales.COLOR,
      kind = "colorPicker",
      setter = function(details, value)
        details.color = value
      end,
      getter = function(details)
        return details.color
      end,
    },
  }
}

local mouseoverHighlight = CopyTable(defaultHighlight)
table.insert(mouseoverHighlight.entries, { kind = "spacer" })
table.insert(mouseoverHighlight.entries,
  {
    label = addonTable.Locales.INCLUDE_TARGET,
    kind = "checkbox",
    setter = function(details, value)
      details.includeTarget = value
    end,
    getter = function(details)
      return details.includeTarget
    end,
  }
)

local animatedBorderHighlight = CopyTable(defaultHighlight)
table.insert(animatedBorderHighlight.entries, { kind = "spacer" })
table.insert(animatedBorderHighlight.entries,
  {
    label = addonTable.Locales.BORDER_WIDTH,
    kind = "slider",
    min = 50, max = 500,
    valuePattern = "%d%%",
    setter = function(details, value)
      details.borderWidth = value / 100
    end,
    getter = function(details)
      return details.borderWidth * 100
    end,
  }
)

local flashingHighlight = CopyTable(defaultHighlight)
table.insert(flashingHighlight.entries, { kind = "spacer" })
table.insert(flashingHighlight.entries,
  {
    label = addonTable.Locales.SPEED,
    kind = "slider",
    min = 10, max = 500,
    valuePattern = "%d%%",
    setter = function(details, value)
      details.speed = value / 100
    end,
    getter = function(details)
      return details.speed * 100
    end,
  }
)

addonTable.CustomiseDialog.WidgetsConfig = {
  ["bars"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 1, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.HEIGHT,
            kind = "slider",
            min = 50, max = 300,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              details.border.height = value / 100
            end,
            getter = function(details)
              return details.border.height * 100
            end,
          },
          {
            label = addonTable.Locales.WIDTH,
            kind = "slider",
            min = 50, max = 300,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              details.border.width = value / 100
            end,
            getter = function(details)
              return details.border.width * 100
            end,
          },
        },
      },
      {
        label = addonTable.Locales.TEXTURES,
        entries = {
          {
            label = addonTable.Locales.BORDER,
            kind = "dropdown",
            getInitData = function(details)
              return GetLabelsValuesBorders()
            end,
            setter = function(details, value)
              details.border.asset = value
            end,
            getter = function(details)
              return details.border.asset
            end
          },
          {
            label = addonTable.Locales.BORDER_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.border.color = value
            end,
            getter = function(details)
              return details.border.color
            end,
          },
          {
            label = addonTable.Locales.FOREGROUND,
            kind = "dropdown",
            getInitData = function()
              return GetLabelsValuesBackgrounds()
            end,
            setter = function(details, value)
              details.foreground.asset = value
            end,
            getter = function(details)
              return details.foreground.asset
            end
          },
          {
            label = addonTable.Locales.BACKGROUND,
            kind = "dropdown",
            getInitData = function()
              return GetLabelsValuesBackgrounds()
            end,
            setter = function(details, value)
              details.background.asset = value
            end,
            getter = function(details)
              return details.background.asset
            end
          },
          {
            label = addonTable.Locales.BACKGROUND_COLOR,
            kind = "colorPickerWithCheckbox",
            setter = function(details, value)
              details.background.color = value.color
              details.background.applyColor = not value.enabled
            end,
            getter = function(details)
              return {color = details.background.color, enabled = not details.background.applyColor}
            end,
          },
          {
            label = addonTable.Locales.SPARK,
            kind = "dropdown",
            getInitData = function(details)
              return GetLabelsValuesSparks()
            end,
            setter = function(details, value)
              details.marker.asset = value
            end,
            getter = function(details)
              return details.marker.asset
            end,
          },
          {
            label = addonTable.Locales.SPARK_COLOR,
            kind = "colorPickerWithCheckbox",
            setter = function(details, value)
              details.marker.color = value.color
              details.marker.applyColor = not value.enabled
            end,
            getter = function(details)
              return {color = details.marker.color, enabled = not details.marker.applyColor}
            end,
          },
        }
      },
    },
    ["health"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.ANIMATE_X,
            kind = "checkbox",
            setter = function(details, value)
              details.animate = value
            end,
            getter = function(details)
              return details.animate
            end,
          },
        }
      },
      {
        label = addonTable.Locales.TEXTURES,
        entries = {
          {
            label = addonTable.Locales.ABSORB,
            kind = "dropdown",
            getInitData = function()
              return GetLabelsValuesBackgrounds()
            end,
            setter = function(details, value)
              details.absorb.asset = value
            end,
            getter = function(details)
              return details.absorb.asset
            end
          },
          {
            label = addonTable.Locales.ABSORB_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.absorb.color = value
            end,
            getter = function(details)
              return details.absorb.color
            end,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {reaction = true},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
    ["cast"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.MARK_INTERRUPT_READY_POINT,
            kind = "checkbox",
            setter = function(details, value)
              details.interruptMarker.asset = value and "MM: Glow" or "MM: Transparency"
            end,
            getter = function(details)
              return details.interruptMarker.asset ~= "MM: Transparency"
            end,
          },
          {
            label = addonTable.Locales.INTERRUPT_POINT_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.interruptMarker.color = value
            end,
            getter = function(details)
              return details.interruptMarker.color
            end,
          },
        },
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {cast = true},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
    ["energy"] = {
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {energy = true},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
      {
        label = addonTable.Locales.TYPES,
        entries = energyTypes,
      },
      {
        label = addonTable.Locales.MOBS,
        entries = energyMobs,
      },
    },
  },
  ["texts"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 1, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.WIDTH_RESTRICTION,
            kind = "slider",
            min = 0, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.maxWidth = value / 100
            end,
            getter = function(details)
              return details.maxWidth * 100
            end,
          },
          {
            label = addonTable.Locales.ALIGNMENT,
            kind = "dropdown",
            getInitData = function()
              return {
                addonTable.Locales.CENTER,
                addonTable.Locales.LEFT,
                addonTable.Locales.RIGHT,
              }, {
                "CENTER",
                "LEFT",
                "RIGHT",
              }
            end,
            setter = function(details, value)
              details.align = value
            end,
            getter = function(details)
              return details.align
            end
          },
          {
            label = addonTable.Locales.TRUNCATE,
            kind = "checkbox",
            setter = function(details, value)
              details.truncate = value
            end,
            getter = function(details)
              return details.truncate
            end,
          },
          {
            label = addonTable.Locales.COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.color = value
            end,
            getter = function(details)
              return details.color
            end,
          },
        }
      },
    },
    ["health"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.HIDE_WHEN_01,
            kind = "checkbox",
            setter = function(details, value)
              details.hideWhen01 = value
            end,
            getter = function(details)
              return details.hideWhen01
            end,
          },
        },
      },
      {
        label = addonTable.Locales.VALUES,
        entries = {
          {
            label = addonTable.Locales.ABSOLUTE,
            kind = "checkbox",
            setter = function(details, value)
              if value and tIndexOf(details.displayTypes, "absolute") == nil then
                table.insert(details.displayTypes, 1, "absolute")
              elseif not value then
                local index = tIndexOf(details.displayTypes, "absolute")
                if index then
                  table.remove(details.displayTypes, index)
                end
              end
            end,
            getter = function(details)
              return tIndexOf(details.displayTypes, "absolute") ~= nil
            end,
          },
          {
            label = addonTable.Locales.ABBREVIATE_LARGE_VALUES,
            kind = "checkbox",
            setter = function(details, value)
              details.abbreviate = value
            end,
            getter = function(details)
              return details.abbreviate
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.PERCENTAGE,
            kind = "checkbox",
            setter = function(details, value)
              if value and tIndexOf(details.displayTypes, "percentage") == nil then
                table.insert(details.displayTypes, 1, "percentage")
              elseif not value then
                local index = tIndexOf(details.displayTypes, "percentage")
                if index then
                  table.remove(details.displayTypes, index)
                end
              end
            end,
            getter = function(details)
              return tIndexOf(details.displayTypes, "percentage") ~= nil
            end,
          },
          {
            label = addonTable.Locales.SIGNIFICANT_FIGURES,
            kind = "slider",
            min = 0, max = 4,
            formatter = function(value)
              if value == 0 then
                return addonTable.Locales.ROUNDED
              else
                return tostring(value + 1)
              end
            end,
            setter = function(details, value)
              if value == 0 then
                details.significantFigures = value
              else
                details.significantFigures = value + 1
              end
            end,
            getter = function(details)
              if details.significantFigures == 0 then
                return details.significantFigures
              else
                return details.significantFigures - 1
              end
            end,
          },
          {
            label = addonTable.Locales.SHOW_PERCENT_SYMBOL,
            kind = "checkbox",
            setter = function(details, value)
              details.showPercentSymbol = value
            end,
            getter = function(details)
              return details.showPercentSymbol
            end,
          },
          { kind = "spacer" },
          multipleValuesDisplay,
        }
      }
    },
    ["damageAbsorb"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.ABBREVIATE_LARGE_VALUES,
            kind = "checkbox",
            setter = function(details, value)
              details.abbreviate = value
            end,
            getter = function(details)
              return details.abbreviate
            end,
          },
        }
      }
    },
    ["creatureName"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_WHEN_WOW_DOES,
            kind = "checkbox",
            setter = function(details, value)
              details.showWhenWowDoes = value
            end,
            getter = function(details)
              return details.showWhenWowDoes
            end,
          },
          {
            label = addonTable.Locales.SHOW_FIRST_NAME_ONLY,
            kind = "checkbox",
            setter = function(details, value)
              details.showFirstNameOnly = value
            end,
            getter = function(details)
              return details.showFirstNameOnly
            end,
            hide = not addonTable.Constants.IsForever,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      }
    },
    ["target"] = {
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = addonTable.Locales.CLASS_COLORED,
            kind = "checkbox",
            setter = function(details, value)
              details.applyClassColors = value
            end,
            getter = function(details)
              return details.applyClassColors
            end,
          },
        }
      }
    },
    ["castSpellName"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_ON_INTERRUPT,
            kind = "checkbox",
            setter = function(details, value)
              details.showInterrupted = value
            end,
            getter = function(details)
              return details.showInterrupted
            end,
          },
        }
      }
    },
    ["castTarget"] = {
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = addonTable.Locales.CLASS_COLORED,
            kind = "checkbox",
            setter = function(details, value)
              details.applyClassColors = value
            end,
            getter = function(details)
              return details.applyClassColors
            end,
          },
        }
      }
    },
    ["castInterrupter"] = {
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = addonTable.Locales.CLASS_COLORED,
            kind = "checkbox",
            setter = function(details, value)
              details.applyClassColors = value
            end,
            getter = function(details)
              return details.applyClassColors
            end,
          },
        }
      }
    },
    ["level"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_MODIFIERS_BRACKETS_EXAMPLES,
            kind = "checkbox",
            setter = function(details, value)
              details.showModifiers = value
            end,
            getter = function(details)
              return details.showModifiers
            end,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      }
    },
    ["guild"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_WHEN_WOW_DOES,
            kind = "checkbox",
            setter = function(details, value)
              details.showWhenWowDoes = value
            end,
            getter = function(details)
              return details.showWhenWowDoes
            end,
          },
        }
      },
      {
        label = addonTable.Locales.VALUES,
        entries = {
          {
            label = addonTable.Locales.PLAYER_GUILD,
            kind = "checkbox",
            setter = function(details, value)
              details.playerGuild = value
            end,
            getter = function(details)
              return details.playerGuild
            end,
          },
          {
            label = addonTable.Locales.NPC_ROLE,
            kind = "checkbox",
            setter = function(details, value)
              details.npcRole = value
            end,
            getter = function(details)
              return details.npcRole
            end,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      }
    },
    ["mythicPlusForces"] = {
      {
        label = addonTable.Locales.VALUES,
        entries = {
          {
            label = addonTable.Locales.ABSOLUTE,
            kind = "checkbox",
            setter = function(details, value)
              if value and tIndexOf(details.displayTypes, "absolute") == nil then
                table.insert(details.displayTypes, 1, "absolute")
              elseif not value then
                local index = tIndexOf(details.displayTypes, "absolute")
                if index then
                  table.remove(details.displayTypes, index)
                end
              end
            end,
            getter = function(details)
              return tIndexOf(details.displayTypes, "absolute") ~= nil
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.PERCENTAGE,
            kind = "checkbox",
            setter = function(details, value)
              if value and tIndexOf(details.displayTypes, "percentage") == nil then
                table.insert(details.displayTypes, 1, "percentage")
              elseif not value then
                local index = tIndexOf(details.displayTypes, "percentage")
                if index then
                  table.remove(details.displayTypes, index)
                end
              end
            end,
            getter = function(details)
              return tIndexOf(details.displayTypes, "percentage") ~= nil
            end,
          },
          {
            label = addonTable.Locales.SHOW_PERCENT_SYMBOL,
            kind = "checkbox",
            setter = function(details, value)
              details.showPercentSymbol = value
            end,
            getter = function(details)
              return details.showPercentSymbol
            end,
          },
          { kind = "spacer" },
          multipleValuesDisplay,
        }
      }
    },
    ["energy"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_PERCENT_SYMBOL,
            kind = "checkbox",
            setter = function(details, value)
              details.showPercentSymbol = value
            end,
            getter = function(details)
              return details.showPercentSymbol
            end,
          },
        },
      },
      {
        label = addonTable.Locales.TYPES,
        entries = energyTypes,
      },
      {
        label = addonTable.Locales.MOBS,
        entries = energyMobs,
      },
    },
    ["threat"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.ONLY_SHOW_WHEN_IN_GROUP,
            kind = "checkbox",
            setter = function(details, value)
              details.showWhenGrouped = value
            end,
            getter = function(details)
              return details.showWhenGrouped
            end,
          },
        },
      },
      {
        label = addonTable.Locales.VALUE,
        entries = {
          {
            label = addonTable.Locales.PERCENTAGE,
            kind = "dropdown",
            getInitData = function()
              return {
                addonTable.Locales.RAW,
                addonTable.Locales.SCALED,
              }, {
                "raw",
                "scaled",
              }
            end,
            setter = function(details, value)
              details.value = value
            end,
            getter = function(details)
              return details.value
            end
          },
          {
            label = addonTable.Locales.SHOW_PERCENT_SYMBOL,
            kind = "checkbox",
            setter = function(details, value)
              details.showPercentSymbol = value
            end,
            getter = function(details)
              return details.showPercentSymbol
            end,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
    ["threatDifferential"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.ONLY_SHOW_WHEN_IN_GROUP,
            kind = "checkbox",
            setter = function(details, value)
              details.showWhenGrouped = value
            end,
            getter = function(details)
              return details.showWhenGrouped
            end,
          },
        },
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    }
  },
  ["markers"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 1, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.VISUAL,
            kind = "dropdown",
            getInitData = function(details)
              return GetLabelsValues(addonTable.Assets.Markers, function(a) return a.tag == details.kind end)
            end,
            setter = function(details, value)
              details.asset = value
            end,
            getter = function(details)
              return details.asset
            end
          },
          {
            label = addonTable.Locales.COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.color = value
            end,
            getter = function(details)
              return details.color
            end,
          },
        },
      },
    },
    ["castIcon"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SQUARE,
            kind = "checkbox",
            setter = function(details, value)
              details.square = value
            end,
            getter = function(details)
              return details.square
            end,
          }
        }
      },
    },
    ["elite"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_ONLY_IN_OPEN_WORLD,
            kind = "checkbox",
            setter = function(details, value)
              details.openWorldOnly = value
            end,
            getter = function(details)
              return details.openWorldOnly
            end,
          }
        }
      },
    },
    ["rare"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.INCLUDE_ELITE_RARES,
            kind = "checkbox",
            setter = function(details, value)
              details.includeElites = value
            end,
            getter = function(details)
              return details.includeElites
            end,
          }
        }
      },
    },
    ["faction"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_ONLY_FOR_PVP_FLAGGED,
            kind = "checkbox",
            setter = function(details, value)
              details.showForPvPFlagged = value
            end,
            getter = function(details)
              return details.showForPvPFlagged
            end,
          }
        }
      },
    },
  },
  ["auras"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 25, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.HEIGHT,
            kind = "slider",
            min = 25, max = 100,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.height = value / 100
            end,
            getter = function(details)
              return details.height * 100
            end,
          },
          {
            label = addonTable.Locales.PADDING,
            kind = "slider",
            min = 0, max = 200,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.padding = value / 100
            end,
            getter = function(details)
              return details.padding * 100
            end,
          },
          {
            label = addonTable.Locales.DIRECTION,
            kind = "dropdown",
            getInitData = function()
              return {
                addonTable.Locales.CENTER,
                addonTable.Locales.LEFT,
                addonTable.Locales.RIGHT,
              }, {
                "CENTER",
                "LEFT",
                "RIGHT",
              }
            end,
            setter = function(details, value)
              details.direction = value
            end,
            getter = function(details)
              return details.direction
            end
          },
          {
            label = addonTable.Locales.LIMIT_TO,
            kind = "slider",
            min = 1, max = 30,
            valuePattern = addonTable.Locales.X_AURAS,
            setter = function(details, value)
              details.limit = value
            end,
            getter = function(details)
              return details.limit
            end,
          },
          {
            label = addonTable.Locales.SHOW_TOOLTIPS,
            kind = "checkbox",
            setter = function(details, value)
              details.showTooltips = value
            end,
            getter = function(details)
              return details.showTooltips
            end,
          },
        },
      },
      {
        label = addonTable.Locales.VISUAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_TYPE_BORDER,
            kind = "checkbox",
            setter = function(details, value)
              details.showType = value
            end,
            getter = function(details)
              return details.showType
            end,
          },
          {
            label = addonTable.Locales.SHOW_ROTATING_SWIPE,
            kind = "checkbox",
            setter = function(details, value)
              details.showSwipe = value
            end,
            getter = function(details)
              return details.showSwipe
            end,
          },
        }
      },
      {
        label = addonTable.Locales.TEXTS,
        entries = {}
      },
      {
        label = addonTable.Locales.SORTING,
        entries = {
          {
            label = addonTable.Locales.METHOD,
            kind = "dropdown",
            getInitData = function()
              return {
                addonTable.Locales.BLIZZARD,
                addonTable.Locales.DURATION,
              }, {
                "blizzard",
                "duration",
              }
            end,
            setter = function(details, value)
              details.sorting.kind = value
            end,
            getter = function(details)
              return details.sorting.kind
            end
          },
          {
            label = addonTable.Locales.REVERSED,
            kind = "checkbox",
            setter = function(details, value)
              details.sorting.reversed = value
            end,
            getter = function(details)
              return details.sorting.reversed
            end,
          },
        }
      }
    },
    ["debuffs"] = {
      {
        label = addonTable.Locales.TEXTS,
        entries = {
          {
            label = "",
            kind = "auraTextsPositioner",
            icon = 135959,
            setter = function() end,
            getter = function(details)
              return details
            end,
          },
        }
      },
      {
        label = addonTable.Locales.FILTERS,
        entries = {
          {
            label = addonTable.Locales.IMPORTANT,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.important = value
            end,
            getter = function(details)
              return details.filters.important
            end,
            hide = addonTable.Constants.IsClassic,
          },
          {
            label = addonTable.Locales.FROM_YOU,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.fromYou = value
            end,
            getter = function(details)
              return details.filters.fromYou
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.EXTRAS,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.includeExtras = value
            end,
            getter = function(details)
              return details.filters.includeExtras
            end,
          },
        }
      },
      {
        label = addonTable.Locales.VISUAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_PANDEMIC,
            kind = "checkbox",
            setter = function(details, value)
              details.pandemic.show = value
            end,
            getter = function(details)
              return details.pandemic.show
            end,
          },
          {
            label = addonTable.Locales.PANDEMIC_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.pandemic.color = value
            end,
            getter = function(details)
              return details.pandemic.color
            end,
          },
        },
      },
    },
    ["buffs"] = {
      {
        label = addonTable.Locales.TEXTS,
        entries = {
          {
            label = "",
            kind = "auraTextsPositioner",
            icon = 132117,
            setter = function() end,
            getter = function(details)
              return details
            end,
          },
        }
      },
      {
        label = addonTable.Locales.FILTERS,
        entries = {
          {
            label = addonTable.Locales.IMPORTANT,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.important = value
            end,
            getter = function(details)
              return details.filters.important
            end,
          },
          {
            label = addonTable.Locales.ENRAGE,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.enrage = value
            end,
            getter = function(details)
              return details.filters.enrage
            end,
          },
          {
            label = addonTable.Locales.MAGIC,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.magic = value
            end,
            getter = function(details)
              return details.filters.magic
            end,
          },
          {
            label = addonTable.Locales.DISPELLABLE,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.dispellable = value
            end,
            getter = function(details)
              return details.filters.dispellable
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.DEFENSIVE_ONLY,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.defensive = value
            end,
            getter = function(details)
              return details.filters.defensive
            end,
            hide = addonTable.Constants.IsClassic,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.FILTER_FRIENDLY_ONLY_FROM_YOU,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.friendlyFromYou = value
            end,
            getter = function(details)
              return details.filters.friendlyFromYou
            end,
            hide = addonTable.Constants.IsClassic,
          },
          {
            label = addonTable.Locales.SHOW_LONG_DURATION_AURAS,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.showLongDurations = value
            end,
            getter = function(details)
              return details.filters.showLongDurations
            end,
            hide = addonTable.Constants.IsClassic,
          },
        }
      },
      {
        label = addonTable.Locales.VISUAL,
        entries = {
          {
            label = addonTable.Locales.SHOW_PURGEABLE,
            kind = "checkbox",
            setter = function(details, value)
              details.purgeable.show = value
            end,
            getter = function(details)
              return details.purgeable.show
            end,
          },
          {
            label = addonTable.Locales.PURGEABLE_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.purgeable.color = value
            end,
            getter = function(details)
              return details.purgeable.color
            end,
          },
        },
      },
    },
    ["crowdControl"] = {
      {
        label = addonTable.Locales.TEXTS,
        entries = {
          {
            label = "",
            kind = "auraTextsPositioner",
            icon = 135860,
            setter = function() end,
            getter = function(details)
              return details
            end,
          },
        }
      },
      {
        label = addonTable.Locales.FILTERS,
        entries = {
          {
            label = addonTable.Locales.FROM_YOU,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.fromYou = value
            end,
            getter = function(details)
              return details.filters.fromYou
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.EXTRAS,
            kind = "checkbox",
            setter = function(details, value)
              details.filters.includeExtras = value
            end,
            getter = function(details)
              return details.filters.includeExtras
            end,
          },
        }
      }
    },
  },
  ["highlights"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 25, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
        },
      },
    },
    ["automatic"] = {
      defaultHighlight,
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            addAlpha = true,
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
    ["target"] = {
      defaultHighlight,
    },
    ["softTarget"] = {
      defaultHighlight,
    },
    ["focus"] = {
      defaultHighlight,
    },
    ["mouseover"] = {
      mouseoverHighlight
    },
    ["fixed"] = {
      defaultHighlight,
    },
    ["auras"] = {
      defaultHighlight,
    },
    ["fixedBordered"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.HEIGHT,
            kind = "slider",
            min = 50, max = 300,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              details.border.height = value / 100
            end,
            getter = function(details)
              return details.border.height * 100
            end,
          },
          {
            label = addonTable.Locales.WIDTH,
            kind = "slider",
            min = 15, max = 300,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              details.border.width = value / 100
            end,
            getter = function(details)
              return details.border.width * 100
            end,
          },
        },
      },
      {
        label = addonTable.Locales.TEXTURES,
        entries = {
          {
            label = addonTable.Locales.BORDER,
            kind = "dropdown",
            getInitData = function(details)
              return GetLabelsValuesBorders()
            end,
            setter = function(details, value)
              details.border.asset = value
            end,
            getter = function(details)
              return details.border.asset
            end
          },
          {
            label = addonTable.Locales.BORDER_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.border.color = value
            end,
            getter = function(details)
              return details.border.color
            end,
          },
          {
            label = addonTable.Locales.BACKGROUND,
            kind = "dropdown",
            getInitData = function()
              return GetLabelsValuesBackgrounds()
            end,
            setter = function(details, value)
              details.background.asset = value
            end,
            getter = function(details)
              return details.background.asset
            end
          },
          {
            label = addonTable.Locales.BACKGROUND_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.background.color = value
            end,
            getter = function(details)
              return details.background.color
            end,
          },
        }
      },
    },
    ["animatedBorder"] = {
      animatedBorderHighlight,
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            addAlpha = true,
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
    ["flashing"] = {
      flashingHighlight,
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {},
            addAlpha = true,
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    }
  },
  ["specialBars"] = {
    ["power"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 1, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.VISUAL,
            kind = "dropdown",
            getInitData = function()
              return GetLabelsValues(addonTable.Assets.PowerBars, nil, true, 2)
            end,
            setter = function(details, value)
              details.asset = value
            end,
            getter = function(details)
              return details.asset
            end
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.USE_FIXED_COLOR,
            kind = "checkbox",
            setter = function(details, value)
              details.useSpecColors = not value
            end,
            getter = function(details)
              return not details.useSpecColors
            end
          },
          {
            label = addonTable.Locales.FIXED_COLOR,
            kind = "colorPicker",
            setter = function(details, value)
              details.fixedColor = value
            end,
            getter = function(details)
              return details.fixedColor
            end,
          },
        }
      }
    },
    ["healthFillText"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.SCALE,
            kind = "slider",
            min = 1, max = 300,
            valuePattern = "%d%%",
            setter = function(details, value)
              details.scale = value / 100
            end,
            getter = function(details)
              return details.scale * 100
            end,
          },
          {
            label = addonTable.Locales.LAYER,
            kind = "slider",
            min = 0, max = 6,
            valuePattern = "%d",
            setter = function(details, value)
              details.layer = value
            end,
            getter = function(details)
              return details.layer
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.BACKGROUND_COLOR,
            kind = "colorPickerWithCheckbox",
            setter = function(details, value)
              details.background.color = value.color
              details.background.applyColor = not value.enabled
            end,
            getter = function(details)
              return {color = details.background.color, enabled = not details.background.applyColor}
            end,
          },
          {
            label = addonTable.Locales.ABSORB_COLOR,
            kind = "colorPickerWithCheckbox",
            setter = function(details, value)
              details.absorb.color = value.color
              details.absorb.applyColor = value.enabled
            end,
            getter = function(details)
              return {color = details.absorb.color, enabled = details.absorb.applyColor}
            end,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.SHOW_WHEN_WOW_DOES,
            kind = "checkbox",
            setter = function(details, value)
              details.showWhenWowDoes = value
            end,
            getter = function(details)
              return details.showWhenWowDoes
            end,
          },
          {
            label = addonTable.Locales.SHOW_FIRST_NAME_ONLY,
            kind = "checkbox",
            setter = function(details, value)
              details.showFirstNameOnly = value
            end,
            getter = function(details)
              return details.showFirstNameOnly
            end,
            hide = not addonTable.Constants.IsForever,
          },
          { kind = "spacer" },
          {
            label = addonTable.Locales.ANIMATE_X,
            kind = "checkbox",
            setter = function(details, value)
              details.animate = value
            end,
            getter = function(details)
              return details.animate
            end,
          },
        }
      },
      {
        label = addonTable.Locales.COLORS,
        entries = {
          {
            label = "",
            kind = "autoColors",
            lockedElements = {reaction = true},
            setter = function() end,
            getter = function(details)
              return details.autoColors
            end,
          },
        },
      },
    },
  },
  ["regions"] = {
    ["*"] = {
      {
        label = addonTable.Locales.GENERAL,
        entries = {
          {
            label = addonTable.Locales.AUTOMATICALLY_SIZED,
            kind = "checkbox",
            setter = function(details, value)
              details.autoSized = value
            end,
            getter = function(details)
              return details.autoSized
            end
          },
          {
            label = addonTable.Locales.HEIGHT,
            kind = "slider",
            min = 10, max = 1500,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              local currentHeight = details.height * addonTable.Assets.BarBordersSize.height
              local newHeight = value / 100 * addonTable.Assets.BarBordersSize.height
              local rect = addonTable.Utilities.GetRectFromRegion(details, 1, details.anchor)
              local newRect = {left = rect.left, bottom = rect.bottom - (newHeight - currentHeight) / 2, width = rect.width, height = newHeight}
              local newDetails = addonTable.Utilities.ConvertRectToWidget(newRect)
              details.anchor = newDetails.anchor

              local old = details.height
              details.height = value / 100
              if details.height ~= old then
                details.autoSized = false
              end
            end,
            getter = function(details)
              return details.height * 100
            end,
          },
          {
            label = addonTable.Locales.WIDTH,
            kind = "slider",
            min = 10, max = 500,
            formatter = function(value) return value .. "%" end,
            setter = function(details, value)
              local currentWidth = details.width * addonTable.Assets.BarBordersSize.width
              local newWidth = value / 100 * addonTable.Assets.BarBordersSize.width
              local rect = addonTable.Utilities.GetRectFromRegion(details, 1, details.anchor)
              local newRect = {left = rect.left - (newWidth - currentWidth) / 2, bottom = rect.bottom, width = newWidth, height = rect.height}
              local newDetails = addonTable.Utilities.ConvertRectToWidget(newRect)
              details.anchor = newDetails.anchor

              local old = details.width
              details.width = value / 100
              if details.width ~= old then
                details.autoSized = false
              end
            end,
            getter = function(details)
              return details.width * 100
            end,
          },
        },
      },
    }
  }
}

addonTable.CustomiseDialog.AurasTextsConfig = {
  ["countdown"] = {
    {
      label = addonTable.Locales.VISIBLE,
      kind = "checkbox",
      setter = function(details, value)
        details.visible = value
      end,
      getter = function(details)
        return details.visible
      end,
    },
    {
      label = addonTable.Locales.SCALE,
      kind = "slider",
      min = 25, max = 300,
      valuePattern = "%d%%",
      setter = function(details, value)
        details.scale = value / 100
      end,
      getter = function(details)
        return details.scale * 100
      end,
    },
    {
      label = addonTable.Locales.COLOR,
      kind = "colorPicker",
      setter = function(details, value)
        details.color = value
      end,
      getter = function(details)
        return details.color
      end,
    },
    { kind = "spacer" },
    {
      label = addonTable.Locales.SHOW_FRACTIONS,
      kind = "checkbox",
      setter = function(details, value)
        details.showFractions = value
      end,
      getter = function(details)
        return details.showFractions
      end,
    },
  },
  ["stacks"] = {
    {
      label = addonTable.Locales.VISIBLE,
      kind = "checkbox",
      setter = function(details, value)
        details.visible = value
      end,
      getter = function(details)
        return details.visible
      end,
    },
    {
      label = addonTable.Locales.SCALE,
      kind = "slider",
      min = 25, max = 300,
      valuePattern = "%d%%",
      setter = function(details, value)
        details.scale = value / 100
      end,
      getter = function(details)
        return details.scale * 100
      end,
    },
    {
      label = addonTable.Locales.COLOR,
      kind = "colorPicker",
      setter = function(details, value)
        details.color = value
      end,
      getter = function(details)
        return details.color
      end,
    },
  }
}
