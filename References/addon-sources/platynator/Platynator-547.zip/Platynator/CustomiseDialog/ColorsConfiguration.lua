---@class addonTablePlatynator
local addonTable = select(2, ...)

local function GetColor(rgb)
  local color = CreateColorFromRGBHexString(rgb)
  return {r = color.r, g = color.g, b = color.b}
end

function addonTable.CustomiseDialog.AddAlphaToColors(details)
  for _, c in pairs(details.colors) do
    c.a = 1
  end

  return details
end

addonTable.CustomiseDialog.ColorsConfig = {
  ["tapped"] = {
    label = addonTable.Locales.TAPPED,
    default = {
      kind = "tapped",
      colors = {
        tapped = GetColor("6E6E6E"),
      }
    },
    entries = {
      {
        label = addonTable.Locales.TAPPED,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.tapped = value
        end,
        getter = function(details)
          return details.colors.tapped
        end,
      },
    },
  },
  ["target"] = {
    label = addonTable.Locales.TARGET,
    default = {
      kind = "target",
      colors = {
        target = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.TARGET,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.target = value
        end,
        getter = function(details)
          return details.colors.target
        end,
      },
    },
  },
  ["notTarget"] = {
    label = addonTable.Locales.NOT_TARGET,
    default = {
      kind = "notTarget",
      colors = {
        notTarget = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.NOT_TARGET,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.notTarget = value
        end,
        getter = function(details)
          return details.colors.notTarget
        end,
      },
    },
  },
  ["softTarget"] = {
    label = addonTable.Locales.SOFT_TARGET,
    default = {
      kind = "softTarget",
      colors = {
        softTarget = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.SOFT_TARGET_SENTENCE_CASE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.softTarget = value
        end,
        getter = function(details)
          return details.colors.softTarget
        end,
      },
    },
  },
  ["focus"] = {
    label = addonTable.Locales.FOCUS,
    default = {
      kind = "focus",
      colors = {
        focus = GetColor("46ad32"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FOCUS,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.focus = value
        end,
        getter = function(details)
          return details.colors.focus
        end,
      },
    },
  },
  ["threat"] = {
    label = addonTable.Locales.THREAT,
    default = {
      kind = "threat",
      colors = {
        safe = GetColor("0F96E6"),
        transition = GetColor("FFA000"),
        warning = GetColor("CC0000"),
        offtank = GetColor("0FAAC8"),
      },
      instancesOnly = false,
      combatOnly = true,
      tanksOnly = false,
      enabled = {
        safe = false,
        offtank = false,
        transition = true,
        warning = true,
      },
    },
    entries = {
      {
        label = addonTable.Locales.SAFE,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.safe = value.color
          details.enabled.safe = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.safe, enabled = details.enabled.safe}
        end,
      },
      {
        label = addonTable.Locales.OFFTANK,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.offtank = value.color
          details.enabled.offtank = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.offtank, enabled = details.enabled.offtank}
        end,
      },
      {
        label = addonTable.Locales.TRANSITION,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.transition = value.color
          details.enabled.transition = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.transition, enabled = details.enabled.transition}
        end,
      },
      {
        label = addonTable.Locales.WARNING,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.warning = value.color
          details.enabled.warning = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.warning, enabled = details.enabled.warning}
        end,
      },
      { kind = "spacer" },
      {
        label = addonTable.Locales.ONLY_APPLY_IN_COMBAT,
        kind = "checkbox",
        setter = function(details, value)
          details.combatOnly = value
        end,
        getter = function(details)
          return details.combatOnly
        end,
      },
      {
        label = addonTable.Locales.ONLY_APPLY_IN_INSTANCES,
        kind = "checkbox",
        setter = function(details, value)
          details.instancesOnly = value
        end,
        getter = function(details)
          return details.instancesOnly
        end,
      },
      {
        label = addonTable.Locales.ONLY_APPLY_WHEN_TANK,
        kind = "checkbox",
        setter = function(details, value)
          details.tanksOnly = value
        end,
        getter = function(details)
          return details.tanksOnly
        end,
      },
    },
  },
  ["threatIgnoreRole"] = {
    label = addonTable.Locales.THREAT_IGNORE_ROLE,
    default = {
      kind = "threatIgnoreRole",
      colors = {
        noThreat = GetColor("0F96E6"),
        transition = GetColor("FFA000"),
        hasThreat = GetColor("CC0000"),
        offtank = GetColor("0FAAC8"),
      },
      instancesOnly = false,
      combatOnly = true,
      useNoThreatColor = true,
      useOffTankColor = false,
    },
    entries = {
      {
        label = addonTable.Locales.NO_THREAT,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.noThreat = value.color
          details.useNoThreatColor = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.noThreat, enabled = details.useNoThreatColor}
        end,
      },
      {
        label = addonTable.Locales.OFFTANK,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.offtank = value.color
          details.useOffTankColor = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.offtank, enabled = details.useOffTankColor}
        end,
      },
      {
        label = addonTable.Locales.TRANSITION,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.transition = value
        end,
        getter = function(details)
          return details.colors.transition
        end,
      },
      {
        label = addonTable.Locales.HAS_THREAT,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.hasThreat = value
        end,
        getter = function(details)
          return details.colors.hasThreat
        end,
      },
      { kind = "spacer" },
      {
        label = addonTable.Locales.ONLY_APPLY_IN_COMBAT,
        kind = "checkbox",
        setter = function(details, value)
          details.combatOnly = value
        end,
        getter = function(details)
          return details.combatOnly
        end,
      },
      {
        label = addonTable.Locales.ONLY_APPLY_IN_INSTANCES,
        kind = "checkbox",
        setter = function(details, value)
          details.instancesOnly = value
        end,
        getter = function(details)
          return details.instancesOnly
        end,
      },
    },
  },
  ["rarity"] = {
    label = addonTable.Locales.RARITY,
    default = {
      kind = "rarity",
      colors = {
        rare = GetColor("d5d5d5"),
        rareElite = GetColor("f8de7e"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.RARE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.rare = value
        end,
        getter = function(details)
          return details.colors.rare
        end,
      },
      {
        label = addonTable.Locales.RARE_ELITE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.rareElite = value
        end,
        getter = function(details)
          return details.colors.rareElite
        end,
      },
    },
  },
  ["eliteType"] = {
    label = addonTable.Locales.ELITE_TYPE,
    default = {
      kind = "eliteType",
      colors = {
        boss = GetColor("bc1c00"),
        miniboss = GetColor("9000bc"),
        caster = GetColor("0074bc"),
        melee = GetColor("fcfcfc"),
        trivial = GetColor("b28e55"),
      },
      enabled = {
        boss = true,
        miniboss = true,
        caster = true,
        melee = true,
        trivial = true,
      },
      instancesOnly = true,
      applyCasterAlways = false,
    },
    entries = {
      {
        label = addonTable.Locales.BOSS,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.boss = value.color
          details.enabled.boss = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.boss, enabled = details.enabled.boss}
        end,
      },
      {
        label = addonTable.Locales.MINIBOSS,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.miniboss = value.color
          details.enabled.miniboss = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.miniboss, enabled = details.enabled.miniboss}
        end,
        hide = not addonTable.Constants.IsRetail,
      },
      {
        label = addonTable.Locales.CASTER,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.caster = value.color
          details.enabled.caster = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.caster, enabled = details.enabled.caster}
        end,
      },
      {
        label = addonTable.Locales.MELEE,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.melee = value.color
          details.enabled.melee = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.melee, enabled = details.enabled.melee}
        end,
      },
      {
        label = addonTable.Locales.TRIVIAL,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.trivial = value.color
          details.enabled.trivial = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.trivial, enabled = details.enabled.trivial}
        end,
      },
      { kind = "spacer" },
      {
        label = addonTable.Locales.ONLY_APPLY_IN_INSTANCES,
        kind = "checkbox",
        setter = function(details, value)
          details.instancesOnly = value
        end,
        getter = function(details)
          return details.instancesOnly
        end,
      },
      {
        label = addonTable.Locales.USE_CASTER_COLOR_ON_NON_ELITES,
        kind = "checkbox",
        setter = function(details, value)
          details.applyCasterAlways = value
        end,
        getter = function(details)
          return details.applyCasterAlways
        end,
      },
    },
  },
  ["delveType"] = {
    label = addonTable.Locales.DELVE_TYPE,
    default = {
      kind = "delveType",
      colors = {
        boss = GetColor("bc1c00"),
        elite = GetColor("9000bc"),
        rare = GetColor("bc5389"),
        caster = GetColor("0074bc"),
        melee = GetColor("fcfcfc"),
        trivial = GetColor("b28e55"),
      },
      enabled = {
        boss = true,
        elite = true,
        rare = true,
        caster = true,
        melee = true,
        trivial = true,
      },
      delves = true,
      outsideInstances = false,
    },
    entries = {
      {
        label = addonTable.Locales.BOSS,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.boss = value.color
          details.enabled.boss = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.boss, enabled = details.enabled.boss}
        end,
      },
      {
        label = addonTable.Locales.ELITE,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.elite = value.color
          details.enabled.elite = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.elite, enabled = details.enabled.elite}
        end,
      },
      {
        label = addonTable.Locales.RARE,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.rare = value.color
          details.enabled.rare = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.rare, enabled = details.enabled.rare}
        end,
      },
      {
        label = addonTable.Locales.CASTER,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.caster = value.color
          details.enabled.caster = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.caster, enabled = details.enabled.caster}
        end,
      },
      {
        label = addonTable.Locales.MELEE,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.melee = value.color
          details.enabled.melee = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.melee, enabled = details.enabled.melee}
        end,
      },
      {
        label = addonTable.Locales.TRIVIAL,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.trivial = value.color
          details.enabled.trivial = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.trivial, enabled = details.enabled.trivial}
        end,
      },
      {
        label = addonTable.Locales.USE_IN_DELVES,
        kind = "checkbox",
        setter = function(details, value)
          details.delves = value
        end,
        getter = function(details)
          return details.delves
        end,
      },
      {
        label = addonTable.Locales.USE_OUTSIDE_INSTANCES,
        kind = "checkbox",
        setter = function(details, value)
          details.outsideInstances = value
        end,
        getter = function(details)
          return details.outsideInstances
        end,
      },
    },
  },
  ["quest"] = {
    label = addonTable.Locales.QUEST,
    default = {
      kind = "quest",
      colors = {
        friendly = GetColor("E0FF00"),
        neutral = GetColor("FFEC4A"),
        hostile = GetColor("FFB963"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FRIENDLY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.friendly = value
        end,
        getter = function(details)
          return details.colors.friendly
        end,
      },
      {
        label = addonTable.Locales.NEUTRAL,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.neutral = value
        end,
        getter = function(details)
          return details.colors.neutral
        end,
      },
      {
        label = addonTable.Locales.HOSTILE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.hostile = value
        end,
        getter = function(details)
          return details.colors.hostile
        end,
      },
    },
  },
  ["guild"] = {
    label = addonTable.Locales.GUILD,
    default = {
      kind = "guild",
      colors = {
        guild = GetColor("3bbc14")
      },
    },
    entries = {
      {
        label = addonTable.Locales.GUILD,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.guild = value
        end,
        getter = function(details)
          return details.colors.guild
        end,
      },
    },
  },
  ["classColors"] = {
    label = addonTable.Locales.CLASS_COLORS,
    default = {
      kind = "classColors",
      colors = {},
    },
    entries = {},
  },
  ["myClassColor"] = {
    label = addonTable.Locales.MY_CLASS,
    default = {
      kind = "myClassColor",
      colors = {},
    },
    entries = {},
  },
  ["reaction"] = {
    label = addonTable.Locales.REACTION,
    default = {
      kind = "reaction",
      colors = {
        friendly = GetColor("00FF00"),
        neutral = GetColor("FFFF00"),
        unfriendly = GetColor("ff8100"),
        hostile = GetColor("FF0000"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FRIENDLY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.friendly = value
        end,
        getter = function(details)
          return details.colors.friendly
        end,
      },
      {
        label = addonTable.Locales.NEUTRAL,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.neutral = value
        end,
        getter = function(details)
          return details.colors.neutral
        end,
      },
      {
        label = addonTable.Locales.UNFRIENDLY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.unfriendly = value
        end,
        getter = function(details)
          return details.colors.unfriendly
        end,
      },
      {
        label = addonTable.Locales.HOSTILE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.hostile = value
        end,
        getter = function(details)
          return details.colors.hostile
        end,
      },
    },
  },
  ["difficulty"] = {
    label = addonTable.Locales.DIFFICULTY,
    default = {
      kind = "difficulty",
      colors = {
        impossible = {r = 1.00, g = 0.10, b = 0.10},
        verydifficult = {r = 1.00, g = 0.50, b = 0.25},
        difficult = {r = 1.00, g = 0.82, b = 0.00},
        standard = {r = 0.25, g = 0.75, b = 0.25},
        trivial = {r = 0.50, g = 0.50, b = 0.50},
      },
    },
    entries = {
      {
        label = addonTable.Locales.TRIVIAL,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.trivial = value
        end,
        getter = function(details)
          return details.colors.trivial
        end,
      },
      {
        label = addonTable.Locales.STANDARD,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.standard = value
        end,
        getter = function(details)
          return details.colors.standard
        end,
      },
      {
        label = addonTable.Locales.DIFFICULT,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.difficult = value
        end,
        getter = function(details)
          return details.colors.difficult
        end,
      },
      {
        label = addonTable.Locales.VERY_DIFFICULT,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.verydifficult = value
        end,
        getter = function(details)
          return details.colors.verydifficult
        end,
      },
      {
        label = addonTable.Locales.IMPOSSIBLE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.impossible = value
        end,
        getter = function(details)
          return details.colors.impossible
        end,
      },
    },
  },
  ["fixed"] = {
    label = addonTable.Locales.FIXED,
    default = {
      kind = "fixed",
      colors = {
        fixed = GetColor("FFFFFF"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FIXED,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.fixed = value
        end,
        getter = function(details)
          return details.colors.fixed
        end,
      },
    },
  },
  ["interruptReady"] = {
    label = addonTable.Locales.INTERRUPT_READY,
    default = {
      kind = "interruptReady",
      colors = {
        ready = GetColor("00FF00"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.READY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.ready = value
        end,
        getter = function(details)
          return details.colors.ready
        end,
      },
    },
  },
  ["interruptNotReady"] = {
    label = addonTable.Locales.INTERRUPT_NOT_READY,
    default = {
      kind = "interruptNotReady",
      colors = {
        notReady = GetColor("FFFFFF"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.NOT_READY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.notReady = value
        end,
        getter = function(details)
          return details.colors.notReady
        end,
      },
    },
  },
  ["castTargetsYou"] = {
    label = addonTable.Locales.CAST_TARGETS_YOU,
    default = {
      kind = "castTargetsYou",
      colors = {
        targeted = GetColor("FF0000"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.TARGETED,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.targeted = value
        end,
        getter = function(details)
          return details.colors.targeted
        end,
      },
    },
  },
  ["importantCast"] = {
    label = addonTable.Locales.IMPORTANT_CAST,
    default = {
      kind = "importantCast",
      colors = {
        cast = GetColor("FF1827"),
        channel = GetColor("0A43FF"),
      },
      enabled = {
        cast = true,
        channel = true,
      }
    },
    entries = {
      {
        label = addonTable.Locales.CAST,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.cast = value.color
          details.enabled.cast = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.cast, enabled = details.enabled.cast}
        end,
      },
      {
        label = addonTable.Locales.CHANNEL,
        kind = "colorPickerWithCheckbox",
        setter = function(details, value)
          details.colors.channel = value.color
          details.enabled.channel = value.enabled
        end,
        getter = function(details)
          return {color = details.colors.channel, enabled = details.enabled.channel}
        end,
      },
    }
  },
  ["cast"] = {
    label = addonTable.Locales.CASTING,
    default = {
      kind = "cast",
      colors = {
        cast = GetColor("FC8C00"),
        channel = GetColor("3EC637"),
        interrupted = GetColor("FC36E0"),
        empowered = GetColor("05c666"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.CAST,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.cast = value
        end,
        getter = function(details)
          return details.colors.cast
        end,
      },
      {
        label = addonTable.Locales.CHANNEL,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.channel = value
        end,
        getter = function(details)
          return details.colors.channel
        end,
      },
      {
        label = addonTable.Locales.EMPOWERED,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.empowered = value
        end,
        getter = function(details)
          return details.colors.empowered
        end,
      },
      {
        label = addonTable.Locales.INTERRUPTED_CAST,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.interrupted = value
        end,
        getter = function(details)
          return details.colors.interrupted
        end,
      },
    }
  },
  ["notCast"] = {
    label = addonTable.Locales.NOT_CASTING,
    default = {
      kind = "notCast",
      colors = {
        notCast = GetColor("FFFFFF"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.NOT_CASTING,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.notCast = value
        end,
        getter = function(details)
          return details.colors.notCast
        end,
      },
    },
  },
  ["isCast"] = {
    label = addonTable.Locales.IS_CASTING,
    default = {
      kind = "isCast",
      colors = {
        isCast = GetColor("FFFFFF"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.IS_CASTING,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.isCast = value
        end,
        getter = function(details)
          return details.colors.isCast
        end,
      },
    },
  },
  ["uninterruptableCast"] = {
    label = addonTable.Locales.UNINTERRUPTABLE_CAST,
    default = {
      kind = "uninterruptableCast",
      colors = {
        uninterruptable = GetColor("83C0C3"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.UNINTERRUPTABLE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.uninterruptable = value
        end,
        getter = function(details)
          return details.colors.uninterruptable
        end,
      },
    }
  },
  ["execute"] = {
    label = addonTable.Locales.EXECUTE,
    default = {
      kind = "execute",
      colors = {
        execute = GetColor("D1D1D1"),
        inCombat = GetColor("FF0000"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.EXECUTE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.execute = value
        end,
        getter = function(details)
          return details.colors.execute
        end,
      },
      {
        label = addonTable.Locales.IN_COMBAT_WITH,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.inCombat = value
        end,
        getter = function(details)
          return details.colors.inCombat
        end,
      },
    }
  },
  ["mouseover"] = {
    label = addonTable.Locales.MOUSEOVER,
    default = {
      kind = "mouseover",
      colors = {
        mouseover = GetColor("B15FEB"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.MOUSEOVER,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.mouseover = value
        end,
        getter = function(details)
          return details.colors.mouseover
        end,
      },
      { kind = "spacer" },
      {
        label = addonTable.Locales.INCLUDE_TARGET,
        kind = "checkbox",
        setter = function(details, value)
          details.includeTarget = value
        end,
        getter = function(details)
          return details.includeTarget
        end,
      },
    }
  },
  ["notMouseover"] = {
    label = addonTable.Locales.NOT_MOUSEOVER,
    default = {
      kind = "notMouseover",
      colors = {
        notMouseover = GetColor("B15FEB"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.NOT_MOUSEOVER,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.notMouseover = value
        end,
        getter = function(details)
          return details.colors.notMouseover
        end,
      },
      { kind = "spacer" },
      {
        label = addonTable.Locales.INCLUDE_TARGET,
        kind = "checkbox",
        setter = function(details, value)
          details.includeTarget = value
        end,
        getter = function(details)
          return details.includeTarget
        end,
      },
    }
  },
  ["inCombat"] = {
    label = addonTable.Locales.IN_COMBAT_WITH,
    default = {
      kind = "inCombat",
      colors = {
        inCombat = GetColor("7c1eff"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.IN_COMBAT_WITH,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.inCombat = value
        end,
        getter = function(details)
          return details.colors.inCombat
        end,
      },
    }
  },
  ["energy"] = {
    label = addonTable.Locales.ENERGY,
    default = {
      kind = "energy",
      colors = {
        energy = GetColor("fff700"),
        mana = GetColor("00aaff"),
        rage = GetColor("ff5500"),
      }
    },
    entries = {
      {
        label = addonTable.Locales.ENERGY,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.energy = value
        end,
        getter = function(details)
          return details.colors.energy
        end,
      },
      {
        label = addonTable.Locales.RAGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.rage = value
        end,
        getter = function(details)
          return details.colors.rage
        end,
      },
      {
        label = addonTable.Locales.MANA,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.mana = value
        end,
        getter = function(details)
          return details.colors.mana
        end,
      },
    },
  },
  ["inRange"] = {
    label = addonTable.Locales.IN_RANGE,
    default = {
      kind = "inRange",
      colors = {
        inRange = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.IN_RANGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.inRange = value
        end,
        getter = function(details)
          return details.colors.inRange
        end,
      },
    },
  },
  ["outOfRange"] = {
    label = addonTable.Locales.OUT_OF_RANGE,
    default = {
      kind = "outOfRange",
      colors = {
        outOfRange = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.OUT_OF_RANGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.outOfRange = value
        end,
        getter = function(details)
          return details.colors.outOfRange
        end,
      },
    },
  },
  ["inRangeMelee"] = {
    label = addonTable.Locales.IN_RANGE_MELEE,
    default = {
      kind = "inRangeMelee",
      colors = {
        inRange = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.IN_RANGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.inRange = value
        end,
        getter = function(details)
          return details.colors.inRange
        end,
      },
    },
  },
  ["outOfRangeMelee"] = {
    label = addonTable.Locales.OUT_OF_RANGE_MELEE,
    default = {
      kind = "outOfRangeMelee",
      colors = {
        outOfRange = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.OUT_OF_RANGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.outOfRange = value
        end,
        getter = function(details)
          return details.colors.outOfRange
        end,
      },
    },
  },
  ["party"] = {
    label = addonTable.Locales.PARTY,
    default = {
      kind = "party",
      colors = {
        damage = GetColor("34edd1"),
        healer = GetColor("34edd1"),
        tank = GetColor("34edd1"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.DAMAGE,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.damage = value
        end,
        getter = function(details)
          return details.colors.damage
        end,
      },
      {
        label = addonTable.Locales.HEALER,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.healer = value
        end,
        getter = function(details)
          return details.colors.healer
        end,
      },
      {
        label = addonTable.Locales.TANK,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.tank = value
        end,
        getter = function(details)
          return details.colors.tank
        end,
      },
    },
  },
  ["friendList"] = {
    label = addonTable.Locales.FRIENDS_LIST,
    default = {
      kind = "friendList",
      colors = {
        friend = GetColor("9dff00"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FRIEND,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.friend = value
        end,
        getter = function(details)
          return details.colors.friend
        end,
      },
    },
  },
  ["pvpFlagged"] = {
    label = addonTable.Locales.PVP_FLAGGED,
    default = {
      kind = "pvpFlagged",
      colors = {
        flagged = GetColor("ffff00"),
      },
    },
    entries = {
      {
        label = addonTable.Locales.FLAGGED,
        kind = "colorPicker",
        setter = function(details, value)
          details.colors.flagged = value
        end,
        getter = function(details)
          return details.colors.flagged
        end,
      },
    },
  },
}

addonTable.CustomiseDialog.ColorsConfigOrder = {
  "tapped",
  "target",
  "notTarget",
  "softTarget",
  "focus",
  "mouseover",
  "notMouseover",
  "threat",
  "threatIgnoreRole",
  "inCombat",
  "inRange",
  "outOfRange",
  "inRangeMelee",
  "outOfRangeMelee",
  "isCast",
  "notCast",
  "delveType",
  "eliteType",
  "rarity",
  "quest",
  "party",
  "guild",
  "friendList",
  "pvpFlagged",
  "classColors",
  "myClassColor",
  "difficulty",
  "execute",
  "reaction",
  "interruptReady",
  "interruptNotReady",
  "castTargetsYou",
  "importantCast",
  "uninterruptableCast",
  "cast",
  "fixed",
}
