---@class addonTablePlatynator
local addonTable = select(2, ...)
addonTable.Config = {}

local announceChanges = true

local settings = {
  MIGRATION = {key = "migration", default = 1, new = 13},

  STYLE = {key = "style", default = "_deer"},
  CURRENT_SKIN = {key = "current_skin", default = "blizzard", refresh = {addonTable.Constants.RefreshReason.Skin}},

  GLOBAL_SCALE = {key = "global_scale", default = 1, refresh = {addonTable.Constants.RefreshReason.Scale}},

  LEGACY_DESIGN = {key = "design_all", default = {}},
  LEGACY_DESIGNS_ASSIGNED = {key = "designs_assigned", default = {}},
  LEGACY_DESIGNS_ENABLED = {key = "designs_enabled", default = { pvpInstance = false, pvpWorld = false, combat = false }},
  LEGACY_SIMPLIFIED_NAMEPLATES = {key = "simplified_nameplates", default = {minion = true, minor = true, instancesNormal = true}},

  DESIGNS = {key = "designs", default = {}, refresh = {addonTable.Constants.RefreshReason.Design}},
  DESIGN_ASSIGNMENTS = {key = "design_assignments", default = {}, new = {
    {criteria = {"cannot-attack"}, simplified = false, scale = 1, style = "_name-only"},
    {criteria = {"can-attack", "class-minor"}, simplified = true, scale = 1, style = "_deer_simplified"},
    {criteria = {"can-attack", "minion"}, simplified = true, scale = 1, style = "_deer_simplified"},
    {criteria = {"can-attack", "loc-dungeon", "class-normal"}, simplified = true, scale = 1, style = "_deer_simplified"},
    {criteria = {"can-attack"}, simplified = false, scale = 1, style = "_deer"},
  }, refresh = {addonTable.Constants.RefreshReason.DesignSelection, addonTable.Constants.RefreshReason.Design}},
  SIMPLIFIED_ASSIGNED_FALLBACK = {key = "simplified_assigned_fallback", default = "_deer_simplified"},

  AURA_FILTERS = {key = "aura_filters", default = {crowdControl = {include = {}, exclude = {}}}},
  AURA_DEDUPLICATE = {key = "aura_deduplicate", default = {["DEATHKNIGHT"] = {55078}}},
  AURA_HIGHLIGHTS = {key = "aura_highlights", default = {--[[ [265] = { -- Affliction Warlock
    buffs = {
      showAll = {color = GetColor("ff0000"), enabled = false},
      showNone = {color = GetColor("ff0000"), enabled = false},
      showIndividualColors = true,
      auras = {
        {spellID = 2830, color = GetColor("ff11ff"), enabled = true}
      }
    debuffs = {
      -- Just like buffs
    }
  }]]}},

  TARGET_SCALE = {key = "target_scale", default = 1.2, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},
  CAST_SCALE = {key = "cast_scale", default = 1, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},
  CAST_ALPHA = {key = "cast_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},
  NOT_TARGET_ALPHA = {key = "not_target_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},
  WHEN_NO_TARGET_ALPHA = {key = "when_no_target_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},
  MOUSEOVER_ALPHA = {key = "mouseover_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.TargetBehaviour}},

  OBSCURED_ALPHA = {key = "obscured_alpha", default = 0.4},
  OBSCURED_COMBAT_ALPHA = {key = "obscured_combat_alpha", default = 0.4},
  OUT_OF_RANGE_ALPHA = {key = "out_of_range_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.Design}},
  NOT_IN_PULL_ALPHA = {key = "not_in_combat_alpha", default = 1, refresh = {addonTable.Constants.RefreshReason.Design}},

  STACKING_NAMEPLATES = {key = "stacking_nameplates", default = {friend = false, enemy = true}, refresh = {addonTable.Constants.RefreshReason.StackingBehaviour}},
  STACK_POSITION_INSETS = {key = "stack_position_insets", default = {top = 0.08, bottom = 0.1}, refresh = {addonTable.Constants.RefreshReason.Movement}},
  STACK_MOTION_SPEED = {key = "stack_motion_speed", default = 0.3, refresh = {addonTable.Constants.RefreshReason.Movement}},
  CLICK_REGION_SCALE_X = {key = "click_region_scale_x", default = 1},
  CLICK_REGION_SCALE_Y = {key = "click_region_scale_y", default = 1},
  CLICKABLE_NAMEPLATES = {key = "clickable_nameplates", default = {friend = false, enemy = true}, refresh = {addonTable.Constants.RefreshReason.Clickable}},

  STACK_REGION_SCALE_X = {key = "stack_region_scale_x", default = 1.2, refresh = {addonTable.Constants.RefreshReason.StackingBehaviour}},
  STACK_REGION_SCALE_Y = {key = "stack_region_scale_y", default = 1.4, refresh = {addonTable.Constants.RefreshReason.StackingBehaviour}},

  VERTICAL_OFFSET = {key = "vertical_offset", default = 0},

  CAST_INTERRUPTED_TIMEOUT = {key = "cast_interrupted_timeout", default = 0.3},

  SHOW_NAMEPLATES_ONLY_NEEDED = {key = "show_nameplates_only_needed", default = false, refresh = {addonTable.Constants.RefreshReason.ShowBehaviour}},
  SHOW_NAMEPLATES = {key = "show_nameplates", default = {
    friendlyNPC = true, friendlyPlayer = true, friendlyMinion = false, enemy = true, enemyMinion = true, enemyMinor = true
  }, refresh = {addonTable.Constants.RefreshReason.ShowBehaviour}},
  SHOW_FRIENDLY_IN_INSTANCES = {key = "show_friendly_in_instances_1", default = "always", refresh = {addonTable.Constants.RefreshReason.ShowBehaviour}},
  INSTANCES_NAME_ONLY_SIZE = {key = "instances_name_only_size", default = 2, refresh = {addonTable.Constants.RefreshReason.ShowBehaviour}},
  NAMEPLATE_POSITION = {key = "nameplate_position", default = "top"},

  SIMPLIFIED_SCALE = {key = "simplified_scale", default = 0.6, refresh = {addonTable.Constants.RefreshReason.SimplifiedScale}},
  BLIZZARD_WIDGET_SCALE = {key = "blizzard_widget_scale", default = 1.2},

  APPLY_CVARS = {key = "apply_cvars", default = true},
}

addonTable.Config.RefreshType = {}

addonTable.Config.Options = {}
addonTable.Config.Defaults = {}
addonTable.Config.NewDefaults = {}

for key, details in pairs(settings) do
  if details.refresh then
    local refreshType = {}
    for _, r in ipairs(details.refresh) do
      refreshType[r] = true
    end
    addonTable.Config.RefreshType[details.key] = refreshType
  end
  addonTable.Config.Options[key] = details.key
  addonTable.Config.Defaults[details.key] = details.default
  if details.new ~= nil then
    addonTable.Config.NewDefaults[details.key] = details.new
  else
    addonTable.Config.NewDefaults[details.key] = details.default
  end
end

function addonTable.Config.IsValidOption(name)
  for _, option in pairs(addonTable.Config.Options) do
    if option == name then
      return true
    end
  end
  return false
end

local function RawSet(name, value)
  local tree = {strsplit(".", name)}
  if addonTable.Config.CurrentProfile == nil then
    error("PLATYNATOR_CONFIG not initialized")
  elseif not addonTable.Config.IsValidOption(tree[1]) then
    error("Invalid option '" .. name .. "'")
  elseif #tree == 1 then
    local oldValue = addonTable.Config.CurrentProfile[name]
    addonTable.Config.CurrentProfile[name] = value
    if value ~= oldValue then
      return true
    end
  else
    local root = addonTable.Config.CurrentProfile
    for i = 1, #tree - 1 do
      root = root[tree[i]]
      if type(root) ~= "table" then
        error("Invalid option '" .. name .. "', broke at [" .. i .. "]")
      end
    end
    local tail = tree[#tree]
    if root[tail] == nil then
      error("Invalid option '" .. name .. "', broke at [tail]")
    end
    local oldValue = root[tail]
    root[tail] = value
    if value ~= oldValue then
      return true
    end
  end
  return false
end

function addonTable.Config.Set(name, value)
  if RawSet(name, value) and announceChanges then
    addonTable.CallbackRegistry:TriggerEvent("SettingChanged", name)
    if addonTable.Config.RefreshType[name] then
      addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", addonTable.Config.RefreshType[name])
    end
  end
end

-- Set multiple settings at once and after all are set fire the setting changed
-- events
function addonTable.Config.MultiSet(nameValueMap)
  local changed = {}
  for name, value in pairs(nameValueMap) do
    if RawSet(name, value) then
      table.insert(changed, name)
    end
  end

  if announceChanges then
    local refreshState = {}
    for _, name in ipairs(changed) do
      addonTable.CallbackRegistry:TriggerEvent("SettingChanged", name)
      if addonTable.Config.RefreshType[name] then
        refreshState = Mixin(refreshState, addonTable.Config.RefreshType[name])
      end
    end
    if next(refreshState) ~= nil then
      addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", refreshState)
    end
  end
end

local addedInstalledNestedToList = {}
local installedNested = {}

function addonTable.Config.Install(name, defaultValue)
  if PLATYNATOR_CONFIG == nil then
    error("PLATYNATOR_CONFIG not initialized")
  elseif name:find("%.") == nil then
    if addonTable.Config.CurrentProfile[name] == nil then
      addonTable.Config.CurrentProfile[name] = defaultValue
    end
  else
    if not addedInstalledNestedToList[name] then
      addedInstalledNestedToList[name] = true
      table.insert(installedNested, name)
    end
    local tree = {strsplit(".", name)}
    local root = addonTable.Config.CurrentProfile
    for i = 1, #tree - 1 do
      if not root[tree[i]] then
        root[tree[i]] = {}
      end
      root = root[tree[i]]
    end
    if root[tree[#tree]] == nil then
      root[tree[#tree]] = defaultValue
    end
  end
end

function addonTable.Config.ResetOne(name, announce)
  local newValue = addonTable.Config.NewDefaults[name]
  if newValue == nil then
    error("Can't reset that", name)
  else
    if type(newValue) == "table" then
      newValue = CopyTable(newValue)
    end
    if announce ~= false then
      addonTable.Config.Set(name, newValue)
    else
      RawSet(name, newValue)
    end
  end
end

function addonTable.Config.Reset()
  PLATYNATOR_CONFIG = {
    Profiles = {
      DEFAULT = {},
    },
    CharacterSpecific = {},
    Version = 1,
  }
  addonTable.Config.InitializeData()
end

local function ImportDefaultsToProfile()
  local isNew = next(addonTable.Config.CurrentProfile) == nil
  for option, value in pairs(isNew and addonTable.Config.NewDefaults or addonTable.Config.Defaults) do
    if addonTable.Config.CurrentProfile[option] == nil then
      if type(value) == "table" then
        addonTable.Config.CurrentProfile[option] = CopyTable(value)
      else
        addonTable.Config.CurrentProfile[option] = value
      end
    end
  end
end

function addonTable.Config.InitializeData()
  if PLATYNATOR_CONFIG == nil then
    addonTable.Config.Reset()
    return
  end

  if PLATYNATOR_CONFIG.Profiles == nil then
    PLATYNATOR_CONFIG = {
      Profiles = {
        DEFAULT = PLATYNATOR_CONFIG,
      },
      CharacterSpecific = {},
      Version = 1,
    }
  end

  if PLATYNATOR_CONFIG.Profiles.DEFAULT == nil then
    PLATYNATOR_CONFIG.Profiles.DEFAULT = {}
  end
  if PLATYNATOR_CONFIG.Profiles[PLATYNATOR_CURRENT_PROFILE] == nil then
    PLATYNATOR_CURRENT_PROFILE = "DEFAULT"
  end

  addonTable.Config.CurrentProfile = PLATYNATOR_CONFIG.Profiles[PLATYNATOR_CURRENT_PROFILE]
  ImportDefaultsToProfile()
end

function addonTable.Config.GetProfileNames()
  return GetKeysArray(PLATYNATOR_CONFIG.Profiles)
end

function addonTable.Config.MakeProfile(newProfileName, clone)
  assert(tIndexOf(addonTable.Config.GetProfileNames(), newProfileName) == nil, "Existing Profile")
  if clone then
    PLATYNATOR_CONFIG.Profiles[newProfileName] = CopyTable(addonTable.Config.CurrentProfile)
  else
    PLATYNATOR_CONFIG.Profiles[newProfileName] = {}
  end
  addonTable.Config.ChangeProfile(newProfileName)
end

function addonTable.Config.DeleteProfile(profileName)
  assert(profileName ~= "DEFAULT" and profileName ~= PLATYNATOR_CURRENT_PROFILE)

  PLATYNATOR_CONFIG.Profiles[profileName] = nil
end

function addonTable.Config.DumpCurrentProfile()
  return CopyTable(PLATYNATOR_CONFIG.Profiles[PLATYNATOR_CURRENT_PROFILE])
end

function addonTable.Config.ChangeProfile(newProfileName, comparisonData)
  assert(tIndexOf(addonTable.Config.GetProfileNames(), newProfileName) ~= nil, "Invalid Profile")

  local changedOptions = {}
  local refreshState = {}
  local newProfile = PLATYNATOR_CONFIG.Profiles[newProfileName]
  local oldProfile = comparisonData or addonTable.Config.CurrentProfile

  for name, value in pairs(oldProfile) do
    if value ~= newProfile[name] then
      table.insert(changedOptions, name)
      Mixin(refreshState, addonTable.Config.RefreshType[name] or {})
    end
  end

  tAppendAll(changedOptions, installedNested)

  addonTable.Config.CurrentProfile = newProfile
  PLATYNATOR_CURRENT_PROFILE = newProfileName

  ImportDefaultsToProfile()

  announceChanges = false
  addonTable.Core.MigrateSettings()
  announceChanges = true

  for _, name in ipairs(changedOptions) do
    addonTable.CallbackRegistry:TriggerEvent("SettingChanged", name)
  end
  addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", refreshState)
end

function addonTable.Config.Get(name)
  -- This is ONLY if a config is asked for before variables are loaded
  if addonTable.Config.CurrentProfile == nil then
    return addonTable.Config.Defaults[name]
  elseif name:find("%.", nil, true) == nil then
    return addonTable.Config.CurrentProfile[name]
  else
    local tree = {strsplit(".", name)}
    local root = addonTable.Config.CurrentProfile
    for i = 1, #tree do
      root = root[tree[i]]
      if root == nil then
        break
      end
    end
    return root
  end
end
