---@class addonTablePlatynator
local addonTable = select(2, ...)
addonTable.Core = {}
addonTable.Utilities = {}
addonTable.API = {}
addonTable.Dialogs = {}
addonTable.Display = {}
addonTable.Assets = {}
addonTable.Design = {}
addonTable.CustomiseDialog = {}
addonTable.Skins = {}

Platynator = {}
