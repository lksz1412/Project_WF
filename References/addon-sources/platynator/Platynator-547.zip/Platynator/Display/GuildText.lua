---@class addonTablePlatynator
local addonTable = select(2, ...)

local isColorBlindMode = false

local cvarMonitor = CreateFrame("Frame")
cvarMonitor:RegisterEvent("VARIABLES_LOADED")
cvarMonitor:RegisterEvent("CVAR_UPDATE")
cvarMonitor:SetScript("OnEvent", function()
  isColorBlindMode = GetCVarBool("colorblindmode")
end)

local invalidPattern1 = "^" .. UNIT_TYPE_LEVEL_TEMPLATE:gsub("%%.", ".+") .. "$"
local invalidPattern2 = "^" .. UNIT_LEVEL_TEMPLATE:gsub("%%.", ".+") .. "$"

local tooltip
if not (addonTable.Constants.IsRetail or addonTable.Constants.IsForever) then
  tooltip = CreateFrame("GameTooltip", "PlatynatorUnitGuildTooltip", nil, "GameTooltipTemplate")
end

addonTable.Display.GuildTextMixin = {}

function addonTable.Display.GuildTextMixin:UpdateText()
  self.defaultText = ""

  if UnitIsPlayer(self.unit) then
    if self.details.playerGuild then
      local guild = GetGuildInfo(self.unit)
      if guild then
        self.defaultText = guild
      end
    end
  elseif not UnitIsBattlePetCompanion(self.unit)
    and not addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, delve = true, pvp = true}) then

    if self.details.npcRole then
      local text
      if addonTable.Constants.IsRetail or addonTable.Constants.IsForever then
        local tooltipData = C_TooltipInfo.GetUnit(self.unit)
        local line = tooltipData.lines[isColorBlindMode and 3 or 2]
        if not issecretvalue(line) and line and not issecretvalue(line.leftText) then
          text = line.leftText
        end
      else
        tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")
        tooltip:SetUnit(self.unit)
        local line = _G[tooltip:GetName() .. "TextLeft" .. (isColorBlindMode and 3 or 2)]
        if line then
          text = line:GetText()
        end
      end
      if text and not text:match(invalidPattern1) and not text:match(invalidPattern2) then
        self.defaultText = text
      end
    end
  end

  local override = addonTable.API.TextOverrides.guild[self.unit]
  self.text:SetText(override or self.defaultText)
end

function addonTable.Display.GuildTextMixin:SetUnit(unit)
  self.unit = unit
  if self.unit then
    self:UpdateText()
    self:RegisterUnitEvent("UNIT_NAME_UPDATE", self.unit)
    if self.details.showWhenWowDoes then
      self:SetShown(UnitIsUnit(self.unit, "target") or UnitShouldDisplayName(self.unit))
      self:RegisterUnitEvent("UNIT_HEALTH", self.unit)
    end
    if self.details.showWhenWowDoes then
      addonTable.Cache:RegisterCallback(unit, "target", function()
        self:SetShown(UnitIsUnit(self.unit, "target") or UnitShouldDisplayName(self.unit))
      end)
    end

    addonTable.Display.RegisterForColorEvents(self, self.details.autoColors, self.details.color)
  else
    addonTable.Display.UnregisterForColorEvents(self)
    self.defaultText = nil
    self:UnregisterAllEvents()
  end
end

function addonTable.Display.GuildTextMixin:Strip()
  self.ApplyTextOverride = nil

  self.defaultText = nil
  addonTable.Display.UnregisterForColorEvents(self)
  self:UnregisterAllEvents()
end

function addonTable.Display.GuildTextMixin:SetColor(r, g, b)
  if not r then
    local c = self.details.color
    r, g, b = c.r, c.g, c.b
  end
  self.text:SetTextColor(r, g, b)
end

function addonTable.Display.GuildTextMixin:OnEvent(eventName, ...)
  if eventName == "UNIT_HEALTH" then
    self:SetShown(UnitIsUnit(self.unit, "target") or UnitShouldDisplayName(self.unit))
  elseif eventName == "UNIT_NAME_UPDATE" then
    self:UpdateText()
  end

  self:ColorEventHandler(eventName)
end

function addonTable.Display.GuildTextMixin:ApplyTextOverride()
  local override = addonTable.API.TextOverrides.guild[self.unit]
  self.text:SetText(override or self.defaultText)
end
