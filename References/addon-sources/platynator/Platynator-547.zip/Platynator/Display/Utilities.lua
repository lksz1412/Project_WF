---@class addonTablePlatynator
local addonTable = select(2, ...)

addonTable.Display.Utilities = {}

local function GetColor(rgb)
  local color = CreateColorFromRGBHexString(rgb)
  return {r = color.r, g = color.g, b = color.b}
end

function addonTable.Display.Utilities.IsNeutralUnit(unit)
  if UnitSelectionType then
    return UnitSelectionType(unit) == 2
  else
    return UnitReaction(unit, "player") == 4
  end
end

function addonTable.Display.Utilities.IsUnfriendlyUnit(unit)
  if UnitSelectionType then
    return UnitSelectionType(unit) == 1
  else
    return UnitReaction(unit, "player") == 3
  end
end

function addonTable.Display.Utilities.IsTappedUnit(unit)
  return not UnitPlayerControlled(unit) and UnitIsTapDenied(unit)
end

if addonTable.Constants.IsRetail or addonTable.Constants.IsForever then
  function addonTable.Display.Utilities.GetUnitDifficulty(unit)
    local rawDifficulty = C_PlayerInfo.GetContentDifficultyCreatureForPlayer(unit)
    if rawDifficulty == Enum.RelativeContentDifficulty.Trivial then
      return  "trivial"
    elseif rawDifficulty == Enum.RelativeContentDifficulty.Easy then
      return "standard"
    elseif rawDifficulty == Enum.RelativeContentDifficulty.Fair then
      return "difficult"
    elseif rawDifficulty == Enum.RelativeContentDifficulty.Difficult then
      return "verydifficult"
    elseif rawDifficulty == Enum.RelativeContentDifficulty.Impossible then
      return "impossible"
    else
      return "difficult"
    end
  end
else
  function addonTable.Display.Utilities.GetUnitDifficulty(unit)
    local level = UnitLevel(unit)
    local levelDiff = level - UnitEffectiveLevel("player");
    if levelDiff >= 5 or level == -1 then
      return "impossible"
    elseif levelDiff >= 3 then
      return "verydifficult"
    elseif levelDiff >= -2 then
      return "difficult"
    elseif -levelDiff <= GetQuestGreenRange() then
      return "standard"
    else
      return  "trivial"
    end
  end
end

do
  function addonTable.Display.Utilities.IsInCombatWith(unit)
    return addonTable.Cache:Get(unit, "combat")
  end
end

function addonTable.Display.Utilities.ConvertColor(color)
  return CreateColor(color.r, color.g, color.b, color.a)
end

local rejectedInstanceTypes = {
  ["none"] = true,
  ["neighbourhood"] = true,
  ["interior"] = true,
}

function addonTable.Display.Utilities.IsInRelevantInstance(state)
  local _, baseType = IsInInstance()
  if rejectedInstanceTypes[baseType] then
    return false
  end
  state = state or {dungeon = true}
  local _, instanceType, difficultyID = GetInstanceInfo()
  if state.dungeon and (instanceType == "party") then
    return true
  end
  if state.raid and (instanceType == "raid") then
    return true
  end
  if state.pvp and (instanceType == "arena" or instanceType == "pvp") then
    return true
  end
  if state.delve and difficultyID == 208 then
    return true
  end
  return false
end

local interruptMap
if addonTable.Constants.IsClassic or addonTable.Constants.IsForever then
  interruptMap = {
    ["DEATHKNIGHT"] = {47528},
    ["WARRIOR"] = {1672, --[[Shield Bash, ranks 3-1]] 1671, 72, 6552},
    ["WARLOCK"] = {19647, 89766},
    ["SHAMAN"] = {57994, --[[Earth Shock, ranks 10-1:]] 49231, 49230, 25454, 10414, 10413, 10412, 8046, 8045, 8044, 8042},
    ["ROGUE"] = {1769, 1768, 1767, 1766},
    ["PRIEST"] = {15487},
    ["PALADIN"] = {31935, 96231},
    ["MONK"] = {116705},
    ["MAGE"] = {2139},
    ["HUNTER"] = {187707, 147362},
    ["DRUID"] = {78675, 106839},
  }
else
  interruptMap = {
    ["DEATHKNIGHT"] = {47528},
    ["WARRIOR"] = {6552},
    ["WARLOCK"] = {89766, 119910, 132409},
    ["SHAMAN"] = {57994},
    ["ROGUE"] = {1766},
    ["PRIEST"] = {15487},
    ["PALADIN"] = {96231, 31935},
    ["MONK"] = {116705},
    ["MAGE"] = {2139},
    ["HUNTER"] = {147362, 187707},
    ["EVOKER"] = {351338},
    ["DRUID"] = {78675, 106839},
    ["DEMONHUNTER"] = {183752},
  }
end

local executeMap = {
  -- Hunter
  [5331] = 0.2,
  -- Warrior (Retail)
  [163201] = 0.2, -- (Arms/Prot)
  [5308] = 0.2, -- (Fury)
  [281001] = 0.35, -- (Massacre, Arms/Prot)
  [206315] = 0.35, -- (Massacre, Fury)
  -- Monk (Retail)
  [322109] = 0.15,
  --Priest (Retail)
  [32379] = 0.2,
  [392507] = 0.35, -- (Deathspeaker)
  -- Death Knight (Retail)
  [343294] = 0.35,
  -- Rogue
  [328085] = 0.35,
  -- Warlock
  [388667] = 0.2, -- Drain soul
  [17877] = 0.2, -- Shadowburn
  [234876] = 0.35, -- Death's Embrace

  --Warrior (Classic ranks)
  [20658] = 0.2,
  [20661] = 0.2,
  [20662] = 0.2,
  -- Hunter (Classic ranks)
  [53351] = 0.2,
  [61005] = 0.2,
  [61006] = 0.2,
  -- Monk (MoP)
  [115080] = 0.1,
  -- Paladin (Classic ranks)
  [24275] = 0.2,
  [24274] = 0.2,
  [24239] = 0.2,
  [27180] = 0.2,
  [48805] = 0.2,
  [48806] = 0.2,
}

if addonTable.Constants.IsRetail then
  executeMap[2948] = 0.3 -- Mage: Scorch (critical strike)
end

local sootheSpells = {
  2908,
  374346,
  19801,
  5938,

  -- Arcane Torrent (Blood Elf Racial)
  28730, 25046, 202719, 129597, 80483, 69179, 155145, 50613, 232633
}

local executeCurve = C_CurveUtil.CreateColorCurve()
executeCurve:SetType(Enum.LuaCurveType.Step)

local currentInterrupt = {}
local currentExecute = 0
local isSootheAvailable = false
do
  local class = UnitClassBase("player")
  local interruptSpells = interruptMap[class] or {}

  local frame = CreateFrame("Frame")
  frame:RegisterEvent("PLAYER_LOGIN")
  frame:RegisterEvent("SPELLS_CHANGED")
  frame:SetScript("OnEvent", function()
    currentInterrupt = {}
    for _, s in ipairs(interruptSpells) do
      if C_SpellBook.IsSpellKnownOrInSpellBook(s) or C_SpellBook.IsSpellKnownOrInSpellBook(s, Enum.SpellBookSpellBank.Pet) then
        table.insert(currentInterrupt, s)
      end
    end

    currentExecute = 0
    for s, amount in pairs(executeMap) do
      if C_SpellBook.IsSpellKnown(s) then
        currentExecute = math.max(amount, currentExecute)
      end
    end

    isSootheAvailable = false
    for _, spellID in ipairs(sootheSpells) do
      if C_SpellBook.IsSpellKnown(spellID) then
        isSootheAvailable = true
        break
      end
    end
  end)
end

function addonTable.Display.Utilities.GetInterruptSpells()
  return currentInterrupt
end

do
  local duration
  local lastDurationTime = 0
  function addonTable.Display.Utilities.GetInterruptSpellPriority()
    local interrupt = currentInterrupt[1]
    if interrupt and lastDurationTime ~= GetTime() then
      duration = C_Spell.GetSpellCooldownDuration(interrupt, true)
      lastDurationTime = GetTime()
    end
    return interrupt, duration
  end
end

function addonTable.Display.Utilities.GetExecuteRange()
  return currentExecute
end

function addonTable.Display.Utilities.GetExecuteCurve()
  return executeCurve
end

function addonTable.Display.Utilities.GetSootheAvailable()
  return isSootheAvailable
end

if addonTable.Constants.IsRetail or addonTable.Constants.IsForever then
  local questData = {}
  do
    local frame = CreateFrame("Frame")
    frame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
    frame:RegisterEvent("QUEST_LOG_UPDATE")
    frame:SetScript("OnEvent", function(_, event, unit)
      if event == "NAME_PLATE_UNIT_REMOVED" then
        questData[unit] = nil
      elseif event == "QUEST_LOG_UPDATE" then
        questData = {}
        addonTable.CallbackRegistry:TriggerEvent("QuestInfoUpdate")
      end
    end)
  end

  local questLineTypes = {
    [Enum.TooltipDataLineType.QuestObjective] = true,
    [Enum.TooltipDataLineType.QuestTitle] = true,
    [Enum.TooltipDataLineType.QuestPlayer] = true,
  }
  local playerName = UnitName("player")
  local playerGUID = UnitGUID("player")

  function addonTable.Display.Utilities.GetQuestInfo(unit)
    if questData[unit] then
      return questData[unit]
    end
    if addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, pvp = true}) or C_Secrets.ShouldUnitIdentityBeSecret(unit) then
      questData[unit] = {}
      return questData[unit]
    end

    local info = C_TooltipInfo.GetUnit(unit)
    if info then
      local lines = tFilter(info.lines, function(l)
        return questLineTypes[l.type]
      end, true)
      local data = {}
      local ignoreUntilTitle = false
      for _, l in ipairs(lines) do
        if not ignoreUntilTitle and l.type == Enum.TooltipDataLineType.QuestObjective then
          local count1, count2 = l.leftText:match("(%d+)%/(%d+)")
          if count1 ~= count2 then
            table.insert(data, count1 .. "/" .. count2)
          end
          local percent = l.leftText:match("(%d+)%%")
          if percent and percent ~= "100" then
            table.insert(data, percent .. "%")
          end
        elseif l.type == Enum.TooltipDataLineType.QuestTitle then
          ignoreUntilTitle = false
        elseif l.type == Enum.TooltipDataLineType.QuestPlayer then
          if l.leftText == playerName or l.guid == playerGUID then
            ignoreUntilTitle = false
          else
            ignoreUntilTitle = true
          end
        end
      end
      questData[unit] = data
    else
      questData[unit] = {}
    end

    return questData[unit]
  end
else
  local questData = {}
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
  frame:SetScript("OnEvent", function(_, _, unit)
    questData[unit] = nil
  end)

  local QuestieTooltips

  addonTable.Utilities.OnAddonLoaded("Questie", function()
    Questie.API.RegisterOnReady(function()
      QuestieTooltips = QuestieLoader:ImportModule("QuestieTooltips")
      addonTable.CallbackRegistry:TriggerEvent("QuestInfoUpdate")
      Questie.API.RegisterForQuestUpdates(function()
        questData = {}
        addonTable.CallbackRegistry:TriggerEvent("QuestInfoUpdate")
      end)
    end)
  end)

  function addonTable.Display.Utilities.GetQuestInfo(unit)
    if not Questie or not Questie.API.isReady then
      return {}
    end

    local npcID = UnitGUID(unit):match("Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)")
    if not npcID then
      return {}
    end
    local status = pcall(function()
      local data = QuestieTooltips.lookupByKey["m_" .. npcID]
      if data then
        local result = {}
        for _, tooltip in pairs(data) do
          if not tooltip.name then
            local objective = tooltip.objective
            if objective.Collected ~= objective.Needed then
              table.insert(result, objective.Collected .. "/" .. objective.Needed)
            end
          end
        end
        questData[unit] = result
      end
    end)
    if not status then
      questData[unit] = {Questie.API.GetQuestObjectiveIconForUnit(UnitGUID(unit)) ~= nil and "" or nil}
    end
    return questData[unit] or {}
  end

end

function addonTable.Display.Utilities.TintAutoColors(autoColors, mod)
  if mod.r ~= 1 or mod.g ~= 1 or mod.b ~= 1 then
    local modColors = CopyTable(autoColors)
    for _, s in ipairs(modColors) do
      for l, c in pairs(s.colors) do
        s.colors[l] = {r = mod.r * c.r, g = mod.g * c.g, b = mod.b * c.b, a = mod.a}
      end
      if s.kind == "classColors" then
        for class, c in pairs(RAID_CLASS_COLORS) do
          s.colors[class] = {r = mod.r * c.r, g = mod.g * c.g, b = mod.b * c.b, a = mod.a}
        end
        s.colors.class = CopyTable(mod)
      end
    end

    return modColors
  end
end

do
  local roleType = {
    Damage = 1,
    Healer = 2,
    Tank = 3,
  }

  local role = roleType.Damage
  local isTank = false
  local rangeLimit = 0
  local lastSpecializationIndex = 0
  local specializationID = 0
  local harmChecker, harmMeleeChecker
  local _, playerClass = UnitClass("player")

  local RangeCheck = LibStub("LibRangeCheck-3.0")
  RangeCheck.RegisterCallback("Platynator", RangeCheck.CHECKERS_CHANGED, function()
    harmChecker = RangeCheck:GetHarmMaxChecker(addonTable.Display.Utilities.GetRangedLimit() or RangeCheck.MeleeRange) or function() return nil end
    harmMeleeChecker = RangeCheck:GetHarmMaxChecker(RangeCheck.MeleeRange) or function() return nil end
  end)

  local isDiscovery = C_Seasons and C_Seasons.GetActiveSeason() == Enum.SeasonID.SeasonOfDiscovery or false

  local GetPlayerRole
  if addonTable.Constants.IsEra or addonTable.Constants.IsBC or addonTable.Constants.IsWrath then
    GetPlayerRole = function()
      -- we're in classic
      local form = GetShapeshiftForm()
      if (playerClass == "WARRIOR" and form == 2) or (playerClass == "DRUID" and form == 1) then
        return roleType.Tank
      elseif playerClass == "PALADIN" and (
        C_UnitAuras.GetUnitAuraBySpellID("player", 25780) ~= nil or
        isDiscovery and C_UnitAuras.GetUnitAuraBySpellID("player", 407627)
      ) then
        return roleType.Tank
      elseif isDiscovery and playerClass == "SHAMAN" and C_UnitAuras.GetUnitAuraBySpellID("player", 408680) then
        return roleType.Tank
      elseif isDiscovery and playerClass == "WARLOCK" and C_UnitAuras.GetUnitAuraBySpellID("player", 403789) then
        return roleType.Tank
      elseif isDiscovery and playerClass == "ROGUE" and C_UnitAuras.GetUnitAuraBySpellID("player", 400014) then
        return roleType.Tank
      end
      return roleType.Damage
    end

  elseif addonTable.Constants.IsForever then
    local roleMap = {
      ["DAMAGER"] = roleType.Damage,
      ["TANK"] = roleType.Tank,
      ["HEALER"] = roleType.Healer,
    }

    GetPlayerRole = function()
      if UnitHasEffectivelyTankAura("player") then
        return roleType.Tank
      end
      return roleMap[UnitGroupRolesAssigned("player")] or roleType.Damage
    end

  else
    local roleMap = {
      ["DAMAGER"] = roleType.Damage,
      ["TANK"] = roleType.Tank,
      ["HEALER"] = roleType.Healer,
    }
    GetPlayerRole = function()
      local _, _, _, _, role = C_SpecializationInfo.GetSpecializationInfo(lastSpecializationIndex)

      return roleMap[role]
    end
  end

  local function AssignRange(isPEW)
    if addonTable.Constants.IsEra or addonTable.Constants.IsBC or addonTable.Constants.IsWrath or addonTable.Constants.IsForever then
      rangeLimit = addonTable.Constants.DefaultRange[playerClass]
    else
      rangeLimit = addonTable.Constants.DefaultRange[specializationID]
      for spellID, range in pairs(addonTable.Constants.RangeModifier) do
        if C_SpellBook.IsSpellKnown(spellID) then
          rangeLimit = range
          break
        end
      end
    end
    local newHarmChecker = RangeCheck:GetHarmMaxChecker(addonTable.Display.Utilities.GetRangedLimit() or RangeCheck.MeleeRange)
    local newHarmMeleeChecker = RangeCheck:GetHarmMaxChecker(RangeCheck.MeleeRange)

    -- Avoid overwriting harm checker when changing zone

    if newHarmChecker or not isPEW and not newHarmChecker or not harmChecker then
      harmChecker = newHarmChecker or function() return false end
    end

    if newHarmMeleeChecker or not isPEW and not newHarmMeleeChecker or not harmMeleeChecker then
      harmMeleeChecker = newHarmMeleeChecker or function() return false end
    end
  end

  local function UpdateAuraFilters()
    local allFilters = addonTable.Config.Get(addonTable.Config.Options.AURA_FILTERS)
    if not allFilters[specializationID] then
      allFilters[specializationID] = {
        buffs = { include = {}, exclude = {} },
        debuffs = { include = {}, exclude = {} },
      }
    end

    local allHighlights = addonTable.Config.Get(addonTable.Config.Options.AURA_HIGHLIGHTS)

    if not allHighlights[specializationID] then
      allHighlights[specializationID] = {
        buffs = {
          mode = "health",
          showAll = {color = GetColor("ff0000"), enabled = false},
          showNone = {color = GetColor("00ff00"), enabled = false},
          showIndividualColors = true,
          auras = {}
        },
        debuffs = {
          mode = "health",
          showAll = {color = GetColor("ff0000"), enabled = false},
          showNone = {color = GetColor("00ff00"), enabled = false},
          showIndividualColors = true,
          auras = {}
        }
      }
    end
  end

  function addonTable.Display.Utilities.MigrateAuraFilters()
    if specializationID then
      UpdateAuraFilters()
    end
  end

  do
    local specializationMonitor = CreateFrame("Frame")

    if addonTable.Constants.IsEra or addonTable.Constants.IsBC or addonTable.Constants.IsWrath then
      if playerClass == "WARRIOR" or playerClass == "DRUID" then
        specializationMonitor:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
      elseif playerClass == "PALADIN" or isDiscovery and (playerClass == "SHAMAN" or playerClass == "WARLOCK" or playerClass == "ROGUE") then
        specializationMonitor:RegisterUnitEvent("UNIT_AURA", "player")
      end

    elseif addonTable.Constants.IsForever then
      if playerClass == "WARRIOR" or playerClass == "DRUID" then
        specializationMonitor:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
      elseif playerClass == "PALADIN" then
        specializationMonitor:RegisterUnitEvent("UNIT_AURA", "player")
      end
      specializationMonitor:RegisterEvent("PLAYER_ROLES_ASSIGNED")
      specializationMonitor:RegisterEvent("GROUP_ROSTER_UPDATE")

    elseif C_EventUtils.IsEventValid("PLAYER_SPECIALIZATION_CHANGED") then
      specializationMonitor:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    end

    specializationMonitor:RegisterEvent("PLAYER_ENTERING_WORLD")
    specializationMonitor:RegisterEvent("SPELLS_CHANGED")

    specializationMonitor:SetScript("OnEvent", function(_, e)
      local triggerEvent = false
      if not (addonTable.Constants.IsEra or addonTable.Constants.IsBC or addonTable.Constants.IsWrath or addonTable.Constants.IsForever) then
        local specIndex = C_SpecializationInfo.GetSpecialization() or lastSpecializationIndex
        triggerEvent = specIndex ~= lastSpecializationIndex
        lastSpecializationIndex = specIndex
        specializationID = C_SpecializationInfo.GetSpecializationInfo(specIndex)
      end

      AssignRange(e == "PLAYER_ENTERING_WORLD")
      UpdateAuraFilters()

      if e ~= "SPELLS_CHANGED" then
        local newRole = GetPlayerRole()
        if newRole ~= role then
          role = newRole
          isTank = role == roleType.Tank
          addonTable.CallbackRegistry:TriggerEvent("RoleChange")
        end
      end

      if triggerEvent then
        addonTable.CallbackRegistry:TriggerEvent("SpecializationChanged")
      end
    end)
  end

  function addonTable.Display.Utilities.IsTankRole()
    return isTank
  end

  function addonTable.Display.Utilities.GetRangedLimit()
    return rangeLimit
  end

  function addonTable.Display.Utilities.GetRangeChecker()
    return harmChecker
  end

  function addonTable.Display.Utilities.GetMeleeRangeChecker()
    return harmMeleeChecker
  end

  function addonTable.Display.Utilities.GetSpecializationID()
    if specializationID == 0 then
      local specIndex = C_SpecializationInfo.GetSpecialization() or lastSpecializationIndex
      lastSpecializationIndex = specIndex
      specializationID = C_SpecializationInfo.GetSpecializationInfo(specIndex)
      UpdateAuraFilters()

      return specializationID
    else
      return specializationID
    end
  end
end

do
  local HasMana
  if UnitHasPowerType then
    HasMana = function(unit)
      return UnitHasPowerType(unit, Enum.PowerType.Mana)
    end
  else
    HasMana = function(unit)
      return UnitPowerType(unit) == Enum.PowerType.Mana
    end
  end

  local maxLevel = GetMaxLevelForExpansionLevel(GetMaximumExpansionLevel())

  local instanceTracker = CreateFrame("Frame")
  instanceTracker:RegisterEvent("PLAYER_ENTERING_WORLD")
  instanceTracker:RegisterEvent("PLAYER_LEVEL_UP")
  instanceTracker:RegisterEvent("ZONE_CHANGED_NEW_AREA")
  instanceTracker:RegisterEvent("INSTANCE_GROUP_SIZE_CHANGED")
  instanceTracker:SetScript("OnEvent", function(_, event)
    local inInstance = addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, delve = true, pvp = true})

    local inRaid = addonTable.Display.Utilities.IsInRelevantInstance({raid = true})
    local inDungeon = addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true})
    local inDelve = addonTable.Display.Utilities.IsInRelevantInstance({delve = true})

    local _, _, _, _, _, _, _, _, _, lfgDungeonID = GetInstanceInfo()
    if PLATYNATOR_LAST_INSTANCE == nil
      or inInstance ~= PLATYNATOR_LAST_INSTANCE.inInstance
      or PLATYNATOR_LAST_INSTANCE.lastLFGInstanceID ~= lfgDungeonID
      or not inInstance then
      PLATYNATOR_LAST_INSTANCE = {
        lastLFGInstanceID = lfgDungeonID,
        inInstance = inInstance,
        inRaid = inRaid,
        inDelve = inDelve,
        inDungeon = inDungeon,
      }
      if lfgDungeonID and addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true}) then
        PLATYNATOR_LAST_INSTANCE.level = maxLevel
      else
        PLATYNATOR_LAST_INSTANCE.level = UnitEffectiveLevel("player")
      end
    end
  end)

  local defaultEnabled = {
    boss = true,
    miniboss = true,
    caster = true,
    melee = true,
    trivial = true,
    elite = true,
    rare = true,
  }

  local GetDungeonEliteType, GetRaidEliteType
  if addonTable.Constants.IsRetail then
    local levelTracker = CreateFrame("Frame")
    levelTracker:RegisterEvent("NAME_PLATE_UNIT_ADDED")
    levelTracker:RegisterEvent("UNIT_LEVEL")
    local delveInvalid = {
      ["trival"] = true,
      ["minus"] = true,
    }
    levelTracker:SetScript("OnEvent", function(_, event, unit)
      if unit:match("nameplate%d+") and (PLATYNATOR_LAST_INSTANCE.inDelve and not delveInvalid[UnitClassification(unit)] or PLATYNATOR_LAST_INSTANCE.inDungeon and UnitClassification(unit) == "elite") and
        not (UnitIsPlayer(unit) or UnitTreatAsPlayerForDisplay and UnitTreatAsPlayerForDisplay(unit))
        and not UnitIsFriend("player", unit)
      then
        local level = UnitLevel(unit)
        local prev = PLATYNATOR_LAST_INSTANCE.level
        if level < prev and level > 0 then
          PLATYNATOR_LAST_INSTANCE.level = level
          addonTable.CallbackRegistry:TriggerEvent("DungeonLevelUpdate")
        end
      end
    end)

    GetDungeonEliteType = function(unit, casterOverride, enabled)
      enabled = enabled or defaultEnabled
      local classification = UnitClassification(unit)
      if classification == "elite" then
        local level = UnitEffectiveLevel(unit)
        local dungeonLevel = PLATYNATOR_LAST_INSTANCE.level
        if level == dungeonLevel + 1 and enabled.miniboss then
          return "miniboss"
        elseif ((level == dungeonLevel + 2) or level == -1) and enabled.boss then
          return "boss"
        else
          return HasMana(unit) and "caster" or "melee"
        end
      elseif classification == "normal" or classification == "trivial" or classification == "minus" then
        return casterOverride and HasMana(unit) and "caster" or "trivial"
      end
    end

    GetRaidEliteType = function(unit, casterOverride, enabled)
      enabled = enabled or defaultEnabled
      local classification = UnitClassification(unit)
      if classification == "elite" then
        local level = UnitEffectiveLevel(unit)
        local dungeonLevel = PLATYNATOR_LAST_INSTANCE.level
        if (level == -1 or UnitIsBossMob and UnitIsBossMob(unit)) and enabled.boss then
          return "boss"
        elseif level >= dungeonLevel + 2 and enabled.miniboss then
          return "miniboss"
        else
          return HasMana(unit) and "caster" or "melee"
        end
      elseif classification == "normal" or classification == "trivial" or classification == "minus" then
        return casterOverride and HasMana(unit) and "caster" or "trivial"
      end
    end
  else
    GetDungeonEliteType = function(unit, casterOverride, enabled)
      enabled = enabled or defaultEnabled
      local classification = UnitClassification(unit)
      if classification == "elite" then
        local level = UnitEffectiveLevel(unit)
        if level == -1 and enabled.boss then
          return "boss"
        else
          return HasMana(unit) and "caster" or "melee"
        end
      elseif classification == "normal" or classification == "trivial" or classification == "minus" then
        return casterOverride and HasMana(unit) and "caster" or "trivial"
      end
    end

    GetRaidEliteType = function(unit, casterOverride, enabled)
      enabled = enabled or defaultEnabled
      local classification = UnitClassification(unit)
      if classification == "elite" then
        local level = UnitEffectiveLevel(unit)
        if level == -1 and enabled.boss then
          return "boss"
        else
          return HasMana(unit) and "caster" or "melee"
        end
      elseif classification == "normal" or classification == "trivial" or classification == "minus" then
        return casterOverride and HasMana(unit) and "caster" or "trivial"
      end
    end
  end

  function addonTable.Display.Utilities.GetEliteType(...)
    if PLATYNATOR_LAST_INSTANCE.inRaid then
      return GetRaidEliteType(...)
    else
      return GetDungeonEliteType(...)
    end
  end

  function addonTable.Display.Utilities.GetDelveType(unit, enabled)
    enabled = enabled or defaultEnabled
    local classification = UnitClassification(unit)
    if classification == "elite" then
      local level = UnitEffectiveLevel(unit)
      local dungeonLevel = PLATYNATOR_LAST_INSTANCE.level
      local isRetail = addonTable.Constants.IsRetail
      if (isRetail and level == dungeonLevel + 2 or level == -1) and enabled.boss then
        return "boss"
      else
        return enabled.elite and "elite" or HasMana(unit) and "caster" or "melee"
      end
    elseif classification == "rareelite" and enabled.rare then
      return "rare"
    elseif classification == "normal" then
      return HasMana(unit) and "caster" or "melee"
    elseif classification == "trivial" or classification == "minus" then
      return "trivial"
    end
  end
end

do
  local groupTracker = CreateFrame("Frame")
  groupTracker:RegisterEvent("PLAYER_ENTERING_WORLD")
  groupTracker:RegisterEvent("INSTANCE_GROUP_SIZE_CHANGED")
  groupTracker:RegisterEvent("GROUP_ROSTER_UPDATE")
  groupTracker:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
  groupTracker:RegisterEvent("UNIT_PET")

  local knownTanksAndPetsMap = {}
  local knownTanksAndPetsList = {}

  groupTracker:SetScript("OnEvent", function(_, event, unit)
    local inRaid = IsInRaid()
    if event == "PLAYER_SPECIALIZATION_CHANGED" then
      if inRaid and unit:match("^raid") or not inRaid and unit:match("^party") then
        local role = UnitGroupRolesAssigned(unit)
        knownTanksAndPetsMap[unit] = role == "TANK" or nil
      end
    elseif event == "UNIT_PET" then
      local petUnit
      if inRaid and unit:match("^raid") then
        petUnit = "raidpet" .. unit:gsub("raid", "")
      elseif not inRaid and unit:match("^party") then
        petUnit = "partypet" .. unit:gsub("party", "")
      elseif not inRaid and unit == "player" then
        petUnit = "pet"
      end
      if petUnit then
        knownTanksAndPetsMap[petUnit] = UnitExists(petUnit) or nil
      end
    elseif inRaid then
      knownTanksAndPetsMap = {}
      for i = 1, 40 do
        local playerUnit = "raid" .. i
        if not UnitIsUnit(playerUnit, "player") then
          local role = UnitGroupRolesAssigned(playerUnit)
          local isAssigned = GetPartyAssignment("MAINTANK", playerUnit) or GetPartyAssignment("MAINASSIST", playerUnit)
          knownTanksAndPetsMap[playerUnit] = isAssigned or role == "TANK" or nil
          local petUnit = "raidpet" .. i
          knownTanksAndPetsMap[petUnit] = UnitExists(petUnit) or nil
        end
      end
    else
      knownTanksAndPetsMap = {}
      for i = 1, 4 do
        local playerUnit = "party" .. i
        local role = UnitGroupRolesAssigned(playerUnit)
        local isAssigned = GetPartyAssignment("MAINTANK", playerUnit) or GetPartyAssignment("MAINASSIST", playerUnit)
        knownTanksAndPetsMap[playerUnit] = isAssigned or role == "TANK" or nil
        local petUnit = "partypet" .. i
        knownTanksAndPetsMap[petUnit] = UnitExists(petUnit) or nil
      end
      knownTanksAndPetsMap["pet"] = UnitExists("pet") or nil
    end

    knownTanksAndPetsList = GetKeysArray(knownTanksAndPetsMap)
  end)

  function addonTable.Display.Utilities.GetOtherTanks()
    return knownTanksAndPetsList
  end
end

do
  local encounterID
  local showEnergy = true

  local encountersForNoEnergy = {
    -- Midnight: Magister's Terrace
    [3073] = true, -- Gemellus
    [3074] = true, -- Degentrius
    -- Midnight: Maisara Caverns
    [3212] = true, -- Muro'jin
    [3213] = true, -- Vordaza
    -- Draenor: Skyreach
    [1698] = true, -- Ranjit
  }

  local encounterTracker = CreateFrame("Frame")
  encounterTracker:RegisterEvent("ENCOUNTER_START")
  encounterTracker:RegisterEvent("ENCOUNTER_END")
  encounterTracker:SetScript("OnEvent", function(_, event, newEncounterID)
    if event == "ENCOUNTER_START" then
      encounterID = newEncounterID
      showEnergy = encountersForNoEnergy[encounterID] == nil
    else
      encounterID = nil
      showEnergy = true
    end

    addonTable.CallbackRegistry:TriggerEvent("EncounterUpdate")
  end)

  function addonTable.Display.Utilities.ShouldShowEnergy()
    return showEnergy
  end
end

do
  local auraFormatter = C_StringUtil.CreateNumericRuleFormatter()
  auraFormatter:SetBreakpoints({
    {
      threshold = 0,
      step = 0.1,
      format = "%.1f",
      rounding = Enum.NumericRuleFormatRounding.Down,
    },
    {
      threshold = 3,
      step = 1,
      format = "%d",
      rounding = Enum.NumericRuleFormatRounding.Down,
    },
    {
      threshold = 60,
      format = COOLDOWN_DURATION_MIN,
      components = {
        {
          div = 60,
          step = 1,
          rounding = Enum.NumericRuleFormatRounding.Down,
        }
      }
    }
  })

  local auraPlainFormatter = C_StringUtil.CreateNumericRuleFormatter()
  auraPlainFormatter:SetBreakpoints({
    {
      threshold = 0,
      step = 1,
      format = "%d",
      rounding = Enum.NumericRuleFormatRounding.Down,
    },
    {
      threshold = 60,
      format = COOLDOWN_DURATION_MIN,
      components = {
        {
          div = 60,
          step = 1,
          rounding = Enum.NumericRuleFormatRounding.Down,
        }
      }
    }
  })

  function addonTable.Display.Utilities.GetAuraNumericFormatter()
    return auraFormatter, auraPlainFormatter
  end
end

do
  local curve = C_CurveUtil.CreateCurve()
  curve:AddPoint(0.9999999, 1)
  curve:AddPoint(1, 0)

  function addonTable.Display.Utilities.Get01HiddenCurve()
    return curve
  end
end

do
  local inInstanceOrParty = false
  local instanceTracker = CreateFrame("Frame")
  instanceTracker:RegisterEvent("PLAYER_ENTERING_WORLD")
  instanceTracker:RegisterEvent("ZONE_CHANGED_NEW_AREA")
  instanceTracker:RegisterEvent("INSTANCE_GROUP_SIZE_CHANGED")
  instanceTracker:SetScript("OnEvent", function(_, event)
    inInstanceOrParty = addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, delve = true, pvp = true}) or IsInGroup()
  end)

  function addonTable.Display.Utilities.IsInInstanceOrParty()
    return inInstanceOrParty
  end
end
