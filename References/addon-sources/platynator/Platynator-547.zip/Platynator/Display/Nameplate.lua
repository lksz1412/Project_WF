---@class addonTablePlatynator
local addonTable = select(2, ...)

addonTable.Display.NameplateMixin = {}
function addonTable.Display.NameplateMixin:OnLoad()
  self:SetFlattensRenderLayers(true)
  self:SetCollapsesLayout(true)
  self:SetScript("OnEvent", self.OnEvent)

  self.widgets = {}

  self.SoftTargetIcon = self:CreateTexture(nil, "OVERLAY")
  self.SoftTargetIcon:SetSize(34, 34)
  self.SoftTargetIcon:SetPoint("BOTTOM", self, "TOP", -1, 24)
  self.SoftTargetIcon:Hide()

  self.BuffDisplay = CreateFrame("Frame", nil, self)
  self.BuffDisplay:SetSize(10, 10)
  self.BuffDisplay:SetFrameStrata("MEDIUM")
  self.BuffDisplay:SetFlattensRenderLayers(true)
  self.DebuffDisplay = CreateFrame("Frame", nil, self)
  self.DebuffDisplay:SetSize(10, 10)
  self.DebuffDisplay:SetFrameStrata("MEDIUM")
  self.DebuffDisplay:SetFlattensRenderLayers(true)
  self.CrowdControlDisplay = CreateFrame("Frame", nil, self)
  self.CrowdControlDisplay:SetSize(10, 10)
  self.CrowdControlDisplay:SetFrameStrata("MEDIUM")
  self.CrowdControlDisplay:SetFlattensRenderLayers(true)

  if addonTable.Constants.IsPixelPerfectPlus then
    self.DebuffDisplay:SetRoundLayoutToNearestPixel(true)
    self.BuffDisplay:SetRoundLayoutToNearestPixel(true)
    self.CrowdControlDisplay:SetRoundLayoutToNearestPixel(true)
  end

  self:SetSize(10, 10)

  self.casting = false

  self.sizeChangeCount = -1

  if not addonTable.Constants.IsSecretsActive then
    addonTable.Display.SetupLegacyAuras(self)
  else
    self.AurasManager = addonTable.Utilities.InitFrameWithMixin(self, addonTable.Display.AurasManagerNextMixin)
  end
end


function addonTable.Display.NameplateMixin:OnSizeChanged()
  -- Optimisation to avoid recalculating anchors/sizes while nameplate scales up/down
  self.sizeChangeCount = 0
  self:SetScript("OnUpdate", function()
    self.sizeChangeCount = self.sizeChangeCount + 1
    if self.sizeChangeCount >= 2 then
      self:ApplyPixelPerfectSizing()
      self:SetScript("OnUpdate", nil)
    end
  end)
end

-- Avoid pixel-perfecting the alignment if the scale hasn't changed, or its
-- shrinking cause the nameplate is disappearing
function addonTable.Display.NameplateMixin:ShouldNotSize()
  -- Detect sizing down, which we should ignore
  if not self.unit then
    return true
  end
  local scale = self:GetEffectiveScale()
  return scale == self.lastScale or scale < self.offsetScale
end

function addonTable.Display.NameplateMixin:LayerWidgets()
  addonTable.Display.LayerWidgets(self.widgets)
  if self.aurasInfo then
    if self.aurasInfo.debuffs then
      self.DebuffDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * self.aurasInfo.debuffs.layer + 450)
    end
    if self.aurasInfo.buffs then
      self.BuffDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * self.aurasInfo.buffs.layer + 460)
    end
    if self.aurasInfo.crowdControl then
      self.CrowdControlDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * self.aurasInfo.buffs.layer + 470)
    end
  end
end

function addonTable.Display.NameplateMixin:ApplyPixelPerfectSizing(force)
  if self:ShouldNotSize() and not force then
    return
  end
  if addonTable.Constants.IsPixelPerfectPlus then
    for _, w in ipairs(self.widgets) do
      w:ApplyAnchor()
      w:ApplySize()
    end
  else
    for _, w in ipairs(self.widgets) do
      if w:IsShown() then
        w.pixelPerfectRequired = nil
        w:ApplyAnchor()
        w:ApplySize()
      else
        w.pixelPerfectRequired = true
      end
    end
  end
  if self.aurasInfo then
    self:AnchorAuras(self.aurasInfo)
  end
  self.lastScale = self:GetEffectiveScale()
end

function addonTable.Display.NameplateMixin:InitializeWidgets(design, scaleOffset, scaleMod)
  self.offsetScale = (scaleOffset or 1) * UIParent:GetEffectiveScale() * addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
  self.scale = design.scale * scaleMod

  self.lastScale = self:GetEffectiveScale()

  self.unit = nil
  self:UpdateVisual()

  if self.widgets then
    addonTable.Display.ReleaseWidgets(self.widgets)
    self.AurasManager:ReleaseSlots()
    self.widgets = nil
  end
  self.widgets = addonTable.Display.GetWidgets(design, self)

  local auras = design.auras
  local designInfo = {}
  for _, a in ipairs(auras) do
    designInfo[a.kind] = a
  end
  self.aurasInfo = designInfo
  self:AnchorAuras(designInfo)
  if not addonTable.Constants.IsSecretsActive then
    addonTable.Display.InitializeWidgetsLegacyAuras(self, designInfo)
  else
    for _, w in ipairs(self.widgets) do
      if w.InstallAuras then
        w:InstallAuras(self.AurasManager)
      end
    end

    self.AurasManager:InitializeWidgets(self, designInfo)
  end

  if self:GetScript("OnSizeChanged") == nil and not addonTable.Constants.IsPixelPerfectPlus then
    self:SetScript("OnSizeChanged", self.OnSizeChanged)
  end
  self:SetScript("OnUpdate", nil)
end

function addonTable.Display.NameplateMixin:Install(nameplate, offsetY)
  self:SetFrameStrata("BACKGROUND")
  self:SetPoint("CENTER", nameplate, "CENTER", 0, offsetY)
  self:SetSize(10, 10)

  if not self.unit then
    for _, w in ipairs(self.widgets) do
      w.pixelPerfectRequired = nil
      w:Show()
    end
  end

  -- We force a sizing immediately to avoid 0 size widgets breaking the textures from the Blizz animations
  self:ApplyPixelPerfectSizing()
  addonTable.Display.LayerWidgets(self.widgets)
  self:SetScript("OnUpdate", nil)
  self:Show()
end

function addonTable.Display.NameplateMixin:SetUnit(unit)
  self.SoftTargetIcon:Hide()

  self.interactUnit = unit
  if unit and not UnitNameplateShowsWidgetsOnly(unit) and not UnitIsGameObject(unit) then
    self.unit = unit

    local canAttack = addonTable.Cache:Get(unit, "canAttack")
    if canAttack and addonTable.Config.Get(addonTable.Config.Options.OUT_OF_RANGE_ALPHA) ~= 1 then
      addonTable.Cache:RegisterCallback(self.unit, "range", function(state)
        self.inRange = state
        self:UpdateVisual()
      end)
      self.inRange = addonTable.Cache:Get(self.unit, "range")
    else
      self.inRange = true
    end

    if canAttack and addonTable.Config.Get(addonTable.Config.Options.NOT_IN_PULL_ALPHA) ~= 1 then
      self:RegisterEvent("PLAYER_REGEN_ENABLED")
      self:RegisterEvent("PLAYER_REGEN_DISABLED")

      self.inCombat = addonTable.Display.Utilities.IsInCombatWith(self.unit)
      addonTable.Cache:RegisterCallback(self.unit, "combat", function(inCombat)
        self.inCombat = inCombat
        self:UpdateVisual()
      end)
    else
      self.inCombat = true
    end

    for _, w in ipairs(self.widgets) do
      w:SetUnit(self.unit)
      if w.UpdateAuras then
        w:UpdateAuras(unit, self.AurasManager)
      end
    end

    addonTable.Cache:Get(unit, "mouseover")

    if addonTable.Config.Get(addonTable.Config.Options.NOT_TARGET_ALPHA) ~= addonTable.Config.Get(addonTable.Config.Options.WHEN_NO_TARGET_ALPHA) then
      addonTable.CallbackRegistry:RegisterCallback("TargetChanged", self.UpdateVisual, self)
    end
    addonTable.Cache:RegisterCallback(unit, "target", function()
      self:UpdateVisual()
    end)

    addonTable.Cache:RegisterCallback(unit, "softTarget", function()
      self:UpdateVisual()
    end)

    addonTable.Cache:RegisterCallback(unit, "mouseover", function()
      self:UpdateVisual()
    end)

    if not addonTable.Constants.IsSecretsActive then
      addonTable.Display.SetUnitUpdateLegacyAuras(self, self.unit)
    end
    self.AurasManager:SetUnit(self.unit)


    self:UpdateCastingState(addonTable.Cache:Get(self.unit, "cast"))
    addonTable.Cache:RegisterCallback(self.unit, "cast", function(state)
      local old = self.casting
      self:UpdateCastingState(state)
      if old ~= self.casting then
        self:UpdateVisual()
      end
    end)

    addonTable.CallbackRegistry:RegisterCallback("TextOverrideUpdated", function(_, unit)
      if unit ~= self.unit then
        return
      end
      for _, w in ipairs(self.widgets) do
        if w.ApplyTextOverride then
          w:ApplyTextOverride()
        end
      end
    end, self)
  else
    self.unit = nil
    for _, w in ipairs(self.widgets) do
      w:SetUnit(nil)
      w:Hide()
    end

    if not addonTable.Constants.IsSecretsActive then
      addonTable.Display.SetUnitUpdateLegacyAuras(self, nil)
    end
    self.AurasManager:SetUnit(nil)

    self:UnregisterEvent("PLAYER_REGEN_ENABLED")
    self:UnregisterEvent("PLAYER_REGEN_DISABLED")

    self:UnregisterAllEvents()
    self.casting = false

    addonTable.CallbackRegistry:UnregisterCallback("TextOverrideUpdated", self)
    addonTable.CallbackRegistry:UnregisterCallback("TargetChanged", self)
  end

  self:UpdateVisual()
  if self.interactUnit then
    self:UpdateSoftInteract()
  end
end

local SmartSize = addonTable.Constants.IsPixelPerfectPlus and UIParent.SetSize or PixelUtil.SetSize

function addonTable.Display.NameplateMixin:AnchorAuras(designInfo)
  self.DebuffDisplay.enabled = false
  self.BuffDisplay.enabled = false
  self.CrowdControlDisplay.enabled = false
  local defaultSize = 20
  if designInfo.debuffs then
    self.DebuffDisplay.enabled = true
    self.DebuffDisplay:ClearAllPoints()
    self.DebuffDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * designInfo.debuffs.layer + 450)
    self.DebuffDisplay.details = designInfo.debuffs
    SmartSize(self.DebuffDisplay, defaultSize * designInfo.debuffs.scale, defaultSize * designInfo.debuffs.scale * designInfo.debuffs.height)
    addonTable.Display.ApplyAnchor(self.DebuffDisplay, designInfo.debuffs.anchor)
  end
  if designInfo.buffs then
    self.BuffDisplay.enabled = true
    self.BuffDisplay:ClearAllPoints()
    self.BuffDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * designInfo.buffs.layer + 450 + 10)
    self.BuffDisplay.details = designInfo.buffs
    SmartSize(self.BuffDisplay, defaultSize * designInfo.buffs.scale, defaultSize * designInfo.buffs.scale * designInfo.buffs.height)
    addonTable.Display.ApplyAnchor(self.BuffDisplay, designInfo.buffs.anchor)
  end
  if designInfo.crowdControl then
    self.CrowdControlDisplay.enabled = true
    self.CrowdControlDisplay:ClearAllPoints()
    self.CrowdControlDisplay:SetFrameLevel(addonTable.Constants.LayerFrameLevelStep * designInfo.crowdControl.layer + 450 + 20)
    self.CrowdControlDisplay.details = designInfo.crowdControl
    SmartSize(self.CrowdControlDisplay, defaultSize * designInfo.crowdControl.scale, defaultSize * designInfo.crowdControl.scale * designInfo.crowdControl.height)
    addonTable.Display.ApplyAnchor(self.CrowdControlDisplay, designInfo.crowdControl.anchor)
  end
end

function addonTable.Display.NameplateMixin:UpdateCastingState(state)
  self.casting = state.cast[1] ~= nil or state.channel[1] ~= nil
end

function addonTable.Display.NameplateMixin:OnEvent()
  self:UpdateVisual()
end

function addonTable.Display.NameplateMixin:UpdateVisual()
  local scaleMod = not addonTable.Constants.IsMists and 1 or UIParent:GetEffectiveScale()
  if not self.unit then
    self:SetAlpha(1)
    self:SetScale(self.scale * addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE) * scaleMod)
    return
  end

  local scale = 1
  local alpha = 0
  local isTarget = addonTable.Cache:Get(self.unit, "target") or addonTable.Cache:Get(self.unit, "softTarget")
  if isTarget then
    alpha = 1
  else
    local isMouseover = addonTable.Cache:Get(self.unit, "mouseover")
    if isMouseover then
      alpha = math.max(alpha, addonTable.Config.Get(addonTable.Config.Options.MOUSEOVER_ALPHA))
    end
    if self.casting then
      scale = addonTable.Config.Get(addonTable.Config.Options.CAST_SCALE)
      alpha = math.max(alpha, addonTable.Config.Get(addonTable.Config.Options.CAST_ALPHA))
    end
    if not isMouseover and not self.casting then
      if (UnitExists("target") or UnitExists("softenemy") or UnitExists("softfriend")) then
        alpha = addonTable.Config.Get(addonTable.Config.Options.NOT_TARGET_ALPHA)
      else
        alpha = addonTable.Config.Get(addonTable.Config.Options.WHEN_NO_TARGET_ALPHA)
      end
    end
  end
  if not self.inRange then
    alpha = alpha * addonTable.Config.Get(addonTable.Config.Options.OUT_OF_RANGE_ALPHA)
  end
  if not self.inCombat and UnitAffectingCombat("player") then
    alpha = alpha * addonTable.Config.Get(addonTable.Config.Options.NOT_IN_PULL_ALPHA)
  end
  self:SetScale(self.scale * scale * addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE) * scaleMod)
  self:SetAlpha(alpha)
end

local doEnemyIcon, doFriendIcon, doInteractIcon

local cvarMonitor = CreateFrame("Frame")
cvarMonitor:RegisterEvent("CVAR_UPDATE")
cvarMonitor:RegisterEvent("VARIABLES_LOADED")
cvarMonitor:SetScript("OnEvent", function()
  doEnemyIcon = GetCVarBool("SoftTargetIconEnemy")
  doFriendIcon = GetCVarBool("SoftTargetIconFriend")
  doInteractIcon = GetCVarBool("SoftTargetIconInteract")
end)

function addonTable.Display.NameplateMixin:UpdateSoftInteract()
  -- From Blizzard code, modified
  local hasCursorTexture = false
  if ((doEnemyIcon and UnitIsUnit(self.interactUnit, "softenemy")) or
    (doFriendIcon and UnitIsUnit(self.interactUnit, "softfriend")) or
    (doInteractIcon and UnitIsUnit(self.interactUnit, "softinteract"))
    ) then
    hasCursorTexture = SetUnitCursorTexture(self.SoftTargetIcon, self.interactUnit)
  end
  self.SoftTargetIcon:SetShown(hasCursorTexture)
end
