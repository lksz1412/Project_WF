---@class addonTablePlatynator
local addonTable = select(2, ...)

addonTable.Display.CreatureTextMixin = {}

function addonTable.Display.CreatureTextMixin:SetUnit(unit)
  self.unit = unit
  if self.unit then
    self:RegisterUnitEvent("UNIT_NAME_UPDATE", self.unit)
    self:SaveName()
    self.text:SetText(self.defaultText)

    if self.details.showWhenWowDoes then
      self:RegisterUnitEvent("UNIT_HEALTH", self.unit)
      self:SetShown(UnitShouldDisplayName(self.unit))
      addonTable.Cache:RegisterCallback(unit, "target", function()
        self:SetShown(UnitIsUnit(self.unit, "target") or UnitShouldDisplayName(self.unit))
      end)
    end

    addonTable.Display.RegisterForColorEvents(self, self.details.autoColors, self.details.color)
  else
    addonTable.Display.UnregisterForColorEvents(self)
    self:UnregisterAllEvents()
    self.defaultText = nil
  end
end

function addonTable.Display.CreatureTextMixin:Strip()
  local c = self.details.color
  self.text:SetTextColor(c.r, c.g, c.b)
  self.ApplyTextOverride = nil
  self.defaultText = nil

  addonTable.Display.UnregisterForColorEvents(self)
  self:UnregisterAllEvents()
end

function addonTable.Display.CreatureTextMixin:SetColor(r, g, b)
  if not r then
    local c =  self.details.color
    r, g, b = c.r, c.g, c.b
  end
  self.text:SetTextColor(r, g, b)
end

function addonTable.Display.CreatureTextMixin:OnEvent(eventName, ...)
  if eventName == "UNIT_HEALTH" then
    if self.details.showWhenWowDoes then
      self:SetShown(UnitShouldDisplayName(self.unit))
    end
  elseif eventName == "UNIT_NAME_UPDATE" then
    self:SaveName()
    self.text:SetText(self.defaultText)
  end

  self:ColorEventHandler(eventName)
end

function addonTable.Display.CreatureTextMixin:SaveName()
  if UnitIsPlayer(self.unit) and RegionalUniqueNamesEnabled and RegionalUniqueNamesEnabled() then
    local part1, part2 = UnitName(self.unit)
    if self.details.showFirstNameOnly then
      self.defaultText = part1
    else
      self.defaultText = part1 and part2 and part1 .. Constants.CharacterNameSeparatorConsts.CHARACTERNAME_SURNAME_SEPARATOR .. part2 or part1
    end
  else
    self.defaultText = UnitName(self.unit)
  end
end

function addonTable.Display.CreatureTextMixin:ApplyTextOverride()
  local override = addonTable.API.TextOverrides.name[self.unit]
  self.text:SetText(override or self.defaultText)
end
