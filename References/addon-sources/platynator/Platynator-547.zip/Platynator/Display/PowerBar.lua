---@class addonTablePlatynator
local addonTable = select(2, ...)

local specializationToDivisor = {
  [265] = addonTable.Constants.IsMists and 100 or nil,
  [267] = addonTable.Constants.IsMists and 10 or nil,
}
local specializationToPower = {
  --Rogue (all specs)
  [259] = Enum.PowerType.ComboPoints,
  [260] = Enum.PowerType.ComboPoints,
  [261] = Enum.PowerType.ComboPoints,
  [1453] = Enum.PowerType.ComboPoints,
  --Druid (feral only)
  [103] = Enum.PowerType.ComboPoints,
  [1447] = Enum.PowerType.ComboPoints,
  --Death Knight (all specs)
  [250] = Enum.PowerType.Runes,
  [251] = Enum.PowerType.Runes,
  [252] = Enum.PowerType.Runes,
  --Warlock (all specs)
  [265] = Enum.PowerType.SoulShards,
  [266] = addonTable.Constants.IsRetail and Enum.PowerType.SoulShards or nil,
  [267] = addonTable.Constants.IsMists and Enum.PowerType.BurningEmbers or Enum.PowerType.SoulShards,
  [1454] = Enum.PowerType.SoulShards,
  --Paladin (all specs)
  [65] = Enum.PowerType.HolyPower,
  [66] = Enum.PowerType.HolyPower,
  [70] = Enum.PowerType.HolyPower,
  [1451] = Enum.PowerType.HolyPower,
  --Monk (windwalker)
  [269] = Enum.PowerType.Chi,
  --Mage (arcane only)
  [62] = Enum.PowerType.ArcaneCharges,
  --Evokers
  [1465] = Enum.PowerType.Essence, -- No spec
  [1467] = Enum.PowerType.Essence,
  [1468] = Enum.PowerType.Essence,
  [1473] = Enum.PowerType.Essence,
}

-- Used in classic era, so excludes classes without an appropriate resource
local classToSpec = {
  ["ROGUE"] = 259,
  ["DRUID"] = 103,
}

local specializationToColor = {
  --Rogue (all specs)
  [259] = CreateColorFromRGBHexString("f71322"),
  [260] = CreateColorFromRGBHexString("f71322"),
  [261] = CreateColorFromRGBHexString("f71322"),
  [1453] = CreateColorFromRGBHexString("f71322"),
  --Druid (feral only)
  [103] = CreateColorFromRGBHexString("e82020"),
  [1447] = CreateColorFromRGBHexString("e82020"),
  --Death Knight (all specs)
  [250] = CreateColorFromRGBHexString("fc3c3f"),
  [251] = CreateColorFromRGBHexString("4282d1"),
  [252] = CreateColorFromRGBHexString("3cc435"),
  --Warlock (all specs)
  [265] = CreateColorFromRGBHexString("b61ff2"),
  [266] = CreateColorFromRGBHexString("b61ff2"),
  [267] = CreateColorFromRGBHexString("b61ff2"),
  [1454] = CreateColorFromRGBHexString("b61ff2"),
  --Paladin (all specs)
  [65] = CreateColorFromRGBHexString("f0c900"),
  [66] = CreateColorFromRGBHexString("f0c900"),
  [70] = CreateColorFromRGBHexString("f0c900"),
  [1451] = CreateColorFromRGBHexString("f0c900"),
  --Monk (windwalker)
  [269] = CreateColorFromRGBHexString("31f78a"),
  --Mage (arcane only)
  [62] = CreateColorFromRGBHexString("46d8fc"),
  --Evokers
  [1465] = CreateColorFromRGBHexString("37e5fc"), -- No spec
  [1467] = CreateColorFromRGBHexString("37e5fc"),
  [1468] = CreateColorFromRGBHexString("37e5fc"),
  [1473] = CreateColorFromRGBHexString("37e5fc"),
}

local powerKind, powerColor, powerDivisor, chargedColor

local specializationMonitor = CreateFrame("Frame")
specializationMonitor:RegisterEvent("PLAYER_LOGIN")
if C_EventUtils.IsEventValid("PLAYER_SPECIALIZATION_CHANGED") then
  specializationMonitor:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
end
specializationMonitor:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
specializationMonitor:SetScript("OnEvent", function()
  local specID
  if UnitClassBase("player") == "DRUID" then
    if GetShapeshiftFormID() == 1 then
      specID = classToSpec["DRUID"]
    end
  elseif addonTable.Constants.IsRetail or addonTable.Constants.IsMists then
    local specIndex = C_SpecializationInfo.GetSpecialization()
    specID = C_SpecializationInfo.GetSpecializationInfo(specIndex)
  else
    specID = classToSpec[UnitClassBase("player")]
  end

  powerKind = specializationToPower[specID]
  powerColor = specializationToColor[specID]
  powerDivisor = specializationToDivisor[specID]
  chargedColor = CreateColorFromRGBHexString("00aaff")

  addonTable.CallbackRegistry:TriggerEvent("PowerChange")
end)

addonTable.Display.PowerBarMixin = {}

function addonTable.Display.PowerBarMixin:PostInit()
  if not self.details.useSpecColors then
    self.fixedColor = self.details.fixedColor
  else
    self.fixedColor = nil
  end
end

function addonTable.Display.PowerBarMixin:Strip()
  self.asset = nil
  self.registered = nil
  self:UnregisterAllEvents()
  addonTable.CallbackRegistry:UnregisterCallback("PowerChange", self)
end

function addonTable.Display.PowerBarMixin:SetUnit(unit)
  self.unit = unit
  if unit then
    self:ApplyTarget()
    addonTable.Cache:RegisterCallback(unit, "target", function()
      self:ApplyTarget()
    end)
  else
    self:UnregisterAllEvents()
    addonTable.CallbackRegistry:UnregisterCallback("PowerChange", self)
    self.registered = nil
  end
end

function addonTable.Display.PowerBarMixin:ApplyTarget()
  local isTarget = addonTable.Cache:Get(self.unit, "target")
  local canAttack = addonTable.Cache:Get(self.unit, "canAttack")
  if isTarget and canAttack and not self.registeredForPower then
    self.registeredForPower = true
    addonTable.CallbackRegistry:RegisterCallback("PowerChange", self.ApplyTarget, self)
  elseif not isTarget and self.registeredForPower then
    self.registeredForPower = nil
    addonTable.CallbackRegistry:UnregisterCallback("PowerChange", self)
  end

  if powerKind and isTarget and canAttack then
    if not self.registered then
      self:RegisterEvent("UNIT_POWER_UPDATE")
      self:RegisterEvent("RUNE_POWER_UPDATE")
      if addonTable.Constants.IsRetail then
        self:RegisterEvent("UNIT_POWER_POINT_CHARGE")
      end
    end

    local maxPower
    local currentPower = 0
    if powerKind == Enum.PowerType.Runes then
      maxPower = addonTable.Constants.DeathKnightMaxRunes
      for index = 1, addonTable.Constants.DeathKnightMaxRunes do
        local _, _, ready = GetRuneCooldown(index)
        if ready then
          currentPower = currentPower + 1
        end
      end
    elseif (addonTable.Constants.IsClassic or addonTable.Constants.IsForever) and powerKind == Enum.PowerType.ComboPoints then
      maxPower = UnitPowerMax("player", powerKind)
      currentPower = GetComboPoints("player", "target")
    else
      maxPower = UnitPowerMax("player", powerKind)
      currentPower = UnitPower("player", powerKind)
      if powerDivisor then
        currentPower = currentPower / powerDivisor
        maxPower = maxPower / powerDivisor
      end
    end
    if maxPower == 0 then
      self:Hide()
      return
    elseif addonTable.Constants.IsForever then
      self:Show()
      self:SetValueSecret(currentPower, maxPower, self.fixedColor or powerColor)
      return
    else
      self:Show()

      local points = {}
      local color = self.fixedColor or powerColor
      for i = 1, maxPower do
        table.insert(points, {set = i <= currentPower, color = color})
      end

      if addonTable.Constants.IsRetail then
        local charged = GetUnitChargedPowerPoints("player")
        if charged then
          for _, i in ipairs(charged) do
            points[i].color = chargedColor
          end
        end
      end

      self:SetValue(points, currentPower)
    end
  else
    self.registered = nil
    self:UnregisterAllEvents()
    self:Hide()
  end
end

function addonTable.Display.PowerBarMixin:OnEvent()
  self:ApplyTarget()
end
