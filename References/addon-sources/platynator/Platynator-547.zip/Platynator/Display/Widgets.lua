---@class addonTablePlatynator
local addonTable = select(2, ...)

local LSM = LibStub("LibSharedMedia-3.0")

local SmartSize = addonTable.Constants.IsPixelPerfectPlus and UIParent.SetSize or PixelUtil.SetSize
local SmartPoint = addonTable.Constants.IsPixelPerfectPlus and UIParent.SetPoint or PixelUtil.SetPoint
local SmartConvert = addonTable.Constants.IsPixelPerfectPlus and function(a) return a end or PixelUtil.ConvertPixelsToUIForRegion

function addonTable.Display.ApplyAnchor(frame, anchor, scale)
  scale = scale or 1
  frame:ClearAllPoints()
  if #anchor == 0 then
    frame:SetPoint("CENTER")
  elseif #anchor == 3 then
    SmartPoint(frame, anchor[1], frame:GetParent(), "CENTER", anchor[2] * scale, anchor[3] * scale)
  elseif #anchor == 2 then
    SmartPoint(frame, "CENTER", frame:GetParent(), "CENTER", anchor[1] * scale, anchor[2] * scale)
  elseif #anchor == 1 then
    frame:SetPoint(anchor[1], frame:GetParent(), "CENTER")
  end
end

local function GetAuraSettings()
  return addonTable.Config.Get(addonTable.Config.Options.AURA_HIGHLIGHTS)[addonTable.Display.Utilities.GetSpecializationID()]
end

local ApplyAnchor = addonTable.Display.ApplyAnchor

local function InitBar(frame, details)
  if frame.Strip then
    frame:Strip()
  end

  local borderDetails = LSM:Fetch("ninesliceborder", details.border.asset, true) or LSM:Fetch("ninesliceborder", "MM: 4px")
  assert(borderDetails)
  local borderSliceDetails = LSM:Fetch("nineslice", borderDetails.nineslice)
  assert(borderSliceDetails)

  frame.lowerScale = 1/borderSliceDetails.scaleModifier
  frame.rawWidth, frame.rawHeight = details.border.width * addonTable.Assets.BarBordersSize.width, details.border.height * addonTable.Assets.BarBordersSize.height
  frame.borderWidth = frame.rawWidth + (borderSliceDetails.padding.left + borderSliceDetails.padding.right) / 2
  frame.borderHeight = frame.rawHeight + (borderSliceDetails.padding.top + borderSliceDetails.padding.bottom) / 2

  local foreground = LSM:Fetch("statusbar", details.foreground.asset, true) or LSM:Fetch("statusbar", "MM: Solid White")
  frame.statusBar:SetScale(borderSliceDetails.scaleModifier * details.scale)
  frame.statusBar:SetMinMaxValues(0, 1)
  frame.statusBar:SetValue(1)
  frame.statusBar:SetStatusBarTexture(foreground)
  frame.statusBar:GetStatusBarTexture():SetDrawLayer("ARTWORK")

  local background = LSM:Fetch("statusbar", details.background.asset, true) or LSM:Fetch("statusbar", "MM: Solid Grey")
  frame.background:SetTexture(background)
  frame.background:SetAllPoints()
  frame.background:SetScale(borderSliceDetails.scaleModifier * details.scale)
  frame.background:SetVertexColor(details.background.color.r, details.background.color.g, details.background.color.b, details.background.color.a)
  frame.border:SetTexture(borderSliceDetails.file)
  frame.border:SetScale(borderSliceDetails.scaleModifier * details.scale)
  frame.border:SetVertexColor(details.border.color.r, details.border.color.g, details.border.color.b, details.border.color.a)
  frame.border:SetTextureSliceMargins(borderSliceDetails.margins.left, borderSliceDetails.margins.top, borderSliceDetails.margins.right, borderSliceDetails.margins.bottom)
  frame.statusBar:GetStatusBarTexture():RemoveMaskTexture(frame.edgeMask)
  frame.marker:Hide()
  if details.marker.asset ~= "MM: Transparency" then
    local markerDetails = LSM:Fetch("spark", details.marker.asset)
    if markerDetails then
      frame.marker:Show()
      frame.marker:SetTexture(markerDetails.file)
      frame.marker.rawWidth = markerDetails.width
      frame.marker.rawOffset = markerDetails.offset
      local color = details.marker.color
      frame.marker:SetVertexColor(color.r, color.g, color.b)
      if markerDetails.mask then
        frame.edgeMask:SetBlockingLoadsRequested(true)
        frame.edgeMask:SetTexture(markerDetails.mask, "CLAMPTOWHITE", "CLAMPTOWHITE")
        frame.statusBar:GetStatusBarTexture():AddMaskTexture(frame.edgeMask)
      end
    end
  end

  frame.statusBar:GetStatusBarTexture():RemoveMaskTexture(frame.mask)
  frame.background:RemoveMaskTexture(frame.mask)
  frame.marker:RemoveMaskTexture(frame.mask)

  local maskDetails = borderDetails.mask
  frame.mask:SetBlockingLoadsRequested(true)
  frame.mask:SetTexture(maskDetails.file, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
  frame.mask:SetTextureSliceMargins(maskDetails.margins.left, maskDetails.margins.top, maskDetails.margins.right, maskDetails.margins.bottom)
  frame.mask:SetScale(details.scale)

  frame.statusBar:GetStatusBarTexture():AddMaskTexture(frame.mask)
  frame.background:AddMaskTexture(frame.mask)
  frame.marker:AddMaskTexture(frame.mask)

  frame.details = details
end

local function SizeBar(frame, details)
  SmartSize(frame, frame.rawWidth * details.scale, frame.rawHeight * details.scale)

  SmartSize(frame.statusBar, frame.rawWidth * frame.lowerScale, frame.rawHeight * frame.lowerScale)
  SmartSize(frame.border, frame.borderWidth * frame.lowerScale, frame.borderHeight * frame.lowerScale)
  if frame.marker:IsShown() then
    SmartSize(frame.marker, frame.marker.rawWidth * details.scale * frame.lowerScale, frame.rawHeight * frame.lowerScale)
    SmartSize(frame.edgeMask, frame.marker.rawWidth * details.scale, frame.rawHeight * details.scale)
  end
end

local function AnchorBar(frame, details)
  ApplyAnchor(frame, frame.details.anchor)
  if frame.marker:IsShown() then
    SmartPoint(frame.marker, "RIGHT", frame.statusBar:GetStatusBarTexture(), "RIGHT", details.scale * frame.lowerScale * frame.marker.rawOffset, 0)
    SmartPoint(frame.edgeMask, "RIGHT", frame.statusBar:GetStatusBarTexture(), "RIGHT", details.scale * frame.marker.rawOffset + 1, 0)
  end
end

local function ArrangeAuras(frame, auraManager, height, kind, filterString)
  local settings = GetAuraSettings()[kind]
  local allocated = 0
  local lastAura
  local firstAura
  local auraFrames = {}
  local missing = {}
  for i = #settings.auras, 1, -1 do
    local point = {"BOTTOM", lastAura, "TOP"}
    if not lastAura then
      point = {"BOTTOM", frame, "BOTTOM", 0, -height}
    end
    local aura = auraManager:AcquireSlot(height, point, filterString, settings.auras[i].spellID)
    if not firstAura then
      firstAura = aura
    end
    lastAura = aura
    auraFrames[i] = aura
  end

  if settings.showAll.enabled then
    allocated = allocated + 1
    local current = frame.auras[kind].textures[allocated]
    current.mask:ClearPoint("TOP")
    current.mask:ClearPoint("BOTTOM")
    current.mask:SetHeight(height)
    current.texture:SetDrawLayer("OVERLAY", 6)
    local color = settings.showAll.color
    current.texture:SetVertexColor(color.r, color.g, color.b)
    frame.auras[kind].pillar:SetSize(10, #settings.auras * height)
    current.aligner:SetPoint("BOTTOM", lastAura, "TOP")
    frame.auras[kind].pillar:SetPoint("TOP", current.aligner, "BOTTOM")
    current.mask:SetPoint("BOTTOM", frame.auras[kind].pillar, "BOTTOM", 0, height)
  end

  if settings.showNone.enabled then
    allocated = allocated + 1
    local current = frame.auras[kind].textures[allocated]
    current.mask:ClearPoint("TOP")
    current.mask:ClearPoint("BOTTOM")
    current.mask:SetHeight(height)
    current.texture:SetDrawLayer("OVERLAY", 6)
    local color = settings.showNone.color
    current.texture:SetVertexColor(color.r, color.g, color.b)
    current.aligner:SetPoint("BOTTOM", firstAura, "TOP")
    current.mask:SetPoint("BOTTOM", current.aligner, "BOTTOM", 0, height)
    table.insert(missing, current.texture)
  end

  if settings.showIndividualColors then
    for index, details in ipairs(settings.auras) do
      allocated = allocated + 1
      local current = frame.auras[kind].textures[allocated]
      current.mask:ClearPoint("TOP")
      current.mask:ClearPoint("BOTTOM")
      current.mask:SetHeight(height)
      current.texture:SetDrawLayer("OVERLAY")
      local color = details.color
      current.texture:SetVertexColor(color.r, color.g, color.b)
      current.aligner:SetPoint("BOTTOM", auraFrames[index], "TOP")
      if details.isMissing then
        current.mask:SetPoint("BOTTOM", current.aligner, "BOTTOM", 0, height)
        table.insert(missing, current.texture)
      else
        current.mask:SetPoint("BOTTOM", current.aligner)
      end
    end
  end

  frame.auras[kind].allocated = allocated
  frame.auras[kind].missing = missing
end

local function UpdateAurasForKind(frame, kind, unit)
  for i = 1, frame.auras[kind].allocated do
    frame.auras[kind].textures[i].texture:Show()
  end
  if frame.auras[kind].allocated < #frame.auras[kind].textures then
    for i = frame.auras[kind].allocated + 1, #frame.auras[kind].textures do
      frame.auras[kind].textures[i].texture:Hide()
    end
  end
  if #frame.auras[kind].missing > 0 then
    local isCombat = addonTable.Cache:Get(unit, "combat")
    for _, t in ipairs(frame.auras[kind].missing) do
      t:SetShown(isCombat)
    end
    addonTable.Cache:RegisterCallback(unit, "combat", function(state)
      for _, t in ipairs(frame.auras[kind].missing) do
        t:SetShown(state)
      end
    end)
  end
end

local function UpdateAuras(frame, unit, auraManager)
  if frame.auras.debuffs and frame.auras.debuffs.active then
    if not UnitCanAssist("player", unit, true, true) then
      UpdateAurasForKind(frame, "debuffs", unit)
    else
      for _, details in ipairs(frame.auras.debuffs.textures) do
        details.texture:Hide()
      end
    end
  end
  if frame.auras.buffs and frame.auras.buffs.active then
    if UnitCanAssist("player", unit, true, true) then
      UpdateAurasForKind(frame, "buffs", unit)
    else
      for _, details in ipairs(frame.auras.buffs.textures) do
        details.texture:Hide()
      end
    end
  end
end

function addonTable.Display.GetHealthBar(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.statusBarAbsorb = CreateFrame("StatusBar", nil, frame)
  frame.statusBarAbsorb:SetStatusBarTexture("Interface/AddOns/Platynator/Assets/Special/transparent.png")

  frame.statusBar = CreateFrame("StatusBar", nil, frame)
  frame.statusBar:SetPoint("CENTER")
  frame.statusBar:SetStatusBarTexture("Interface/AddOns/Platynator/Assets/Special/white.png")

  frame.absorbClipping = CreateFrame("Frame", nil, frame)
  frame.absorbClipping:SetAllPoints(frame.statusBarAbsorb:GetStatusBarTexture())
  frame.absorbClipping:SetClipsChildren(true)
  frame.absorbTexture = frame.absorbClipping:CreateTexture(nil, "ARTWORK", nil, -1)
  frame.absorbTexture:SetAllPoints(frame.statusBar)

  frame.marker = frame.statusBar:CreateTexture(nil, "OVERLAY", nil, 7)
  frame.marker:SetSnapToPixelGrid(false)

  local borderHolder = CreateFrame("Frame", nil, frame)
  frame.border = borderHolder:CreateTexture()
  frame.border:SetDrawLayer("OVERLAY")
  frame.border:SetPoint("CENTER", frame)

  frame.mask = frame:CreateMaskTexture()
  frame.mask:SetAllPoints(frame.statusBar)

  frame.edgeMask = frame:CreateMaskTexture()

  frame.background = frame:CreateTexture()
  frame.background:SetPoint("CENTER")
  frame.background:SetDrawLayer("BACKGROUND")

  frame.auras = {}

  function frame:Init(details)
    InitBar(frame, details)

    local borderDetails = LSM:Fetch("ninesliceborder", details.border.asset, true) or LSM:Fetch("ninesliceborder", "MM: 4px")
    assert(borderDetails)
    local borderSliceDetails = LSM:Fetch("nineslice", borderDetails.nineslice)
    assert(borderSliceDetails)

    frame.absorbTexture:SetTexture(LSM:Fetch("statusbar", details.absorb.asset, true) or LSM:Fetch("statusbar", "MM: Absorb Wide"))
    frame.absorbTexture:SetVertexColor(details.absorb.color.r, details.absorb.color.g, details.absorb.color.b, details.absorb.color.a)
    frame.statusBarAbsorb:SetPoint("LEFT", frame.statusBar:GetStatusBarTexture(), "RIGHT")
    frame.absorbTexture:RemoveMaskTexture(frame.mask)

    frame:GenerateCutaway(details)

    if frame.statusBarCutaway then
      frame.statusBarCutaway:SetShown(details.animate)
    end
    if details.animate then
      frame.statusBarCutaway:SetStatusBarTexture(LSM:Fetch("statusbar", details.foreground.asset, true) or LSM:Fetch("statusbar", "MM: Solid White"))
      frame.statusBarCutaway:SetScale(borderSliceDetails.scaleModifier * details.scale)
      frame.statusBarCutaway:GetStatusBarTexture():RemoveMaskTexture(frame.mask)
      frame.statusBarCutaway:SetAlpha(0)
      frame.statusBarCutawayMask:SetPoint("LEFT", frame.statusBar:GetStatusBarTexture(), "RIGHT")
      frame.statusBarCutawayMask:SetScale(details.scale)

      frame.statusBarCutaway:GetStatusBarTexture():AddMaskTexture(frame.statusBarCutawayMask)
      frame.statusBarCutaway:GetStatusBarTexture():AddMaskTexture(frame.mask)
    end

    frame.statusBarAbsorb:SetScale(details.scale)
    frame.absorbClipping:SetScale(borderSliceDetails.scaleModifier * details.scale)

    frame.absorbTexture:AddMaskTexture(frame.mask)

    if details.kind == "health" then
      Mixin(frame, addonTable.Display.HealthBarMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:GenerateCutaway(details)
    if frame.statusBarCutaway or not details.animate then
      return
    end

    frame.statusBarCutaway = CreateFrame("StatusBar", nil, frame)
    frame.statusBarCutawayAnimation = frame.statusBarCutaway:CreateAnimationGroup()
    frame.statusBarCutawayAnimation:SetToFinalAlpha(true)
    local alpha = frame.statusBarCutawayAnimation:CreateAnimation("Alpha")
    alpha:SetSmoothing("IN_OUT")
    alpha:SetFromAlpha(1)
    alpha:SetToAlpha(0)
    alpha:SetDuration(0.3)
    frame.statusBarCutawayMask = frame.statusBarCutaway:CreateMaskTexture()
    frame.statusBarCutawayMask:SetBlockingLoadsRequested(true)
    frame.statusBarCutawayMask:SetTexture("Interface/AddOns/Platynator/Assets/Special/white.png", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    frame.statusBarCutawayMask:SetTextureSliceMargins(1, 1, 1, 1)

    frame.statusBarCutaway:SetAllPoints(frame.statusBar)
  end

  function frame:ApplyFrameLevels()
    if frame.statusBarCutaway then
      frame.statusBarCutaway:SetFrameLevel(frame:GetFrameLevel() + 1)
    end
    frame.statusBarAbsorb:SetFrameLevel(frame:GetFrameLevel() + 2)
    frame.statusBar:SetFrameLevel(frame:GetFrameLevel() + 3)
    borderHolder:SetFrameLevel(frame:GetFrameLevel() + 5)
  end

  function frame:ApplyAnchor()
    AnchorBar(frame, frame.details)
  end

  function frame:ApplySize()
    SizeBar(frame, frame.details)
    SmartSize(frame.statusBarAbsorb, frame.rawWidth, frame.rawHeight)
    if frame.statusBarCutaway then
      SmartSize(frame.statusBarCutawayMask, frame.rawWidth * frame.lowerScale, frame.rawHeight * frame.lowerScale)
    end
  end

  function frame:SetMarkerAlpha(a)
    self.marker:SetAlpha(a)
  end

  function frame:InstallAurasForKind(auraManager, kind, filterString)
    if addonTable.Utilities.IsChangesRestricted() then
      return
    end
    local settings = GetAuraSettings()[kind]
    if #settings.auras == 0 or settings.mode ~= "health" then
      if frame.auras[kind] then
        frame.auras[kind].active = false
        for _, details in ipairs(frame.auras[kind].textures) do
          details.texture:Hide()
        end
      end
      return
    end
    if not frame.auras[kind] then
      frame.auras[kind] = {textures = {}}
      frame.auras[kind].maskWrapper = CreateFrame("Frame", nil, frame, "DisableUntrustedLayoutScriptsTemplate")
      frame.auras[kind].maskWrapper:SetAllPoints()
      frame.auras[kind].pillar = CreateFrame("Frame", nil, frame, "DisableUntrustedLayoutScriptsTemplate")
    end
    frame.auras[kind].active = true
    local foreground = LSM:Fetch("statusbar", frame.details.foreground.asset, true) or LSM:Fetch("statusbar", "MM: Solid White")

    local limit = (settings.showIndividualColors and #settings.auras or 0) + (settings.showAll.enabled and 1 or 0) + (settings.showNone.enabled and 1 or 0)
    if #frame.auras[kind].textures < limit then
      for i = #frame.auras[kind].textures + 1, limit do
        local t = frame.statusBar:CreateTexture(nil, "OVERLAY", nil, 5)
        local m = frame.auras[kind].maskWrapper:CreateMaskTexture()
        t:SetAllPoints(frame.statusBar)
        m:SetBlockingLoadsRequested(true)
        m:SetTexture("Interface/AddOns/Platynator/Assets/Special/white.png", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE", "NEAREST")
        m:SetPoint("LEFT", frame.statusBar:GetStatusBarTexture(), -5, 0)
        m:SetPoint("RIGHT", frame.statusBar:GetStatusBarTexture(), 0, 0)
        t:AddMaskTexture(m)
        t:AddMaskTexture(frame.mask)
        local a = frame.auras[kind].maskWrapper:CreateTexture()
        a:SetWidth(10)
        a:SetHeight(0.000001)
        a:SetColorTexture(0, 0, 0, 0)
        table.insert(frame.auras[kind].textures, {texture = t, mask = m, aligner = a})
      end
    end

    for index, details in ipairs(frame.auras[kind].textures) do
      details.texture:RemoveMaskTexture(frame.edgeMask)
      details.texture:SetTexture(foreground)
    end

    local markerDetails = LSM:Fetch("spark", frame.details.marker.asset)
    if markerDetails and markerDetails.mask then
      for _, details in ipairs(frame.auras[kind].textures) do
        details.texture:AddMaskTexture(frame.edgeMask)
      end
    end

    local height = SmartConvert(frame.rawHeight * frame.details.scale, frame) + 1
    ArrangeAuras(frame, auraManager, height, kind, filterString)
  end

  function frame:InstallAuras(auraManager)
    self:InstallAurasForKind(auraManager, "debuffs", "HARMFUL|PLAYER")
    self:InstallAurasForKind(auraManager, "buffs", "HELPFUL|PLAYER")
  end

  frame.UpdateAuras = UpdateAuras

  return frame
end

function addonTable.Display.GetCastBar(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.statusBar = CreateFrame("StatusBar", nil, frame)
  frame.statusBar:SetPoint("CENTER")

  frame.marker = frame.statusBar:CreateTexture(nil, "OVERLAY", nil, 7)
  frame.marker:SetSnapToPixelGrid(false)

  local borderHolder = CreateFrame("Frame", nil, frame)
  frame.border = borderHolder:CreateTexture()
  frame.border:SetDrawLayer("OVERLAY")
  frame.border:SetPoint("CENTER", frame)

  frame.mask = frame:CreateMaskTexture()
  frame.mask:SetAllPoints(frame.statusBar)

  frame.edgeMask = frame:CreateMaskTexture()

  frame.background = frame:CreateTexture()
  frame.background:SetPoint("CENTER")
  frame.background:SetDrawLayer("BACKGROUND")

  frame.interruptPositioner = CreateFrame("StatusBar", nil, frame)
  frame.interruptPositioner:SetStatusBarTexture("Interface/AddOns/Platynator/Special/transparent.png")
  frame.interruptPositioner:SetPoint("CENTER")

  frame.interruptMarker = CreateFrame("StatusBar", nil, frame)
  frame.interruptMarker:SetStatusBarTexture("Interface/AddOns/Platynator/Special/transparent.png")
  frame.interruptMarkerPoint = frame.interruptMarker:CreateTexture()
  frame.interruptMarkerPoint:SetColorTexture(1, 1, 1)
  frame.interruptMarkerPoint:SetWidth(5)
  frame.interruptMarker:SetPoint("LEFT", frame.interruptPositioner:GetStatusBarTexture(), "RIGHT")
  frame.interruptMarkerPoint:SetPoint("LEFT", frame.interruptMarker:GetStatusBarTexture(), "RIGHT")

  function frame:ReverseInterruptMarker(state)
    if state then
      self.interruptMarker:SetFillStyle(Enum.StatusBarFillStyle.Reverse)
      self.interruptPositioner:SetFillStyle(Enum.StatusBarFillStyle.Reverse)
      self.interruptMarker:ClearAllPoints()
      self.interruptMarkerPoint:ClearAllPoints()
      self.interruptMarker:SetPoint("RIGHT", frame.interruptPositioner:GetStatusBarTexture(), "LEFT")
      self.interruptMarkerPoint:SetPoint("RIGHT", frame.interruptMarker:GetStatusBarTexture(), "LEFT")
    else
      self.interruptMarker:SetFillStyle(Enum.StatusBarFillStyle.Standard)
      self.interruptPositioner:SetFillStyle(Enum.StatusBarFillStyle.Standard)
      self.interruptMarker:ClearAllPoints()
      self.interruptMarkerPoint:ClearAllPoints()
      self.interruptMarker:SetPoint("LEFT", frame.interruptPositioner:GetStatusBarTexture(), "RIGHT")
      self.interruptMarkerPoint:SetPoint("LEFT", frame.interruptMarker:GetStatusBarTexture(), "RIGHT")
    end
  end

  function frame:Init(details)
    InitBar(frame, details)

    local borderDetails = LSM:Fetch("ninesliceborder", details.border.asset, true) or LSM:Fetch("ninesliceborder", "MM: 4px")
    assert(borderDetails)
    local borderSliceDetails = LSM:Fetch("nineslice", borderDetails.nineslice)
    assert(borderSliceDetails)

    frame.interruptMarker:SetScale(borderSliceDetails.scaleModifier * details.scale)
    frame.interruptPositioner:SetScale(borderSliceDetails.scaleModifier * details.scale)
    frame.interruptMarker.active = false
    if details.interruptMarker.asset ~= "MM: Transparency" then
      local markerDetails = LSM:Fetch("spark", details.interruptMarker.asset)
      if markerDetails then
        frame.interruptMarker.active = true
        frame.interruptMarker.rawWidth = markerDetails.width
        frame.interruptMarker.rawOffset = markerDetails.offset
        frame.interruptMarkerPoint:SetTexture(markerDetails.file)
        local color = details.interruptMarker.color
        frame.interruptMarkerPoint:SetVertexColor(color.r, color.g, color.b)
      end
    end

    frame.interruptMarkerPoint:RemoveMaskTexture(frame.mask)
    frame.interruptMarkerPoint:AddMaskTexture(frame.mask)

    frame.details = details

    if details.kind == "cast" then
      Mixin(frame, addonTable.Display.CastBarMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyFrameLevels()
    frame.statusBar:SetFrameLevel(frame:GetFrameLevel() + 2)
    frame.interruptMarker:SetFrameLevel(frame:GetFrameLevel() + 5)
    borderHolder:SetFrameLevel(frame:GetFrameLevel() + 6)
  end

  function frame:ApplyAnchor()
    AnchorBar(frame, frame.details)
  end

  function frame:ApplySize()
    local details = frame.details
    SizeBar(frame, details)

    local lowerScale = frame.lowerScale
    frame.interruptMarkerPoint:SetHeight(frame.rawHeight * lowerScale)
    frame.interruptMarker:SetSize(frame.rawWidth * lowerScale, frame.rawHeight * lowerScale)
    frame.interruptPositioner:SetSize(frame.rawWidth * lowerScale, frame.rawHeight * lowerScale)
    if details.interruptMarker.asset ~= "MM: Transparency" then
      SmartSize(frame.interruptMarkerPoint, frame.interruptMarker.rawWidth * details.scale * lowerScale, frame.rawHeight * lowerScale)
    end
  end

  return frame
end

function addonTable.Display.GetEnergyBar(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.statusBar = CreateFrame("StatusBar", nil, frame)
  frame.statusBar:SetPoint("CENTER")

  frame.marker = frame.statusBar:CreateTexture()
  frame.marker:SetSnapToPixelGrid(false)

  local borderHolder = CreateFrame("Frame", nil, frame)
  frame.border = borderHolder:CreateTexture()
  frame.border:SetDrawLayer("OVERLAY")
  frame.border:SetPoint("CENTER", frame)

  frame.mask = frame:CreateMaskTexture()
  frame.mask:SetAllPoints(frame.statusBar)

  frame.edgeMask = frame:CreateMaskTexture()

  frame.background = frame:CreateTexture()
  frame.background:SetPoint("CENTER")
  frame.background:SetDrawLayer("BACKGROUND")

  function frame:Init(details)
    InitBar(frame, details)

    if details.kind == "energy" then
      Mixin(frame, addonTable.Display.EnergyBarMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyFrameLevels()
    frame.statusBar:SetFrameLevel(frame:GetFrameLevel() + 3)
    borderHolder:SetFrameLevel(frame:GetFrameLevel() + 5)
  end

  function frame:ApplyAnchor()
    AnchorBar(frame, frame.details)
  end

  function frame:ApplySize()
    SizeBar(frame, frame.details)
  end

  return frame
end

function addonTable.Display.GetPower(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.powerTextures = {}
  frame.powerStatusPips = {}

  function frame:Init(details)
    if frame.Strip then
      frame:Strip()
    end

    frame.details = details

    Mixin(frame, addonTable.Display.PowerBarMixin)

    frame:SetScript("OnEvent", frame.OnEvent)

    self.asset = addonTable.Assets.PowerBars[self.details.asset]

    for _, t in ipairs(self.powerTextures) do
      t:SetTexture(self.asset.file)
    end

    for _, sb in ipairs(self.powerStatusPips) do
      sb.empty:SetTexture(self.asset.file)
      sb.filled:SetTexture(self.asset.file)
    end

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
    local maxPower = self.lastMaxPower
    self.lastMaxPower = nil
    SmartSize(self, (self.asset.width - self.asset.inset) * (self.points and #self.points or 0), self.asset.height)
    if self.points then
      self:SetValue(self.points)
    elseif self.currentPower and maxPower then
      self:SetValueSecret(self.currentPower, maxPower, self.lastColor)
    end
  end

  function frame:SetValue(points)
    local maxPower = #points
    self.points = points
    if self.lastMaxPower ~= maxPower then
      local width = SmartConvert(self.asset.width * self.details.scale, self)
      local height = SmartConvert(self.asset.height * self.details.scale, self)
      while #self.powerTextures < maxPower do
        local t = self:CreateTexture(nil, "ARTWORK")
        t:SetTexture(self.asset.file)

        table.insert(self.powerTextures, t)
      end

      if #self.powerTextures > maxPower then
        for i = maxPower + 1, #self.powerTextures do
          self.powerTextures[i]:Hide()
        end
      end

      local offset = SmartConvert((-(self.asset.width - self.asset.inset) * maxPower/2 - self.asset.inset / 2) * self.details.scale, self)
      local step = SmartConvert((self.asset.width - self.asset.inset) * self.details.scale, self)
      for i = 1, maxPower do
        local t = self.powerTextures[i]
        t:ClearAllPoints()
        t:SetPoint("LEFT", self, "CENTER", offset, 0)
        t:SetSize(width, height)
        t:Show()
        offset = offset + step
      end

      self.lastMaxPower = maxPower

      SmartSize(self, (self.asset.width - self.asset.inset) * self.details.scale * maxPower, (self.asset.height - self.asset.inset) * self.details.scale)
    end

    if maxPower > 0 then
      for i, point in ipairs(points) do
        local t = self.powerTextures[i]
        t:SetSpriteSheetCell(point.set and 1 or 2, 1, 2)
        t:SetVertexColor(point.color.r, point.color.g, point.color.b)
      end
    end
  end

  function frame:SetValueSecret(currentPower, maxPower, color)
    self.currentPower = currentPower
    self.lastColor = color
    if self.lastMaxPower ~= maxPower then
      local width = SmartConvert(self.asset.width * self.details.scale, self)
      local height = SmartConvert(self.asset.height * self.details.scale, self)
      while #self.powerStatusPips < maxPower do
        local sb = CreateFrame("StatusBar", nil, self)
        sb:SetStatusBarTexture("Interface/AddOns/Platynator/Special/transparent.png")
        sb:SetClipsChildren(true)
        sb.empty = sb:CreateTexture()
        sb.empty:SetPoint("LEFT", sb:GetStatusBarTexture(), "RIGHT")
        sb.empty:SetTexture(self.asset.file)
        sb.empty:SetSpriteSheetCell(2, 1, 2)
        sb.filled = sb:CreateTexture()
        sb.filled:SetTexture(self.asset.file)
        sb.filled:SetSpriteSheetCell(1, 1, 2)
        sb.filled:SetAllPoints(sb:GetStatusBarTexture())
        sb:SetMinMaxValues(#self.powerStatusPips, #self.powerStatusPips + 1)
        sb:SetValue(#self.powerStatusPips)

        table.insert(self.powerStatusPips, sb)
      end

      if #self.powerStatusPips > maxPower then
        for i = maxPower + 1, #self.powerStatusPips do
          self.powerStatusPips[i]:Hide()
        end
      end

      local offset = SmartConvert((-(self.asset.width - self.asset.inset) * maxPower/2 - self.asset.inset / 2) * self.details.scale, self)
      local step = SmartConvert((self.asset.width - self.asset.inset) * self.details.scale, self)
      for i = 1, maxPower do
        local sb = self.powerStatusPips[i]
        sb:ClearAllPoints()
        sb:SetPoint("LEFT", self, "CENTER", offset, 0)
        sb:SetSize(width, height)
        sb.empty:SetSize(width, height)
        sb:Show()
        offset = offset + step
      end

      self.lastMaxPower = maxPower

      SmartSize(self, (self.asset.width - self.asset.inset) * self.details.scale * maxPower, (self.asset.height - self.asset.inset) * self.details.scale)
    end

    if maxPower > 0 then
      for i = 1, maxPower do
        local sb = self.powerStatusPips[i]
        sb:SetValue(currentPower)
        sb.filled:SetVertexColor(color.r, color.g, color.b)
        sb.empty:SetVertexColor(color.r, color.g, color.b)
      end
    end
  end
end

function addonTable.Display.GetHighlight(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.highlight = frame:CreateTexture()
  frame.highlight:SetAllPoints()

  function frame:Init(details)
    local highlightDetails = (details.sliced and (LSM:Fetch("nineslice", details.asset, true) or LSM:Fetch("nineslice", "MM: 7px"))) or (LSM:Fetch("platynator/sizedtexture", details.asset, true) or LSM:Fetch("platynator/sizedtexture", "MM: Glow"))
    assert(highlightDetails)
    frame.details = details

    frame.highlight:SetTexture(highlightDetails.file)
    frame.highlight:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)
    frame.highlight:SetScale(details.scale)

    if details.sliced then
      frame.highlight:SetScale(highlightDetails.scaleModifier * details.scale)
      frame.highlight:SetTextureSliceMargins(highlightDetails.margins.left, highlightDetails.margins.top, highlightDetails.margins.right, highlightDetails.margins.bottom)
    else
      frame.highlight:ClearTextureSlice()
    end

    if details.kind == "target" then
      Mixin(frame, addonTable.Display.TargetHighlightMixin)
    elseif details.kind == "softTarget" then
      Mixin(frame, addonTable.Display.SoftTargetHighlightMixin)
    elseif details.kind == "focus" then
      Mixin(frame, addonTable.Display.FocusHighlightMixin)
    elseif details.kind == "mouseover" then
      Mixin(frame, addonTable.Display.MouseoverHighlightMixin)
    elseif details.kind == "automatic" then
      Mixin(frame, addonTable.Display.AutomaticHighlightMixin)
    elseif details.kind == "fixed" then
      Mixin(frame, addonTable.Display.FixedHighlightMixin)
    elseif details.kind == "auras" then
      Mixin(frame, addonTable.Display.FixedHighlightMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
    local details = frame.details
    local highlightDetails = (details.sliced and (LSM:Fetch("nineslice", details.asset, true) or LSM:Fetch("nineslice", "MM: 7px"))) or (LSM:Fetch("platynator/sizedtexture", details.asset, true) or LSM:Fetch("platynator/sizedtexture", "MM: Glow"))
    assert(highlightDetails)
    if details.sliced then
      local width, height = details.width * addonTable.Assets.BarBordersSize.width, details.height * addonTable.Assets.BarBordersSize.height
      frame.rawWidth, frame.rawHeight = width * details.scale, height * details.scale
      SmartSize(frame, frame.rawWidth, frame.rawHeight)
      SmartSize(frame.highlight, (width + (highlightDetails.padding.left + highlightDetails.padding.right) / 2) / highlightDetails.scaleModifier, (height + (highlightDetails.padding.top + highlightDetails.padding.bottom) / 2) / highlightDetails.scaleModifier)
    else
      frame.rawWidth, frame.rawHeight = highlightDetails.width * details.width * details.scale, highlightDetails.height * details.height * details.scale
      SmartSize(frame, frame.rawWidth, frame.rawHeight)
      SmartSize(frame.highlight, highlightDetails.width * details.width, highlightDetails.height * details.height)
    end
  end

  return frame
end

function addonTable.Display.GetAnimatedBorderHighlight(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.Animation = frame:CreateAnimationGroup()
  do
    frame.Top = frame:CreateTexture()
    frame.Top:SetPoint("TOPLEFT")
    frame.Top:SetPoint("TOPRIGHT")
    frame.Top:SetTexture("Interface/AddOns/Platynator/Assets/Special/pandemic.png")
    frame.Bottom = frame:CreateTexture()
    frame.Bottom:SetPoint("BOTTOMLEFT")
    frame.Bottom:SetPoint("BOTTOMRIGHT")
    frame.Bottom:SetTexture("Interface/AddOns/Platynator/Assets/Special/pandemic.png")
    frame.Bottom:SetRotation(math.pi)
    frame.Left = frame:CreateTexture()
    frame.Left:SetPoint("TOPLEFT")
    frame.Left:SetPoint("BOTTOMLEFT")
    frame.Left:SetTexture("Interface/AddOns/Platynator/Assets/Special/pandemic-90.png")
    frame.Right = frame:CreateTexture()
    frame.Right:SetPoint("TOPRIGHT")
    frame.Right:SetPoint("BOTTOMRIGHT")
    frame.Right:SetTexture("Interface/AddOns/Platynator/Assets/Special/pandemic-90.png")
    frame.Right:SetRotation(math.pi)
    frame.TopFlipBook = frame.Animation:CreateAnimation("Flipbook")
    frame.TopFlipBook:SetTarget(frame.Top)
    frame.BottomFlipBook = frame.Animation:CreateAnimation("Flipbook")
    frame.BottomFlipBook:SetTarget(frame.Bottom)
    frame.LeftFlipBook = frame.Animation:CreateAnimation("Flipbook")
    frame.LeftFlipBook:SetTarget(frame.Left)
    frame.RightFlipBook = frame.Animation:CreateAnimation("Flipbook")
    frame.RightFlipBook:SetTarget(frame.Right)
    frame.Animation:SetLooping("REPEAT")
  end

  function frame:Init(details)
    local highlightDetails = addonTable.Assets.Highlights[details.asset]
    frame.defaultBorderDim = highlightDetails.defaultWidth
    frame.details = details

    frame.Top:SetTexture(highlightDetails.horizontal)
    frame.Bottom:SetTexture(highlightDetails.horizontal)
    frame.Right:SetTexture(highlightDetails.vertical)
    frame.Left:SetTexture(highlightDetails.vertical)
    frame.Top:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)
    frame.Bottom:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)
    frame.Right:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)
    frame.Left:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)

    frame.TopFlipBook:SetFlipBookColumns(highlightDetails.columns)
    frame.TopFlipBook:SetFlipBookRows(highlightDetails.rows)
    frame.BottomFlipBook:SetFlipBookColumns(highlightDetails.columns)
    frame.BottomFlipBook:SetFlipBookRows(highlightDetails.rows)
    frame.RightFlipBook:SetFlipBookColumns(highlightDetails.rows)
    frame.RightFlipBook:SetFlipBookRows(highlightDetails.columns)
    frame.LeftFlipBook:SetFlipBookColumns(highlightDetails.rows)
    frame.LeftFlipBook:SetFlipBookRows(highlightDetails.columns)

    frame.TopFlipBook:SetDuration(highlightDetails.duration)
    frame.BottomFlipBook:SetDuration(highlightDetails.duration)
    frame.LeftFlipBook:SetDuration(highlightDetails.duration)
    frame.RightFlipBook:SetDuration(highlightDetails.duration)

    if details.kind == "animatedBorder" then
      Mixin(frame, addonTable.Display.AnimatedBorderHighlightMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
    local details = frame.details
    SmartSize(frame, addonTable.Assets.BarBordersSize.width * details.width * details.scale, addonTable.Assets.BarBordersSize.height * details.height * details.scale)

    local dim = SmartConvert(details.borderWidth * frame.defaultBorderDim, frame)
    frame.Top:SetHeight(dim)
    frame.Bottom:SetHeight(dim)
    frame.Left:SetWidth(dim)
    frame.Right:SetWidth(dim)
  end

  return frame
end

function addonTable.Display.GetFlashingHighlight(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.highlight = frame:CreateTexture()
  frame.highlight:SetAllPoints()

  frame.Animation = frame:CreateAnimationGroup()
  local fadeOut = frame.Animation:CreateAnimation("Alpha")
  fadeOut:SetTarget(frame.highlight)
  fadeOut:SetFromAlpha(1)
  fadeOut:SetToAlpha(0.3)
  fadeOut:SetOrder(1)
  fadeOut:SetSmoothing("IN_OUT")
  frame.Animation:SetLooping("BOUNCE")
  frame.Animation:Stop()

  function frame:Init(details)
    local highlightDetails = (details.sliced and (LSM:Fetch("nineslice", details.asset, true) or LSM:Fetch("nineslice", "MM: 7px"))) or (LSM:Fetch("platynator/sizedtexture", details.asset, true) or LSM:Fetch("platynator/sizedtexture", "MM: Glow"))
    assert(highlightDetails)
    frame.details = details
    frame.highlight:SetAlpha(1)

    fadeOut:SetDuration(0.4 / details.speed)

    frame.highlight:SetTexture(highlightDetails.file)
    frame.highlight:SetVertexColor(details.color.r, details.color.g, details.color.b, details.color.a)
    frame.highlight:SetScale(details.scale)

    if details.sliced then
      frame.highlight:SetScale(highlightDetails.scaleModifier * details.scale)
      frame.highlight:SetTextureSliceMargins(highlightDetails.margins.left, highlightDetails.margins.top, highlightDetails.margins.right, highlightDetails.margins.bottom)
    else
      frame.highlight:ClearTextureSlice()
    end

    if details.kind == "flashing" then
      Mixin(frame, addonTable.Display.FlashingHighlightMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
    local details = frame.details
    local highlightDetails = (details.sliced and (LSM:Fetch("nineslice", details.asset, true) or LSM:Fetch("nineslice", "MM: 7px"))) or (LSM:Fetch("platynator/sizedtexture", details.asset, true) or LSM:Fetch("platynator/sizedtexture", "MM: Glow"))
    assert(highlightDetails)
    if details.sliced then
      local width, height = details.width * addonTable.Assets.BarBordersSize.width, details.height * addonTable.Assets.BarBordersSize.height
      SmartSize(frame, width * details.scale, height * details.scale)
      SmartSize(frame.highlight, (width + (highlightDetails.padding.left + highlightDetails.padding.right) / 2) / highlightDetails.scaleModifier, (height + (highlightDetails.padding.top + highlightDetails.padding.bottom) / 2) / highlightDetails.scaleModifier)
    else
      SmartSize(frame, highlightDetails.width * details.width * details.scale, highlightDetails.height * details.height * details.scale)
      SmartSize(frame.highlight, highlightDetails.width * details.width, highlightDetails.height * details.height)
    end
  end

  function frame:SetColor(...)
    self:SetShown(... ~= nil)
    self.Animation:SetPlaying(... ~= nil)
    if ... then
      local _, _, _, a = ...
      self:SetAlpha(a)
      self.highlight:SetVertexColor(...)
    end
  end

  return frame
end

function addonTable.Display.GetBorderedHighlight(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.border = frame:CreateTexture()
  frame.border:SetDrawLayer("OVERLAY")
  frame.border:SetPoint("CENTER")

  frame.mask = frame:CreateMaskTexture()
  frame.mask:SetAllPoints(frame)

  frame.background = frame:CreateTexture()
  frame.background:SetPoint("CENTER")
  frame.background:SetDrawLayer("BACKGROUND")

  function frame:Init(details)
    if frame.Strip then
      frame:Strip()
    end

    frame.details = details

    local borderDetails = LSM:Fetch("ninesliceborder", details.border.asset, true) or LSM:Fetch("ninesliceborder", "MM: 4px")
    assert(borderDetails)
    local borderSliceDetails = LSM:Fetch("nineslice", borderDetails.nineslice)
    assert(borderSliceDetails)

    frame.lowerScale = 1/borderSliceDetails.scaleModifier
    frame.rawWidth, frame.rawHeight = details.border.width * addonTable.Assets.BarBordersSize.width, details.border.height * addonTable.Assets.BarBordersSize.height
    frame.borderWidth = frame.rawWidth + (borderSliceDetails.padding.left + borderSliceDetails.padding.right) / 2
    frame.borderHeight = frame.rawHeight + (borderSliceDetails.padding.top + borderSliceDetails.padding.bottom) / 2

    local background = LSM:Fetch("statusbar", details.background.asset, true) or LSM:Fetch("statusbar", "MM: Solid Grey")
    frame.background:SetTexture(background)
    frame.background:SetAllPoints()
    frame.background:SetScale(borderSliceDetails.scaleModifier * details.scale)
    frame.background:SetVertexColor(details.background.color.r, details.background.color.g, details.background.color.b, details.background.color.a)

    frame.border:SetTexture(borderSliceDetails.file)
    frame.border:SetScale(borderSliceDetails.scaleModifier * details.scale)
    frame.border:SetVertexColor(details.border.color.r, details.border.color.g, details.border.color.b, details.border.color.a)
    frame.border:SetTextureSliceMargins(borderSliceDetails.margins.left, borderSliceDetails.margins.top, borderSliceDetails.margins.right, borderSliceDetails.margins.bottom)
    frame.border:SetShown(details.border.show)

    local maskDetails = borderDetails.mask
    frame.mask:SetBlockingLoadsRequested(true)
    frame.mask:SetTexture(maskDetails.file, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    frame.mask:SetTextureSliceMargins(maskDetails.margins.left, maskDetails.margins.top, maskDetails.margins.right, maskDetails.margins.bottom)
    frame.mask:SetScale(details.scale)

    frame.background:AddMaskTexture(frame.mask)

    if details.kind == "fixedBordered" then
      Mixin(frame, addonTable.Display.FixedHighlightMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
    local details = frame.details
    SmartSize(frame, frame.rawWidth * details.scale, frame.rawHeight * details.scale)

    SmartSize(frame.background, frame.rawWidth * frame.lowerScale, frame.rawHeight * frame.lowerScale)
    SmartSize(frame.border, frame.borderWidth * frame.lowerScale, frame.borderHeight * frame.lowerScale)
  end

  return frame
end

function addonTable.Display.GetAuraHighlight(frame, parent)
  local frame = addonTable.Display.GetHighlight(frame, parent)

  frame.auras = {}

  function frame:InstallAurasForKind(auraManager, kind, filterString)
    frame.highlight:Hide()
    if addonTable.Utilities.IsChangesRestricted() then
      return
    end
    local settings = GetAuraSettings()[kind]
    if #settings.auras == 0 or settings.mode ~= "highlight" then
      if frame.auras[kind] then
        frame.auras[kind].active = false
        for _, details in ipairs(frame.auras[kind].textures) do
          details.texture:Hide()
        end
      end
      return
    end
    if not frame.auras[kind] then
      frame.auras[kind] = {textures = {}}
      frame.auras[kind].maskWrapper = CreateFrame("Frame", nil, frame, "DisableUntrustedLayoutScriptsTemplate")
      frame.auras[kind].maskWrapper:SetAllPoints()
      frame.auras[kind].pillar = CreateFrame("Frame", nil, frame, "DisableUntrustedLayoutScriptsTemplate")
    end
    frame.auras[kind].active = true
    local highlightDetails = (frame.details.sliced and (LSM:Fetch("nineslice", frame.details.asset, true) or LSM:Fetch("nineslice", "MM: 7px"))) or (LSM:Fetch("platynator/sizedtexture", frame.details.asset, true) or LSM:Fetch("platynator/sizedtexture", "MM: Glow"))

    local limit = (settings.showIndividualColors and #settings.auras or 0) + (settings.showAll.enabled and 1 or 0) + (settings.showNone.enabled and 1 or 0)
    if #frame.auras[kind].textures < limit then
      for i = #frame.auras[kind].textures + 1, limit do
        local t = frame:CreateTexture(nil, "OVERLAY", nil, 5)
        local m = frame.auras[kind].maskWrapper:CreateMaskTexture()
        t:SetAllPoints(frame.highlight)
        m:SetBlockingLoadsRequested(true)
        m:SetTexture("Interface/AddOns/Platynator/Assets/Special/white.png", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE", "NEAREST")
        m:SetPoint("LEFT", frame, 0, 0)
        m:SetPoint("RIGHT", frame, 0, 0)
        t:AddMaskTexture(m)
        local a = frame.auras[kind].maskWrapper:CreateTexture()
        a:SetWidth(10)
        a:SetHeight(0.000001)
        a:SetColorTexture(0, 0, 0, 0)
        table.insert(frame.auras[kind].textures, {texture = t, mask = m, aligner = a})
      end
    end

    for _, details in ipairs(frame.auras[kind].textures) do
      details.texture:SetTexture(highlightDetails.file)
      details.texture:SetVertexColor(frame.details.color.r, frame.details.color.g, frame.details.color.b, frame.details.color.a)
      details.texture:SetScale(frame.details.scale)

      if frame.details.sliced then
        details.texture:SetScale(highlightDetails.scaleModifier * frame.details.scale)
        details.texture:SetTextureSliceMargins(highlightDetails.margins.left, highlightDetails.margins.top, highlightDetails.margins.right, highlightDetails.margins.bottom)
      else
        details.texture:ClearTextureSlice()
      end
    end

    ArrangeAuras(frame, auraManager, frame.rawHeight, kind, filterString)
  end
  function frame:InstallAuras(auraManager)
    self:InstallAurasForKind(auraManager, "debuffs", "HARMFUL|PLAYER")
    self:InstallAurasForKind(auraManager, "buffs", "HELPFUL|PLAYER")
  end

  frame.UpdateAuras = UpdateAuras
end

function addonTable.Display.GetMarker(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)

  frame.marker = frame:CreateTexture()

  frame.marker:SetAllPoints()

  function frame:Init(details)
    frame.details = details

    local markerDetails = addonTable.Assets.Markers[details.asset]

    frame.marker:SetTexture(markerDetails.file)
    if details.color then
      frame.marker:SetVertexColor(details.color.r, details.color.g, details.color.b)
    else
      frame.marker:SetVertexColor(1, 1, 1)
    end

    if details.kind == "quest" then
      Mixin(frame, addonTable.Display.QuestMarkerMixin)
    elseif details.kind == "cannotInterrupt" then
      Mixin(frame, addonTable.Display.CannotInterruptMarkerMixin)
    elseif details.kind == "elite" then
      Mixin(frame, addonTable.Display.EliteMarkerMixin)
    elseif details.kind == "rare" then
      Mixin(frame, addonTable.Display.RareMarkerMixin)
    elseif details.kind == "raid" then
      Mixin(frame, addonTable.Display.RaidMarkerMixin)
    elseif details.kind == "castIcon" then
      Mixin(frame, addonTable.Display.CastIconMarkerMixin)
    elseif details.kind == "pvp" then
      Mixin(frame, addonTable.Display.PvPMarkerMixin)
    elseif details.kind == "faction" then
      Mixin(frame, addonTable.Display.FactionMarkerMixin)
    elseif details.kind == "boss" then
      Mixin(frame, addonTable.Display.BossMarkerMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
    if frame.PostApplyAnchor then
      frame:PostApplyAnchor()
    end
  end

  function frame:ApplySize()
    local details = frame.details
    local markerDetails = addonTable.Assets.Markers[details.asset]
    SmartSize(frame, markerDetails.width * details.scale, markerDetails.height * details.scale)
  end

  return frame
end

function addonTable.Display.GetText(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)
  frame:SetSize(1, 1)

  frame.text = frame:CreateFontString(nil, nil, "GameFontNormal")
  frame.text:SetPoint("CENTER")
  frame.text:SetText(" ")

  function frame:Init(details)
    if frame.Strip then
      frame:Strip()
    end

    frame.details = details

    frame.text:SetFontObject(addonTable.CurrentFont)
    frame.text:ClearAllPoints()
    frame.text:SetPoint(details.anchor[1] or "CENTER")
    frame.text:SetTextColor(details.color.r, details.color.g, details.color.b)
    frame.text:SetWordWrap(not details.truncate)
    frame.text:SetNonSpaceWrap(false)
    frame.text:SetSpacing(0)

    frame.text:SetJustifyV("BOTTOM")
    if details.align ~= frame.text:GetJustifyH() then
      frame.text:SetText(" ")
    end
    frame.text:SetJustifyH(details.align)
    local scale = details.scale * 0.85
    local width = details.maxWidth * addonTable.Assets.BarBordersSize.width
    frame.text:SetSmoothScaling(addonTable.CurrentFontUsesSmoothing)
    frame.text:SetScale(scale)
    frame.text:SetWidth(width / scale)

    if details.kind == "health" then
      Mixin(frame, addonTable.Display.HealthTextMixin)
    elseif details.kind == "damageAbsorb" then
      Mixin(frame, addonTable.Display.AbsorbTextMixin)
    elseif details.kind == "creatureName" then
      Mixin(frame, addonTable.Display.CreatureTextMixin)
    elseif details.kind == "guild" then
      Mixin(frame, addonTable.Display.GuildTextMixin)
    elseif details.kind == "castSpellName" then
      Mixin(frame, addonTable.Display.CastTextMixin)
    elseif details.kind == "level" then
      Mixin(frame, addonTable.Display.LevelTextMixin)
    elseif details.kind == "target" then
      Mixin(frame, addonTable.Display.UnitTargetTextMixin)
    elseif details.kind == "castTarget" then
      Mixin(frame, addonTable.Display.CastTargetTextMixin)
    elseif details.kind == "castInterrupter" then
      Mixin(frame, addonTable.Display.CastInterrupterTextMixin)
    elseif details.kind == "castTimeLeft" then
      Mixin(frame, addonTable.Display.CastTimeLeftTextMixin)
    elseif details.kind == "quest" then
      Mixin(frame, addonTable.Display.QuestTextMixin)
    elseif details.kind == "mythicPlusForces" then
      Mixin(frame, addonTable.Display.MythicPlusForcesTextMixin)
    elseif details.kind == "energy" then
      Mixin(frame, addonTable.Display.EnergyTextMixin)
    elseif details.kind == "threat" then
      Mixin(frame, addonTable.Display.ThreatTextMixin)
    elseif details.kind == "threatDifferential" then
      Mixin(frame, addonTable.Display.ThreatDifferentialTextMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
  end

  return frame
end

function addonTable.Display.GetHealthFillText(frame, parent)
  frame = frame or CreateFrame("Frame", nil, parent or UIParent)
  frame:SetSize(1, 1)

  frame.mask = CreateFrame("Frame", nil, frame)
  frame.mask:SetClipsChildren(true)
  frame.maskAbsorb = CreateFrame("Frame", nil, frame)
  frame.maskAbsorb:SetClipsChildren(true)

  frame.statusBar = CreateFrame("StatusBar", nil, frame)
  frame.statusBar:SetStatusBarTexture("Interface/AddOns/Platynator/Special/transparent.png")
  frame.statusBar:SetMinMaxValues(0, 1)
  frame.mask:SetAllPoints(frame.statusBar:GetStatusBarTexture())

  frame.statusBarAbsorb = CreateFrame("StatusBar", nil, frame)
  frame.statusBarAbsorb:SetStatusBarTexture("Interface/AddOns/Platynator/Special/transparent.png")
  frame.maskAbsorb:SetAllPoints(frame.statusBarAbsorb:GetStatusBarTexture())

  frame.foreground = frame.mask:CreateFontString(nil, nil, "GameFontNormal")
  frame.foreground:SetPoint("CENTER", frame)
  frame.foreground:SetText(" ")

  frame.absorb = frame.maskAbsorb:CreateFontString(nil, nil, "GameFontNormal")
  frame.absorb:SetPoint("CENTER", frame)
  frame.absorb:SetText(" ")

  local alphaZeroed = CreateFrame("Frame", nil, frame)
  alphaZeroed:SetAlpha(0)
  alphaZeroed:SetAllPoints(frame)
  frame.absorbPlacer = alphaZeroed:CreateFontString(nil, nil, "GameFontNormal")
  frame.absorbPlacer:SetPoint("LEFT", frame.statusBar:GetStatusBarTexture(), "RIGHT", -1, 0)
  frame.absorbPlacer:SetText(" ")

  frame.background = frame:CreateFontString(nil, nil, "GameFontNormal")
  frame.background:SetPoint("CENTER", frame)
  frame.background:SetText(" ")

  frame.statusBar:SetAllPoints(frame.background)
  frame.statusBarAbsorb:SetAllPoints(frame.absorbPlacer)

  frame.texts = {frame.foreground, frame.absorb, frame.background, frame.absorbPlacer}

  frame:SetAllPoints(frame.text)

  function frame:Init(details)
    if frame.Strip then
      frame:Strip()
    end

    frame.details = details

    for _, t in ipairs(frame.texts) do
      t:SetFontObject(addonTable.CurrentFont)
      if t ~= self.absorbPlacer then
        t:ClearAllPoints()
        t:SetPoint(details.anchor[1] or "CENTER", frame)
      end
      t:SetJustifyV("BOTTOM")

      local scale = details.scale * 0.85
      t:SetSmoothScaling(addonTable.CurrentFontUsesSmoothing)
      t:SetScale(scale)
    end

    frame.background:SetTextColor(details.background.color.r, details.background.color.g, details.background.color.b)
    frame.absorb:SetTextColor(details.absorb.color.r, details.absorb.color.g, details.absorb.color.b)

    frame.absorb:SetShown(details.absorb.applyColor)

    frame.maskAbsorb:SetFrameLevel(frame:GetFrameLevel() + 2)
    frame.mask:SetFrameLevel(frame:GetFrameLevel() + 3)

    if details.kind == "healthFillText" then
      Mixin(frame, addonTable.Display.HealthFillTextBarMixin)
    else
      assert(false)
    end

    frame:SetScript("OnEvent", frame.OnEvent)

    if frame.PostInit then
      frame:PostInit()
    end
  end

  function frame:ApplyAnchor()
    ApplyAnchor(frame, frame.details.anchor)
  end

  function frame:ApplySize()
  end

  return frame
end

local livePools = {
  healthBars = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetHealthBar),
  healthFillTextSpecialBars = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetHealthFillText),
  castBars = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetCastBar),
  energyBars = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetEnergyBar),
  texts = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetText),
  powerSpecialBars = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetPower),
  highlights = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetHighlight),
  animatedBorderHighlights = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetAnimatedBorderHighlight),
  flashingHighlights = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetFlashingHighlight),
  fixedBorderedHighlights = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetBorderedHighlight),
  aurasHighlights = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetAuraHighlight),
  markers = CreateFramePool("Frame", UIParent, nil, nil, false, addonTable.Display.GetMarker),
}

local editorPools = {
  healthBars = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetHealthBar),
  healthFillTextSpecialBars = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetHealthFillText),
  castBars = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetCastBar),
  energyBars = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetEnergyBar),
  texts = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetText),
  powerSpecialBars = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetPower),
  highlights = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetHighlight),
  animatedBorderHighlights = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetAnimatedBorderHighlight),
  flashingHighlights = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetFlashingHighlight),
  fixedBorderedHighlights = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetBorderedHighlight),
  markers = CreateFramePool("Frame", UIParent, "PlatynatorPropagateMouseTemplate", nil, false, addonTable.Display.GetMarker),
}

local poolType = {}
local layerStep = addonTable.Constants.LayerFrameLevelStep

function addonTable.Display.LayerWidgets(widgets)
  for _, w in ipairs(widgets) do
    w:SetFrameLevel(w.frameLevel)
    if w.ApplyFrameLevels then
      w:ApplyFrameLevels()
    end
  end
end

function addonTable.Display.GetWidgets(design, parent, isEditor)
  local widgets = {}

  local pools = isEditor and editorPools or livePools

  for index, barDetails in ipairs(design.bars) do
    local w = pools[barDetails.kind .. "Bars"]:Acquire()
    poolType[w] = barDetails.kind .. "Bars"
    w:SetParent(parent)
    w:Show()
    w:SetFrameStrata("MEDIUM")
    w.frameLevel = layerStep * barDetails.layer + index * 10
    w:Init(barDetails)
    w.kind = "bars"
    w.kindIndex = index
    table.insert(widgets, w)
  end

  for index, textDetails in ipairs(design.texts) do
    local w = pools.texts:Acquire()
    poolType[w] = "texts"
    w:SetParent(parent)
    w:Show()
    w:SetFrameStrata("MEDIUM")
    w.frameLevel = layerStep * textDetails.layer + index * 10
    w:Init(textDetails)
    w.kind = "texts"
    w.kindIndex = index
    table.insert(widgets, w)
  end

  for index, highlightDetails in ipairs(design.highlights) do
    local w
    if pools[highlightDetails.kind .. "Highlights"] then
      w = pools[highlightDetails.kind .. "Highlights"]:Acquire()
      poolType[w] = highlightDetails.kind .. "Highlights"
    else
      w = pools.highlights:Acquire()
      poolType[w] = "highlights"
    end
    w:SetParent(parent)
    w:Show()
    w:SetFrameStrata("MEDIUM")
    w.frameLevel = layerStep * highlightDetails.layer + index * 10
    w:Init(highlightDetails)
    w.kind = "highlights"
    w.kindIndex = index
    table.insert(widgets, w)
  end

  for index, specialDetails in ipairs(design.specialBars) do
    local w = pools[specialDetails.kind .. "SpecialBars"]:Acquire()
    poolType[w] = specialDetails.kind .. "SpecialBars"
    w:SetParent(parent)
    w:Show()
    w:SetFrameStrata("MEDIUM")
    w.frameLevel = layerStep * specialDetails.layer + index * 10
    w:Init(specialDetails)
    w.kind = "specialBars"
    w.kindIndex = index
    table.insert(widgets, w)
  end

  for index, markerDetails in ipairs(design.markers) do
    local w = pools.markers:Acquire()
    poolType[w] = "markers"
    w:SetParent(parent)
    w:Show()
    w:SetFrameStrata("MEDIUM")
    w.frameLevel = layerStep * markerDetails.layer + index * 10
    w:Init(markerDetails)
    w.kind = "markers"
    w.kindIndex = index
    table.insert(widgets, w)
  end

  for _, w in ipairs(widgets) do
    if addonTable.Constants.IsPixelPerfectPlus and (not addonTable.Utilities.IsChangesRestricted() or not w.auras) then
      PixelUtil.SetRoundLayoutToNearestPixelRecursively(w, true)
    else
      w.pixelPerfectRequired = nil
      w:SetScript("OnShow", function()
        if w.pixelPerfectRequired and w.unit then
          w.pixelPerfectRequired = nil
          w:ApplyAnchor()
          w:ApplySize()
        end
      end)
    end
    w:ApplyAnchor()
    w:ApplySize()
  end

  return widgets
end

function addonTable.Display.ReleaseWidgets(widgets, isEditor)
  local pools = isEditor and editorPools or livePools

  for _, w in ipairs(widgets) do
    w:Strip()
    pools[poolType[w]]:Release(w)
    poolType[w] = nil
  end
end
