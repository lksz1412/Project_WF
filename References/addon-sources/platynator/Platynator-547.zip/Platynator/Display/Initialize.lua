---@class addonTablePlatynator
local addonTable = select(2, ...)

function addonTable.Display.Initialize()
  local cache = CreateFrame("Frame")
  Mixin(cache, addonTable.Display.CacheMixin)
  cache:OnLoad()
  addonTable.Cache = cache

  local context = CreateFrame("Frame")
  Mixin(context, addonTable.Display.DesignForContextMixin)
  context:OnLoad()
  addonTable.Display.Context = context

  local manager = CreateFrame("Frame")
  Mixin(manager, addonTable.Display.ManagerMixin)
  manager:OnLoad()
end

---@class PlatynatorDisplayManager: Frame
addonTable.Display.ManagerMixin = {}
function addonTable.Display.ManagerMixin:OnLoad()
  self.styleIndex = 0
  self.clickRegionPool = CreateFramePool("Frame")

  self.preallocatedDisplaysByIndex = {}
  self.preallocatedDisplays = {}

  self.nameplateDisplays = {}
  self.nameplateClickRegions = {}
  self.nameplateStackRegions = {}

  for i = 1, 40 do
    local clickRegion = CreateFrame("Frame")
    self.nameplateClickRegions["NamePlate" .. i] = clickRegion
    if addonTable.Constants.IsMists then
      clickRegion:SetScale(UIParent:GetScale())
    end
    clickRegion.visual = clickRegion:CreateTexture()
    clickRegion.visual:SetColorTexture(addonTable.Constants.ClickRegionColor.r, addonTable.Constants.ClickRegionColor.g, addonTable.Constants.ClickRegionColor.b, addonTable.Constants.ClickRegionColor.a)
    clickRegion.visual:SetAllPoints()

    if C_XMLUtil.GetTemplateInfo("PingableUnitFrameTemplate") then
      local pingRegion = CreateFrame("Frame", nil, clickRegion, "PingableUnitFrameTemplate")
      pingRegion:SetAllPoints()

      clickRegion.ping = pingRegion
    end

    local stackRegion = CreateFrame("Frame")
    local tex = stackRegion:CreateTexture()
    tex:SetColorTexture(1, 0, 0, 0)
    tex:SetAllPoints(stackRegion)
    stackRegion.visual = stackRegion:CreateTexture()
    stackRegion.visual:SetColorTexture(addonTable.Constants.StackRegionColor.r, addonTable.Constants.StackRegionColor.g, addonTable.Constants.StackRegionColor.b, addonTable.Constants.StackRegionColor.a)
    stackRegion.visual:SetPoint("CENTER", stackRegion)
    if addonTable.Constants.IsMists then
      stackRegion:SetScale(UIParent:GetScale())
    end
    self.nameplateStackRegions["NamePlate" .. i] = stackRegion
  end

  self:SetScript("OnEvent", self.OnEvent)

  self:RegisterEvent("NAME_PLATE_UNIT_ADDED")
  self:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
  self:RegisterEvent("NAME_PLATE_CREATED")
  self:RegisterEvent("PLAYER_LOGIN")
  self:RegisterEvent("PLAYER_ENTERING_WORLD")
  if C_EventUtils.IsEventValid("GARRISON_UPDATE") then
    self:RegisterEvent("GARRISON_UPDATE")
  end
  self:RegisterEvent("UI_SCALE_CHANGED")

  self:RegisterEvent("PLAYER_SOFT_INTERACT_CHANGED")

  self:RegisterEvent("PLAYER_REGEN_DISABLED")
  self:RegisterEvent("PLAYER_REGEN_ENABLED")
  if C_Secrets and C_Secrets.HasSecretRestrictions() then
    self:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
  end
  self:RegisterEvent("PLAYER_TARGET_CHANGED")

  addonTable.CallbackRegistry:RegisterCallback("UnitDesignChange", function(_, unit)
    local display = self.nameplateDisplays[unit]
    if display then
      self:Uninstall(unit)
      self:Install(unit)
    end
  end)

  NamePlateDriverFrame:UnregisterEvent("DISPLAY_SIZE_CHANGED")
  if not addonTable.Constants.IsRetail then
    NamePlateDriverFrame:UnregisterEvent("CVAR_UPDATE")
  end

  self:RegisterEvent("VARIABLES_LOADED")

  addonTable.CallbackRegistry:RegisterCallback("RefreshStateChange", function(_, state)
    if state[addonTable.Constants.RefreshReason.Design] then
      self:SetScript("OnUpdate", function()
        self:SetScript("OnUpdate", nil)
        self:UpdateFriendlyFont()
        self:UpdateNamePlateSize()
        self:RestylePoolsStaggered()
        self:UpdateActivePlates()
        self:UpdateSoftInteract()
        self:UpdateStacking()
        self:UpdateAllClickRegions()
        self:UpdateTargetScale()
      end)
    end
    if state[addonTable.Constants.RefreshReason.SimplifiedScale] then
      self:UpdateSimplifiedScale()
    end
    if state[addonTable.Constants.RefreshReason.Scale] or state[addonTable.Constants.RefreshReason.TargetBehaviour] then
      self:UpdateFriendlyFont()
      self:UpdateNamePlateSize()
      self:RestylePoolsStaggered()

      self:UpdateActivePlates()
      self:UpdateAllClickRegions()
      self:UpdateTargetScale()
    end
    if state[addonTable.Constants.RefreshReason.StackingBehaviour] then
      self:UpdateNamePlateSize()
      self:UpdateStacking()
      self:RestylePoolsStaggered()
      self:UpdateActivePlates()
    end
    if state[addonTable.Constants.RefreshReason.Movement] then
      self:UpdateMovement()
    end
    if state[addonTable.Constants.RefreshReason.ShowBehaviour] then
      self:UpdateFriendlyFont()
      self:UpdateNamePlateSize()
      self:RepositionDisplays()
      self:UpdateShowState()
    end
    if state[addonTable.Constants.RefreshReason.Simplified] then
      self:RestylePoolsStaggered()
      self:UpdateActivePlates()
      self:RepositionDisplays()
    end
    if state[addonTable.Constants.RefreshReason.Clickable] then
      self:UpdateNamePlateSize()
      self:UpdateClickable()
    end
    if state[addonTable.Constants.RefreshReason.DesignSelection] then
      self:UpdateFont()
      self:RestylePoolsStaggered()
      self:UpdateActivePlates()
      self:UpdateFriendlyFont()
      self:UpdateNamePlateSize()
      self:UpdateAllClickRegions()
      self:RepositionDisplays()
    end
  end)

  addonTable.CallbackRegistry:RegisterCallback("SettingChanged", function(_, settingName)
    if settingName == addonTable.Config.Options.CLICK_REGION_SCALE_X
      or settingName == addonTable.Config.Options.CLICK_REGION_SCALE_Y
      or settingName == addonTable.Config.Options.VERTICAL_OFFSET
    then
      self:UpdateNamePlateSize()
      self:UpdateStackRegionsOnly()
      self:RepositionDisplays()
      self:UpdateAllClickRegions()
      self:UpdateStacking()
    elseif settingName == addonTable.Config.Options.APPLY_CVARS then
      addonTable.Display.SetCVars()
    elseif settingName == addonTable.Config.Options.OBSCURED_ALPHA then
      self:UpdateObscuredAlpha()
    elseif settingName == addonTable.Config.Options.BLIZZARD_WIDGET_SCALE then
      self:UpdateWidgetScale()
    elseif settingName == addonTable.Config.Options.NAMEPLATE_POSITION then
      self:UpdateNamePlateSize()
      self:RepositionDisplays()
      self:UpdateNamePlatePosition()
    end
  end)

  self.showingRegion = {
    click = false,
    stack = false,
  }
  addonTable.CallbackRegistry:RegisterCallback("ShowRegion", function(_, kind, shouldShow)
    self.showingRegion[kind] = shouldShow
    if kind == "stack" then
      for unit in pairs(self.nameplateDisplays) do
        self:UpdateStackingRegion(unit)
      end
    elseif kind == "click" then
      for unit in pairs(self.nameplateDisplays) do
        self:UpdateClickRegion(unit)
      end
    end
  end)

  hooksecurefunc(NamePlateDriverFrame, "OnNamePlateAdded", function(_, unit)
    if unit == "preview" then
      return
    end
    local nameplate = C_NamePlate.GetNamePlateForUnit(unit, false)
    if nameplate then
      nameplate.UnitFrame:SetParent(addonTable.hiddenFrame)
      nameplate.UnitFrame:UnregisterAllEvents()

      if nameplate.UnitFrame.castBar then
        nameplate.UnitFrame.castBar:UnregisterAllEvents()
      elseif nameplate.UnitFrame.CastBarsContainer then
        nameplate.UnitFrame.CastBarsContainer.castBar:UnregisterAllEvents()
      end

      if nameplate.UnitFrame.WidgetContainer then
        nameplate.UnitFrame.WidgetContainer:SetParent(nameplate)
        nameplate.UnitFrame.WidgetContainer:SetScale(addonTable.Config.Get(addonTable.Config.Options.BLIZZARD_WIDGET_SCALE))
      end
      if nameplate:CanChangeHitTestPoints() then
        local clickRegion = self.nameplateClickRegions[nameplate:GetName()]
        nameplate:SetAllHitTestPoints(clickRegion)
      end
      local stackRegion = self.nameplateStackRegions[nameplate:GetName()]
      nameplate:SetStackingBoundsFrame(stackRegion)
    end
  end)
end

function addonTable.Display.ManagerMixin:UpdateFont()
  local defaultEnemyDesign = addonTable.Core.GetDesignByName(addonTable.Display.Context:GetDefaultEnemyNPCDesign())
  addonTable.CurrentFont, addonTable.CurrentFontUsesSmoothing = addonTable.Core.GetFontByDesign(defaultEnemyDesign)
end

function addonTable.Display.ManagerMixin:UpdateSoftInteract()
  if self.lastInteract and self.lastInteract.interactUnit then
    self.lastInteract:UpdateSoftInteract()
  end
end

function addonTable.Display.ManagerMixin:UpdateWidgetScale()
  for unit in pairs(self.nameplateDisplays) do
    local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
    if nameplate.UnitFrame then
      local WidgetContainer = nameplate.UnitFrame.WidgetContainer
      if WidgetContainer then
        WidgetContainer:SetScale(addonTable.Config.Get(addonTable.Config.Options.BLIZZARD_WIDGET_SCALE))
      end
    end
  end
end

function addonTable.Display.ManagerMixin:UpdateActivePlates()
  local allUnits = GetKeysArray(self.nameplateDisplays)
  for _, unit in pairs(allUnits) do
    self:Uninstall(unit)
    self:Install(unit)
  end
end

function addonTable.Display.ManagerMixin:UpdateStackRegionsOnly()
  for unit in pairs(self.nameplateDisplays) do
    self:UpdateStackingRegion(unit)
  end
end

local function StyleSettingsKey(settings)
  return settings.style .. "$$" .. settings.scale .. "$$" .. addonTable.Core.GetDesignScale(settings.simplified or false)
end

function addonTable.Display.ManagerMixin:GeneratePoolForIndex(index)
  self.preallocatedDisplaysByIndex[index] = table.create(40)
  for i = 1, 40 do
    local frame = CreateFrame("Frame", nil, _G["NamePlate" .. i] or UIParent)
    Mixin(frame, addonTable.Display.NameplateMixin)
    frame.kind = index
    frame:OnLoad()
    frame:SetPoint("CENTER")
    table.insert(self.preallocatedDisplays, frame)
    table.insert(self.preallocatedDisplaysByIndex[index], frame)
  end
end

function addonTable.Display.ManagerMixin:GeneratePools()
  if addonTable.Constants.IsForever or addonTable.Constants.IsRetail then
    self:RestylePools()
  else
    self:RestylePoolsStaggered(1)
  end
end

function addonTable.Display.ManagerMixin:AllocateEnoughPools()
  local assignments = addonTable.Config.Get(addonTable.Config.Options.DESIGN_ASSIGNMENTS)

  self.seenStyleIndexes = {}
  self.indexToStyle = {}
  local index = 0
  for _, settings in ipairs(assignments) do
    local key = StyleSettingsKey(settings)
    if not self.seenStyleIndexes[key] then
      index = index + 1
      self.seenStyleIndexes[key] = index
      self.indexToStyle[index] = settings
      if not self.preallocatedDisplaysByIndex[index] then
        self:GeneratePoolForIndex(index)
      end
    end
  end
end

function addonTable.Display.ManagerMixin:RestylePools()
  self:AllocateEnoughPools()

  for index, list in ipairs(self.preallocatedDisplaysByIndex) do
    local settings = self.indexToStyle[index]
    if settings then
      local design, scaleMod, scaleOffset = addonTable.Core.GetDesignByName(settings.style), settings.scale, addonTable.Core.GetDesignScale(settings.simplified or false)
      for _, display in ipairs(list) do
        if display.styleIndex ~= self.styleIndex then
          local parent = display:GetParent()
          display:SetParent(UIParent)
          display:Show()
          display:SetPoint("CENTER")
          display:InitializeWidgets(design, scaleOffset, scaleMod)
          display.styleIndex = self.styleIndex
          display:Hide()
          display:SetParent(parent)
        end
      end
    end
  end
end

function addonTable.Display.ManagerMixin:RestylePoolsStaggered(step)
  step = step or 1
  if self.styleTicker then
    self.styleTicker:Cancel()
    self.styleTicker = nil
  end
  self.styleIndex = self.styleIndex + 1

  self:AllocateEnoughPools()

  if addonTable.Utilities.IsChangesRestricted() then -- Can do the rest lazily as we know it doesn't affect auras
    return
  end

  local index = 1
  self.styleTicker = C_Timer.NewTicker(0, function()
    for i = index, index + step - 1 do
      local display = self.preallocatedDisplays[i]
      local settings = self.indexToStyle[display.kind]
      if settings then
        local design, scaleMod, scaleOffset = addonTable.Core.GetDesignByName(settings.style), settings.scale, addonTable.Core.GetDesignScale(settings.simplified or false)
        if display.styleIndex ~= self.styleIndex then
          local parent = display:GetParent()
          display:SetParent(UIParent)
          display:Show()
          display:SetPoint("CENTER")
          display:InitializeWidgets(design, scaleOffset, scaleMod)
          display.styleIndex = self.styleIndex
          display:Hide()
          display:SetParent(parent)
        end
      end
    end
    index = index + step
    if index > #self.preallocatedDisplays then
      self.styleTicker = nil
    end
  end, #self.preallocatedDisplays / step)
end

function addonTable.Display.ManagerMixin:CombatChangesCheck()
  if InCombatLockdown() then
    self.combatChangesPending = true
    return true
  end
  return false
end

function addonTable.Display.ManagerMixin:UpdateStacking()
  if self:CombatChangesCheck() then
    return
  end
  local state = addonTable.Config.Get(addonTable.Config.Options.STACKING_NAMEPLATES)
  C_CVar.SetCVarBitfield("nameplateStackingTypes", Enum.NamePlateStackType.Enemy, state.enemy)
  C_CVar.SetCVarBitfield("nameplateStackingTypes", Enum.NamePlateStackType.Friendly, state.friend)
end

function addonTable.Display.ManagerMixin:UpdateMovement()
  if self:CombatChangesCheck() then
    return
  end
  if addonTable.Constants.IsCVarsBack then
    local insets = addonTable.Config.Get(addonTable.Config.Options.STACK_POSITION_INSETS)
    C_CVar.SetCVar("nameplateTopInset", insets.top)
    C_CVar.SetCVar("nameplateBottomInset", insets.bottom)
    local speed = addonTable.Config.Get(addonTable.Config.Options.STACK_MOTION_SPEED)
    C_CVar.SetCVar("nameplateMotionSpeed", speed * 0.1) -- Scaled down due to larger values giving wonky results
  end
end

function addonTable.Display.ManagerMixin:UpdateTargetScale()
  if self:CombatChangesCheck() then
    return
  end

  C_CVar.SetCVar("nameplateSelectedScale", addonTable.Config.Get(addonTable.Config.Options.TARGET_SCALE))
end

local function GetCVarsForNameplates()
  return {
    friendlyPlayer = "nameplateShowFriendlyPlayers",
    friendlyNPC = "nameplateShowFriendlyNpcs",
    friendlyMinion = "nameplateShowFriendlyPlayerMinions",
    enemy = "nameplateShowEnemies",
    enemyMinion = "nameplateShowEnemyMinions",
    enemyMinor = "nameplateShowEnemyMinus",
  }, {
    friendlyMinionPet = "nameplateShowFriendlyPlayerPets",
    friendlyMinionTotem = "nameplateShowFriendlyPlayerTotems",
    friendlyMinionGuardian = "nameplateShowFriendlyPlayerGuardians",
  }, {
    enemyMinionPet = "nameplateShowEnemyPets",
    enemyMinionTotem = "nameplateShowEnemyTotems",
    enemyMinionGuardian = "nameplateShowEnemyGuardians",
  }
end

function addonTable.Display.ManagerMixin:UpdateShowState()
  if self:CombatChangesCheck() then
    return
  end

  C_CVar.SetCVar("nameplateShowAll", addonTable.Config.Get(addonTable.Config.Options.SHOW_NAMEPLATES_ONLY_NEEDED) and "0" or "1")

  local currentShow = addonTable.Config.Get(addonTable.Config.Options.SHOW_NAMEPLATES)

  local baseValues, friendlyMinions, enemyMinions = GetCVarsForNameplates()
  C_CVar.SetCVar("nameplateShowOnlyNameForFriendlyPlayerUnits", "0")
  C_CVar.SetCVar("nameplateUseClassColorForFriendlyPlayerUnitNames", "0")

  for key, cvar in pairs(baseValues) do
    local newValue = currentShow[key] and "1" or "0"
    C_CVar.SetCVar(cvar, newValue)
  end

  if currentShow.friendlyMinion then
    for key, cvar in pairs(friendlyMinions) do
      local newValue = currentShow[key] and "1" or "0"
      C_CVar.SetCVar(cvar, newValue)
    end
  end
  if currentShow.enemyMinion then
    for key, cvar in pairs(enemyMinions) do
      local newValue = currentShow[key] and "1" or "0"
      C_CVar.SetCVar(cvar, newValue)
    end
  end

  self.toggledFriendly = false

  self:UpdateInstanceShowState()
end

function addonTable.Display.ManagerMixin:UpdateInstanceShowState()
  local state = addonTable.Config.Get(addonTable.Config.Options.SHOW_FRIENDLY_IN_INSTANCES)

  if self:CombatChangesCheck() then
    return
  end

  local relevantInstance = addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, delve = true})
  local isDelve = addonTable.Display.Utilities.IsInRelevantInstance({delve = true})

  if state == "name_only" then
    C_CVar.SetCVar("nameplateShowOnlyNameForFriendlyPlayerUnits", relevantInstance and "1" or "0")
    C_CVar.SetCVar("nameplateUseClassColorForFriendlyPlayerUnitNames", relevantInstance and self.friendlyNameOnlyClassColors and "1" or "0")
  end

  local values = GetCVarsForNameplates()
  local currentShow = addonTable.Config.Get(addonTable.Config.Options.SHOW_NAMEPLATES)

  if relevantInstance then
    if not self.toggledFriendly and
      (state == "name_only" and not currentShow.friendlyPlayer
      or state == "never" and (currentShow.friendlyPlayer or currentShow.friendlyNPC)
      or state == "name_only" and currentShow.friendlyNPC)
      or state == "always" and (not currentShow.friendlyPlayer or not currentShow.friendlyNPC) then
      C_CVar.SetCVar(values.friendlyPlayer, state == "never" and "0" or "1")
      if currentShow.friendlyNPC then
        C_CVar.SetCVar(values.friendlyNPC, state ~= "always" and (not isDelve or state == "never") and "0" or "1")
      end
      self.toggledFriendly = true
    end
  elseif self.toggledFriendly then
    if currentShow.friendlyPlayer then
      C_CVar.SetCVar(values.friendlyPlayer, "1")
    elseif state ~= "never" then
      C_CVar.SetCVar(values.friendlyPlayer, "0")
    end
    if currentShow.friendlyNPC then
      C_CVar.SetCVar(values.friendlyNPC, "1")
    elseif state == "always" then
      C_CVar.SetCVar(values.friendlyNPC, "0")
    end
    self.toggledFriendly = false
  end
end

function addonTable.Display.ManagerMixin:UpdateNamePlatePosition()
  if self:CombatChangesCheck() then
    return
  end

  C_CVar.SetCVar("nameplateOtherAtBase", addonTable.Config.Get(addonTable.Config.Options.NAMEPLATE_POSITION) == "top" and 0 or 1)
end

function addonTable.Display.ManagerMixin:UpdateStackingRegion(unit)
  local stackRegion = self.nameplateDisplays[unit].stackRegion
  if not stackRegion then
    return
  end
  stackRegion.visual:SetSize(stackRegion.rect.width, stackRegion.rect.height)
  stackRegion:SetPoint(
    "BOTTOMLEFT",
    stackRegion:GetParent(),
    "CENTER",
    stackRegion.rect.left,
    stackRegion.rect.bottom + self:GetBaseOffset(unit)
  )
  stackRegion:SetSize(stackRegion.rect.width, stackRegion.rect.height)

  stackRegion.visual:SetShown(self.showingRegion.stack)
end

function addonTable.Display.ManagerMixin:UpdateClickRegion(unit)
  local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
  if nameplate and nameplate:CanChangeHitTestPoints() then
    local clickRegion = self.nameplateClickRegions[nameplate:GetName()]
    if not clickRegion.parented then
      clickRegion.parented = true
      clickRegion:SetParent(nameplate)
    end
    clickRegion:Show()
    clickRegion:ClearAllPoints()
    if clickRegion.ping then
      clickRegion.ping:SetAttribute("unit", unit)
    end
    local globalScale = addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
    local region, clickScale, scale = addonTable.Display.Context:GetClickRegion(unit)
    local width = region.width * clickScale * scale * globalScale * addonTable.Assets.BarBordersSize.width
    local height = region.height * clickScale * scale * globalScale * addonTable.Assets.BarBordersSize.height
    clickRegion:SetSize(width, height)
    if region.anchor[2] then
      local rect = addonTable.Utilities.GetRectFromRegion(region, clickScale * scale * globalScale, region.anchor, true)
      local newLeft = rect.left
      local newBottom = rect.bottom
      clickRegion:SetPoint(
        "BOTTOMLEFT",
        nameplate,
        "CENTER",
        newLeft,
        newBottom + self:GetBaseOffset(unit)
      )
    else
      clickRegion:SetPoint("CENTER", nameplate, "CENTER", 0, self:GetBaseOffset(unit))
    end
    nameplate:SetAllHitTestPoints(clickRegion)
    clickRegion.visual:SetShown(self.showingRegion.click)
  end
end

function addonTable.Display.ManagerMixin:UpdateAllClickRegions()
  if self:CombatChangesCheck() then
    return
  end

  for unit in pairs(self.nameplateDisplays) do
    self:UpdateClickRegion(unit)
  end
end

function addonTable.Display.ManagerMixin:Install(unit)
  local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
  -- NOTE: the nameplate _name_ does not correspond to the unit
  if nameplate and unit and (addonTable.Constants.IsRetail or not UnitIsUnit("player", unit)) then
    addonTable.Cache:AddUnit(unit)
    local globalScale = addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
    local designName, scale, shouldSimplify, settings = addonTable.Display.Context:GetAssignedDesign(unit)
    if settings == nil then
      addonTable.Cache:RemoveUnit(unit)
      addonTable.Display.Context:RevokedUnitListeners(unit)
      addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.BAD_CUSTOM_STYLE_SELECT)
      return
    end
    local design = addonTable.Core.GetDesignByName(designName)
    local nameplateIndex = tonumber(nameplate:GetName():match("%d+"))
    local newDisplay = self.preallocatedDisplaysByIndex[self.seenStyleIndexes[StyleSettingsKey(settings)]][nameplateIndex]
    C_NamePlateManager.SetNamePlateSimplified(unit, shouldSimplify)
    self.nameplateDisplays[unit] = newDisplay
    if nameplate.SetStackingBoundsFrame then
      if not self.nameplateStackRegions[nameplate:GetName()].parented then
        self.nameplateStackRegions[nameplate:GetName()].parented = true
        self.nameplateStackRegions[nameplate:GetName()]:SetParent(nameplate)
      end
      newDisplay.stackRegion = self.nameplateStackRegions[nameplate:GetName()]
      newDisplay.stackRegion.rect = addonTable.Utilities.GetRectFromRegion(design.regions.stack, scale * design.scale * globalScale, design.regions.stack.anchor, true)
      nameplate:SetStackingBoundsFrame(newDisplay.stackRegion)
      self:UpdateStackingRegion(unit)
    end

    self:UpdateClickRegion(unit)

    if newDisplay.styleIndex ~= self.styleIndex then
      local scaleOffset, scaleMod = addonTable.Core.GetDesignScale(shouldSimplify), scale
      newDisplay:SetParent(UIParent)
      newDisplay:Show()
      newDisplay:SetPoint("CENTER")
      newDisplay:InitializeWidgets(design, scaleOffset, scaleMod)
      newDisplay.styleIndex = self.styleIndex
      newDisplay:SetParent(nameplate)
    end
    newDisplay:Install(nameplate, self:GetBaseOffset(unit) / scale / design.scale / globalScale)
    newDisplay:SetUnit(unit)
  end
end

function addonTable.Display.ManagerMixin:Uninstall(unit, removed)
  local display = self.nameplateDisplays[unit]
  if display then
    addonTable.Cache:RemoveUnit(unit, removed)
    addonTable.Display.Context:RevokedUnitListeners(unit)
    display:SetUnit(nil)
    display:ClearAllPoints()
    display:Hide()
    self.nameplateDisplays[unit] = nil
  end
end

function addonTable.Display.ManagerMixin:UpdateNamePlateSize()
  if self:CombatChangesCheck() then
    return
  end

  local assignments = addonTable.Config.Get(addonTable.Config.Options.DESIGN_ASSIGNMENTS)
  local left, bottom, top, right

  for _, details in ipairs(assignments) do
    local design = addonTable.Core.GetDesignByName(details.style)
    local click = design.regions.click
    local rect = addonTable.Utilities.GetRectFromRegion(click, details.scale * design.scale, click.anchor, true)
    local newLeft = rect.left
    local newBottom = rect.bottom
    local newRight = newLeft + rect.width
    local newTop = newBottom + rect.height
    if left == nil then
      left = newLeft
      bottom = newBottom
      right = newRight
      top = newTop
    end

    left = math.min(newLeft, left)
    bottom = math.min(newBottom, bottom)
    right = math.max(newRight, right)
    top = math.max(newTop, top)
  end

  local globalScale = addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
  local verticalOffset = addonTable.Config.Get(addonTable.Config.Options.VERTICAL_OFFSET) * addonTable.Assets.BarBordersSize.height

  local width = math.max(math.abs(right), math.abs(left)) * 2 * globalScale
  local height = (top - bottom) * globalScale
  self.baseOffsetFriendly = - height / 2 - bottom * globalScale + verticalOffset * globalScale / 2
  self.baseOffsetEnemy = self.baseOffsetFriendly
  if addonTable.Config.Get(addonTable.Config.Options.NAMEPLATE_POSITION) == "bottom" then
    self.baseOffsetEnemy = height / 2 - top * globalScale + verticalOffset * globalScale / 2
  end

  height = height + verticalOffset * globalScale
  width = math.max(math.min(250, 200 * NamePlateConstants.NAME_PLATE_SCALES[tonumber(C_CVar.GetCVar("nameplateSize"))].horizontal), width)

  if self.baseBlizzHeight and self.baseBlizzHeight > height then
    local diff = -(self.baseBlizzHeight - height) / 2
    self.baseOffsetFriendly = self.baseOffsetFriendly + diff
    if addonTable.Config.Get(addonTable.Config.Options.NAMEPLATE_POSITION) == "bottom" then
      diff = -diff
    end
    self.baseOffsetEnemy = self.baseOffsetEnemy + diff
    height = self.baseBlizzHeight
  end
  if addonTable.Constants.IsMists then
    local uiParentScale = UIParent:GetScale()
    C_NamePlate.SetNamePlateSize(width * uiParentScale, height * uiParentScale)
  else
    C_NamePlate.SetNamePlateSize(width, height)
  end
end

function addonTable.Display.ManagerMixin:GetBaseOffset(unit)
  local offset = self.baseOffsetFriendly
  if not UnitIsFriend("player", unit) and UnitReaction(unit, "player") ~= 4 --[[different neutral check due to np behaviour]] then
    offset = self.baseOffsetEnemy
  end
  return offset
end

function addonTable.Display.ManagerMixin:RepositionDisplays()
  local globalScale = addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
  for unit, display in pairs(self.nameplateDisplays) do
    local styleName, scale = addonTable.Display.Context:GetAssignedDesign(unit)
    local design = addonTable.Core.GetDesignByName(styleName)
    display:Install(C_NamePlate.GetNamePlateForUnit(unit), self:GetBaseOffset(unit) / scale / design.scale / globalScale)
  end
end

function addonTable.Display.ManagerMixin:UpdateClickable()
  if self:CombatChangesCheck() then
    return
  end

  local state = addonTable.Config.Get(addonTable.Config.Options.CLICKABLE_NAMEPLATES)
  if C_NamePlateManager and C_NamePlateManager.SetNamePlateHitTestInsets then
    local value = 10000

    if state.enemy then
      C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Enemy, 0, 0, 0, 0)
    else
      C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Enemy, value, value, value, value)
    end

    if state.friend then
      C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Friendly, 0, 0, 0, 0)
    else
      C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Friendly, value, value, value, value)
    end
  else
    C_NamePlate.SetNamePlateFriendlyClickThrough(not state.friend)
    C_NamePlate.SetNamePlateEnemyClickThrough(not state.enemy)
  end
end

function addonTable.Display.ManagerMixin:UpdateSimplifiedScale()
  if self:CombatChangesCheck() then
    return
  end

  if not C_CVar.GetCVarInfo("nameplateSimplifiedScale") then
    return
  end

  for unit, display in pairs(self.nameplateDisplays) do
    local _, _, shouldSimplify = addonTable.Display.Context:GetAssignedDesign(unit)
    display.offsetScale = addonTable.Core.GetDesignScale(shouldSimplify) * UIParent:GetEffectiveScale() * addonTable.Config.Get(addonTable.Config.Options.GLOBAL_SCALE)
  end

  C_CVar.SetCVar("nameplateSimplifiedScale", addonTable.Config.Get(addonTable.Config.Options.SIMPLIFIED_SCALE))
end

function addonTable.Display.ManagerMixin:UpdateObscuredAlpha()
  if InCombatLockdown() then
    return
  end
  C_CVar.SetCVar("nameplateOccludedAlphaMult", UnitAffectingCombat("player") and addonTable.Config.Get(addonTable.Config.Options.OBSCURED_COMBAT_ALPHA) or addonTable.Config.Get(addonTable.Config.Options.OBSCURED_ALPHA))
end

local systemFontSizes = {}
if SystemFont_NamePlate_Outlined then
  local members = {
    {
      alphabet = "roman",
      file ="Fonts/FRIZQT__.TTF",
      height = 9,
      flags = "SLUG",
    },
    {
      alphabet = "korean",
      file ="Fonts/2002.TTF",
      height = 9,
      flags = "SLUG",
    },
    {
      alphabet = "simplifiedchinese",
      file ="Fonts/ARKai_T.ttf",
      height = 9,
      flags = "SLUG",
    },
    {
      alphabet = "traditionalchinese",
      file ="Fonts/blei00d.TTF",
      height = 9,
      flags = "SLUG",
    },
    {
      alphabet = "russian",
      file ="Fonts/FRIZQT___CYR.TTF",
      height = 9,
      flags = "SLUG",
    },
  }
  CreateFontFamily("PlatynatorOriginalSystemFont", members)
  for _, m in ipairs(members) do
    m.flags = m.flags .. " OUTLINE"
  end
  CreateFontFamily("PlatynatorOriginalSystemFontOutlined", members)

  for i = 1, 5 do
    local details = NamePlateConstants.NAME_PLATE_SCALES[i]
    local size = details.vertical * NamePlateConstants.HEALTH_BAR_FONT_HEIGHT
    table.insert(systemFontSizes, size)
  end
end

local function ChangeFont(base, new, overrideHeight)
  for _, a in ipairs(addonTable.Constants.FontFamilies) do
    local baseObj = base:GetFontObjectForAlphabet(a)
    local newObj = new:GetFontObjectForAlphabet(a)
    local font, _, flags = newObj:GetFont()
    baseObj:SetFont(font, 9, flags)
  end
  base:SetShadowColor(new:GetShadowColor())
  base:SetShadowOffset(new:GetShadowOffset())
end

function addonTable.Display.ManagerMixin:UpdateFriendlyFont()
  if not addonTable.CurrentFont or not C_CVar.GetCVarInfo("nameplateShowOnlyNameForFriendlyPlayerUnits") then
    return
  end

  if self:CombatChangesCheck() then
    return
  end

  local state = addonTable.Config.Get(addonTable.Config.Options.SHOW_FRIENDLY_IN_INSTANCES)
  if state == "name_only" then
    local designName = addonTable.Display.Context:GetDefaultFriendlyPlayerDesign()
    local design = addonTable.Core.GetDesignByName(designName)
    self.friendlyNameOnlyClassColors = false
    do
      for _, t in ipairs(design.texts) do
        if t.kind == "creatureName" then
          for _, c in ipairs(t.autoColors) do
            if c.kind == "classColors" then
              self.friendlyNameOnlyClassColors = true
            end
          end
          break
        end
      end
    end
    if not self.friendlyNameOnlyClassColors then
      for _, t in ipairs(design.specialBars) do
        if t.kind == "healthFillText" then
          for _, c in ipairs(t.autoColors) do
            if c.kind == "classColors" then
              self.friendlyNameOnlyClassColors = true
            end
          end
          break
        end
      end
    end
    local newFriendlyColor = addonTable.Display.Utilities.IsInRelevantInstance({dungeon = true, raid = true, delve = true}) and self.friendlyNameOnlyClassColors and "1" or "0"
    local newNameplateSize = addonTable.Config.Get(addonTable.Config.Options.INSTANCES_NAME_ONLY_SIZE)
    C_CVar.SetCVar("nameplateUseClassColorForFriendlyPlayerUnitNames", newFriendlyColor)
    C_CVar.SetCVar("nameplateSize", newNameplateSize)
    ChangeFont(SystemFont_NamePlate_Outlined, _G[addonTable.CurrentFont])
    ChangeFont(SystemFont_NamePlate, _G[addonTable.CurrentFont])
  else
    ChangeFont(SystemFont_NamePlate_Outlined, PlatynatorOriginalSystemFontOutlined)
    ChangeFont(SystemFont_NamePlate, PlatynatorOriginalSystemFont)
  end
end

function addonTable.Display.ManagerMixin:UpdateBaseNamePlateInfo()
  if addonTable.Constants.IsRetail then
    local namePlateSize = GetCVarNumberOrDefault(NamePlateConstants.SIZE_CVAR);
    -- Remove aura height
    local namePlateScale = NamePlateConstants.NAME_PLATE_SCALES[namePlateSize] or NamePlateConstants.NAME_PLATE_SCALES[Enum.NamePlateSize.Medium];
    local _
    _, self.baseBlizzHeight = C_NamePlate.GetNamePlateSize()
    local auraScale = GetCVarNumberOrDefault(NamePlateConstants.AURA_SCALE_CVAR)

    self.baseBlizzHeight = self.baseBlizzHeight - NamePlateConstants.AURA_ITEM_HEIGHT * auraScale * namePlateScale.aura - GetCVarNumberOrDefault(NamePlateConstants.DEBUFF_PADDING_CVAR)
  end
end

function addonTable.Display.ManagerMixin:OnEvent(eventName, ...)
  if eventName == "NAME_PLATE_UNIT_ADDED" then
    local unit = ...
    self:Install(unit)
  elseif eventName == "NAME_PLATE_UNIT_REMOVED" then
    local unit = ...
    self:Uninstall(unit, true)
  elseif eventName == "NAME_PLATE_CREATED" then
    local nameplate = ...
    local index = tonumber(nameplate:GetName():match("%d+"))
    for _, list in ipairs(self.preallocatedDisplaysByIndex) do
      list[index]:SetParent(nameplate)
    end
  elseif eventName == "PLAYER_TARGET_CHANGED" then
    addonTable.CallbackRegistry:TriggerEvent("TargetChanged")
  elseif eventName == "PLAYER_SOFT_INTERACT_CHANGED" then
    if self.lastInteract and self.lastInteract.interactUnit then
      self.lastInteract:UpdateSoftInteract()
    end
    local unit
    for i = 1, 40 do
      unit = "nameplate" .. i
      if UnitIsUnit(unit, "softinteract") or UnitIsUnit(unit, "softenemy") or UnitIsUnit(unit, "softfriend") then
        break
      else
        unit = nil
      end
    end
    if self.nameplateDisplays[unit] then
      self.lastInteract = self.nameplateDisplays[unit]
      self.lastInteract:UpdateSoftInteract()
    else
      self.lastInteract = nil
    end
  elseif eventName == "PLAYER_REGEN_DISABLED" then
    self:UpdateObscuredAlpha()
  elseif eventName == "ADDON_RESTRICTION_STATE_CHANGED" then
    if self.styleTicker then
      self.styleTicker:Cancel()
      self.styleTicker = nil
      -- Necessary, as we can't redo auras in combat (12.1 restrictions)
      self:RestylePools()
    end
  elseif eventName == "PLAYER_REGEN_ENABLED" then
    if self.combatChangesPending then
      self.combatChangesPending = false
      self:UpdateStacking()
      self:UpdateShowState()
      self:UpdateNamePlateSize()
      self:UpdateTargetScale()
      self:UpdateSimplifiedScale()
      self:UpdateClickable()
      self:UpdateAllClickRegions()
      self:UpdateNamePlatePosition()
      self:RepositionDisplays()
    end
    self:UpdateObscuredAlpha()
  elseif eventName == "UI_SCALE_CHANGED" then
    self:UpdateNamePlateSize()
  elseif eventName == "PLAYER_ENTERING_WORLD" then
    self:UpdateInstanceShowState()
    self:UpdateNamePlateSize()
    self:UpdateClickable()
  elseif eventName == "GARRISON_UPDATE" then
    self:UpdateInstanceShowState()
  elseif eventName == "PLAYER_LOGIN" then
    self:UpdateFont()
    self:UpdateFriendlyFont()

    self:GeneratePools()
  elseif eventName == "VARIABLES_LOADED" then
    if addonTable.Constants.IsClassic then
      -- Need to disable them to prevent inexplicable taint errors

      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_NPC_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyNpcAuraDisplay.Debuffs, false)
      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_NPC_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyNpcAuraDisplay.Buffs, false)
      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_NPC_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyNpcAuraDisplay.CrowdControl, false)

      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_PLAYER_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyPlayerAuraDisplay.Debuffs, false)
      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_PLAYER_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyPlayerAuraDisplay.Buffs, false)
      C_CVar.SetCVarBitfield(NamePlateConstants.ENEMY_PLAYER_AURA_DISPLAY_CVAR, Enum.NamePlateEnemyPlayerAuraDisplay.LossOfControl, false)
    end
    addonTable.Display.SetCVars()

    addonTable.Utilities.PurgeKey(NamePlateFriendlyFrameOptions, "updateNameUsesGetUnitName")

    self:UpdateInstanceShowState()
    self:UpdateFriendlyFont()
    self:UpdateStacking()
    self:UpdateMovement()
    self:UpdateShowState()
    self:UpdateTargetScale()
    self:UpdateBaseNamePlateInfo()
    self:UpdateNamePlateSize()
    self:UpdateSimplifiedScale()
    self:UpdateObscuredAlpha()
    self:UpdateNamePlatePosition()
  end
end
