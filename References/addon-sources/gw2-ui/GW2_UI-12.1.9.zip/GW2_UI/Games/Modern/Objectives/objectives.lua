---@class GW2
local GW = select(2, ...)

local function IsQuestFrequency(q)
    local isFreq = q.frequency and q.frequency > 0
    if q.frequency == nil then
        local questLogIndex = q:GetQuestLogIndex()
        if questLogIndex and questLogIndex > 0 then
            local questInfo = C_QuestLog.GetInfo(questLogIndex)
            if questInfo then
                isFreq = questInfo.frequency > 0
            end
        end
    end
    return isFreq
end

local function GetQuestHeaderTitle(questID)
    local headerIndex = C_QuestLog.GetHeaderIndexForQuest and C_QuestLog.GetHeaderIndexForQuest(questID)
    local info = headerIndex and C_QuestLog.GetInfo(headerIndex)
    return info and info.title
end

local function IsClassQuest(questID)
    return GW.IsOwnClassHeader(GetQuestHeaderTitle(questID))
end

local function IsTopContainerQuest(q)
    return q:IsCampaign() or (GW.Forever and IsClassQuest(q.questID))
end
GW.IsTopContainerQuest = IsTopContainerQuest

local TOP_CONTAINER_TITLE = GW.Forever and GW.myLocalizedClass or TRACKER_HEADER_CAMPAIGN_QUESTS
GW.QuestTrackerTopContainerTitle = TOP_CONTAINER_TITLE

local zoneContext
local function GetZoneContext()
    local mapID = GW.Location.GetMapID()
    if zoneContext and mapID and zoneContext.mapID == mapID then
        return zoneContext
    end

    local name
    local searchMapID = mapID
    while searchMapID and searchMapID > 0 do
        local info = C_Map.GetMapInfo(searchMapID)
        if not info then break end
        if info.mapType == Enum.UIMapType.Zone then
            name = info.name
            break
        end
        searchMapID = info.parentMapID
    end

    local context = {mapID = mapID, name = name or GetRealZoneText()}
    if mapID then
        zoneContext = context
    end
    return context
end

local function IsZoneQuest(q, zone)
    if not zone or IsTopContainerQuest(q) then
        return false
    end
    return GetQuestHeaderTitle(q.questID) == zone.name
end

local function IsDungeonQuest(q)
    local tagID = GW.GetQuestTagID(q.questID)
    return tagID == Enum.QuestTag.Dungeon or tagID == Enum.QuestTag.Heroic
end

local function GetQuestContainerKind(q, zone)
    if GW.settings.objectives.dungeonQuests and IsDungeonQuest(q) then
        return GW.Enum.ObjectivesBlockType.Dungeon
    end
    if GW.settings.objectives.zoneQuests and IsZoneQuest(q, zone) then
        return GW.Enum.ObjectivesBlockType.Zone
    end
    return IsTopContainerQuest(q) and GW.Enum.ObjectivesBlockType.Campaign or GW.Enum.ObjectivesBlockType.Quests
end

local function GetContainerQuestColorKey(container, q, questID, isFrequency)
    local isCampaignColor = container.type == GW.Enum.ObjectivesBlockType.Campaign or (container.type == GW.Enum.ObjectivesBlockType.Dungeon and IsTopContainerQuest(q))
    return GW.GetQuestColorKey(questID, isCampaignColor, isFrequency)
end

local function GetContainerHeaderTitle(container, zone)
    if container.type == GW.Enum.ObjectivesBlockType.Dungeon then
        return GW.L["Dungeon Quests"]
    end
    if container.type == GW.Enum.ObjectivesBlockType.Zone then
        return zone and zone.name and zone.name ~= "" and zone.name or GW.L["Zone Quests"]
    end
    return container.type == GW.Enum.ObjectivesBlockType.Campaign and TOP_CONTAINER_TITLE or TRACKER_HEADER_QUESTS
end

local function BrightenColor(r, g, b, factor)
    factor = factor or 0.3
    return
        math.min(1, r + (1 - r) * factor),
        math.min(1, g + (1 - g) * factor),
        math.min(1, b + (1 - b) * factor)
end

function GW.GetQuestColorKey(questID, isCampaignContainer, isFrequency)
    -- the campaign container is its own visual group and wins over the classification:
    -- IsCampaign fills it, and that does not always match a Campaign classification
    if isCampaignContainer then
        return GW.Enum.ObjectivesNotificationType.Campaign
    end

    if GW.GetQuestTagID(questID) == Enum.QuestTag.PvP then
        return GW.Enum.ObjectivesNotificationType.PvPQuest
    end

    local classification = C_QuestInfoSystem and C_QuestInfoSystem.GetQuestClassification and C_QuestInfoSystem.GetQuestClassification(questID)
    local classifications = Enum.QuestClassification

    if classification and classifications then
        if classification == classifications.Legendary then
            return GW.Enum.ObjectivesNotificationType.LegendaryQuest
        elseif classification == classifications.Important then
            return GW.Enum.ObjectivesNotificationType.ImportantQuest
        elseif classification == classifications.Campaign then
            return GW.Enum.ObjectivesNotificationType.Campaign
        elseif classification == classifications.Recurring or classification == classifications.Calling then
            return GW.Enum.ObjectivesNotificationType.DailyQuest
        end
    end

    return isFrequency and GW.Enum.ObjectivesNotificationType.DailyQuest or GW.Enum.ObjectivesNotificationType.Quest
end

local function ShouldSortSuperTrackedQuestToTop()
    return GW.settings.objectives.superTrackedOnTop
end

local QUEST_SORT_MODES = { LEVEL = true, LEVEL_DESC = true, ZONE = true }

local function GetQuestSortMode()
    local mode = GW.settings.objectives.sorting
    return QUEST_SORT_MODES[mode] and mode
end

local function SortQuestIDsBySetting(questIDs, watchOrder, mode)
    local levels, zones = {}, {}
    for _, questID in ipairs(questIDs) do
        levels[questID] = GW.QuestCache:Get(questID).level or 0
        zones[questID] = mode == "ZONE" and GetQuestHeaderTitle(questID) or ""
    end
    table.sort(questIDs, function(left, right)
        if zones[left] ~= zones[right] then
            return zones[left] < zones[right]
        end
        if levels[left] ~= levels[right] then
            if mode == "LEVEL_DESC" then
                return levels[left] > levels[right]
            end
            return levels[left] < levels[right]
        end
        return (watchOrder[left] or 0) < (watchOrder[right] or 0)
    end)
end

-- AddObjective keeps no reference to its options table (field reads only), so one
-- scratch table serves every quest objective line — a full update otherwise allocated
-- a fresh table per line, the bulk of the trackers garbage churn
local objectiveOptions = {}
local function QuestObjectiveOptions(finished, objectiveType, useCompletedLine, timerShown, duration, startTime)
    wipe(objectiveOptions)
    objectiveOptions.isQuest = true
    objectiveOptions.finished = finished
    objectiveOptions.objectiveType = objectiveType
    objectiveOptions.useCompletedLine = useCompletedLine
    objectiveOptions.timerShown = timerShown
    objectiveOptions.duration = duration
    objectiveOptions.startTime = startTime
    return objectiveOptions
end

local function HasAutoQuestPopUpOfType(questID, checkType)
    for i = 1, GetNumAutoQuestPopUps() do
        local id, popUpType = GetAutoQuestPopUp(i)
        if id == questID and popUpType == checkType then
            return true
        end
    end
    return false
end

-- Everything UpdateBlockInternal renders derives from these inputs: when they are
-- unchanged since the last pass over this quest, the block is pixel identical and the
-- whole rebuild (row re-anchoring, SetText with its text layout flushes, height math)
-- is skipped. QUEST_LOG_UPDATE fires for every log change and always runs a FULL
-- layout over every watched quest — with the fingerprint that becomes one comparison
-- per unchanged quest. Running quest timers stay skippable: the clock lives in the
-- rows own OnUpdate, only presence and total duration are part of the fingerprint
local signatureParts, signatureCount = {}, 0
local function AddSignaturePart(value)
    signatureCount = signatureCount + 1
    signatureParts[signatureCount] = tostring(value)
end

local function GetQuestRewardXP(questID)
    return not GW.Retail and GW.GetQuestRewardXP(questID) or nil
end

local function BuildQuestBlockSignature(quest, questID, questLogIndex, colorKey)
    local numObjectives = C_QuestLog.GetNumQuestObjectives(questID)
    local isComplete = quest:IsComplete()
    local isSuperTracked = questID == C_SuperTrack.GetSuperTrackedQuestID()
    local shouldShowWaypoint = isSuperTracked or (questID == QuestMapFrame_GetFocusedQuestID())
    local timeTotal, timeElapsed = C_QuestLog.GetTimeAllowed(questID)
    local requiredMoney = quest.requiredMoney or 0

    signatureCount = 0
    AddSignaturePart(questID)
    AddSignaturePart(quest.title)
    AddSignaturePart(colorKey)
    AddSignaturePart(GW.ObjectivesTrackerState.layoutGeneration)
    AddSignaturePart(GW.settings.objectives.showCompleted)
    AddSignaturePart(GW.settings.objectives.statusBars)
    AddSignaturePart(isComplete)
    AddSignaturePart(C_QuestLog.IsFailed(questID))
    AddSignaturePart(isSuperTracked)
    AddSignaturePart(shouldShowWaypoint)
    AddSignaturePart(quest.isAutoComplete)
    AddSignaturePart(quest.startEvent)
    AddSignaturePart(HasAutoQuestPopUpOfType(questID, "COMPLETE"))
    AddSignaturePart(HasAutoQuestPopUpOfType(questID, "OFFER"))
    AddSignaturePart(QuestUtil.CanCreateQuestGroup(questID))
    AddSignaturePart(requiredMoney)
    AddSignaturePart(questLogIndex and select(2, GetQuestLogSpecialItemInfo(questLogIndex)))
    if requiredMoney > 0 then
        AddSignaturePart(GetMoney())
    end
    if isComplete or shouldShowWaypoint then
        AddSignaturePart(C_QuestLog.GetNextWaypointText(questID))
    end
    if isComplete then
        AddSignaturePart(GetQuestLogCompletionText(questLogIndex))
    end
    AddSignaturePart(timeTotal and timeElapsed and timeElapsed < timeTotal and timeTotal or false)
    AddSignaturePart(GetQuestRewardXP(questID))
    AddSignaturePart(numObjectives)
    for objectiveIndex = 1, numObjectives do
        local text, objectiveType, finished = GetQuestObjectiveInfo(questID, objectiveIndex, false)
        AddSignaturePart(text)
        AddSignaturePart(objectiveType)
        AddSignaturePart(finished)
        if objectiveType == "progressbar" then
            AddSignaturePart(GetQuestProgressBarPercent(questID))
        end
    end

    return table.concat(signatureParts, "\1", 1, signatureCount)
end

local GROUP_CONTENT_TAGS = {
    [Enum.QuestTag.PvP] = true,
    [Enum.QuestTag.Raid] = true,
    [Enum.QuestTag.Heroic] = true,
    [Enum.QuestTag.Raid10] = true,
    [Enum.QuestTag.Raid25] = true,
    [Enum.QuestTag.Scenario] = true,
}

local function GetQuestLevelPrefix(quest, questID)
    if not GW.Forever or not quest.level then return "" end

    local tagInfo = C_QuestLog.GetQuestTagInfo(questID)
    if tagInfo and tagInfo.tagID == Enum.QuestTag.Dungeon then
        return "[" .. quest.level .. " |TInterface/AddOns/GW2_UI/textures/icons/quest-dungeon-icon.png:12:12:0:0|t ] "
    elseif tagInfo and (tagInfo.tagID == Enum.QuestTag.Group or tagInfo.isElite) then
        return "[" .. quest.level .. " |TInterface/AddOns/GW2_UI/textures/icons/quest-group-icon.png:12:12:0:0|t ] "
    elseif tagInfo and GROUP_CONTENT_TAGS[tagInfo.tagID] then
        return "[" .. quest.level .. "+] "
    end
    return "[" .. quest.level .. "] "
end

local function UpdateBlockInternal(self, parent, quest, questID, questLogIndex, signature)
    local numObjectives = C_QuestLog.GetNumQuestObjectives(questID)
    local isComplete = quest:IsComplete()
    local questFailed = C_QuestLog.IsFailed(questID)
    local isSuperTracked = (questID == C_SuperTrack.GetSuperTrackedQuestID())
    local shouldShowWaypoint = isSuperTracked or (questID == QuestMapFrame_GetFocusedQuestID())

    self.height = GW.GetObjectivesBlockBaseHeight()
    self.numObjectives = 0
    self.turnin:SetShown(self:IsQuestAutoTurnInOrAutoAccept(questID, "COMPLETE"))
    self.popupQuestAccept:SetShown(self:IsQuestAutoTurnInOrAutoAccept(questID, "OFFER"))
    self:UpdateFindGroupButton(questID, false)

    if quest.requiredMoney > 0 then
        parent.watchMoneyReasons = parent.watchMoneyReasons + 1
    else
        parent.watchMoneyReasons = parent.watchMoneyReasons - 1
    end

    self.questID = questID
    self.questLogIndex = questLogIndex
    self.gwSignature = signature or BuildQuestBlockSignature(quest, questID, questLogIndex, self.gwColorKey)
    self.title = quest.title
    self.isSuperTracked = isSuperTracked
    local headerText = GetQuestLevelPrefix(quest, questID) .. quest.title
    local xpReward = GetQuestRewardXP(questID)
    if xpReward then
        headerText = headerText .. " |cFF888888(" .. GW.CommaValue(xpReward) .. XP .. ")|r"
    end
    self.Header:SetText(headerText)

    if isSuperTracked then
        local r, g, b = BrightenColor(self.color.r, self.color.g, self.color.b, 0.3)
        self.Header:SetTextColor(r, g, b)
        self:GetScript("OnEnter")(self)
    else
        self.Header:SetTextColor(self.color.r, self.color.g, self.color.b)
        if not self:IsMouseOver() then
            self:GetScript("OnLeave")(self)
        end
    end

    self:UpdateSuperTrackButton(isSuperTracked, self.gwColorKey)

    -- keyed: a nil key never dedups, and the queue drains only a few entries per tick —
    -- un-deduped bursts kept the item buttons stale for seconds
    GW.CombatQueue:Queue("update_tracker_actionbutton_" .. parent:GetName() .. (self.index or 0), self.UpdateObjectiveActionButton, {self})

    if numObjectives == 0 and GetMoney() >= quest.requiredMoney and not quest.startEvent then
        isComplete = true
    end

    if not isComplete then
        self:UpdateBlockObjectives(numObjectives)
    end

    if isComplete then
        if quest.isAutoComplete then
            self:AddObjective(QUEST_WATCH_CLICK_TO_COMPLETE, QuestObjectiveOptions(false, nil))
        else
            local completionText = GetQuestLogCompletionText(questLogIndex)
            if completionText then
                if shouldShowWaypoint then
                    local waypointText = C_QuestLog.GetNextWaypointText(questID)
                    if waypointText then
                        self:AddObjective(WAYPOINT_OBJECTIVE_FORMAT_OPTIONAL:format(waypointText), QuestObjectiveOptions(false, nil))
                    end
                end
                self:AddObjective(completionText, QuestObjectiveOptions(false, nil))
            else
                local waypointText = C_QuestLog.GetNextWaypointText(questID)
                if waypointText then
                    self:AddObjective(waypointText, QuestObjectiveOptions(false, nil))
                else
                    self:AddObjective(QUEST_WATCH_QUEST_READY, QuestObjectiveOptions(false, nil))
                end
            end
        end
    elseif questFailed then
        self:AddObjective(FAILED, QuestObjectiveOptions(false, nil))
    else
        if shouldShowWaypoint then
			local waypointText = C_QuestLog.GetNextWaypointText(questID);
			if waypointText  then
                self:AddObjective(WAYPOINT_OBJECTIVE_FORMAT_OPTIONAL:format(waypointText), QuestObjectiveOptions(isComplete, nil))
			end
		end

        if quest.requiredMoney > GetMoney() then
            self:AddObjective(GW.FormatMoneyForChat(GetMoney(), true) .. " / " .. GW.FormatMoneyForChat(quest.requiredMoney, true), QuestObjectiveOptions(isComplete, nil))
        end

        -- timer bar
		local timeTotal, timeElapsed = C_QuestLog.GetTimeAllowed(questID)
		if timeTotal and timeElapsed and timeElapsed < timeTotal then
            self:AddObjective(TIME_REMAINING, QuestObjectiveOptions(nil, nil, nil, true, timeTotal, GetTime() - timeElapsed))
		end
    end

    self:SetHeight(self.height)
end

GwQuestLogBlockMixin = {}

function GwQuestLogBlockMixin:UpdateBlockObjectives(numObjectives)
    local showCompletedObjectives = GW.settings.objectives.showCompleted
    for objectiveIndex = 1, numObjectives do
        local text, objectiveType, finished = GetQuestObjectiveInfo(self.questID, objectiveIndex, false)
        if text and (showCompletedObjectives or not finished) then
            self:AddObjective(text, QuestObjectiveOptions(finished, objectiveType, showCompletedObjectives))
        end
    end
end

function GwQuestLogBlockMixin:UpdateBlock(parent, quest, questID, questLogIndex, signature)
    if quest and not questID then
        questID = quest:GetID()
        questLogIndex = quest:GetQuestLogIndex()
    end
    UpdateBlockInternal(self, parent, quest, questID, questLogIndex, signature)
end

GwQuestLogMixin = {}

function GwQuestLogMixin:OnEvent(event, ...)
    local numWatchedQuests = C_QuestLog.GetNumQuestWatches()

    if event == "QUEST_LOG_UPDATE" then
        self:QueueUpdateLayout()
    elseif event == "QUEST_ACCEPTED" then
        local questID = ...
        if not C_QuestLog.IsQuestBounty(questID) then
            if C_QuestLog.IsQuestTask(questID) then
                if not C_QuestLog.IsWorldQuest(questID) then
                    self:QueuePartialUpdate(questID)
                end
            else
                if GetCVarBool("autoQuestWatch") and numWatchedQuests < Constants.QuestWatchConsts.MAX_QUEST_WATCHES then
                    C_QuestLog.AddQuestWatch(questID)
                    self:QueuePartialUpdate(questID)
                end
            end
        end
    elseif event == "QUEST_WATCH_LIST_CHANGED" then
        local questID, added = ...
        if added then
            if not C_QuestLog.IsQuestBounty(questID) or C_QuestLog.IsComplete(questID) then
                self:QueuePartialUpdate(questID, added)
            end
        else
            self:QueueUpdateLayout()
        end
    elseif event == "QUEST_AUTOCOMPLETE" then
        local questID = ...
        self:QueuePartialUpdate(questID)
    elseif event == "PLAYER_MONEY" and self.watchMoneyReasons > numWatchedQuests then
        self:QueueUpdateLayout()
    elseif event == "PLAYER_ENTERING_WORLD" then
        self:RegisterEvent("QUEST_DATA_LOAD_RESULT")
    elseif event == "QUEST_DATA_LOAD_RESULT" then
        local questID, success = ...
        local idx = C_QuestLog.GetLogIndexForQuestID(questID)
        if success and questID and idx and idx > 0 then
            C_Timer.After(1, function() self:QueuePartialUpdate(questID) end)
        end
    else
        self:QueueUpdateLayout()
    end

    if self.watchMoneyReasons > numWatchedQuests then
        self.watchMoneyReasons = self.watchMoneyReasons - numWatchedQuests
    end
end

local function QuestLogFlushQueuedUpdatesOnUpdate(frame)
    frame:SetScript("OnUpdate", nil)

    local container = frame.container
    container.updateFlushQueued = false
    container.isUpdating = false

    local didUpdate = false
    if container.fullUpdateQueued then
        container.fullUpdateQueued = false
        wipe(container.partialUpdatesByQuestID)
        wipe(container.partialUpdateOrder)
        container:UpdateLayout()
        didUpdate = true
    else
        for _, questID in ipairs(container.partialUpdateOrder) do
            local updateData = container.partialUpdatesByQuestID[questID]
            if updateData then
                container:PartialUpdate(questID, updateData.added)
                didUpdate = true
            end
        end
        wipe(container.partialUpdatesByQuestID)
        wipe(container.partialUpdateOrder)
    end

    container:CheckForAutoQuests()
    if didUpdate then
        GwQuestTracker:LayoutChanged()
    end
end

function GwQuestLogMixin:QueueUpdateLayout()
    self.fullUpdateQueued = true
    wipe(self.partialUpdatesByQuestID)
    wipe(self.partialUpdateOrder)

    if self.updateFlushQueued then
        return
    end

    self.updateFlushQueued = true
    self.updateQueueFrame:SetScript("OnUpdate", QuestLogFlushQueuedUpdatesOnUpdate)
end

function GwQuestLogMixin:QueuePartialUpdate(questID, added)
    if not questID or self.fullUpdateQueued then
        return
    end

    local updateData = self.partialUpdatesByQuestID[questID]
    if updateData then
        updateData.added = updateData.added or added
    else
        self.partialUpdatesByQuestID[questID] = {added = added}
        tinsert(self.partialUpdateOrder, questID)
    end

    if self.updateFlushQueued then
        return
    end

    self.updateFlushQueued = true
    self.updateQueueFrame:SetScript("OnUpdate", QuestLogFlushQueuedUpdatesOnUpdate)
end

function GwQuestLogMixin:GetBlockByQuestId(questID)
    for i = 1, #self.blocks do
        local block = self.blocks[i]
        if block.questID == questID then
            return block
        end
    end
    return nil
end

function GwQuestLogMixin:GetOrCreateBlockByQuestId(questID, colorKey)
    for i = 1, #self.blocks do
        local block = self.blocks[i]
        if block.questID == questID then
            return block
        elseif block.questID == nil then
            return self:GetBlock(i, colorKey, true)
        end
    end
    return self:GetBlock(#self.blocks + 1, colorKey, true)
end

function GwQuestLogMixin:GetQuestWatchId(questID)
    for i = 1, C_QuestLog.GetNumQuestWatches() do
        if questID == C_QuestLog.GetQuestIDForQuestWatchIndex(i) then
            return i
        end
    end
    return nil
end

function GwQuestLogMixin:CheckForAutoQuests()
    for i = 1, GetNumAutoQuestPopUps() do
        local questID, popUpType = GetAutoQuestPopUp(i)
        if questID and (popUpType == "OFFER" or popUpType == "COMPLETE") then
            local questBlock = self:GetBlockByQuestId(questID)
            if questBlock then
                if popUpType == "OFFER" then
                    questBlock.popupQuestAccept:Show()
                elseif popUpType == "COMPLETE" then
                    questBlock.turnin:Show()
                end
            end
        end
    end
end

function GwQuestLogMixin:UpdateLayout()
    if self.isUpdating then
        return
    end
    self.isUpdating = true

    local counterQuest = 0
    local shouldShowHeader = not self.collapsed
    local frameName = self:GetName()
    local watchedQuestIDs = {}
    local watchedQuestOrder = {}

    if self.collapsed then
        self.header:Show()
    elseif self.type == GW.Enum.ObjectivesBlockType.Quests then
        self.header:Hide()
    end

    local zone = GW.settings.objectives.zoneQuests and GetZoneContext() or nil
    self.zoneName = zone and zone.name

    local numQuests = C_QuestLog.GetNumQuestWatches()
    for i = 1, numQuests do
        local curQuestId = C_QuestLog.GetQuestIDForQuestWatchIndex(i)
        if curQuestId then
            watchedQuestOrder[curQuestId] = i
            watchedQuestIDs[#watchedQuestIDs + 1] = curQuestId
        end
    end

    local sortMode = GetQuestSortMode()
    if sortMode then
        SortQuestIDsBySetting(watchedQuestIDs, watchedQuestOrder, sortMode)
        for position, questID in ipairs(watchedQuestIDs) do
            watchedQuestOrder[questID] = position
        end
    end

    if ShouldSortSuperTrackedQuestToTop() then
        local superTrackedQuestID = C_SuperTrack.GetSuperTrackedQuestID()
        table.sort(watchedQuestIDs, function(leftQuestID, rightQuestID)
            local isLeftSuperTracked = leftQuestID == superTrackedQuestID
            local isRightSuperTracked = rightQuestID == superTrackedQuestID

            if isLeftSuperTracked ~= isRightSuperTracked then
                return isLeftSuperTracked
            end

            return (watchedQuestOrder[leftQuestID] or 0) < (watchedQuestOrder[rightQuestID] or 0)
        end)
    end

    for _, curQuestId in ipairs(watchedQuestIDs) do
        if curQuestId then
            local q = GW.QuestCache:Get(curQuestId)
            local kind = GetQuestContainerKind(q, zone)
            if kind == self.type then
                if shouldShowHeader then
                    self.header:Show()
                    counterQuest = counterQuest + 1

                    local isFrequency = IsQuestFrequency(q)
                    local colorKey = GetContainerQuestColorKey(self, q, curQuestId, isFrequency)
                    local questLogIndex = q:GetQuestLogIndex()
                    local signature = BuildQuestBlockSignature(q, curQuestId, questLogIndex, colorKey)
                    local block = self.blocks and self.blocks[counterQuest]

                    if block and block:IsShown() and block.questID == curQuestId and block.gwSignature == signature then
                        -- pixel identical since the last pass: keep the rendered rows and
                        -- only refresh what the rebuild would have refreshed anyway
                        block.isFrequency = isFrequency
                        if q.requiredMoney > 0 then
                            self.watchMoneyReasons = self.watchMoneyReasons + 1
                        else
                            self.watchMoneyReasons = self.watchMoneyReasons - 1
                        end
                        if block.questLogIndex ~= questLogIndex then
                            -- the log index feeds the item button, it shifts when other
                            -- quests come and go without our content changing
                            block.questLogIndex = questLogIndex
                            GW.CombatQueue:Queue("update_tracker_actionbutton_" .. frameName .. block.index, block.UpdateObjectiveActionButton, {block})
                        end
                    else
                        block = self:GetBlock(counterQuest, colorKey, true)
                        block.isFrequency = isFrequency
                        block:UpdateBlock(self, q, curQuestId, questLogIndex, signature)
                        block:Show()
                    end
                    GW.CombatQueue:Queue("update_tracker_" .. frameName .. block.index, block.UpdateObjectiveActionButtonPosition, {block})
                else
                    counterQuest = counterQuest + 1
                    local block = self.blocks and self.blocks[counterQuest]
                    if block then
                        block:Hide()
                        block.questLogIndex = 0
                        GW.CombatQueue:Queue("update_tracker_" .. frameName .. counterQuest, block.UpdateObjectiveActionButton, {block})
                    end
                end
            end
        end
    end
    self.numQuests = counterQuest

    -- hide other quests
    for i = counterQuest + 1, #self.blocks do
        local block = self.blocks[i]
        block.questID = nil
        block.questLogIndex = 0
        block:Hide()
        GW.CombatQueue:Queue("update_tracker_itembutton_remove" .. i, block.UpdateObjectiveActionButton, {block})
    end

    if counterQuest == 0 and self.type ~= GW.Enum.ObjectivesBlockType.Quests then
        self.header:Hide()
    end


    self:LayoutBlocks(counterQuest)

    local headerCounterText = " (" .. counterQuest .. ")"
    self.header.title:SetText(GetContainerHeaderTitle(self, zone) .. headerCounterText)

    self.isUpdating = false
end

function GwQuestLogMixin:PartialUpdate(questID, added)
    if self.isUpdating or not questID then
        return
    end

    if ShouldSortSuperTrackedQuestToTop() or GetQuestSortMode() then
        self:UpdateLayout()
        GwQuestTracker:LayoutChanged()
        return
    end

    self.isUpdating = true

    local questWatchId = self:GetQuestWatchId(questID)
    local q = GW.QuestCache:Get(questID)
    local zone = GW.settings.objectives.zoneQuests and GetZoneContext() or nil
    if self.collapsed or GetQuestContainerKind(q, zone) ~= self.type or questWatchId == nil or not questWatchId then
        self.isUpdating = false
        return
    end

    local questLogIndex = q:GetQuestLogIndex()
    local isFrequency = IsQuestFrequency(q)
    local colorKey = GetContainerQuestColorKey(self, q, questID, isFrequency)
    local signature = BuildQuestBlockSignature(q, questID, questLogIndex, colorKey)
    local existingBlock = self:GetBlockByQuestId(questID)
    if existingBlock and existingBlock:IsShown() and existingBlock.gwSignature == signature then
        existingBlock.questLogIndex = questLogIndex
        self.isUpdating = false
        return
    end

    local block = self:GetOrCreateBlockByQuestId(questID, colorKey)

    if block and questLogIndex and questLogIndex > 0 then
        block.isFrequency = isFrequency
        block:UpdateBlock(self, q, questID, questLogIndex, signature)
        block:Show()
        if added then
            C_Timer.After(0.1, function()
                local b = self:GetBlockByQuestId(questID)
                if b then b:NewQuestAnimation() end
            end)
        end
    end

    local _, counterQuest = self:LayoutBlocks()
    self.numQuests = counterQuest

    local headerCounterText = " (" .. counterQuest .. ")"
    self.header.title:SetText(GetContainerHeaderTitle(self, zone) .. headerCounterText)

    if block and block.hasItem then
        GW.CombatQueue:Queue("update_tracker_quest_itembutton_position" .. block.index, block.UpdateObjectiveActionButtonPosition, {block})
    end

    self.isUpdating = false
end

function GwQuestLogMixin:BlockOnClick(button)
    if ChatFrameUtil.TryInsertQuestLinkForQuestID(self.questID) then
        return
    end

    if button ~= "RightButton" then
        local questID = self.questID
        if IsModifiedClick("QUESTWATCHTOGGLE") then
            C_QuestLog.RemoveQuestWatch(questID)
        else
            local quest = GW.QuestCache:Get(questID)
            if quest.isAutoComplete and quest:IsComplete() then
                RemoveAutoQuestPopUp(questID)
                ShowQuestComplete(questID)
            else
                GW.ShowQuestDetails(questID)
            end
        end
    else
        MenuUtil.CreateContextMenu(self, function(owner, rootDescription)
            rootDescription:SetMinimumWidth(1)
            local questID = self.questID
            rootDescription:CreateTitle(C_QuestLog.GetTitleForQuestID(questID))

            if C_SuperTrack.GetSuperTrackedQuestID() ~= questID then
                rootDescription:CreateButton(SUPER_TRACK_QUEST, function()
                    C_SuperTrack.SetSuperTrackedQuestID(questID)
                end)
            else
                rootDescription:CreateButton(STOP_SUPER_TRACK_QUEST, function()
                    C_SuperTrack.SetSuperTrackedQuestID(0)
                end)
            end

            local toggleDetailsText = QuestUtil.IsShowingQuestDetails(questID) and OBJECTIVES_HIDE_VIEW_IN_QUESTLOG or OBJECTIVES_VIEW_IN_QUESTLOG

            rootDescription:CreateButton(toggleDetailsText, function()
                QuestUtil.OpenQuestDetails(questID)
            end)

            rootDescription:CreateButton(OBJECTIVES_SHOW_QUEST_MAP, function() GW.ShowQuestDetails(questID) end)

            rootDescription:CreateButton(OBJECTIVES_STOP_TRACKING, function()
                C_QuestLog.RemoveQuestWatch(questID)
            end)

            if C_QuestLog.IsPushableQuest(questID) and IsInGroup() then
                rootDescription:CreateButton(SHARE_QUEST, function()
                    QuestUtil.ShareQuest(questID)
                end)
            end
            GW.SetMenuEntryNegative(rootDescription:CreateButton(ABANDON_QUEST_ABBREV, function()
                QuestMapQuestOptions_AbandonQuest(questID)
            end))
            rootDescription:CreateButton(GW.L["Wowhead URL"], function() GW.ShowWowheadUrlPopup("quest", questID) end)
        end)
    end
end

GwObjectivesQuestContainerMixin = CreateFromMixins(GwQuestLogMixin)

function GwObjectivesQuestContainerMixin:InitModule()
    self.blockMixInTemplate = GwQuestLogBlockMixin

    self:SetScript("OnEvent", self.OnEvent)
    self:RegisterEvent("QUEST_LOG_UPDATE")
    self:RegisterEvent("QUEST_WATCH_LIST_CHANGED")
    self:RegisterEvent("QUEST_AUTOCOMPLETE")
    self:RegisterEvent("QUEST_ACCEPTED")
    self:RegisterEvent("PLAYER_MONEY")
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("SUPER_TRACKING_CHANGED")
    self:RegisterEvent("QUEST_POI_UPDATE")
    -- caves and buildings bring their own map, the quests only move when the zone changes
    EventRegistry:RegisterCallback("GW2_UI.PlayerLocationChanged", function()
        if GW.settings.objectives.zoneQuests and GetZoneContext().name ~= self.zoneName then
            self:QueueUpdateLayout()
        end
    end, self)
    self.watchMoneyReasons = 0
    self.updateQueueFrame = CreateFrame("Frame", nil, self)
    self.updateQueueFrame.container = self
    self.updateFlushQueued = false
    self.fullUpdateQueued = false
    self.partialUpdatesByQuestID = {}
    self.partialUpdateOrder = {}

    self.header = CreateFrame("Button", nil, self, "GwQuestTrackerHeader")
    self.header.title:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Header, "SHADOW")

    self.collapsed = false
    self.header:SetScript("OnMouseDown", function() self:ToggleCollapsed() end) -- this way, otherwiese we have a wrong self at the function
    if self.type == GW.Enum.ObjectivesBlockType.Campaign then
        self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Campaign]:GetRGB())
        self.header.icon:SetTexCoord(0.5, 1, 0, 0.25)
        self.header.title:SetText(TOP_CONTAINER_TITLE)
    else
        self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Quest]:GetRGB())
        self.header.icon:SetTexCoord(0, 0.5, 0.25, 0.5)
        self.header.title:SetText(GetContainerHeaderTitle(self))
    end

    self:OnEvent("LOAD")
end
