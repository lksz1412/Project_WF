---@class GW2
local GW = select(2, ...)
local IsIn = GW.IsIn
local MixinHideDuringPetAndOverride = GW.MixinHideDuringPetAndOverride

GwHealthglobeMixin = {}

function GwHealthglobeMixin:FlashAnimation(delta, t)
    t = (t or 0) + delta * max(1, 4 * (1 - (self.healthPercentage / 0.65)))
    local c = 0.4 * math.abs(math.sin(t))
    self.border.normal:SetVertexColor(c, c, c, 1)

    if self.healthPercentage > 0.65 and c < 0.2 then
        self:SetScript("OnUpdate", nil)
        self.border.normal:SetVertexColor(0, 0, 0, 1)
    end
end

function GwHealthglobeMixin:UpdateHealthData()
    local health, healthMax = UnitHealth("player"), UnitHealthMax("player")

    self.health:SetMinMaxValues(0, healthMax)
    self.health:SetValue(health, Enum.StatusBarInterpolation.ExponentialEaseOut)

    -- absorb + heal prediction: the values go into the invisible geometry bars whose
    -- fill starts at the health fill top (see BuildStackedSegment), the clip frames
    -- reveal the matching slice of the segment textures.
    -- healthMax may be secret in combat but can be PASSED THROUGH as-is — only the
    -- pedestal needs Lua math, so it refreshes whenever healthMax is readable and
    -- stays frozen otherwise (a stale pedestal drifts the segment by ~1px at most,
    -- the amount scale itself always follows the live max)
    UnitGetDetailedHealPrediction("player", nil, self.hpValues)
    local allHeal = self.hpValues:GetIncomingHeals()

    if not GW.IsSecretValue(healthMax) then
        self.gwGeoPedestal = -healthMax * self.gwGeoPedestalFactor
    end
    self.healPredictionGeo:SetMinMaxValues(self.gwGeoPedestal, healthMax)
    self.damageAbsorbGeo:SetMinMaxValues(self.gwGeoPedestal, healthMax)
    self.healPredictionGeo:SetValue(allHeal, Enum.StatusBarInterpolation.ExponentialEaseOut)

    local damageAbsorbAmount, damageAbsorbClamped = self.hpValues:GetDamageAbsorbs()
    self.damageAbsorbGeo:SetValue(damageAbsorbAmount, Enum.StatusBarInterpolation.ExponentialEaseOut)
    self.overDamageAbsorbIndicator:SetAlphaFromBoolean(damageAbsorbClamped, 1, 0)

    local healAbsorbAmount = self.hpValues:GetHealAbsorbs()
    self.healAbsorb:SetMinMaxValues(0, healthMax)
    self.healAbsorb:SetValue(healAbsorbAmount, Enum.StatusBarInterpolation.ExponentialEaseOut)
end

function GwHealthglobeMixin:OnEvent(event)
    if event == "PLAYER_ENTERING_WORLD" then
        MixinHideDuringPetAndOverride(self)
        self:UpdateHealthData()
        self:SelectPvp()
    elseif IsIn(event, "UNIT_HEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_MAXHEALTH", "UNIT_ABSORB_AMOUNT_CHANGED", "UNIT_HEAL_PREDICTION", "UNIT_HEAL_ABSORB_AMOUNT_CHANGED", "UNIT_MAX_HEALTH_MODIFIERS_CHANGED") then
        self:UpdateHealthData()
    elseif IsIn(event, "WAR_MODE_STATUS_UPDATE", "PLAYER_FLAGS_CHANGED", "UNIT_FACTION") then
        self:SelectPvp()
    elseif event == "RESURRECT_REQUEST" then
        PlaySound(SOUNDKIT.UI_70_BOOST_THANKSFORPLAYING_SMALLER, "Master")
    end
end

function GwHealthglobeMixin:OnEnter()
    local warmode = GW.Retail and C_PvP.IsWarModeDesired()
    local pvpdesired = GetPVPDesired()
    local freePVP = UnitIsPVPFreeForAll(self.gwUnit)
    local unitPVP = UnitIsPVP(self.gwUnit)
    local pvpactive = false
    if freePVP or (GW.NotSecretValue(unitPVP) and unitPVP) then
        pvpactive = true
    end

    GameTooltip_SetDefaultAnchor(GameTooltip, self)
    GameTooltip:SetUnit(self.gwUnit)
    GameTooltip:AddLine(" ")
    if warmode or pvpdesired or pvpactive then
        GameTooltip_AddColoredLine(GameTooltip, PVP .. " - " .. VIDEO_OPTIONS_ENABLED, HIGHLIGHT_FONT_COLOR)
    else
        GameTooltip_AddColoredLine(GameTooltip, PVP .. " - " .. VIDEO_OPTIONS_DISABLED, HIGHLIGHT_FONT_COLOR)
    end
    if warmode then
        GameTooltip_AddNormalLine(GameTooltip, PVP_WARMODE_TOGGLE_ON, true)
    else
        if pvpdesired then
            GameTooltip_AddNormalLine(GameTooltip, PVP_TOGGLE_ON_VERBOSE, true)
        else
            if pvpactive then
                local pvpTime = GetPVPTimer()
                if pvpTime > 0 and pvpTime < 301000 then
                    local _, nMin, nSec = GW.TimeParts(pvpTime)
                    GameTooltip_AddNormalLine(GameTooltip, TIME_REMAINING .. " " .. string.format(TIMER_MINUTES_DISPLAY, nMin, nSec))
                end
                GameTooltip_AddNormalLine(GameTooltip, PVP_TOGGLE_OFF_VERBOSE, true)
            else
                GameTooltip_AddNormalLine(GameTooltip, PVP_WARMODE_TOGGLE_OFF, true)
            end
        end
    end

    local honorLevel = UnitHonorLevel and UnitHonorLevel("player")
    local badge = honorLevel and GW.GetHonorBadge(honorLevel, 0)
    if badge then
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(badge .. " " .. HONOR_LEVEL_LABEL:format(honorLevel), GW.GetLocalizedNumber(UnitHonor("player")) .. " / " .. GW.GetLocalizedNumber(UnitHonorMax("player")), 1, 1, 1, 1, 1, 1)
        local nextLevel = GW.GetNextHonorBadgeLevel(honorLevel)
        if nextLevel then
            GameTooltip:AddDoubleLine(GW.L["Next badge"], GW.GetHonorBadge(nextLevel, 0) .. " " .. HONOR_LEVEL_LABEL:format(nextLevel))
        end
    end

    if IsInRaid() then
        local groupNumber
        for i = 1, GetNumGroupMembers() do
            if GW.UnitIsUnit("raid" .. i, self.gwUnit) then
                groupNumber = select(3, GetRaidRosterInfo(i))
            end
        end
        if groupNumber then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(format(QUEST_SUGGESTED_GROUP_NUM_TAG, groupNumber), 1, 1, 1)
        end
    end
    GameTooltip:Show()

    if GW.settings.unitframes.player.pvpIndicator and self.pvp.pvpFlag then
        self.pvp:fadeIn()
    end
end

GwHealthglobeRepairMixin = {}

function GwHealthglobeRepairMixin:OnEvent(event)
    if event ~= "PLAYER_ENTERING_WORLD" and not GW.inWorld then
        return
    end
    local needRepair = false
    local gearBroken = false
    for i = 1, 23 do
        local current, maximum = GetInventoryItemDurability(i)
        if current and maximum then
            local dur = current / maximum
            if dur == 0 then
                gearBroken = true
                needRepair = true
                break -- Keine weitere Überprüfung nötig, wenn ein Item komplett kaputt ist
            elseif dur < 0.5 then
                needRepair = true
            end
        end
    end
    self.gearBroken = gearBroken

    self.gearBroken = gearBroken
    self.icon:SetTexCoord(0, 1, gearBroken and 0.5 or 0, gearBroken and 1 or 0.5)
    self:SetShown(needRepair)
end

function GwHealthglobeRepairMixin:OnEnter()
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    GameTooltip:ClearLines()
    if self.gearBroken then
        GameTooltip:AddLine(TUTORIAL_TITLE37, 1, 1, 1)
    else
        GameTooltip:AddLine(TUTORIAL_TITLE36, 1, 1, 1)
    end
    GameTooltip:Show()
end

function GwHealthglobeMixin:ToggleSettings()
    self:UpdateHealthData()
end

local function LoadHealthGlobe()
    local hg = CreateFrame("Button", "GW2_PlayerFrame", UIParent, "GwHealthGlobeModernTmpl")
    GW.SetFrameRoleset(hg, "unitFrames")
    -- player data can still be unavailable at load — a 0 range would break the
    -- pedestal (see below) until the first real update delivers the true max
    local maxHp = math.max(UnitHealthMax("player") or 0, 1)

    for _, bar in pairs({hg.health, hg.healAbsorb}) do
        bar:SetMinMaxValues(0, maxHp)
        bar:SetOrientation("VERTICAL")
    end

    -- Damage absorb and heal prediction render as segments STACKED on top of the
    -- current health fill (classic look). The amounts can be secret in combat, so
    -- the stacking must work without any Lua math on them:
    --   * an invisible geometry bar is anchored with its bottom to the health bar's
    --     fill texture top — its engine computed fill rect then covers exactly
    --     [health, health + amount] on screen
    --   * a SetClipsChildren frame spans [health fill top, geometry fill top] and
    --     crops the globe aligned segment texture to that window. Clip frames are
    --     used deliberately: an EMPTY clip rect reliably clips everything, while an
    --     empty/degenerate MaskTexture rect gets ignored by the renderer and would
    --     reveal the whole texture whenever the amount is 0
    --   * a status bar HIDES its fill when it renders below ~1px (rect degenerates
    --     to the full frame) — the geometry bar therefore carries a 2px pedestal
    --     below the health edge (range starts at -pedestalValue, frame extended 2px
    --     downward) so its fill rect never collapses; the clip frame bottom sits on
    --     the health fill directly, keeping the pedestal outside the visible window
    -- The MissingHealth clamp mode caps the amounts, so a segment never runs past
    -- the top of the globe.
    local GEO_PEDESTAL_PX = 2
    hg.gwGeoPedestalFactor = GEO_PEDESTAL_PX / hg.health:GetHeight()
    hg.gwGeoPedestal = -maxHp * hg.gwGeoPedestalFactor

    local function BuildStackedSegment(texturePath, r, g, b, a)
        local geo = CreateFrame("StatusBar", nil, hg)
        geo:SetOrientation("VERTICAL")
        geo:SetHeight(hg.health:GetHeight() + GEO_PEDESTAL_PX)
        geo:SetPoint("BOTTOMLEFT", hg.health:GetStatusBarTexture(), "TOPLEFT", 0, -GEO_PEDESTAL_PX)
        geo:SetPoint("BOTTOMRIGHT", hg.health:GetStatusBarTexture(), "TOPRIGHT", 0, -GEO_PEDESTAL_PX)
        -- fully transparent color fill: the bar still needs a managed fill texture
        -- (the clipper anchors to its rect), but nothing gets drawn
        geo:SetColorFill(0, 0, 0, 0)
        geo:SetMinMaxValues(hg.gwGeoPedestal, maxHp)
        geo:SetValue(0)

        -- clip window [health, health + amount]: bottom on the health fill top,
        -- top on the geometry fill top — empty when the amount is 0
        local clipper = CreateFrame("Frame", nil, hg)
        clipper:SetClipsChildren(true)
        clipper:SetFrameLevel(hg.health:GetFrameLevel() + 1)
        clipper:SetPoint("BOTTOMLEFT", hg.health:GetStatusBarTexture(), "TOPLEFT")
        clipper:SetPoint("BOTTOMRIGHT", hg.health:GetStatusBarTexture(), "TOPRIGHT")
        clipper:SetPoint("TOPLEFT", geo:GetStatusBarTexture(), "TOPLEFT")

        -- the segment texture stays anchored to the full globe (correct curvature),
        -- the clip frame crops it to the segment window
        local tex = clipper:CreateTexture(nil, "ARTWORK")
        tex:SetTexture(texturePath)
        tex:SetPoint("TOPLEFT", hg.health, "TOPLEFT")
        tex:SetPoint("BOTTOMRIGHT", hg.health, "BOTTOMRIGHT")
        tex:SetVertexColor(r, g, b, a)

        return geo
    end

    hg.healPredictionGeo = BuildStackedSegment("Interface/AddOns/GW2_UI/textures/globe/globewhite.png", 0.58431, 0.9372, 0.2980, 0.60)
    hg.damageAbsorbGeo = BuildStackedSegment("Interface/AddOns/GW2_UI/textures/globe/globeabsorb.png", 1, 1, 1, 0.66)

    -- over absorb glow (full globe) — shown while the absorb amount is clamped
    local indicatorHolder = CreateFrame("Frame", nil, hg)
    indicatorHolder:SetFrameLevel(hg.health:GetFrameLevel() + 2)
    indicatorHolder:SetAllPoints(hg.health)
    hg.overDamageAbsorbIndicator = indicatorHolder:CreateTexture(nil, "OVERLAY")
    hg.overDamageAbsorbIndicator:SetTexture("Interface/AddOns/GW2_UI/textures/globe/globeabsorb.png")
    hg.overDamageAbsorbIndicator:SetAllPoints(indicatorHolder)
    hg.overDamageAbsorbIndicator:SetVertexColor(1, 1, 1, 0.66)
    hg.overDamageAbsorbIndicator:SetAlpha(0)

    hg.hpValues = CreateUnitHealPredictionCalculator()
    hg.hpValues:SetDamageAbsorbClampMode(Enum.UnitDamageAbsorbClampMode.MissingHealth)
    hg.hpValues:SetHealAbsorbClampMode(Enum.UnitHealAbsorbClampMode.CurrentHealth)
    hg.hpValues:SetIncomingHealClampMode(Enum.UnitIncomingHealClampMode.MissingHealth)
    hg.hpValues:SetHealAbsorbMode(Enum.UnitHealAbsorbMode.ReducedByIncomingHeals)
    hg.hpValues:SetIncomingHealOverflowPercent(1)

    -- position based on XP bar space and make it movable if your actionbars are off
    if GW.settings.actionbars.enabled and GW.settings.actionbars.barLayout and not GW.ShouldBlockIncompatibleAddon("Actionbars") and not GW.IsGamepadInterface() then
        if GW.settings.hud.xpBar then
            hg:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 17)
        else
            hg:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 0)
        end
    else
        GW.RegisterMovableFrame(hg, GW.L["Health Globe"], "unitframes.healthGlobe", "Unitframe", nil, nil, false)
        hg:SetPoint("TOPLEFT", hg.gwMover)
        if not GW.settings.hud.xpBar and not hg.isMoved then
            local framePoint = GW.settings.unitframes.healthGlobe.pos
            hg.gwMover:ClearAllPoints()
            hg.gwMover:SetPoint(framePoint.point, UIParent, framePoint.relativePoint, framePoint.xOfs, 0)
        end
    end
    GW.RegisterScaleFrame(hg, 1.1)

    -- unit frame stuff
    hg:SetAttribute("*type1", "target")
    hg:SetAttribute("*type2", "togglemenu")
    hg:SetAttribute("unit", "player")
    hg:EnableMouse(true)
    hg:RegisterForClicks("AnyDown")
    hg.gwUnit = "player"

    GW.AddToClique(hg)

    -- the texts come from the text designer
    Mixin(hg, GW.HealthGlobeTextMixin)
    hg:ApplyTextTags()

    hg.UpdateTooltip = (GW.NotSecretValue(hg.gwUnit) and hg.OnEnter) or nil
    hg:SetScript("OnEvent", hg.OnEvent)
    hg:SetScript("OnEnter", hg.OnEnter)
    hg:SetScript("OnLeave", function(self)
        GameTooltip_Hide()
        if GW.settings.unitframes.player.pvpIndicator and self.pvp.pvpFlag then
            self.pvp:fadeOut()
        end
    end)
    hg:RegisterEvent("PLAYER_ENTERING_WORLD")
    hg:RegisterUnitEvent("PLAYER_FLAGS_CHANGED", "player")
    hg:RegisterEvent("RESURRECT_REQUEST")
    hg:RegisterUnitEvent("UNIT_HEAL_PREDICTION", "player")
    hg:RegisterUnitEvent("UNIT_HEALTH", "player")
    hg:RegisterUnitEvent("UNIT_MAXHEALTH", "player")
    hg:RegisterUnitEvent("UNIT_FACTION", "player")
    hg:RegisterUnitEvent("UNIT_ABSORB_AMOUNT_CHANGED", "player")
    hg:RegisterUnitEvent("UNIT_HEAL_ABSORB_AMOUNT_CHANGED", "player")
    hg:RegisterUnitEvent("UNIT_MAX_HEALTH_MODIFIERS_CHANGED", "player")
    hg:RegisterEvent("WAR_MODE_STATUS_UPDATE")

    -- setup hooks for the repair icon (and disable default repair frame)
    DurabilityFrame:UnregisterAllEvents()
    DurabilityFrame:HookScript("OnShow", GW.Self_Hide)
    DurabilityFrame:Hide()

    local rep = hg.repair
    rep:SetScript("OnEvent", rep.OnEvent)
    rep:SetScript("OnEnter", rep.OnEnter)
    rep:SetScript("OnLeave", GameTooltip_Hide)
    rep:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
    rep:RegisterEvent("PLAYER_ENTERING_WORLD")

    -- grab the TotemFramebuttons to our own Totem Frame
    GW.CreateTotemBar()

    -- setup anim to flash the PvP marker
    local pvp = hg.pvp
    local pagIn = pvp:CreateAnimationGroup("fadeIn")
    local pagOut = pvp:CreateAnimationGroup("fadeOut")
    local fadeOut = pagOut:CreateAnimation("Alpha")
    local fadeIn = pagIn:CreateAnimation("Alpha")

    pagOut:SetScript("OnFinished", function(self)
        self:GetParent():SetAlpha(0.33)
    end)

    fadeOut:SetFromAlpha(1.0)
    fadeOut:SetToAlpha(0.33)
    fadeOut:SetDuration(0.1)
    fadeIn:SetFromAlpha(0.33)
    fadeIn:SetToAlpha(1.0)
    fadeIn:SetDuration(0.1)

    pvp.fadeOut = function()
        pagIn:Stop()
        pagOut:Stop()
        pagOut:Play()
    end
    pvp.fadeIn = function(self)
        self:SetAlpha(1)
        pagIn:Stop()
        pagOut:Stop()
        pagIn:Play()
    end

    if not GW.settings.unitframes.player.pvpIndicator then pvp:Hide() end

    return hg
end
GW.LoadHealthGlobe = LoadHealthGlobe
