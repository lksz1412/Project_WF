---@class GW2
local GW = select(2, ...)
local RegisterMovableFrame = GW.RegisterMovableFrame

local function updateLootFrameButtons(self)
    for _, button in next, { self.ScrollTarget:GetChildren() } do
        local item = button.Item

        if item and not item.backdrop then
            local Icon = item.icon:GetTexture()
            item:GwStripTextures()
            item.icon:SetTexture(Icon)

            GW.HandleIcon(item.icon, true, GW.BackdropTemplates.DefaultWithColorableBorder)
            GW.HandleIconBorder(item.IconBorder, item.icon.backdrop)
            item.IconBorder:SetTexture("Interface/AddOns/GW2_UI/textures/bag/bagitemborder.png")
        end

        if button.BorderFrame then
            button.BorderFrame:SetAlpha(0)
        end
        if button.IconQuestTexture then
            button.IconQuestTexture:SetAlpha(0)
        end
        if button.HighlightNameFrame then
            button.HighlightNameFrame:SetAlpha(0)
        end
        if button.PushedNameFrame then
            button.PushedNameFrame:SetAlpha(0)
        end

        if button.NameFrame then
            button.NameFrame:SetTexture("Interface/AddOns/GW2_UI/textures/character/menu-hover.png")
            button.NameFrame:SetHeight(button:GetHeight())
            button.NameFrame:SetPoint("LEFT", button, "RIGHT", 0, 0)
        end

        if button.Text then 
            button.Text:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        end
    end
end

local function LoadLootFrameSkin()
    if not GW.settings.skins.lootFrame.enabled then return end

    LootFrame:GwStripTextures()
    if LootFrame.NineSlice then
        LootFrame.NineSlice:SetAlpha(0)
    end
    LootFrameBg:Hide()
    LootFrameTitleText:Hide()

    local GwLootFrameTitle = CreateFrame("Frame", nil, LootFrame, "GwLootFrameTitleTemp")
    GwLootFrameTitle:SetPoint("BOTTOMLEFT", LootFrame, "TOPLEFT", 0, -25)
    GwLootFrameTitle.headerString:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Normal)
    GwLootFrameTitle.headerString:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())

    local w = LootFrame:GetWidth()
    GwLootFrameTitle:SetWidth(w)
    GwLootFrameTitle.BGLEFT:SetWidth(w)
    GwLootFrameTitle.BGRIGHT:SetWidth(w)
    GwLootFrameTitle.headerString:SetWidth(w)

    if not LootFrame.SetBackdrop then
        Mixin(LootFrame, BackdropTemplateMixin)
        LootFrame:HookScript("OnSizeChanged", LootFrame.OnBackdropSizeChanged)
    end

    LootFrame:SetBackdrop({
        edgeFile = "",
        bgFile = "Interface/AddOns/GW2_UI/textures/bag/lootframebg.png",
        edgeSize = 1
    })

    -- the frame grows and shrinks with the loot, the mover keeps its full size like blizzards edit mode
    local maxHeight = LootFrame.GetPanelMaxHeight and LootFrame:GetPanelMaxHeight() or LootFrame:GetHeight()
    RegisterMovableFrame(LootFrame, BUTTON_LAG_LOOT, "skins.lootFrame", "Blizzard", {LootFrame:GetWidth(), maxHeight}, {GW.MoverOption.Scale})
    if not GetCVarBool("lootUnderMouse") then
        local pos = GW.settings.skins.lootFrame.pos
        LootFrame:ClearAllPoints()
        LootFrame:SetPoint(pos.point, nil, pos.relativePoint, pos.xOfs, pos.yOfs)
        hooksecurefunc(LootFrame, "SetPoint", function(_, _, holder)
            if holder ~= LootFrame.gwMover then
                LootFrame:ClearAllPoints()
                LootFrame:SetPoint("TOPLEFT", LootFrame.gwMover)
            end
        end)
    end

    LootFrame:GwKillEditMode()

    GW.HandleTrimScrollBar(LootFrame.ScrollBar)
    GW.HandleScrollControls(LootFrame)

    LootFrame.ClosePanelButton:ClearAllPoints()
    LootFrame.ClosePanelButton:SetPoint("RIGHT", GwLootFrameTitle.BGRIGHT, "RIGHT", -5, -2)
    LootFrame.ClosePanelButton:SetSize(20,20)
    LootFrame.ClosePanelButton:SetNormalTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-normal.png")
    LootFrame.ClosePanelButton:SetPushedTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")
    LootFrame.ClosePanelButton:SetHighlightTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")

    hooksecurefunc(LootFrame.ScrollBox, "Update", updateLootFrameButtons)
end
GW.LoadLootFrameSkin = LoadLootFrameSkin
