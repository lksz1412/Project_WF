---@class GW2
local GW = select(2, ...)

local tomTomWaypoint = nil

local function AddTomTomWaypoint(questId, objective)
    if TomTom and TomTom.AddWaypoint and Questie and Questie.started then
        local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(questId)
        local spawn, zone, name = QuestieLoader:ImportModule("DistanceUtils").GetNearestSpawnForQuest(QuestieQuest)
        if (not spawn) and objective ~= nil then
            spawn, zone, name = QuestieLoader:ImportModule("DistanceUtils").GetNearestSpawn(objective)
        end
        if spawn then
            if tomTomWaypoint and TomTom.RemoveWaypoint then -- remove old waypoint
                TomTom:RemoveWaypoint(tomTomWaypoint)
            end
            local uiMapId = QuestieLoader:ImportModule("ZoneDB"):GetUiMapIdByAreaId(zone)
            tomTomWaypoint = TomTom:AddWaypoint(uiMapId, spawn[1] / 100, spawn[2] / 100,  {title = name, crazy = true})
        end
    end
end

local function LinkQuestIntoChat(questId)
    if not ChatFrame1EditBox:IsVisible() then
        ChatFrameUtil.OpenChat(GetQuestLink(questId))
    else
        ChatFrameUtil.InsertLink(GetQuestLink(questId))
    end
end

local function UntrackQuest(questLogIndex)
    RemoveQuestWatch(questLogIndex)
    WatchFrame_Update()
    QuestLog_Update()
end

local function AddQuestInfos(questLogIndex, id)
    local title, level, _, _, _, isComplete, frequency, questId, startEvent = GetQuestLogTitle(questLogIndex)
    if title and questId then
        local isFailed = false
        local numObjectives = GetNumQuestLeaderBoards(questLogIndex)

        if isComplete == nil then
            local hiddenObjective = nil
			local uncompletedObjectives = nil
            for j = 1, numObjectives do
                local text, _, finished = GetQuestLogLeaderBoard(j, questLogIndex)
                if not finished and text then
                    uncompletedObjectives = true
                elseif not finished and not text then
                    hiddenObjective = true
                end
            end
            if (hiddenObjective and not uncompletedObjectives) then
                isComplete = true
            else
                isComplete = false
            end
        elseif isComplete == 1 then
            isComplete = true
        else
            isComplete = false
            isFailed = true
        end

        return {
            questId = questId,
            questWatchedId = id or 0,
            questLogIndex = questLogIndex,
            questLevel = level,
            tagID = GW.GetQuestTagID(questId),
            title = title,
            isComplete = isComplete,
            startEvent = startEvent,
            numObjectives = numObjectives,
            requiredMoney = GetQuestLogRequiredMoney(questLogIndex),
            isAutoComplete = GetQuestLogIsAutoComplete(questLogIndex),
            isFailed = isFailed,
            isFrequency = GW.IsRepeatableQuestFrequency(frequency),
            isClassQuest = GW.IsClassQuestLogIndex(questLogIndex),
        }
    end
end
-- AddObjective keeps no reference to its options table (field reads only), so one
-- scratch table serves every quest objective line — a full update otherwise allocated
-- a fresh table per line
local objectiveOptions = {}
local function QuestObjectiveOptions(finished, objectiveType, useCompletedLine)
    wipe(objectiveOptions)
    objectiveOptions.isQuest = true
    objectiveOptions.finished = finished
    objectiveOptions.objectiveType = objectiveType
    objectiveOptions.useCompletedLine = useCompletedLine
    return objectiveOptions
end

-- Everything UpdateBlockInternal renders derives from these inputs: when they are
-- unchanged since the last pass over this quest, the block is pixel identical and the
-- whole rebuild (row re-anchoring, SetText with its text layout flushes, height math)
-- is skipped — QUEST_LOG_UPDATE otherwise runs a full rebuild over every watched quest
local signatureParts, signatureCount = {}, 0
local function AddSignaturePart(value)
    signatureCount = signatureCount + 1
    signatureParts[signatureCount] = tostring(value)
end

local function BuildQuestBlockSignature(quest, colorKey)
    -- mirrors the completion override at the top of UpdateBlockInternal
    local isComplete = quest.isComplete or (quest.numObjectives == 0 and GetMoney() >= quest.requiredMoney and not quest.startEvent)

    signatureCount = 0
    AddSignaturePart(quest.questId)
    AddSignaturePart(quest.title)
    AddSignaturePart(quest.questLevel)
    AddSignaturePart(quest.tagID)
    AddSignaturePart(colorKey)
    AddSignaturePart(GW.ObjectivesTrackerState.layoutGeneration)
    AddSignaturePart(GW.settings.objectives.showCompleted)
    AddSignaturePart(GW.settings.objectives.statusBars)
    AddSignaturePart(isComplete)
    AddSignaturePart(quest.isFailed)
    AddSignaturePart(quest.isAutoComplete)
    AddSignaturePart(quest.requiredMoney)
    if quest.requiredMoney and quest.requiredMoney > 0 then
        AddSignaturePart(GetMoney())
    end
    AddSignaturePart(GW.GetQuestRewardXP(quest.questId))
    -- turnin/accept popups are rendered as block buttons (the mixin method uses no self)
    AddSignaturePart(GwObjectivesBlockTemplateMixin.IsQuestAutoTurnInOrAutoAccept(nil, quest.questId, "COMPLETE", isComplete, quest.isAutoComplete))
    AddSignaturePart(GwObjectivesBlockTemplateMixin.IsQuestAutoTurnInOrAutoAccept(nil, quest.questId, "OFFER"))
    if isComplete then
        AddSignaturePart(GetQuestLogCompletionText(quest.questLogIndex))
    else
        local infos = C_QuestLog.GetQuestObjectives(quest.questId)
        AddSignaturePart(quest.numObjectives)
        for objectiveIndex = 1, quest.numObjectives do
            local info = infos and infos[objectiveIndex]
            if info then
                AddSignaturePart(info.text)
                AddSignaturePart(info.type)
                AddSignaturePart(info.finished)
            end
        end
    end

    return table.concat(signatureParts, "\1", 1, signatureCount)
end

local function UpdateBlockInternal(self, parent, quest, signature)
    self.height = GW.GetObjectivesBlockBaseHeight()
    self.numObjectives = 0
    self.turnin:Hide()
    self.turnin:SetShown(self:IsQuestAutoTurnInOrAutoAccept(quest.questId, "COMPLETE", quest.isComplete, quest.isAutoComplete))
    self.popupQuestAccept:SetShown(self:IsQuestAutoTurnInOrAutoAccept(quest.questId, "OFFER"))

    if quest.requiredMoney then
        parent.watchMoneyReasons = parent.watchMoneyReasons + 1
    else
        parent.watchMoneyReasons = parent.watchMoneyReasons - 1
    end

    self.title = quest.title
    local text = GW.GetQuestLevelPrefix(quest.questLevel, quest.tagID)

    self.questID = quest.questId
    self.questLogIndex = quest.questLogIndex
    self.gwSignature = signature or BuildQuestBlockSignature(quest, self.gwColorKey)
    self.title = quest.title
    self.isAutoComplete = quest.isAutoComplete
    self.Header:SetText(text .. quest.title)
    local xpReward = GW.GetQuestRewardXP(quest.questId)
    if xpReward then
        self.Header:SetText(text .. quest.title .. " |cFF888888(" .. GW.CommaValue(xpReward) .. XP .. ")|r")
    end

    GW.CombatQueue:Queue("update_tracker_actionbutton_" .. parent:GetName() .. (self.index or 0), self.UpdateObjectiveActionButton, {self})

    if quest.numObjectives == 0 and GetMoney() >= quest.requiredMoney and not quest.startEvent then
        quest.isComplete = true
    end
    self.isComplete = quest.isComplete

    if not quest.isComplete then
        self:UpdateBlockObjectives(quest.numObjectives)
    end

    if quest.requiredMoney and quest.requiredMoney > GetMoney() and not quest.isComplete then
        self:AddObjective(GW.FormatMoneyForChat(GetMoney(), true) .. " / " .. GW.FormatMoneyForChat(quest.requiredMoney, true), QuestObjectiveOptions(quest.isComplete, nil))
    end

    if quest.isComplete then
        if quest.isAutoComplete then
            self:AddObjective(QUEST_WATCH_CLICK_TO_COMPLETE, QuestObjectiveOptions(false, nil))
        else
            local completionText = GetQuestLogCompletionText(quest.questLogIndex)
            if completionText then
                self:AddObjective(completionText, QuestObjectiveOptions(false, nil))
            else
                self:AddObjective(QUEST_WATCH_QUEST_READY, QuestObjectiveOptions(false, nil))
            end
        end
    elseif quest.isFailed then
        self:AddObjective(FAILED, QuestObjectiveOptions(false, nil))
    end

    self.height = self.height + 5
    self:SetHeight(self.height)
end

GwQuestLogBlockMixin = {}

function GwQuestLogBlockMixin:UpdateBlockObjectives(numObjectives)
    local showCompletedObjectives = GW.settings.objectives.showCompleted
    local infos = C_QuestLog.GetQuestObjectives(self.questID)
    for objectiveIndex = 1, numObjectives do
        local text = infos[objectiveIndex].text
        local objectiveType = infos[objectiveIndex].type
        local finished = infos[objectiveIndex].finished
        if text and (showCompletedObjectives or not finished) then
            self:AddObjective(text, QuestObjectiveOptions(finished, objectiveType, showCompletedObjectives))
        end
    end
end

function GwQuestLogBlockMixin:UpdateBlock(parent, quest, signature)
    UpdateBlockInternal(self, parent, quest, signature)
end

GwQuestLogMixin = {}

function GwQuestLogMixin:GetBlockByQuestId(questID)
    for _, block in ipairs(self.blocks) do
        if block and block.questID == questID then
            return block
        end
    end
    return nil
end

function GwQuestLogMixin:CheckForAutoQuests()
    for i = 1, GetNumAutoQuestPopUps() do
        local questID, popUpType = GetAutoQuestPopUp(i)
        if questID and (popUpType == "OFFER" or popUpType == "COMPLETE") then
            local questBlock = self:GetBlockByQuestId(questID)
            if questBlock then
                if popUpType == "OFFER" then
                    questBlock.popupQuestAccept:Show()
                elseif popUpType == "COMPLETE" then
                    questBlock.turnin:Show()
                end
            end
        end
    end
end

local function QuestLogLayoutFlushOnUpdate(frame)
    frame:SetScript("OnUpdate", nil)

    local container = frame.container
    container.layoutUpdateQueued = false
    container:UpdateLayout()
    container:CheckForAutoQuests()
    GwQuestTracker:LayoutChanged()
end

function GwQuestLogMixin:QueueUpdateLayout()
    if self.layoutUpdateQueued then
        return
    end

    self.layoutUpdateQueued = true
    self.layoutUpdateFrame:SetScript("OnUpdate", QuestLogLayoutFlushOnUpdate)
end

function GwQuestLogMixin:OnEvent(event, ...)
    local arg1 = ...
    local numWatchedQuests = GetNumQuestWatches()

    if (event == "QUEST_WATCH_LIST_CHANGED" or event == "QUEST_LOG_UPDATE" or event == "UPDATE_FACTION" or (event == "UNIT_QUEST_LOG_CHANGED" and arg1 == "player")) then
        self:QueueUpdateLayout()
    elseif event == "PLAYER_MONEY" and self.watchMoneyReasons > numWatchedQuests then
        self:QueueUpdateLayout()
    else
        self:QueueUpdateLayout()
    end

    if self.watchMoneyReasons > numWatchedQuests then
        self.watchMoneyReasons = self.watchMoneyReasons - numWatchedQuests
    end
end

function GwQuestLogMixin:UpdateLayout()
    if self.isUpdating then
        return
    end
    self.isUpdating = true

    local counterQuest = 0
    local shouldShowHeader = not self.collapsed
    local frameName = self:GetName()

    if self.collapsed then
        self.header:Show()
    else
        self.header:Hide()
    end

    -- collect quests here
    local sorted = {}
    GW.sorted = sorted
    local numQuests = GetNumQuestWatches()
    for i = 1, numQuests do
        local questLogIndex = GetQuestIndexForWatch(i)

        if questLogIndex and questLogIndex > 0 then
            local questInfo = AddQuestInfos(questLogIndex, i)
            -- class quests go to the campaign container, like on forever
            if questInfo and (questInfo.isClassQuest or false) == (self.type == GW.Enum.ObjectivesBlockType.Campaign) then table.insert(sorted, questInfo) end
        end
    end

    --sort based on setting
    if GW.settings.objectives.sorting == "LEVEL" then
        -- Sort by level
        table.sort(sorted, function(a, b)
            return a and b and a.questLevel < b.questLevel
        end)
    elseif GW.settings.objectives.sorting == "LEVEL_DESC" then
        table.sort(sorted, function(a, b)
            return a and b and a.questLevel > b.questLevel
        end)
    elseif GW.settings.objectives.sorting == "ZONE" then
        GW.SortQuestsByZone(sorted)
    end

    wipe(self.trackedQuests)
    for _, quest in pairs(sorted) do
        if shouldShowHeader then
            self.header:Show()
            counterQuest = counterQuest + 1
            -- class quests take the color of the campaign, like on forever
            local colorKey = quest.isClassQuest and GW.Enum.ObjectivesNotificationType.Campaign
                or quest.tagID == Enum.QuestTag.PvP and GW.Enum.ObjectivesNotificationType.PvPQuest or quest.isFrequency and GW.Enum.ObjectivesNotificationType.DailyQuest or GW.Enum.ObjectivesNotificationType.Quest
            local signature = BuildQuestBlockSignature(quest, colorKey)
            local block = self.blocks and self.blocks[counterQuest]

            if block and block:IsShown() and block.questID == quest.questId and block.gwSignature == signature then
                -- pixel identical since the last pass: keep the rendered rows and only
                -- refresh what the rebuild would have refreshed anyway
                block.isFrequency = quest.isFrequency
                if quest.requiredMoney then
                    self.watchMoneyReasons = self.watchMoneyReasons + 1
                else
                    self.watchMoneyReasons = self.watchMoneyReasons - 1
                end
                if block.questLogIndex ~= quest.questLogIndex then
                    -- feeds the quest item button and the click handlers, it shifts when
                    -- other quests come and go without our content changing
                    block.questLogIndex = quest.questLogIndex
                    GW.CombatQueue:Queue("update_tracker_actionbutton_" .. frameName .. block.index, block.UpdateObjectiveActionButton, {block})
                end
            else
                block = self:GetBlock(counterQuest, colorKey, true)
                block.isFrequency = quest.isFrequency
                block:UpdateBlock(self, quest, signature)
                block:Show()
            end

            GW.CombatQueue:Queue("update_tracker_" .. frameName .. block.index, block.UpdateObjectiveActionButtonPosition, {block})
            tinsert(self.trackedQuests, quest)
        else
            counterQuest = counterQuest + 1
            local block = self.blocks and self.blocks[counterQuest]
            if block then
                block.questID = nil
                block.questLogIndex = 0
                block:Hide()
                GW.CombatQueue:Queue("update_tracker_" .. frameName .. counterQuest, block.UpdateObjectiveActionButton, {block})
            end
        end
    end

    self.numQuests = counterQuest

    -- hide other quests
    for i = counterQuest + 1, #self.blocks do
        local block = self.blocks[i]
        block.questID = nil
        block.questLogIndex = 0
        block:Hide()
        GW.CombatQueue:Queue("update_tracker_itembutton_remove" .. frameName .. i, block.UpdateObjectiveActionButton, {block})
    end

    if counterQuest == 0 and self.type == GW.Enum.ObjectivesBlockType.Campaign then
        self.header:Hide()
    end

    self:LayoutBlocks(counterQuest)

    local headerCounterText = " (" .. counterQuest .. ")"
    self.header.title:SetText((self.type == GW.Enum.ObjectivesBlockType.Campaign and GW.myLocalizedClass or TRACKER_HEADER_QUESTS) .. headerCounterText)

    self.isUpdating = false
end

function GwQuestLogMixin:BlockOnClick(button)
    if button == "RightButton" then
        MenuUtil.CreateContextMenu(self, function(ownerRegion, rootDescription)
            rootDescription:CreateTitle(self.title)

            if Questie and Questie.started then
                local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(self.questID) or {}

                if QuestieQuest:IsComplete() == 0 then
                    local submenuObjectives = rootDescription:CreateButton(OBJECTIVES_TRACKER_LABEL)

                    for _, objective in pairs(QuestieQuest.Objectives) do
                        local submenuObjectives = submenuObjectives:CreateButton(objective.Description)

                        if TomTom and TomTom.AddWaypoint then
                            submenuObjectives:CreateButton(GW.L["Set TomTom Target"], function()
                                AddTomTomWaypoint(self.questID, objective)
                            end)
                        end

                        submenuObjectives:CreateButton(GW.L["Show on Map"], function()
                            QuestieLoader:ImportModule("TrackerUtils"):ShowObjectiveOnMap(objective)
                        end)
                    end

                    if next(QuestieQuest.SpecialObjectives) then
                        for _, objective in pairs(QuestieQuest.SpecialObjectives) do
                            local submenuObjectives = submenuObjectives:CreateButton(objective.Description)

                            if TomTom and TomTom.AddWaypoint then
                                submenuObjectives:CreateButton(GW.L["Set TomTom Target"], function()
                                    AddTomTomWaypoint(self.questID, objective)
                                end)
                            end

                            submenuObjectives:CreateButton(GW.L["Show on Map"], function()
                                QuestieLoader:ImportModule("TrackerUtils"):ShowObjectiveOnMap(objective)
                            end)
                        end
                    end
                end

                rootDescription:CreateButton(GW.L["Wowhead URL"], function() GW.ShowWowheadUrlPopup("quest", self.questID) end)
            else
                if WatchFrame.showObjectives then
                    rootDescription:CreateButton(OBJECTIVES_SHOW_QUEST_MAP, function()
                        GW.ShowQuestDetails(self.questID)
                    end)
                end
            end

            rootDescription:CreateButton(OBJECTIVES_VIEW_IN_QUESTLOG, function() GW.ShowQuestLogEntry(self.questLogIndex) end)
            if CanAbandonQuest(self.questID) then
                GW.SetMenuEntryNegative(rootDescription:CreateButton(ABANDON_QUEST_ABBREV, function() GW.AbandonQuestLogEntry(self.questID) end))
            end

            if TomTom and TomTom.AddWaypoint and Questie and Questie.started then
                rootDescription:CreateButton(GW.L["Set TomTom Target"], function() AddTomTomWaypoint(self.questID, nil) end)
            end

            if Questie and Questie.started and self.isComplete then
                rootDescription:CreateButton(GW.L["Show on Map"], function()
                    local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(self.questID)
                    QuestieLoader:ImportModule("TrackerUtils"):ShowFinisherOnMap(QuestieQuest)
                end)
            end

            rootDescription:CreateButton(OBJECTIVES_STOP_TRACKING, function() UntrackQuest(self.questLogIndex) end)

            if GetQuestLogPushable(self.questLogIndex) and IsInGroup()then
				rootDescription:CreateButton(SHARE_QUEST, function()
					QuestLogPushQuest(self.questLogIndex)
				end)
			end

        end)
        return
    end

    if IsShiftKeyDown() and ChatFrameUtil.GetActiveWindow() then
        if button == "LeftButton" then
            LinkQuestIntoChat(self.questID)
        end
        return
    elseif IsControlKeyDown() then
        if button == "LeftButton" then
            AddTomTomWaypoint(self.questID, nil)
        else
            UntrackQuest(self.questLogIndex)
        end
        return
    end

    if button ~= "RightButton" then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)

        if self.isComplete and self.isAutoComplete then
            ShowQuestComplete(self.questLogIndex)
            WatchFrameAutoQuest_ClearPopUp(self.questID)
        else
            GW.ShowQuestLogEntry(self.questLogIndex)
        end
    end
end

GwObjectivesQuestContainerMixin = CreateFromMixins(GwQuestLogMixin)

function GwObjectivesQuestContainerMixin:InitModule()
    self.blockMixInTemplate = GwQuestLogBlockMixin

    self:SetScript("OnEvent", self.OnEvent)
    self:RegisterEvent("QUEST_LOG_UPDATE")
	self:RegisterEvent("QUEST_WATCH_UPDATE")
	self:RegisterEvent("UPDATE_FACTION")
	self:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
    self:RegisterEvent("QUEST_WATCH_LIST_CHANGED")
	self:RegisterEvent("PLAYER_LEVEL_UP")
    self:RegisterEvent("PLAYER_MONEY")
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self.watchMoneyReasons = 0
    self.trackedQuests = {}
    self.layoutUpdateFrame = CreateFrame("Frame", nil, self)
    self.layoutUpdateFrame.container = self
    self.layoutUpdateQueued = false

    self.header = CreateFrame("Button", nil, self, "GwQuestTrackerHeader")
    self.header.title:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Header, "SHADOW")

    self.collapsed = false
    self.header:SetScript("OnMouseDown", function() self:ToggleCollapsed() end) -- this way, otherwiese we have a wrong self at the function
    if self.type == GW.Enum.ObjectivesBlockType.Campaign then
        self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Campaign]:GetRGB())
        self.header.icon:SetTexCoord(0.5, 1, 0, 0.25)
        self.header.title:SetText(GW.myLocalizedClass)
    else
        self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Quest]:GetRGB())
        self.header.icon:SetTexCoord(0, 0.5, 0.25, 0.5)
        self.header.title:SetText(TRACKER_HEADER_QUESTS)
    end


    ExpandQuestHeader(0)

    self:OnEvent("LOAD")
end
