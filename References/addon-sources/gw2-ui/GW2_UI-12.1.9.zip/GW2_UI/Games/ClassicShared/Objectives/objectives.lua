---@class GW2
local GW = select(2, ...)
-- Mists has its own
if GW.Mists then return end
local questWatchDB -- GW.private.questWatch, set in InitModule

local lastAQW = GetTime()
local tomTomWaypoint = nil

local function AddTomTomWaypoint(questId, objective)
    if TomTom and TomTom.AddWaypoint and Questie and Questie.started then
        local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(questId)
        local spawn, zone, name = QuestieLoader:ImportModule("DistanceUtils").GetNearestSpawnForQuest(QuestieQuest)
        if (not spawn) and objective ~= nil then
            spawn, zone, name = QuestieLoader:ImportModule("DistanceUtils").GetNearestSpawn(objective)
        end
        if spawn then
            if tomTomWaypoint and TomTom.RemoveWaypoint then -- remove old waypoint
                TomTom:RemoveWaypoint(tomTomWaypoint)
            end
            local uiMapId = QuestieLoader:ImportModule("ZoneDB"):GetUiMapIdByAreaId(zone)
            tomTomWaypoint = TomTom:AddWaypoint(uiMapId, spawn[1] / 100, spawn[2] / 100,  {title = name, crazy = true})
        end
    end
end

-- quest links exist from wrath on, before that questie has its own format
local function LinkQuestIntoChat(title, questId)
    local link
    if GW.Wrath then
        link = GetQuestLink(questId)
    elseif Questie and Questie.started then
        link = "[" .. title .. " (" .. questId .. ")]"
    else
        link = gsub(title, " *(.*)", "%1")
    end
    if not ChatFrame1EditBox:IsVisible() then
        ChatFrameUtil.OpenChat(link)
    else
        ChatFrameUtil.InsertLink(link)
    end
end

local function UntrackQuest(questLogIndex)
    local questID = GetQuestIDFromLogIndex(questLogIndex)
    for index, value in ipairs(QUEST_WATCH_LIST) do
        if value.id == questID then
            tremove(QUEST_WATCH_LIST, index)
        end
    end
    if GetCVar("autoQuestWatch") == "0" then
        questWatchDB.TrackedQuests[questID] = nil
    else
        questWatchDB.AutoUntrackedQuests[questID] = true
    end
    RemoveQuestWatch(questLogIndex)
    if GW.Wrath then
        WatchFrame_Update()
    else
        QuestWatch_Update()
    end
    QuestLog_Update()
end

local function AddQuestInfos(questId, id)
    local title, level, _, _, _, isComplete, frequency, _, startEvent = GetQuestLogTitle(id)
    local sourceItemId = nil
    local isFailed = false

    -- vanilla has no quest items in the quest log, questie knows them
    if GW.Classic and Questie and Questie.started then
        local questieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(questId)
        if questieQuest and questieQuest.sourceItemId then
            sourceItemId = questieQuest.sourceItemId
        end
    end

    if isComplete == nil then
        isComplete = false
    elseif isComplete == 1 then
        isComplete = true
    else
        isComplete = false
        isFailed = true
    end

    return {
        questId = questId,
        questWatchedId = id or 0,
        questLogIndex = id,
        questLevel = level,
        tagID = GW.GetQuestTagID(questId),
        title = title,
        isComplete = isComplete,
        startEvent = startEvent,
        numObjectives = GetNumQuestLeaderBoards(id),
        requiredMoney = GetQuestLogRequiredMoney(id),
        isAutoComplete = false,
        sourceItemId = sourceItemId,
        isFailed = isFailed,
        isFrequency = GW.IsRepeatableQuestFrequency(frequency),
        isClassQuest = GW.IsClassQuestLogIndex(id),
    }
end

-- AddObjective keeps no reference to its options table (field reads only), so one
-- scratch table serves every quest objective line — a full update otherwise allocated
-- a fresh table per line
local objectiveOptions = {}
local function QuestObjectiveOptions(finished, objectiveType, useCompletedLine)
    wipe(objectiveOptions)
    objectiveOptions.isQuest = true
    objectiveOptions.finished = finished
    objectiveOptions.objectiveType = objectiveType
    objectiveOptions.useCompletedLine = useCompletedLine
    return objectiveOptions
end

-- Everything UpdateBlockInternal renders derives from these inputs: when they are
-- unchanged since the last pass over this quest, the block is pixel identical and the
-- whole rebuild (row re-anchoring, SetText with its text layout flushes, height math)
-- is skipped — QUEST_LOG_UPDATE otherwise runs a full rebuild over every watched quest
local signatureParts, signatureCount = {}, 0
local function AddSignaturePart(value)
    signatureCount = signatureCount + 1
    signatureParts[signatureCount] = tostring(value)
end

local function BuildQuestBlockSignature(quest, colorKey)
    -- mirrors the completion override at the top of UpdateBlockInternal
    local isComplete = quest.isComplete or (quest.numObjectives == 0 and GetMoney() >= quest.requiredMoney and not quest.startEvent)

    signatureCount = 0
    AddSignaturePart(quest.questId)
    AddSignaturePart(quest.title)
    AddSignaturePart(quest.questLevel)
    AddSignaturePart(quest.tagID)
    AddSignaturePart(colorKey)
    AddSignaturePart(GW.ObjectivesTrackerState.layoutGeneration)
    AddSignaturePart(GW.settings.objectives.showCompleted)
    AddSignaturePart(GW.settings.objectives.statusBars)
    AddSignaturePart(isComplete)
    AddSignaturePart(quest.isFailed)
    AddSignaturePart(quest.isAutoComplete)
    AddSignaturePart(quest.requiredMoney)
    if quest.requiredMoney and quest.requiredMoney > 0 then
        AddSignaturePart(GetMoney())
    end
    -- the xp reward is part of the header text
    AddSignaturePart(GW.GetQuestRewardXP(quest.questId))
    if isComplete then
        AddSignaturePart(GetQuestLogCompletionText(quest.questLogIndex))
    else
        local infos = C_QuestLog.GetQuestObjectives(quest.questId)
        AddSignaturePart(quest.numObjectives)
        for objectiveIndex = 1, quest.numObjectives do
            local info = infos and infos[objectiveIndex]
            if info then
                AddSignaturePart(info.text)
                AddSignaturePart(info.type)
                AddSignaturePart(info.finished)
            end
        end
    end

    return table.concat(signatureParts, "\1", 1, signatureCount)
end

local function UpdateBlockInternal(self, parent, quest, signature)
    self.height = GW.GetObjectivesBlockBaseHeight()
    self.numObjectives = 0
    self.turnin:Hide()

    if quest.requiredMoney then
        parent.watchMoneyReasons = parent.watchMoneyReasons + 1
    else
        parent.watchMoneyReasons = parent.watchMoneyReasons - 1
    end

    self.title = quest.title
    local text = GW.GetQuestLevelPrefix(quest.questLevel, quest.tagID)

    self.questID = quest.questId
    self.questLogIndex = quest.questLogIndex
    self.gwSignature = signature or BuildQuestBlockSignature(quest, self.gwColorKey)
    self.sourceItemId = quest.sourceItemId
    self.title = quest.title
    self.Header:SetText(text .. quest.title)

    GW.CombatQueue:Queue("update_tracker_actionbutton_" .. parent:GetName() .. (self.index or 0), self.UpdateObjectiveActionButton, {self})

    local xpReward = GW.GetQuestRewardXP(quest.questId)
    if xpReward then
        self.Header:SetText(text .. quest.title .. " |cFF888888(" .. GW.CommaValue(xpReward) .. XP .. ")|r")
    end

    if quest.numObjectives == 0 and GetMoney() >= quest.requiredMoney and not quest.startEvent then
        quest.isComplete = true
    end
    self.isComplete = quest.isComplete

    if not quest.isComplete then
        self:UpdateBlockObjectives(quest.numObjectives)
    end

    if quest.requiredMoney and quest.requiredMoney > GetMoney() and not quest.isComplete then
        self:AddObjective(GW.FormatMoneyForChat(GetMoney(), true) .. " / " .. GW.FormatMoneyForChat(quest.requiredMoney, true), QuestObjectiveOptions(quest.isComplete, nil))
    end

    if quest.isComplete then
        if quest.isAutoComplete then
            self:AddObjective(QUEST_WATCH_CLICK_TO_COMPLETE, QuestObjectiveOptions(false, nil))
        else
            local completionText = GetQuestLogCompletionText(quest.questLogIndex)
            if completionText then
                self:AddObjective(completionText, QuestObjectiveOptions(false, nil))
            else
                self:AddObjective(QUEST_WATCH_QUEST_READY, QuestObjectiveOptions(false, nil))
            end
        end
    elseif quest.isFailed then
        self:AddObjective(FAILED, QuestObjectiveOptions(false, nil))
    end

    self.height = self.height + 5
    self:SetHeight(self.height)
end

GwQuestLogBlockMixin = {}

function GwQuestLogBlockMixin:UpdateBlockObjectives(numObjectives)
    local showCompletedObjectives = GW.settings.objectives.showCompleted
    local infos = C_QuestLog.GetQuestObjectives(self.questID)
    for objectiveIndex = 1, numObjectives do
        local text = infos[objectiveIndex].text
        local objectiveType = infos[objectiveIndex].type
        local finished = infos[objectiveIndex].finished
        if text and (showCompletedObjectives or not finished) then
            self:AddObjective(text, QuestObjectiveOptions(finished, objectiveType, showCompletedObjectives))
        end
    end
end

function GwQuestLogBlockMixin:UpdateBlock(parent, quest, signature)
    if quest.questId then
        UpdateBlockInternal(self, parent, quest, signature)
    end
end

GwQuestLogMixin = {}

local function QuestLogLayoutFlushOnUpdate(frame)
    frame:SetScript("OnUpdate", nil)

    local container = frame.container
    container.layoutUpdateQueued = false
    container:UpdateLayout()
    GwQuestTracker:LayoutChanged()
end

function GwQuestLogMixin:QueueUpdateLayout()
    if self.layoutUpdateQueued then
        return
    end

    self.layoutUpdateQueued = true
    self.layoutUpdateFrame:SetScript("OnUpdate", QuestLogLayoutFlushOnUpdate)
end

function GwQuestLogMixin:OnEvent(event, ...)
    local arg1 = ...
    local numWatchedQuests = GetNumQuestWatches()

    if (event == "QUEST_LOG_UPDATE" or event == "UPDATE_FACTION" or (event == "UNIT_QUEST_LOG_CHANGED" and arg1 == "player")) then
        self:QueueUpdateLayout()
    elseif event == "PLAYER_MONEY" and self.watchMoneyReasons > numWatchedQuests then
        self:QueueUpdateLayout()
    else
        self:QueueUpdateLayout()
    end

    if self.watchMoneyReasons > numWatchedQuests then
        self.watchMoneyReasons = self.watchMoneyReasons - numWatchedQuests
    end
end

function GwQuestLogMixin:UpdateLayout()
    if self.isUpdating then
        return
    end
    self.isUpdating = true

    local counterQuest = 0
    local shouldShowHeader = not self.collapsed
    local frameName = self:GetName()

    if self.collapsed then
        self.header:Show()
    else
        self.header:Hide()
    end

    -- collect quests here
    local sorted = {}
    GW.sorted = sorted
    local numQuests = GetNumQuestLogEntries()
    for i = 1, numQuests do
        local questId = select(8, GetQuestLogTitle(i))

        if questId and questId > 0 then
            local questInfo = AddQuestInfos(questId, i)
            table.insert(sorted, questInfo)
        end
    end

    --sort based on setting
    if GW.settings.objectives.sorting == "LEVEL" then
        -- Sort by level
        table.sort(sorted, function(a, b)
            return a and b and a.questLevel < b.questLevel
        end)
    elseif GW.settings.objectives.sorting == "LEVEL_DESC" then
        table.sort(sorted, function(a, b)
            return a and b and a.questLevel > b.questLevel
        end)
    elseif GW.settings.objectives.sorting == "ZONE" then
        GW.SortQuestsByZone(sorted)
    end

    wipe(self.trackedQuests)
    for _, quest in pairs(sorted) do
        -- class quests go to the campaign container, like on forever
        if (quest.isClassQuest or false) == (self.type == GW.Enum.ObjectivesBlockType.Campaign) and ((GetCVar("autoQuestWatch") == "1" and not questWatchDB.AutoUntrackedQuests[quest.questId]) or (GetCVar("autoQuestWatch") == "0" and questWatchDB.TrackedQuests[quest.questId])) then
            if shouldShowHeader then
                self.header:Show()
                counterQuest = counterQuest + 1

                local isFrequency = quest.isFrequency
                -- class quests take the color of the campaign, like on forever
                local colorKey = quest.isClassQuest and GW.Enum.ObjectivesNotificationType.Campaign
                    or quest.tagID == Enum.QuestTag.PvP and GW.Enum.ObjectivesNotificationType.PvPQuest or isFrequency and GW.Enum.ObjectivesNotificationType.DailyQuest or GW.Enum.ObjectivesNotificationType.Quest
                local signature = BuildQuestBlockSignature(quest, colorKey)
                local block = self.blocks and self.blocks[counterQuest]

                if block and block:IsShown() and block.questID == quest.questId and block.gwSignature == signature then
                    -- pixel identical since the last pass: keep the rendered rows and only
                    -- refresh what the rebuild would have refreshed anyway
                    block.isFrequency = isFrequency
                    if quest.requiredMoney then
                        self.watchMoneyReasons = self.watchMoneyReasons + 1
                    else
                        self.watchMoneyReasons = self.watchMoneyReasons - 1
                    end
                    if block.questLogIndex ~= quest.questLogIndex or block.sourceItemId ~= quest.sourceItemId then
                        -- both feed the quest item button, they shift when other quests
                        -- come and go without our content changing
                        block.questLogIndex = quest.questLogIndex
                        block.sourceItemId = quest.sourceItemId
                        GW.CombatQueue:Queue("update_tracker_actionbutton_" .. frameName .. block.index, block.UpdateObjectiveActionButton, {block})
                    end
                else
                    block = self:GetBlock(counterQuest, colorKey, true)
                    block.isFrequency = isFrequency
                    block:UpdateBlock(self, quest, signature)
                    block:Show()
                end

                GW.CombatQueue:Queue("update_tracker_" .. frameName .. block.index, block.UpdateObjectiveActionButtonPosition, {block})
                -- the compass takes the same color
                quest.colorKey = colorKey
                tinsert(self.trackedQuests, quest)
            else
                counterQuest = counterQuest + 1
                local block = self.blocks and self.blocks[counterQuest]
                if block then
                    block.questID = nil
                    block.questLogIndex = 0
                    block.sourceItemId = nil
                    block:Hide()
                    GW.CombatQueue:Queue("update_tracker_" .. frameName .. counterQuest, block.UpdateObjectiveActionButton, {block})
                end
            end
        end
    end

    self.numQuests = counterQuest

    -- hide other quests
    for i = counterQuest + 1, #self.blocks do
        local block = self.blocks[i]
        block.questID = nil
        block.questLogIndex = 0
        block.sourceItemId = nil
        block:Hide()
        GW.CombatQueue:Queue("update_tracker_itembutton_remove" .. frameName .. i, block.UpdateObjectiveActionButton, {block})
    end

    if counterQuest == 0 and self.type == GW.Enum.ObjectivesBlockType.Campaign then
        self.header:Hide()
    end

    self:LayoutBlocks(counterQuest)

    local headerCounterText = " (" .. counterQuest .. ")"
    self.header.title:SetText((self.type == GW.Enum.ObjectivesBlockType.Campaign and GW.myLocalizedClass or TRACKER_HEADER_QUESTS) .. headerCounterText)

    self.isUpdating = false
end

function GwQuestLogMixin:BlockOnClick(button)
    if button == "RightButton" then
        MenuUtil.CreateContextMenu(self, function(ownerRegion, rootDescription)
            rootDescription:CreateTitle(self.title)

            if Questie and Questie.started then
                local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(self.questID)

                if QuestieQuest and QuestieQuest:IsComplete() == 0 then
                    local submenuObjectives = rootDescription:CreateButton(OBJECTIVES_TRACKER_LABEL)

                    for _, objective in pairs(QuestieQuest.Objectives) do
                        local submenuObjectives = submenuObjectives:CreateButton(objective.Description)

                        if TomTom and TomTom.AddWaypoint then
                            submenuObjectives:CreateButton(GW.L["Set TomTom Target"], function()
                                AddTomTomWaypoint(self.questID, objective)
                            end)
                        end

                        submenuObjectives:CreateButton(GW.L["Show on Map"], function()
                            QuestieLoader:ImportModule("TrackerUtils"):ShowObjectiveOnMap(objective)
                        end)
                    end

                    if next(QuestieQuest.SpecialObjectives) then
                        for _, objective in pairs(QuestieQuest.SpecialObjectives) do
                            local submenuObjectives = submenuObjectives:CreateButton(objective.Description)

                            if TomTom and TomTom.AddWaypoint then
                                submenuObjectives:CreateButton(GW.L["Set TomTom Target"], function()
                                    AddTomTomWaypoint(self.questID, objective)
                                end)
                            end

                            submenuObjectives:CreateButton(GW.L["Show on Map"], function()
                                QuestieLoader:ImportModule("TrackerUtils"):ShowObjectiveOnMap(objective)
                            end)
                        end
                    end
                end
            end

            rootDescription:CreateButton(COMMUNITIES_INVITE_MANAGER_LINK_TO_CHAT, function() LinkQuestIntoChat(self.title, self.questID) end)
            rootDescription:CreateButton(GW.L["Wowhead URL"], function() GW.ShowWowheadUrlPopup("quest", self.questID) end)
            rootDescription:CreateButton(OBJECTIVES_VIEW_IN_QUESTLOG, function() GW.ShowQuestLogEntry(self.questLogIndex) end)
            if CanAbandonQuest(self.questID) then
                GW.SetMenuEntryNegative(rootDescription:CreateButton(ABANDON_QUEST_ABBREV, function() GW.AbandonQuestLogEntry(self.questID) end))
            end

            if TomTom and TomTom.AddWaypoint and Questie and Questie.started then
                rootDescription:CreateButton(GW.L["Set TomTom Target"], function() AddTomTomWaypoint(self.questID, nil) end)
            end

            if Questie and Questie.started and self.isComplete then
                rootDescription:CreateButton(GW.L["Show on Map"], function()
                    local QuestieQuest = QuestieLoader:ImportModule("QuestieDB").GetQuest(self.questID)
                    QuestieLoader:ImportModule("TrackerUtils"):ShowFinisherOnMap(QuestieQuest)
                end)
            end

            rootDescription:CreateButton(UNTRACK_QUEST, function() UntrackQuest(self.questLogIndex)  end)

        end)
        return
    end

    if IsShiftKeyDown() and ChatFrameUtil.GetActiveWindow() then
        if button == "LeftButton" then
            LinkQuestIntoChat(self.title, self.questID)
        end
        return
    elseif IsControlKeyDown() then
        if button == "LeftButton" then
            AddTomTomWaypoint(self.questID, nil)
        else
            UntrackQuest(self.questLogIndex)
        end
        return
    end

    if button ~= "RightButton" then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        GW.ShowQuestLogEntry(self.questLogIndex, true)
    end
end

GwObjectivesQuestContainerMixin = CreateFromMixins(GwQuestLogMixin)

-- a watch change can concern either container, class quests have their own
local function UpdateQuestContainers()
    GW.ObjectiveTrackerContainer.Quests:OnEvent()
    GW.ObjectiveTrackerContainer.Campaign:OnEvent()
end


function GwObjectivesQuestContainerMixin:_RemoveQuestWatch(index, isGW2)
    if not isGW2 then
        local questId = select(8, GetQuestLogTitle(index))
        if questId == 0 then
            questId = index
        end

        if questId then
            if "0" == GetCVar("autoQuestWatch") then
                questWatchDB.TrackedQuests[questId] = nil
            else
                questWatchDB.AutoUntrackedQuests[questId] = true
            end
            UpdateQuestContainers()
        end
    end
end

function GwObjectivesQuestContainerMixin:_AQW_Insert(index)
    if index == 0 then
        return
    end

    local now = GetTime()
    if index and index == self._last_aqw and (now - lastAQW) < 0.1 then
        -- this fixes double calling due to AQW+AQW_Insert (QuestGuru fix)
        return
    end

    lastAQW = now
    self._last_aqw = index
    RemoveQuestWatch(index, true) -- prevent hitting 5 quest watch limit

    local questId = select(8, GetQuestLogTitle(index))
    if questId == 0 then
        questId = index
    end

    if questId > 0 then
        if "0" == GetCVar("autoQuestWatch") then
            if questWatchDB.TrackedQuests[questId] then
                questWatchDB.TrackedQuests[questId] = nil
            else
                questWatchDB.TrackedQuests[questId] = true
            end
        else
            if questWatchDB.AutoUntrackedQuests[questId] then
                questWatchDB.AutoUntrackedQuests[questId] = nil
            elseif IsShiftKeyDown() and (QuestLogFrame:IsShown() or (QuestLogExFrame and QuestLogExFrame:IsShown())) then--hack
                questWatchDB.AutoUntrackedQuests[questId] = true
            end
        end

        UpdateQuestContainers()
    end
end

function GwObjectivesQuestContainerMixin:InitModule()
    self.blockMixInTemplate = GwQuestLogBlockMixin

    questWatchDB = GW.private.questWatch

    -- migrate the former per character saved variable (temp function)
    if type(GW2UI_QUEST_WATCH_DB) == "table" then
        for _, listName in ipairs({ "TrackedQuests", "AutoUntrackedQuests" }) do
            for questId, value in pairs(GW2UI_QUEST_WATCH_DB[listName] or {}) do
                if questWatchDB[listName][questId] == nil then
                    questWatchDB[listName][questId] = value
                end
            end
        end
        GW2UI_QUEST_WATCH_DB = nil
    end

    self:SetScript("OnEvent", self.OnEvent)
    self:RegisterEvent("QUEST_LOG_UPDATE")
	self:RegisterEvent("QUEST_WATCH_UPDATE")
	self:RegisterEvent("UPDATE_FACTION")
	self:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
	self:RegisterEvent("PLAYER_LEVEL_UP")
    self:RegisterEvent("PLAYER_MONEY")
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self.watchMoneyReasons = 0
    self.trackedQuests = {}
    self.layoutUpdateFrame = CreateFrame("Frame", nil, self)
    self.layoutUpdateFrame.container = self
    self.layoutUpdateQueued = false

    self.header = CreateFrame("Button", nil, self, "GwQuestTrackerHeader")
    self.header.title:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Header, "SHADOW")

    self.collapsed = false
    self.header:SetScript("OnMouseDown", function() self:ToggleCollapsed() end) -- this way, otherwiese we have a wrong self at the function
    if self.type == GW.Enum.ObjectivesBlockType.Campaign then
        self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Campaign]:GetRGB())
        self.header.icon:SetTexCoord(0.5, 1, 0, 0.25)
        self.header.title:SetText(GW.myLocalizedClass)
        -- the quest watch hooks below exist once, in the quests container
        self:OnEvent("LOAD")
        return
    end
    self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.Quest]:GetRGB())
    self.header.icon:SetTexCoord(0, 0.5, 0.25, 0.5)
    self.header.title:SetText(TRACKER_HEADER_QUESTS)

    --hook functions
    if not GW.Wrath then
        hooksecurefunc("AutoQuestWatch_Insert", function(questIndex) self:_AQW_Insert(questIndex) end)
    end
    hooksecurefunc("AddQuestWatch", function(questIndex) self:_AQW_Insert(questIndex) end)
    hooksecurefunc("RemoveQuestWatch", function(questIndex) self:_RemoveQuestWatch(questIndex) end)

    IsQuestWatched = function(index)
        local _, _, _, isHeader, _, _, _, questId = GetQuestLogTitle(index)
        if isHeader then return false end
        if questId == 0 then
            questId = index
        end

        if "0" == GetCVar("autoQuestWatch") then
            return questWatchDB.TrackedQuests[questId or -1]
        else
            return questId and (not questWatchDB.AutoUntrackedQuests[questId])
        end
    end

    GetNumQuestWatches = function()
        return 0
    end

    local baseQLTB_OnClick = QuestLogTitleButton_OnClick
    QuestLogTitleButton_OnClick = function(btn, button) -- I wanted to use hooksecurefunc but this needs to be a pre-hook to work properly unfortunately
        if (not btn) or btn.isHeader or not IsShiftKeyDown() then baseQLTB_OnClick(btn, button) return end
        local questLogLineIndex = btn:GetID() + FauxScrollFrame_GetOffset(QuestLogListScrollFrame)

        if ( IsModifiedClick("CHATLINK") and ChatFrameUtil.GetActiveWindow() ) then
            local questId = GetQuestIDFromLogIndex(questLogLineIndex)
            ChatFrameUtil.InsertLink("["..gsub(btn:GetText(), " *(.*)", "%1").." ("..questId..")]")
        else
            if GetNumQuestLeaderBoards(questLogLineIndex) == 0 and not IsQuestWatched(questLogLineIndex) then -- only call if we actually want to fix this quest (normal quests already call AQW_insert)
                self:_AQW_Insert(questLogLineIndex)
                if GW.Wrath then
                    WatchFrame_Update()
                else
                    QuestWatch_Update()
                end
                QuestLog_SetSelection(questLogLineIndex)
                QuestLog_Update()
            else
                baseQLTB_OnClick(btn, button)
            end
        end
    end

    if not self._IsQuestWatched then
        self._IsQuestWatched = IsQuestWatched
        self._GetNumQuestWatches = GetNumQuestWatches
    end

    self:OnEvent("LOAD")
end
