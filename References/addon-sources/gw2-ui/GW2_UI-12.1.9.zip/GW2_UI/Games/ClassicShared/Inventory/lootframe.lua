---@class GW2
local GW = select(2, ...)
local RegisterMovableFrame = GW.RegisterMovableFrame

local LOOT_BUTTON_SHIFT = 20

local function updateLootFrameButtons()
    for i = 1, 4 do
        _G["LootButton" .. i]:ClearNormalTexture()
        _G["LootButton" .. i].IconBorder:SetTexture("Interface/AddOns/GW2_UI/textures/bag/bagitemborder.png")
    end
end

local function LoadLootFrameSkin()
    if not GW.settings.skins.lootFrame.enabled then return end

    LootFrameBg:Hide()
    LootFrameBg:SetPoint("TOPLEFT", 0, -64)
    LootFrameBg:SetWidth(170)
    LootFrame.TitleBg:Hide()
    LootFrame.TopTileStreaks:Hide()
    LootFramePortraitFrame:Hide()
    LootFramePortraitOverlay:Hide()
    LootFrameInset:Hide()
    LootFrameTopBorder:Hide()
    LootFrameTopRightCorner:Hide()
    LootFrameRightBorder:Hide()
    LootFrameLeftBorder:Hide()
    LootFrameBottomBorder:Hide()
    LootFrameBotRightCorner:Hide()
    LootFrameBotLeftCorner:Hide()

    local r = {LootFrame:GetRegions()}
    for _,c in pairs(r) do
        if c:GetObjectType() == "FontString" then
            c:Hide()
        end
    end

    local GwLootFrameTitle = CreateFrame("Frame", nil, LootFrame, "GwLootFrameTitleTemp")
    GwLootFrameTitle:SetPoint("BOTTOMLEFT", LootFrameBg, "TOPLEFT")
    GwLootFrameTitle.headerString:SetFont(DAMAGE_TEXT_FONT, 14)
    GwLootFrameTitle.headerString:SetTextColor(255 / 255, 241 / 255, 209 / 255)

    local w, _ = LootFrame:GetSize()
    GwLootFrameTitle:SetWidth(w)
    GwLootFrameTitle.BGLEFT:SetWidth(w)
    GwLootFrameTitle.BGRIGHT:SetWidth(w)
    GwLootFrameTitle.headerString:SetWidth(w)

    LootFrame:SetHeight(LootFrame:GetHeight() + LOOT_BUTTON_SHIFT)
    for i = 1, 4 do
        local button = _G["LootButton" .. i]
        local point, relativeTo, relativePoint, x, y = button:GetPoint(1)
        button:ClearAllPoints()
        button:SetPoint(point, relativeTo, relativePoint, x, y - LOOT_BUTTON_SHIFT)
    end

    -- the mover also carries the scale, it is there with loot under the mouse too; its position is unused then.
    -- it keeps the size of the frame with all buttons, whatever the frame does later
    RegisterMovableFrame(LootFrame, BUTTON_LAG_LOOT, "skins.lootFrame", "Blizzard", {LootFrame:GetSize()}, {GW.MoverOption.Scale})
    if GetCVar("lootUnderMouse") == "0" then
        local pos = GW.settings.skins.lootFrame.pos
        LootFrame:ClearAllPoints()
        LootFrame:SetPoint(pos.point, UIParent, pos.relativePoint, pos.xOfs, pos.yOfs)
        hooksecurefunc("LootFrame_Show", function(self)
            LootFrame:ClearAllPoints()
            LootFrame:SetPoint("TOPLEFT", self.gwMover)
        end)
    end

    LootFrameCloseButton:ClearAllPoints()
    LootFrameCloseButton:SetPoint("RIGHT", GwLootFrameTitle.BGRIGHT, "RIGHT", -5, -2)
    LootFrameCloseButton:SetSize(20, 20)
    LootFrameCloseButton:SetNormalTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-normal.png")
    LootFrameCloseButton:SetPushedTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")
    LootFrameCloseButton:SetHighlightTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")

    LootFrameNext:SetFont(UNIT_NAME_FONT, 12)
    LootFramePrev:SetFont(UNIT_NAME_FONT, 12)
    LootFrameNext:SetTextColor(255 / 255, 241 / 255, 209 / 255)
    LootFramePrev:SetTextColor(255 / 255, 241 / 255, 209 / 255)

    LootFrameDownButton:SetNormalTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowdown_up.png")
    LootFrameDownButton:SetPushedTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowdown_up.png")
    LootFrameDownButton:SetHighlightTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowdown_up.png")

    LootFrameUpButton:SetNormalTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowup_down.png")
    LootFrameUpButton:SetPushedTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowup_down.png")
    LootFrameUpButton:SetHighlightTexture("Interface/AddOns/GW2_UI/textures/uistuff/arrowup_down.png")

    for i = 1, 4 do
        _G["LootButton" .. i .. "NameFrame"]:SetTexture("Interface/AddOns/GW2_UI/textures/character/menu-hover.png")
        _G["LootButton" .. i .. "NameFrame"]:SetHeight(_G["LootButton" .. i]:GetHeight())
        _G["LootButton" .. i .. "NameFrame"]:SetPoint("LEFT", _G["LootButton" .. i], "RIGHT", 0, 0)

        _G["LootButton" .. i .. "IconTexture"]:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        _G["LootButton" .. i .. "Text"]:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
    end

    hooksecurefunc("LootFrame_Update", updateLootFrameButtons)
end
GW.LoadLootFrameSkin = LoadLootFrameSkin