---@class GW2
local GW = select(2, ...)

GwObjectivesMonthlyActivitiesBlockMixin = {}

function GwObjectivesMonthlyActivitiesBlockMixin:UpdateBlock(requirements)
    local showCompletedObjectives = GW.settings.objectives.showCompleted
    self.height = GW.GetObjectivesBlockBaseHeight()
    self.numObjectives = 0

    for _, requirement in ipairs(requirements) do
        if not requirement.completed or showCompletedObjectives then
            local criteriaString = requirement.requirementText
            criteriaString = string.gsub(criteriaString, " / ", "/")
            criteriaString = string.gsub(criteriaString, "- ", "")
            self:AddObjective(criteriaString, {isMonthlyActivity = true, finished = requirement.completed, useCompletedLine = showCompletedObjectives})
        end
    end

    for i = (self.numObjectives or 0) + 1, #self.objectiveBlocks do
        self.objectiveBlocks[i]:Hide()
    end

    self:SetHeight(self.height)
end

GwObjectivesMonthlyActivitiesContainerMixin = {}

function GwObjectivesMonthlyActivitiesContainerMixin:UpdateLayout()
    local trackedActivities = C_PerksActivities.GetTrackedPerksActivities().trackedIDs
    local shownIndex = 1

    self.header:Hide()

    if self.collapsed and #trackedActivities > 0 then
        self.header:Show()
        wipe(trackedActivities)
    end

    for i = 1, #trackedActivities do
        local activityID = trackedActivities[i]
        local activityInfo = C_PerksActivities.GetPerksActivityInfo(activityID)

        if activityInfo and not activityInfo.completed then
            local activityName = activityInfo.activityName
			local requirements = activityInfo.requirementsList
            local block = self:GetBlock(shownIndex, GW.Enum.ObjectivesNotificationType.MonthlyActivity, false)
            if block == nil then
                return
            end

            block.id = activityID
            block.title = activityName
            block.Header:SetText(activityName)
            -- criteria
            block:UpdateBlock(requirements)
            block:Show()

            shownIndex = shownIndex + 1

            self.header:Show()
        end
    end

    for i = shownIndex, #self.blocks do
        self.blocks[i]:Hide()
        self.blocks[i].id = nil
    end

    self:LayoutBlocks(shownIndex - 1)

    GwQuestTracker:LayoutChanged()
end

function GwObjectivesMonthlyActivitiesContainerMixin:OnEvent(event, ...)
    if event == "PERKS_ACTIVITIES_TRACKED_UPDATED" or event == "PERKS_ACTIVITIES_TRACKED_LIST_CHANGED" then
        self:UpdateLayout()
    elseif event == "PERKS_ACTIVITY_COMPLETED" then
        local trackedActivities = C_PerksActivities.GetTrackedPerksActivities().trackedIDs
        local perksActivityID = ...
        for i = 1, #trackedActivities do
            local activityID = trackedActivities[i]
            if activityID == perksActivityID then
                PlaySound(SOUNDKIT.TRADING_POST_UI_COMPLETING_ACTIVITIES)
                self:UpdateLayout()
                break
            end
        end
    end
end

function GwObjectivesMonthlyActivitiesContainerMixin:BlockOnClick(button)
    if IsModifiedClick("CHATLINK") and ChatFrameUtil.GetActiveWindow() then
		local perksActivityLink = C_PerksActivities.GetPerksActivityChatLink(self.id)
		ChatFrameUtil.InsertLink(perksActivityLink)
	elseif button ~= "RightButton" then
		if not EncounterJournal then
			EncounterJournal_LoadUI()
		end
		if IsModifiedClick("QUESTWATCHTOGGLE") then
			C_PerksActivities.RemoveTrackedPerksActivity(self.id)
		else
			MonthlyActivitiesFrame_OpenFrameToActivity(self.id)
		end

		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
	else
        MenuUtil.CreateContextMenu(self, function(ownerRegion, rootDescription)
            rootDescription:SetMinimumWidth(1)
            rootDescription:CreateTitle(self.title)
            rootDescription:CreateButton(OBJECTIVES_VIEW_IN_QUESTLOG, function()
                if not EncounterJournal then
                    EncounterJournal_LoadUI()
                end
                MonthlyActivitiesFrame_OpenFrameToActivity(self.id)
            end)
            rootDescription:CreateButton(OBJECTIVES_STOP_TRACKING, function()
                C_PerksActivities.RemoveTrackedPerksActivity(self.id)
            end)
        end)
	end
end

function GwObjectivesMonthlyActivitiesContainerMixin:InitModule()
    self:RegisterEvent("PERKS_ACTIVITIES_TRACKED_UPDATED")
    self:RegisterEvent("PERKS_ACTIVITY_COMPLETED")
    self:RegisterEvent("PERKS_ACTIVITIES_TRACKED_LIST_CHANGED")
    self:SetScript("OnEvent", self.OnEvent)

    self.header = CreateFrame("Button", nil, self, "GwQuestTrackerHeader")
    self.header.icon:SetTexCoord(0.5, 1, 0.75, 1)
    self.header.title:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Header, "SHADOW")
    self.header.title:SetText(TRACKER_HEADER_MONTHLY_ACTIVITIES)

    self.collapsed = false
    self.header:SetScript("OnMouseDown", function() self:ToggleCollapsed() end) -- this way, otherwiese we have a wrong self at the function
    self.header.title:SetTextColor(GW.Colors.ObjectivesTypeColors[GW.Enum.ObjectivesNotificationType.MonthlyActivity]:GetRGB())

    self.blockMixInTemplate = GwObjectivesMonthlyActivitiesBlockMixin

    self:UpdateLayout()
end
