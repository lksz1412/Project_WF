---@class GW2
local GW = select(2, ...)

local function ApplyAlliedRacesUISkin()
    if not GW.settings.skins.alliedRaces.enabled then return end

    AlliedRacesFrame.NineSlice:SetAlpha(0)
    AlliedRacesFramePortrait:SetAlpha(0)
    AlliedRacesFrameBg:SetAlpha(0)
    AlliedRacesFrame.ModelScene:GwStripTextures()
    AlliedRacesFrame.ModelScene:ClearAllPoints()
    AlliedRacesFrame.ModelScene:SetPoint("LEFT", 0, -9)
    AlliedRacesFrame.ModelScene:SetHeight(565)

    select(2, AlliedRacesFrame.ModelScene:GetRegions()):Hide()
    GW.HandleModelSceneControlFrame(AlliedRacesFrame.ModelScene.ControlFrame)

    GW.CreateFrameHeaderWithBody(AlliedRacesFrame, AlliedRacesFrameTitleText, "Interface/AddOns/GW2_UI/textures/icons/auction-window-icon.png", {AlliedRacesFrame.RaceInfoFrame}, nil, false, true)

    AlliedRacesFrame.Banner:Hide()
    AlliedRacesFrame.RaceInfoFrame.tex:ClearAllPoints()
    AlliedRacesFrame.RaceInfoFrame.tex:SetPoint("TOPLEFT", AlliedRacesFrame.RaceInfoFrame, "TOPLEFT", -35, -30)
    AlliedRacesFrame.RaceInfoFrame.tex:SetPoint("BOTTOMRIGHT", AlliedRacesFrame.RaceInfoFrame, "BOTTOMRIGHT", 0, 0)

    AlliedRacesFrameCloseButton:GwSkinButton(true)
    AlliedRacesFrameCloseButton:SetSize(20, 20)

    GW.HandleTrimScrollBar(AlliedRacesFrame.RaceInfoFrame.ScrollFrame.ScrollBar)
    GW.HandleScrollControls(AlliedRacesFrame.RaceInfoFrame.ScrollFrame)

    AlliedRacesFrame.FrameBackground:GwStripTextures()

    AlliedRacesFrame.RaceInfoFrame.ScrollFrame.Child:GwStripTextures()
    AlliedRacesFrame.RaceInfoFrame.ScrollFrame.Child.ObjectivesFrame:GwStripTextures()

    GW.AddDetailsBackground(AlliedRacesFrame.RaceInfoFrame.ScrollFrame.Child.ObjectivesFrame)
    AlliedRacesFrame.RaceInfoFrame.AlliedRacesRaceName:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    AlliedRacesFrame.RaceInfoFrame.ScrollFrame.Child.RaceDescriptionText:SetTextColor(GW.Colors.FallbackWhite:GetRGB())
    AlliedRacesFrame.RaceInfoFrame.ScrollFrame.Child.RacialTraitsLabel:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())

    AlliedRacesFrame:HookScript("OnShow", function(self)
        for button in self.abilityPool:EnumerateActive() do
            select(3, button:GetRegions()):Hide()
            GW.HandleIcon(button.Icon, true)

            button.Text:SetTextColor(GW.Colors.FallbackWhite:GetRGB())
        end
    end)
end


local function LoadAlliedRacesUISkin()
    GW.RegisterLoadHook(ApplyAlliedRacesUISkin, "Blizzard_AlliedRacesUI", AlliedRacesFrame)
end
GW.LoadAlliedRacesUISkin = LoadAlliedRacesUISkin