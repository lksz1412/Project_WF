---@class GW2
local GW = select(2, ...)

local function ApplySoulbindsSkin()
	if not GW.settings.skins.soulbinds.enabled then return end

	SoulbindViewer:GwStripTextures()
	local tex = SoulbindViewer:CreateTexture(nil, "BACKGROUND", nil, -7)
	tex:SetPoint("TOP", SoulbindViewer, "TOP", 0, 25)
	tex:SetTexture("Interface/AddOns/GW2_UI/textures/party/manage-group-bg.png")
	local w, h = SoulbindViewer:GetSize()
	tex:SetSize(w + 50, h + 50)
	SoulbindViewer.tex = tex

	SoulbindViewer.CloseButton:GwSkinButton(true)
	SoulbindViewer.CloseButton:SetSize(20, 20)
	SoulbindViewer.CommitConduitsButton:GwSkinButton(false, true)
	SoulbindViewer.CommitConduitsButton:SetFrameLevel(10)
	SoulbindViewer.ActivateSoulbindButton:GwSkinButton(false, true)
	SoulbindViewer.ActivateSoulbindButton:SetFrameLevel(10)
end

local function LoadSoulbindsSkin()
	GW.RegisterLoadHook(ApplySoulbindsSkin, "Blizzard_Soulbinds", SoulbindViewer)
end
GW.LoadSoulbindsSkin = LoadSoulbindsSkin

