---@class GW2
local GW = select(2, ...)

local function ApplyChromieTimerSkin()
    if not GW.settings.skins.chromieTime.enabled then return end

    ChromieTimeFrame.CloseButton:GwSkinButton(true)
    ChromieTimeFrame.CloseButton:SetSize(20, 20)
    ChromieTimeFrame.SelectButton:GwSkinButton(false, true)

    ChromieTimeFrame:GwStripTextures()
    ChromieTimeFrame.Background:Hide()
    local tex = ChromieTimeFrame:CreateTexture(nil, "BACKGROUND")
    tex:SetPoint("TOP", ChromieTimeFrame, "TOP", 0, 25)
    tex:SetTexture("Interface/AddOns/GW2_UI/textures/party/manage-group-bg.png")
    local w, h = ChromieTimeFrame:GetSize()
    tex:SetSize(w + 50, h + 50)
    ChromieTimeFrame.tex = tex

    local Title = ChromieTimeFrame.Title
    Title:DisableDrawLayer("BACKGROUND")
    Title:GwCreateBackdrop(GW.BackdropTemplates.Default, true)

    local InfoFrame = ChromieTimeFrame.CurrentlySelectedExpansionInfoFrame
    InfoFrame:DisableDrawLayer("BACKGROUND")
    InfoFrame:GwCreateBackdrop(GW.BackdropTemplates.Default, true)
    InfoFrame.Name:SetTextColor(1, 0.8, 0)
    InfoFrame.Description:SetTextColor(GW.Colors.FallbackWhite:GetRGB())
end

local function LoadChromieTimerSkin()
    GW.RegisterLoadHook(ApplyChromieTimerSkin, "Blizzard_ChromieTimeUI", ChromieTimeFrame)
end
GW.LoadChromieTimerSkin = LoadChromieTimerSkin