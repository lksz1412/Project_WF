---@class GW2
local GW = select(2, ...)

local function SkinRewards()
    for reward in AdventureMapQuestChoiceDialog.rewardPool:EnumerateActive() do
        if not reward.gwSkinned then
            reward.ItemNameBG:GwStripTextures()
            reward.ItemNameBG:GwCreateBackdrop(GW.BackdropTemplates.DefaultWithSmallBorder, true)


            GW.HandleItemButton(reward)
            GW.HandleIcon(reward.Icon)
            reward.Icon:SetDrawLayer('OVERLAY')

        end
    end
end

local function ApplyAdventureMapSkin()
    if not GW.settings.skins.adventureMap.enabled then return end

    --Quest Choise
    AdventureMapQuestChoiceDialog:GwStripTextures()
    AdventureMapQuestChoiceDialog:GwCreateBackdrop(GW.BackdropTemplates.Default, true)
    -- Rewards
    hooksecurefunc(AdventureMapQuestChoiceDialog, 'RefreshRewards', SkinRewards)
    -- Quick Fix for the Font Color
    AdventureMapQuestChoiceDialog.Details.Child.TitleHeader:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    AdventureMapQuestChoiceDialog.Details.Child.DescriptionText:SetTextColor(GW.Colors.FallbackWhite:GetRGB())
    AdventureMapQuestChoiceDialog.Details.Child.ObjectivesHeader:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    AdventureMapQuestChoiceDialog.Details.Child.ObjectivesText:SetTextColor(GW.Colors.FallbackWhite:GetRGB())
    --Buttons
    GW.HandleTrimScrollBar(AdventureMapQuestChoiceDialog.Details.ScrollBar)
    GW.HandleScrollControls(AdventureMapQuestChoiceDialog.Details)
    AdventureMapQuestChoiceDialog.CloseButton:GwSkinButton(true)
    AdventureMapQuestChoiceDialog.AcceptButton:GwSkinButton(false, true)
    AdventureMapQuestChoiceDialog.DeclineButton:GwSkinButton(false, true)
end

local function LoadAdventureMapSkin()
    GW.RegisterLoadHook(ApplyAdventureMapSkin, "Blizzard_AdventureMap", AdventureMapQuestChoiceDialog)
end
GW.LoadAdventureMapSkin = LoadAdventureMapSkin