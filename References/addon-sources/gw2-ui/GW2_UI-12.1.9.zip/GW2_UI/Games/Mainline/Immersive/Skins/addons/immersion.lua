---@class GW2
local GW = select(2, ...)

local function LoadImmersionAddonSkin()
    if not GW.settings.skins.immersion.enabled then return end

    local ImmersionFrame = _G.ImmersionFrame

    if ImmersionFrame then
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetNormalTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-normal.png")
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetHighlightTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetPushedTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-hover.png")
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetDisabledTexture("Interface/AddOns/GW2_UI/textures/uistuff/window-close-button-normal.png")
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetSize(25, 25)
        ImmersionFrame.TalkBox.MainFrame.CloseButton:ClearAllPoints()
        ImmersionFrame.TalkBox.MainFrame.CloseButton:SetPoint("TOPRIGHT", -30, -8)

        ImmersionFrame.TalkBox.BackgroundFrame.TextBackground:SetTexture("Interface/AddOns/GW2_UI/textures/party/manage-group-bg.png")

        ImmersionFrame.TalkBox.Hilite:Hide()

        ImmersionFrame.TalkBox.MainFrame.Indicator:SetPoint("TOPRIGHT", -56, -13)
    end
end
GW.LoadImmersionAddonSkin = LoadImmersionAddonSkin