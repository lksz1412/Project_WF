---@class GW2
local GW = select(2, ...)
local GWGetClassColor = GW.GWGetClassColor
local HeroPanel = GW.HeroPanel
local petStateSprite = HeroPanel.petStateSprite
local statTiles = HeroPanel.statTiles
local setStatFrame = HeroPanel.SetStatFrame
local setPetStatFrame = HeroPanel.SetPetStatFrame
local PaperDollSlotButton_Update = HeroPanel.SlotButton_Update

local TOGGLE_PANELS = {
    PaperDollFrame = {"GwHeroPanelMenu", "paperdoll"},
    ReputationFrame = {"GwPaperReputation", "reputation"},
    SkillFrame = {"GwPaperSkills", "paperdollskills"},
    PetPaperDollFrame = {"GwPetContainer", "paperdollpet"},
}

local function PaperDollStats_QueuedUpdate(self)
    self:SetScript("OnUpdate", nil)
    GW.PaperDollUpdateStats(self:GetParent())
end

local function PaperDollUpdateUnitData(dressingRoom)
    dressingRoom.characterName:SetText(UnitPVPName("player"))
    local _, name = C_SpecializationInfo.GetSpecializationInfo(GW.myspec)
    local color = GWGetClassColor(GW.myclass, true)
    GW.SetClassIcon(dressingRoom.classIcon, GW.myclass)

    dressingRoom.classIcon:SetVertexColor(color.r, color.g, color.b, color.a)

    if name ~= nil then
        local data = GUILD_RECRUITMENT_LEVEL .. " " .. GW.mylevel .. " " .. name .. " " .. GW.myLocalizedClass
        dressingRoom.characterData:SetText(data)
    else
        dressingRoom.characterData:SetFormattedText(PLAYER_LEVEL, GW.mylevel, GW.myLocalizedRace, GW.myLocalizedClass)
    end
end

local function PaperDollPetStats_OnEvent(self, event, ...)
    if InCombatLockdown() then
        self:RegisterEvent("PLAYER_REGEN_ENABLED")
        self.prevEvent = event
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        event = self.prevEvent
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
    end

    local unit = ...
    if event == "PET_UI_UPDATE" or event == "PET_BAR_UPDATE" or (event == "UNIT_PET" and unit == "player") then
        if GwPetContainer:IsVisible() and not HasPetUI() then
            GwCharacterWindow:SetAttribute("windowpanelopen", "paperdoll")
            GwHeroPanelMenu.petMenu:Disable()
            return
        end
    elseif event == "PET_UI_CLOSE" then
        if GwPetContainer:IsVisible() then
            GwCharacterWindow:SetAttribute("windowpanelopen", "paperdoll")
            GwHeroPanelMenu.petMenu:Disable()
            return
        end
    end
    GW.PaperDollUpdatePetStats(self:GetParent())
end

local function PaperDollStats_OnEvent(self, event, ...)
    local unit = ...
    local parent = self:GetParent()
    if event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_PVP_RANK_CHANGED" or ((event == "UNIT_MODEL_CHANGED" or event == "UNIT_NAME_UPDATE") and unit == "player") then
        parent.model:SetUnit("player", false)
        PaperDollUpdateUnitData(parent)
        return
    end

    if unit == "player" then
        if event == "UNIT_LEVEL" then
            PaperDollUpdateUnitData(parent)
        elseif event == "UNIT_DAMAGE" or
                event == "UNIT_ATTACK_SPEED" or
                event == "UNIT_RANGEDDAMAGE" or
                event == "UNIT_ATTACK" or
                event == "UNIT_STATS" or
                event == "UNIT_RANGED_ATTACK_POWER" or
                event == "UNIT_SPELL_HASTE" or
                event == "UNIT_MAXHEALTH" or
                event == "UNIT_AURA" or
                event == "UNIT_RESISTANCES" or
                event == "UPDATE_INVENTORY_ALERTS" or
                IsMounted() then
            self:SetScript("OnUpdate", PaperDollStats_QueuedUpdate)
        end
    end

    if event == "COMBAT_RATING_UPDATE" or
            event == "SPEED_UPDATE" or
            event == "LIFESTEAL_UPDATE" or
            event == "AVOIDANCE_UPDATE" or
            event == "BAG_UPDATE" or
            event == "PLAYER_EQUIPMENT_CHANGED" or
            event == "PLAYERBANKSLOTS_CHANGED" or
            event == "PLAYER_AVG_ITEM_LEVEL_UPDATE" or
            event == "PLAYER_DAMAGE_DONE_MODS" or
            IsMounted() then
        self:SetScript("OnUpdate", PaperDollStats_QueuedUpdate)
    elseif event == "PLAYER_TALENT_UPDATE" then
        PaperDollUpdateUnitData(parent)
        self:SetScript("OnUpdate", PaperDollStats_QueuedUpdate)
    elseif event == "ACTIVE_TALENT_GROUP_CHANGED" then
        GW.PaperDollUpdateStats(parent)
    elseif event == "SPELL_POWER_CHANGED" then
        self:SetScript("OnUpdate", PaperDollStats_QueuedUpdate)
    end
end

local function PaperDollUpdateStats(dressingRoom)
    wipe(statTiles)
    HeroPanel.UpdateItemLevel()
    local statText, tooltip1, tooltip2

    local numShownStats = 1
    local grid = 1
    local x = 0
    local y = 0

    for primaryStatIndex = 1, 5 do
        _, statText, tooltip1, tooltip2 = GW.stats.getPrimary(primaryStatIndex)
        grid, x, y, numShownStats = setStatFrame(GW.stats.PRIMARY_STATS[primaryStatIndex], numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    -- Armor
    statText, tooltip1, tooltip2 = GW.stats.getArmor()
    grid, x, y, numShownStats = setStatFrame("ARMOR", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    -- Defense only for Tanksclasses
    if GW.myClassID == 1 or GW.myClassID == 2 or GW.myClassID == 11 then
        statText, tooltip1, tooltip2 = GW.stats.getDefense()
        grid, x, y, numShownStats = setStatFrame("DEFENSE", numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    --damage
    statText, tooltip1, tooltip2 = GW.stats.getDamage()
    grid, x, y, numShownStats = setStatFrame("DAMAGE", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    --attack power
    statText, tooltip1, tooltip2 = GW.stats.getAttackPower()
    grid, x, y, numShownStats = setStatFrame("ATTACKPOWER", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    --ranged damage
    statText, tooltip1, tooltip2 = GW.stats.getRangedDamage()
    if statText then
        grid, x, y, numShownStats = setStatFrame("RANGEDDAMAGE", numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    --ranged attack power
    if statText then
        statText, tooltip1, tooltip2 = GW.stats.getRangedAttackPower()
        grid, x, y, numShownStats = setStatFrame("RANGEDATTACKPOWER", numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    --resitance
    for resistanceIndex = 2, 6 do
        _, statText, tooltip1, tooltip2 = GW.stats.getResitance(resistanceIndex)
        grid, x, y, numShownStats = setStatFrame(GW.stats.RESITANCE_STATS[resistanceIndex], numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    --durability
    grid, x, y, numShownStats = setStatFrame("DURABILITY", numShownStats, "DURABILITY", nil, nil, grid, x, y)

    GW.StatsPicker.Layout(dressingRoom.stats, statTiles, 30)
end
GW.PaperDollUpdateStats = PaperDollUpdateStats

local function PaperDollUpdatePetStats(dressingRoomPet)
    local hasUI, isHunterPet = HasPetUI()
    local statText, tooltip1, tooltip2
    if not hasUI then return end

    local numShownStats = 1
    local grid = 1
    local x = 0
    local y = 0

    dressingRoomPet.model:SetUnit("pet")
    if UnitCreatureFamily("pet") then
		dressingRoomPet.characterName:SetText((UnitName("pet") or "") .. " - " .. format(UNIT_LEVEL_TEMPLATE, (UnitLevel("pet") or ""), "") .. " " .. (UnitCreatureFamily("pet") or ""))
	else
        dressingRoomPet.characterName:SetText((UnitName("pet") or "") .. " - " .. format(UNIT_LEVEL_TEMPLATE, (UnitLevel("pet") or ""), ""))
    end

    if isHunterPet then
        local happiness = GetPetHappiness()
        local totalPoints, spent = GetPetTrainingPoints()
        local currXP, nextXP = GetPetExperience()

        dressingRoomPet.model.expBar:SetMinMaxValues(min(0, currXP), nextXP)
        dressingRoomPet.model.expBar:SetValue(currXP)
        dressingRoomPet.model.expBar.value:SetText(GW.CommaValue(currXP) .. " / " .. GW.CommaValue(nextXP) .. " - " .. math.floor(currXP / nextXP * 100) .. "%")
        dressingRoomPet.classIcon:SetTexCoord(GW.getSprite(petStateSprite, happiness, 1))
        dressingRoomPet.itemLevel:SetText(totalPoints - spent)
        dressingRoomPet.characterData:SetText(GetPetLoyalty())
        dressingRoomPet.characterData:Show()
        dressingRoomPet.itemLevel:Show()
        dressingRoomPet.itemLevelLabel:Show()
        dressingRoomPet.classIcon:Show()
        dressingRoomPet.model.expBar:Show()
        dressingRoomPet.model:SetPosition(-2,0,-0.5)
        dressingRoomPet.model:SetRotation(-0.15)

        dressingRoomPet.happiness:Show()
    else
        dressingRoomPet.model.expBar:Hide()
        dressingRoomPet.characterData:Hide()
        dressingRoomPet.itemLevel:Hide()
        dressingRoomPet.itemLevelLabel:Hide()
        dressingRoomPet.classIcon:Hide()
        dressingRoomPet.model:SetPortraitZoom(-0.8)
        dressingRoomPet.model.zoomLevel = -0.8
        dressingRoomPet.model:SetRotation(0.5)
    end

    for primaryStatIndex = 1, 5 do
        _, statText, tooltip1, tooltip2 = GW.stats.getPrimary(primaryStatIndex, "pet")
        grid, x, y, numShownStats = setPetStatFrame(GW.stats.PRIMARY_STATS[primaryStatIndex], numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end

    statText, tooltip1, tooltip2 = GW.stats.getAttackPower("pet")
    grid, x, y, numShownStats = setPetStatFrame("ATTACKPOWER", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    statText, tooltip1, tooltip2 = GW.stats.getDamage("pet")
    grid, x, y, numShownStats = setPetStatFrame("DAMAGE", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    statText, tooltip1, tooltip2 = GW.stats.getArmor("pet")
    grid, x, y, numShownStats = setPetStatFrame("ARMOR", numShownStats, statText, tooltip1, tooltip2, grid, x, y)

    for resistanceIndex = 2, 6 do
        _, statText, tooltip1, tooltip2 = GW.stats.getResitance(resistanceIndex, "pet")
        grid, x, y, numShownStats = setPetStatFrame(GW.stats.RESITANCE_STATS[resistanceIndex], numShownStats, statText, tooltip1, tooltip2, grid, x, y)
    end
end
GW.PaperDollUpdatePetStats = PaperDollUpdatePetStats

local function LoadPVPTab(container)
    PVPFrame.Hide = PVPFrame.Show
    PVPFrame:Show()
    PVPFrame:SetParent(container)
    PVPFrame:ClearAllPoints()
    PVPFrame:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
    PVPFrame:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 8)

    PVPFrameBackground:ClearAllPoints()
    PVPFrameBackground:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
    PVPFrameBackground:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 8)

    PVPFrame:GwStripTextures(true)

    PVPFrameHonorLabel:ClearAllPoints()
    PVPFrameHonorLabel:SetPoint("TOP", PVPFrameBackground, "TOP", 0, -10)
    PVPFrameHonorLabel:SetFont(UNIT_NAME_FONT, 14)
    PVPFrameHonorPoints:SetFont(UNIT_NAME_FONT, 14)

    PVPFrameArenaLabel:ClearAllPoints()
    PVPFrameArenaLabel:SetPoint("TOP", PVPFrameBackground, "TOP", 0, -130)
    PVPFrameArenaLabel:SetFont(UNIT_NAME_FONT, 14)
    PVPFrameArenaPoints:SetFont(UNIT_NAME_FONT, 14)

    PVPHonor:ClearAllPoints()
    PVPHonor:SetPoint("TOP", PVPFrameBackground, "TOP", 0, -35)

    PVPHonorKillsLabel:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorTodayLabel:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorTodayKills:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorYesterdayLabel:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorYesterdayKills:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorLifetimeLabel:SetFont(STANDARD_TEXT_FONT, 14)
    PVPHonorLifetimeKills:SetFont(STANDARD_TEXT_FONT, 14)

    PVPTeam1Standard:ClearAllPoints()
    PVPTeam1Standard:SetPoint("LEFT", PVPFrameBackground, "LEFT", 150, 90)

    PVPTeam2Standard:ClearAllPoints()
    PVPTeam2Standard:SetPoint("LEFT", PVPFrameBackground, "LEFT", 150, 0)

    PVPTeam3Standard:ClearAllPoints()
    PVPTeam3Standard:SetPoint("LEFT", PVPFrameBackground, "LEFT", 150, -90)
end

local function LoadPaperDoll(tabContainer)
    local dressingRoom = CreateFrame("Button", "GwDressingRoom", tabContainer, "GwDressingRoom")
    GW.HandleModelControlFrame(dressingRoom.model.controlFrame)
    local heroPanelMenu = CreateFrame("Frame", "GwHeroPanelMenu", tabContainer, "GwCharacterMenuFilledTemplate")
    local honorFrame = CreateFrame("Frame", "GwPaperHonor", tabContainer, "GwPaperHonor")

    --Legacy pet window
    local petContainer = CreateFrame("Frame", "GwPetContainer", tabContainer, "GwPetContainer")
    local dressingRoomPet = CreateFrame("Button", "GwDressingRoomPet", petContainer, "GwPetPaperdoll")

    GwCharacterWindow:SetHeroPanelMenu(heroPanelMenu)

    dressingRoom.stats:SetScript("OnEvent", PaperDollStats_OnEvent)
    for _, event in ipairs({"PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED"}) do
        if C_EventUtils.IsEventValid(event) then
            dressingRoom.stats:RegisterEvent(event)
        end
    end
    dressingRoomPet.stats:SetScript("OnEvent", PaperDollPetStats_OnEvent)

    heroPanelMenu.SetupBackButton = HeroPanel.SetupBackButton

    HeroPanel.SetupSlots(dressingRoom)

    HeroPanel.HookSlotUpdate("Interface/AddOns/GW2_UI/textures/character/slot-bg-classic.png", true, PaperDollSlotButton_Update)

    GW.SetPaperDollModelPosition(dressingRoom.model)

    CharacterFrame:UnregisterAllEvents()
    HeroPanel.HookToggleCharacter(TOGGLE_PANELS)

    HeroPanel.SetupFonts(dressingRoom, dressingRoomPet)

    GW.StatsPicker.Setup(dressingRoom.stats, dressingRoom, function() PaperDollUpdateStats(dressingRoom) end)
    PaperDollUpdateStats(dressingRoom)
    PaperDollUpdatePetStats(dressingRoomPet)

    local titelFrame = GW.LoadPDTitles(tabContainer, heroPanelMenu)
    local skillsFrame = GW.LoadPDSkills(tabContainer, heroPanelMenu)
    LoadPVPTab(honorFrame)
    heroPanelMenu:SetupBackButton(honorFrame.backButton, CHARACTER .. ": " .. HONOR)
    heroPanelMenu:SetupBackButton(dressingRoomPet.backButton, CHARACTER .. ": " .. PET)

    HeroPanel.SetupAdvancedStatsButton(dressingRoom)

    -- Secure stuff
    GW.CharacterMenuButton_OnLoad(heroPanelMenu.skillsMenu, true, true)
    GW.CharacterMenuButton_OnLoad(heroPanelMenu.titleMenu, false, true)
    GW.CharacterMenuButton_OnLoad(heroPanelMenu.honorMenu, true, true)
    GW.CharacterMenuButton_OnLoad(heroPanelMenu.petMenu, false, true)
    GW.SetCharacterWindowOpenAttribute(heroPanelMenu.skillsMenu, "paperdollskills")
    GW.SetCharacterWindowOpenAttribute(heroPanelMenu.titleMenu, "titles")
    GW.SetCharacterWindowOpenAttribute(heroPanelMenu.honorMenu, "paperdollhonor")
    GW.SetCharacterWindowOpenAttribute(heroPanelMenu.petMenu, "paperdollpet")

    GwCharacterWindow:SetFrameRef("GwHeroPanelMenu", heroPanelMenu)
    GwCharacterWindow:SetFrameRef("GwPaperDollTitles", titelFrame)
    GwCharacterWindow:SetFrameRef("GwPaperHonor", honorFrame)
    GwCharacterWindow:SetFrameRef("GwPaperSkills", skillsFrame)
    GwCharacterWindow:SetFrameRef("GwDressingRoom", dressingRoom)
    GwCharacterWindow:SetFrameRef("GwPetContainer", petContainer)

    -- add addon buttons here
    GwCharacterWindow:SetAttribute("myClassId", GW.myClassID)
    GwCharacterWindow:SetNextAddonMenuButtonShadowState(GW.myClassID == 3 or GW.myClassID == 9 or GW.myClassID == 6)
    GwCharacterWindow:SetNextAddonMenuButtonAnchor((GW.myClassID == 3 or GW.myClassID == 9 or GW.myClassID == 6) and heroPanelMenu.petMenu or heroPanelMenu.honorMenu)
    HeroPanel.AddAddonButtons(heroPanelMenu)

    -- pet GwDressingRoom
    HeroPanel.SetupPetMenuDriver(heroPanelMenu)

    HeroPanel.KeepCharacterFrameHidden()
end
GW.LoadPaperDoll = LoadPaperDoll
