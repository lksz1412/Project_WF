---@class GW2
local GW = select(2, ...)

local function Construct_SummonIcon(frame)
    local summonIcon = frame.RaisedElementParent.TextureParent:CreateTexture(nil, "ARTWORK")
	summonIcon:SetSize(25, 25)
	summonIcon:SetPoint('CENTER', frame, 'CENTER')

	return summonIcon
end
GW.Construct_SummonIcon = Construct_SummonIcon
