---@class GW2
local GW = select(2, ...)
local L = GW.L

local function LoadSlashCommands()
    SLASH_GWSLASH1 = "/gw2"
    function SlashCmdList.GWSLASH(msg)
        if msg == "" then
            GW.Notice(L["Slash commands:"])
            GW.Notice(L["  /gw2 settings       -> Open the settings window"])
            GW.Notice(L["  /gw2 reset windows  -> Reset the inventory and hero panel windows"])
            GW.Notice(L["  /gw2 status         -> Show the GW2 status window"])
            GW.Notice(L["  /gw2 kb             -> Activate keybind mode"])
            GW.Notice(L["  /gw2 mh             -> Activate Move HUD mode"])
            GW.Notice(L["  /gw2 reset profile  -> Reset the current profile to default settings"])
            -- only the commands this client has
            if C_ContentTracking then
                GW.Notice(L["  /gw2 clear achievements  -> Untrack all earned achievements (Blizzard bug)"])
            end
            GW.Notice(L["  /gw2 error          -> Show the GW2 error log"])
            GW.Notice(L["  /gw2 test error     -> Raise a test error to check the error log"])
            GW.Notice(L["  /gw2 test lootroll  -> Show test loot roll bars"])
            if GW.Retail or GW.Mists then
                GW.Notice(L["  /gw2 test mythicplus -> Toggle a test Mythic+ timer in the quest tracker"])
            end
            if not (GW.Classic or GW.TBC) then
                GW.Notice(L["  /gw2 test bossframes -> Toggle test boss frames in the quest tracker"])
            end
            if not GW.Classic then
                GW.Notice(L["  /gw2 test arenaframes -> Toggle test arena frames in the quest tracker"])
            end
        elseif msg == "settings" then
            if InCombatLockdown() then
                GW.Notice(L["Settings are not available in combat!"])
                return
            end
            GwSettingsWindow:Show()
            --UIFrameFadeIn(GwSettingsWindow, 0.2, 0, 1)
        elseif msg == "reset windows" then
            GW.settings.bags.bag.pos = nil
            GW.settings.bags.bank.pos = nil
            GW.settings.windows.character.pos = nil
            GW.settings.skins.mail.pos = nil
            GW.settings.skins.guildBank.pos = nil
            C_UI.Reload()
        elseif msg == "status" then
            GW.ShowStatusReport()
        elseif msg == "kb" then
            if InCombatLockdown() then
                GW.Notice(L["Settings are not available in combat!"])
                return
            end
            GW.DisplayHoverBinding()
        elseif msg == "mh" then
            if InCombatLockdown() then
                GW.Notice(L["You cannot move elements during combat!"])
                return
            end
            if GW.MoveHudScaleableFrame:IsShown() then
                GW.lockHudObjects(GW.MoveHudScaleableFrame)
            else
                GW.moveHudObjects(GW.MoveHudScaleableFrame)
            end
        elseif msg == "reset profile" then
            if InCombatLockdown() then
                GW.Notice(L["Settings are not available in combat!"])
                return
            end
            GW.ShowPopup({text =  GW.L["Are you sure you want to load the default settings?\n\nAll previous settings will be lost."],
                OnAccept = function() GW.ResetToDefault(); C_UI.Reload() end}
            )
        elseif msg == "error" then
            Gw2ErrorLog:Toggle()
        elseif msg == "test error" then
            GW.TestErrorHandler()
        elseif msg == "test lootroll" then
            GW.TestLootRolls()
        elseif msg == "test mythicplus" and (GW.Retail or GW.Mists) then
            if GW.TestMythicPlusTimer then GW.TestMythicPlusTimer() end
        elseif msg == "test bossframes" and not (GW.Classic or GW.TBC) then
            if GW.ToggleBossFramesTest then GW.ToggleBossFramesTest() end
        elseif msg == "test arenaframes" and not GW.Classic then
            if GW.ToggleArenaFramesTest then GW.ToggleArenaFramesTest() end
        elseif msg == "clear achievements" and C_ContentTracking then
            local trackedAchievements = C_ContentTracking.GetTrackedIDs(Enum.ContentTrackingType.Achievement)
            local numAchievements = #trackedAchievements
            local counter = 0

            for i = 1, numAchievements do
                local achievementID = trackedAchievements[i]
                local achievementName = select(2, GetAchievementInfo(achievementID))
                local wasEarnedByMe = select(13, GetAchievementInfo(achievementID))

                if wasEarnedByMe then
                    C_ContentTracking.StopTracking(Enum.ContentTrackingType.Achievement, achievementID, Enum.ContentTrackingStopType.Manual)
                    GW.Notice(format(L["Untracked Achievement '%s (%s)'"], achievementName, achievementID))

                    counter = counter + 1
                end
            end
            GW.Notice(format(L["%s Achievements cleared"], counter))
        else
            GW.Notice("\"" .. msg .. "\" is not a valid GW2 UI slash command.")
        end
    end

    -- /tt whispers the target, without a message it opens the whisper to it
    SLASH_GWTELLTARGET1 = "/tt"
    function SlashCmdList.GWTELLTARGET(msg)
        if not UnitIsPlayer("target") then return end
        local name, realm = UnitName("target")
        if GW.IsSecretValue(name) or not name then return end
        if realm and realm ~= "" then
            name = name .. "-" .. realm
        end
        msg = strtrim(msg or "")
        if msg == "" then
            ChatFrameUtil.OpenChat("/w " .. name .. " ")
        else
            C_ChatInfo.SendChatMessage(msg, "WHISPER", nil, name)
        end
    end
end
GW.LoadSlashCommands = LoadSlashCommands
