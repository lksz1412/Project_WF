---@class GW2
local GW = select(2, ...)

function GW:FixBlizzardIssues()
    -- classic dialogs with a wide edit box (friend and guild notes) add to their last width on every show
    if not GW.isModern then
        for i = 1, 4 do
            _G["StaticPopup" .. i]:HookScript("OnHide", function(popup) popup:SetWidth(320) end)
        end
    end

    if self.settings.general.fixGuildNewsSpam then
        -- https://nga.178.com/read.php?tid=42399961
        local newsRequireUpdate, newsTimer
        CommunitiesFrameGuildDetailsFrameNews:SetScript("OnEvent", function(frame, event)
            if event == "GUILD_NEWS_UPDATE" then
                if newsTimer then
                    newsRequireUpdate = true
                else
                    CommunitiesGuildNewsFrame_OnEvent(frame, event)

                    -- After 1 second, if guild news still need to be updated, update again
                    newsTimer = C_Timer.NewTimer(1, function()
                        if newsRequireUpdate then
                            CommunitiesGuildNewsFrame_OnEvent(frame, event)
                        end
                        newsRequireUpdate = false
                        newsTimer = nil
                    end)
                end
            else
                CommunitiesGuildNewsFrame_OnEvent(frame, event)
            end
        end)
    end
end
