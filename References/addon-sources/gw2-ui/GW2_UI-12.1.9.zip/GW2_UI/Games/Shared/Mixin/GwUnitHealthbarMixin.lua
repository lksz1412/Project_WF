---@class GW2
local GW = select(2, ...)

GwUnitHealthbarMixin = {}

-- The classic clients resolve unit data asynchronously
local HEALTH_RETRY_INTERVAL = 0.1
local HEALTH_RETRY_LIMIT = 10

local function HasNoHealthData(unit, health, healthMax)
    if not unit or not UnitExists(unit) then return false end
    if healthMax <= 0 then return true end
    -- a unit at 0 health is dead; alive and 0 means the value has not arrived yet
    return health <= 0 and not UnitIsDeadOrGhost(unit)
end

function GwUnitHealthbarMixin:ScheduleHealthDataRetry(forceUpdate)
    if self.gwHealthRetryPending then return end

    local retries = (self.gwHealthRetries or 0) + 1
    if retries > HEALTH_RETRY_LIMIT then return end
    self.gwHealthRetries = retries

    local unit = self.gwUnit
    self.gwHealthRetryPending = true
    C_Timer.After(HEALTH_RETRY_INTERVAL, function()
        self.gwHealthRetryPending = nil
        -- the frame may have been pointed at a different unit in the meantime
        if self.gwUnit == unit and UnitExists(unit) then
            self:UpdateHealthBar(forceUpdate)
        end
    end)
end

function GwUnitHealthbarMixin:UpdateHealthBar(forceUpdate)
    if GW.isModern then
        local statusBarAnimation = forceUpdate and Enum.StatusBarInterpolation.Immediate or Enum.StatusBarInterpolation.ExponentialEaseOut
        local unit = self.gwUnit
        local healthMax = UnitHealthMax(unit)
        local health = healthMax
        if UnitIsConnected(unit) then
            health = UnitHealth(unit)
        end

        UnitGetDetailedHealPrediction(unit, nil, self.hpValues)
        local allHeal = self.hpValues:GetIncomingHeals()
        local damageAbsorbAmount, damageAbsorbClamped = self.hpValues:GetDamageAbsorbs()
        local healAbsorbAmount = self.hpValues:GetHealAbsorbs()

        if self.healPrediction then
            self.healPrediction:SetMinMaxValues(0, healthMax)
            self.healPrediction:SetValue(allHeal, Enum.StatusBarInterpolation.ExponentialEaseOut)
        end

        self.health:SetMinMaxValues(0, healthMax)
        self.health:SetValue(health, statusBarAnimation)

        if self.absorbbg then
            self.absorbbg:SetMinMaxValues(0, healthMax)
            self.absorbbg:SetValue(damageAbsorbAmount, statusBarAnimation)
        end
        if self.absorbOverlay then self.absorbOverlay:SetAlphaFromBoolean(damageAbsorbClamped, 1, 0) end
        if self.antiHeal then
            self.antiHeal:SetMinMaxValues(0, healthMax)
            self.antiHeal:SetValue(healAbsorbAmount, statusBarAnimation)
        end
    else
        local unit = self.gwUnit
        local healthMax = UnitHealthMax(unit)
        local health = UnitIsConnected(unit) and UnitHealth(unit) or healthMax

        if HasNoHealthData(unit, health, healthMax) then
            self:ScheduleHealthDataRetry(forceUpdate)
        else
            self.gwHealthRetries = nil
        end

        local absorb = (self.showAbsorbBar and UnitGetTotalAbsorbs and UnitGetTotalAbsorbs(unit)) or 0
        local prediction = UnitGetIncomingHeals(unit) or 0
        local healAbsorb = UnitGetTotalHealAbsorbs and UnitGetTotalHealAbsorbs(unit) or 0

        local healthPrecentage = (healthMax > 0) and (health / healthMax) or 0
        local absorbPrecentage = (absorb > 0 and healthMax > 0) and (absorb / healthMax) or 0
        local absorbAmount = absorb > 0 and (healthPrecentage + absorbPrecentage) or 0
        local absorbAmount2 = absorb > 0 and (absorbPrecentage - (1 - healthPrecentage)) or 0
        local predictionPrecentage = (prediction > 0 and healthMax > 0) and math.min(1, healthPrecentage + (prediction / healthMax)) or 0
        local healAbsorbPrecentage = (healAbsorb > 0 and healthMax > 0) and math.min(1, healAbsorb / healthMax) or 0

        if self.healPrediction then
            self.healPrediction:SetFillAmount(predictionPrecentage)
        end

        if forceUpdate then
            self.health:ForceFillAmount(healthPrecentage)
            if self.absorbbg then self.absorbbg:ForceFillAmount(absorbAmount) end
            if self.absorbOverlay then self.absorbOverlay:ForceFillAmount(absorbAmount2) end
            if self.antiHeal then self.antiHeal:ForceFillAmount(healAbsorbPrecentage) end
        else
            self.health:SetFillAmount(healthPrecentage)
            if self.absorbbg then self.absorbbg:SetFillAmount(absorbAmount) end
            if self.absorbOverlay then self.absorbOverlay:SetFillAmount(absorbAmount2) end
            if self.antiHeal then self.antiHeal:SetFillAmount(healAbsorbPrecentage) end
        end
    end
end
