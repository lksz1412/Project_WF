---@class GW2
local GW = select(2, ...)

--[[
    Own container item buttons.

    Replaces taking blizzards multi purpose ContainerFrameXItemY buttons, which fights with
    blizzards own layout and update code (anchor family errors, frame rotation, relayouts).
    The buttons inherit ContainerFrameItemButtonTemplate, so all click/drag/use/split/tooltip
    behavior keeps working through the inherited handlers, driven by the parents bag id
    (container:SetID) and the buttons slot id (button:SetID) - the same mechanism the taken
    buttons relied on. Only the content updates are done here via the C_Container api,
    mirroring blizzards ContainerFrame_Update.

    The buttons are stored in cf.gw_items with cf.gw_num_slots, so the existing layout code
    (layoutContainerFrame) keeps working unchanged. Like blizzards buttons, gw_items[1] gets
    the highest slot id, since the layout iterates the list backwards.
]]

local allItemButtons = {}

-- the modern clients only carry the keyring id in the enum, the classic ones also as global
local KEYRING_CONTAINER = (Enum.BagIndex and Enum.BagIndex.Keyring) or KEYRING_CONTAINER or -2

-- the skin repurposes the templates quest texture as our own quest icon on every
-- flavor (the retail default), the content update here only toggles it

-- blizzards cooldown helper only exists on the classic flavors
local function updateCooldown(bagID, button)
    if ContainerFrame_UpdateCooldown then
        ContainerFrame_UpdateCooldown(bagID, button)
    else
        local cooldown = button.cooldown
        if not cooldown then
            return
        end
        local start, duration, enable = C_Container.GetContainerItemCooldown(bagID, button:GetID())
        CooldownFrame_Set(cooldown, start, duration, enable)
        if duration > 0 and enable == 0 then
            SetItemButtonTextureVertexColor(button, 0.4, 0.4, 0.4)
        else
            SetItemButtonTextureVertexColor(button, 1, 1, 1)
        end
    end
    -- both paths (blizzards helper and the fallback above) reset the icon color to
    -- white, wiping the unusable tint the quality skin applied - put it back on top
    GW.ReapplyBagItemUnusableTint(button)
end

local function GetQuestTexture(button)
    if button.IconQuestTexture == nil then
        button.IconQuestTexture = _G[button:GetName() .. "IconQuestTexture"] or false
    end
    return button.IconQuestTexture
end

-- Everything the update below writes is derived from these fields, so an unchanged set means
-- every setter would write the value the button already holds. Remembering them per button lets
-- a bag event that changed a single stack skip the other slots instead of reskinning all of them
-- (the quality setter alone pulls the whole bag skin behind it). Returns true when the slot has
-- to be written and stores the new state in that case.
local function TakeSlotState(button, info)
    local itemID, count, quality, locked, filtered, readable, noValue, link
    if info then
        itemID, count, quality = info.itemID, info.stackCount, info.quality
        locked, filtered, readable = info.isLocked, info.isFiltered, info.isReadable
        noValue, link = info.hasNoValue, info.hyperlink
    end

    if button.gw_slotStateSet
        and button.gw_slotItemID == itemID
        and button.gw_slotCount == count
        and button.gw_slotQuality == quality
        and button.gw_slotLocked == locked
        and button.gw_slotFiltered == filtered
        and button.gw_slotReadable == readable
        and button.gw_slotNoValue == noValue
        and button.gw_slotLink == link
    then
        return false
    end

    button.gw_slotStateSet = true
    button.gw_slotItemID, button.gw_slotCount, button.gw_slotQuality = itemID, count, quality
    button.gw_slotLocked, button.gw_slotFiltered, button.gw_slotReadable = locked, filtered, readable
    button.gw_slotNoValue, button.gw_slotLink = noValue, link
    return true
end

-- force writes the slot even when its content did not change, needed whenever something outside
-- the container api changed the look (settings, skin/size sweeps, a new slot id on the button)
local function UpdateOwnContainerItemButton(button, force)
    local bagID = button:GetParent():GetID()
    local slotID = button:GetID()

    local info = C_Container.GetContainerItemInfo(bagID, slotID)
    if not TakeSlotState(button, info) and not force then
        return
    end

    local texture = info and info.iconFileID
    local itemCount = info and info.stackCount
    local locked = info and info.isLocked
    local quality = info and info.quality
    local readable = info and info.isReadable
    local isFiltered = info and info.isFiltered
    local itemID = info and info.itemID

    SetItemButtonTexture(button, texture)
    SetItemButtonCount(button, itemCount)
    SetItemButtonDesaturated(button, locked)
    button.gwItemInfo = info
    SetItemButtonQuality(button, quality, info and info.hyperlink or itemID)
    button.gwItemInfo = nil

    -- toggle the quest icon (the skin owns the textures look)
    local questTexture = GetQuestTexture(button)
    if questTexture then
        local questInfo = info and C_Container.GetContainerItemQuestInfo(bagID, slotID)
        questTexture:SetShown(questInfo and (questInfo.questID ~= nil or questInfo.isQuestItem == true) or false)
    end

    if texture then
        updateCooldown(bagID, button)
    elseif button.cooldown then
        button.cooldown:Hide()
    end

    -- go through the mixin setters where they exist and only write the fields directly on
    -- the flavors without them: hasItem and readable are mixin state like bagID, and an own
    -- value on a retail button taints every protected item interaction
    if button.SetHasItem then
        button:SetHasItem(texture)
    else
        button.hasItem = texture and 1 or nil
    end
    if button.SetReadable then
        button:SetReadable(readable)
    else
        button.readable = readable
    end

    if GameTooltip:IsOwned(button) then
        if not info then
            GameTooltip:Hide()
        elseif button.UpdateTooltip then
            button:UpdateTooltip()
        elseif button.OnEnter then
            -- the retail bank item buttons have no UpdateTooltip, their mixin
            -- rebuilds the tooltip in OnEnter
            button:OnEnter()
        end
    end

    if button.searchOverlay then
        button.searchOverlay:SetShown(isFiltered == true)
    end
end
GW.UpdateOwnContainerItemButton = UpdateOwnContainerItemButton

-- forever's gamepad interface: X uses the selected item, Y destroys it after blizzards confirmation.
-- Using one is protected, so while a slot is selected X is bound to a secure button that right-clicks
-- it; bindings can only change out of combat, combat start clears them and combat end sets them again
local gamepadUse, gamepadDestroy

local function itemButton_OnSmartNavSelect(self)
    if not InCombatLockdown() then
        gamepadUse:SetAttribute("clickbutton2", self)
        gamepadDestroy.slot = self
        SetOverrideBindingClick(gamepadUse, true, "PAD3", "GwGamepadItemUse", "RightButton")
        SetOverrideBindingClick(gamepadUse, true, "PAD4", "GwGamepadItemDestroy")
    end
end

local function itemButton_OnSmartNavDeselect()
    if not InCombatLockdown() then
        ClearOverrideBindings(gamepadUse)
    end
end

if GW.IsGamepadInterface() then
    gamepadUse = CreateFrame("Button", "GwGamepadItemUse", UIParent, "SecureActionButtonTemplate")
    gamepadUse:SetAttribute("type2", "click")
    gamepadUse:RegisterForClicks("AnyDown")
    gamepadUse:RegisterEvent("PLAYER_REGEN_DISABLED")
    gamepadUse:RegisterEvent("PLAYER_REGEN_ENABLED")
    gamepadUse:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_REGEN_DISABLED" then
            ClearOverrideBindings(self)
        else
            local button = SmartNavigation:GetCurrentButton()
            if button and button.OnSmartNavSelect == itemButton_OnSmartNavSelect then
                itemButton_OnSmartNavSelect(button)
            end
        end
    end)

    gamepadDestroy = CreateFrame("Button", "GwGamepadItemDestroy", UIParent)
    gamepadDestroy:SetScript("OnClick", function(self)
        local item = Item:CreateFromBagAndSlot(self.slot:GetBagID(), self.slot:GetID())
        if not item:IsItemEmpty() then
            C_Item.ConfirmDeleteItem(item:GetItemGUID())
        end
    end)
end

local function EnsureItemButton(cf, index, iconSize, opts)
    local button = cf.gw_items[index]
    if button then
        return button
    end

    local bagID = cf:GetID()
    local name = "GwContainerItem" .. (bagID >= 0 and bagID or ("N" .. -bagID)) .. "_" .. index
    -- on retail the container item button template is based on the ItemButton
    -- intrinsic, creating it as a plain Button would lose icon/count/border
    button = CreateFrame(opts and opts.frameType or (GW.isModern and "ItemButton" or "Button"), name, cf, opts and opts.template or "ContainerFrameItemButtonTemplate")
    button.gwOwnItemButton = true

    -- the templates children are created by name on the classic flavors and by
    -- parent key on retail, cache the ones we need
    button.cooldown = _G[name .. "Cooldown"] or button.Cooldown
    GetQuestTexture(button)

    -- the extended slot advert and new item visuals of the template default to shown,
    -- blizzard hides them in its own update pass, so we do it once at creation
    if ContainerFrameItemButton_SetForceExtended then
        ContainerFrameItemButton_SetForceExtended(button, false)
    end
    if button.NewItemTexture then
        button.NewItemTexture:Hide()
    end
    if button.BattlepayItemTexture then
        button.BattlepayItemTexture:Hide()
    end

    if GW.SkinBagItemButton then
        GW.SkinBagItemButton(button, iconSize)
        button.gwSkinned = true
    end

    if gamepadUse then
        button.OnSmartNavSelect = itemButton_OnSmartNavSelect
        button.OnSmartNavDeselect = itemButton_OnSmartNavDeselect
    end

    -- No secure overlay for spell-item-targeting: the buttons inherit
    -- ContainerFrameItemButtonTemplate, whose OnClick is a secure template script and
    -- handles the targeting UseContainerItem itself (Baganator relies on exactly this).
    -- An overlay button would also make every ancestor unhideable in combat.
    cf.gw_items[index] = button
    allItemButtons[#allItemButtons + 1] = button
    return button
end

-- shows/hides the secure "/use" overlays with the item targeting state. Toggling
-- secure frames is combat locked: in-combat flips are skipped and resynced on
-- PLAYER_REGEN_ENABLED (item targeting spells in combat are a rare edge)
local function UpdateOwnContainerItemButtons(cf, force)
    if not cf or not cf.gw_items then
        return
    end
    for i = 1, cf.gw_num_slots or 0 do
        local button = cf.gw_items[i]
        if button then
            UpdateOwnContainerItemButton(button, force)
        end
    end
end
GW.UpdateOwnContainerItemButtons = UpdateOwnContainerItemButtons

-- item buttons created in combat get tainted clicks (a Blizzard restriction), so the missing ones
-- are made up front; they stay hidden until the container is set up
local function PrepareOwnContainerItemButtons(cf, bagID, iconSize, opts, numSlots)
    if not cf then
        return
    end
    cf.gw_items = cf.gw_items or {}
    for i = #cf.gw_items + 1, numSlots or C_Container.GetContainerNumSlots(bagID) do
        EnsureItemButton(cf, i, iconSize, opts):Hide()
    end
end
GW.PrepareOwnContainerItemButtons = PrepareOwnContainerItemButtons

-- (re)builds the own item buttons of one of our containers to match the bags current size.
-- iconSize is only used for the initial skinning of newly created buttons. straightIDs assigns
-- the slot ids in list order like the old bank frame buttons, without it the ids are assigned
-- in reverse like blizzards container frame buttons - the layouts iterate accordingly.
-- opts can carry a frameType/template override and an initButton callback for buttons that
-- need more than the parent bag id and slot id (the retail bank item buttons)
local function SetupOwnContainerItemButtons(cf, bagID, iconSize, straightIDs, opts)
    if not cf then
        return
    end
    if not cf.gw_items then
        cf.gw_items = {}
    end

    -- the keyring only shows while it is open in our bag
    local numSlots = 0
    if bagID ~= KEYRING_CONTAINER then
        numSlots = C_Container.GetContainerNumSlots(bagID)
    elseif cf.shouldShow then
        numSlots = GetKeyRingSize and GetKeyRingSize() or C_Container.GetContainerNumSlots(bagID)
    end
    local bagFamily = select(2, C_Container.GetContainerNumFreeSlots(bagID))
    -- the button set only has to be rebuilt when the container itself changed: with the same
    -- id, size and family the existing buttons already carry the right slot ids, and only the
    -- slot contents can have changed. The retail bank reuses one container frame for all tabs,
    -- so the id has to be part of that check
    local rebuild = bagID ~= cf.gw_bag_id or numSlots ~= cf.gw_num_slots or bagFamily ~= cf.gw_bag_family

    cf.gw_bag_id = bagID
    cf.gw_num_slots = numSlots
    cf.gw_bag_family = bagFamily

    if not rebuild then
        UpdateOwnContainerItemButtons(cf)
        return
    end

    for i = 1, numSlots do
        local button = EnsureItemButton(cf, i, iconSize, opts)
        local slotID = straightIDs and i or (numSlots - i + 1)
        button:SetID(slotID)
        if opts and opts.initButton then
            opts.initButton(button, bagID, slotID)
        end
        button:Show()
        -- forced: the slot id or the container behind it can have changed, which makes any
        -- remembered slot state of this button meaningless
        UpdateOwnContainerItemButton(button, true)
    end

    -- hide leftovers from a previously bigger bag
    for i = numSlots + 1, #cf.gw_items do
        cf.gw_items[i]:Hide()
    end
end
GW.SetupOwnContainerItemButtons = SetupOwnContainerItemButtons

-- ITEM_LOCKED / ITEM_UNLOCKED, updates one slot or all when no slot is given
local function UpdateOwnContainerLockedState(cf, slotID)
    if not cf or not cf.gw_items then
        return
    end
    local bagID = cf:GetID()
    for i = 1, cf.gw_num_slots or 0 do
        local button = cf.gw_items[i]
        if button and (not slotID or button:GetID() == slotID) then
            local info = C_Container.GetContainerItemInfo(bagID, button:GetID())
            -- an unlock must not clear the junk grey out (the quality skin combined both)
            SetItemButtonDesaturated(button, (info and info.isLocked) or (button.isJunk and GW.settings.bags.items.junkDesaturate) or false)
            -- the remembered slot state has to follow, or the next content update would skip
            -- a slot whose lock state it thinks it never wrote
            button.gw_slotLocked = info and info.isLocked
        end
    end
end
GW.UpdateOwnContainerLockedState = UpdateOwnContainerLockedState

local function UpdateOwnContainerCooldowns(cf)
    if not cf or not cf.gw_items then
        return
    end
    local bagID = cf:GetID()
    for i = 1, cf.gw_num_slots or 0 do
        local button = cf.gw_items[i]
        if button and button.hasItem then
            updateCooldown(bagID, button)
        end
    end
end
GW.UpdateOwnContainerCooldowns = UpdateOwnContainerCooldowns

local function UpdateOwnContainerSearchResults(cf)
    if not cf or not cf.gw_items then
        return
    end
    local bagID = cf:GetID()
    for i = 1, cf.gw_num_slots or 0 do
        local button = cf.gw_items[i]
        if button and button.searchOverlay then
            local info = C_Container.GetContainerItemInfo(bagID, button:GetID())
            button.searchOverlay:SetShown((info and info.isFiltered) == true)
            button.gw_slotFiltered = info and info.isFiltered
        end
    end
end
GW.UpdateOwnContainerSearchResults = UpdateOwnContainerSearchResults

-- slot by slot like blizzards container frames, C_NewItems.ClearAll on close tainted the item upgrade frame
local function ClearOwnContainerNewItems(cf)
    if not cf or not cf.gw_items then
        return
    end
    local bagID = cf:GetID()
    for i = 1, cf.gw_num_slots or 0 do
        local button = cf.gw_items[i]
        if button then
            C_NewItems.RemoveNewItem(bagID, button:GetID())
            if button.gwNewItem then
                button.gwNewItem:Hide()
            end
        end
    end
end
GW.ClearOwnContainerNewItems = ClearOwnContainerNewItems

-- used by the flavor reskin sweeps to apply size and style setting changes
local function ForEachOwnBagItemButton(func)
    for i = 1, #allItemButtons do
        func(allItemButtons[i])
    end
end
GW.ForEachOwnBagItemButton = ForEachOwnBagItemButton

-- central refresh for the bag/bank setting callbacks and integrations (e.g. pawn): updates
-- all visible own item buttons; hidden buttons get rebuilt on the next open anyway.
-- Always forced - the trigger sits outside the container api, so the slot contents look
-- unchanged while the setting that decides how to draw them did change
local function UpdateAllOwnBagItemButtons()
    for i = 1, #allItemButtons do
        local button = allItemButtons[i]
        if button:IsVisible() then
            UpdateOwnContainerItemButton(button, true)
        end
    end
end
GW.UpdateAllOwnBagItemButtons = UpdateAllOwnBagItemButtons
