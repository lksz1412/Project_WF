---@class GW2
local GW = select(2, ...)
local L = GW.L

local BORDER_TEXTURE = "Interface/AddOns/GW2_UI/textures/bag/bagitemborder.png"

-- the keyring exists on the classic flavors and on forever, the reagent bag on retail and forever
local HAS_KEYRING = (C_ActionBar and C_ActionBar.ShouldShowKeyring and C_ActionBar.ShouldShowKeyring()) or (IsKeyRingEnabled and IsKeyRingEnabled()) or false
local HAS_REAGENT_BAG = (Constants.InventoryConstants and Constants.InventoryConstants.NumReagentBagSlots or 0) > 0
local KEYRING_CONTAINER = (Enum.BagIndex and Enum.BagIndex.Keyring) or KEYRING_CONTAINER or -2
local REAGENT_CONTAINER = (Enum.BagIndex and Enum.BagIndex.ReagentBag) or (NUM_BAG_SLOTS + 1)

local BAG_ITEM_SIZE_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bag.itemSize,
    minValue = 26,
    maxValue = 48,
    step = 1
}
local BAG_ITEM_SPACING_X_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bag.itemSpacingX,
    minValue = 0,
    maxValue = 20,
    step = 1
}
local BAG_ITEM_SPACING_Y_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bag.itemSpacingY,
    minValue = 0,
    maxValue = 20,
    step = 1
}
local BANK_ITEM_SIZE_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bank.itemSize,
    minValue = 26,
    maxValue = 48,
    step = 1
}
local BANK_ITEM_SPACING_X_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bank.itemSpacingX,
    minValue = 0,
    maxValue = 20,
    step = 1
}
local BANK_ITEM_SPACING_Y_CONFIG = {
    defaultValue = GW.globalDefault.profile.bags.bank.itemSpacingY,
    minValue = 0,
    maxValue = 20,
    step = 1
}
local CONTAINER_FRAME_SIDE_PADDING = 5
local CONTAINER_FRAME_RIGHT_PADDING = 5

local OVERLAY_BASE_SIZE = 40
local JUNK_ATLAS = C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("bags-junkcoin")
local ITEM_OVERLAYS = {
    {key = "IconQuestTexture", width = 25, height = 25},
    {key = "junkIcon", width = JUNK_ATLAS and JUNK_ATLAS.width or 16, height = JUNK_ATLAS and JUNK_ATLAS.height or 16},
    {key = "scrapIcon", width = 14, height = 12},
    {key = "UpgradeIcon", width = 15, height = 15},
}

local function ScaleItemOverlays(b, iconSize)
    local scale = iconSize / OVERLAY_BASE_SIZE
    if b.gwOverlayScale == scale then return end
    b.gwOverlayScale = scale
    b.gwNewItem:SetScale(0.8 * scale)
    for _, overlay in ipairs(ITEM_OVERLAYS) do
        local texture = b[overlay.key]
        if texture then
            texture:SetSize(overlay.width * scale, overlay.height * scale)
        end
    end
end

-- reskins an ItemButton to use GW2_UI styling; one central version for every flavor,
-- retail only parts are capability guarded
local function reskinItemButton(b, overrideIconSize)
    if not b then return end
    local iconSize = overrideIconSize or GW.settings.bags.bag.itemSize
    b:SetSize(iconSize, iconSize)

    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    GW.HandleItemButtonCrop(b)
    b.icon:SetAllPoints(b)
    b.icon:SetAlpha(0.9)

    b.IconBorder:SetAllPoints(b)
    b.IconBorder:SetTexture(BORDER_TEXTURE)

    if b.ClearNormalTexture then
        b:ClearNormalTexture()
    else
        local norm = b:GetNormalTexture()
        if norm then
            norm:SetTexture(nil)
        end
    end
    if b.NormalTexture then
        b.NormalTexture:SetTexture()
    end

    if GW.isModern then
        -- kill the retail slot background
        if not b.ItemSlotBackground then
            b.ItemSlotBackground = b:CreateTexture(nil, "BACKGROUND", nil, -6)
            b.ItemSlotBackground:SetAllPoints(b)
        end
        b.ItemSlotBackground:SetAlpha(0)
    end
    if b.Background then
        b.Background:Hide()
    end

    local high = b:GetHighlightTexture()
    high:SetAllPoints(b)
    high:SetTexture(BORDER_TEXTURE)
    high:SetBlendMode("ADD")
    high:SetAlpha(0.33)

    local pushed = b:GetPushedTexture()
    if pushed then
        pushed:SetTexture("Interface/AddOns/GW2_UI/textures/uistuff/ui-quickslot-depress.png")
        pushed:SetAllPoints(b)
    end

    if not b.gwBackdrop then
        local bd = b:CreateTexture(nil, "BACKGROUND")
        bd:SetTexture("Interface/AddOns/GW2_UI/textures/bag/bagitembackdrop.png")
        bd:SetAllPoints(b)
        b.gwBackdrop = bd
    end

    b.Count:ClearAllPoints()
    b.Count:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, -3)
    b.Count:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "THINOUTLINE")
    b.Count:SetJustifyH("RIGHT")

    -- the templates quest texture becomes our own quest icon on every flavor,
    -- so quest items are marked the same everywhere (the retail default)
    if b.IconQuestTexture then
        b.IconQuestTexture:ClearAllPoints()
        b.IconQuestTexture:SetTexture("Interface/AddOns/GW2_UI/textures/icons/icon-quest.png")
        b.IconQuestTexture:SetPoint("TOPLEFT", -7, 1)
        b.IconQuestTexture:SetVertexColor(221 / 255, 198 / 255, 68 / 255)
        b.IconQuestTexture:SetAlpha(1)
        if b.UpdateQuestItem then
            hooksecurefunc(b, "UpdateQuestItem", function()
                b.IconQuestTexture:SetTexture("Interface/AddOns/GW2_UI/textures/icons/icon-quest.png")
            end)
        elseif b.Refresh then --bank_slots
            hooksecurefunc(b, "Refresh", function()
                b.IconQuestTexture:SetTexture("Interface/AddOns/GW2_UI/textures/icons/icon-quest.png")
            end)
        end
    end

    if b.flash then
        b.flash:SetAllPoints(b)
    end

    if not b.gwNewItem then
        b.gwNewItem = CreateFrame("Frame", nil, b, "NewFeatureLabelNoAnimateTemplate")
        b.gwNewItem:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 2, 2)
        b.gwNewItem:SetFrameLevel(b:GetFrameLevel() + 5)
        b.gwNewItem.Label:ClearAllPoints()
        b.gwNewItem.Label:SetPoint("BOTTOMLEFT")
        b.gwNewItem.BGLabel:ClearAllPoints()
        b.gwNewItem.BGLabel:SetPoint("BOTTOMLEFT", 0.5, -0.5)
        b.gwNewItem:Hide()
    end

    if not b.junkIcon then
        b.junkIcon = b:CreateTexture(nil, "OVERLAY", nil, 2)
        b.junkIcon:SetAtlas("bags-junkcoin")
        b.junkIcon:SetPoint("TOPLEFT", -3, 3)
        b.junkIcon:Hide()
    end

    -- scrapping only exists on retail
    if C_Item.CanScrapItem and not b.scrapIcon then
        b.scrapIcon = b:CreateTexture(nil, "OVERLAY", nil, 2)
        b.scrapIcon:SetAtlas("bags-icon-scrappable")
        b.scrapIcon:SetPoint("TOPLEFT", 0, 0)
        b.scrapIcon:Hide()
    end

    if not b.UpgradeIcon then
        b.UpgradeIcon = b:CreateTexture(nil, "OVERLAY", nil, 2)
        b.UpgradeIcon:SetPoint("TOPRIGHT", 7, -1)
        b.UpgradeIcon:Hide()
    end
    ScaleItemOverlays(b, iconSize)

    if not b.itemlevel then
        b.itemlevel = b:CreateFontString(nil, "OVERLAY")
        b.itemlevel:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "THINOUTLINE")
        b.itemlevel:SetPoint("BOTTOMRIGHT", 0, 0)
        b.itemlevel:SetText("")
    end

    if b.cooldown then
        GW.RegisterCooldown(b.cooldown)
    elseif b.Cooldown then
        GW.RegisterCooldown(b.Cooldown)
    elseif b.GetName and b:GetName() and _G[b:GetName() .. "Cooldown"] then
        GW.RegisterCooldown(_G[b:GetName() .. "Cooldown"])
    end
end
GW.SkinBagItemButton = reskinItemButton


local function updateItemVisuals(b, overrideIconSize)
   if not b or not b:IsShown() then return end

    local iconSize = overrideIconSize or GW.settings.bags.bag.itemSize

    if b:GetWidth() ~= iconSize or b:GetHeight() ~= iconSize then
        b:SetSize(iconSize, iconSize)
    end

    local left, right, top, bottom = b.icon:GetTexCoord()
    if left ~= 0.07 or right ~= 0.93 or top ~= 0.07 or bottom ~= 0.93 then
        b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    end
    if b.icon:GetAlpha() ~= 0.9 then
        b.icon:SetAlpha(0.9)
    end

    if b:GetHighlightTexture() then
        local high = b:GetHighlightTexture()
        if high:GetTexture() ~= BORDER_TEXTURE then
            high:SetTexture(BORDER_TEXTURE)
        end
        if high:GetBlendMode() ~= "ADD" then
            high:SetBlendMode("ADD")
        end
        if high:GetAlpha() ~= 0.33 then
            high:SetAlpha(0.33)
        end
    end

    local point, _, relativePoint, x, y = b.Count:GetPoint()
    if point ~= "TOPRIGHT" or relativePoint ~= "TOPRIGHT" or x ~= 0 or y ~= -3 then
        b.Count:ClearAllPoints()
        b.Count:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, -3)
    end
    if b.Count:GetJustifyH() ~= "RIGHT" then
        b.Count:SetJustifyH("RIGHT")
    end

    -- blizzard may size the quest texture again, then all overlays are set once more
    if b.IconQuestTexture and math.abs(b.IconQuestTexture:GetWidth() - 25 * iconSize / OVERLAY_BASE_SIZE) > 0.5 then
        b.gwOverlayScale = nil
    end
    ScaleItemOverlays(b, iconSize)
    if b.IconQuestTexture then
        point, _, _, x, y = b.IconQuestTexture:GetPoint()
        if point ~= "TOPLEFT" or x ~= -7 or y ~= 1 then
            b.IconQuestTexture:ClearAllPoints()
            b.IconQuestTexture:SetPoint("TOPLEFT", -7, 1)
        end
    end

    if b.flash then
        b.flash:SetAllPoints(b)
    end
end
GW.UpdateBagItemButtonVisuals = updateItemVisuals


local function reskinItemButtons()
    -- our own bag and bank item buttons with their separate size settings; hidden ones only
    -- get the new size, the rest of the visual updates run on the next sweep while shown
    GW.ForEachOwnBagItemButton(function(slot)
        local bagID = slot:GetParent():GetID()
        local isBank = bagID == BANK_CONTAINER or bagID > NUM_BAG_SLOTS
        local iconSize = isBank and GW.settings.bags.bank.itemSize or GW.settings.bags.bag.itemSize

        if not slot.gwSkinned then
            GW.SkinBagItemButton(slot, iconSize)
            slot.gwSkinned = true
        elseif slot:IsShown() then
            GW.UpdateBagItemButtonVisuals(slot, iconSize)
        else
            slot:SetSize(iconSize, iconSize)
        end
    end)
end


-- makes a blizzard frame inert: no scripts, no events, no points - blizzards code can
-- still show/hide it, but the frame never renders or updates anything
local function disableBlizzardFrame(frame, offscreen)
    frame:SetScript("OnShow", nil)
    frame:SetScript("OnHide", nil)
    frame:UnregisterAllEvents()
    if offscreen then
        -- blizzard still reads its position while it is shown (UpdateContainerFrameAnchors), so it waits
        -- off screen; a GetRight of our own would taint blizzards bag code
        local moving = false
        local function MoveOffscreen()
            if moving then return end
            moving = true
            frame:ClearAllPoints()
            frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -2000, 2000)
            moving = false
        end
        frame:SetClampedToScreen(false)
        MoveOffscreen()
        hooksecurefunc(frame, "SetPoint", MoveOffscreen)
    else
        frame:ClearAllPoints()
        hooksecurefunc(frame, "SetPoint", frame.ClearAllPoints)
    end
end

local function disableBlizzardContainers()
    for i = 1, NUM_CONTAINER_FRAMES do
        local cf = _G["ContainerFrame" .. i]
        if cf then
            disableBlizzardFrame(cf)
        end
    end

    local combinedBag = ContainerFrameCombinedBags
    if combinedBag then
        disableBlizzardFrame(combinedBag)
        -- keeps blizzards UpdateItemLayout from erroring when first accessing a
        -- vendor and then adding a bag
        combinedBag:RegisterEvent("BAG_CONTAINER_UPDATE")
    end
end


local function SetItemButtonQualityForBags(button, quality)
    button.IconBorder:SetTexture(BORDER_TEXTURE)
    button.IconOverlay:Hide()
    button.IconBorder:SetAlpha(0.9)

    local commonQuality = LE_ITEM_QUALITY_COMMON or Enum.ItemQuality.Common
    if quality and quality >= commonQuality then
        -- not every client has a common entry in blizzards color table, fall back to white
        local color = BAG_ITEM_QUALITY_COLORS[quality] or (quality == commonQuality and GW.Colors.FallbackWhite)
        if color then
            button.IconBorder:Show()
            button.IconBorder:SetVertexColor(color.r, color.g, color.b)
        else
            button.IconBorder:Hide()
        end
    else
        button.IconBorder:Hide()
    end
end
GW.SetItemButtonQualityForBags = SetItemButtonQualityForBags

-- item slots outside the bags (mail, guild bank) frame common items white, blizzards bag color for them is grey
local function SetItemSlotQuality(button, quality)
    SetItemButtonQualityForBags(button, quality)
    if quality == (LE_ITEM_QUALITY_COMMON or Enum.ItemQuality.Common) then
        button.IconBorder:SetVertexColor(GW.Colors.FallbackWhite:GetRGB())
    end
end
GW.SetItemSlotQuality = SetItemSlotQuality

-- flavor extras can decorate every item button after the shared quality skin ran
-- (e.g. the equipment set name on mists), registered at file scope from the flavors
local itemButtonDecorators = {}
-- Unusable detection through the tooltip: a red line means the character cannot use the
-- item, whatever the reason (level, class, proficiency, reputation) - the tooltip encodes
-- them all, in every locale. Three red lines that do NOT mean unusable are excluded, the
-- same set Baganator filters. Cached per item link; level ups and new skills can change
-- usability, so those bump the generation and invalidate every cached verdict at once.
local unusableGeneration = 0

local unusableWatcher = CreateFrame("Frame")
unusableWatcher:RegisterEvent("PLAYER_LEVEL_UP")
unusableWatcher:RegisterEvent("SKILL_LINES_CHANGED")
unusableWatcher:SetScript("OnEvent", function()
    unusableGeneration = unusableGeneration + 1
    if GW.settings.bags.items.markUnusable then
        GW.UpdateAllOwnBagItemButtons()
    end
end)

local function IsRedTooltipColor(r, g, b)
    return r == 1 and g < 0.2 and b < 0.2
end

-- a red left line means unusable, unless it is one of these three
local function IsUnusableLeftLine(r, g, b, text)
    return IsRedTooltipColor(r, g, b)
        and text ~= ITEM_SCRAPABLE_NOT
        and text ~= CANNOT_UNEQUIP_COMBAT
        and text ~= ITEM_DISENCHANT_NOT_DISENCHANTABLE
end

-- C_TooltipInfo carries the line colors directly, but its query functions only exist on
-- retail (the classic clients ship the namespace without them) - there a hidden scanning
-- tooltip provides the same lines through its font strings
local function ScanBagItemForUnusable(bagID, slot)
    if C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local data = C_TooltipInfo.GetBagItem(bagID, slot)
        if data and data.lines then
            for _, line in ipairs(data.lines) do
                local c = line.leftColor
                if c and IsUnusableLeftLine(c.r, c.g, c.b, line.leftText) then
                    return true
                end
                c = line.rightColor
                if c and IsRedTooltipColor(c.r, c.g, c.b) then
                    return true
                end
            end
        end
        return false
    end


    -- other scans hide the tooltip, without an owner it stays empty
    GW.ScanTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    GW.ScanTooltip:ClearLines()
    if bagID == BANK_CONTAINER then
        GW.ScanTooltip:SetInventoryItem("player", BankButtonIDToInvSlotID(slot))
    else
        GW.ScanTooltip:SetBagItem(bagID, slot)
    end
    -- line 1 is the item name, never a restriction
    for i = 2, GW.ScanTooltip:NumLines() do
        local left = _G["GW2_UIScanTooltipTextLeft" .. i]
        if left and left:IsShown() then
            local r, g, b = left:GetTextColor()
            if IsUnusableLeftLine(r, g, b, left:GetText()) then
                return true
            end
        end
        local right = _G["GW2_UIScanTooltipTextRight" .. i]
        if right and right:IsShown() then
            local r, g, b = right:GetTextColor()
            if IsRedTooltipColor(r, g, b) then
                return true
            end
        end
    end
    return false
end

local function IsItemUnusable(bagID, button, itemInfo)
    if not itemInfo or not itemInfo.hyperlink then
        return false
    end
    if button.gwUnusableLink == itemInfo.hyperlink and button.gwUnusableGeneration == unusableGeneration then
        return button.gwUnusable
    end

    local cached = C_Item.GetItemInfo(itemInfo.hyperlink) ~= nil
    button.gwUnusableLink = cached and itemInfo.hyperlink or nil
    button.gwUnusableGeneration = unusableGeneration
    button.gwUnusable = ScanBagItemForUnusable(bagID, button:GetID())

    -- without item data the tooltip lacks the red lines; after a reload that is the whole bank
    if not cached then
        local item = Item:CreateFromItemLink(itemInfo.hyperlink)
        if not item:IsItemDataCached() then
            GW.ContinueOnItemLoad(item, function()
                if button:IsVisible() then
                    GW.UpdateOwnContainerItemButton(button, true)
                end
            end)
        end
    end

    return button.gwUnusable
end

-- cooldown updates (blizzards ContainerFrame_UpdateCooldown and our retail fallback)
-- reset the icon vertex color to white, wiping the unusable tint - the content update
-- calls this afterwards to put the tint back. Relies on the gwUnusable verdict cached
-- by IsItemUnusable, which the quality skin refreshed earlier in the same update
local function ReapplyUnusableTint(button)
    if button.gwUnusable and GW.settings.bags.items.markUnusable and button.gwOwnItemButton then
        SetItemButtonTextureVertexColor(button, RED_FONT_COLOR.r, RED_FONT_COLOR.g, RED_FONT_COLOR.b)
    end
end
GW.ReapplyBagItemUnusableTint = ReapplyUnusableTint

local function RegisterItemButtonDecorator(decorator)
    itemButtonDecorators[#itemButtonDecorators + 1] = decorator
end
GW.RegisterItemButtonDecorator = RegisterItemButtonDecorator

local function SetItemButtonData(button, quality, itemIDOrLink, suppressOverlays)
    if not button.gwBackdrop then
        return
    end

    button.IconOverlay:Hide()
    local t = button.IconBorder
    local colorCommon = GW.GetBagItemQualityColor(Enum.ItemQuality.Common)
    t:SetTexture(BORDER_TEXTURE)
    t:SetAlpha(0.9)
    t:SetVertexColor(colorCommon.r, colorCommon.g, colorCommon.b)

    local container = button:GetParent()
    local bag_id = container:GetID()
    local keyring = HAS_KEYRING and bag_id == KEYRING_CONTAINER
    local isReagentBag = HAS_REAGENT_BAG and bag_id == REAGENT_CONTAINER
    local professionColors = keyring and BAG_ITEM_QUALITY_COLORS[LE_ITEM_QUALITY_WOW_TOKEN]
        or isReagentBag and GW.GetBagItemQualityColor(Enum.ItemQuality.Artifact)
        or GW.Colors.ProfessionBagColors[container.gw_bag_family or select(2, C_Container.GetContainerNumFreeSlots(bag_id))]
    local showItemLevel = button.itemlevel and itemIDOrLink and GW.settings.bags.items.showItemLevel and not professionColors

    -- never store this as button.bagID: blizzards ContainerFrameItemButtonMixin:GetBagID
    -- returns self.bagID before falling back to the parents id, so an own value there taints
    -- every protected item interaction (using an item, selling to a vendor) with
    -- ADDON_ACTION_FORBIDDEN - blizzard routes its own id through SetAttribute for that reason
    button.gwBagID = bag_id

    -- Show the new item marker if active; C_NewItems is the only state holder, we just read it,
    -- and closing the bags clears it like blizzards container frames used to. This runs for empty
    -- slots too: without that the marker of a sold, moved or used up item kept sitting on the now
    -- empty slot, since nothing else ever hides it. Only our own container buttons carry a real
    -- bag id and slot id here, the (stolen) bag bar buttons also have the gw backdrop
    if button.gwOwnItemButton then
        local isNew = itemIDOrLink and GW.settings.bags.items.newItemGlow and C_NewItems.IsNewItem(bag_id, button:GetID())
        button.gwNewItem:SetShown(isNew == true)
        if not itemIDOrLink then
            -- drop the state as well, or the next item landing in this slot inherits the marker
            C_NewItems.RemoveNewItem(bag_id, button:GetID())
        end
    end

    -- by default the profession bag tint wins over an items quality color; with the
    -- quality-over-profession option the tint is applied first so the quality color wins
    local qualityWinsOverProfession = GW.settings.bags.professionBagQualityColor
    if qualityWinsOverProfession and (GW.settings.bags.professionBagColor or isReagentBag) and professionColors then
        t:SetVertexColor(professionColors.r, professionColors.g, professionColors.b)
        t:Show()
    end

    if itemIDOrLink then
        if quality == nil then quality = 0 end

        -- Show junk icon if active; the factory hands over the record it just fetched
        local itemInfo = button.gwItemInfo or C_Container.GetContainerItemInfo(bag_id, button:GetID())
        button.isJunk = itemInfo and ((itemInfo.quality and itemInfo.quality == Enum.ItemQuality.Poor) and not itemInfo.hasNoValue) or false

        if button.junkIcon then
            if button.isJunk and GW.settings.bags.items.junkIcon then
                button.junkIcon:Show()
            else
                button.junkIcon:Hide()
            end
        end

        -- grey out junk; combined with the lock state, which desaturates through the
        -- same channel (a picked up item must stay grey either way)
        SetItemButtonDesaturated(button, (button.isJunk and GW.settings.bags.items.junkDesaturate) or (itemInfo and itemInfo.isLocked) or false)

        if button.gwOwnItemButton and GetItemButtonIconTexture then
            local icon = GetItemButtonIconTexture(button)
            if GW.settings.bags.items.markUnusable and IsItemUnusable(bag_id, button, itemInfo) then
                icon:SetVertexColor(RED_FONT_COLOR.r, RED_FONT_COLOR.g, RED_FONT_COLOR.b)
            else
                icon:SetVertexColor(1, 1, 1)
            end
        end

        -- Show upgrade icon if active
        if itemInfo and itemInfo.hyperlink and GW.settings.bags.items.upgradeIcon and button.UpgradeIcon then
            GW.RegisterPawnUpgradeIcon(button, itemInfo.hyperlink)
        elseif button.UpgradeIcon then
            button.UpgradeIcon:Hide()
        end

        -- Show ilvl if active
        if button.itemlevel and showItemLevel then
            local canShowItemLevel = GW.IsItemEligibleForItemLevelDisplay(itemIDOrLink)
            if canShowItemLevel then
                GW.SetItemLevel(button, quality, itemIDOrLink, nil, GW.settings.bags.items.levelThreshold)
            else
                button.itemlevel:SetText("")
                button.__gwLastItemLink = nil
            end
        elseif button.itemlevel then
            button.itemlevel:SetText("")
            button.__gwLastItemLink = nil
        end

        -- flavor extras (azerite/corruption/scrap on retail, equipment set names on mists)
        for i = 1, #itemButtonDecorators do
            itemButtonDecorators[i](button, quality, itemIDOrLink, suppressOverlays)
        end

        if GW.settings.bags.items.qualityBorder and quality and quality > 0 then
            local color = GW.GetBagItemQualityColor(quality)
            t:SetVertexColor(color.r, color.g, color.b)
        end

        t:Show()
        -- the empty slot icon toggle only applies to our own container item buttons,
        -- not to the (stolen) bag bar buttons that also carry the gw backdrop
        if button.gwOwnItemButton and GetItemButtonIconTexture then
            GetItemButtonIconTexture(button):Show()
        end
    else
        if button.junkIcon then button.junkIcon:Hide() end
        if button.scrapIcon then button.scrapIcon:Hide() end
        if button.gwEquipSetIcon then
            button.gwEquipSetIcon:Hide()
            button.gwEquipSetIconBorder:Hide()
        end
        if button.UpgradeIcon then button.UpgradeIcon:Hide() end
        if button.gwBindType then button.gwBindType:SetText("") end
        if button.itemlevel then
            button.itemlevel:SetText("")
            button.__gwLastItemLink = nil
        end
        if button.gwOwnItemButton and GetItemButtonIconTexture then
            local icon = GetItemButtonIconTexture(button)
            icon:SetVertexColor(1, 1, 1) -- an unusable tint must not survive into the empty slot look
            icon:Hide()
        end
        button.gwUnusableLink = nil
    end

    if not qualityWinsOverProfession and (GW.settings.bags.professionBagColor or isReagentBag) and professionColors then
        t:SetVertexColor(professionColors.r, professionColors.g, professionColors.b)
        t:Show()
    end

    --Keyring
    if keyring then
        t:Show()
        t:SetVertexColor(professionColors.r, professionColors.g, professionColors.b)
    end
end
GW.SetBagItemButtonQualitySkin = SetItemButtonData

local bag_resize
local bank_resize
local function NormalizeByConfig(value, config)
    local normalized = math.floor((tonumber(value) or config.defaultValue) + 0.5)
    return math.max(config.minValue, math.min(config.maxValue, normalized))
end

-- the bag and both bank frames offer the very same three sliders, only the setting
-- prefix differs, so the settings, their limits and their menu entries live in one table
local ITEM_SIZE_SETTINGS = {
    BAG = {
        {db = "bag", key = "itemSize", title = "Icon Size", config = BAG_ITEM_SIZE_CONFIG},
        {db = "bag", key = "itemSpacingX", title = "Slot Spacing X", config = BAG_ITEM_SPACING_X_CONFIG},
        {db = "bag", key = "itemSpacingY", title = "Slot Spacing Y", config = BAG_ITEM_SPACING_Y_CONFIG},
    },
    BANK = {
        {db = "bank", key = "itemSize", title = "Icon Size", config = BANK_ITEM_SIZE_CONFIG},
        {db = "bank", key = "itemSpacingX", title = "Slot Spacing X", config = BANK_ITEM_SPACING_X_CONFIG},
        {db = "bank", key = "itemSpacingY", title = "Slot Spacing Y", config = BANK_ITEM_SPACING_Y_CONFIG},
    },
}

-- acedb can hand out values from an older profile or from a detached default, so every
-- entry point clamps all six settings before anything is laid out with them
local function normalizeItemSizeSettings()
    for _, entries in next, ITEM_SIZE_SETTINGS do
        for _, entry in ipairs(entries) do
            GW.settings.bags[entry.db][entry.key] = NormalizeByConfig(GW.settings.bags[entry.db][entry.key], entry.config)
        end
    end
end

local function resizeInventory()
    normalizeItemSizeSettings()
    reskinItemButtons()
    if bag_resize then
        bag_resize()
    end
    if bank_resize then
        bank_resize()
    end
end


-- builds the icon size and slot spacing sliders of a bag or bank settings menu
local function addItemSizeMenuEntries(rootDescription, prefix)
    for _, entry in ipairs(ITEM_SIZE_SETTINGS[prefix]) do
        GW.AddMenuSliderDescription(rootDescription, {
            title = L[entry.title],
            minValue = entry.config.minValue,
            maxValue = entry.config.maxValue,
            step = entry.config.step,
            getValue = function() return GW.settings.bags[entry.db][entry.key] end,
            setValue = function(value)
                local normalized = NormalizeByConfig(value, entry.config)
                if GW.settings.bags[entry.db][entry.key] ~= normalized then
                    GW.settings.bags[entry.db][entry.key] = normalized
                    resizeInventory()
                end
                return normalized
            end
        })
    end
end


local function reskinBagBar(b, ha)
    local bag_size = 28
    local highlightAlpha = ha and ha or 0

    b:SetSize(bag_size, bag_size)
    b.tooltipText = BANK_BAG

    if b.Count then
        b.Count:ClearAllPoints()
        b.Count:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, -3)
        b.Count:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "THINOUTLINE")
        b.Count:SetJustifyH("RIGHT")
    end

    -- the retail bag bar buttons are round: drop the circle mask, restore the icons
    -- real Show method (blizzard overrides it there) and swap the round hud backpack
    -- art for the classic backpack icon
    if b.CircleMask then
        b.CircleMask:Hide()
    end
    if GW.isModern and b.icon then
        b.icon.Show = nil
        local tex = b.icon:GetTexture()
        if not tex or tex == 1721259 then
            b.icon:SetTexture(130716)
        end
    end
    if b.UpdateTextures and not b.gwUpdateTexturesHooked then
        -- blizzards UpdateTextures repaints the round slot art onto the normal,
        -- pushed and highlight textures on every item texture/quality update and
        -- the slot highlight ring stays shown since our bags are always open -
        -- restore our look after every repaint
        b.gwUpdateTexturesHooked = true
        hooksecurefunc(b, "UpdateTextures", function(self)
            local pushedTex = self:GetPushedTexture()
            if pushedTex then
                pushedTex:SetTexture("Interface/AddOns/GW2_UI/textures/uistuff/ui-quickslot-depress.png")
                pushedTex:SetAllPoints(self)
            end
            local highTex = self:GetHighlightTexture()
            if highTex then
                highTex:SetTexture(BORDER_TEXTURE)
                highTex:SetBlendMode("ADD")
                highTex:SetAlpha(0.33)
                highTex:SetAllPoints(self)
            end
            if self.SlotHighlightTexture then
                self.SlotHighlightTexture:SetTexture("Interface/AddOns/GW2_UI/textures/uistuff/ui-quickslot-depress.png")
                self.SlotHighlightTexture:SetAlpha(0)
            end
        end)

        b:UpdateTextures()
    end

    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    GW.HandleItemButtonCrop(b)
    b.icon:SetAlpha(0.75)
    b.icon:Show()

    local norm = b:GetNormalTexture()
    if norm and not norm.gwKilled then
        -- the round retail slot ring keeps coming back: blizzards UpdateTextures paints
        -- it with SetAtlas (not SetTexture), and hiding the texture does not stick either
        -- because the buttons state machine shows its normal texture again on every click
        -- and after the bag drop fly-in. So blank it at the source instead of fighting
        -- its visibility, and leave it shown but empty.
        norm.gwKilled = true
        local function blankNormalTexture(self)
            if self:GetTexture() or (self.GetAtlas and self:GetAtlas()) then
                self:SetTexture(nil)
            end
        end
        if norm.SetAtlas then
            hooksecurefunc(norm, "SetAtlas", blankNormalTexture)
        end
        hooksecurefunc(norm, "SetTexture", function(self, texture)
            if texture then
                blankNormalTexture(self)
            end
        end)
    end
    norm:SetTexture(nil)
    norm:SetAlpha(0)

    local pushed = b:GetPushedTexture()
    if pushed then
        pushed:SetTexture("Interface/AddOns/GW2_UI/textures/uistuff/ui-quickslot-depress.png")
        pushed:SetAllPoints(b)
    end

    b.IconBorder:SetAllPoints(b)
    b.IconBorder:SetTexture(BORDER_TEXTURE)
    b.IconBorder:SetVertexColor(1, 1, 1)
    b.IconBorder:Show()
    if not b.gwIconBorderHooked then
        -- compare the argument, not GetTexture: it does not necessarily hand back the
        -- path that was set, so a comparison against it never matches and the hook
        -- calls itself until the stack blows. The re-entrancy flag guards the rest.
        b.gwIconBorderHooked = true
        hooksecurefunc(b.IconBorder, "SetTexture", function(self, texture)
            if texture == BORDER_TEXTURE or b.gwSettingIconBorder then
                return
            end
            b.gwSettingIconBorder = true
            self:SetTexture(BORDER_TEXTURE)
            b.gwSettingIconBorder = false
        end)
    end

    local high = b:GetHighlightTexture()
    high:SetTexture(BORDER_TEXTURE)
    high:SetBlendMode("ADD")
    high:SetAlpha(0.33)
    high:SetSize(bag_size, bag_size)
    high:ClearAllPoints()
    high:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)

    if b.SlotHighlightTexture then
        b.SlotHighlightTexture:SetAlpha(highlightAlpha)
        b.SlotHighlightTexture:SetTexture("Interface/AddOns/GW2_UI/textures/uistuff/ui-quickslot-depress.png")
    end

    -- blizzard checks the bag slot buttons for every open bag and with us every bag is always
    -- open, so the yellow checked glow carries no information - kill it
    if b.GetCheckedTexture and b:GetCheckedTexture() then
        b:GetCheckedTexture():SetTexture(nil)
    end
end


-- reskins the default search boxes
local function reskinSearchBox(sb)
    if not sb then
        return
    end

    GW.SkinEditBox(sb, {search = true, noBackground = true})

    sb.Left:SetTexture(nil)
    sb.Right:SetTexture(nil)
    sb.Middle:SetTexture("Interface/AddOns/GW2_UI/textures/bag/bagsearchbg.png")
    -- blizzard hangs the middle on the left cap, the search icon has to sit inside it
    sb.Middle:ClearAllPoints()
    sb.Middle:SetPoint("LEFT", sb, "LEFT", 0, 0)
    sb.Middle:SetPoint("RIGHT", sb, "RIGHT", 0, 0)

    sb.Middle:SetHeight(24)
    sb.Middle:SetTexCoord(unpack(GW.TexCoords))
end
GW.SkinBagSearchBox = reskinSearchBox


-- (re)steals the default search boxes
local function relocateSearchBox(sb, f)
    if not sb or not f then
        return
    end

    sb:SetParent(f)
    sb:ClearAllPoints()
    -- in line with the item slots
    sb:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -40)
    sb:SetPoint("TOPRIGHT", f, "TOPRIGHT", -5, -40)
    sb:SetHeight(24)
end


-- on right click, open the bag filter dropdown (if valid) for this bag slot
local function AddButtons_BagFilters(description, bagID)

    description:CreateTitle(BAG_FILTER_ASSIGN_TO)

    local function IsSelected(flag)
        return C_Container.GetBagSlotFlag(bagID, flag)
    end

    local function SetSelected(flag)
        local value = not IsSelected(flag)
        C_Container.SetBagSlotFlag(bagID, flag, value)
    end

    local checkbox = description:CreateCheckbox(BAG_FILTER_IGNORE, IsSelected, SetSelected, LE_BAG_FILTER_FLAG_IGNORE_CLEANUP)
    checkbox:SetResponse(MenuResponse.Close)
end

local function bag_OnMouseDown(self, button)
    if button ~= "RightButton" or not self.gwHasBag or not ((self:GetID() - CharacterBag0Slot:GetID() + 1) > 0 and (self:GetID() - CharacterBag0Slot:GetID() + 1) < 5) then
        return
    end

    local bag_id = self:GetID() - CharacterBag0Slot:GetID() + 1
    MenuUtil.CreateContextMenu(self, function(ownerRegion, rootDescription)
        AddButtons_BagFilters(rootDescription, bag_id)
    end)
end
GW.BagSlotOnMouseDown = bag_OnMouseDown


-- positions ItemButtons fluidly for this container
local function layoutContainerFrame(cf, max_col, row, col, rev, item_off_x, item_off_y)
    if not cf or not cf.gw_num_slots or cf.gw_num_slots <= 0 then
        return col, row, false, 0
    end

    local unfinishedRow = false
    local startNewRow = false
    local finishedRows = 0
    local nS = cf.gw_num_slots
    local nE = 1
    local nD = -1
    if rev then
        nE = nS
        nS = 1
        nD = 1
    end

    for n = nS, nE, nD do
        local item = cf.gw_items[n]
        if item then
            -- gw_compact leaves the empty slots out of the flow entirely, the caller shows
            -- a single placeholder with the free slot count instead
            if cf.gw_compact and not item.hasItem then
                item:Hide()
            else
                item:Show()
                item:ClearAllPoints()
                item:SetPoint("TOPLEFT", cf, "TOPLEFT", col * item_off_x, -row * item_off_y)
                col = col + 1
                if col >= max_col then
                    col = 0
                    row = row + 1
                    finishedRows = finishedRows + 1
                    startNewRow = true
                end
            end
        end
    end

    if (startNewRow and col > 0 and col < max_col) or (not startNewRow and col < max_col) then
        unfinishedRow = true
    end

    return col, row, unfinishedRow, finishedRows
end


-- update the number of free bag slots available and set the display for it
local function updateFreeSlots(sp_str, start_idx, end_idx, opt_container)
    if not sp_str or not sp_str.SetText then
        return
    end

    local free = 0
    local full = 0
    if opt_container then
        free = C_Container.GetContainerNumFreeSlots(opt_container)
        full = C_Container.GetContainerNumSlots(opt_container)
    end

    for bag_id = start_idx, end_idx do
        free = free + C_Container.GetContainerNumFreeSlots(bag_id)
        full = full + C_Container.GetContainerNumSlots(bag_id)
    end

    sp_str:SetText((full - free) .. " / " .. full)
    return free, full
end


local function snapFrameSize(f, cfs, size, paddingX, paddingY, min_height)
    if not f then
        return
    end
    if not size or not paddingX or not paddingY then
        -- acedb can have the profile defaults detached (logout, profile operations)
        return
    end

    local isBag = f == GwBagFrame
    local cols = isBag and f.gw_bag_cols or f.gw_bank_cols
    local sep = isBag and GW.settings.bags.bag.separateBags or (not isBag and GW.settings.bags.bank.separateBags)

    if not cfs then
        f:SetHeight(min_height)
        return
    end

    local slots = 0
    if cfs.gw_num_slots then
        -- a single container was handed in (the retail bank panel)
        slots = cfs.gw_num_slots
    else
        for _, cf in pairs(cfs) do
            if cf.gw_num_slots then
                slots = slots + cf.gw_num_slots
            end
        end
    end

    local rows
    local isizeX = size + paddingX
    local isizeY = size + paddingY
    if isBag and f.gw_layout_rows then
        -- the bag layout stores the rows it actually used, headers, gaps and placeholders included
        rows = f.gw_layout_rows
    elseif sep and not isBag then
        -- one row per visible section header: main bank + equipped bank bags; the forever bank counts its own
        local headers = f.gw_bank_headers
        if not headers then
            headers = 1
            for i = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
                if GetInventoryItemID("player", C_Container.ContainerIDToInventoryID(i)) then
                    headers = headers + 1
                end
            end
        end
        f.finishedRow = f.finishedRow or 0
        f.unfinishedRow = f.unfinishedRow or 0
        rows = f.finishedRow + headers + f.unfinishedRow
    else
        rows = math.ceil(slots / cols)
    end
    f:SetHeight(max((isizeY * rows) + 75, min_height))
    local contentWidth = (isizeX * cols) - paddingX
    local frameWidth = contentWidth + CONTAINER_FRAME_SIDE_PADDING + CONTAINER_FRAME_RIGHT_PADDING + 2
    f:SetWidth(frameWidth)
end


local function onMoved(self, setting, snap_size)
    if not self then
        return
    end

    self:StopMovingOrSizing()
    -- check if frame is out of screen, if yes move it back
    ValidateFramePosition(self)

    local x = self:GetLeft()
    local y = self:GetTop()

    -- re-anchor to UIParent after the move
    self:ClearAllPoints()
    self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x, y)

    -- store the updated position
    if setting then
        local pos = GW.settings.bags[setting].pos
        if pos then
            wipe(pos)
        else
            pos = {}
        end
        pos.point = "TOPLEFT"
        pos.relativePoint = "BOTTOMLEFT"
        pos.xOfs = x
        pos.yOfs = y
        GW.settings.bags[setting].pos = pos
    end

    -- apply our snap sizing, if necessary
    if snap_size then
        snap_size(self)
    end
end


local function colCount(size, paddingX, width)
    local isize = size + paddingX
    return math.floor((width - CONTAINER_FRAME_SIDE_PADDING - CONTAINER_FRAME_RIGHT_PADDING + paddingX - 1) / isize)
end


local function onSizerMouseDown(self, btn)
    if btn ~= "LeftButton" then
        return
    end
    local bfm = self:GetParent()
    bfm:StartSizing("BOTTOMRIGHT")
end


local function onSizerMouseUp(self, btn)
    if btn ~= "LeftButton" then
        return
    end
    local bfm = self:GetParent()
    bfm:StopMovingOrSizing()
    if self.onResizeStop then
        self.onResizeStop(bfm)
    end
end


local function onMoverDragStart(self)
    self:GetParent():StartMoving()
end


local function onMoverDragStop(self)
    onMoved(self:GetParent(), self.onMoveSetting)
end


local function LoadInventory()
    _G["BINDING_HEADER_GW2UI_INVENTORY_BINDINGS"] = INVENTORY_TOOLTIP
    _G["BINDING_NAME_BAG_SORT"] = BAG_CLEANUP_BAGS
    _G["BINDING_NAME_BANK_SORT"] = BAG_CLEANUP_BANK

    BagsBar:GwKillEditMode()
    BagsBar:GwKill()

    -- make blizzards container frames inert once, we only use their open/close
    -- lifecycle as the bag state
    disableBlizzardContainers()

    -- apply the current size settings to any already created own item buttons
    reskinItemButtons()

    -- whenever an ItemButton sets its quality ensure our custom border is being used;
    -- resolved through GW so a flavor can override the skin (retail does)
    hooksecurefunc("SetItemButtonQuality", function(...)
        GW.SetBagItemButtonQualitySkin(...)
    end)

    local helpers = {}
    -- resolved through GW so a flavor can override it (retail does)
    helpers.bag_OnMouseDown = function(...) return GW.BagSlotOnMouseDown(...) end
    helpers.addItemSizeMenuEntries = addItemSizeMenuEntries
    helpers.reskinBagBar = reskinBagBar
    helpers.reskinSearchBox = reskinSearchBox
    helpers.relocateSearchBox = relocateSearchBox
    helpers.disableBlizzardFrame = disableBlizzardFrame
    helpers.layoutContainerFrame = layoutContainerFrame
    helpers.updateFreeSlots = updateFreeSlots
    helpers.snapFrameSize = snapFrameSize
    helpers.onMoved = onMoved
    helpers.colCount = colCount
    helpers.onSizerMouseDown = onSizerMouseDown
    helpers.onSizerMouseUp = onSizerMouseUp
    helpers.onMoverDragStart = onMoverDragStart
    helpers.onMoverDragStop = onMoverDragStop
    -- clamp every size setting once, before the two frames lay anything out with them
    normalizeItemSizeSettings()

    bag_resize = GW.LoadBag(helpers)
    bank_resize = GW.LoadBank(helpers)
    GW.LoadGuildBank()
end
GW.LoadInventory = LoadInventory
