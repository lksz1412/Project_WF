---@class GW2
local GW = select(2, ...)

local TIME_FOR_3 = 0.6
local TIME_FOR_2 = 0.8
local UI_WIDGET_TYPE_STATUS_BAR = 2
local UI_WIDGET_TYPE_DOUBLE_STATUS_BAR = 3
local UI_WIDGET_TYPE_SCENARIO_CURRENCIES = 11

-- Blizzards ShouldShowMawBuffs reads MAW auras unguarded and throws on secret auras, so the guarded
-- version below replaces it. Not with forever's gamepad interface: there the replaced global taints
-- blizzards tracker layout and that reaches the gamepad ui
if ShouldShowMawBuffs then
    -- our tracker renders its own Maw buff button: mute Blizzards container in
    -- the hidden default tracker — its display loop compares secret aura data
    -- (applications) and its updates are invisible anyway
    if ScenarioObjectiveTracker and ScenarioObjectiveTracker.MawBuffsBlock and ScenarioObjectiveTracker.MawBuffsBlock.Container then
        ScenarioObjectiveTracker.MawBuffsBlock.Container:UnregisterAllEvents()
    end

    local origShouldShowMawBuffs = ShouldShowMawBuffs
    local lastKnown = false
    function GW.ShouldShowMawBuffs()
        local ok, result = pcall(origShouldShowMawBuffs)
        if ok then
            lastKnown = result and true or false
            return lastKnown
        end
        -- secret state (e.g. in combat): the reads can only turn the button ON or
        -- keep it — the collected powers do not vanish mid fight
        local slotOk, _, slot = pcall(C_UnitAuras.GetAuraSlots, "player", "MAW", 1)
        if slotOk and slot ~= nil then
            lastKnown = true
        end
        return lastKnown
    end

    -- Maw aura enumeration via slot handles — works while aura data is secret;
    -- the returned aura tables may carry secret values (fine for setters/tooltips).
    -- Returns nil on a FAILED read (callers keep their last known set then)
    function GW.CollectMawAuras()
        local auras = {}
        local ok = pcall(function()
            local continuation
            repeat
                local results = { C_UnitAuras.GetAuraSlots("player", "MAW", 40, continuation) }
                continuation = results[1]
                for i = 2, #results do
                    local auraData = C_UnitAuras.GetAuraDataBySlot("player", results[i])
                    if auraData then
                        tinsert(auras, auraData)
                    end
                end
            until not continuation
        end)
        if not ok then
            return nil
        end
        return auras
    end

    if GW.isModern and not GW.IsGamepadInterface() then
        ShouldShowMawBuffs = GW.ShouldShowMawBuffs
    end
end

GwObjectivesScenarioContainerWidgetMixin = {}
GwObjectivesScenarioContainerMixin = {}
GwQuesttrackerScenarioBlockMixin = {}

-- Blizzards own scenario spell buttons run UpdateCooldown from layout chains that
-- can carry our taint: C_Spell.GetSpellCooldown then hands them secret values and
-- the comparisons in CooldownFrame_Set throw. The duration object route needs no
-- comparisons at all, so the mixin method is replaced before any button copies
-- it — this covers Blizzards pool buttons and our own action button (which mixes
-- this in on InitModule). Blizzard stores the id as self.spellID (capital D)
if GW.isModern and ScenarioSpellButtonMixin then
    function ScenarioSpellButtonMixin:UpdateCooldown()
        local durationObject = self.spellID and C_Spell.GetSpellCooldownDuration(self.spellID)
        if durationObject then
            self.Cooldown:SetCooldownFromDurationObject(durationObject)
        else
            self.Cooldown:Clear()
        end
    end
end

local function HasValidTimerData(widgetInfo)
    return type(widgetInfo) == "table"
        and type(widgetInfo.timerMin) == "number"
        and type(widgetInfo.timerMax) == "number"
        and type(widgetInfo.timerValue) == "number"
        and widgetInfo.timerMax > widgetInfo.timerMin
        and widgetInfo.timerValue > widgetInfo.timerMin
        and widgetInfo.timerValue <= widgetInfo.timerMax
end

local function IsRealTimerWidget(widgetInfo)
    return widgetInfo and widgetInfo.hasTimer and HasValidTimerData(widgetInfo)
end

local function IsFakeTimerWidget(widgetInfo)
    return widgetInfo and not widgetInfo.hasTimer and HasValidTimerData(widgetInfo)
end

local function IsScenarioCriteriaComplete(criteriaInfo)
    if not criteriaInfo then
        return false
    end

    if criteriaInfo.completed ~= nil then
        return criteriaInfo.completed
    end

    if criteriaInfo.quantity and criteriaInfo.totalQuantity and criteriaInfo.totalQuantity > 0 then
        return criteriaInfo.quantity >= criteriaInfo.totalQuantity
    end

    return false
end

function GwObjectivesScenarioContainerWidgetMixin:RemoveAllWidgets()
    self.widgetFrames = {}
    self.timerWidgets = {}
    self.numTimers = 0

    if self.ticker then
        self.ticker:Cancel()
        self.ticker = nil
    end

    self.widgetPools:ReleaseAll()
end

function GwObjectivesScenarioContainerWidgetMixin:RegisterTimerWidget(widgetID, widgetFrame)
    if not self.timerWidgets[widgetID] then
        -- New timer added
        self.timerWidgets[widgetID] = widgetFrame
        -- the timer and the status bar manager share a timer block, each runs its own ticker
        if not self.ticker then
            self.ticker = C_Timer.NewTicker(1,
                function()
                    for id, widget in pairs(self.timerWidgets) do
                        self:ProcessWidget(id, widget.widgetType)
                    end
                end)
        end

        self.numTimers = self.numTimers + 1
    end
end

function GwObjectivesScenarioContainerWidgetMixin:UnregisterTimerWidget(widgetID)
    if self.timerWidgets[widgetID] then
        -- Existing timer removed
        self.timerWidgets[widgetID] = nil

        self.numTimers = self.numTimers - 1

        if self.numTimers == 0 and self.ticker then
            self.ticker:Cancel()
            self.ticker = nil
        end

        if self.numTimers == 0 and self.layoutFunc and self.container then
            self.layoutFunc(self.container)
        end
    end
end

function GwObjectivesScenarioContainerWidgetMixin:RegisterFakeTimerWidget(widgetID, widgetFrame)
    if not self.timerWidgets[widgetID] then
        self.timerWidgets[widgetID] = widgetFrame
        self.numTimers = self.numTimers + 1
    end
end

function GwObjectivesScenarioContainerWidgetMixin:UnregisterFakeTimerWidget(widgetID)
    if self.timerWidgets[widgetID] then
        self.timerWidgets[widgetID] = nil
        self.numTimers = self.numTimers - 1

        if self.numTimers == 0 and self.layoutFunc and self.container then
            self.layoutFunc(self.container)
        end
    end
end

function GwObjectivesScenarioContainerWidgetMixin:SyncWidgetTimerRegistration(widgetID, widgetFrame, widgetInfo)
    local oldIsRealTimer = widgetFrame.isRealTimer
    local oldIsFakeTimer = widgetFrame.isFakeTimer
    local newIsRealTimer = IsRealTimerWidget(widgetInfo)
    local newIsFakeTimer = IsFakeTimerWidget(widgetInfo)

    if oldIsRealTimer and not newIsRealTimer then
        self:UnregisterTimerWidget(widgetID)
    elseif oldIsFakeTimer and not newIsFakeTimer then
        self:UnregisterFakeTimerWidget(widgetID)
    end

    if not oldIsRealTimer and newIsRealTimer then
        self:RegisterTimerWidget(widgetID, widgetFrame)
    elseif not oldIsFakeTimer and newIsFakeTimer then
        self:RegisterFakeTimerWidget(widgetID, widgetFrame)
    end

    widgetFrame.hasTimer = widgetInfo.hasTimer
    widgetFrame.isRealTimer = newIsRealTimer
    widgetFrame.isFakeTimer = newIsFakeTimer
end

function GwObjectivesScenarioContainerWidgetMixin:RemoveWidget(widgetID)
    local widgetFrame = self.widgetFrames[widgetID]
    if not widgetFrame then
        -- This widget was never created. Nothing to do
        return
    end

    -- If this is a widget with a timer, remove it from the timer list
    if widgetFrame.isRealTimer then
        self:UnregisterTimerWidget(widgetID)
    elseif widgetFrame.isFakeTimer then
        self:UnregisterFakeTimerWidget(widgetID)
    end

    self.widgetPools:Release(widgetFrame)
    self.widgetFrames[widgetID] = nil
end

function GwObjectivesScenarioContainerWidgetMixin:OnEvent(event, ...)
    if event == "UPDATE_ALL_UI_WIDGETS" then
        self:ProcessAllWidgets()
    elseif event == "UPDATE_UI_WIDGET" then
        local widgetInfo = ...
        if self:IsRegisteredForWidgetSet(widgetInfo.widgetSetID) then
            self:ProcessWidget(widgetInfo.widgetID, widgetInfo.widgetType)
        end
    end
end

function GwObjectivesScenarioContainerWidgetMixin:IsRegisteredForWidgetSet(widgetSetID)
    if widgetSetID then
        return self.widgetSetID == widgetSetID
    else
        return self.widgetSetID ~= nil
    end
end

function GwObjectivesScenarioContainerWidgetMixin:GetWidgetFromPools(templateInfo)
    if templateInfo then
        return self.widgetPools:Acquire()
    end
end

function GwObjectivesScenarioContainerWidgetMixin:CreateWidget(widgetID, widgetType, widgetTypeInfo, widgetInfo)
    local widgetFrame = self:GetWidgetFromPools(widgetTypeInfo.templateInfo)

    widgetFrame.widgetID = widgetID
    widgetFrame.widgetSetID = self.widgetSetID
    widgetFrame.widgetType = widgetType
    widgetFrame.isRealTimer = false
    widgetFrame.isFakeTimer = false
    self:SyncWidgetTimerRegistration(widgetID, widgetFrame, widgetInfo)

    self.widgetFrames[widgetID] = widgetFrame

    return widgetFrame
end

function GwObjectivesScenarioContainerWidgetMixin:HandleTimer(timerBlock, widgetInfo)
    if widgetInfo.shownState ~= Enum.WidgetShownState.Hidden then
        local timerValue = Clamp(widgetInfo.timerValue, widgetInfo.timerMin, widgetInfo.timerMax)
        local timeRemaining = timerValue - widgetInfo.timerMin
        local timerText = SecondsToClock(timeRemaining)

        timerBlock.timer:SetMinMaxValues(widgetInfo.timerMin, widgetInfo.timerMax)
        timerBlock.timer:SetValue(timerValue)
        timerBlock.timerString:SetText(timerText)

        timerBlock.timer:Show()
    else
        timerBlock.timer:SetShown(timerBlock.needToShowTimer)
        if not timerBlock.needToShowTimer then
            timerBlock.height = 1
        end
    end
end

function GwObjectivesScenarioContainerWidgetMixin:IsTimerRunning()
    return (self.numTimers or 0) > 0
end

function GwObjectivesScenarioContainerWidgetMixin:ProcessWidget(widgetID, widgetType)
    local widgetTypeInfo = UIWidgetManager:GetWidgetTypeInfo(widgetType)
    if not widgetTypeInfo then
        -- This WidgetType is not supported (nothing called RegisterWidgetVisTypeTemplate for it)
        return
    end

    local widgetInfo = widgetTypeInfo.visInfoDataFunction(widgetID)
    local widgetFrame = self.widgetFrames[widgetID]
    local widgetAlreadyExisted = (widgetFrame ~= nil)

    if widgetAlreadyExisted and widgetFrame.widgetType ~= widgetType then
        -- This widget existed already but the type has changed, so release the old widget frame and treat it as a brand new widget
        self:RemoveWidget(widgetID)
        widgetAlreadyExisted = false
    end
    local isNewWidget = false
    if widgetAlreadyExisted then
        if not widgetInfo then
            self:RemoveWidget(widgetID)
            return
        end

        self:SyncWidgetTimerRegistration(widgetID, widgetFrame, widgetInfo)
    else
        -- Widget did not already exist
        if widgetInfo then
            -- And it should be shown...create it
            widgetFrame = self:CreateWidget(widgetID, widgetType, widgetTypeInfo, widgetInfo)
            isNewWidget = true
        else
            -- Widget should not be shown. It didn't already exist so there is nothing to do
            return
        end
    end
    if widgetFrame.isRealTimer or widgetFrame.isFakeTimer then
        self:HandleTimer(self.timerBlock, widgetInfo)
    elseif widgetInfo and self.handlesCurrencyWidgets and widgetType == UI_WIDGET_TYPE_SCENARIO_CURRENCIES then
        wipe(self.widgetInfoForCurrency)
        tinsert(self.widgetInfoForCurrency, widgetInfo)
        if self.layoutFunc then
            self.layoutFunc(self.container)
        end
        return
    elseif widgetInfo and self.handlesStatusBarWidgets and (widgetType == UI_WIDGET_TYPE_STATUS_BAR or widgetType == UI_WIDGET_TYPE_DOUBLE_STATUS_BAR) then
        wipe(self.widgetInfoForStatusBar)
        tinsert(self.widgetInfoForStatusBar, widgetInfo)
        if self.layoutFunc then
            self.layoutFunc(self.container)
        end
        return
    end

    if isNewWidget or widgetFrame.isFakeTimer then
        if self.layoutFunc then
            self.layoutFunc(self.container)
        end
    end
end

function GwObjectivesScenarioContainerWidgetMixin:ProcessAllWidgets()
    local setWidgets = C_UIWidgetManager.GetAllWidgetsBySetID(self.widgetSetID)
    for _, widgetInfo in ipairs(setWidgets) do
        self:ProcessWidget(widgetInfo.widgetID, widgetInfo.widgetType)
    end

    if self.layoutFunc then
        self.layoutFunc(self.container)
    end
end

function GwObjectivesScenarioContainerWidgetMixin:UnregisterForWidgetSet()
    if not self.widgetSetID then
        -- We are not registered to a WidgetSet...nothing to do
        return
    end

    self:RemoveAllWidgets()

    self.widgetSetID = nil
    self.widgetID = nil
    self.layoutFunc = nil
    wipe(self.widgetInfoForStatusBar)
    wipe(self.widgetInfoForCurrency)

    self:UnregisterEvent("UPDATE_ALL_UI_WIDGETS")
    self:UnregisterEvent("UPDATE_UI_WIDGET")
end

function GwObjectivesScenarioContainerWidgetMixin:RegisterForWidgetSet(widgetSetID)
    if self.widgetSetID then
        -- We are already registered to a WidgetSet
        if self.widgetSetID == widgetSetID then
            -- And it's the same WidgetSet we are trying to register again...nothing to do
            return
        else
            -- We are already registered for a different WidgetSet...unregister it
            self:UnregisterForWidgetSet()
        end
    end

    if not widgetSetID then
        return
    end

    self.widgetSetID = widgetSetID
    self.layoutFunc = self.container.QueueUpdateLayout
    self.widgetFrames = {}
    self.timerWidgets = {}
    self.widgetInfoForStatusBar = {}
    self.widgetInfoForCurrency = {}
    self.numTimers = 0

    self:ProcessAllWidgets()

    self:RegisterEvent("UPDATE_ALL_UI_WIDGETS")
    self:RegisterEvent("UPDATE_UI_WIDGET")
end

local function CreateScenarioWidgetManager(container, handlesStatusBarWidgets, handlesCurrencyWidgets)
    local widgetManager = CreateFrame("Frame")
    Mixin(widgetManager, GwObjectivesScenarioContainerWidgetMixin)
    widgetManager.widgetPools = CreateFramePool("Frame")
    widgetManager:SetScript("OnEvent", widgetManager.OnEvent)
    widgetManager.timerBlock = container.timerBlock
    widgetManager.container = container
    widgetManager.handlesStatusBarWidgets = handlesStatusBarWidgets
    widgetManager.handlesCurrencyWidgets = handlesCurrencyWidgets

    return widgetManager
end

function GwObjectivesScenarioContainerMixin:ClearWidgetSet()
    self:UpdateWidgetRegistration()
end

-- both managers share the timer block and classify timers purely by widget data,
-- so a timer can be driven from either widget set
function GwObjectivesScenarioContainerMixin:HasRunningWidgetTimer()
    return self.timerWidgetManager:IsTimerRunning() or self.statusBarWidgetManager:IsTimerRunning()
end

function GwObjectivesScenarioContainerMixin:UpdateWidgetRegistration(widgetSetID)
    self.timerWidgetManager:RegisterForWidgetSet(widgetSetID)
    if widgetSetID ~= nil then
        self.statusBarWidgetManager:RegisterForWidgetSet(514)
    else
        self.statusBarWidgetManager:RegisterForWidgetSet()
    end
end

-- Rows that the scenario fills itself (currency, trait icons, maw buffs, spell rows)
-- sit closer to the block top and a bit further apart than AddObjective rows. Used as
-- the first row origin AND as the gap between rows, so both are the same number.
local CUSTOM_ROW_Y_OFFSET = -5

-- aligns the secure item button with the first row of the scenario block
local SCENARIO_ITEM_BUTTON_TOP_OFFSET = 20

-- the Blizzard scenario tracker renders a FIXED bottom widget set besides the
-- per-step set — the Torghast blessing/torment rows live there. Rendered with
-- own visuals: GW font labels plus the trait icon tiles.
local SCENARIO_BOTTOM_WIDGET_SET = 252
local function CollectScenarioSpellRows()
    local rows
    local ok = pcall(function()
        for _, widget in ipairs(C_UIWidgetManager.GetAllWidgetsBySetID(SCENARIO_BOTTOM_WIDGET_SET) or {}) do
            if widget.widgetType == Enum.UIWidgetVisualizationType.TextWithState then
                local info = C_UIWidgetManager.GetTextWithStateWidgetVisualizationInfo(widget.widgetID)
                if info and info.shownState ~= Enum.WidgetShownState.Hidden and info.text and info.text ~= "" then
                    rows = rows or {}
                    tinsert(rows, { text = info.text, orderIndex = info.orderIndex or 0 })
                end
            elseif widget.widgetType == Enum.UIWidgetVisualizationType.SpellDisplay then
                local info = C_UIWidgetManager.GetSpellDisplayVisualizationInfo(widget.widgetID)
                if info and info.spellInfo and info.spellInfo.shownState ~= Enum.WidgetShownState.Hidden and info.spellInfo.spellID then
                    rows = rows or {}
                    tinsert(rows, { spellID = info.spellInfo.spellID, orderIndex = info.orderIndex or 0 })
                end
            end
        end
    end)
    if not ok then
        return nil
    end
    -- GetAllWidgetsBySetID returns the widgets unsorted — the orderIndex carries
    -- the display order (label, its spells, next label, ...)
    if rows then
        table.sort(rows, function(a, b)
            return a.orderIndex < b.orderIndex
        end)
    end
    return rows
end

local SPELL_ROW_ICON_SIZE = 32
local SPELL_ROW_SPACING = 6
local SPELL_ROW_ICON_INDENT = 20 -- icons align with the objective text, labels with the headers
-- /run GW.DumpScenarioBlocks() — objective row geometry for layout debugging
function GW.DumpScenarioBlocks()
    local container = GwQuesttrackerContainerScenario
    local block = container and container.block
    if not block then
        print("scenario block not found")
        return
    end
    print(format("block: height=%d numObjectives=%d frameHeight=%d top=%d bottom=%d",
        block.height or -1, block.numObjectives or -1, block:GetHeight(), block:GetTop() or -1, block:GetBottom() or -1))
    for i, objectiveBlock in ipairs(block.objectiveBlocks or {}) do
        local text = objectiveBlock.ObjectiveText and objectiveBlock.ObjectiveText:GetText() or ""
        print(format("  [%d] shown:%s h:%d textH:%d top:%d bar:%s text:%s", i, tostring(objectiveBlock:IsShown()),
            objectiveBlock:GetHeight(), objectiveBlock.ObjectiveText and objectiveBlock.ObjectiveText:GetHeight() or -1,
            objectiveBlock:GetTop() or -1, tostring(objectiveBlock.StatusBar:IsShown()), text:sub(1, 20)))
    end
    if container.gwSpellRows then
        print(format("spellRows: shown:%s h:%d top:%d bottom:%d", tostring(container.gwSpellRows:IsShown()),
            container.gwSpellRows:GetHeight(), container.gwSpellRows:GetTop() or -1, container.gwSpellRows:GetBottom() or -1))
    end
end

local function UpdateScenarioSpellRowsFrame(frame, rows)
    for _, label in ipairs(frame.labels) do
        label:Hide()
    end
    frame.iconPool:ReleaseAll()

    local width = frame:GetWidth()
    local y, x = 0, nil
    local labelIndex = 0
    for _, row in ipairs(rows) do
        if row.text then
            if x then -- close an open icon line
                y = y + SPELL_ROW_ICON_SIZE + SPELL_ROW_SPACING
                x = nil
            end
            labelIndex = labelIndex + 1
            local label = frame.labels[labelIndex]
            if not label then
                label = frame:CreateFontString(nil, "ARTWORK")
                label:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "SHADOW")
                label:SetTextColor(1, 1, 1)
                label:SetJustifyH("LEFT")
                frame.labels[labelIndex] = label
            end
            label:ClearAllPoints()
            label:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -y)
            label:SetText(row.text)
            label:Show()
            -- measure instead of assuming: the tracker font size is configurable
            y = y + math.max(label:GetStringHeight() or 0, 12) + SPELL_ROW_SPACING
        elseif row.spellID then
            if x and width > 0 and (x + SPELL_ROW_ICON_SIZE) > width then
                y = y + SPELL_ROW_ICON_SIZE + SPELL_ROW_SPACING
                x = nil
            end
            x = x or SPELL_ROW_ICON_INDENT
            local tile = frame.iconPool:Acquire()
            tile:ClearAllPoints()
            tile:SetPoint("TOPLEFT", frame, "TOPLEFT", x, -y)
            tile.Icon:SetTexture(C_Spell.GetSpellTexture(row.spellID))
            tile.spellID = row.spellID
            tile.auraInstanceID = nil
            if not tile.mask then
                tile.mask = tile:CreateMaskTexture()
                tile.mask:SetAllPoints(tile.Icon)
                tile.mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
                tile.Icon:AddMaskTexture(tile.mask)
            end
            tile:Show()
            x = x + SPELL_ROW_ICON_SIZE + SPELL_ROW_SPACING
        end
    end
    if x then
        y = y + SPELL_ROW_ICON_SIZE
    end

    frame:SetHeight(math.max(y, 1))
    return y
end

local function PrepareScenarioCustomObjectiveBlock(objectiveBlock, height)
    objectiveBlock:SetHeight(height)
    objectiveBlock.ObjectiveText:SetText("")
    objectiveBlock.ObjectiveText:SetHeight(height)
    objectiveBlock.StatusBar:Hide()
    objectiveBlock.TimerBar:Hide()
    objectiveBlock.TimerBar:SetScript("OnUpdate", nil)
    objectiveBlock:SetCompletedLineState(false)
    objectiveBlock:Show()
end

local function AddScenarioCurrencyObjective(block, widgetInfo)
    if not widgetInfo or widgetInfo.shownState == Enum.WidgetShownState.Hidden or not widgetInfo.currencies or #widgetInfo.currencies == 0 then
        return false
    end

    block.numObjectives = block.numObjectives + 1
    local objectiveBlock = block:GetObjectiveBlock(block.numObjectives, block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET, CUSTOM_ROW_Y_OFFSET)

    PrepareScenarioCustomObjectiveBlock(objectiveBlock, block.currenciesFrame:GetHeight())

    block.currenciesFrame:SetParent(objectiveBlock)
    block.currenciesFrame:ClearAllPoints()
    block.currenciesFrame:SetPoint("TOPRIGHT", objectiveBlock, "TOPRIGHT", 0, 0)
    block.currenciesFrame:Show()

    for idx, currency in ipairs(widgetInfo.currencies) do
        if idx == 6 then break end

        local currencyFrame = block.currenciesFrame.currency[idx]
        currencyFrame.counter:SetText(currency.text)
        currencyFrame.icon:SetTexture(currency.iconFileID)
        if not currencyFrame.mask then
            currencyFrame.mask = currencyFrame:CreateMaskTexture()
            currencyFrame.mask:SetAllPoints(currencyFrame.icon)
            currencyFrame.mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
            currencyFrame.icon:AddMaskTexture(currencyFrame.mask)
        end
        currencyFrame.tooltip = currency.tooltip
        currencyFrame:Show()
    end

    block:AccountObjectiveRow(objectiveBlock, CUSTOM_ROW_Y_OFFSET)

    return true
end

-- own GW rendering for the fixed bottom widget set (blessing/torment labels + tiles)
local function AddScenarioSpellRowsObjective(block, container)
    local frame = container.gwSpellRows -- created in InitModule (retail only)
    if not frame then
        return false
    end

    local rows = CollectScenarioSpellRows()
    if not rows or #rows == 0 then
        frame:Hide()
        return false
    end

    block.numObjectives = block.numObjectives + 1
    local objectiveBlock = block:GetObjectiveBlock(block.numObjectives, block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET, CUSTOM_ROW_Y_OFFSET)

    frame:SetParent(objectiveBlock)
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", objectiveBlock, "TOPLEFT", 5, 0)
    frame:SetPoint("TOPRIGHT", objectiveBlock, "TOPRIGHT", -10, 0)

    local height = UpdateScenarioSpellRowsFrame(frame, rows)
    PrepareScenarioCustomObjectiveBlock(objectiveBlock, height + GW.GetObjectivesEntrySpacing())
    frame:Show()

    block:AccountObjectiveRow(objectiveBlock, CUSTOM_ROW_Y_OFFSET)

    return true
end

-- widget status bars can carry partition markers (e.g. the Torghast empowerment
-- threshold) — thin ticks on the objective progress bar. Values can be secret,
-- a failed placement just skips the ticks
local function UpdateStatusBarPartitions(statusBar, widgetInfo)
    if statusBar.gwPartitions then
        for _, tick in ipairs(statusBar.gwPartitions) do
            tick:Hide()
        end
    end

    pcall(function()
        local values = widgetInfo and widgetInfo.partitionValues
        if not values or #values == 0 or not widgetInfo.barMax or widgetInfo.barMax <= (widgetInfo.barMin or 0) then
            return
        end

        statusBar.gwPartitions = statusBar.gwPartitions or {}
        local barMin = widgetInfo.barMin or 0
        local width = statusBar:GetWidth()
        for i, value in ipairs(values) do
            local tick = statusBar.gwPartitions[i]
            if not tick then
                tick = statusBar:CreateTexture(nil, "OVERLAY")
                tick:SetColorTexture(1, 1, 1, 0.9)
                statusBar.gwPartitions[i] = tick
            end
            local fraction = (value - barMin) / (widgetInfo.barMax - barMin)
            if fraction > 0 and fraction < 1 and width > 0 then
                tick:SetSize(3, statusBar:GetHeight() + 4)
                tick:ClearAllPoints()
                tick:SetPoint("CENTER", statusBar, "LEFT", fraction * width, 0)
                tick:Show()
            end
        end
    end)
end

local function AddScenarioTieredEntranceTraitsObjective(block)
    if not (GW.isModern and C_ScenarioInfo.IsTieredEntranceScenario()) then
        return false
    end

    local spells = C_ScenarioInfo.GetTieredEntranceActiveSpells()
    if not spells then
        return false
    end

    block.numObjectives = block.numObjectives + 1
    local objectiveBlock = block:GetObjectiveBlock(block.numObjectives, block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET, CUSTOM_ROW_Y_OFFSET)

    block.tieredEntranceTraitsFrame:SetSpells(spells)
    PrepareScenarioCustomObjectiveBlock(objectiveBlock, block.tieredEntranceTraitsFrame:GetHeight() + GW.GetObjectivesEntrySpacing())

    block.tieredEntranceTraitsFrame:SetParent(objectiveBlock)
    block.tieredEntranceTraitsFrame:ClearAllPoints()
    block.tieredEntranceTraitsFrame:SetPoint("TOPRIGHT", objectiveBlock, "TOPRIGHT", -10, 0)
    block.tieredEntranceTraitsFrame:Show()

    block:AccountObjectiveRow(objectiveBlock, CUSTOM_ROW_Y_OFFSET)

    return true
end

local function AddScenarioMawBuffsObjective(block)
    if not (GW.ShouldShowMawBuffs and GW.ShouldShowMawBuffs()) then
        block.mawBuffsFrame:Hide()
        return false
    end

    block.numObjectives = block.numObjectives + 1
    local objectiveBlock = block:GetObjectiveBlock(block.numObjectives, block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET, CUSTOM_ROW_Y_OFFSET)

    -- a failed read (secret state) keeps the last known power set
    local auras = GW.CollectMawAuras() or block.mawBuffsFrame.auras or {}
    block.mawBuffsFrame:SetAuras(auras, JAILERS_TOWER_BUFFS_BUTTON_TEXT)
    PrepareScenarioCustomObjectiveBlock(objectiveBlock, block.mawBuffsFrame:GetHeight() + GW.GetObjectivesEntrySpacing())

    block.mawBuffsFrame:SetParent(objectiveBlock)
    block.mawBuffsFrame:ClearAllPoints()
    block.mawBuffsFrame:SetPoint("TOPRIGHT", objectiveBlock, "TOPRIGHT", -10, 0)
    block.mawBuffsFrame:Show()

    block:AccountObjectiveRow(objectiveBlock, CUSTOM_ROW_Y_OFFSET)

    return true
end

local function ScenarioContainerLayoutRunnerOnUpdate(frame)
    frame:SetScript("OnUpdate", nil)

    local container = frame.container
    container.layoutQueued = false
    container:UpdateLayout()
end

function GwObjectivesScenarioContainerMixin:QueueUpdateLayout(event, ...)
    if event == "JAILERS_TOWER_LEVEL_UPDATE" then
        local level, type, textureKit = ...
        self.jailersTowerLevelUpdateInfo = {level = level, type = type, textureKit = textureKit}
    end

    if self.layoutQueued then
        return
    end

    self.layoutQueued = true
    self.layoutUpdateFrame:SetScript("OnUpdate", ScenarioContainerLayoutRunnerOnUpdate)
end

function GwObjectivesScenarioContainerMixin:UpdateLayout()
    local compassData = {type = GW.Enum.ObjectivesNotificationType.Scenario, title = "Unknown Scenario"}

    local block = self.block
    local timerBlock = self.timerBlock
    local _, _, numStages, _, _, _, _, _, _, _, _, _, scenarioID = C_Scenario.GetInfo()
    local name, instanceType, difficultyID, difficultyName = GetInstanceInfo()
    local isDelveScenario = GW.Retail and difficultyID == 208

    local hasNoScenario = numStages == 0 or (GW.Retail and IsOnGroundFloorInJailersTower())

    -- The timer frame stays up for a challenge mode timer or a still registered
    -- scenario widget timer. A widget that disappears without a Hidden update never
    -- runs HandleTimer, so the frame would stay shown and its height gets folded
    -- into the block below - the container then keeps that height with nothing in
    -- it, which pushes every container after it down (empty gap in the tracker).
    if not timerBlock.needToShowTimer and (hasNoScenario or not self:HasRunningWidgetTimer()) then
        timerBlock.timer:Hide()
        timerBlock.height = 1
        timerBlock:SetHeight(timerBlock.height)
    end

    block.height = 0.1

    if timerBlock.timer:IsShown() then
        block.height = timerBlock.height
    end
    block.height = block.height + self.groupInfoBar:GetLayoutHeight()

    block.numObjectives = 0
    block.questLogIndex = 0
    -- origin of the first objective row; the delve branch moves it further down when
    -- the icon row needs its own space (see there)
    block.gwFirstRowYOffset = CUSTOM_ROW_Y_OFFSET
    block.groupButton:Hide()
    block.delvesFrame:Hide()
    block.currenciesFrame:Hide()
    for i = 1, 5 do
        block.currenciesFrame.currency[i]:Hide()
    end
    block.tieredEntranceTraitsFrame:Hide()

    if not isDelveScenario then
        GW.StopNemesisCounter()
    end
    block:Show()
    if hasNoScenario then
        if instanceType == "raid" then
            compassData.title = name
            compassData.desc = difficultyName
            GwObjectivesNotification:SetNotification("scenario", compassData)
            block.height = block.height + 5
        else
            GwObjectivesNotification:SetNotification("scenario", nil)
            block:Hide()
        end

        GW.CombatQueue:Queue("update_tracker_scenario_itembutton", block.UpdateObjectiveActionButton, {block})
        if block.hasItem then
            block.fromContainerTopHeight = block.height
            GW.CombatQueue:Queue("update_tracker_scenario_itembutton_position", block.UpdateObjectiveActionButtonPosition, {block})
        end

        for i = (block.numObjectives or 0) + 1, #block.objectiveBlocks do
            block.objectiveBlocks[i]:Hide()
        end

        block:SetHeight(block.height)
        -- bottom margin only when something is actually on screen (raid notification
        -- block or a still running timer), an empty container stays collapsed
        if block:IsShown() or timerBlock.timer:IsShown() then
            self:SetHeight(block.height + GW.GetObjectivesBlockGap())
        else
            self:SetHeight(block.height)
        end
        self:ClearWidgetSet()

        return
    end

    local stageName, stageDescription, numCriteria, _, _, _, _, _, allSpellInfo, _, questID, widgetSetID = C_Scenario.GetStepInfo()
    self:UpdateWidgetRegistration(widgetSetID)
    local isMythicKeystone = difficultyID == 8
    stageDescription = stageDescription or ""
    stageName = stageName or ""
    if difficultyName then
        local level = GW.Retail and C_ChallengeMode.GetActiveKeystoneInfo() or 0
        if level > 0 then
            compassData.title = stageName .. " |cFFFFFFFF +" .. level .. " " .. difficultyName .. "|r"
        else
            compassData.title = stageName .. " |cFFFFFFFF " .. difficultyName .. "|r"
        end
        compassData.desc = stageDescription .. " "
    end

    if GW.Retail and IsInJailersTower() then
        local floor = ""
        local widgetInfo = C_UIWidgetManager.GetScenarioHeaderCurrenciesAndBackgroundWidgetVisualizationInfo(3302)
        if widgetInfo then floor = widgetInfo.headerText or "" end

        if self.jailersTowerLevelUpdateInfo and self.jailersTowerLevelUpdateInfo.type then
            local typeString = C_ScenarioInfo.GetJailersTowerTypeString(self.jailersTowerLevelUpdateInfo.type)
            if typeString then
                compassData.title = difficultyName .. " |cFFFFFFFF " .. floor .. " - " .. typeString .. "|r"
            else
                compassData.title = difficultyName .. " |cFFFFFFFF " .. floor .. "|r"
            end
        else
            compassData.title = difficultyName .. " |cFFFFFFFF " .. floor .. "|r"
        end

        compassData.type = GW.Enum.ObjectivesNotificationType.Torghast
    end

    -- check for active delves
    local delvesWidgetInfo = isDelveScenario and C_UIWidgetManager.GetScenarioHeaderDelvesWidgetVisualizationInfo(6183)
    if delvesWidgetInfo and delvesWidgetInfo.frameTextureKit == "delves-scenario" then
        local tierLevel = delvesWidgetInfo.tierText or ""
        GwObjectivesNotification.iconFrame.tooltipSpellID = delvesWidgetInfo.tierTooltipSpellID
        compassData.title = difficultyName .. " |cFFFFFFFF(" .. tierLevel .. ")|r - " .. delvesWidgetInfo.headerText
        block.delvesFrame:Show()
        -- without a stage description the icon row floats in the notifications empty
        -- lower half (InitModule anchor, +35). WITH one that space holds the description
        -- text - the row then gets its own slot at the top of the block and pushes the
        -- objective rows down by its height
        block.delvesFrame:ClearAllPoints()
        if strtrim(stageDescription) ~= "" then
            block.delvesFrame:SetPoint("TOPRIGHT", block, "TOPRIGHT", 0, 0)
            block.gwFirstRowYOffset = CUSTOM_ROW_Y_OFFSET - block.delvesFrame:GetHeight()
        else
            block.delvesFrame:SetPoint("TOPRIGHT", GwObjectivesNotification, "BOTTOMRIGHT", 0, 35)
        end
        block.delvesFrame.reward:Show()
        local id = 1
        for _, spellInfo in ipairs(delvesWidgetInfo.spells) do
            if spellInfo.shownState ~= Enum.WidgetShownState.Hidden then
                local spellData = C_Spell.GetSpellInfo(spellInfo.spellID)
                local spellBlock = block.delvesFrame.spell[id]

                if spellInfo.spellID == 1307638 then -- Chest icon
                    spellBlock.icon:SetTexture("Interface/AddOns/GW2_UI/textures/icons/chest.png")
                    GW.RequestNemesisCounterUpdate(spellBlock)
                else
                    spellBlock.icon:SetTexture(spellData.iconID)
                    spellBlock.notification.Text:SetText("")
                    spellBlock.notification:Hide()
                end

                if not spellBlock.mask then
                    spellBlock.mask = spellBlock:CreateMaskTexture()
                    spellBlock.mask:SetAllPoints(spellBlock.icon)
                    spellBlock.mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
                    spellBlock.icon:AddMaskTexture(spellBlock.mask)
                end
                spellBlock.icon:SetDesaturated(spellInfo.enabledState == Enum.WidgetEnabledState.Disabled)
                spellBlock.spellID = spellData.spellID
                spellBlock:Show()
                id = id + 1
            end
        end

        for i = id, 5 do
            block.delvesFrame.spell[i].spellID = nil
            block.delvesFrame.spell[i].notification:Hide()
            block.delvesFrame.spell[i]:Hide()
        end

        -- handle death
        if delvesWidgetInfo.currencies and #delvesWidgetInfo.currencies > 0 and delvesWidgetInfo.currencies[1].textEnabledState > 0 then
            block.delvesFrame.deathCounter.tooltip = delvesWidgetInfo.currencies[1].tooltip
            block.delvesFrame.deathCounter.counter:SetText(delvesWidgetInfo.currencies[1].text)
            block.delvesFrame.deathCounter.icon:SetTexture(delvesWidgetInfo.currencies[1].iconFileID)
            block.delvesFrame.deathCounter:Show()
        else
            block.delvesFrame.deathCounter:Hide()
        end

        -- handle rewards
        if delvesWidgetInfo.rewardInfo.shownState ~= Enum.UIWidgetRewardShownState.Hidden then
            local rewardTooltip = (delvesWidgetInfo.rewardInfo.shownState == Enum.UIWidgetRewardShownState.ShownEarned) and delvesWidgetInfo.rewardInfo.earnedTooltip or delvesWidgetInfo.rewardInfo.unearnedTooltip
            block.delvesFrame.reward.tooltip = rewardTooltip
            block.delvesFrame.reward.earned:SetShown(delvesWidgetInfo.rewardInfo.shownState == Enum.UIWidgetRewardShownState.ShownEarned)
            block.delvesFrame.reward.unearned:SetShown(delvesWidgetInfo.rewardInfo.shownState == Enum.UIWidgetRewardShownState.ShownUnearned)
            block.delvesFrame.reward:Show()
        else
            block.delvesFrame.reward:Hide()
        end

        compassData.type = GW.Enum.ObjectivesNotificationType.Delve
    end

    block:SetBlockColorByKey(compassData.type)
    block.Header:SetTextColor(block.color.r, block.color.g, block.color.b)
    block.hover:SetVertexColor(block.color.r, block.color.g, block.color.b)
    GwObjectivesNotification:SetNotification("scenario", compassData)

    if questID then
        block.questLogIndex = (GW.Retail and C_QuestLog.GetLogIndexForQuestID or GetQuestLogIndexByID)(questID)
    end

    --check for groupfinder button and add spells
    if GW.isModern then
        block:UpdateFindGroupButton(scenarioID, true)
        GW.CombatQueue:Queue("update_tracker_scenario_spell", block.UpdateScenarioSpell, {block, allSpellInfo})
    end

    local objectiveOptions = {
        finished = false,
        useCompletedLine = true,
        scenarioObjective = true,
        objectiveType = "monster",
        qty = 0,
        isMythicKeystone = false,
        firstObjectivesYValue = block.gwFirstRowYOffset,
    }

    for _, widgetInfo in ipairs( self.timerWidgetManager.widgetInfoForCurrency or {} ) do
        if AddScenarioCurrencyObjective(block, widgetInfo) then
            break
        end
    end
    AddScenarioTieredEntranceTraitsObjective(block)
    AddScenarioMawBuffsObjective(block)
    AddScenarioSpellRowsObjective(block, self)

    for _, row in ipairs(block.objectiveBlocks) do
        GW.SetObjectiveTimeText(row, nil)
    end
    for criteriaIndex = 1, numCriteria do
        local scenarioCriteriaInfo = C_ScenarioInfo.GetCriteriaInfo(criteriaIndex)
        if scenarioCriteriaInfo then
            local objectiveType = scenarioCriteriaInfo.isWeightedProgress and "progressbar" or "monster"

            if objectiveType == "progressbar" and not isMythicKeystone then
                scenarioCriteriaInfo.totalQuantity = 100
            end

            local mythicKeystoneCurrentValue = 0
            if isMythicKeystone then
                mythicKeystoneCurrentValue = tonumber(string.match(scenarioCriteriaInfo.quantityString, "%d+")) or 1
            end
            objectiveOptions.finished = IsScenarioCriteriaComplete(scenarioCriteriaInfo)
            objectiveOptions.objectiveType = objectiveType
            objectiveOptions.qty = scenarioCriteriaInfo.quantity
            objectiveOptions.isMythicKeystone = isMythicKeystone
            block:AddObjective(GW.ParseCriteria(scenarioCriteriaInfo.quantity, scenarioCriteriaInfo.totalQuantity, scenarioCriteriaInfo.description, isMythicKeystone, mythicKeystoneCurrentValue, scenarioCriteriaInfo.isWeightedProgress), objectiveOptions)
            GW.SetObjectiveTimeText(block.objectiveBlocks[block.numObjectives], GW.GetEncounterTimeText(scenarioCriteriaInfo))
            if scenarioCriteriaInfo.duration > 0 and scenarioCriteriaInfo.elapsed <= scenarioCriteriaInfo.duration then
                block:AddObjective(TIME_REMAINING, {isQuest = false, qty = nil, totalqty = nil, timerShown = true, duration = scenarioCriteriaInfo.duration, startTime = GetTime() - scenarioCriteriaInfo.elapsed})
            end
        end
    end
    -- add special widgets here
    GW.addEmberCourtData(self)

    local bonusSteps = C_Scenario.GetBonusSteps() or {}
    for _, v in ipairs(bonusSteps) do
        local bonusStepIndex = v
        local _, _, numCriteriaForStep = C_Scenario.GetStepInfo(bonusStepIndex)

        for criteriaIndex = 1, numCriteriaForStep do
            local scenarioCriteriaInfo = C_ScenarioInfo.GetCriteriaInfoByStep(bonusStepIndex, criteriaIndex)
            local objectiveType = scenarioCriteriaInfo.isWeightedProgress and "progressbar" or "monster"

            -- timer bar
            if scenarioCriteriaInfo.duration > 0 and scenarioCriteriaInfo.elapsed <= scenarioCriteriaInfo.duration and not (scenarioCriteriaInfo.failed or scenarioCriteriaInfo.completed) then
                block:AddObjective(TIME_REMAINING, {isQuest = false, qty = nil, totalqty = nil, timerShown = true, duration = scenarioCriteriaInfo.duration, startTime = GetTime() - scenarioCriteriaInfo.elapsed})
            else
                objectiveOptions.finished = IsScenarioCriteriaComplete(scenarioCriteriaInfo)
                objectiveOptions.objectiveType = objectiveType
                objectiveOptions.qty = scenarioCriteriaInfo.quantity
                objectiveOptions.isMythicKeystone = false
                block:AddObjective(GW.ParseCriteria(scenarioCriteriaInfo.quantity, scenarioCriteriaInfo.totalQuantity, scenarioCriteriaInfo.description), objectiveOptions)
            end
        end
    end

    --check for additonal statusbar
    local hasVisibleStatusBarWidget = false
    for _, widgetInfo in ipairs( self.statusBarWidgetManager.widgetInfoForStatusBar or {} ) do
        if widgetInfo and widgetInfo.shownState ~= Enum.WidgetShownState.Hidden then
            hasVisibleStatusBarWidget = true
            local objectiveType = "object"
            local quantity = widgetInfo.barValue

            -- the values render on the bar itself, the row text is just the label —
            -- an empty label collapses the row around a centered bar (AddObjective)
            if widgetInfo.barValueTextType == Enum.StatusBarValueTextType.Percentage then
                objectiveType = "progressbar"
                quantity = math.min(1, widgetInfo.barValue / widgetInfo.barMax) * 100
            end
            block:AddObjective(widgetInfo.text or "", { finished = false, objectiveType = objectiveType, qty = quantity, totalqty = widgetInfo.barMax, firstObjectivesYValue = block.gwFirstRowYOffset })
            local objectiveBlock = block.objectiveBlocks[block.numObjectives]
            UpdateStatusBarPartitions(objectiveBlock.StatusBar, widgetInfo)
        end
    end
    if hasVisibleStatusBarWidget and not self.timerWidgetManager:IsTimerRunning() then
        self:ClearWidgetSet()
    end

    for i = (block.numObjectives or 0) + 1, #block.objectiveBlocks do
        block.objectiveBlocks[i]:Hide()
    end

    -- the origin of the first row, which no row books itself (includes the delve
    -- icon rows height when it occupies its own slot at the block top)
    block.height = block.height - (block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET)
    if block.hasItem then
        -- the button sits next to the first rows of the block: book only the offset
        -- above the block content (timer bar, delve icon row), never the summed row
        -- heights — the button must not sink with every additional objective row
        block.fromContainerTopHeight = (timerBlock.timer:IsShown() and timerBlock.height or 0)
            + SCENARIO_ITEM_BUTTON_TOP_OFFSET
            + (CUSTOM_ROW_Y_OFFSET - (block.gwFirstRowYOffset or CUSTOM_ROW_Y_OFFSET))
        GW.CombatQueue:Queue("update_tracker_scenario_itembutton_position", block.UpdateObjectiveActionButtonPosition, {block})
    end

    local intGWQuestTrackerHeight = 0
    if timerBlock.affixeFrame:IsShown() then intGWQuestTrackerHeight = intGWQuestTrackerHeight + 40 end
    if timerBlock.timer:IsShown() then intGWQuestTrackerHeight = intGWQuestTrackerHeight + 40 end

    if self.timerWidgetManager:IsTimerRunning() then
        timerBlock.height = 40
    end

    timerBlock:SetHeight(timerBlock.height)
    block:SetHeight(block.height - intGWQuestTrackerHeight)
    -- like LayoutBlocks: one block gap per block, the (single) last one becomes the
    -- container's bottom margin - without it the next container sits too close
    self:SetHeight(block.height + GW.GetObjectivesBlockGap())
end

function GwQuesttrackerScenarioBlockMixin:UpdateAffixes(fakeIds)
    if not GW.Retail then return end
    local _, affixes = C_ChallengeMode.GetActiveKeystoneInfo()
    affixes = fakeIds and #fakeIds > 0 and fakeIds or affixes or {}

    for idx, v in ipairs(affixes) do
        local affix = self.affixeFrame.affixes[idx]
        local _, _, filedataid = C_ChallengeMode.GetAffixInfo(v)
        if idx == 1 then self.height = self.height + 40 end
        if filedataid then
            affix.icon:SetTexture(filedataid)
            if not affix.mask then
                affix.mask = affix:CreateMaskTexture()
                affix.mask:SetAllPoints(affix.icon)
                affix.mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
                affix.icon:AddMaskTexture(affix.mask)
            end
        end
        affix.affixID = v
        affix:Show()
        self.affixeFrame:Show()
        self.affixeFrame:SetHeight(40) -- needed for anchor points
    end

    if not affixes or (#affixes == 0) then
        for _, v in ipairs(self.affixeFrame.affixes) do
            v.affixID = nil
            v.icon:SetTexture("Interface/AddOns/GW2_UI/textures/icons/icon-boss.png")
        end
        self.affixeFrame:Hide()
        self.affixeFrame:SetHeight(1) -- needed for anchor points
    end
end

function GwQuesttrackerScenarioBlockMixin:UpdateDeathCounter()
    if not GW.Retail then return end
    self.container.groupInfoBar:SetDeaths(C_ChallengeMode.GetDeathCount())
end

function GwQuesttrackerScenarioBlockMixin:TimerStop()
    self:SetScript("OnUpdate", nil)
    self.timer:Hide()
    self.chestoverlay:Hide()
    self.gwChallengeMode = false
    self.container.groupInfoBar:SetDeaths(nil)
end

local function GetChallengeModeMapID()
    if GW.Retail then
        return C_ChallengeMode.GetActiveChallengeMapID()
    elseif GW.Mists then
        local _, _, _, _, _, _, _, mapID = GetInstanceInfo()
        return mapID
    end
end

local function GetChallengeModeTimeData(mapID)
    if not mapID then
        return
    end

    if GW.Retail then
        local _, _, timeLimit = C_ChallengeMode.GetMapUIInfo(mapID)
        if not timeLimit or timeLimit <= 0 then
            return
        end
        return timeLimit, timeLimit * TIME_FOR_2, timeLimit * TIME_FOR_3
    end

    local times = C_ChallengeMode.GetChallengeModeMapTimes(mapID)
    if not times or not times[1] or times[1] <= 0 then
        return
    end
    return times[1], times[2], times[3]
end

local function SetupChallengeModeTimer(self, getElapsedTime, timeLimit, time2, time3)
    self.chestoverlay:Show()
    self.timer:SetMinMaxValues(0, timeLimit)
    self.cmTimerThrottle = 0
    self:SetScript("OnUpdate", function(_, elapsed)
        -- M+ timer text has second resolution; throttle to ~10x/s instead of every frame
        -- (this runs for the whole dungeon, i.e. exactly when frame budget is tightest).
        self.cmTimerThrottle = self.cmTimerThrottle + elapsed
        if self.cmTimerThrottle < 0.1 then
            return
        end
        self.cmTimerThrottle = 0

        local elapsedTime = getElapsedTime()
        self.timer:SetValue(math.max(0, timeLimit - elapsedTime))
        self.chestoverlay.chest2:SetShown(elapsedTime < time2)
        self.chestoverlay.chest3:SetShown(elapsedTime < time3)

        if elapsedTime < timeLimit then
            self.timerString:SetText(SecondsToClock(timeLimit - elapsedTime))
            self.timerString:SetTextColor(1, 1, 1)
        else
            self.timerString:SetText(SecondsToClock(0))
            self.timerString:SetTextColor(255, 0, 0)
        end

        if elapsedTime < time3 then
            self.chestoverlay.timerStringChest3:SetText(SecondsToClock(time3 - elapsedTime))
            self.chestoverlay.timerStringChest2:SetText(SecondsToClock(time2 - elapsedTime))
            self.chestoverlay.timerStringChest3:Show()
            self.chestoverlay.timerStringChest2:Show()
        elseif elapsedTime < time2 then
            self.chestoverlay.timerStringChest2:SetText(SecondsToClock(time2 - elapsedTime))
            self.chestoverlay.timerStringChest2:Show()
            self.chestoverlay.timerStringChest3:Hide()
        else
            self.chestoverlay.timerStringChest2:Hide()
            self.chestoverlay.timerStringChest3:Hide()
        end
    end)

    self.timer:Show()
    self.needToShowTimer = true
    self.height = self.height + 50
    self:UpdateAffixes()
    self:UpdateDeathCounter()
    self.gwChallengeMode = true
    self.container.groupInfoBar:UpdateState()
end

local function SetupProvingGroundTimer(self, timerID, duration)
    self.timer:SetMinMaxValues(0, duration)
    self.pgTimerThrottle = 0
    self:SetScript("OnUpdate", function(_, elapsed)
        self.pgTimerThrottle = self.pgTimerThrottle + elapsed
        if self.pgTimerThrottle < 0.1 then
            return
        end
        self.pgTimerThrottle = 0

        local _, elapsedTime = GetWorldElapsedTime(timerID)
        local remaining = math.max(0, duration - elapsedTime)
        self.timer:SetValue(remaining)
        self.timerString:SetText(SecondsToClock(remaining))
    end)
    self.timer:Show()
    self.needToShowTimer = true
    self.height = self.height + 40
end

function GwQuesttrackerScenarioBlockMixin:TimerUpdate(...)
    self.height = 1
    self.gwTest = nil
    self.container.groupInfoBar:SetTest(false)

    for i = 1, select("#", ...) do
        local timerID = select(i, ...)
        local _, _, wtype = GetWorldElapsedTime(timerID)
        if wtype == Enum.WorldElapsedTimerTypes.ChallengeMode then
            local mapID = GetChallengeModeMapID()
            local timeLimit, time2, time3 = GetChallengeModeTimeData(mapID)
            if timeLimit and time2 and time3 then
                SetupChallengeModeTimer(self, function() return select(2, GetWorldElapsedTime(timerID)) end, timeLimit, time2, time3)
                return
            end
        elseif wtype == Enum.WorldElapsedTimerTypes.ProvingGround then
            local _, _, _, duration = C_Scenario.GetProvingGroundsInfo()
            if duration and duration > 0 then
                SetupProvingGroundTimer(self, timerID, duration)
                return
            end
        end
    end

    self.timer:Hide()
    self.chestoverlay:Hide()
    self.gwChallengeMode = false
    self.container.groupInfoBar:SetDeaths(nil)
    self:SetScript("OnUpdate", nil)
    self.needToShowTimer = false

    for _, v in ipairs(self.affixeFrame.affixes) do
        v.affixID = nil
        v.icon:SetTexture("Interface/AddOns/GW2_UI/textures/icons/icon-boss.png")
    end
    self.affixeFrame:Hide()
    self.affixeFrame:SetHeight(1) -- needed for anchor points
end

function GwQuesttrackerScenarioBlockMixin:TimerBlockOnEvent(event, ...)
    if event == "PLAYER_ENTERING_WORLD" or event == nil then
        self:TimerUpdate(GetWorldElapsedTimers())
        self:UpdateDeathCounter()
    elseif event == "WORLD_STATE_TIMER_START" then
        local timerID = ...
        self:TimerUpdate(timerID)
    elseif event == "WORLD_STATE_TIMER_STOP" then
        self:TimerStop()
    elseif event == "PROVING_GROUNDS_SCORE_UPDATE" then
        local score = ...
        self.score.scoreString:SetText(score)
        self.score:Show()
        self.height = self.height + 40
    elseif event == "CHALLENGE_MODE_START" or event == "CHALLENGE_MODE_COMPLETED" or event == "CHALLENGE_MODE_MAPS_UPDATE" or event == "ZONE_CHANGED" then
        self:TimerUpdate(GetWorldElapsedTimers())
    elseif event == "CHALLENGE_MODE_DEATH_COUNT_UPDATED" then
        self:UpdateDeathCounter()
    end
    self:SetHeight(self.height)

    self.container:QueueUpdateLayout()
end

local function ScenarioContainerOnEvent(self, event, ...)
    self:QueueUpdateLayout(event, ...)
end

local function UIWidgetTemplateTooltipFrameOnEnter(self)
    if self.tooltip then
        self.tooltipContainsHyperLink = false
        self.preString = nil
        self.hyperLinkString = nil
        self.postString = nil
        self.tooltipContainsHyperLink, self.preString, self.hyperLinkString, self.postString = ExtractHyperlinkString(self.tooltip)

        EmbeddedItemTooltip:SetOwner(self, "ANCHOR_LEFT")

        if self.tooltipContainsHyperLink then
            local clearTooltip = true
            if self.preString and self.preString:len() > 0 then
                EmbeddedItemTooltip:AddLine(self.preString, 1, 1, 1, true)
                clearTooltip = false
            end

            GameTooltip_ShowHyperlink(EmbeddedItemTooltip, self.hyperLinkString, 0, 0, clearTooltip)

            if self.postString and self.postString:len() > 0 then
                GameTooltip_AddColoredLine(EmbeddedItemTooltip, self.postString, self.tooltipColor or HIGHLIGHT_FONT_COLOR, true)
            end

            self.UpdateTooltip = self.OnEnter

            EmbeddedItemTooltip:Show()
        else
            local header, nonHeader = SplitTextIntoHeaderAndNonHeader(self.tooltip)
            if header then
                GameTooltip_AddColoredLine(EmbeddedItemTooltip, header, self.tooltipColor or NORMAL_FONT_COLOR, true)
            end
            if nonHeader then
                GameTooltip_AddColoredLine(EmbeddedItemTooltip, nonHeader, self.tooltipColor or NORMAL_FONT_COLOR, true)
            end
            self.UpdateTooltip = nil

            EmbeddedItemTooltip:SetShown(header ~= nil)
        end
    end
end

function GwObjectivesScenarioContainerMixin:InitModule()
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("SCENARIO_UPDATE")
    self:RegisterEvent("SCENARIO_CRITERIA_UPDATE")
    self:RegisterEvent("LOOT_CLOSED")
    self:RegisterEvent("CURRENCY_DISPLAY_UPDATE")
    self:RegisterEvent("ZONE_CHANGED_INDOORS")
    self:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    self:RegisterEvent("ZONE_CHANGED")
    self:RegisterEvent("SCENARIO_COMPLETED")
    self:RegisterEvent("SCENARIO_SPELL_UPDATE")
    self:RegisterEvent("JAILERS_TOWER_LEVEL_UPDATE")
    self:SetScript("OnEvent", ScenarioContainerOnEvent)


    self.jailersTowerType = nil
    self.layoutQueued = false
    self.layoutUpdateFrame = CreateFrame("Frame", nil, self)
    self.layoutUpdateFrame.container = self

    if GW.isModern then
        self.gwSpellRows = CreateFrame("Frame", nil, self)
        self.gwSpellRows.labels = {}
        self.gwSpellRows.iconPool = CreateFramePool("Frame", self.gwSpellRows, "GwTieredEntranceTraitSpellTemplate")
        self.gwSpellRows:Hide()
    end

    -- JailersTower hook
    -- do it only here so we are sure we do not hook more than one time
    if GW.isModern then
        hooksecurefunc(ScenarioObjectiveTracker, "SlideInContents", function(container)
            if container:ShouldShowCriteria() and IsInJailersTower() then
                self:QueueUpdateLayout()
            end
        end)

        -- own Maw buff button: re-layout when the power count changes (appear on
        -- the first collected buff, live count/list while running)
        -- blessing/torment rows: follow widget updates of the fixed bottom set
        local widgetWatcher = CreateFrame("Frame")
        widgetWatcher:RegisterEvent("UPDATE_UI_WIDGET")
        widgetWatcher:SetScript("OnEvent", function(_, _, widgetInfo)
            if widgetInfo and widgetInfo.widgetSetID == SCENARIO_BOTTOM_WIDGET_SET then
                self:QueueUpdateLayout()
            end
        end)

        local lastMawCount = -1
        local function HasMawAura()
            local ok, _, slot = pcall(C_UnitAuras.GetAuraSlots, "player", "MAW", 1)
            return not ok or slot ~= nil
        end
        local mawWatcher = CreateFrame("Frame")
        mawWatcher:RegisterUnitEvent("UNIT_AURA", "player")
        mawWatcher:SetScript("OnEvent", function()
            -- outside torghast there are almost never maw auras, the full read only runs when there are
            if lastMawCount <= 0 and not IsInJailersTower() and not HasMawAura() then
                return
            end
            local collected = GW.CollectMawAuras()
            if not collected then
                return -- failed read (secret state): keep the current display
            end
            if #collected ~= lastMawCount then
                lastMawCount = #collected
                self:QueueUpdateLayout()
            end
        end)
    end

    self.timerBlock = CreateFrame("Button", "GwQuestTrackerTimer", self, "GwQuesttrackerScenarioBlock")
    self.timerBlock.container = self
    self.timerBlock.needToShowTimer = false
    self.timerBlock.height = self.timerBlock:GetHeight()
    self.timerBlock.timerlabel = self.timerBlock.timer.timerlabel
    self.timerBlock.timerString = self.timerBlock.timer.timerString

    self.timerBlock.timerlabel:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "SHADOW")
    self.timerBlock.timerlabel:SetTextColor(1, 1, 1)
    self.timerBlock.timerString:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "SHADOW")
    self.timerBlock.timerString:SetTextColor(1, 1, 1)

    self.timerBlock.chestoverlay.timerStringChest2:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "SHADOW", -2)
    self.timerBlock.chestoverlay.timerStringChest2:SetTextColor(1, 1, 1)
    self.timerBlock.chestoverlay.timerStringChest3:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, "SHADOW", -2)
    self.timerBlock.chestoverlay.timerStringChest3:SetTextColor(1, 1, 1)

    self.timerBlock.chestoverlay.chest2:ClearAllPoints()
    self.timerBlock.chestoverlay.chest3:ClearAllPoints()
    self.timerBlock.chestoverlay.timerStringChest2:ClearAllPoints()
    self.timerBlock.chestoverlay.timerStringChest3:ClearAllPoints()
    self.timerBlock.chestoverlay.chest2:SetPoint("LEFT", self.timerBlock.timer, "LEFT", self.timerBlock.timer:GetWidth() * (1 - TIME_FOR_2) - 1, -6)
    self.timerBlock.chestoverlay.chest3:SetPoint("LEFT", self.timerBlock.timer, "LEFT", self.timerBlock.timer:GetWidth() * (1 - TIME_FOR_3) - 1, -6)
    self.timerBlock.chestoverlay.timerStringChest2:SetPoint("RIGHT", self.timerBlock.chestoverlay.chest2, "LEFT", -2, -6)
    self.timerBlock.chestoverlay.timerStringChest3:SetPoint("RIGHT", self.timerBlock.chestoverlay.chest3, "LEFT", -2, -6)

    self.timerBlock.score.scoreString:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)

    for _, v in ipairs(self.timerBlock.affixeFrame.affixes) do
        v:SetScript("OnEnter", function(affixBlock)
            if affixBlock.affixID then
                GameTooltip:SetOwner(affixBlock, "ANCHOR_BOTTOMLEFT", 0, 50)
                GameTooltip:ClearLines()
                local name, description = C_ChallengeMode.GetAffixInfo(affixBlock.affixID)
                GameTooltip:SetOwner(affixBlock, "ANCHOR_RIGHT")
                GameTooltip:SetText(name, 1, 1, 1, 1, true)
                GameTooltip:AddLine(description, nil, nil, nil, true)
                GameTooltip:Show()
            end
        end)
        v:SetScript("OnLeave", GameTooltip_Hide)
    end


    self.timerBlock:SetParent(self)
    self.timerBlock:ClearAllPoints()
    self.timerBlock:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0)

    self.timerBlock:RegisterEvent("PLAYER_ENTERING_WORLD")
    self.timerBlock:RegisterEvent("WORLD_STATE_TIMER_START")
    self.timerBlock:RegisterEvent("WORLD_STATE_TIMER_STOP")
    self.timerBlock:RegisterEvent("CHALLENGE_MODE_MAPS_UPDATE")
    self.timerBlock:RegisterEvent("CHALLENGE_MODE_START")
    self.timerBlock:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    self.timerBlock:RegisterEvent("ZONE_CHANGED")
    self.timerBlock:RegisterEvent("CHALLENGE_MODE_DEATH_COUNT_UPDATED")

    if GW.isModern then
        self.timerBlock:RegisterEvent("PROVING_GROUNDS_SCORE_UPDATE")
    end
    self.timerBlock:SetScript("OnEvent", self.timerBlock.TimerBlockOnEvent)

    self.block = self:GetBlock(1, GW.Enum.ObjectivesNotificationType.Scenario, GW.isModern) -- only create an actionbutton for retail here
    if GW.isModern then
        -- the mixin carries our secret safe UpdateCooldown (replaced at the top of
        -- this file), so the button inherits it here
        Mixin(self.block.actionButton, ScenarioSpellButtonMixin)
        self.block.actionButton:SetScript("OnEnter", self.block.actionButton.OnEnter)
    end

    self.block:ClearAllPoints()
    self.groupInfoBar = GW.CreateGroupInfoBar(self)
    self.block:SetPoint("TOPRIGHT", self.groupInfoBar, "BOTTOMRIGHT", 0, 0)
    self.block.Header:SetText("")
    self.block.delvesFrame:ClearAllPoints()
    self.block.delvesFrame:SetPoint("TOPRIGHT", GwObjectivesNotification, "BOTTOMRIGHT", 0, 35)

    for _, v in ipairs(self.block.delvesFrame.spell) do
        v:SetScript("OnEnter", function(delveBlock)
                if delveBlock.spellID then
                    GameTooltip:SetOwner(delveBlock, "ANCHOR_LEFT")
                    GameTooltip:SetSpellByID(delveBlock.spellID)
                    GameTooltip:Show()
                end
            end)
        v:SetScript("OnLeave", GameTooltip_Hide)
    end

    self.block.delvesFrame.reward:SetScript("OnEnter", UIWidgetTemplateTooltipFrameOnEnter)
    self.block.delvesFrame.reward:SetScript("OnLeave", function() UIWidgetTemplateTooltipFrameMixin:OnLeave() end)

    self.block.delvesFrame.deathCounter:SetScript("OnEnter", UIWidgetTemplateTooltipFrameOnEnter)
    self.block.delvesFrame.deathCounter:SetScript("OnLeave", function() UIWidgetTemplateTooltipFrameMixin:OnLeave() end)
    self.block.delvesFrame.deathCounter.counter:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Normal)

    for i = 1, 5 do
        self.block.currenciesFrame.currency[i]:SetScript("OnEnter", UIWidgetTemplateTooltipFrameOnEnter)
        self.block.currenciesFrame.currency[i]:SetScript("OnLeave", function() UIWidgetTemplateTooltipFrameMixin:OnLeave() end)
        self.block.currenciesFrame.currency[i].counter:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Normal)
    end

    self.timerWidgetManager = CreateScenarioWidgetManager(self, false, true)
    self.statusBarWidgetManager = CreateScenarioWidgetManager(self, true, false)

    C_Timer.After(0.8, function() self:QueueUpdateLayout() end)

    self.timerBlock:TimerBlockOnEvent()
end

-- /gw2 test mythicplus: a 30 minute key with three affixes and three deaths, the next call ends it
local TEST_AFFIXES = {9, 10, 152}
function GW.TestMythicPlusTimer()
    local timerBlock = GwQuestTrackerTimer
    if not timerBlock then return end
    if timerBlock.gwTest then
        timerBlock.gwTest = nil
        timerBlock:TimerBlockOnEvent()
        return
    end

    timerBlock.gwTest = true
    timerBlock.height = 1
    local startTime = GetTime()
    local timeLimit = 1800
    SetupChallengeModeTimer(timerBlock, function() return GetTime() - startTime end, timeLimit, timeLimit * TIME_FOR_2, timeLimit * TIME_FOR_3)
    timerBlock:UpdateAffixes(TEST_AFFIXES)
    timerBlock.container.groupInfoBar:SetDeaths(3, 15)
    timerBlock.container.groupInfoBar:SetTest(true)
    timerBlock:SetHeight(timerBlock.height)
    timerBlock.container:QueueUpdateLayout()
end
