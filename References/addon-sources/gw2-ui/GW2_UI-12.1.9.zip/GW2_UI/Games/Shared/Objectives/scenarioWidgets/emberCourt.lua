---@class GW2
local GW = select(2, ...)

local function addEmberCourtData(container)
    if GW.Location.GetMapID() == 1644 then
        local BottomScenarioWidgetContainerBlock = ScenarioObjectiveTracker and ScenarioObjectiveTracker.BottomWidgetContainerBlock
        if BottomScenarioWidgetContainerBlock and BottomScenarioWidgetContainerBlock.WidgetContainer:GetHeight() > 1.1 then
            container.block.numObjectives = container.block.numObjectives + 1
            local objectiveBlock = container.block:GetObjectiveBlock(container.block.numObjectives)
            BottomScenarioWidgetContainerBlock.gwBlock = objectiveBlock
            objectiveBlock:SetHeight(max(BottomScenarioWidgetContainerBlock.height or 0, BottomScenarioWidgetContainerBlock.WidgetContainer:GetHeight()))
            BottomScenarioWidgetContainerBlock.SetParent = nil
            BottomScenarioWidgetContainerBlock.ClearAllPoints = nil
            BottomScenarioWidgetContainerBlock.SetPoint = nil
            BottomScenarioWidgetContainerBlock:SetParent(objectiveBlock)
            BottomScenarioWidgetContainerBlock:ClearAllPoints()
            BottomScenarioWidgetContainerBlock:SetPoint("TOP", 0, 15)
            BottomScenarioWidgetContainerBlock.SetParent = GW.NoOp
            BottomScenarioWidgetContainerBlock.ClearAllPoints = GW.NoOp
            BottomScenarioWidgetContainerBlock.SetPoint = GW.NoOp
            objectiveBlock:Show()
            objectiveBlock.ObjectiveText:SetText("")
            container.block.height = container.block.height + objectiveBlock:GetHeight() + 15
            container.block.numObjectives = container.block.numObjectives + 1
            objectiveBlock.hasObjectToHide = true
            objectiveBlock.objectToHide = BottomScenarioWidgetContainerBlock
            objectiveBlock.resetParent = true
        end
    end
end
GW.addEmberCourtData = addEmberCourtData
