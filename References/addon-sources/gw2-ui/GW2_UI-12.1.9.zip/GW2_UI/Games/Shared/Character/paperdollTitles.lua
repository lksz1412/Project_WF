---@class GW2
local GW = select(2, ...)
local L = GW.L

local savedPlayerTitles = {}
local showEarned = true
local showUnearned = false

local function title_OnClick(self)
    if not self.titleId then
        return
    end
    SetCurrentTitle(self.titleId)

    self:GetParent():GetParent():GetParent().input:SetText("")
    self:GetParent():GetParent():GetParent().input.clearButton:Hide()
end


local function UpdateScrollBox(self)
    local dataProvider = CreateDataProvider();
    for index, playerTitle in ipairs(savedPlayerTitles) do
        dataProvider:Insert({index = index, playerTitle = playerTitle})
    end
    self.ScrollBox:SetDataProvider(dataProvider, ScrollBoxConstants.RetainScrollPosition)
end

local function Titles_InitButton(button, elementData)
    local playerTitle = elementData.playerTitle

    if not button.gwSkinned then
        button.name:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        button:HookScript("OnClick", title_OnClick)
        GW.AddListItemChildHoverTexture(button)

        button.gwSkinned = true
    end

    button.name:SetText(playerTitle.name)
    button.titleId = playerTitle.id

    -- set zebra color by idx or watch status
    if (GetCurrentTitle() == button.titleId) or ((elementData.index % 2) == 1) then
        button.zebra:SetVertexColor(1, 1, 1, 1)
    else
        button.zebra:SetVertexColor(0, 0, 0, 0)
    end

    if playerTitle.isKnown then
        button:Enable()
        button.name:SetTextColor(1, 1, 1)
    else
        button:Disable();
        button.name:SetTextColor(0.60, 0.60, 0.60)
    end

    button.gwSelected:SetShown(GetCurrentTitle() == button.titleId)
end

local function saveKnowenTitles(titlewin, searchString)
    wipe(savedPlayerTitles)
    if not (showEarned or showUnearned) then
        UpdateScrollBox(titlewin)
        return
    end

    local query = searchString and searchString:lower() or nil

    for i = 1, GetNumTitles() do
        local isKnown = IsTitleKnown(i)
        if (isKnown and showEarned) or (not isKnown and showUnearned) then
            local tempName, playerTitle = GetTitleName(i)
            if tempName and playerTitle then
                tempName = strtrim(tempName)
                if (not query) or (tempName:lower():find(query, 1, true)) then
                    tinsert(savedPlayerTitles, {name = tempName, id = i, isKnown = isKnown})
                end
            end
        end
    end

    table.sort(savedPlayerTitles,
        function(a, b)
            return a.name < b.name
        end
    )
    if showEarned then
        tinsert(savedPlayerTitles, 1, {name = PLAYER_TITLE_NONE, id = -1, isKnown = true})
    end

    UpdateScrollBox(titlewin)
end


local function ResetFilter()
    showEarned = true
    showUnearned = false

    GwTitleWindow.input:SetText("")
    GwTitleWindow.input.clearButton:Hide()
    saveKnowenTitles(GwTitleWindow)
end

local function IsFilterSelected(earned)
    if earned then return showEarned end
    return showUnearned
end

local function SetFilterSelected(earned)
    if earned then
        showEarned = not showEarned
    else
        showUnearned = not showUnearned
    end
    GwTitleWindow.input:SetText("")
    GwTitleWindow.input.clearButton:Hide()
    saveKnowenTitles(GwTitleWindow)
end

local function GenerateFilterMenu(_, rootDescription)
    rootDescription:SetMinimumWidth(1)
    local check = rootDescription:CreateCheckbox(ACHIEVEMENTFRAME_FILTER_COMPLETED, IsFilterSelected, SetFilterSelected, true)
    check:AddInitializer(GW.BlizzardDropdownCheckButtonInitializer)

    check = rootDescription:CreateCheckbox(L["Unearned"], IsFilterSelected, SetFilterSelected, false)
    check:AddInitializer(GW.BlizzardDropdownCheckButtonInitializer)
    check:SetTooltip(function(tooltip, elementDescription)
        tooltip:SetText(MenuUtil.GetElementText(elementDescription), 1, 1, 1)
        tooltip:AddLine(L["You may see duplicated titles that are unavailable to your faction"], 1, 1, 1)
    end)

    rootDescription:CreateDivider()
    rootDescription:CreateButton(RESET, ResetFilter)
end

function GW.LoadPDTitles(parent, fmMenu)
    local titlewin = CreateFrame("Frame", "GwTitleWindow", parent, "GwTitleWindow")

    GW.SkinEditBox(titlewin.input, {search = true})
    titlewin.input:SetScript("OnEnterPressed", titlewin.input.ClearFocus)
    titlewin.input:HookScript("OnTextChanged", function(self)
        local text = self:GetText()
        saveKnowenTitles(titlewin, text ~= "" and text or nil)
    end)

    -- blizzards dropdown button opens and closes the filter menu on its own
    local filter = titlewin.filter
    filter:SetupMenu(GenerateFilterMenu)
    filter:RegisterCallback(DropdownButtonMixin.Event.OnMenuOpen, GameTooltip_Hide, titlewin)
    -- with both filters off nothing would show, closing the menu then resets them
    filter:RegisterCallback(DropdownButtonMixin.Event.OnMenuClose, function()
        if not showEarned and not showUnearned then
            ResetFilter()
        end
    end, titlewin)
    filter:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(FILTER, 1, 1, 1)
        GameTooltip:Show()
    end)
    filter:HookScript("OnLeave", GameTooltip_Hide)

    local view = CreateScrollBoxListLinearView()
    view:SetElementInitializer("GwTitleButtonTemplate", function(button, elementData)
        Titles_InitButton(button, elementData);
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(titlewin.ScrollBox, titlewin.ScrollBar, view)
    GW.HandleTrimScrollBar(titlewin.ScrollBar)
    GW.HandleScrollControls(titlewin)
    titlewin.ScrollBar:SetHideIfUnscrollable(true)

    saveKnowenTitles(titlewin)

    -- update title window when a title update event occurs
    titlewin:SetScript(
        "OnEvent",
        function()
            if GW.inWorld then
                local text = titlewin.input:GetText()
                saveKnowenTitles(titlewin, text ~= "" and text or nil)
            end
        end
    )
    titlewin:RegisterEvent("KNOWN_TITLES_UPDATE")
    titlewin:RegisterUnitEvent("UNIT_NAME_UPDATE", "player")

    fmMenu:SetupBackButton(titlewin.backButton, CHARACTER .. ": " .. PAPERDOLL_SIDEBAR_TITLES)

    return titlewin
end