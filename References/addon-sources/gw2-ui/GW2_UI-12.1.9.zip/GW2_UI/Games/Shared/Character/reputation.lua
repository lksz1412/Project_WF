---@class GW2
local GW = select(2, ...)
local L = GW.L
local RoundDec = GW.RoundDec
local RT = GW.REP_TEXTURES

local isSearchResult = nil
local firstReputationCat = 1
local lastReputationCat = 1
local OFF_Y = 10
local DETAIL_H = 65
local DETAIL_LG_H = (DETAIL_H * 2) + OFF_Y
local DETAIL_LG_NODESC_H = 95 -- expanded row without description block

local function HasDescription(data)
    return data ~= nil and data.description ~= nil and data.description ~= ""
end

local function GetExpandedHeight(data)
    return HasDescription(data) and DETAIL_LG_H or DETAIL_LG_NODESC_H
end
local REPBG_T = 0
local REPBG_B = 0.464

local g_selectionBehavior = nil
local updateQueued = false

local factionDataCache = {}

local ExpandAllFactionHeaders = C_Reputation and C_Reputation.ExpandAllFactionHeaders or ExpandAllFactionHeaders
local SetWatchedFactionByIndex = C_Reputation and C_Reputation.SetWatchedFactionByIndex or SetWatchedFactionIndex
local ToggleFactionAtWar = C_Reputation and C_Reputation.ToggleFactionAtWar or FactionToggleAtWar
local GetNumFactions = C_Reputation and C_Reputation.GetNumFactions or GetNumFactions
local IsMajorFaction = C_Reputation.IsMajorFaction

-- session reputation gain: a baseline per factionID is taken when entering the world and kept in
-- memory only, so it resets on login and reload like the money session data (or manually via
-- ctrl + right click); the gain is simply current total minus baseline
local function GetFactionTotalStanding(data)
    local total = data.currentStanding or 0
    if data.factionID and IsMajorFaction(data.factionID) and C_MajorFactions then
        local major = C_MajorFactions.GetMajorFactionData(data.factionID)
        if major then
            total = (major.renownLevel or 0) * (major.renownLevelThreshold or 0) + (major.renownReputationEarned or 0)
        end
    end
    if data.factionID and C_Reputation.IsFactionParagonForCurrentPlayer(data.factionID) then
        local currentValue = C_Reputation.GetFactionParagonInfo(data.factionID)
        total = total + (currentValue or 0)
    end
    return total
end
GW.GetFactionTotalStanding = GetFactionTotalStanding

local sessionBaseline = {}

local updatingSessionBaseline = false
local lastNumFactions
local function UpdateSessionBaseline(reset, expandHeaders)
    if updatingSessionBaseline then return end
    updatingSessionBaseline = true -- ExpandAllFactionHeaders fires UPDATE_FACTION synchronously
    local store = sessionBaseline
    if reset then
        wipe(store)
    end
    if expandHeaders then
        ExpandAllFactionHeaders() -- collapsed headers hide their factions from the index range
    end
    for factionIndex = 1, GetNumFactions() do
        local data = GW.GetFactionDataByIndex(factionIndex)
        if data and not data.isHeader and data.factionID and store[data.factionID] == nil then
            store[data.factionID] = GetFactionTotalStanding(data)
        end
    end
    lastNumFactions = GetNumFactions()
    updatingSessionBaseline = false
end

local function GetSessionGain(data)
    if not data.factionID then return 0 end
    local baseline = sessionBaseline[data.factionID]
    if baseline == nil then return 0 end
    return GetFactionTotalStanding(data) - baseline
end

local sessionTracker = CreateFrame("Frame")
sessionTracker:RegisterEvent("PLAYER_ENTERING_WORLD")
sessionTracker:RegisterEvent("UPDATE_FACTION")
sessionTracker:SetScript("OnEvent", function(_, event, isLogin, isReload)
    if event == "PLAYER_ENTERING_WORLD" then
        -- the baseline is the state at login, a loading screen later changes nothing
        if isLogin or isReload then
            UpdateSessionBaseline(false, true)
        end
    elseif GetNumFactions() ~= lastNumFactions then
        -- a rep gain changes no rows, only a new faction (or a header toggle) does; no header expanding here
        UpdateSessionBaseline()
    end
end)

local ReputationFrameEvents = {
	"QUEST_LOG_UPDATE",
	"UPDATE_FACTION",
}
if GW.isModern then
    tinsert(ReputationFrameEvents, "MAJOR_FACTION_RENOWN_LEVEL_CHANGED")
    tinsert(ReputationFrameEvents, "MAJOR_FACTION_UNLOCKED")
end

local function SetFontWithShadow(element, font, size, sizeAddition)
    element:GwSetFontTemplate(font, size, "SHADOW", sizeAddition)
end

-- the reward icon of a faction with a pending paragon chest: a slowly turning flare behind it and a soft pulse
-- of the icon itself, both looping while the row is shown
local function AddParagonIndicatorAnimation(indicator)
    local flare = indicator:CreateTexture(nil, "BACKGROUND")
    flare:SetTexture("Interface/AddOns/GW2_UI/textures/hud/level-up-flare.png")
    flare:SetPoint("CENTER")
    flare:SetSize(32, 32)

    local group = indicator:CreateAnimationGroup()
    group:SetLooping("REPEAT")

    local rotation = group:CreateAnimation("Rotation")
    rotation:SetTarget(flare)
    rotation:SetDegrees(-360)
    rotation:SetDuration(12)
    rotation:SetOrder(1)

    local fadeOut = group:CreateAnimation("Alpha")
    fadeOut:SetTarget(indicator.Icon)
    fadeOut:SetFromAlpha(1)
    fadeOut:SetToAlpha(0.6)
    fadeOut:SetDuration(1.5)
    fadeOut:SetSmoothing("IN_OUT")
    fadeOut:SetOrder(1)

    local fadeIn = group:CreateAnimation("Alpha")
    fadeIn:SetTarget(indicator.Icon)
    fadeIn:SetFromAlpha(0.6)
    fadeIn:SetToAlpha(1)
    fadeIn:SetDuration(1.5)
    fadeIn:SetSmoothing("IN_OUT")
    fadeIn:SetStartDelay(1.5)
    fadeIn:SetOrder(1)

    indicator.animationGroup = group
end

local GLOW_TEXTURE = "Interface/AddOns/GW2_UI/textures/uistuff/rowglow.png"
local GLOW_MIN, GLOW_MAX = 0.35, 0.62
local PULSE_PEAK = 0.28
local CYCLE = 4
local function AddParagonRowAnimation(button)
    local function Burst(sublevel, blend)
        local texture = button:CreateTexture(nil, "ARTWORK", nil, sublevel)
        texture:SetTexture(GLOW_TEXTURE)
        texture:SetBlendMode(blend)
        texture:SetVertexColor(GW.Colors.FactionBarColors[9]:GetRGB())
        texture:SetPoint("TOPLEFT")
        texture:SetPoint("BOTTOMLEFT")
        texture:SetPoint("RIGHT", button, "CENTER", 0, 0) -- runs out around the middle of the row
        texture:Hide()
        return texture
    end
    local glow = Burst(3, "BLEND")
    glow:SetAlpha(GLOW_MIN)
    local pulse = Burst(4, "ADD")
    pulse:SetAlpha(0)

    local group = button:CreateAnimationGroup()
    group:SetLooping("REPEAT")

    local function Alpha(target, from, to, duration, delay)
        local anim = group:CreateAnimation("Alpha")
        anim:SetTarget(target)
        anim:SetFromAlpha(from)
        anim:SetToAlpha(to)
        anim:SetDuration(duration)
        anim:SetStartDelay(delay or 0)
        anim:SetSmoothing("IN_OUT")
        anim:SetOrder(1)
    end

    Alpha(glow, GLOW_MIN, GLOW_MAX, CYCLE / 2)
    Alpha(glow, GLOW_MAX, GLOW_MIN, CYCLE / 2, CYCLE / 2)

    Alpha(pulse, 0, PULSE_PEAK, 0.5)
    Alpha(pulse, PULSE_PEAK, 0, 1.3, 0.5)
    Alpha(pulse, 0, 0, CYCLE - 1.8, 1.8)

    local grow = group:CreateAnimation("Scale")
    grow:SetTarget(pulse)
    grow:SetScaleFrom(0.9, 1)
    grow:SetScaleTo(1.15, 1)
    grow:SetOrigin("LEFT", 0, 0)
    grow:SetDuration(1.8)
    grow:SetSmoothing("OUT")
    grow:SetOrder(1)

    group:SetScript("OnPlay", function()
        glow:Show()
        pulse:Show()
    end)
    group:SetScript("OnStop", function()
        glow:Hide()
        pulse:Hide()
    end)
    button.paragonRowAnimation = group
end

local DETAIL_INDICATOR_SIZE = 24
local function SetDetailsParagon(frame, pending)
    if pending and not frame.paragonIndicator then
        local indicator = CreateFrame("Frame", nil, frame)
        indicator:SetSize(DETAIL_INDICATOR_SIZE, DETAIL_INDICATOR_SIZE)
        indicator.Icon = indicator:CreateTexture(nil, "ARTWORK")
        indicator.Icon:SetTexture("Interface/AddOns/GW2_UI/textures/icons/rewards-icon.png")
        indicator.Icon:SetAllPoints()
        indicator:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L["Paragon"], 1, 1, 1)
            GameTooltip:Show()
        end)
        indicator:SetScript("OnLeave", GameTooltip_Hide)
        AddParagonIndicatorAnimation(indicator)
        AddParagonRowAnimation(frame)
        frame.paragonIndicator = indicator
    end
    if not frame.paragonIndicator then return end

    local indicator = frame.paragonIndicator
    if pending then
        indicator:ClearAllPoints()
        indicator:SetPoint("LEFT", frame.name, "LEFT", frame.name:GetStringWidth() + 6, 0)
        indicator:Show()
        indicator.animationGroup:Play()
        frame.paragonRowAnimation:Play()
    else
        indicator:Hide()
        indicator.animationGroup:Stop()
        frame.paragonRowAnimation:Stop()
    end
end

local function sortFactionsStatus(tbl)
    table.sort(tbl, function(a, b)
            if a.isFriend ~= b.isFriend then
                return b.isFriend
            elseif a.reaction ~= b.reaction then
                return a.reaction > b.reaction
            else
                return a.reaction < b.reaction
            end
        end)
    return tbl
end

local function addToFactionTable(factionTbl, reaction, standingText, isFriend, name, hasRewardPending, pendingParagonRewardFactions)
    for _, v in ipairs(factionTbl) do
        if v.isFriend == isFriend and v.standingText == standingText then
            v.counter = v.counter + 1
            if hasRewardPending then
                tinsert(pendingParagonRewardFactions, {name = name})
            end
            return true
        end
    end

    if hasRewardPending then
        tinsert(pendingParagonRewardFactions, {name = name})
    end

    tinsert(factionTbl, {reaction = reaction, standingText = standingText, isFriend = isFriend, counter = 1})
    return false
end

local function UpdateCategories(self, details)
    self:SetDataProvider(CreateDataProvider(details), ScrollBoxConstants.RetainScrollPosition)
end

local function UpdateDetailsData(self, details)
    local selectedFactionIndex
    if g_selectionBehavior then
        local selected = g_selectionBehavior:GetSelectedElementData()[1]
        selectedFactionIndex = selected and selected.factionIndex
    end

    self:SetDataProvider(CreateDataProvider(details), ScrollBoxConstants.RetainScrollPosition)

    if selectedFactionIndex then
        g_selectionBehavior:SelectElementDataByPredicate(function(elementData)
            return elementData.factionIndex == selectedFactionIndex
        end)
    end
end

local function CollectFactionData(fetchData)
    local categories = {}
    local details = {}
    local factionTbl = {}
    local pendingParagonRewardFactions = {}

    local cMax, cCur = 0, 0
    local idx, headerName = 0, ""
    local skipFirst = true
    local hasPendingParagonReward = false
    local savedHeaderName = ""

    local searchLower = isSearchResult and string.lower(isSearchResult) or nil

    if fetchData then
        ExpandAllFactionHeaders()
        wipe(factionDataCache)
        for factionIndex = 1, GetNumFactions() do
            local factionData = GW.GetFactionDataByIndex(factionIndex)
            if factionData then
                if factionData.name == GUILD then
                    factionData = C_Reputation.GetGuildFactionData()
                end
                if factionData then
                    factionData.factionIndex = factionIndex
                    tinsert(factionDataCache, factionData)
                end
            end
        end
    end

    for _, data in ipairs(factionDataCache) do
        if data then
            local includeInDetails = false
            if data.name then
                if isSearchResult then
                    if not (data.isHeader and not data.isChild) and string.find(string.lower(data.name), searchLower) then
                        includeInDetails = true
                    end
                else
                    if data.factionIndex >= firstReputationCat and data.factionIndex <= lastReputationCat and data.factionID and (not data.isHeader or data.isChild) then
                        includeInDetails = not data.isHeader or data.isHeaderWithRep
                    end
                end
            end

            if includeInDetails then
                if data.isHeader and data.isChild then
                    savedHeaderName = data.name
                elseif not data.isChild then
                    savedHeaderName = ""
                end
                data.savedHeaderName = savedHeaderName
                tinsert(details, data)
            end

            -- Category collection
            local friendInfo = C_GossipInfo.GetFriendshipReputation(data.factionID or 0)
            local _, _, _, hasRewardPending = C_Reputation.GetFactionParagonInfo(data.factionID or 0)

            if data.name then
                if data.isHeader and not data.isChild then
                    if not skipFirst then
                        tinsert(categories, {
                            idx = idx,
                            idxLast = data.factionIndex - 1,
                            name = headerName,
                            standingCur = cCur,
                            standingMax = cMax,
                            fctTbl = sortFactionsStatus(factionTbl),
                            hasPendingParagonReward = hasPendingParagonReward,
                            pendingParagonRewardFactions = pendingParagonRewardFactions
                        })
                    end
                    skipFirst = false
                    cMax, cCur = 0, 0
                    factionTbl = {}
                    pendingParagonRewardFactions = {}
                    hasPendingParagonReward = false
                    idx = data.factionIndex
                    headerName = data.name
                else
                    if friendInfo and friendInfo.friendshipFactionID and friendInfo.friendshipFactionID > 0 then
                        local ranks = C_GossipInfo.GetFriendshipReputationRanks(friendInfo.friendshipFactionID)
                        cMax = cMax + ranks.maxLevel
                        cCur = cCur + ranks.currentLevel
                        addToFactionTable(factionTbl, ranks.currentLevel, friendInfo.reaction, true, data.name, hasRewardPending, pendingParagonRewardFactions)
                        if hasRewardPending then hasPendingParagonReward = true end
                    elseif IsMajorFaction(data.factionID) then
                        local major = C_MajorFactions.GetMajorFactionData(data.factionID)
                        if major then
                            local standingText = RENOWN_LEVEL_LABEL:format(major.renownLevel)
                            cMax = cMax + #C_MajorFactions.GetRenownLevels(data.factionID)
                            cCur = cCur + major.renownLevel
                            addToFactionTable(factionTbl, major.renownLevel, standingText, false, data.name, hasRewardPending, pendingParagonRewardFactions)
                            if hasRewardPending then hasPendingParagonReward = true end
                        end
                    elseif not data.isHeader then
                        local standingText = _G["FACTION_STANDING_LABEL" .. data.reaction]
                        cMax = cMax + 8
                        cCur = cCur + data.reaction
                        addToFactionTable(factionTbl, data.reaction, standingText, false, data.name, hasRewardPending, pendingParagonRewardFactions)
                        if hasRewardPending then hasPendingParagonReward = true end
                    end
                end
            end
        end
    end

    -- Final category insert
    if #factionTbl > 0 then
        tinsert(categories, {
            idx = idx,
            idxLast = #factionDataCache,
            name = headerName,
            standingCur = cCur,
            standingMax = cMax,
            fctTbl = sortFactionsStatus(factionTbl),
            hasPendingParagonReward = hasPendingParagonReward,
            pendingParagonRewardFactions = pendingParagonRewardFactions
        })
    end

    return categories, details
end

local function SetSelectedHeaderIndexRange(firstIndex, lastIndex)
    firstReputationCat = firstIndex
    lastReputationCat = lastIndex
end

local function detailsAtwar_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:SetText(REPUTATION_AT_WAR_DESCRIPTION, nil, nil, nil, nil, true)
    GameTooltip:Show()
end

local function detailsInactive_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:SetText(REPUTATION_MOVE_TO_INACTIVE, nil, nil, nil, nil, true)
    GameTooltip:Show()
end

local function detailsShowAsBar_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:SetText(REPUTATION_SHOW_AS_XP, nil, nil, nil, nil, true)
    GameTooltip:AddLine(L["Right-click a faction to toggle this directly."], 0.8, 0.8, 0.8, true)
    GameTooltip:Show()
end

local function LayoutDetailControls(self)
    local previous
    for _, row in ipairs({ self.atwar, self.showAsBar, self.inactive }) do
        if row:IsShown() then
            row:ClearAllPoints()
            if previous then
                row:SetPoint("LEFT", previous, "RIGHT", 20, 0)
            else
                row:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 10, 8)
            end
            previous = row
        end
    end
end

local function detailsControls_OnShow(self)
    -- no description: skip the empty dark block (the row is shorter then, see GetExpandedHeight)
    local showDescription = HasDescription(self:GetParent().data)
    self:GetParent().details:SetShown(showDescription)
    self:GetParent().detailsbg:SetShown(showDescription)

    self.atwar:SetShown(self.atwar.isShowAble)
    self.viewRenown:SetShown(self.viewRenown.isShowAble)
    self.inactive:SetShown(self.inactive.isShowAble)

    LayoutDetailControls(self)
end

local function detailsControls_OnHide(self)
    self:GetParent().details:Hide()
    self:GetParent().detailsbg:Hide()
end

local function ToggleDetailsButton(self, showDetails)
    self:SetHeight(showDetails and GetExpandedHeight(self.data) or DETAIL_H)
    self.controles:SetShown(showDetails)
    if showDetails then
        self.repbg:SetTexCoord(unpack(GW.TexCoords))
    else
        self.repbg:SetTexCoord(0, 1, REPBG_T, REPBG_B)
    end
    self.repbg:SetDesaturated(not showDetails)
end

local function ToggleDetails(self)
    if not self then return end
    g_selectionBehavior:ToggleSelect(self)
    ToggleDetailsButton(self, g_selectionBehavior:IsSelected(self))
end

local function ToggleWatchedFaction(data)
    if data.isWatched then
        SetWatchedFactionByIndex(0)
    else
        SetWatchedFactionByIndex(data.factionIndex)
    end
    isSearchResult = nil
    local _, details = CollectFactionData(true)
    UpdateDetailsData(GwRepDetailFrame.Details, details)
end

local function details_OnClick(self, mouseButton)
    if mouseButton == "RightButton" then
        if IsControlKeyDown() then
            UpdateSessionBaseline(true, true)
            isSearchResult = nil
            local _, details = CollectFactionData(true)
            UpdateDetailsData(GwRepDetailFrame.Details, details)
            return
        end
        ToggleWatchedFaction(self.data)
    else
        ToggleDetails(self)
    end
end

local function setReputationDetails(frame, data)
    frame.factionIndex = data.factionIndex
    frame.factionID = data.factionID

    if g_selectionBehavior:IsSelected(frame) then
        frame.controles:Show()
        frame:SetHeight(GetExpandedHeight(data))
    else
        frame:SetHeight(DETAIL_H)
        frame.controles:Hide()
    end

    local currentRank = GetText("FACTION_STANDING_LABEL" .. math.min(8, math.max(1, data.reaction)), GW.mysex)
    local nextRank = GetText("FACTION_STANDING_LABEL" .. math.min(8, math.max(1, data.reaction + 1)), GW.mysex)
    local friendInfo = C_GossipInfo.GetFriendshipReputation(data.factionID or 0)

    frame.background:SetTexture(nil)

    if data.isAccountWide then
        frame.accountWide:Show()
    else
        frame.accountWide:Hide()
    end

    if data.savedHeaderName ~= nil and data.savedHeaderName ~= "" and data.savedHeaderName ~= data.name then
        frame.name:SetText(data.name .. "  |cFFa0a0a0" .. data.savedHeaderName .. "|r")
    else
        frame.name:SetText(data.name)
    end
    frame.details:SetText(data.description)

    frame.controles.atwar.checkbutton:SetChecked(data.atWarWith)
    frame.atWarIndicator:ClearAllPoints()
    if data.isAccountWide then
        frame.atWarIndicator:SetPoint("RIGHT", frame.accountWide, "LEFT", -4, 0)
    else
        frame.atWarIndicator:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -8)
    end
    frame.atWarIndicator:SetShown(data.atWarWith)

    local sessionGain = GetSessionGain(data)
    if sessionGain ~= 0 then
        frame.sessionGain.text:SetText(L["%s this session"]:format((sessionGain > 0 and "+" or "-") .. GW.GetLocalizedNumber(math.abs(sessionGain))))
        if sessionGain > 0 then
            frame.sessionGain.text:SetTextColor(0.5, 1, 0.5)
        else
            frame.sessionGain.text:SetTextColor(1, 0.5, 0.5)
        end
        frame.sessionGain:SetWidth(math.max(10, frame.sessionGain.text:GetStringWidth()))
        frame.sessionGain:Show()
    else
        frame.sessionGain:Hide()
    end

    frame.controles.viewRenown.isShowAble = data.factionID and IsMajorFaction(data.factionID)
    frame.controles.atwar.isShowAble = data.canToggleAtWar
    frame.controles.showAsBar.checkbutton:SetChecked(data.isWatched)
    frame.controles.inactive.isShowAble = data.canSetInactive
    frame.controles.inactive.checkbutton:SetChecked(not GW.IsFactionActive(data.factionIndex))

    if frame.controles:IsShown() then
        detailsControls_OnShow(frame.controles)
    end

    if data.factionID and RT[data.factionID] then
        frame.repbg:SetTexture("Interface/AddOns/GW2_UI/textures/rep/" .. RT[data.factionID])
        if g_selectionBehavior:IsSelected(frame) then
            frame.repbg:SetTexCoord(unpack(GW.TexCoords))
            frame.repbg:SetAlpha(0.85)
            frame.repbg:SetDesaturated(false)
        else
            frame.repbg:SetTexCoord(0, 1, REPBG_T, REPBG_B)
            frame.repbg:SetAlpha(0.33)
            frame.repbg:SetDesaturated(true)
        end
    else
        GW.Debug("no faction", data.name, data.factionID)
        frame.repbg:SetAlpha(0)
    end

    local remaining, remainingTarget -- points to the next rank / reward; nil at max rank
    local pendingParagonReward = false
    if data.factionID and C_Reputation.IsFactionParagonForCurrentPlayer(data.factionID) then
        local currentValue, threshold, _, hasRewardPending = C_Reputation.GetFactionParagonInfo(data.factionID)
        local value = currentValue % threshold
        local isMajorFaction = IsMajorFaction(data.factionID)
        local majorFactionData = isMajorFaction and C_MajorFactions.GetMajorFactionData(data.factionID)
        local currentRankText = majorFactionData and RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel) or friendInfo.friendshipFactionID and friendInfo.reaction or currentRank

        pendingParagonReward = hasRewardPending

        frame.currentRank:SetText(currentRankText)
        frame.nextRank:SetText(L["Paragon"] .. (currentValue > threshold and (" (" .. RoundDec(currentValue / threshold, 0) .. "x)") or ""))

        frame.currentValue:SetText(GW.GetLocalizedNumber(value))
        frame.nextValue:SetText(GW.GetLocalizedNumber(threshold))

        local percent = math.floor(RoundDec(((value - 0) / (threshold - 0)) * 100))
        frame.percentage:SetText(percent .. "%")

        frame.StatusBar:SetMinMaxValues(0, 1)
        frame.StatusBar:SetValue((value - 0) / (threshold - 0))
        remaining, remainingTarget = threshold - value, L["Paragon"]

        frame.background2:SetVertexColor(GW.Colors.FactionBarColors[9]:GetRGB())
        frame.StatusBar:SetStatusBarColor(GW.Colors.FactionBarColors[9]:GetRGB())
    elseif friendInfo.friendshipFactionID > 0 then
        frame.StatusBar:SetMinMaxValues(0, 1)
        frame.currentRank:SetText(friendInfo.reaction)
        frame.nextRank:SetText()

        frame.background2:SetVertexColor(GW.Colors.FactionBarColors[5]:GetRGB())
        frame.StatusBar:SetStatusBarColor(GW.Colors.FactionBarColors[5]:GetRGB())

        if (friendInfo.nextThreshold) then
            frame.currentValue:SetText(GW.GetLocalizedNumber(friendInfo.standing - friendInfo.reactionThreshold))
            frame.nextValue:SetText(GW.GetLocalizedNumber(friendInfo.nextThreshold - friendInfo.reactionThreshold))

            local percent =
                math.floor(RoundDec(((friendInfo.standing - friendInfo.reactionThreshold) / (friendInfo.nextThreshold - friendInfo.reactionThreshold)) * 100))
            if percent == -1 then
                frame.percentage:SetText("0%")
            else
                frame.percentage:SetText(percent .. "%")
            end

            frame.StatusBar:SetValue((friendInfo.standing - friendInfo.reactionThreshold) / (friendInfo.nextThreshold - friendInfo.reactionThreshold))
            remaining = friendInfo.nextThreshold - friendInfo.standing
        else
            --max rank
            frame.StatusBar:SetValue(1)
            frame.nextValue:SetText()
            frame.currentValue:SetText()
            frame.percentage:SetText("100%")
        end
    elseif data.factionID and IsMajorFaction(data.factionID) then
        local majorFactionData = C_MajorFactions.GetMajorFactionData(data.factionID)
        if majorFactionData then
            frame.StatusBar:SetMinMaxValues(0, 1)

            frame.background2:SetVertexColor(GW.Colors.FactionBarColors[11]:GetRGB())
            frame.StatusBar:SetStatusBarColor(GW.Colors.FactionBarColors[11]:GetRGB())

            if C_MajorFactions.HasMaximumRenown(data.factionID) then
                --max rank
                frame.StatusBar:SetValue(1)

                frame.currentRank:SetText(RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel))
                frame.nextRank:SetText(RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel))

                frame.nextValue:SetText()
                frame.currentValue:SetText()
                frame.percentage:SetText("100%")
            else
                frame.nextRank:SetText(RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel + 1))
                frame.currentRank:SetText(RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel))

                frame.currentValue:SetText(GW.GetLocalizedNumber(majorFactionData.renownReputationEarned or 0))
                frame.nextValue:SetText(GW.GetLocalizedNumber(majorFactionData.renownLevelThreshold))
                frame.percentage:SetText((math.floor((majorFactionData.renownReputationEarned or 0) / majorFactionData.renownLevelThreshold * 100) .. "%"))

                frame.StatusBar:SetValue((majorFactionData.renownReputationEarned or 0) / majorFactionData.renownLevelThreshold)
                remaining = majorFactionData.renownLevelThreshold - (majorFactionData.renownReputationEarned or 0)
                remainingTarget = RENOWN_LEVEL_LABEL:format(majorFactionData.renownLevel + 1)
            end
        end
    else
        frame.currentRank:SetText(currentRank)
        frame.nextRank:SetText(nextRank)
        frame.currentValue:SetText(GW.GetLocalizedNumber(data.currentStanding - data.currentReactionThreshold))
        local ldiff = data.nextReactionThreshold - data.currentReactionThreshold
        if ldiff == 0 then
            ldiff = 1
        end
        local percent = math.floor(RoundDec(((data.currentStanding - data.currentReactionThreshold) / ldiff) * 100))
        if percent == -1 then
            frame.percentage:SetText("0%")
        else
            frame.percentage:SetText(percent .. "%")
        end

        frame.nextValue:SetText(GW.GetLocalizedNumber(ldiff))

        frame.StatusBar:SetMinMaxValues(0, 1)
        frame.StatusBar:SetValue((data.currentStanding - data.currentReactionThreshold) / ldiff)
        if currentRank ~= nextRank then
            remaining, remainingTarget = ldiff - (data.currentStanding - data.currentReactionThreshold), nextRank
        end

        if currentRank == nextRank and data.currentStanding - data.currentReactionThreshold == 0 then
            frame.percentage:SetText("100%")
            frame.StatusBar:SetValue(1)
            frame.nextValue:SetText()
            frame.currentValue:SetText()
        end

        frame.background2:SetVertexColor(GW.Colors.FactionBarColors[data.reaction]:GetRGB())
        frame.StatusBar:SetStatusBarColor(GW.Colors.FactionBarColors[data.reaction]:GetRGB())
    end

    if remaining and remaining > 0 then
        if remainingTarget then
            frame.remaining:SetText(L["%s until %s"]:format(GW.GetLocalizedNumber(remaining), remainingTarget))
        else
            frame.remaining:SetText(L["%s until next rank"]:format(GW.GetLocalizedNumber(remaining)))
        end
    else
        frame.remaining:SetText("")
    end

    if data.atWarWith then
        frame.background2:SetVertexColor(1, 0.1, 0.1)
        frame.repbg:SetVertexColor(1, 0.4, 0.4)
    else
        frame.repbg:SetVertexColor(1, 1, 1)
    end

    SetDetailsParagon(frame, pendingParagonReward)
end

local function status_SetValue(self)
    local v = self:GetValue()
    local _, max = self:GetMinMaxValues()
    local width = math.max(1, math.min(10, 10 * ((v / max) / 0.1)))

    if v == max then
        self.spark:Hide()
    else
        self.spark:SetPoint("RIGHT", self, "LEFT", self:GetWidth() * (v / max), 0)
        self.spark:SetWidth(width)
        self.spark:Show()
    end
end

local function detailsInactive_OnClick(self)
    local parent = self:GetParent():GetParent()
    isSearchResult = nil
    local shouldBeActive = not GW.IsFactionActive(parent.data.factionIndex)
    GW.SetFactionActive(parent.data.factionIndex, shouldBeActive)
    local categories, details = CollectFactionData(true)
    UpdateCategories(GwPaperReputation.Categories, categories)
    local firstCategory = GwPaperReputation.Categories:FindElementData(1)
    if firstCategory then
        SetSelectedHeaderIndexRange(firstCategory.idx, firstCategory.idxLast)
        categories, details = CollectFactionData()
    end
    UpdateDetailsData(GwRepDetailFrame.Details, details)
end

local function detailsAtwar_OnClick(self)
    local parent = self:GetParent():GetParent()
    ToggleFactionAtWar(parent.data.factionIndex)
    if parent.data.canToggleAtWar then
        PlaySound(parent.data.atWarWith and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF or SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        isSearchResult = nil
        local _, details = CollectFactionData(true)
        UpdateDetailsData(GwRepDetailFrame.Details, details)
    end
end

local function detailsViewRenown_OnClick(self)
    if not EncounterJournal and EncounterJournal_LoadUI then
		EncounterJournal_LoadUI()
	end

	if EncounterJournal and not EncounterJournal:IsShown() then
		ShowUIPanel(EncounterJournal)
	end

    local parent = self:GetParent():GetParent()
	EJ_ContentTab_Select(EncounterJournal.JourneysTab:GetID())
	EncounterJournalJourneysFrame:ResetView(nil, parent.data.factionID)
end

local function detailsShowAsBar_OnClick(self)
    local parent = self:GetParent():GetParent()
    ToggleWatchedFaction(parent.data)
end

local function InitDetailsButton(button, elementData)
    if not button.gwSkinned then

        SetFontWithShadow(button.controles.atwar.string, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.controles.inactive.string, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.controles.showAsBar.string, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.StatusBar.currentValue, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.StatusBar.percentage, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.StatusBar.nextValue, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)

        SetFontWithShadow(button.currentRank, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.nextRank, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        SetFontWithShadow(button.remaining, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        button.remaining:SetTextColor(0.8, 0.8, 0.8)
        SetFontWithShadow(button.sessionGain.text, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
        button.sessionGain:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.text:GetText(), 1, 1, 1)
            GameTooltip:AddLine(L["Reset Session Data: Hold Ctrl + Right Click"], 0.6, 0.6, 0.6, true)
            GameTooltip:Show()
        end)
        button.sessionGain:SetScript("OnLeave", GameTooltip_Hide)
        button.sessionGain:SetScript("OnMouseUp", function(_, mouseButton) details_OnClick(button, mouseButton) end)
        SetFontWithShadow(button.name, DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Normal)
        SetFontWithShadow(button.details, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)

        button.currentRank:SetTextColor(0.6, 0.6, 0.6)
        button.nextRank:SetTextColor(0.6, 0.6, 0.6)
        button.name:SetTextColor(1, 1, 1, 1)
        button.details:SetTextColor(0.8, 0.8, 0.8, 1)

        button.StatusBar:SetMinMaxValues(0, 1)
        button.StatusBar:SetStatusBarColor(240 / 255, 240 / 255, 155 / 255)
        hooksecurefunc(button.StatusBar, "SetValue", status_SetValue)
        button.StatusBar:GetParent().currentValue = button.StatusBar.currentValue
        button.StatusBar:GetParent().percentage = button.StatusBar.percentage
        button.StatusBar:GetParent().nextValue = button.StatusBar.nextValue

        button.controles:SetScript("OnShow", detailsControls_OnShow)
        button.controles:SetScript("OnHide", detailsControls_OnHide)
        button.controles.atwar:SetScript("OnEnter", detailsAtwar_OnEnter)
        button.controles.atwar:SetScript("OnLeave", GameTooltip_Hide)
        button.controles.atwar:SetScript("OnClick", detailsAtwar_OnClick)
        button.controles.atwar.checkbutton:SetScript("OnClick", function() detailsAtwar_OnClick(button.controles.atwar) end)
        button.controles.atwar.checkbutton:SetScript("OnEnter", function() detailsAtwar_OnEnter(button.controles.atwar) end)
        button.controles.atwar.checkbutton:SetScript("OnLeave", GameTooltip_Hide)
        button.controles.viewRenown:SetScript("OnClick", detailsViewRenown_OnClick)
        button.controles.inactive:SetScript("OnEnter", detailsInactive_OnEnter)
        button.controles.inactive:SetScript("OnLeave", GameTooltip_Hide)
        button.controles.inactive.checkbutton:SetScript("OnEnter", detailsInactive_OnEnter)
        button.controles.inactive.checkbutton:SetScript("OnLeave", GameTooltip_Hide)
        button.controles.inactive:SetScript("OnClick", detailsInactive_OnClick)
        button.controles.inactive.checkbutton:SetScript("OnClick", function() detailsInactive_OnClick(button.controles.inactive) end)
        button.controles.showAsBar:SetScript("OnEnter", detailsShowAsBar_OnEnter)
        button.controles.showAsBar:SetScript("OnLeave", GameTooltip_Hide)
        button.controles.showAsBar:SetScript("OnClick", detailsShowAsBar_OnClick)
        button.controles.showAsBar.checkbutton:SetScript("OnClick", function() detailsShowAsBar_OnClick(button.controles.showAsBar) end)
        button.controles.showAsBar.checkbutton:SetScript("OnEnter", detailsShowAsBar_OnEnter)
        button.controles.showAsBar.checkbutton:SetScript("OnLeave", GameTooltip_Hide)
        if GW.isModern then
            button.accountWide.Icon:SetAtlas("warbands-icon", true)
        end
        button.accountWide:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(REPUTATION_TOOLTIP_ACCOUNT_WIDE_LABEL, 1, 1, 1)
            GameTooltip:Show()
        end)
        button.accountWide:SetScript("OnLeave", GameTooltip_Hide)
        button.atWarIndicator:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(AT_WAR, 1, 1, 1)
            GameTooltip:AddLine(REPUTATION_AT_WAR_DESCRIPTION, 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
        end)
        button.atWarIndicator:SetScript("OnLeave", GameTooltip_Hide)
        button.atWarIndicator:SetScript("OnMouseUp", function(_, mouseButton) details_OnClick(button, mouseButton) end)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        button:SetScript("OnClick", details_OnClick)
        button:SetScript("OnEnter", function(self)
            self.repbg:SetBlendMode("ADD")
            self.background:SetBlendMode("ADD")
            self.background2:SetBlendMode("ADD")
        end)
        button:SetScript("OnLeave", function(self)
            self.repbg:SetBlendMode("BLEND")
            self.background:SetBlendMode("BLEND")
            self.background2:SetBlendMode("BLEND")
        end)

        button.controles.atwar.string:SetText(AT_WAR)
        button.controles.atwar:SetWidth(22 + button.controles.atwar.string:GetStringWidth())
        button.controles.inactive.string:SetText(FACTION_INACTIVE)
        button.controles.inactive:SetWidth(22 + button.controles.inactive.string:GetStringWidth())
        button.controles.showAsBar.string:SetText(SHOW_FACTION_ON_MAINSCREEN)
        button.controles.showAsBar:SetWidth(22 + button.controles.showAsBar.string:GetStringWidth())
        button.currentRank:SetText(REFORGE_CURRENT)
        button.nextRank:SetText(NEXT)

        button.details:SetPoint("TOPLEFT", button.StatusBar, "BOTTOMLEFT", 0, -25)
        button.statusbarbg:SetPoint("TOPLEFT", button.StatusBar, "TOPLEFT", -2, 2)
        button.statusbarbg:SetPoint("BOTTOMRIGHT", button.StatusBar, "BOTTOMRIGHT", 2, -2)
        button.currentRank:SetPoint("TOPLEFT", button.StatusBar, "BOTTOMLEFT", 0, -5)
        button.nextRank:SetPoint("TOPRIGHT", button.StatusBar, "BOTTOMRIGHT", 0, -5)
        button.remaining:ClearAllPoints()
        button.remaining:SetPoint("TOP", button.StatusBar, "BOTTOM", 0, -5)
        button.sessionGain:ClearAllPoints()
        button.sessionGain:SetPoint("RIGHT", button.atWarIndicator, "LEFT", -6, 0)

        button.details:Hide()
        button.detailsbg:Hide()
        button.details:SetWidth(button.StatusBar:GetWidth())
        button.repbg:SetTexCoord(0, 1, REPBG_T, REPBG_B)
        button.repbg:SetDesaturated(true)

        button.gwSkinned = true
    end
    button.data = elementData
    setReputationDetails(button, elementData)
end

local function InitCategorieButton(button, elementData)
    if not button.gwSkinned then
        SetFontWithShadow(button.name, DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.Normal)
        SetFontWithShadow(button.StatusBar.percentage, UNIT_NAME_FONT, GW.Enum.TextSizeType.Small, -2)

        button.name:SetTextColor(1, 1, 1, 1)

        hooksecurefunc(button.StatusBar, "SetValue", function(self)
                local v = self:GetValue()
                local width = math.max(1, math.min(10, 10 * ((v / 1) / 0.1)))
                if v == max then
                    button.StatusBar.Spark:Hide()
                else
                    button.StatusBar.Spark:SetPoint("RIGHT", self, "LEFT", 201 * (v / 1), 0)
                    button.StatusBar.Spark:SetWidth(width)
                    button.StatusBar.Spark:Show()
                end
            end)
        button:SetScript("OnClick", function(self)
            isSearchResult = nil
            SetSelectedHeaderIndexRange(self.factionIndexFirst, self.factionIndexLast)
            local categories, details = CollectFactionData()
            UpdateCategories(GwPaperReputation.Categories, categories)
            UpdateDetailsData(GwRepDetailFrame.Details, details)
        end)
        button:SetScript("OnEnter", function(self)
            local addedFriendTitle = false
            self.backgroundHover:SetBlendMode("ADD")
            self.zebra:SetBlendMode("ADD")
            self.StatusBar.percentage:Show()

            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            GameTooltip:SetText(ACHIEVEMENT_SUMMARY_CATEGORY, 1, 1, 1)

            for _, v in pairs(self.standings) do
                if v.isFriend and not addedFriendTitle then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine(FRIENDS, 1, 1, 1)
                    addedFriendTitle = true
                end
                GameTooltip:AddDoubleLine(v.standingText, v.counter)
            end
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function(self)
            self.backgroundHover:SetBlendMode("BLEND")
            self.zebra:SetBlendMode("BLEND")
            self.StatusBar.percentage:Hide()
            GameTooltip:Hide()
        end)
        button.paragonIndicator:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L["Paragon"], 1, 1, 1)
            for _, v in pairs(button.pendingParagonRewardFactions) do
                GameTooltip:AddLine(v.name)
            end
            GameTooltip:Show()
        end)
        button.paragonIndicator:SetScript("OnLeave", GameTooltip_Hide)

        AddParagonIndicatorAnimation(button.paragonIndicator)

        function button:StopParagonIdicatorAnimation()
            self.paragonIndicator:Hide()
            self.paragonIndicator.animationGroup:Stop()
        end

        function button:StartParagonIdicatorAnimation()
            self.paragonIndicator:Show()
            self.paragonIndicator.animationGroup:Play()
        end

        GwPaperReputation:HookScript("OnHide", function()
           button:StopParagonIdicatorAnimation()
        end)

        button.gwSkinned = true
    end

    button.factionIndexFirst = elementData.idx
    button.factionIndexLast = elementData.idxLast
    button.standings = elementData.fctTbl
    button.pendingParagonRewardFactions = elementData.pendingParagonRewardFactions

    button.name:SetText(elementData.name)
    if elementData.name ~= COVENANT_SANCTUM_TIER_INACTIVE and elementData.standingCur and elementData.standingCur > 0 and elementData.standingMax and elementData.standingMax > 0 then
        button.StatusBar:SetValue(elementData.standingCur / elementData.standingMax)
        button.StatusBar.percentage:SetText(math.floor(RoundDec(button.StatusBar:GetValue() * 100)) .. "%")
        if elementData.standingCur / elementData.standingMax >= 1 and elementData.standingMax ~= 0 then
            button.StatusBar:SetStatusBarColor(171 / 255, 37 / 255, 240 / 255)
            button.StatusBar.Spark:Hide()
        else
            button.StatusBar:SetStatusBarColor(GW.Colors.FactionBarColors[5]:GetRGB())
        end
        button.StatusBar:Show()
        button.statusbarbg:Show()
    else
        button.StatusBar:Hide()
        button.statusbarbg:Hide()
    end
    -- paragonIndicator
    button:StopParagonIdicatorAnimation()
    if GwPaperReputation:IsShown() then
        if elementData.hasPendingParagonReward then
            button:StartParagonIdicatorAnimation()
        end
    end

    local zebra = button:GetElementDataIndex() % 2
    if button.factionIndexFirst == firstReputationCat then
        button.zebra:SetVertexColor(1, 1, 0.5, 0.15)
    else
        button.zebra:SetVertexColor(zebra, zebra, zebra, 0.05)
    end
end

-- opens the category of a faction, selects it with its details and scrolls it into view
local function ShowFaction(factionID)
    if not factionID or not g_selectionBehavior then return end
    if GwPaperReputation.input:GetText() ~= "" then
        GwPaperReputation.input:SetText("")
    end
    isSearchResult = nil

    local categories = CollectFactionData(true)
    local factionIndex
    for _, data in ipairs(factionDataCache) do
        if data.factionID == factionID then
            factionIndex = data.factionIndex
            break
        end
    end
    if not factionIndex then return end
    for _, category in ipairs(categories) do
        if factionIndex >= category.idx and factionIndex <= category.idxLast then
            SetSelectedHeaderIndexRange(category.idx, category.idxLast)
            break
        end
    end

    local _, details = CollectFactionData()
    UpdateCategories(GwPaperReputation.Categories, categories)
    UpdateDetailsData(GwRepDetailFrame.Details, details)

    local function IsFaction(elementData)
        return elementData.factionID == factionID
    end
    g_selectionBehavior:SelectElementDataByPredicate(IsFaction)
    GwRepDetailFrame.Details:ScrollToElementDataByPredicate(IsFaction, ScrollBoxConstants.AlignCenter)
end

-- the reputation tab with the given faction picked; without the gw2 character window blizzards frame opens
function GW.ShowReputationFaction(factionID)
    if InCombatLockdown() then return end
    if not GwPaperReputation then
        ToggleCharacter("ReputationFrame")
    elseif not GwPaperReputation:IsVisible() then
        GwCharacterWindow:SetAttribute("windowpanelopen", "reputation")
    end
    if GwPaperReputation then
        RunNextFrame(function()
            if GwPaperReputation:IsVisible() then
                ShowFaction(factionID)
            end
        end)
    end
end

function GW.LoadReputation(tabContainer)
    local fmGPR = CreateFrame("Frame", "GwPaperReputation", tabContainer, "GwPaperReputationTemplate")
    local fmDetail = CreateFrame("Frame", "GwRepDetailFrame", tabContainer, "GwRepDetailFrameTemplate")
    local view = CreateScrollBoxListLinearView()

    view:SetElementInitializer("GwPaperDollReputationCatTemplate", function(button, elementData)
        InitCategorieButton(button, elementData)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(fmGPR.Categories, fmGPR.ScrollBar, view)
    GW.HandleTrimScrollBar(fmGPR.ScrollBar)
    GW.HandleScrollControls(fmGPR)
    fmGPR.ScrollBar:SetHideIfUnscrollable(true)

    local fnGPR_OnEvent = function(_, event)
        if not GW.inWorld or not fmGPR:IsShown() then
            return
        end
        if not updateQueued then
            updateQueued = true
            C_Timer.After(0.2, function()
                isSearchResult = nil
                local _, details = CollectFactionData(true)
                UpdateDetailsData(fmDetail.Details, details)
                GW.Debug("Reputation", event)
                updateQueued = false
            end)
        end
    end
    fmGPR.Categories:SetScript("OnEvent", fnGPR_OnEvent)
    GW.SkinEditBox(fmGPR.input, {search = true})
    fmGPR.input:SetScript("OnEnterPressed", fmGPR.input.ClearFocus)
    fmGPR.input:HookScript("OnTextChanged", function(self)
        local text = self:GetText()
        isSearchResult = text ~= "" and text or nil
        local _, details = CollectFactionData()
        UpdateDetailsData(fmDetail.Details, details)
    end)

    local detailsView = CreateScrollBoxListLinearView()
    detailsView:SetElementInitializer("GwReputationDetailsTemplate", function(button, elementData)
        InitDetailsButton(button, elementData)
    end)
    detailsView:SetElementResetter(function(button)
        SetDetailsParagon(button, false)
    end)
    detailsView:SetPadding(5, 5, 12, 12, 10)
    detailsView:SetElementExtentCalculator(function(dataIndex, elementData)
        if SelectionBehaviorMixin.IsElementDataIntrusiveSelected(elementData) then
            return GetExpandedHeight(elementData)
        else
            return DETAIL_H
        end
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(fmDetail.Details, fmDetail.ScrollBar, detailsView)

    g_selectionBehavior = ScrollUtil.AddSelectionBehavior(fmDetail.Details, SelectionBehaviorFlags.Deselectable, SelectionBehaviorFlags.Intrusive);
    g_selectionBehavior:RegisterCallback(SelectionBehaviorMixin.Event.OnSelectionChanged, function(o, elementData, selected)
        local button = fmDetail.Details:FindFrame(elementData)
        if not button then return end
        ToggleDetailsButton(button, selected)
    end, fmDetail)

    ScrollUtil.AddResizableChildrenBehavior(fmDetail.Details)

    GW.HandleTrimScrollBar(fmDetail.ScrollBar)
    GW.HandleScrollControls(fmDetail)
    fmDetail.ScrollBar:SetHideIfUnscrollable(true)

    ReputationFrame:UnregisterAllEvents()

    local firstShow = true
    fmGPR:HookScript("OnShow", function(self)
        FrameUtil.RegisterFrameForEvents(self.Categories, ReputationFrameEvents)
        isSearchResult = nil
        local cat, detailsOnShow = CollectFactionData(true)
        UpdateCategories(fmGPR.Categories, cat)
        if firstShow then
            firstShow = false
            local firstCategory = fmGPR.Categories:FindElementData(1)
            if firstCategory then
                SetSelectedHeaderIndexRange(firstCategory.idx, firstCategory.idxLast)
                _, detailsOnShow = CollectFactionData()
            end
        end
        UpdateDetailsData(fmDetail.Details, detailsOnShow)
    end)

    fmGPR:HookScript("OnHide", function(self)
        FrameUtil.UnregisterFrameForEvents(self.Categories, ReputationFrameEvents)
    end)
end
