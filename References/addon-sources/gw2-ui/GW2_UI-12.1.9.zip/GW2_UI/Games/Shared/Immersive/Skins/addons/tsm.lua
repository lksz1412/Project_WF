---@class GW2
local GW = select(2, ...)

local skinLoaded = false

local function AddTsmTab()
    if AuctionHouseFrame:GetScale() < 0.5 then
        return
    end
    if skinLoaded then return end
    local libAhTab = LibStub:GetLibrary("LibAHTab-1-0", true)
    local tab = libAhTab and libAhTab:DoesIDExist("TSM_AH_TAB") and libAhTab:GetButton("TSM_AH_TAB")
    if not tab then return end
    skinLoaded = true

    if not tab.gwSkinned then
        local iconTexture = "Interface/AddOns/GW2_UI/textures/Auction/tabicon_addon_tsm.png"
        GW.SkinSideTabButton(tab, iconTexture, "TSM")
    end

    tab:ClearAllPoints()
    tab:SetPoint("TOPRIGHT", AuctionHouseFrame.LeftSidePanel, "TOPLEFT", 1, -32 + (-40 * GW.ActionHouseTabsAdded))
    tab:SetParent(AuctionHouseFrame.LeftSidePanel)
    tab:SetSize(64, 40)
    GW.ActionHouseTabsAdded = GW.ActionHouseTabsAdded + 1
end

local function LoadTSMAddonSkin()
    if not GW.settings.skins.auctionHouse.enabled or not TSM_API or not AuctionatorAHFrameMixin then return end
    local function AddTsmTabLater()
        RunNextFrame(AddTsmTab)
    end
    local displayModeHooked = false
    hooksecurefunc(AuctionatorAHFrameMixin, "OnShow", function()
        AddTsmTabLater()
        if not displayModeHooked then
            displayModeHooked = true
            hooksecurefunc(AuctionHouseFrame, "SetDisplayMode", AddTsmTabLater)
        end
    end)
end
GW.LoadTSMAddonSkin = LoadTSMAddonSkin