---@class GW2
local GW = select(2, ...)

local function ApplyFlightMapSkin()
    if not GW.settings.skins.flightMap.enabled then return end

    TaxiFrame:GwStripTextures()

    GW.CreateFrameHeaderWithBody(TaxiFrame, TaxiMerchant, "Interface/AddOns/GW2_UI/textures/character/addon-window-icon.png", nil, nil, nil, true)
    TaxiFrame.gwHeader.windowIcon:SetSize(48, 48)
    TaxiFrame.gwHeader.windowIcon:ClearAllPoints()
    TaxiFrame.gwHeader.windowIcon:SetPoint("CENTER", TaxiFrame.gwHeader, "BOTTOMLEFT", 6 + 24, 19)

    TaxiFrame:HookScript("OnShow", function()
        GW.SetHeaderPortrait(TaxiFrame.gwHeader, "NPC")
    end)

    TaxiFrame:SetSize(350, 400)

    TaxiRouteMap:ClearAllPoints()
    TaxiRouteMap:SetPoint("TOP", TaxiFrame, 0, -37)
    TaxiMap:ClearAllPoints()
    TaxiMap:SetPoint("TOP", TaxiFrame, 0, -37)
    TaxiCloseButton:GwSkinButton(true, false)
    TaxiCloseButton:SetSize(25, 25)
    TaxiCloseButton:ClearAllPoints()
    TaxiCloseButton:SetPoint("TOPRIGHT", TaxiFrame, "TOPRIGHT", 0, 4)
    TaxiCloseButton:SetParent(TaxiFrame)
end

local function LoadFlightMapSkin()
    GW.RegisterLoadHook(ApplyFlightMapSkin, "Blizzard_FlightMap", TaxiFrame)
end
GW.LoadFlightMapSkin = LoadFlightMapSkin