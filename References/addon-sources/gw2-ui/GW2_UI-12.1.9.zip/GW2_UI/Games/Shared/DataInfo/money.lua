---@class GW2
local GW = select(2, ...)
local L = GW.L
local GetStorage = GW.GetStorage
local ClearStorage = GW.ClearStorage
local UpdateCharData = GW.UpdateCharData
local FormatMoneyForChat = GW.FormatMoneyForChat

local ALLIANCE_ICON = "|TInterface/AddOns/GW2_UI/Textures/social/GameIcons/Launcher/alliance.png:13:13|t"
local HORDE_ICON = "|TInterface/AddOns/GW2_UI/Textures/social/GameIcons/Launcher/horde.png:13:13|t"
local NEUTRAL_ICON = "|TInterface/Timer/Panda-Logo:14|t"

local Ticker = nil
local warbandGold = 0

local function UpdateMarketPrice()
    if C_WowTokenPublic and C_WowTokenPublic.UpdateMarketPrice then
        return C_WowTokenPublic.UpdateMarketPrice()
    end
end

local function UpdateWarbandGold()
    if C_Bank and C_Bank.FetchDepositedMoney and Enum.BankType and Enum.BankType.Account and C_Bank.CanViewBank(Enum.BankType.Account) then
        warbandGold = C_Bank.FetchDepositedMoney(Enum.BankType.Account) or 0
    end
end

local function GetGraysValue()
    local total = 0
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local itemLink = C_Container.GetContainerItemLink(bag, slot)
            if itemLink then
                local _, _, rarity, _, _, itemType, _, _, _, _, itemPrice = C_Item.GetItemInfo(itemLink)
                if itemPrice and rarity == 0 and itemType ~= "Quest" then
                    local item = C_Container.GetContainerItemInfo(bag, slot)
                    total = total + itemPrice * (item.stackCount or 1)
                end
            end
        end
    end

    return total
end

local function Money_OnClick(self, button)
    if button == "RightButton" then
        if IsShiftKeyDown() then
            MenuUtil.CreateContextMenu(self, function(ownerRegion, rootDescription)
                rootDescription:SetMinimumWidth(1)
                rootDescription:CreateTitle(DELETE)
                for _, char in pairs(GetStorage(nil, "REALM") or {}) do
                    if char and type(char) == "table" and char.money and char.money >= 0 then
                        rootDescription:CreateButton(format("%s - %s", char.name, char.faction), function()
                            ClearStorage(nil, char.name)
                            UpdateCharData()
                        end)
                    end
                end
            end)
        elseif IsControlKeyDown() then
            GW.earnedMoney = 0
            GW.spentMoney = 0
        end
        self:GetScript("OnEnter")(self)
    end

end
GW.Money_OnClick = Money_OnClick

local function OnEvent(self, event)
    if not IsLoggedIn() then return end

    UpdateWarbandGold()

    if not Ticker and C_WowTokenPublic and C_WowTokenPublic.UpdateMarketPrice then
        C_WowTokenPublic.UpdateMarketPrice()
        Ticker = C_Timer.NewTicker(60, UpdateMarketPrice)
    end
end
GW.MoneyOnEvent = OnEvent

local function Money_OnEnter(self)
    local list = GetStorage(nil, "REALM")
    if not list then return end

    local chars, totalAlliance, totalHorde, totalNeutral = {}, 0, 0, 0
    for _, char in pairs(list) do
        if char and type(char) == "table" and char.money and char.money >= 0 then
            local entry = {
                name = char.name,
                amount = char.money,
                class = char.class,
                faction = char.faction or "Neutral"
            }
            tinsert(chars, entry)

            if entry.faction == "Alliance" then
                totalAlliance = totalAlliance + entry.amount
            elseif entry.faction == "Horde" then
                totalHorde = totalHorde + entry.amount
            else
                totalNeutral = totalNeutral + entry.amount
            end
        end
    end

    sort(chars, function(a, b) return a.amount > b.amount end)

    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:ClearLines()

    GameTooltip:AddLine(L["Session:"])
    GameTooltip:AddDoubleLine(L["Earned:"], FormatMoneyForChat(GW.earnedMoney), 1, 1, 1, 1, 1, 1)
    GameTooltip:AddDoubleLine(L["Spent:"], FormatMoneyForChat(GW.spentMoney), 1, 1, 1, 1, 1, 1)

    local profit = GW.earnedMoney - GW.spentMoney
    if profit ~= 0 then
        local label = profit > 0 and L["Profit:"] or L["Deficit:"]
        local r, g = profit > 0 and 0 or 1, profit > 0 and 1 or 0
        GameTooltip:AddDoubleLine(label, FormatMoneyForChat(abs(profit)), r, g, 0, 1, 1, 1)
    end

    GameTooltip:AddLine(" ")

    -- list all players from the realm
    GameTooltip:AddLine(CHARACTER .. ":")
    for _, g in pairs(chars) do
        local color = GW.GWGetClassColor(g.class, true)
        local icon = g.faction == "Alliance" and ALLIANCE_ICON or g.faction == "Horde" and HORDE_ICON or NEUTRAL_ICON
        local label = format("%s%s", icon, g.name)
        if g.name == GetStorage("name") then
            label = label .. " |TInterface/COMMON/Indicator-Green:14:14:0:-2|t"
        end
        GameTooltip:AddDoubleLine(label, FormatMoneyForChat(g.amount), color.r, color.g, color.b, 1, 1, 1)
    end

    -- add total gold on realm
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(FRIENDS_LIST_REALM)

    if totalAlliance > 0 and totalHorde > 0 then
        if totalAlliance > 0 then GameTooltip:AddDoubleLine(FACTION_ALLIANCE, FormatMoneyForChat(totalAlliance), GW.Colors.FactionColors.Alliance.r, GW.Colors.FactionColors.Alliance.g, GW.Colors.FactionColors.Alliance.b, 1, 1, 1) end
        if totalHorde > 0 then GameTooltip:AddDoubleLine(FACTION_HORDE, FormatMoneyForChat(totalHorde), GW.Colors.FactionColors.Horde.r, GW.Colors.FactionColors.Horde.g, GW.Colors.FactionColors.Horde.b, 1, 1, 1) end
        GameTooltip:AddLine(" ")
    end

    GameTooltip:AddDoubleLine(TOTAL .. ":", FormatMoneyForChat(totalAlliance + totalHorde + totalNeutral), 1, 1, 1, 1, 1, 1)

    if Enum.BankType and C_Bank and C_Bank.CanViewBank and C_Bank.CanViewBank(Enum.BankType.Account) then
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(L["Warband:"], FormatMoneyForChat(warbandGold), 1, 1, 1, 1, 1, 1)
    end

    GameTooltip:AddLine(" ")
    UpdateMarketPrice()
    GameTooltip:AddDoubleLine(TOKEN_FILTER_LABEL .. ":", FormatMoneyForChat(C_WowTokenPublic.GetCurrentMarketPrice() or 0), 0, 0.8, 1, 1, 1, 1)

    local grayValue = GetGraysValue()
    if grayValue > 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(L["Grays"] , FormatMoneyForChat(grayValue), nil, nil, nil, 1, 1, 1)
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("|cffaaaaaa" .. L["Reset Session Data: Hold Ctrl + Right Click"] .. "|r")
    GameTooltip:AddLine("|cffaaaaaa" .. L["Reset Character Data: Hold Shift + Right Click"] .. "|r")

    GameTooltip:Show()
end
GW.Money_OnEnter = Money_OnEnter