---@class GW2
local GW = select(2, ...)

local function ReskinWhoFrameButton(button)
    if not button.gwSkinned then
        button.Variable:SetFont(UNIT_NAME_FONT, 11)
        button.Level:SetFont(UNIT_NAME_FONT, 11)
        button.Class:SetFont(UNIT_NAME_FONT, 11)
        GW.AddListItemChildHoverTexture(button)
        button.gwSkinned = true
    end
end

-- 12.1: The Who window still lives in the old FriendsFrame — when the SocialUI is active,
-- Blizzard hides all tabs there except "Who". The legacy window therefore gets
-- its GW header here.
local function SkinLegacyFriendsFrame()
    GW.HandlePortraitFrame(FriendsFrame)
    if FriendsFrameIcon then
        FriendsFrameIcon:SetAlpha(0)
    end
    FriendsFrameCloseButton:SetPoint("TOPRIGHT", -5, -2)

    GW.CreateFrameHeaderWithBody(FriendsFrame, FriendsFrameTitleText, "Interface/AddOns/GW2_UI/textures/social/social-windowheader.png", WhoFrame and {WhoFrame.ScrollBox} or {}, nil, true, true)
    FriendsFrame.gwHeader.windowIcon:ClearAllPoints()
    FriendsFrame.gwHeader.windowIcon:SetPoint("CENTER", FriendsFrame.gwHeader, "BOTTOMLEFT", -26, 35)
    FriendsFrameTitleText:ClearAllPoints()
    FriendsFrameTitleText:SetPoint("BOTTOMLEFT", FriendsFrame.gwHeader, "BOTTOMLEFT", 25, 10)
    FriendsFrameTitleText:GwSetFontTemplate(DAMAGE_TEXT_FONT, GW.Enum.TextSizeType.BigHeader, nil, 2)
    FriendsFrame:SetClampedToScreen(true)
    FriendsFrame:SetClampRectInsets(-40, 0, FriendsFrame.gwHeader:GetHeight() - 30, 0)

    for i = 1, FRIEND_TAB_COUNT do
        local tab = _G["FriendsFrameTab" .. i]
        if tab then
            tab:GwStripTextures()
            if tab.Text then
                tab.Text:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
            end
        end
    end

    if FriendsFrameBattlenetFrame and FriendsFrameBattlenetFrame.UnavailableInfoFrame then
        FriendsFrameBattlenetFrame.UnavailableInfoFrame:ClearAllPoints()
        FriendsFrameBattlenetFrame.UnavailableInfoFrame:SetPoint("TOPLEFT", FriendsFrame.gwHeader, "TOPRIGHT", 1, -18)
    end
end

-- Forever keeps the old window without the who list
function GW.SkinSocialUIWhoList()
    SkinLegacyFriendsFrame()
    if not WhoFrame then return end

    WhoFrameTotals:SetTextColor(1, 1, 1)
    WhoFrameListInset:SetAlpha(0)

    GW.HandleTrimScrollBar(WhoFrame.ScrollBar)
    GW.HandleScrollControls(WhoFrame)

    -- rows first, the hover helper skips rows already marked as skinned
    hooksecurefunc(WhoFrame.ScrollBox, "Update", function(scrollBox)
        scrollBox:ForEachFrame(ReskinWhoFrameButton)
    end)
    hooksecurefunc(WhoFrame.ScrollBox, "Update", GW.HandleItemListScrollBoxHover)

    if WhoFrameEditBox.Backdrop then
        WhoFrameEditBox.Backdrop:SetAlpha(0)
    end
    GW.SkinEditBox(WhoFrameEditBox, {search = true})

    for _, frame in ipairs({WhoFrameColumnHeader1, WhoFrameColumnHeader2, WhoFrameColumnHeader3, WhoFrameColumnHeader4}) do
        frame:GwStripTextures()
        local r = {frame:GetRegions()}
        for _, c in pairs(r) do
            if c:GetObjectType() == "FontString" then
                c:GwSetFontTemplate(UNIT_NAME_FONT, GW.Enum.TextSizeType.Small)
            end
        end
        GW.HandleScrollFrameHeaderButton(frame)
    end

    GW.SkinWhoFrameDropdown()

    WhoFrameColumnHeader1:SetPoint("BOTTOMLEFT", WhoFrameListInset, "TOPLEFT", 5, 0)
    WhoFrameWhoButton:GwSkinButton(false, true)
    WhoFrameAddFriendButton:GwSkinButton(false, true)
    WhoFrameGroupInviteButton:GwSkinButton(false, true)
end
