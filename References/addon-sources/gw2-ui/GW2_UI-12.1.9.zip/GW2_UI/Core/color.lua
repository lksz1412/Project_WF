---@class GW2
local GW = select(2, ...)

GW.Colors.TextColors = {
    LightHeader = CreateColor(1, 0.9450, 0.8196),
    Guild = CreateColor(0, 1, 16 / 255),
}

-- wine red: the dominant tone of the settings panel background (settingspanelbg.png,
-- ~48/24/24) lifted to accent brightness while keeping its 2:1:1 hue; the expansion
-- clients take the color of their expansion so the settings show which client is running
GW.Colors.Accent = (GW.Classic and CreateColor(190 / 255, 150 / 255, 60 / 255)) -- gold
    or (GW.TBC and CreateColor(90 / 255, 160 / 255, 40 / 255)) -- fel green
    or (GW.Wrath and CreateColor(70 / 255, 140 / 255, 190 / 255)) -- ice blue
    or (GW.Cata and CreateColor(200 / 255, 95 / 255, 35 / 255)) -- fire orange
    or (GW.Mists and CreateColor(40 / 255, 150 / 255, 120 / 255)) -- jade
    or (GW.Retail and CreateColor(120 / 255, 70 / 255, 180 / 255)) -- void purple
    or (GW.Forever and CreateColor(175 / 255, 120 / 255, 70 / 255)) -- bronze
    or CreateColor(150 / 255, 50 / 255, 50 / 255)
-- the accent lifted towards white, for light that is added or multiplied onto dark art (logo glow, separators)
do
    local r, g, b = GW.Colors.Accent:GetRGB()
    GW.Colors.AccentLight = CreateColor(r + (1 - r) * 0.4, g + (1 - g) * 0.4, b + (1 - b) * 0.4)
end

-- the stagger text of a brewmaster: light, moderate, heavy
GW.Colors.StaggerTextColors = {
    CreateColor(0.4, 0.9, 0.4),
    CreateColor(0.95, 0.85, 0.3),
    CreateColor(0.9, 0.4, 0.4),
}

GW.Colors.DebuffColors = {
    [GW.Enum.DispelType.None] = CreateColor(220 / 255, 0, 0),
    [GW.Enum.DispelType.Curse] = CreateColor(97 / 255, 72 / 255, 177 / 255),
    [GW.Enum.DispelType.Disease] = CreateColor(177 / 255, 114 / 255, 72 / 255),
    [GW.Enum.DispelType.Magic] = CreateColor(72 / 255, 94 / 255, 177 / 255),
    [GW.Enum.DispelType.Poison] = CreateColor(94 / 255, 177 / 255, 72 / 255),
    [GW.Enum.DispelType.Bleed] = CreateColor(1, 0.2, 0.6),
    [GW.Enum.DispelType.Enrage] = CreateColor(243 / 255, 95 / 255, 245 / 255),
}
GW.Colors.DebuffColors.None = GW.Colors.DebuffColors[GW.Enum.DispelType.None]
GW.Colors.DebuffColors.Curse = GW.Colors.DebuffColors[GW.Enum.DispelType.Curse]
GW.Colors.DebuffColors.Disease = GW.Colors.DebuffColors[GW.Enum.DispelType.Disease]
GW.Colors.DebuffColors.Magic = GW.Colors.DebuffColors[GW.Enum.DispelType.Magic]
GW.Colors.DebuffColors.Poison = GW.Colors.DebuffColors[GW.Enum.DispelType.Poison]
GW.Colors.DebuffColors.Bleed = GW.Colors.DebuffColors[GW.Enum.DispelType.Bleed]
GW.Colors.DebuffColors.Enrage = GW.Colors.DebuffColors[GW.Enum.DispelType.Enrage]
GW.Colors.DebuffColors.BadDispel = CreateColor(0.05, 0.85, 0.94)
GW.Colors.DebuffColors.Stealable = CreateColor(0.93, 0.91, 0.55)

GW.Colors.Fallback = CreateColor(0, 0, 0, 1)
GW.Colors.FallbackWhite = CreateColor(1, 1, 1, 1)
GW.Colors.Transparent = CreateColor(0, 0, 0, 0)

-- the colors our skins share, so every window looks the same
GW.Colors.SkinColors = {
    HeaderBorder = CreateColor(1, 1, 1, 0.2), -- the thin light frame of list and section headers
    SeparatorHighlight = CreateColor(1, 0.93, 0.73, 0.25), -- hover over a header separator
    ListHover = CreateColor(0.8, 0.8, 0.8, 0.8), -- menu-hover.png on list rows
    ListSelected = CreateColor(0.8, 0.8, 0.8, 1), -- menu-hover.png on the selected list row
    CardHover = CreateColor(0.8, 0.8, 0.8, 0.35), -- menu-hover.png over art and cards
    HighlightWhite = CreateColor(1, 1, 1, 0.25), -- flat white highlight over icons and buttons
    StatusBarTrack = CreateColor(1, 1, 1, 0.12), -- the empty track of a progress bar on dark art
    IconBorder = CreateColor(0.45, 0.45, 0.45, 1), -- the frame of an icon without quality
    CreamBorder = CreateColor(1, 0.99, 0.85), -- the light frame of cards and tiles
    QuestGold = CreateColor(1, 0.8, 0.1), -- quest titles, enough money, finished objectives
    ObjectiveOpen = CreateColor(0.63, 0.09, 0.09), -- an objective still to do
    Disabled = CreateColor(0.6, 0.6, 0.6), -- greyed out text, money that is missing
    StrikeLine = CreateColor(0.78, 0.78, 0.78, 0.7), -- the line through a finished objective
    Placeholder = CreateColor(0.7, 0.7, 0.7), -- the hint in an empty text field
    SubText = CreateColor(0.75, 0.75, 0.75), -- the small second line under a name
    Positive = CreateColor(0.3, 1, 0.3),
    Negative = CreateColor(1, 0.3, 0.3),
    TokenBorder = CreateColor(0, 0.8, 1), -- the WoW token icon frame
    Applied = CreateColor(1, 0.7, 1), -- an applied transmog appearance
    DisabledBorder = CreateColor(0.3, 0.3, 0.3), -- the frame of something that cannot be used
    CardBorder = CreateColor(0.6, 0.6, 0.6), -- the light grey frame of cards and model previews
    Chip = CreateColor(0, 0, 0, 0.35), -- a small name plate on a card
    NotificationBadge = CreateColor(1, 0, 0, 1), -- the round count of micro buttons and chat tabs
    TooltipBorder = CreateColor(0.05, 0.05, 0.05, 1), -- the dark frame of our tooltips
    MapBadge = CreateColor(0, 0, 0, 0.6), -- the dark disc behind a badge on the world map
    RowShade = CreateColor(0, 0, 0, 0.6), -- the dark start of a row background that fades out to the right
    ListHeader = CreateColor(0, 0, 0, 0.5), -- the even band behind a header of a list, the art behind must not show through
    AfkShade = CreateColor(0, 0, 0, 0.6), -- the dark band behind the chat and the logout bar of the afk screen
}

-- the coin amounts of our bag money
GW.Colors.MoneyColors = {
    Gold = CreateColor(221 / 255, 187 / 255, 68 / 255),
    Silver = CreateColor(170 / 255, 170 / 255, 170 / 255),
    Copper = CreateColor(177 / 255, 97 / 255, 34 / 255),
}

-- the palette of the group frame aura indicators (Core/consts.lua), distinct tones so that
-- several indicators of one class stay apart
GW.Colors.IndicatorColors = {
    Green = CreateColor(0.2, 0.8, 0.2),
    Lime = CreateColor(0.78, 1, 0.25),
    Mint = CreateColor(0.15, 1, 0.55),
    Teal = CreateColor(0.3, 0.75, 0.75),
    Cyan = CreateColor(0.2, 0.9, 0.95),
    Blue = CreateColor(0.15, 0.3, 1),
    Navy = CreateColor(0.05, 0.12, 0.45),
    Purple = CreateColor(0.45, 0.25, 0.8),
    Pink = CreateColor(0.85, 0.35, 0.85),
    Red = CreateColor(0.9, 0.12, 0.08),
    Orange = CreateColor(0.95, 0.5, 0.05),
    Yellow = CreateColor(1, 0.95, 0.6),
    Grey = CreateColor(0.65, 0.65, 0.65),
}

-- breath, fatigue and feign death bars, the tones Blizzard's classic timers use
GW.Colors.MirrorTimerColors = {
    EXHAUSTION = CreateColor(1, 0.9, 0),
    BREATH = CreateColor(0, 0.5, 1),
    DEATH = CreateColor(1, 0.7, 0),
    FEIGNDEATH = CreateColor(1, 0.7, 0),
}
GW.Colors.MirrorTimerBackground = CreateColor(0.2, 0.2, 0.2, 0.5)

GW.Colors.PowerBarCustomColors = {
    MANA = CreateColor(37 / 255, 133 / 255, 240 / 255),
    RAGE = CreateColor(240 / 255, 66 / 255, 37 / 255),
    ENERGY = CreateColor(240 / 255, 200 / 255, 37 / 255),
    LUNAR_POWER = CreateColor(130 / 255, 172 / 255, 230 / 255),
    RUNIC_POWER = CreateColor(37 / 255, 214 / 255, 240 / 255),
    FOCUS = CreateColor(240 / 255, 121 / 255, 37 / 255),
    FURY = CreateColor(166 / 255, 37 / 255, 240 / 255),
    PAIN = CreateColor(255 / 255, 156 / 255, 0),
    MAELSTROM = CreateColor(0.00, 0.50, 1.00),
    INSANITY = CreateColor(0.40, 0, 0.80),
    CHI = CreateColor(0.71, 1.0, 0.92),

    -- vehicle colors
    AMMOSLOT = CreateColor(0.80, 0.60, 0.00),
    FUEL = CreateColor(0.0, 0.55, 0.5),
    STAGGER = CreateColor(0.52, 1.0, 0.52),
}

-- keyed by the bag family bit field (second return of GetContainerNumFreeSlots)
GW.Colors.ProfessionBagColors = {
    [1] = CreateColor(1, 1, 1),         --quiver
    [2] = CreateColor(1, 1, 1),         --ammo pouch
    [4] = CreateColor(.251, .878, .816),--soul bag
    [8] = CreateColor(.88, .73, .29),   --leatherworking
    [16] = CreateColor(.29, .30, .88),  --inscription
    [32] = CreateColor(.07, .71, .13),  --herbs
    [64] = CreateColor(.76, .02, .8),   --enchanting
    [128] = CreateColor(.91, .46, .18), --engineering
    [512] = CreateColor(.03, .71, .81), --gems
    [1024] = CreateColor(.54, .40, .04), --mining
    [32768] = CreateColor(.42, .59, 1), --fishing
    [65536] = CreateColor(.87, .05, .25) --cooking
}

GW.Colors.ObjectivesTypeColors = {
    [GW.Enum.ObjectivesNotificationType.Quest] = CreateColor(221 / 255, 198 / 255, 68 / 255),
    [GW.Enum.ObjectivesNotificationType.Campaign] = CreateColor(121 / 255, 222 / 255, 47 / 255),
    [GW.Enum.ObjectivesNotificationType.Event] = CreateColor(240 / 255, 121 / 255, 37 / 255),
    [GW.Enum.ObjectivesNotificationType.Scenario] = CreateColor(171 / 255, 37 / 255, 240 / 255),
    [GW.Enum.ObjectivesNotificationType.Boss] = CreateColor(240 / 255, 37 / 255, 37 / 255),
    [GW.Enum.ObjectivesNotificationType.Achievement] = CreateColor(37 / 255, 240 / 255, 172 / 255),
    [GW.Enum.ObjectivesNotificationType.Arena] = CreateColor(240 / 255, 37 / 255, 37 / 255),
    [GW.Enum.ObjectivesNotificationType.DailyQuest] = CreateColor(68 / 255, 192 / 255, 250 / 255),
    [GW.Enum.ObjectivesNotificationType.Torghast] = CreateColor(109 / 255, 161 / 255, 207 / 255),
    [GW.Enum.ObjectivesNotificationType.HousingInitiative] = CreateColor(0.85, 0.7, 0.43),
    [GW.Enum.ObjectivesNotificationType.Delve] = CreateColor(171 / 255, 37 / 255, 240 / 255),
    [GW.Enum.ObjectivesNotificationType.Recipe] = CreateColor(228 / 255, 157 / 255, 0 / 255),
    [GW.Enum.ObjectivesNotificationType.MonthlyActivity] = CreateColor(228 / 255, 157 / 255, 0 / 255),
    [GW.Enum.ObjectivesNotificationType.Dead] = CreateColor(255 / 255, 255 / 255, 255 / 255),
    [GW.Enum.ObjectivesNotificationType.LegendaryQuest] = CreateColor(255 / 255, 128 / 255, 0 / 255),
    [GW.Enum.ObjectivesNotificationType.ImportantQuest] = CreateColor(186 / 255, 96 / 255, 240 / 255),
    [GW.Enum.ObjectivesNotificationType.PvPQuest] = CreateColor(230 / 255, 90 / 255, 75 / 255),
}

-- experience bar colors, the tooltip marks its lines with them
GW.Colors.StatusBarColors = {
    Xp = CreateColor(0.83, 0.57, 0),
    Rested = CreateColor(0.5, 0, 0.5), -- set in experiencebar.xml, here for the tooltip
    PetXpBattle = CreateColor(0.58, 0, 0.55),
    PetXp = CreateColor(240 / 255, 240 / 255, 155 / 255),
    Honor = CreateColor(1, 0.2, 0.2),
    House = CreateColor(0.85, 0.7, 0.43),
}

GW.Colors.FactionBarColors = {
    [1] = CreateColor(0.8, 0.3, 0.22),
    [2] = CreateColor(0.8, 0.3, 0.22),
    [3] = CreateColor(0.75, 0.27, 0),
    [4] = CreateColor(0.9, 0.7, 0),
    [5] = CreateColor(0, 0.6, 0.1),
    [6] = CreateColor(0, 0.6, 0.1),
    [7] = CreateColor(0, 0.6, 0.1),
    [8] = CreateColor(0, 0.6, 0.1),
    [9] = CreateColor(0.22, 0.37, 0.98), --Paragon
    [10] = CreateColor(0.09, 0.29, 0.79), --Azerite
    [11] = CreateColor(0, 0.74, 0.95),  --(Renown)
}

local function CreateReactionColor(colorSettings, fallback)
    if type(colorSettings) ~= "table" then
        colorSettings = fallback
    end

    return CreateColor(colorSettings.r or fallback.r, colorSettings.g or fallback.g, colorSettings.b or fallback.b)
end

GW.Colors.UnitFrameReactionColors = { -- will be set with the first update on Addon load
    -- friendly #58aa44
    -- hostile #9f2414
    -- tappedDenied #9f9f9f
}

function GW.UpdateUnitFrameReactionColors()
    GW.Colors.UnitFrameReactionColors.Friendly = CreateReactionColor(GW.settings.unitframes.reactionColors.Friendly, GW.globalDefault.profile.unitframes.reactionColors.Friendly)
    GW.Colors.UnitFrameReactionColors.Hostile = CreateReactionColor(GW.settings.unitframes.reactionColors.Hostile, GW.globalDefault.profile.unitframes.reactionColors.Hostile)
    GW.Colors.UnitFrameReactionColors.TappedDenied = CreateReactionColor(GW.settings.unitframes.reactionColors.TappedDenied, GW.globalDefault.profile.unitframes.reactionColors.TappedDenied)
end

GW.Colors.UnitFrameDisconnected = CreateColor(0.3, 0.3, 0.3)

GW.Colors.ClassColors = {
    WARRIOR = CreateColor(90 / 255, 54 / 255, 38 / 255, 1),
    PALADIN = CreateColor(177 / 255, 72 / 255, 117 / 255, 1),
    HUNTER = CreateColor(99 / 255, 125 / 255, 53 / 255, 1),
    ROGUE = CreateColor(190 / 255, 183 / 255, 79 / 255, 1),
    PRIEST = CreateColor(205 / 255, 205 / 255, 205 / 255, 1),
    DEATHKNIGHT = CreateColor(148 / 255, 62 / 255, 62 / 255, 1),
    SHAMAN = CreateColor(30 / 255, 44 / 255, 149 / 255, 1),
    --MAGE = CreateColor(62 / 255, 121 / 255, 149 / 255, 1},
    MAGE = CreateColor(101 / 255, 157 / 255, 184 / 255, 1),
    WARLOCK = CreateColor(125 / 255, 88 / 255, 154 / 255, 1),
    MONK = CreateColor(66 / 255, 151 / 255, 112 / 255, 1),
    DRUID = CreateColor(158 / 255, 103 / 255, 37 / 255, 1),
    DEMONHUNTER = CreateColor(72 / 255, 38 / 255, 148 / 255, 1),
    EVOKER = CreateColor(56 / 255, 99 / 255, 113 / 255, 1)
}

GW.Colors.PetHappinessColors = {
    CreateColor(0.69, 0.13, 0.36),
    CreateColor(0.72, 0.6, 0.12),
    CreateColor(0.3, 0.64, 0.18),
}

GW.Colors.PlayerStatusColors = {
    Available = CreateColor(0.3, 1, 0.3),
    Away = CreateColor(1, 0.6, 0),
    Busy = CreateColor(1, 0.2, 0.2),
}

GW.Colors.InstanceDifficultyColors = {
    lfr = CreateColor(0.32, 0.91, 0.25),
    normal = CreateColor(0.09, 0.51, 0.82),
    heroic = CreateColor(0.67, 0.15, 0.94),
    challenge = CreateColor(0.9, 0.89, 0.27),
    mythic = CreateColor(0.82, 0.42, 0.16),
    time = CreateColor(0.41, 0.80, 0.94),
}

GW.Colors.FactionColors = {
    Horde = CreateColor(163 / 255, 46 / 255, 54 / 255), --Horde
    Alliance = CreateColor(57 / 255, 115 / 255, 186 / 255) --Alliance
}

GW.Colors.GemTypeInfoColors = {
	Yellow			= CreateColor(0.97, 0.82, 0.29),
	Red				= CreateColor(1.00, 0.47, 0.47),
	Blue			= CreateColor(0.47, 0.67, 1.00),
	Hydraulic		= CreateColor(1.00, 1.00, 1.00),
	Cogwheel		= CreateColor(1.00, 1.00, 1.00),
	Meta			= CreateColor(1.00, 1.00, 1.00),
	Prismatic		= CreateColor(1.00, 1.00, 1.00),
	PunchcardRed	= CreateColor(1.00, 0.47, 0.47),
	PunchcardYellow	= CreateColor(0.97, 0.82, 0.29),
	PunchcardBlue	= CreateColor(0.47, 0.67, 1.00),
}

GW.Colors.TotemColors = {
    Earth = CreateColor(0.23, 0.45, 0.13),
    Fire = CreateColor(0.58, 0.23, 0.10),
    Water = CreateColor(0.19, 0.48, 0.60),
    Air = CreateColor(0.42, 0.18, 0.74),
}
