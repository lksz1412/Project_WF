---@class GW2
local GW = select(2, ...)
local L = GW.L

local function LoadChatPanel(sWindow)
    local p = CreateFrame("Frame", nil, sWindow, "GwSettingsPanelTmpl")

    local general = CreateFrame("Frame", nil, p, "GwSettingsPanelTmpl")
    general.panelId = "chat_general"
    general.header:SetFont(DAMAGE_TEXT_FONT, 20)
    general.header:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    general.header:SetText(CHAT)
    general.sub:SetFont(UNIT_NAME_FONT, 12)
    general.sub:SetTextColor(181 / 255, 160 / 255, 128 / 255)
    general.sub:SetText(L["Edit chat settings."])
    general.header:SetWidth(general.header:GetStringWidth())
    general.breadcrumb:SetFont(DAMAGE_TEXT_FONT, 12)
    general.breadcrumb:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    general.breadcrumb:SetText(GENERAL)

    local chatBubbles = CreateFrame("Frame", nil, p, "GwSettingsPanelTmpl")
    chatBubbles.panelId = "chat_bubbles"
    chatBubbles.header:SetFont(DAMAGE_TEXT_FONT, 20)
    chatBubbles.header:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    chatBubbles.header:SetText(CHAT)
    chatBubbles.sub:SetFont(UNIT_NAME_FONT, 12)
    chatBubbles.sub:SetTextColor(181 / 255, 160 / 255, 128 / 255)
    chatBubbles.sub:SetText(L["Edit chat bubble settings."])
    chatBubbles.header:SetWidth(chatBubbles.header:GetStringWidth())
    chatBubbles.breadcrumb:SetFont(DAMAGE_TEXT_FONT, 12)
    chatBubbles.breadcrumb:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    chatBubbles.breadcrumb:SetText(CHAT_BUBBLES_TEXT)

    local nameInChat = CreateFrame("Frame", nil, p, "GwSettingsPanelTmpl")
    nameInChat.panelId = "chat_name"
    nameInChat.header:SetFont(DAMAGE_TEXT_FONT, 20)
    nameInChat.header:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    nameInChat.header:SetText(CHAT)
    nameInChat.sub:SetFont(UNIT_NAME_FONT, 12)
    nameInChat.sub:SetTextColor(181 / 255, 160 / 255, 128 / 255)
    nameInChat.sub:SetText(L["Put a name in front of your own messages."])
    nameInChat.header:SetWidth(nameInChat.header:GetStringWidth())
    nameInChat.breadcrumb:SetFont(DAMAGE_TEXT_FONT, 12)
    nameInChat.breadcrumb:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    nameInChat.breadcrumb:SetText(L["Name in Chat"])

    general:AddOption(ENABLE, L["Enable the improved chat window."], {getterSetter = "chat.enabled", callback = function() GW.ShowRlPopup = true end, incompatibleAddons = "Chat", isMasterToggle = true})
    general:AddOption(L["GW2 Chat Message Style"], L["Changes the chat font, timestamp color and name display"], { getterSetter = "chat.gw2Style", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Fade Chat"], L["Allow the chat to fade when not in use."], { getterSetter = "chat.fade", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Hide Editbox"], L["Hide the chat editbox when not in focus."], { getterSetter = "chat.hideEditBox", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["URL Links"], L["Attempt to create URL links inside the chat."], { getterSetter = "chat.findUrl", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Hyperlink Hover"], L["Display the hyperlink tooltip while hovering over a hyperlink."], { getterSetter = "chat.hyperlinkTooltip", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Item Link Info"], L["Show the icon and the item level of items linked in chat."], { getterSetter = "chat.itemLinkInfo", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Unread Counter"], L["Show the number of new whisper, guild and group messages on chat tabs that are not shown."], { getterSetter = "chat.unreadCount", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Short Channels"], L["Shorten the channel names in chat."], { getterSetter = "chat.shortChannelNames", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Role Icon"], L["Display LFG Icons in group chat."], { getterSetter = "chat.lfgIcons", callback = function() GW.UpdateChatSettings() GW.CollectLfgRolesForChatIcons() end, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Class Color Mentions"], L["Use class color for the names of players when they are mentioned."], { getterSetter = "chat.classColorMentions", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Emotion Icons"], L["Display emotion icons in chat"], {getterSetter = "chat.keywords.emoji", callback = function(value) GW.UpdateChatSettings() if GW_EmoteFrame then GW_EmoteFrame:Hide() end for _, frameName in ipairs(CHAT_FRAMES) do if _G[frameName].buttonEmote then _G[frameName].buttonEmote:SetShown(value) end end end, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Quick Join Messages"], L["Show clickable Quick Join messages inside of the chat."], { getterSetter = "chat.socialLink", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}, hidden = not GW.isModern})
    general:AddOption(L["Add timestamp to all messages"], nil, { getterSetter = "chat.timestampAll", callback = GW.UpdateChatSettings, dependence = {["chat.enabled"] = true}})
    general:AddOption(L["Copy Chat Lines"], L["Adds an arrow infront of the chat lines to copy the entire line"], { getterSetter = "chat.copyChatLines", dependence = {["chat.enabled"] = true}})
    general:AddOption(L["History"], L["Log the main chat frames history. So when you reloadui or log in and out you see the history from your last session"], { getterSetter = "chat.history.enabled", dependence = {["chat.enabled"] = true}})
    general:AddOptionSlider(L["History Size"], nil, { getterSetter = "chat.history.size", min = 10, max = 500, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true, ["chat.history.enabled"] = true}})
    general:AddOptionButton(L["Reset History"], nil, {callback = function() GW.private.ChatHistoryLog = {} end, isNegativeButton = true, forceNewLine = true})
    general:AddOptionButton(L["Save Chat Layout to Profile"], L["Saves the chat tabs with their name, messages, channels, colors and position into the profile."], {callback = GW.SaveChatLayout, forceNewLine = true})
    general:AddOptionButton(L["Apply Chat Layout from Profile"], L["Replaces the chat tabs of this character with the layout saved in the profile."], {callback = function()
        GW.ShowPopup({text = L["Replace the chat tabs of this character with the layout saved in the profile?"], OnAccept = GW.ApplyChatLayout, button1 = ACCEPT, button2 = CANCEL})
    end})

    general:AddOptionDropdown(L["Chat Buttons Position"], L["Position of the chat control buttons (menu, channel, voice, social). Top and Right move them into a small hover bar, so the chat window can sit flush at the screen edge."], { getterSetter = "chat.buttonsPosition", callback = function() GW.UpdateChatButtonsPosition() end, optionsList = {"LEFT", "TOP", "RIGHT"}, optionNames = {L["Left"], L["Top"], L["Right"]}, dependence = {["chat.enabled"] = true}})
    general:AddOptionDropdown(TIMESTAMPS_LABEL, OPTION_TOOLTIP_TIMESTAMPS, { getterSetter = "chat.timeStampFormat", optionsList = {"NONE", "%I:%M ", "%I:%M:%S ", "%I:%M %p ", "%I:%M:%S %p ", "%H:%M ", "%H:%M:%S "}, optionNames = {NONE, "03:27", "03:27:32", "03:27 PM", "03:27:32 PM", "15:27", "15:27:32"}, dependence = {["chat.enabled"] = true}})
    general:AddOptionDropdown(L["Announce Interrupts"], L["Announce when you interrupt a spell to the specified chat channel"], { getterSetter = "chat.interruptAnnounce", callback = GW.ToggleInterruptAnncouncement, optionsList = {"NONE", "SAY", "YELL", "PARTY", "RAID", "RAID_ONLY", "EMOTE"}, optionNames = {NONE, SAY, YELL, L["Party Only"], L["Party / Raid"], L["Raid Only"], EMOTE}, hidden = GW.isModern})

    local soundKeys = {}
    for _, sound in next, GW.Libs.LSM:List("sound") do
        tinsert(soundKeys, sound)
    end
    general:AddOptionDropdown(L["Keyword Alert"], nil, { getterSetter = "chat.keywords.alertNew", callback = GW.UpdateChatSettings, optionsList = soundKeys, optionNames = soundKeys, dependence = {["chat.enabled"] = true}, hasSound = true})
    local whisperNames = {}
    for index, sound in ipairs(soundKeys) do
        whisperNames[index] = sound == "None" and "Blizzard" or sound
    end
    general:AddOptionDropdown(L["Whisper Alert"], L["Plays a sound when you receive a whisper."], { getterSetter = "chat.whisperSound", optionsList = soundKeys, optionNames = whisperNames, dependence = {["chat.enabled"] = true}, hasSound = true})

    general:AddOptionSlider(L["Spam Interval"], L["Prevent the same messages from displaying in chat more than once within this set amount of seconds, set to zero to disable."], { getterSetter = "chat.spamInterval", callback = function() GW.UpdateChatSettings(); GW.DisableChatThrottle() end, min = 0, max = 100, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true}})
    general:AddOptionSlider(L["Combat Repeat"], L["Number of repeat characters while in combat before the chat editbox is automatically closed, set to zero to disable."], { getterSetter = "chat.inCombatTextRepeat", callback = function() GW.UpdateChatSettings() end, min = 0, max = 15, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true}})
    general:AddOptionSlider(L["Scroll Messages"], L["Number of messages you scroll for each step."], { getterSetter = "chat.scrollMessages", callback = function() GW.UpdateChatSettings() end, min = 1, max = 12, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true}})
    general:AddOptionSlider(L["Scroll Interval"], L["Number of time in seconds to scroll down to the bottom of the chat window if you are not scrolled down completely."], { getterSetter = "chat.scrollDownInterval", callback = function() GW.UpdateChatSettings() end, min = 0, max = 120, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true}})
    general:AddOptionSlider(L["Maximum lines of 'Copy Chat Frame'"], L["Set the maximum number of lines displayed in the Copy Chat Frame"], { getterSetter = "chat.maxCopyLines", min = 50, max = 500, decimalNumbers = 0, step = 1, dependence = {["chat.enabled"] = true}})
    general:AddOptionText(L["Keywords"], L["List of words to color in chat if found in a message. If you wish to add multiple words you must seperate the word with a comma. To search for your current name you can use %MYNAME%.\n\nExample:\n%MYNAME%, Heal, Tank"], { getterSetter = "chat.keywords.list", callback = function() GW.UpdateChatSettings() GW.UpdateChatKeywords() end, dependence = {["chat.enabled"] = true}})
    general:AddOptionColorPicker(L["Keyword highlight color"], nil, { getterSetter = "CHAT_KEYWORDS_ALERT_COLOR", dependence = {["chat.enabled"] = true}, isPrivateSetting = true})

    chatBubbles:AddOption(ENABLE, L["Replace the default UI chat bubbles. (Only in not protected areas)"], {getterSetter = "chat.bubbles.enabled", callback = function() GW.ShowRlPopup = true end, isMasterToggle = true})
    chatBubbles:AddOptionSlider(L["Chatbubble Scale"], nil, { getterSetter = "chat.bubbles.scale", isPercent = true, min = 0.5, max = 2, decimalNumbers = 2, step = 0.01, dependence = {["chat.bubbles.enabled"] = true}})
    chatBubbles:AddOption(L["Color by Chat Type"], L["Colors the border and the name of a bubble in the color of its chat type, as set for the chat window."], {getterSetter = "chat.bubbles.chatTypeColors", dependence = {["chat.bubbles.enabled"] = true}})

    nameInChat:AddOption(ENABLE, L["Put the name in front of your messages in the selected chats."], {getterSetter = "chat.nameInChat.enabled", isMasterToggle = true})
    nameInChat:AddOptionText(NAME, L["Shown in parentheses in front of your message, e.g, '(Tom): Hello'."], {getterSetter = "chat.nameInChat.name", dependence = {["chat.nameInChat.enabled"] = true}})
    nameInChat:AddOptionDropdown(CHANNELS, nil, {getterSetter = "chat.nameInChat.channels", optionsList = {"GUILD", "PARTY", "RAID", "INSTANCE"}, optionNames = {GUILD, PARTY, RAID, INSTANCE_CHAT}, checkbox = true, dependence = {["chat.nameInChat.enabled"] = true}})
    nameInChat:AddOptionText(CHANNEL, L["Name of a chat channel that gets the name as well."], {getterSetter = "chat.nameInChat.channel", dependence = {["chat.nameInChat.enabled"] = true}})
    nameInChat:AddOption(L["Hide Name if it Matches Your Character's Name"], L["If the name above matches your character's name, it is not added."], {getterSetter = "chat.nameInChat.hideOwnName", dependence = {["chat.nameInChat.enabled"] = true}})
    nameInChat:AddOption(L["Ignore Messages Starting with '!'"], L["Messages that begin with an exclamation mark (!) get no name. Useful for addon commands like !keys."], {getterSetter = "chat.nameInChat.ignoreCommands", dependence = {["chat.nameInChat.enabled"] = true}})

    sWindow:AddSettingsPanel(p, CHAT, L["Edit chat settings."], {{name = GENERAL, frame = general}, {name = CHAT_BUBBLES_TEXT, frame = chatBubbles}, {name = L["Name in Chat"], frame = nameInChat}})
end
GW.LoadChatPanel = LoadChatPanel
