---@class GW2
local GW = select(2, ...)
local L = GW.L

-- the entries mirror the container list in ObjectivesTracker.lua: every container that loads on
-- this client can be ordered, and an entry without a label on this client is skipped
local function GetObjectiveTrackerModuleOrderOptions()
    local types = GW.Enum.ObjectivesNotificationType
    local modules = {
        {key = "Achievement", label = ACHIEVEMENTS, color = types.Achievement, load = not (GW.Classic or GW.TBC)},
        {key = "NearlyDone", label = L["Nearly Done"], color = types.Achievement, load = not (GW.Classic or GW.TBC)},
        {key = "Campaign", label = GW.QuestTrackerTopContainerTitle or GW.myLocalizedClass, color = types.Campaign, load = true},
        {key = "Dungeon", label = L["Dungeon Quests"], color = types.Quest, load = GW.isModern},
        {key = "Zone", label = L["Zone Quests"], color = types.Quest, load = GW.isModern},
        {key = "Quests", label = TRACKER_HEADER_QUESTS or QUESTS_LABEL, color = types.Quest, load = true},
        {key = "Bonus", label = EVENTS_LABEL, color = types.Event, load = GW.isModern},
        {key = "Recipe", label = PROFESSIONS_TRACKER_HEADER_PROFESSION, color = types.Recipe, load = GW.isModern},
        {key = "MonthlyActivity", label = TRACKER_HEADER_MONTHLY_ACTIVITIES, color = types.MonthlyActivity, load = GW.isModern},
        {key = "Collection", label = ADVENTURE_TRACKING_MODULE_HEADER_TEXT, color = types.Recipe, load = GW.isModern},
        {key = "HousingInitiative", label = HOUSING_DASHBOARD_ENDEAVOR, color = types.HousingInitiative, load = GW.Retail},
        {key = "WQT", label = "|cffaaaaaa[AddOn]|r World Quest Tracker", color = types.Event, load = GW.Retail},
        {key = "PetTracker", label = "|cffaaaaaa[AddOn]|r Pet Tracker", color = types.Event, load = GW.Retail},
        {key = "Todoloo", label = "|cffaaaaaa[AddOn]|r Todoloo's", color = types.Event, load = GW.Retail},
    }

    local optionsList = {}
    local optionNames = {}
    for _, module in ipairs(modules) do
        if module.load and module.label then
            optionsList[#optionsList + 1] = module.key
            optionNames[#optionNames + 1] = GW.Colors.ObjectivesTypeColors[module.color]:WrapTextInColorCode(module.label)
        end
    end

    return optionsList, optionNames
end

local function UpdateObjectiveTrackerStatusBarSettings()
    for _, container in ipairs({
        GwQuesttrackerContainerQuests,
        GwQuesttrackerContainerCampaign,
        GwQuesttrackerContainerZone,
        GwQuesttrackerContainerDungeon,
        GwQuesttrackerContainerAchievement,
        GwQuesttrackerContainerNearlyDone,
        GwQuesttrackerContainerBonus,
        GwQuesttrackerContainerCollection,
        GwQuesttrackerContainerMonthlyActivity,
        GwQuesttrackerContainerRecipe,
        GwQuesttrackerContainerScenario,
        GwQuesttrackerContainerHousingInitiative
    }) do
        if container and container.UpdateLayout then
            container:UpdateLayout()
        end
    end

    if GwQuestTracker then
        GwQuestTracker:LayoutChanged()
    end
end

local function LoadObjectivesPanel(sWindow)
    local p = CreateFrame("Frame", nil, sWindow, "GwSettingsPanelTmpl")
    p.panelId = "objectives_general"
    p.header:SetFont(DAMAGE_TEXT_FONT, 20)
    p.header:SetTextColor(GW.Colors.TextColors.LightHeader:GetRGB())
    p.header:SetText(L["Tracker"])
    p.sub:SetFont(UNIT_NAME_FONT, 12)
    p.sub:SetTextColor(181 / 255, 160 / 255, 128 / 255)
    p.sub:SetText(L["Edit objectives settings."])

    p:AddOption(ENABLE, L["Enable the revamped and improved quest tracker."], {getterSetter = "objectives.enabled", callback = function() GW.ShowRlPopup = true end, incompatibleAddons = "Objectives", isMasterToggle = true})
    p:AddOptionDropdown(L["Collapse Objectives Automatically"], L["Choose when the Objective Tracker should collapse all sections automatically."], {
        getterSetter = "objectives.autoCollapse",
        callback = GW.ToggleObjectivesAutoCollapse,
        optionsList = (function()
            local list = {"Raid", "Party", "Combat"}
            if GW.Retail or GW.Mists then
                tinsert(list, 1, "MythicPlus")
            end
            if GW.Retail then
                tinsert(list, 4, "Delve")
            end
            return list
        end)(),
        optionNames = (function()
            local list = {RAID, PARTY, COMBAT}
            if GW.Retail then
                tinsert(list, 1, L["Mythic+"])
            elseif GW.Mists then
                tinsert(list, 1, L["Challenge Mode"])
            end
            if GW.Retail then
                tinsert(list, 4, L["Delve"])
            end
            return list
        end)(),
        checkbox = true,
        dependence = {["objectives.enabled"] = true}
    })
    p:AddOption(L["Supertracked Quest to Top"], L["Move the currently supertracked quest to the top of the quest tracker list."], {getterSetter = "objectives.superTrackedOnTop", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}, hidden = not GW.Retail})
    p:AddOption(L["Show zone quests separately"], L["Show the quests of your current zone in a separate module. Its position is set in the module order list."], {getterSetter = "objectives.zoneQuests", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOption(L["Show dungeon quests separately"], L["Show the dungeon quests of your quest log in a separate module. Its position is set in the module order list."], {getterSetter = "objectives.dungeonQuests", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOption(L["Show Completed Objectives"], L["Show completed quest objectives instead of hiding them."], {getterSetter = "objectives.showCompleted", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}})
    p:AddOption(L["Compact Mode"], L["Reduce spacing and font sizes across the Objective Tracker."], {getterSetter = "objectives.compactMode", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}})
    p:AddOptionSlider(L["Objective Spacing"], L["Scales the gaps between objective lines and between quest blocks. Lower values pack them tighter."], {getterSetter = "objectives.spacing", callback = GW.RefreshObjectivesTrackerLayout, min = 0.5, max = 1.5, decimalNumbers = 2, step = 0.05, dependence = {["objectives.enabled"] = true}})
    p:AddOption(L["Toggle Compass"], L["Enable or disable the quest tracker compass."], {getterSetter = "objectives.compass", callback = function() if not (GW.Classic or GW.TBC or GW.Wrath) then GwQuesttrackerContainerBossFrames:SetUpFramePosition(); GwQuesttrackerContainerArenaBGFrames:SetUpFramePosition() end; GwObjectivesNotification:OnUpdate() end, dependence = {["objectives.enabled"] = true}})
    p:AddOption(L["Nearly Done"], L["Shows the three achievements you are closest to completing in the quest tracker. Right-click opens a menu to track or hide one."], {getterSetter = "objectives.nearlyDone", callback = function() GW.UpdateNearlyDoneAchievements() end, dependence = {["objectives.enabled"] = true}, hidden = GW.Classic or GW.TBC})
    p:AddOption(L["Show Objective Tracker progress bars"], L["If disabled, progress bars will not be shown for various objective tracker items such as quests, achievements, etc."], {getterSetter = "objectives.statusBars", callback = UpdateObjectiveTrackerStatusBarSettings, dependence = {["objectives.enabled"] = true}})

    p:AddOption(L["Show Quest XP in Quest Tracker"], nil, {getterSetter = "objectives.showXp", callback = GW.RefreshObjectivesTrackerLayout, dependence = {["objectives.enabled"] = true}, hidden = GW.Retail})
    p:AddOptionDropdown(L["Quest Tracker Sorting"], nil, { getterSetter = "objectives.sorting", callback = GW.RefreshObjectivesTrackerLayout, optionsList = {"DEFAULT", "LEVEL", "LEVEL_DESC", "ZONE"}, optionNames = {DEFAULT, L["Level (ascending)"], L["Level (descending)"], ZONE}, dependence = {["objectives.enabled"] = true}, hidden = GW.Retail})

    local moduleOrderOptions, moduleOrderOptionNames = GetObjectiveTrackerModuleOrderOptions()
    p:AddOptionSortableList(L["Objective Tracker Module Order"], L["Set the order of Objective Tracker modules."], {
        getterSetter = "objectives.moduleOrder",
        callback = GW.ApplyObjectivesTrackerModuleOrder,
        optionsList = moduleOrderOptions,
        optionNames = moduleOrderOptionNames,
        maxVisibleRows = 6,
        dependence = {["objectives.enabled"] = true},
        hidden = GW.Classic or GW.TBC
    })

    p:AddGroupHeader(HUD_EDIT_MODE_BOSS_FRAMES_LABEL, {hidden = GW.Classic or GW.TBC})
    p:AddOption(HUD_EDIT_MODE_CAST_BAR_LABEL, L["Shows the casts of the bosses in place of their power bar."], {getterSetter = "objectives.bossFrames.castbar", callback = GW.UpdateBossFramesSettings, dependence = {["objectives.enabled"] = true}, hidden = GW.Classic or GW.TBC})
    p:AddOption(AURAS, L["Shows your own debuffs and the important buffs of the bosses, chosen like on Blizzard's enemy nameplates."], {getterSetter = "objectives.bossFrames.auras", callback = GW.UpdateBossFramesSettings, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOptionButton(L["Preview Boss Frames"], L["Shows test bosses in the quest tracker. Ends with the next fight."], {callback = function()
        if GW.ToggleBossFramesTest() then
            GW.ActivateSettingsPreview("bossFrames", function() GW.ToggleBossFramesTest(false) end)
        else
            GW.DeactivateSettingsPreview("bossFrames")
        end
    end, dependence = {["objectives.enabled"] = true}, forceNewLine = true, hidden = GW.Classic or GW.TBC})
    p:AddOptionTagDesigner(L["Design Texts"], L["Build the name line, the health text and the power text from blocks."], {target = GW.GetUnitFrameTextTarget("boss", function() if GW.UpdateBossFramesSettings then GW.UpdateBossFramesSettings() end end), dependence = {["objectives.enabled"] = true}, hidden = GW.Classic or GW.TBC})

    p:AddGroupHeader(HUD_EDIT_MODE_ARENA_FRAMES_LABEL, {hidden = GW.Classic})
    p:AddOption(HUD_EDIT_MODE_CAST_BAR_LABEL, L["Shows the casts of the opponents in place of their power bar."], {getterSetter = "objectives.arenaFrames.castbar", callback = GW.UpdateArenaFramesSettings, dependence = {["objectives.enabled"] = true}, hidden = GW.Classic})
    p:AddOption(AURAS, L["Shows crowd control on the opponents and their important buffs."], {getterSetter = "objectives.arenaFrames.auras", callback = GW.UpdateArenaFramesSettings, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOptionButton(L["Preview Arena Frames"], L["Shows test opponents in the quest tracker. Ends with the next fight."], {callback = function()
        if GW.ToggleArenaFramesTest() then
            GW.ActivateSettingsPreview("arenaFrames", function() GW.ToggleArenaFramesTest(false) end)
        else
            GW.DeactivateSettingsPreview("arenaFrames")
        end
    end, dependence = {["objectives.enabled"] = true}, forceNewLine = true, hidden = GW.Classic})
    p:AddOptionTagDesigner(L["Design Texts"], L["Build the name line, the health text and the power text from blocks."], {target = GW.GetUnitFrameTextTarget("arena", function() if GW.UpdateArenaFramesSettings then GW.UpdateArenaFramesSettings() end end), dependence = {["objectives.enabled"] = true}, hidden = GW.Classic})

    p:AddGroupHeader(L["Boss Times"])
    p:AddOption(L["Mythic+ split times"], L["Shows when each boss died since the key started, compared to your best time on this key level."], {getterSetter = "objectives.encounterTimes.mythicPlus", callback = GW.RefreshEncounterTimes, dependence = {["objectives.enabled"] = true}, hidden = not (GW.Retail or GW.Mists)})
    p:AddOption(L["Dungeon fight times"], L["Shows how long each boss fight took, compared to your best time on this difficulty."], {getterSetter = "objectives.encounterTimes.dungeon", callback = GW.RefreshEncounterTimes, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOption(L["Raid fight times"], L["Shows how long each boss fight took, compared to your best time on this difficulty."], {getterSetter = "objectives.encounterTimes.raid", callback = GW.RefreshEncounterTimes, dependence = {["objectives.enabled"] = true}, hidden = not GW.isModern})
    p:AddOption(L["Delve times"], L["Shows how long each boss fight and the whole delve took, compared to your best time on this tier."], {getterSetter = "objectives.encounterTimes.delve", callback = GW.RefreshEncounterTimes, dependence = {["objectives.enabled"] = true}, hidden = not GW.Retail})
    p:AddOption(L["Boss times in chat"], L["Posts the time of each defeated boss in the chat."], {getterSetter = "objectives.encounterTimes.chat"})

    p:AddGroupHeader(L["Quest Frame"])
    p:AddOption(L["XP Quest Percent"], L["Shows the xp you got from that quest in % based on your current needed xp for next level."], {getterSetter = "general.questXpPercent"})
    p:AddOption(L["Mark Quest Reward"], L["Marks the most valuable quest reward with a gold coin."], {getterSetter = "general.questRewardMostValueIcon", callback = GW.ResetQuestRewardMostValueIcon})

    sWindow:AddSettingsPanel(p, L["Tracker"], L["Edit objectives settings."])
end
GW.LoadObjectivesPanel = LoadObjectivesPanel
