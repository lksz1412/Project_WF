---@class GW2
local GW = select(2, ...)

local function addChange(addonVersion, changeList)
    tinsert(GW.changelog, {version = addonVersion, changes = changeList})
end

--[[
AddChange(string addonVersion, table changeList)
  {
   GW_CHANGELOGS_TYPES fixType // bugfix, feature
   string description
  }
]]

addChange("12.1.9", {
    {GW.Enum.ChangelogType.feature, [=[Battleground score: a line below each score shows how close a side is to winning, the hover shows the points and an estimate how long it takes]=]},
    {GW.Enum.ChangelogType.bug, [=[Battleground score: Arathi Basin shows all five bases, not only the ones known when you entered]=]},
    {GW.Enum.ChangelogType.feature, [=[Immersive Questing: the window remembers where you moved it, the settings can move it back to the middle]=]},
    {GW.Enum.ChangelogType.bug, [=[Skins: the Spoken Places skin also loads when the addon folder is named Spoken_Places]=]},
    {GW.Enum.ChangelogType.change, [=[Skins: the Spoken Places lore panel is now a part of the world map window, with a side tab to open it again]=]},
    {GW.Enum.ChangelogType.change, [=[Upcoming level rewards: now a tab at the bottom of the spell book instead of an own window; at the max level it stays while a trainer still has something to learn]=]},
    {GW.Enum.ChangelogType.feature, [=[Immersive Questing: with the Spoken addon the pages follow the voice, a button replays it; optionally picking a quest stops the greeting]=]},
    {GW.Enum.ChangelogType.feature, [=[Gamepad (Forever): bags, bank, hero panel and popups work with the d-pad, a footer shows the buttons; in the bags X uses, sells or moves and Y destroys an item, back opens the search]=]},
    {GW.Enum.ChangelogType.bug, [=[Gamepad (Forever): the GW2 UI button in the game menu can be reached with the d-pad]=]},
})

addChange("12.1.8", {
    {GW.Enum.ChangelogType.feature, [=[Objectives tracker: optional own modules for the quests of your current zone and for dungeon quests, their place is set in the module order]=]},
    {GW.Enum.ChangelogType.bug, [=[Upcoming level rewards (Forever): spells you already learned no longer show as trainable when the spell book hides the lower ranks]=]},
    {GW.Enum.ChangelogType.bug, [=[AFK screen: the line with mail and whispers is no longer cut off at the bottom edge with bigger fonts]=]},
    {GW.Enum.ChangelogType.bug, [=[Unit frames (Forever): fixed an error when targeting a unit while DBM or BigWigs is loaded]=]},
    {GW.Enum.ChangelogType.bug, [=[Totem selection bar: shamans without a totem no longer see an empty button on the screen]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: quick join notices for group finder listings no longer cause an error, they name the activity]=]},
})

addChange("12.1.7", {
    {GW.Enum.ChangelogType.change, [=[Upcoming level rewards: Shift-click links a spell in the chat; the window plays its opening sound on TBC too]=]},
    {GW.Enum.ChangelogType.bug, [=[Move HUD: sliders like the tracker height sit on their value and keep a typed value; Shift-click selects the frame that comes up front with all its options]=]},
    {GW.Enum.ChangelogType.bug, [=[Text designer: "Hide At Zero" for power also works on Forever and Retail in every mode with the current value]=]},
    {GW.Enum.ChangelogType.change, [=[Quest log: "Abandon Quest" in red like in the tracker; group finder: the delist button in our look]=]},
    {GW.Enum.ChangelogType.feature, [=[Totem selection bar (shaman): own settings page to turn it off and set button size and spacing; its mover no longer disappears after moving; the class totems settings carry their right name]=]},
    {GW.Enum.ChangelogType.feature, [=[Text designer: the health color (red over yellow to green) also on Retail and Forever]=]},
    {GW.Enum.ChangelogType.change, [=[World map: opens faster and remembers where you moved it]=]},
    {GW.Enum.ChangelogType.change, [=[AFK screen: shows your running queues, level, class, specialization and item level, new whispers and mail; the chat only shows once a message came in, on a dark background with the time; time and logout countdown keep running when you press a key in between]=]},
    {GW.Enum.ChangelogType.feature, [=[Skins: Spoken Places story panel]=]},
    {GW.Enum.ChangelogType.feature, [=[Group frames: the buff and debuff filters of a grid can each be reset to default, the note how the filters work also shows on the party grid page]=]},
    {GW.Enum.ChangelogType.change, [=[Objectives tracker: the section header at the top of the scrolled list no longer lies over the quests, the list scrolls below it]=]},
    {GW.Enum.ChangelogType.bug, [=[Upcoming level rewards: a weapon master or pet trainer no longer replaces the spells of your class trainer]=]},
    {GW.Enum.ChangelogType.bug, [=[Cooldown texts (Forever): no Lua error in battlegrounds and other restricted content]=]},
    {GW.Enum.ChangelogType.bug, [=[Dodge bar (Forever): no Lua error in combat with your own spell, the bar fills like on Retail]=]},
    {GW.Enum.ChangelogType.bug, [=[Text designer: a profile imported from another client no longer causes Lua errors, texts this client does not have are left out]=]},
})

addChange("12.1.6", {
    {GW.Enum.ChangelogType.feature, [=[Upcoming level rewards: bigger window with a level path that shows every rank at its level and the money you need now and for the next 5 levels; open it from the experience bar or the new button in the spell book, on Wrath and Forever a notification after a level up shows the new spells at your trainer]=]},
    {GW.Enum.ChangelogType.change, [=[Group frames: the party, raid 10 and raid 25 grids start at the top left like the raid 40 grid, the party grid has smaller frames by default]=]},
    {GW.Enum.ChangelogType.change, [=[Target of target: sits right next to the target frame and at the same height by default]=]},
    {GW.Enum.ChangelogType.feature, [=[Installer: new look, a welcome with your own character, a step list on the left and a spotlight on what a step changes; modules are tiles that light their frame, the text style step changes your real frames live; a new layout step chooses between the health globe and player and target frames side by side like in World of Warcraft, a new playstyle step puts the group and raid frames of healers at the bottom in the middle]=]},
    {GW.Enum.ChangelogType.change, [=[Forever: bronze accent color instead of white]=]},
    {GW.Enum.ChangelogType.change, [=[Party frames: new buffs no longer play an animation]=]},
    {GW.Enum.ChangelogType.bug, [=[Friends list (Forever): the list headers keep their size on hover, name, level and class sit in one row without gaps]=]},
    {GW.Enum.ChangelogType.bug, [=[Communities: the chat input box is back]=]},
    {GW.Enum.ChangelogType.bug, [=[Battleground score (Forever): Warsong Gulch shows the captured flags instead of 0:0 and which side carries a flag]=]},
    {GW.Enum.ChangelogType.bug, [=[Bank (Forever): opening the bank without a bank tab no longer causes an error, the free first tab is bought again]=]},
    {GW.Enum.ChangelogType.bug, [=[Druid (Forever): the small mana bar also shows in bear form]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest tracker: sorting by level works on Forever and can also sort descending; quest item buttons hide when their quest is scrolled out of view and show their range dot instead of a question mark]=]},
    {GW.Enum.ChangelogType.bug, [=[Totem bar: Totemic Recall stays in the bar, the bar and its mover grow with your totems]=]},
    {GW.Enum.ChangelogType.feature, [=[Text designer: power can show current - percent in one block like health, the current - percent templates use that one block; separator, space, line break and custom text can hide when the text before or after them is empty, power can hide at zero]=]},
    {GW.Enum.ChangelogType.bug, [=[Text designer: fixed Lua errors with the power block and class colors, the previews on the classic clients show health again, the options are no longer cut off; in the settings search the designers show right away and in full, the mouse wheel over a block list scrolls on at its end]=]},
    {GW.Enum.ChangelogType.bug, [=[Hero panel: the Pawn button opens Pawn in front and no longer closes it again]=]},
    {GW.Enum.ChangelogType.bug, [=[Player buffs and debuffs: moved in the move mode they stay there, before they jumped back to their default place]=]},
    {GW.Enum.ChangelogType.bug, [=[Breath, fatigue and feign death bars (Retail, Forever): the GW2 look of the classic clients again]=]},
    {GW.Enum.ChangelogType.bug, [=[Cooldown texts: show the right time right away when a bag or bar shows again, before the time from when it was closed stayed for up to 30 seconds]=]},
    {GW.Enum.ChangelogType.feature, [=[HUD layouts: "Share in chat" in the move mode posts the layout as a link, other players with GW2 UI click it, see a sketch of the frames and take the layout over]=]},
})

addChange("12.1.5", {
    {GW.Enum.ChangelogType.change, [=[Text designer: a template for every text line, with the options from before the designer; the designer itself sits behind the new Advanced switch]=]},
    {GW.Enum.ChangelogType.feature, [=[Installer: new step Text Style, Minimal, Default or Detailed for the health and power texts of target, group and player frames]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest window (Forever): reward icons without a second frame]=]},
    {GW.Enum.ChangelogType.bug, [=[Spellbook: fixed a Lua error when a new spell tab shows up]=]},
    {GW.Enum.ChangelogType.bug, [=[Totem bar: no longer jumps over the other action bars in combat]=]},
    {GW.Enum.ChangelogType.bug, [=[Group frames: a line break in the text designer shows the second row]=]},
})

addChange("12.1.4", {
    {GW.Enum.ChangelogType.bug, [=[Bags (Classic, TBC, Wrath, Mists): Mark Unusable Items works again and marks the bank items right after a reload]=]},
    {GW.Enum.ChangelogType.bug, [=[Target, focus and pet frames: fixed a Lua error on login when their health text was switched off before the text designer]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest window: with the quest skin off the texts are dark on the parchment again]=]},
    {GW.Enum.ChangelogType.bug, [=[Group frames: fixed a Lua error when a setting adds frames while the preview is shown]=]},
    {GW.Enum.ChangelogType.bug, [=[Character window (Forever): the model fits the window at every scale]=]},
    {GW.Enum.ChangelogType.bug, [=[Profiles (Forever): renaming or switching a profile no longer causes an error, the interrupt announcement is no longer offered there]=]},
    {GW.Enum.ChangelogType.bug, [=[Profiles: a copied profile names your character as its creator]=]},
    {GW.Enum.ChangelogType.change, [=[Action bars: the buttons of the possess bar get our look]=]},
    {GW.Enum.ChangelogType.bug, [=[Spellbook: the bar with the lower ranks stays open until it is clicked again]=]},
    {GW.Enum.ChangelogType.bug, [=[Inspect (Forever): season and rank no longer overlap on the PvP tab]=]},
    {GW.Enum.ChangelogType.bug, [=[Edit mode (Forever): blizzards totem bar no longer shows a mover, our totem bar has its own]=]},
    {GW.Enum.ChangelogType.bug, [=[Edit mode: after switching the advanced options, showing the party or raid frames no longer causes a Lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat (Forever): the group role icons show in front of the names again]=]},
    {GW.Enum.ChangelogType.bug, [=[Social window: the selected tab is highlighted like in the hero panel]=]},
    {GW.Enum.ChangelogType.bug, [=[Collections (Forever): pets get a light grey frame, new toys show their icon, the mount, pet and toy counters sit on the left and are skinned, the rotate buttons of the pet card too]=]},
    {GW.Enum.ChangelogType.bug, [=[Skins (Forever): item icons show again, for example at the merchant and in the character window]=]},
})

addChange("12.1.3", {
    {GW.Enum.ChangelogType.feature, [=[Edit mode: new skin for the window, the settings of a frame and its dialogs (option under Skins)]=]},
    {GW.Enum.ChangelogType.feature, [=[Loot feed: the items, currencies and money you receive in a short list that fades out, like in Guild Wars 2; the icons show their tooltip and hold their row, equipment shows its item level on the icon; options for the lowest item quality and for money]=]},
    {GW.Enum.ChangelogType.feature, [=[Quest tracker (Wrath, Mists, Retail, Forever): new section "Nearly Done" with the three achievements you are closest to completing; right-click tracks or hides one (option, off by default)]=]},
    {GW.Enum.ChangelogType.feature, [=[World map: exploration progress as a ring on each zone of the continent maps that is not fully explored, shown when the mouse is over the zone, the tooltip lists the areas still missing (Classic and TBC: the number of explored areas) (option, off by default)]=]},
    {GW.Enum.ChangelogType.feature, [=[World map: a panel with the exploration of the shown zone and its continent, collapsible, in a corner and at a distance of your choice; with Krowi's Achievement Filter also the achievements of the zone, a click opens them in its achievement window; a trail of dots shows the way you went in this session (own option, off by default)]=]},
    {GW.Enum.ChangelogType.feature, [=[Skins for the shop, on Retail and Forever for the PvP scoreboard, on Retail for the catalyst and the scrapper]=]},
    {GW.Enum.ChangelogType.feature, [=[Chat bubbles: border and name in the color of the chat type, like yell, party or party leader (option, off by default)]=]},
    {GW.Enum.ChangelogType.change, [=[Quest log (Classic, TBC): hover in the quest type color, colors stay when a quest is hovered or selected, dungeon and group quests show the icons of the quest tracker, hovering a quest shows its objectives, finished ones struck through like in the tracker; opening a quest from the tracker scrolls the log to it; PvP, legendary and important quests get a star in their type color, the quest compass shows the same type and color as the tracker]=]},
    {GW.Enum.ChangelogType.change, [=[Move HUD: shift-click puts a frame behind the frames it overlaps, so the one below can be reached]=]},
    {GW.Enum.ChangelogType.change, [=[Settings: Discord and GitHub buttons next to the close button, they replace the Join Discord entry; the system info is a page of the overview like the credits]=]},
    {GW.Enum.ChangelogType.change, [=[AFK screen: guild name in guild color; auto repair: the chat message shows the cost like the durability tooltip]=]},
    {GW.Enum.ChangelogType.change, [=[Unit frames: offline players show a full gray health and power bar like the group frames, an unknown level as ??]=]},
    {GW.Enum.ChangelogType.bug, [=[Unit frames (TBC): health no longer stays on an old value during combat]=]},
    {GW.Enum.ChangelogType.bug, [=[Target of target: the cast bar no longer runs backwards when a cast follows a channel]=]},
    {GW.Enum.ChangelogType.bug, [=[Bags: Mark Unusable Items is correct for items seen for the first time and, on the classic clients, in the bank]=]},
    {GW.Enum.ChangelogType.bug, [=[Collections, transmog: the help button can be clicked on its whole area again, its help in our look]=]},
    {GW.Enum.ChangelogType.bug, [=[Move HUD: the X and Y fields of a frame keep the same meaning after dragging it as after resetting it]=]},
    {GW.Enum.ChangelogType.bug, [=[Reputation: a faction marked as inactive moves into the Inactive category right away]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest tracker (Retail, Forever): a quest ready for turn in no longer lists its open optional objectives]=]},
    {GW.Enum.ChangelogType.bug, [=[Group frames: the power bar "only healers" shows for healers, the unit tooltip shows the group role]=]},
    {GW.Enum.ChangelogType.bug, [=[Alerts: no error when our alerts and Blizzard's loot alerts show at the same time]=]},
    {GW.Enum.ChangelogType.bug, [=[Action bars: no longer empty when an addon with the old LibStrataFix is installed, like Paste]=]},
    {GW.Enum.ChangelogType.bug, [=[Profiles: icons from icon packs show correctly and no longer seem to change, loading the default settings keeps the profile icon]=]},
})

addChange("12.1.2", {
    {GW.Enum.ChangelogType.bug, [=[Bank (Classic clients): the first sort after login no longer sorts differently than the next one, special bags like quivers or herb bags are recognized right away]=]},
    {GW.Enum.ChangelogType.bug, [=[Profiles: the icon picker no longer stutters when it opens]=]},
    {GW.Enum.ChangelogType.bug, [=[Role bar: counts your own role on TBC and Wrath; Quest compass (Classic clients): class and PvP quests take their tracker color]=]},
    {GW.Enum.ChangelogType.feature, [=[Text designer: new blocks Guild and Target of the unit; names can be shortened, abbreviated or show the realm, the class as an icon, health and power as current / max, health with shield, power only on healers, AFK and DND in the status, threat in percent, reaction and health colors]=]},
    {GW.Enum.ChangelogType.change, [=[Quest tracker (Classic clients, Mists): class quests get their own section named after your class, like on Forever]=]},
    {GW.Enum.ChangelogType.change, [=[Quest log (Classic, TBC): looks like the quest tracker, zones as its headers, quests in its type colors, the level in front in its difficulty color; the objectives in the details get boxes and the tracker's progress bars]=]},
    {GW.Enum.ChangelogType.change, [=[Hero panel: the spellbook plays Blizzard's spellbook sounds when it opens and closes]=]},
    {GW.Enum.ChangelogType.change, [=[Settings: new options you already looked at keep a dim marker until the next update, searching for "!" lists them too]=]},
})

addChange("12.1.1", {
    {GW.Enum.ChangelogType.bug, [=[Guild bank: the search shows on TBC and Wrath and also finds item types like armor or herb]=]},
    {GW.Enum.ChangelogType.bug, [=[Profiles: only one activation prompt at a time, the import button shows its check mark]=]},
    {GW.Enum.ChangelogType.bug, [=[Bags and bank (Classic clients): sorting right after login no longer uses incomplete item data, the sort key bindings work; Mists: caged pets no longer stop the sorting]=]},
})

addChange("12.1.0", {
    {GW.Enum.ChangelogType.feature, [=[Action bars: extra bars can show only out of combat; bars hidden by their show option are really hidden and take no clicks; bars can hide while mounted or in a vehicle, on Retail also while skyriding; keybind and macro name position per bar]=]},
    {GW.Enum.ChangelogType.feature, [=[Quest tracker: section headers stay at the top while scrolling, a slim bar shows the scroll position; PvP quests are red; Forever: class quests get their own section]=]},
    {GW.Enum.ChangelogType.feature, [=[Minimap: side, order and visibility of the side buttons can be set; the AddOn flyout closes after a click, optionally also when the mouse leaves it; the FPS can be a hover detail; Classic clients: the layer as a minimap detail]=]},
    {GW.Enum.ChangelogType.feature, [=[Chat: name in chat puts a name like (Tom) in front of your messages, like Name2Chat; the chat tabs can be saved to the profile and applied on another character; with chat fading, hovering the chat shows the faded messages again; item links show their icon and item level; hidden tabs count new messages; whispers can play an own sound, /tt whispers your target]=]},
    {GW.Enum.ChangelogType.feature, [=[Classic clients: spellbook and talents mark spells that are not on the global cooldown; spell ranks that do not fit fold behind a +N button; Classic gets the advanced attributes window; Forever: energy and mana ticker, skinned group finder]=]},
    {GW.Enum.ChangelogType.feature, [=[Boss times: reworked page with instance cards, a timeline up to the key timer and every boss against its best time]=]},
    {GW.Enum.ChangelogType.feature, [=[New optional ring around the cursor that shows the global cooldown]=]},
    {GW.Enum.ChangelogType.feature, [=[Cast bars: target of target and focus target can show interrupts, interrupted casts name the interrupter]=]},
    {GW.Enum.ChangelogType.feature, [=[Grids: border in the dispel type color, phase and PvP icons]=]},
    {GW.Enum.ChangelogType.feature, [=[Experience bar: shift-click the reputation bar to open the faction, tooltip on the upcoming level rewards]=]},
    {GW.Enum.ChangelogType.feature, [=[Grids, health globe, power bar, class power bars and unit frames (player, pet, target, focus, target of target, focus target, party, boss, arena): the texts are built from blocks by drag and drop in their settings, with icons, health, power, status, colors and own text; the unit frames get a level line and a power bar text with offsets, the small frames also a health text; the old text options are taken over]=]},
    {GW.Enum.ChangelogType.feature, [=[Layouts: the new layout "Gamepad" places the HUD around the gamepad bars of Forever and is picked there automatically; profile and gamepad layouts can be reset to their default positions]=]},
    {GW.Enum.ChangelogType.change, [=[Quest tracker (Classic clients): zone sorting, quest XP and the daily and weekly color work without Questie; Wrath posts real quest links; class quests are green like on Forever]=]},
    {GW.Enum.ChangelogType.change, [=[Action bars: empty slots hidden in Edit Mode come back on login, "Empty Slots Alpha" at 0% hides them until you drag something onto the bars]=]},
    {GW.Enum.ChangelogType.change, [=[New scale setting for the loot roll bars; the Pawn button of the hero panel shows the Pawn tooltip; Blizzard's own coordinates below the minimap are hidden]=]},
    {GW.Enum.ChangelogType.change, [=[Scale handles of hero panel, friends and world map: drag with the right button, Shift + right click resets; Escape closes the hero panel together with the other windows]=]},
    {GW.Enum.ChangelogType.change, [=[Bags: NEW label on new items; a left click on the gold picks up money like Blizzard's bags; the bags can also open automatically at the guild bank; the bank (Classic clients and Forever) can sort itself when opening; the guild bank has a search on TBC and Wrath too]=]},
    {GW.Enum.ChangelogType.change, [=[Reputation tracking: losses no longer switch the bar, renown and paragon gains count too]=]},
    {GW.Enum.ChangelogType.change, [=[New credits page, reviewed English texts and a few settings polished; a click on the version in the settings copies it for bug reports]=]},
    {GW.Enum.ChangelogType.bug, [=[Action bars: no flicker between the override and the normal bar, fewer "action blocked" errors; Classic multi bars no longer stay hidden after a reconnect; Forever: no Edit Mode error on save; the out of range color follows page, stance and form changes]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest tracker: correct scroll range after a resize and in combat; Classic clients: elite and dungeon icons in every language]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest frame and immersive questing (Classic clients): quest texts are always readable, required items show their name]=]},
    {GW.Enum.ChangelogType.bug, [=[Minimap: the instance difficulty no longer shows only 0 and works in every language; switched off coordinates stay hidden on hover, hovering the clock or coordinates no longer hides them, the coordinates hide in instances]=]},
    {GW.Enum.ChangelogType.bug, [=[Tooltips: "Hide in combat" no longer hides them out of combat with a modifier key; guild names with "level" no longer break the level line]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: NPC lines in instances get a timestamp again, no quick join error in combat]=]},
    {GW.Enum.ChangelogType.bug, [=[Damage meter skin: bar backgrounds stay transparent after login and in the details]=]},
    {GW.Enum.ChangelogType.bug, [=[Merchant: all buyback slots are skinned without the extended vendor]=]},
    {GW.Enum.ChangelogType.bug, [=[Forever: tracked recipes and professions dragged to the action bars open again, without "action blocked" in combat; easier to read skill bar numbers; no "action blocked" errors with the gamepad interface, whose action bar and micro bar settings are greyed out and whose focus frame no longer shows around the windows]=]},
    {GW.Enum.ChangelogType.bug, [=[Hero panel: possible taint from the equipment flyout; reputation shows the session gain for renown factions]=]},
    {GW.Enum.ChangelogType.bug, [=[World map: no "action blocked" when closing it; Classic and TBC apply the map opacity right after login]=]},
    {GW.Enum.ChangelogType.bug, [=[Classic clients: shift-click in the quest log tracks the right quest, quests show their required gold, the character window opens again after closing it with escape, Wrath glyph icons and pet talents, Mists quest sharing and untracking from the tracker, inspected talents on Mists, window titles of the macro and merchant frames on Wrath and Mists]=]},
    {GW.Enum.ChangelogType.bug, [=[Smaller fixes: renaming the active profile keeps its settings, uninterruptible casts show on target and focus, their level is colored like in the tooltip, item icons in popups are no longer upside down, party pet power bars update, druid form art and the demon hunter void metamorphosis bar, the raid 40 sort method and dispel icon options work, resetting the player aura movers resets their settings too, the character window loads after a reload in combat, no errors from the target threat value on bosses, when a movie plays or in the group finder inside instances, immersive questing no longer holds the keys in combat, Forever: the embedded professions window keeps its size, unit frame portraits no longer turn black now and then, group leader crown on target and focus, Delve tier in the boss times, new profiles remember their character, same title size in all windows]=]},
})

addChange("12.0.0", {
    {GW.Enum.ChangelogType.feature, [=[Support for World of Warcraft: Forever, with its own hero panel, bank, swing timer and skins for its new windows]=]},
    {GW.Enum.ChangelogType.change, [=[One addon for every game version; large parts of GW2 UI are rewritten to be faster and use less memory]=]},
    {GW.Enum.ChangelogType.feature, [=[Quest tracker: the quest level is back, a group info bar for Mythic+ and raid bosses (deaths, battle res, bloodlust) and boss times with Mythic+ splits, compared to your best, in a new "Boss Times" page]=]},
    {GW.Enum.ChangelogType.feature, [=[Quest tracker boss and arena frames: a slim cast bar and, on Retail and Forever, the most important auras; preview them in the settings]=]},
    {GW.Enum.ChangelogType.feature, [=[Own loot roll bars with timer and item level]=]},
    {GW.Enum.ChangelogType.feature, [=[Guild bank in the look of the GW2 bank and an optional bind type label on items]=]},
    {GW.Enum.ChangelogType.feature, [=[Automation options (all off by default): accept group invites from friends, set your role, track reputation, fast loot, release in battlegrounds and a train all button]=]},
    {GW.Enum.ChangelogType.feature, [=[Tooltips: Mythic+ enemy forces, best Mythic+ run, optional item quality border and the mount of other players again]=]},
    {GW.Enum.ChangelogType.feature, [=[Dynamic HUD: choose the action bar background in and out of combat, with its own opacity]=]},
    {GW.Enum.ChangelogType.feature, [=[Honor badges on Retail in the health globe tooltip and on the honor bar, with matching prestige portraits]=]},
    {GW.Enum.ChangelogType.feature, [=[Profiles: a new page lists the data saved per character and removes it for deleted characters]=]},
    {GW.Enum.ChangelogType.feature, [=[Micro bar: right click on the talent button switches specialization, loot specialization and loadout]=]},
    {GW.Enum.ChangelogType.feature, [=[More for the classic clients: upcoming spells, shaman totem bar, player pet frame options and abandon quest in the quest tracker menu]=]},
    {GW.Enum.ChangelogType.feature, [=[Small additions: currency cap toast, game icons in the friends data text, GW2 UI memory in the system data text, loot frame scale also with loot under the mouse]=]},
    {GW.Enum.ChangelogType.feature, [=[New and updated skins: quest choice, class trainer, trade, mail and hunter stable on all clients, chat, communities, books and letters, macros, flight map, merchant, inspect, dressing room, transmogrifier, Auctionator and Postal]=]},
    {GW.Enum.ChangelogType.change, [=[Friends tooltip and menu moved to the contacts button next to the chat]=]},
    {GW.Enum.ChangelogType.change, [=[Smaller changes: sliders show percent, cleaner status report, target and focus frames without show animation, Forever leaves the action bars to the gamepad interface]=]},
    {GW.Enum.ChangelogType.bug, [=[Fewer taints and "action blocked" errors, among them the spellbook, the game menu and bags in combat]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixes for combo points, talents, alerts, data texts, raid control, chat, the world map, mail and the hero panel]=]},
})

addChange("11.2.1", {
    {GW.Enum.ChangelogType.bug, [=[Fix actionbars not shown]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Micromenu hover lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Layouts: frame positions no longer jump to default at login after an older version was run in between]=]},
})

addChange("11.2.0", {
    {GW.Enum.ChangelogType.change, [=[Settings are stored in a new structure, grouped by module. Every profile is converted once on the first login, positions and values stay as they are; the old format cannot be read by earlier versions anymore, so a downgrade below 11.2.0 starts with default settings]=]},
    {GW.Enum.ChangelogType.bug, [=[Layouts: a layout that says nothing about a frame leaves it alone instead of pulling it to its default position, which moved frames around on every profile; it adopts the current position of that frame once instead]=]},
    {GW.Enum.ChangelogType.change, [=[Adventure guide, journeys tab: the renown and journey cards, their progress bars and the reward cards of a journey follow the skin instead of showing blizzards golden plates]=]},
    {GW.Enum.ChangelogType.bug, [=[Profile switch by specialization: the frames now move to the positions of the incoming profile instead of staying where the old profile had them]=]},
    {GW.Enum.ChangelogType.bug, [=[Layouts: renaming a layout keeps its specializations assigned, deleting one no longer leaves the buttons pointing at it, empty names are rejected and a new layout no longer follows later frame moves]=]},
    {GW.Enum.ChangelogType.feature, [=[Classic, TBC and Wrath: the inspect window is skinned now, with the portrait of the inspected player in the header, item levels on the equipment slots and the gw2 paperdoll background behind the model]=]},
    {GW.Enum.ChangelogType.feature, [=[Classic, TBC, Wrath and Mists: the dressing room and the small preview window of quest rewards follow the skin of the other windows]=]},
    {GW.Enum.ChangelogType.change, [=[Alert toasts: icons carry the 1px border of the other skins and show the item quality on loot, legendary items, followers, pets, mounts and toys, titles and names use the same fonts on every toast, bonus roll toasts are skinned on every show]=]},
    {GW.Enum.ChangelogType.feature, [=[Reputation overview: rows of factions with a paragon chest waiting glow softly and a band of light sweeps across them, the reward icon turns with its own flare]=]},
    {GW.Enum.ChangelogType.feature, [=[Rare toast: shift + right click puts the rare on an ignore list, the list can be edited in the notification settings]=]},
    {GW.Enum.ChangelogType.feature, [=[Notification settings: a play button next to every toast option shows that toast once, with its sound]=]},
    {GW.Enum.ChangelogType.feature, [=[Alerts: new toasts for full bags and a Great Vault with rewards to collect (Retail), the rare toast can add a chat line with a clickable map pin to the position; the paragon toast covers the Dragonflight factions and the durability, call to arms and paragon checks are more reliable]=]},
    {GW.Enum.ChangelogType.feature, [=[Collections skin: progress bars with tooltips on every tab, mount achievement points next to the counter, double click summons a mount or pet and middle click toggles its favorite, wardrobe slot tooltips show the collected appearances of the slot, heirloom icons show the upgrade level as pips]=]},
    {GW.Enum.ChangelogType.feature, [=[New addon skin for Extended Transmog Sets (Retail): the set list, its filter and scrollbar follow the collections skin]=]},
    {GW.Enum.ChangelogType.change, [=[New skin for the collections journal (Retail): frame and tabs, mount and pet lists, pet card and battle pet loadout, toy and heirloom grids with quality borders, wardrobe items, sets and the transmog vendor models, warband scenes, plus scroll bars, dropdowns, search boxes and summon buttons]=]},
    {GW.Enum.ChangelogType.change, [=[New skin for the Blizzard settings panel (all game versions): frame, tabs, category list, checkboxes, sliders, dropdowns, buttons and keybinding rows]=]},
    {GW.Enum.ChangelogType.feature, [=[Great Vault micro menu button: the tooltip now shows the weekly progress of all three raid, dungeon and world slots]=]},
    {GW.Enum.ChangelogType.feature, [=[Micro bar: the order of the buttons can be changed and single buttons can be hidden (HUD settings, micro bar section), a reset button restores the defaults]=]},
    {GW.Enum.ChangelogType.feature, [=[Micro menu tooltips: achievement points, collection counts, profession skills, group finder split into dungeons and pvp with live queue times, keystone, mythic+ rating and rated brackets]=]},
    {GW.Enum.ChangelogType.feature, [=[Micro bar: can be arranged vertically (HUD settings) and scaled in Move HUD mode, the background art follows the screen position and has its own show option instead of disappearing once the bar is moved]=]},
    {GW.Enum.ChangelogType.feature, [=[Update icon: remembers the newest version seen in group or guild across reloads, a click opens the changelog; the settings overview shows the available update in a banner above the changelog]=]},
    {GW.Enum.ChangelogType.feature, [=[Update icon tooltip: installed and available version, how many features, changes and fixes the update brings and who reported it; chat notice and flash can be switched off in the micro bar settings]=]},
    {GW.Enum.ChangelogType.change, [=[Hero panel stats picker: order and visibility are stored per character now (existing profile settings are carried over once), the set bonus tile is hidden via the picker instead of an option]=]},
    {GW.Enum.ChangelogType.change, [=[Settings migrations from versions before 11.0.0 removed]=]},
    {GW.Enum.ChangelogType.bug, [=[Micro bar fade: the bar no longer ends up invisible but clickable when the mouse comes back during the fade out, and hovering the update, mail or work order icon keeps the bar shown]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix the addon update notification: the version comparison never matched release versions and compared numbers as text]=]},
    {GW.Enum.ChangelogType.bug, [=[Spellbook on Classic, TBC and Wrath: no more stutter when opening, the book is only rebuilt after spell or talent changes and the unknown spell filter runs a lot cheaper]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat tabs no longer change their size on hover on Classic, TBC, Wrath and Mists]=]},
})

addChange("11.1.6", {
    {GW.Enum.ChangelogType.change, [=[Dressing room skin: GW2 header with framed portrait, framed model area with skinned controls, the transmog set panel and its list are skinned as well]=]},
    {GW.Enum.ChangelogType.change, [=[Merchant and flight master skins: the npc portrait in the header is framed like the inspect portrait]=]},
    {GW.Enum.ChangelogType.change, [=[Inspect skin (retail and mists): GW2 model background, item level on the slots, framed portrait with name and level in the header; retail also: PvP tab with honor header, talent row and rating blocks, GW2 fonts on the guild tab]=]},
    {GW.Enum.ChangelogType.change, [=[Great Vault skin: reward slots, activity art, intro text and the currency row now use the GW2 look, locked slots show a lock, the selected slot a gold border]=]},
    {GW.Enum.ChangelogType.change, [=[Character data (gold per character) moved into the main database, the old GW2UI_STORAGE2 variable is migrated automatically]=]},
    {GW.Enum.ChangelogType.change, [=[Era clients: the quest tracking state moved into the character database, the old GW2UI_QUEST_WATCH_DB variable is migrated automatically]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix actionbar binding error on era clients]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix pet bar keybindings missing after a fresh login]=]},
    {GW.Enum.ChangelogType.bug, [=[Micro menu: the inventory and character tooltips no longer stay open after leaving the button]=]},
    {GW.Enum.ChangelogType.bug, [=[Micro menu: the quest counter no longer includes hidden quests]=]},
    {GW.Enum.ChangelogType.change, [=[World event tracker: code split per expansion, less work per tick, fixed the taskbar flash option, the next event time in the micro menu tooltip and alerts of disabled events]=]},
    {GW.Enum.ChangelogType.change, [=[World event tracker: new Midnight weekly storylines (Prey Hunt, Silvermoon Court, Zul'jarra's Forces, Slayer's Duellum), updated Liadrin quest list and a "ready for turn-in" state in the tooltip]=]},
    {GW.Enum.ChangelogType.bug, [=[Action bars are now layered above the objectives tracker]=]},
    {GW.Enum.ChangelogType.change, [=[Hero panel (Retail): missing enchants and empty sockets are marked red (item info option), optional item level coloring relative to the equipped average, set bonus count and Mythic+ rating as tiles in the attributes list with tooltips]=]},
    {GW.Enum.ChangelogType.change, [=[Hero panel (all game versions): stats picker via the cog in the attributes box - hide single stats, reorder them by drag and drop, right click resets to the defaults]=]},
    {GW.Enum.ChangelogType.bug, [=[Hero panel can be moved during combat (placed at the cursor on release), scaling in combat shows a notice instead of an error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix minimap coordinates staying at N/A or frozen depending on the order the options were enabled]=]},
    {GW.Enum.ChangelogType.bug, [=[Show the "Move to Inactive" toggle in the reputation details on era clients]=]},
    {GW.Enum.ChangelogType.change, [=[Reputation: at war factions are marked in the list, the detail options are now one checkbox row]=]},
    {GW.Enum.ChangelogType.change, [=[Reputation: show the amount missing to the next rank, right click toggles the experience bar, no empty description block]=]},
    {GW.Enum.ChangelogType.feature, [=[Reputation: show the reputation gained this session per faction (resets on reload, ctrl + right click resets it manually)]=]},
})

addChange("11.1.5", {
    {GW.Enum.ChangelogType.bug, [=[Fix evoker ebon might bar]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix party unit values]=]},
})

addChange("11.1.4", {
    {GW.Enum.ChangelogType.feature, [=[Bags: the bag can open and close itself with the merchant, mailbox, auction house, bank and trade window - pick the contexts in the new "Open automatically at" submenu of the bag settings. Only what the auto open opened gets closed: a bag you opened yourself stays]=]},
    {GW.Enum.ChangelogType.feature, [=[Bags: new display options - sort on open, grey out junk, tint items red that your character cannot use, and an equipment set icon on set items (Retail) so they are safe from accidental selling]=]},
    {GW.Enum.ChangelogType.bug, [=[Quest tracker (Retail): the group finder eye no longer breaks Blizzards applicant list - clicking it tainted the group finder, and with the secret values of 12.1 every applicant update then errored until reload]=]},
    {GW.Enum.ChangelogType.bug, [=[Auras (Retail): no more blocked action error when your dispel abilities change during combat - the aura containers now refresh right after the fight instead]=]},
    {GW.Enum.ChangelogType.bug, [=[Player buffs (Retail): weapon enchantment slots sit flush in the buff grid again instead of drifting off with a gap]=]},
    {GW.Enum.ChangelogType.bug, [=[Bag taint]=]},
})

addChange("11.1.3", {
    {GW.Enum.ChangelogType.change, [=[Advanced aura filters (Retail): rebuilt from the ground up so an aura can never appear twice again - even with the secret aura values of patch 12.1. Every selected filter now narrows the display, and each entry cycles through three states: off, required (check) or excluded (red cross)]=]},
    {GW.Enum.ChangelogType.feature, [=[New aura property filters (Retail): Dispellable, Stealable, Boss Aura, Priority Debuff and Role Aura - these stay accurate even while aura data is secret]=]},
    {GW.Enum.ChangelogType.change, [=[Aura display (Retail): target, focus and pet frames show one buff and one debuff block with their own size sliders; the "own auras bigger" split had to go - it was the source of the duplicate icons. Dispel type icons still appear only on debuffs you can dispel and now follow talent changes instantly]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix wrong HP values on retail clients]=]},
    {GW.Enum.ChangelogType.bug, [=[Setting improvements]=]},
    {GW.Enum.ChangelogType.bug, [=[Grids hides correctly]=]},
})

addChange("11.1.2", {
    {GW.Enum.ChangelogType.bug, [=[Secret more secrets]=]},
})

addChange("11.1.1", {
    {GW.Enum.ChangelogType.bug, [=[Unit frames (Retail): Blizzard reads the .unit field on frames itself since 12.1 (the ping system among others) - an addon-written value there is tainted and trips up Blizzards secure readers. The oUF-based raid grids got the upstream oUF fix (internal state moved to its own field), and every own secure unit frame (player, target, focus, party, pet, boss, arena) keeps its bookkeeping in a gw-prefixed field now; the unit reaches Blizzard exclusively through the secure "unit" attribute]=]},
    {GW.Enum.ChangelogType.bug, [=[Memory (Retail): the raid grids built a full aura container setup for every one of their ~125 pre-created (hidden) frames right at login - and bound them to the PLAYERS own auras on top, so each of them also built skinned aura buttons for every aura you had. That cost around 90 MB before you ever joined a group. Grid aura containers and indicator trackers are now built lazily, when a frame receives its first real unit (deferred out of combat), and never fall back to tracking the player]=]},
    {GW.Enum.ChangelogType.change, [=[Performance: the quest tracker no longer rebuilds every tracked quest on every quest log update - unchanged quests are skipped via a content fingerprint, rows only re-apply fonts and anchors when the layout settings actually changed, and the per-line allocation churn is gone. Progress on one quest now only redraws that quest. Applies to ALL game versions]=]},
    {GW.Enum.ChangelogType.change, [=[Advanced aura filters (Retail): the "Dispellable" option matches its label again - it shows auras your group can dispel (as the old aura engine did), not every aura that merely has a dispel type]=]},
})

addChange("11.1.0", {
    {GW.Enum.ChangelogType.feature, [=[Dispel type icon (Retail): debuffs show their dispel type (magic, curse, poison, disease) as a small corner icon on the player, target, focus, pet, party and raid frames. The per-frame "Show Dispel Type Icon" setting is a three state choice now - off, on every debuff with a dispel type, or (the default) only on debuffs your group can actually dispel, matching Blizzards own dispel indicator behavior. Dispellable debuffs render before the rest of a frames debuffs for that]=]},
    {GW.Enum.ChangelogType.bug, [=[Secret more secrets]=]},
})

addChange("11.0.0", {
    {GW.Enum.ChangelogType.change, [=[Patch 12.1 (Retail): full compatibility update - all removed APIs replaced, the Social/Friends frame skin was rebuilt for Blizzards new SocialUI, and the "Advanced Tooltip ID Modifier" setting works again on the new secure auras]=]},
    {GW.Enum.ChangelogType.change, [=[Auras (Retail): player bars, target, focus, pet, party and the raid grids run on Blizzards new AuraContainer system now, so everything keeps working while aura values are secret in combat - including stack counts, cooldown swipes, the indicator duration bars and the "show aura tooltips out of combat" mode. The GW2 look is unchanged, the other game versions keep the old engine]=]},
    {GW.Enum.ChangelogType.feature, [=[Auras: new "Ignored Auras" setting - hide an aura by its spell id, with icon, name and tooltip per entry. Available for target, focus, pet and party frames on all game versions, for the player bars on Retail and per grid type on the raid grids (it replaces the old global name based text field there, custom entries have to be re-added once)]=]},
    {GW.Enum.ChangelogType.feature, [=[Auras: new "Aura Sorting" setting - default, remaining time or name, each ascending or descending. For the player bars on all game versions (old sort settings are migrated) and for target, focus and pet on Retail]=]},
    {GW.Enum.ChangelogType.feature, [=[Pandemic highlight (Retail): your own auras glow while they are inside their pandemic window (the last 30% of the duration, where refreshing adds the remaining time on top) - on the player, target, focus, pet, party and raid frames including the aura indicators. Can be turned off per frame ("Pandemic Highlight")]=]},
    {GW.Enum.ChangelogType.feature, [=[Auras (Retail): the "Important" filter is back in the advanced buff/debuff filters (raid grids, target, focus, pet); the grid debuff filters default to important plus dispellable debuffs. Stealable buffs on target and focus get their highlight border back]=]},
    {GW.Enum.ChangelogType.feature, [=[Raid grids (all game versions): the aura indicator dropdowns accept any spell now - pick "Custom Spell ID..." and enter the id manually; custom spells use a neutral white indicator color]=]},
    {GW.Enum.ChangelogType.bug, [=[Dungeon & Raid Debuffs (Retail): the list, its scale and the grid emphasis work again on the party frames and the raid grids (was disabled since 12.0)]=]},
    {GW.Enum.ChangelogType.change, [=[Raid grids: the private aura module was removed - 12.1 merged private auras into the normal debuffs, they show up in the regular debuff display now]=]},
    {GW.Enum.ChangelogType.feature, [=[Class powers (Retail): the aura driven bars removed in 12.0 are back and secret proof - Shield of the Righteous, Metamorphosis, Barbed Shot, Mongoose Fury, Rend, Enrage and Shield Block (incl. Last Stand with Bolster)]=]},
    {GW.Enum.ChangelogType.feature, [=[Dynamic HUD (Retail): the aura driven combat HUD backgrounds removed in 12.0 are back, including the model effects (Avenging Wrath, Metamorphosis, Ascendance, Dark Transformation, Dragonrage, Eclipse, ...)]=]},
    {GW.Enum.ChangelogType.bug, [=[Health globe (Retail): absorb shields and incoming heals sit on top of the current health fill again instead of filling from the bottom]=]},
    {GW.Enum.ChangelogType.feature, [=[Dodge bar (all game versions): shows the remaining cooldown of the tracked ability as text, plus the available charges for abilities that have them. Can be turned off in the player settings ("Show Dodge Bar Cooldown Text")]=]},
    {GW.Enum.ChangelogType.bug, [=[Dodge bar (Retail): the bar was empty after a login or reload, abilities without charges (Disengage, Blink, ...) never showed their cooldown, and the fill now spans the whole visible arc so it matches the cooldown exactly]=]},
    {GW.Enum.ChangelogType.change, [=[Profile export/import runs on Blizzards C_EncodingUtil now, the bundled LibDeflate, LibBase64, LibCompress and AceSerializer libraries were removed. New export strings start with "!GW3!", old "!GW2!" strings stay importable]=]},
    {GW.Enum.ChangelogType.feature, [=[Move HUD: the mover dialog shows the exact X/Y offsets as editable fields, two buttons center a frame on the screen axes, shift clicking the arrows nudges by 10 pixels, and dragging snaps to the grid while it is shown]=]},
    {GW.Enum.ChangelogType.change, [=[Settings: sliders show a value fill up to their handle and every option row highlights under the mouse]=]},
    {GW.Enum.ChangelogType.feature, [=[Bags: three new settings - "Item Level Threshold" (only draw the item level at or above a chosen value), "Hide Empty Slots" (empty slots are left out and a placeholder shows the free slot count; it still accepts dropped items, combined bag view only) and "Mark New Items" (a marker on newly received items until the bags are closed)]=]},
    {GW.Enum.ChangelogType.change, [=[Bags: the search filter is dropped when the bags close - a forgotten filter no longer hides items on the next open]=]},
    {GW.Enum.ChangelogType.bug, [=[Action bars: hotkey labels no longer shift or lose their short format when the game detects a gamepad, long bindings like "CTRL+!" no longer ellipsize, and the multi bar/pet/stance hotkeys use a larger font]=]},
    {GW.Enum.ChangelogType.bug, [=[Bank (Classic): the "buy bank slot" confirmation shows the price again and items in the main bank slots show their tooltip again]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed several errors: opening the game menu in combat ("protected function Button:SetSize()"), reloading during combat (damage meter skin, gossip frame)]=]},
    {GW.Enum.ChangelogType.change, [=[Known issues on Retail: the "New Aura Animation" is not possible with Blizzards secret aura restrictions and is disabled there; auras matching several advanced filter branches at once can show up twice in rare cases]=]},
})

addChange("10.15.1", {
    {GW.Enum.ChangelogType.bug, [=[Bags (Retail): fixed "AddOn 'GW2_UI' tried to call the protected function 'UseContainerItem()'" when using an item from the bags or selling it to a vendor, after which the bags stopped responding until a reload - the bag id was stored on the item buttons under the same field name Blizzards own item button mixin reads, so Blizzard got our value instead of its own and refused the interaction; the item state fields go through Blizzards setters now]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: fixed an error when switching chat tabs while a chat frame had lines that Blizzard had not laid out yet]=]},
})

addChange("10.15.0", {
    {GW.Enum.ChangelogType.change, [=[Bags & Bank: complete rework on every game version - bags and bank use their own item buttons now instead of taking Blizzards multi purpose buttons, which ends the fights with Blizzards layout and update code (anchor errors, misplaced buttons); Blizzards container and bank frames are made inert at load, so they no longer update in the background or play their own open/close sounds. All behavior, settings and the resize handling stay the same]=]},
    {GW.Enum.ChangelogType.change, [=[Bags & Bank: the per game version duplicated code moved into one shared implementation - fixes only need to be made once now; the bag bar uses Blizzards real bag slot buttons everywhere, one central item button skin marks quest items with the same golden quest icon on every flavor, and flavor extras (currency display, azerite/corruption/scrap, equipment set names) plug in as small modules]=]},
    {GW.Enum.ChangelogType.feature, [=[Bank: own icon size and slot spacing settings on every game version, previously shared with the bags; the current bag values are carried over once so nothing changes visually]=]},
    {GW.Enum.ChangelogType.feature, [=[Bank (Classic/TBC/Wrath/Mists): new "Separate bags" option like the bags already have it - the main bank and each bank bag get their own section with a collapsible header that can be renamed via right click; the "Reverse Bag Order" toggle also applies immediately again]=]},
    {GW.Enum.ChangelogType.feature, [=[Bags: new "Separate keyring" (Classic/TBC/Wrath) and "Separate reagent bag" (Retail) options - in the combined bag view the keyring or reagent bag starts on its own row with a gap as separation, so it is visible that these slots do not belong to the bags]=]},
    {GW.Enum.ChangelogType.feature, [=[Bags: the profession bag coloring wins over an items quality color on every flavor by default now; the new option "Show Quality Color for Profession Bags" flips that around]=]},
    {GW.Enum.ChangelogType.change, [=[Bags: retail niceties for every game version - the retail styled money icons, the localized gold number format, the skinned stack split popup and a uniform minimum frame size; the watched currency displays (Retail/Mists) fill the available bag width instead of showing a fixed number]=]},
})

addChange("10.14.3", {
    {GW.Enum.ChangelogType.bug, [=[Bags (Classic/TBC/Wrath/Mists): fixed "SetPoint would result in anchor family connection" errors after opening the bags multiple times; the taken container item buttons are reset to a single clean anchor right away, since Blizzards container code only adds anchor points and the leftover mixed anchors bridged our bag frames with the container frames]=]},
    {GW.Enum.ChangelogType.bug, [=[Bags (Classic Era): the bag slot buttons sit above the keyring button again; Blizzards new bags bar relayouts the backpack button on login and on edit mode updates and pulled it out of our bag bar]=]},
})

addChange("10.14.2", {
    {GW.Enum.ChangelogType.bug, [=[Talents (Classic Era): fixed a login error introduced with the staged loading; the talent trees are now created lazily once the server has delivered the talent data]=]},
    {GW.Enum.ChangelogType.change, [=[Talents (Classic/TBC/Wrath/Mists): the talent frame no longer uses global frame lookups - trees, buttons and prerequisite arrows are referenced directly now and on Mists the Blizzard talent buttons for the secure click routing are cached; also removed the unused talent branch array and the dead line blocking logic]=]},
    {GW.Enum.ChangelogType.change, [=[Spellbook (Classic/TBC/Wrath/Mists): the spellbook no longer uses global frame lookups - tab containers, buttons, headers and the future spells tab are referenced directly now; this also fixes a stale spell group header when the spell list shrinks on Classic and the future spells tab not clearing its previous entries on TBC/Wrath]=]},
})

addChange("10.14.1", {
    {GW.Enum.ChangelogType.bug, [=[Cast bar: fixed a "table that cannot be accessed while tainted" error from Blizzards overlay casting bar on Retail; the overlay cast bar is now disabled like the other Blizzard cast bars when the GW2 UI cast bar is active, and the cast bar mover is now also killed on Classic Era]=]},
    {GW.Enum.ChangelogType.bug, [=[Classic Era: fixed "Script ran too long" errors during login on Hardcore realms; the UI setup now runs in stages - on Era the main part right after the addon has loaded, the Blizzard dependent parts (chat, minimap, action bars, edit mode) on PLAYER_LOGIN, and on all clients the Blizzard/addon skins load in their own execution one frame later, so no single execution exceeds the hardcore script watchdog]=]},
})

addChange("10.14.0", {
    {GW.Enum.ChangelogType.feature, [=[New chat option "Chat Buttons Position": move the chat control buttons (menu, channel, voice, social) into a small hover bar above or right of the chat; text, tabs and edit box then use the full chat width. Switches live without a reload]=]},
    {GW.Enum.ChangelogType.feature, [=[The settings window now shows a "Reload required" hint in the header as soon as a reload setting is changed, with a tooltip listing the pending settings; toggling a setting back to its original state removes the reload prompt again]=]},
    {GW.Enum.ChangelogType.feature, [=[Classic Era: update for patch 1.15.9 - the Era client now uses the modern shared UI, so action bars, stance/pet bar, micro menu, status tracking bars, game menu, addon list and minimap were moved onto the same code path as the other clients, including Edit Mode layout support]=]},
    {GW.Enum.ChangelogType.change, [=[Runes (Season of Discovery): the rune filter dropdown now uses the modern menu system like Blizzards engraving frame; the old dropdown tainted the shared dropdown globals for the whole session]=]},
    {GW.Enum.ChangelogType.bug, [=[Classic: fixed an ADDON_ACTION_FORBIDDEN error from the protected ClearTarget() when the GW2 layout is applied on login or the Edit Mode is closed; the Edit Mode target/focus preview reset is skipped on classic clients since 1.15.9 protects the targeting functions]=]},
    {GW.Enum.ChangelogType.bug, [=[Spellbook (Season of Discovery): the rune tab no longer shows hidden placeholder spells for not yet learned runes, matching the default spellbook]=]},
    {GW.Enum.ChangelogType.bug, [=[Game menu: fixed logout and exit game failing with an ADDON_ACTION_FORBIDDEN error on classic clients; the edit mode layout apply inevitably taints the menu wiring, so both buttons are now driven by secure /logout and /quit click overlays, and the GW2 UI settings button no longer goes through Blizzards button pool]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed font shadows no longer rendering on unit frames, nameplates, objectives, tooltips and other addon texts since 12.0.7 broke shadows set directly on font strings; shadows are now applied via generated font objects instead]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: NPC emotes on non-Retail clients showed a literal %s instead of the NPC name; the name placeholder inside the emote text is formatted again]=]},
    {GW.Enum.ChangelogType.bug, [=[Talents (Mists): fixed ADDON_ACTION_FORBIDDEN errors from the protected RemoveTalent() when unlearning or switching talents; learning and unlearning now run through Blizzards secure talent buttons and a switched talent is learned automatically once the unlearn is confirmed]=]},
})

addChange("10.13.1", {
    {GW.Enum.ChangelogType.feature, [=[Talents can now be unlearned via right-click in the talent frame (Mists)]=]},
    {GW.Enum.ChangelogType.feature, [=[Static popups and GW2 UI's own popup dialogs restyled in the ready check look: shaded footer band with divider behind the buttons and green confirm / red cancel buttons with check and cross icons]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed the action bar flickering/bouncing between the normal bar and the vehicle/override bar during combat (removed tainting custom button flash code; Blizzard handles auto-attack flashing natively)]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: fixed several secret-value errors on Retail (keyword/URL filter, message formatter, chat bubbles, LFG role icons, chat history) and no longer drop secret system messages]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat: fixed Battle.net friend lookup in the social queue leader detection using the wrong API]=]},
    {GW.Enum.ChangelogType.change, [=[Performance: optimized aura processing, cast bar and unit frame events to cut per-frame CPU usage]=]},
    {GW.Enum.ChangelogType.change, [=[Performance: chat bubbles and the world event tracker no longer poll every frame in the background]=]},
    {GW.Enum.ChangelogType.change, [=[Performance: reduced memory churn in damage text, runes, timers, action bars and bag/inventory coloring]=]},
    {GW.Enum.ChangelogType.feature, [=[Cast bar: the player/pet cast bar can be sized freely now - width and height sliders in the player cast bar settings. Ticks, empower stages and the latency zone follow the new size]=]},
    {GW.Enum.ChangelogType.feature, [=[Cast bar: the "Advanced Casting Bar" toggle was replaced by one setting per element - spell name, cast timer and latency zone can be turned on individually, and the spell icon can sit left, right or be hidden. Profiles that had the advanced bar enabled get all of them turned on. The target and focus cast bars get the same split (spell name, cast timer), and their cast timer works again on Retail - it never updated since the timer moved into the game engine]=]},
    {GW.Enum.ChangelogType.feature, [=[Cast bar: optional custom colors for casting, channeling, empowered and interrupted casts ("Custom Colors" in the player cast bar settings) - the painted bar art keeps its structure and takes your hue]=]},
    {GW.Enum.ChangelogType.feature, [=[Cast bar (Retail): empowered casts show the stage you are holding as a numeral on the bar and brighten with every stage reached. Interrupted or failed casts shake the bar, with an optional sound - all three can be turned off in the player cast bar settings]=]},
    {GW.Enum.ChangelogType.bug, [=[Bags: the "new item" marker stayed on a slot after the item was sold, moved or used up]=]},
    {GW.Enum.ChangelogType.change, [=[Performance: a bag update only refreshes the bags and slots that actually changed instead of rebuilding and re-laying out every bag slot, which removes the stutter while looting or using items with the bags open]=]},
})

addChange("10.13.0", {
    {GW.Enum.ChangelogType.feature, [=[Added column-based player aura growth directions and clearer row/column layout labels]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix some more Mists errors]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix for 12.0.7]=]},
})

addChange("10.12.2", {
    {GW.Enum.ChangelogType.bug, [=[Auras can be cancelled again (Mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed experience bar Lua error when tracking reputation with a classic pet active]=]},
})

addChange("10.12.1", {
    {GW.Enum.ChangelogType.bug, [=[Fixed issue with Mists support]=]},
})

addChange("10.12.0", {
    {GW.Enum.ChangelogType.feature, [=[Add support for Mists new patch]=]},
})

addChange("10.11.0", {
    {GW.Enum.ChangelogType.feature, [=[Add aura options to player pet frame]=]},
    {GW.Enum.ChangelogType.feature, [=[Add aura size settings to target and focus frame]=]},
    {GW.Enum.ChangelogType.change, [=[Ready Check reskin]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix lua error in experience bar]=]},
})

addChange("10.10.0", {
    {GW.Enum.ChangelogType.feature, [=[Added option to change unitframe reaction colors]=]},
    {GW.Enum.ChangelogType.feature, [=[Re-enabled short value prefix style and decimal length settings for Retail health values]=]},
    {GW.Enum.ChangelogType.feature, [=[Added Class Totems settings for enabling/disabling the bar, button size and button spacing]=]},
    {GW.Enum.ChangelogType.feature, [=[Added Stance Bar settings for button size, button spacing, alpha and mouseover fade]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Todooloo itegration]=]},
})


addChange("10.9.1", {
    {GW.Enum.ChangelogType.change, [=[Codex Addon support added]=]},
})

addChange("10.9.0", {
    {GW.Enum.ChangelogType.feature, [=[Added movable party frames with new spacing and horizontal/vertical layout options]=]},
    {GW.Enum.ChangelogType.feature, [=[Added automatic Objectives Tracker collapsing with separate options for Mythic+/Challenge Mode, Raid, Party, Delve and Combat]=]},
    {GW.Enum.ChangelogType.feature, [=[Added Objectives Tracker options for Supertracked Quest to Top, Show Completed Objectives and Compact Mode]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to change Objectives Tracker container order]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to change grid class order sorting]=]},
    {GW.Enum.ChangelogType.feature, [=[Added raid aura indicator settings for size, bar width and stack count visibility]=]},
    {GW.Enum.ChangelogType.feature, [=[Added titles to TBC]=]},
    {GW.Enum.ChangelogType.change, [=[Update Damage Meter skin]=]},
})

addChange("10.8.2", {
    {GW.Enum.ChangelogType.bug, [=[More secrets]=]},
    {GW.Enum.ChangelogType.bug, [=[Classic hero panel works again]=]},
})

addChange("10.8.1", {
    {GW.Enum.ChangelogType.bug, [=[More 12.0.5 secrets]=]},
})

addChange("10.8.0", {
    {GW.Enum.ChangelogType.change, [=[Added per-grid Private Auras size settings for Raid, Raid 10, Raid 25, Maintank and Party grids]=]},
    {GW.Enum.ChangelogType.change, [=[Added Narcissus Achievement Frame support for achievements opened from the Objectives Tracker]=]},
    {GW.Enum.ChangelogType.change, [=[Improved UI responsiveness by reducing frequent update loops across the global update handler, micro menu, minimap, quest compass and 5-second rule timer]=]},
    {GW.Enum.ChangelogType.change, [=[Added smoother character panel transitions across Mainline, Classic, TBC, Wrath and Mists and centralized the shared character window animation handling]=]},
    {GW.Enum.ChangelogType.change, [=[Refactored watched bag currency displays in Mainline and Mists to use shared currency slot templates]=]},
    {GW.Enum.ChangelogType.change, [=[Reworked Immersive Questing and added new customization options]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed an Objectives notification taint error caused by protected (secret) text comparisons]=]},
})

addChange("10.7.0", {
    {GW.Enum.ChangelogType.feature, [=[Added bag and bank slot spacing controls (X/Y) with shared icon size + spacing settings across Mainline, Classic, TBC and Mists]=]},
    {GW.Enum.ChangelogType.feature, [=[Delve Scenario header now displays the remaining Nemesis enemies.]=]},
    {GW.Enum.ChangelogType.change, [=[Updated bag and bank frame sizing to keep consistent right-side padding independent from slot spacing]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Scenario tracker update handling: multiple rapid event triggers are now merged into a single layout refresh per frame to prevent duplicate updates and reduce UI jitter]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Quest tracker update handling: UpdateLayout and PartialUpdate are now queued and merged per frame to avoid duplicate refreshes and reduce UI jitter]=]},
    {GW.Enum.ChangelogType.change, [=[Improved objective notification text formatting: progress values like 2/12 are now kept visible for world and bonus objectives]=]},
    {GW.Enum.ChangelogType.change, [=[Improved objective notification visuals: smoother icon/progress transitions plus hover blend feedback for clearer focus]=]},
    {GW.Enum.ChangelogType.change, [=[Added a Retail-only "Private Auras" toggle for grid debuffs in raid layouts (including maintank and party grid)]=]},
    {GW.Enum.ChangelogType.change, [=[Updated bag and bank settings (Mainline/Classic/TBC/Mists): replaced Compact Icons toggle with a shared icon-size slider and centralized bag item size normalization/configuration]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed a chat formatting error that could trigger "invalid option in `format`" when messages contained percent signs (%)]=]},
})

addChange("10.6.2", {
    {GW.Enum.ChangelogType.bug, [=[Temporarily disabled Grid aura timers]=]},
})

addChange("10.6.1", {
    {GW.Enum.ChangelogType.bug, [=[Removed scenario debug print output]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Unit Frame Lua error for non-player classes]=]},
    {GW.Enum.ChangelogType.change, [=[Updated scenario handling to use the current API flow]=]},
})

addChange("10.6.0", {
    {GW.Enum.ChangelogType.feature, [=[Added class power anchor modes: Default, Center, Left and Right]=]},
    {GW.Enum.ChangelogType.feature, [=[Added class power settings: anchor X offset, anchor Y offset and custom resource bar gap]=]},
    {GW.Enum.ChangelogType.feature, [=[Added custom resource bar side option: Auto, Left, Right]=]},
    {GW.Enum.ChangelogType.feature, [=[Added minimap setting to always show the AddOn flyout button]=]},
    {GW.Enum.ChangelogType.feature, [=[Added minimap behavior to show a single AddOn button directly when flyout is not forced]=]},
    {GW.Enum.ChangelogType.feature, [=[Added setting to animate micro menu notification icons]=]},
    {GW.Enum.ChangelogType.change, [=[Added EN/DE localization and descriptions for the new class power settings]=]},
    {GW.Enum.ChangelogType.change, [=[Refactored class power anchor handling to use shared helpers]=]},
    {GW.Enum.ChangelogType.change, [=[Improved class power sub-frame alignment for non-default anchors]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Demon Hunter and Brewmaster defaultResourceBar anchoring]=]},
    {GW.Enum.ChangelogType.change, [=[Improved overlap handling for custom resource bars in CENTER mode]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Warlock shard and shardFragment anchoring with side settings]=]},
    {GW.Enum.ChangelogType.change, [=[Mail skin layout now switches between compact and expanded widths based on visible right pane content]=]},
    {GW.Enum.ChangelogType.change, [=[Refactored mail compose/open handlers and cleanup helpers to reduce duplicated UI logic]=]},
    {GW.Enum.ChangelogType.change, [=[Moved "Sell junk automatically" from bag-specific menus to General settings near Auto Repair]=]},
    {GW.Enum.ChangelogType.change, [=[Centralized auto-sell junk initialization to run SetupVendorJunk once globally]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Settings Overview Credits layout with section icons and two-column names]=]},
    {GW.Enum.ChangelogType.change, [=[Improved Settings Overview changelog scroll growth behavior with smooth post-drag animation]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed mail inbox bottom button vertical alignment]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed mail open view scroll area sizing and scrollbar spacing]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed mail separator visibility and sizing in compact/expanded modes]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed tooltip taint from comparing secret class text values (classLine:GetText)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed scenario event timer showing in excluded zones (for example Stormarion Assault area)]=]},
})

addChange("10.5.1", {
    {GW.Enum.ChangelogType.bug, [=[Buggrabber integration]=]},
})

addChange("10.5.0", {
    {GW.Enum.ChangelogType.feature, [=[Added Midnight event tracker to worldmap]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to show spell icons to the floating combat text (classic)]=]},
    {GW.Enum.ChangelogType.change, [=[Hide druid mana in none related forms and specs (Retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix GMOTD taint]=]},
})

addChange("10.4.1", {
    {GW.Enum.ChangelogType.bug, [=[Loading issue on none retail clients]=]},
})

addChange("10.4.0", {
    {GW.Enum.ChangelogType.feature, [=[Add aura indicator back to retail, only for whitelisted spells]=]},
    {GW.Enum.ChangelogType.feature, [=[Damage Meter skin (retail)]=]},
    {GW.Enum.ChangelogType.change, [=[Tooltips updates]=]},
    {GW.Enum.ChangelogType.bug, [=[Class color issue on grids]=]},
})

addChange("10.3.2", {
    {GW.Enum.ChangelogType.bug, [=[Retail aura error]=]},
})

addChange("10.3.1", {
    {GW.Enum.ChangelogType.bug, [=[Some chat issues]=]},
    {GW.Enum.ChangelogType.bug, [=[Coloring issues]=]},
    {GW.Enum.ChangelogType.bug, [=[Experiencebar repuration tracking]=]},
    {GW.Enum.ChangelogType.bug, [=[Objectives tracker error]=]},
})

addChange("10.3.0", {
    {GW.Enum.ChangelogType.feature, [=[Add option to change unitframe healtbar texture]=]},
    {GW.Enum.ChangelogType.feature, [=[Add option ot add Healtglobe spacing to not manage actionsbars (Retail)]=]},
    {GW.Enum.ChangelogType.feature, [=[Added own chat command history]=]},
    {GW.Enum.ChangelogType.change, [=[Tooltips updates]=]},
    {GW.Enum.ChangelogType.change, [=[Color handling refactor]=]},
    {GW.Enum.ChangelogType.change, [=[Update TBC advanced stats]=]},
    {GW.Enum.ChangelogType.bug, [=[Grid buff handling on none retail clients]=]},
    {GW.Enum.ChangelogType.bug, [=[More bug fixes]=]},
})

addChange("10.2.2", {
    {GW.Enum.ChangelogType.bug, [=[Fix lua error with housing]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix CD Manager Skin, which can cause that the CD Manager was disapearing]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix worldmap skin]=]},
})

addChange("10.2.1", {
    {GW.Enum.ChangelogType.bug, [=[More chat secrets]=]},
    {GW.Enum.ChangelogType.bug, [=[Grid color error]=]},
    {GW.Enum.ChangelogType.bug, [=[Equipment manager item level]=]},
    {GW.Enum.ChangelogType.bug, [=[Vehicle leave button on TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Missing widgets on TBC and Mists]=]},
    {GW.Enum.ChangelogType.bug, [=[PvP UI fixes]=]},
    {GW.Enum.ChangelogType.change, [=[Grid buffs can be disabled (retail)]=]},
})

addChange("10.2.0", {
    {GW.Enum.ChangelogType.feature, [=[Added all new aura filter options to grids (retail)]=]},
    {GW.Enum.ChangelogType.feature, [=[Added party pet grid]=]},
    {GW.Enum.ChangelogType.feature, [=[Added new aura filter options to target unitframe]=]},
    {GW.Enum.ChangelogType.bug, [=[More secrets with 12.0.1]=]},
})

addChange("10.1.0", {
    {GW.Enum.ChangelogType.feature, [=[Added bar size settings to: Targetframe, Target of targetframe, Focusframe, Target of focusframe and playerframe]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to change chatbubble size]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to toggle the dodgebar]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to toggle the skyridingbar]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to anchor the classpower bar to center to have them alligned when using profile on different characters]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to show keybinds only on used slots]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option for a rectangle minimap (Read the setting notes)]=]},
    {GW.Enum.ChangelogType.change, [=[Gear manager: Gears can now be draged to the actionbars]=]},
    {GW.Enum.ChangelogType.change, [=[ Dodgebar, skyridingbar and player ressourcebars now fades with player frame)]=]},
    {GW.Enum.ChangelogType.bug, [=[Some more secrets (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Grid range fader is working again]=]},
    {GW.Enum.ChangelogType.bug, [=[Raidmarkers are now showing correclty]=]},
    {GW.Enum.ChangelogType.bug, [=[Many more fixes]=]},
})

addChange("10.0.5", {
    {GW.Enum.ChangelogType.bug, [=[Gamemenu skin on TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Aura tooltip works again]=]},
    {GW.Enum.ChangelogType.bug, [=[Chatframe secret value]=]},
    {GW.Enum.ChangelogType.bug, [=[Forbidden tooltips]=]},
    {GW.Enum.ChangelogType.bug, [=[Socal frame lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Frame fader fixes]=]},
    {GW.Enum.ChangelogType.bug, [=[Raid target fix]=]},
})

addChange("10.0.4", {
    {GW.Enum.ChangelogType.change, [=[Added grid aura filter options for retail, that are all blizzard allows at the moment]=]},
    {GW.Enum.ChangelogType.bug, [=[Totembar error on none Retail clients]=]},
    {GW.Enum.ChangelogType.bug, [=[Grid backgorund on none Retail clients]=]},
})

addChange("10.0.3", {
    {GW.Enum.ChangelogType.bug, [=[Tooltip error on TBC]=]},
})

addChange("10.0.2", {
    {GW.Enum.ChangelogType.bug, [=[Tooltip error on TBC]=]},
})

addChange("10.0.1", {
    {GW.Enum.ChangelogType.bug, [=[Tooltip error on TBC]=]},
})

addChange("10.0.0", {
    {GW.Enum.ChangelogType.feature, [=[Midnight support]=]},
})

addChange("9.1.0", {
    {GW.Enum.ChangelogType.feature, [=[Social frame for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat frame fixes (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Questlog skin fixes (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Hide Keyring if actionbar not enabled (TBC & Era)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix minimap left click lua error (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix spellbook and talents not clickable (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix totembar lua error (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Update spellbook (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectives tracker actionbutton (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix customs classcolor on none retail clients]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix merchant skin (TBC))]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix missing auto repair text (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix not cancable player auras (TBC)]=]},
})

addChange("9.0.2", {
    {GW.Enum.ChangelogType.bug, [=[Added missing raid debuffs for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Added many TBC checks]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix tooltip (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix gossip skin (TBC)]=]},
    {GW.Enum.ChangelogType.bug, [=[Added missing minimap tracking (TBC)]=]},
})

addChange("9.0.1", {
    {GW.Enum.ChangelogType.bug, [=[Pet happines is now active on TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Questlog skin updates for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Update Honor Tab for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Many actionbar fixes for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Disable some objectives tracker modules which are not supported in TBC, like Boss frames]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix micromenu lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix chatframe lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Added missing consts for TBC]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix shaman classpowe error on TBC]=]},
})

addChange("9.0.0", {
    {GW.Enum.ChangelogType.feature, [=[TBC support]=]},
})

addChange("8.6.2", {
    {GW.Enum.ChangelogType.bug, [=[Used wrong setting for worldmap scale for era]=]},
})

addChange("8.6.1", {
    {GW.Enum.ChangelogType.bug, [=[Worldmap position and scale is not saved (era)]=]},
    {GW.Enum.ChangelogType.change, [=[FCT default style uses now a fallback from on nameplate anchor]=]},
    {GW.Enum.ChangelogType.change, [=[XP bar rework]=]},
})

addChange("8.6.0", {
    {GW.Enum.ChangelogType.feature, [=[Add option to invert multiactionbars, to follow the blizzard layout]=]},
    {GW.Enum.ChangelogType.bug, [=[Chatframe fixes]=]},
})

addChange("8.5.3", {
    {GW.Enum.ChangelogType.change, [=[Add housing micro button]=]},
    {GW.Enum.ChangelogType.bug, [=[Many chat related fixes]=]},
    {GW.Enum.ChangelogType.bug, [=[Socket skin error (Mists)]=]},
})

addChange("8.5.2", {
    {GW.Enum.ChangelogType.change, [=[Updates for 11.2.7]=]},
})

addChange("8.5.1", {
    {GW.Enum.ChangelogType.change, [=[Talent switch works again (Mists)]=]},
})

addChange("8.5.0", {
    {GW.Enum.ChangelogType.feature, [=[Added Recent Alliens tab to social panel (retail)]=]},
    {GW.Enum.ChangelogType.feature, [=[Add CD Manager skin (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix character stats lus error (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix druid mana bar in bear form]=]},
})

addChange("8.4.6", {
    {GW.Enum.ChangelogType.bug, [=[Fix era honor lua error]=]},
})

addChange("8.4.5", {
    {GW.Enum.ChangelogType.bug, [=[Fix spellbook lua error (era)]=]},
})

addChange("8.4.4", {
    {GW.Enum.ChangelogType.bug, [=[Remove not needed and outdated libs]=]},
})

addChange("8.4.3", {
    {GW.Enum.ChangelogType.bug, [=[Fix talent tooltip (era)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix rare hunter pet name error (era & mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectives tracker (mists)]=]},
})

addChange("8.4.2", {
    {GW.Enum.ChangelogType.change, [=[1.15.8 fixes]=]},
})

addChange("8.4.1", {
    {GW.Enum.ChangelogType.bug, [=[Fix Bag lua error (Era)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix PetTracker lua error (Retail)]=]},
})

addChange("8.4.0", {
    {GW.Enum.ChangelogType.feature, [=[Added option to disable micromenu module]=]},
    {GW.Enum.ChangelogType.feature, [=[Added monk stagger value to classpower bar]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Questie Map Coords error (Era & Mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix classpower 'Only show in combat' option when leaving a vehicle]=]},
    {GW.Enum.ChangelogType.change, [=[Refactor seperate bag option]=]},
    {GW.Enum.ChangelogType.change, [=[TOC update (Mists)]=]},
})

addChange("8.3.5", {
    {GW.Enum.ChangelogType.bug, [=[Fix settings dependecies tooltip]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix reset profile option]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Paladin classpower]=]},
    {GW.Enum.ChangelogType.change, [=[Add missing auctionator frame skin]=]},
    {GW.Enum.ChangelogType.change, [=[Update classpower aura handling, this should be a performace boost, if your class has a classpower based on a de/buff]=]},
})

addChange("8.3.4", {
    {GW.Enum.ChangelogType.bug, [=[Player powerbar is now correctly hidden in specific situations]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Lua error for fresh characters]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Game Menu skin issue when using ConsolePort]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed fading issue with player pet frame icon]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Lua error in Who-list]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Lua error when opening the settings menu]=]},
    {GW.Enum.ChangelogType.bug, [=[Fixed Lua error in immersive questing when required money is missing (Era & Mists)]=]},
})

addChange("8.3.3",{
    {GW.Enum.ChangelogType.bug, [=[Fix wrong classpower color for warlocks (Mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix settings lua error is UI Scale is used]=]},
})

addChange("8.3.2",{
    {GW.Enum.ChangelogType.bug, [=[Fix micromenu issue with consoleport addon]=]},
})

addChange("8.3.1",{
    {GW.Enum.ChangelogType.change, [=[Settingsframe rework, addons can now hook into it]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix TSM Loading issue]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix DB migration for old profiles]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix druid bear hud background]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix quest item not clickable (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix quest item texture too big (era)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix druid eclipsebar (mists)]=]},
})

addChange("8.3.0",{
    {GW.Enum.ChangelogType.change, [=[11.2.0 support]=]},
})

addChange("8.2.8",{
    {GW.Enum.ChangelogType.bug, [=[Fix absorb bar toggle]=]},
    {GW.Enum.ChangelogType.change, [=[Enable absorb bar toggle on Mists and Retail clients]=]},
})

addChange("8.2.7",{
    {GW.Enum.ChangelogType.bug, [=[Fix hunter classpower]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix micro stuttering while leaving combat (retail)]=]},
})

addChange("8.2.6",{
    {GW.Enum.ChangelogType.bug, [=[Migration lua error for new users]=]},
    {GW.Enum.ChangelogType.bug, [=[GW2 Layout creation if max Account Layouts are reached (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix micromenu moving (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Copy chat / emote button not clickable (mists & era)]=]},
})

addChange("8.2.5",{
    {GW.Enum.ChangelogType.bug, [=[Fix quest sorting (era & mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix reputation text (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix classpower]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectives tracker quest item (era)]=]},
})

addChange("8.2.4",{
    {GW.Enum.ChangelogType.bug, [=[Fix warbank itemlevel (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Hide multibars during pet battle (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix target health % values]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix combopoints on target]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix minimap instance difficult indicator (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix actionbar coloring (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix title filter error (retail)]=]},
})

addChange("8.2.3",{
    {GW.Enum.ChangelogType.bug, [=[Loading error]=]},
    {GW.Enum.ChangelogType.change, [=[Add more options to player de/buff settings]=]},
})

addChange("8.2.2",{
    {GW.Enum.ChangelogType.bug, [=[Bagnator skin error (Mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Objectives tracker actionbutton error (Era)]=]},
})

addChange("8.2.1",{
    {GW.Enum.ChangelogType.bug, [=[Arena frame lua error (Mists)]=]},
})

addChange("8.2.0",{
    {GW.Enum.ChangelogType.feature, [=[Add option to hide absorb bar on all unitframes]=]},
})

addChange("8.1.9",{
    {GW.Enum.ChangelogType.bug, [=[Scenario error (retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Bag sorting (Mists & Era)]=]},
})

addChange("8.1.8",{
    {GW.Enum.ChangelogType.bug, [=[Bag opening lag]=]},
    {GW.Enum.ChangelogType.bug, [=[Wrong tooltip faction (Retail)]=]},
    {GW.Enum.ChangelogType.bug, [=[Friendstooltip show correct game now]=]},
    {GW.Enum.ChangelogType.bug, [=[Spellbook tweaks (Mists)]=]},
})

addChange("8.1.7",{
    {GW.Enum.ChangelogType.bug, [=[Shadow prist orbs (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[DK runes (mists)]=]},
    {GW.Enum.ChangelogType.bug, [=[Unitframe absorb amounts (mists)]=]},
})

addChange("8.1.6",{
    {GW.Enum.ChangelogType.bug, [=[Next round of Mists fixes]=]},
})

addChange("8.1.5",{
    {GW.Enum.ChangelogType.change, [=[Added temp chi bg texture]=]},
})

addChange("8.1.4",{
    {GW.Enum.ChangelogType.bug, [=[Next round of Mists fixes]=]},
})

addChange("8.1.3",{
    {GW.Enum.ChangelogType.bug, [=[Fix issue with 8.1.2]=]},
})

addChange("8.1.2",{
    {GW.Enum.ChangelogType.bug, [=[More Mists adjustments]=]},
})

addChange("8.1.1",{
    {GW.Enum.ChangelogType.bug, [=[More Mists adjustments]=]},
})

addChange("8.1.0",{
    {GW.Enum.ChangelogType.bug, [=[Mists support]=]},
})

addChange("8.0.7",{
    {GW.Enum.ChangelogType.bug, [=[Fix collection tracking collapse (retail)]=]},
})

addChange("8.0.6",{
    {GW.Enum.ChangelogType.bug, [=[Some more fixes for all versions]=]},
})

addChange("8.0.5",{
    {GW.Enum.ChangelogType.bug, [=[Fix target level color (era & cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix unit level at tooltip (era)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix aura tooltip (era & cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix mirror timer (era & cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectives tooltip (era & cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix copying profiles)]=]},
})

addChange("8.0.4",{
    {GW.Enum.ChangelogType.bug, [=[Fix microbar moving (cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Readd spellbook and talent setting (cata)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix skyridingbar (retail)]=]},
})

addChange("8.0.3",{
    {GW.Enum.ChangelogType.bug, [=[Fix eclips bar on era]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix micromenu moving on era and cata]=]},
})

addChange("8.0.2",{
    {GW.Enum.ChangelogType.bug, [=[Combopoint error for era and cata]=]},
})

addChange("8.0.1",{
    {GW.Enum.ChangelogType.feature, [=[Merged Retail, Era and Cata version]=]},
})

addChange("7.15.0",{
    {GW.Enum.ChangelogType.feature, [=[Added more option to unitframe fader]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to extend player powerbar hight (player unitframe)]=]},
    {GW.Enum.ChangelogType.change, [=[Add required settings to settings tooltip]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Pawn integration]=]},
})

addChange("7.14.1",{
    {GW.Enum.ChangelogType.bug, [=[Fix settings lua error]=]},
})

addChange("7.14.0",{
    {GW.Enum.ChangelogType.feature, [=[Added unitframe fader options to all unitframes]=]},
    {GW.Enum.ChangelogType.bug, [=[Raidlock error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix buff reminder]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix pawn integration]=]},
})

addChange("7.13.2",{
    {GW.Enum.ChangelogType.bug, [=[Fix issue with 7.13.1]=]},
})

addChange("7.13.1",{
    {GW.Enum.ChangelogType.bug, [=[Hero panel opens for enchants]=]},
    {GW.Enum.ChangelogType.bug, [=[Weapon enchants should now show correclty]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Pawn integration]=]},
    {GW.Enum.ChangelogType.bug, [=[Raid lock lua error]=]},
    {GW.Enum.ChangelogType.change, [=[Redo reputation frame, should load and react faster]=]},
    {GW.Enum.ChangelogType.change, [=[Add radio button texture]=]},
    {GW.Enum.ChangelogType.change, [=[Added Nightfall to objectives tracker]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
    {GW.Enum.ChangelogType.change, [=[Added 3 new widget mover to move hud mode]=]},
    {GW.Enum.ChangelogType.change, [=[Added some animations]=]},
})

addChange("7.13.0",{
    {GW.Enum.ChangelogType.feature, [=[Cooldown Manager skin]=]},
    {GW.Enum.ChangelogType.feature, [=[Add paragon indicator to reputation category list]=]},
    {GW.Enum.ChangelogType.bug, [=[PetTracker integration now work as expected]=]},
    {GW.Enum.ChangelogType.bug, [=[WQT integration now work as expected]=]},
    {GW.Enum.ChangelogType.bug, [=[Error when entering delves]=]},
    {GW.Enum.ChangelogType.change, [=[Rewritten objectives tracker, should perform much better now]=]},
    {GW.Enum.ChangelogType.change, [=[Better CLEU handling with sharing over the addon]=]},
    {GW.Enum.ChangelogType.change, [=[Much more optimization over all modules of the addon]=]},
})

addChange("7.12.1",{
    {GW.Enum.ChangelogType.change, [=[Skin tweaks]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix profile lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix FCT lua error]=]},
    {GW.Enum.ChangelogType.bug, [=[Castbar channel ticks]=]},
    {GW.Enum.ChangelogType.bug, [=[Target frame debuff settings are working again]=]},
})

addChange("7.12.0",{
    {GW.Enum.ChangelogType.bug, [=[Update for 11.1.0]=]},
})

addChange("7.11.1",{
    {GW.Enum.ChangelogType.bug, [=[Fix actionbar taint]=]},
})

addChange("7.11.0",{
    {GW.Enum.ChangelogType.feature, [=[dded option to hide target item level display]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to show Singing Socket gems]=]},
    {GW.Enum.ChangelogType.change, [=[Update auctionator skin]=]},
    {GW.Enum.ChangelogType.bug, [=[Repuration error]=]},
    {GW.Enum.ChangelogType.bug, [=[Notification tooltip]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix inverted statusbar]=]},
    {GW.Enum.ChangelogType.bug, [=[Party frame auras can stuck sometimes]=]},
})

addChange("7.10.0",{
    {GW.Enum.ChangelogType.feature, [=[Added Talking Head Scaler]=]},
    {GW.Enum.ChangelogType.feature, [=[Target/Focus frame bars no inverted in inverted mode]=]},
    {GW.Enum.ChangelogType.change, [=[Optimize aura handling for all unitframes]=]},
    {GW.Enum.ChangelogType.change, [=[Optimize Healthbar and Powerbar handling]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix PetTracker loading]=]},
})

addChange("7.9.3",{
    {GW.Enum.ChangelogType.change, [=[Remove CUSTOM_CLASS_COLOR support and cahnge it to GW2 Class colors]=]},
    {GW.Enum.ChangelogType.change, [=[Add option to set number format]=]},
})

addChange("7.9.2",{
    {GW.Enum.ChangelogType.change, [=[TRP3 chat support]=]},
})

addChange("7.9.1",{
    {GW.Enum.ChangelogType.change, [=[TRP3 chat support]=]},
})

addChange("7.9.0",{
    {GW.Enum.ChangelogType.feature, [=[Added grid out of range alpha value setting]=]},
    {GW.Enum.ChangelogType.feature, [=[Added custom class color support]=]},
    {GW.Enum.ChangelogType.change, [=[Update more dropdowns]=]},
    {GW.Enum.ChangelogType.change, [=[Use local number delimiter]=]},
    {GW.Enum.ChangelogType.change, [=[11.0.7 changes]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix PetTracker integration]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Blizzard mirror timer not shown]=]},
    {GW.Enum.ChangelogType.bug, [=[Setting search works again]=]},
})

addChange("7.8.0",{
    {GW.Enum.ChangelogType.feature, [=[Add option to hook profiles to a spec. This will switch the profile on spec switch]=]},
    {GW.Enum.ChangelogType.feature, [=[Add todoloo support for GW2 Objectives tracker]=]},
    {GW.Enum.ChangelogType.feature, [=[Add searchbox for player titles]=]},
    {GW.Enum.ChangelogType.feature, [=[Add slash command to clear tracked but already earned achievements (blizzard bug): /gw2 clear achievements]=]},
    {GW.Enum.ChangelogType.feature, [=[Add option to change profile icons]=]},
    {GW.Enum.ChangelogType.feature, [=[Add TRP3 support for GW2 chatbubbles]=]},
    {GW.Enum.ChangelogType.change, [=[Added fraction icons to the guild datatext]=]},
    {GW.Enum.ChangelogType.change, [=[Change all dropdown elements to new blizzard ui system]=]},
    {GW.Enum.ChangelogType.change, [=[Allow max 4 watched tokens with gw2 bags enabled]=]},
    {GW.Enum.ChangelogType.bug, [=[Objectives tracker bonus step names]=]},
    {GW.Enum.ChangelogType.bug, [=[Achievement skin scroll height]=]},
    {GW.Enum.ChangelogType.bug, [=[Grid aura indicators now only shows player auras]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix dodgebar for some classes]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectives tracker loading order]=]},
})

addChange("7.7.2",{
    {GW.Enum.ChangelogType.bug, [=[Guild data info lua error]=]},
    {GW.Enum.ChangelogType.change, [=[Skin updates]=]},
    {GW.Enum.ChangelogType.change, [=[Guild data info text]=]},
    {GW.Enum.ChangelogType.change, [=[Stackcount setting]=]},
})

addChange("7.7.1",{
    {GW.Enum.ChangelogType.change, [=[Add Dracthyr fraction to tooltip]=]},
    {GW.Enum.ChangelogType.change, [=[Add stackcount to tooltip]=]},
    {GW.Enum.ChangelogType.change, [=[Changes for 11.0.5]=]},
})

addChange("7.7.0",{
    {GW.Enum.ChangelogType.feature, [=[Option to copy a single chat line]=]},
    {GW.Enum.ChangelogType.feature, [=[Option to show chat history]=]},
    {GW.Enum.ChangelogType.feature, [=[Option to show channel ticks on castbar]=]},
    {GW.Enum.ChangelogType.feature, [=[Option to control the grid name update frequence to save some fps]=]},
    {GW.Enum.ChangelogType.feature, [=[Add mastery buff to raid buff reminder]=]},
    {GW.Enum.ChangelogType.change, [=[Jailers tower error]=]},
    {GW.Enum.ChangelogType.change, [=[Social frame lua error]=]},
    {GW.Enum.ChangelogType.change, [=[Player castbar sometimes stuck on screen]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
    {GW.Enum.ChangelogType.change, [=[Add warband reputation indicator]=]},
})

addChange("7.6.0",{
    {GW.Enum.ChangelogType.feature, [=[Add option to shorten healtglobe shield values]=]},
    {GW.Enum.ChangelogType.feature, [=[Add option to hide player frame at party grid]=]},
    {GW.Enum.ChangelogType.feature, [=[Add option to hide class icons at grids, if no class color is used]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix drawn layer of lfg accept button]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix BigWigs integration]=]},
    {GW.Enum.ChangelogType.change, [=[Add Monk hero talent to dodgebar]=]},
    {GW.Enum.ChangelogType.change, [=[Added theater event timer bar to objectives tracker]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
})

addChange("7.5.0",{
    {GW.Enum.ChangelogType.feature, [=[Add option to shorten values, like health values or damage text]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix new font settings]=]},
    {GW.Enum.ChangelogType.bug, [=[fix LSM with new fonts]=]},
})

addChange("7.4.0",{
    {GW.Enum.ChangelogType.feature, [=[New Font system
        - You can now select between multiple different font styles
        - You can select your own fonts for texts and header texts
        - You can adjust the font size for: Big Headers, Header, Normal and Small texts

        - To select the font like before this update, use 'GW2 Legacy']=]},
    {GW.Enum.ChangelogType.feature, [=[Tooltips gets font size option for all 3 types]=]},
    {GW.Enum.ChangelogType.feature, [=[Added TWW events to the event tracker]=]},
    {GW.Enum.ChangelogType.feature, [=[Added auction house skin]=]},
    {GW.Enum.ChangelogType.feature, [=[Added fx animation to the dynamic hud (not all classes yet)]=]},
    {GW.Enum.ChangelogType.feature, [=[Added remaning live to delve tracker]=]},
    {GW.Enum.ChangelogType.feature, [=[Find an small easter agg with the GW2 settings splash screen]=]},
    {GW.Enum.ChangelogType.change, [=[Add DK hero talent to dodgebar]=]},
    {GW.Enum.ChangelogType.change, [=[Update some textures]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix barber shop skin]=]},
})

addChange("7.3.0",{
    {GW.Enum.ChangelogType.feature, [=[Delves support for objectives tracker]=]},
    {GW.Enum.ChangelogType.feature, [=[Added group progress to objectives tooltip]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
    {GW.Enum.ChangelogType.bug, [=[Objectives tracker auto turn in quests]=]},
    {GW.Enum.ChangelogType.bug, [=[Totem tracker should work again]=]},
})

addChange("7.2.0",{
    {GW.Enum.ChangelogType.feature, [=[Talent frame skin]=]},
    {GW.Enum.ChangelogType.feature, [=[Tooltip Item Count now has options Include Reagents and Include Warband]=]},
    {GW.Enum.ChangelogType.feature, [=[Keybind support for immersive questing]=]},
    {GW.Enum.ChangelogType.feature, [=[Keybind support for gossip skin]=]},
    {GW.Enum.ChangelogType.feature, [=[Stancebar can now be disabled]=]},
    {GW.Enum.ChangelogType.feature, [=[DK runes now get sorted based on there progress]=]},
    {GW.Enum.ChangelogType.feature, [=[Add timer to tracked achievements]=]},
    {GW.Enum.ChangelogType.feature, [=[New immersive questing backgrounds for TWW]=]},
    {GW.Enum.ChangelogType.change, [=[Chat frame alert color is now saved per character]=]},
    {GW.Enum.ChangelogType.change, [=[Update some skins]=]},
    {GW.Enum.ChangelogType.change, [=[Update imported debuffs]=]},
    {GW.Enum.ChangelogType.bug, [=[EJ skin error]=]},
    {GW.Enum.ChangelogType.bug, [=[Raid frame ignored auras works again]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix GW2_Layout creation process]=]},
})

addChange("7.1.0",{
    {GW.Enum.ChangelogType.feature, [=[Added option to skin blizzards default actionbars
        That function disabled our managed actionbars and there hooked features]=]},
    {GW.Enum.ChangelogType.feature, [=[Adventuremap skin]=]},
    {GW.Enum.ChangelogType.bug, [=[Objectives tracker actionbutton works again]=]},
    {GW.Enum.ChangelogType.bug, [=[Error handler shows only GW2 errors]=]},
    {GW.Enum.ChangelogType.bug, [=[M+ progess counter should show correect % again (raw value is not possible atm)]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix minimap lua error]=]},
    {GW.Enum.ChangelogType.change, [=[Added TRP3 tooltips support]=]},
    {GW.Enum.ChangelogType.change, [=[Immersive Question changes and improvements]=]},
})

addChange("7.0.2",{
    {GW.Enum.ChangelogType.change, [=[Added self reading animation to immersive questing]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix error handler]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objective tracker action button handling]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix event objectives click functions]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix currency transfer taint error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix ouf range indicator]=]},
})

addChange("7.0.1",{
    {GW.Enum.ChangelogType.bug, [=[First round of fixes]=]},
})

addChange("7.0.0",{
    {GW.Enum.ChangelogType.change, [=[Update for TWW]=]},
})

addChange("6.14.10",{
    {GW.Enum.ChangelogType.bug, [=[Show character item info now works correctly]=]},
    {GW.Enum.ChangelogType.change, [=[Export some api]=]},
})

addChange("6.14.9",{
    {GW.Enum.ChangelogType.change, [=[Export some api]=]},
})

addChange("6.14.8",{
    {GW.Enum.ChangelogType.change, [=[Update toc]=]},
})

addChange("6.14.7",{
    {GW.Enum.ChangelogType.change, [=[Prepare for 10.2.7]=]},
})

addChange("6.14.6",{
    {GW.Enum.ChangelogType.bug, [=[Fix GW2 slash commands]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix merchant frame next/prev page button position]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix lua error if our minimap is disableds]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix character itemlevel was not shown]=]},
})

addChange("6.14.5",{
    {GW.Enum.ChangelogType.bug, [=[Party frame visibility]=]},
})

addChange("6.14.4",{
    {GW.Enum.ChangelogType.bug, [=[Tooltip M+ lua error]=]},
})

addChange("6.14.3",{
    {GW.Enum.ChangelogType.bug, [=[Party visibility]=]},
})

addChange("6.14.2",{
    {GW.Enum.ChangelogType.change, [=[Update for 10.2.6]=]},
})

addChange("6.14.1",{
    {GW.Enum.ChangelogType.bug, [=[Fix details profile]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix player debuff show wrong icon texture]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix gossip skin text height]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix small unitframe height]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix ToT mover]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix playerframe level up icon]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix objectiv tracker hover not showing all details]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix creating new profile]=]},

    {GW.Enum.ChangelogType.change, [=[Update merchant skin]=]},
    {GW.Enum.ChangelogType.change, [=[Change castbar mover frame beased on details option]=]},
    {GW.Enum.ChangelogType.change, [=[Added Masque actionbutton skin]=]},
})

addChange("6.14.0", {
    {GW.Enum.ChangelogType.feature, [=[Added Big Dig event timer]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to change pulltimer seconds]=]},

    {GW.Enum.ChangelogType.bug, [=[Raidframes name overlapping]=]},
    {GW.Enum.ChangelogType.bug, [=[Chat install process]=]},
    {GW.Enum.ChangelogType.bug, [=[Alt player background setting]=]},
    {GW.Enum.ChangelogType.bug, [=[Colorpicker error]=]},
})

addChange("6.13.3",{
    {GW.Enum.ChangelogType.bug, [=[Remove print statement]=]},
})

addChange("6.13.2",{
    {GW.Enum.ChangelogType.bug, [=[Fix profile page error]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix db migration error]=]},
    {GW.Enum.ChangelogType.bug, [=[Handle evoker soar correct]=]},
})

addChange("6.13.1",{
    {GW.Enum.ChangelogType.bug, [=[Fix error a profile rename]=]},
})

addChange("6.13.0",{
    {GW.Enum.ChangelogType.feature, [=[Switch to a new database format to better handle profiles. That requires a reload after the first login on each character.]=]},
    {GW.Enum.ChangelogType.feature, [=[Added right click function to the minimaps expansion icon to show also the landing pages from previous addons]=]},
    {GW.Enum.ChangelogType.feature, [=[Added animated statusbars to the pet frame]=]},
    {GW.Enum.ChangelogType.feature, [=[Added copy/paste function to colorpicker]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to disable objectives statusbars to have a more compact objectives tracker]=]},

    {GW.Enum.ChangelogType.change, [=[Some more settings does not requires a reload]=]},

    {GW.Enum.ChangelogType.bug, [=[Fix stancebar error. You can now use the button in combat again]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix worldmap event tracker container size]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix tank frame middle icon]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix auraindicators updating]=]},
    {GW.Enum.ChangelogType.bug, [=[GW2 setting window is now moveable]=]},
})


addChange("6.12.0",{
    {GW.Enum.ChangelogType.feature, [=[Added new paladin classpower texture and animation]=]},
    {GW.Enum.ChangelogType.feature, [=[Added new arms warrior classpower]=]},
    {GW.Enum.ChangelogType.feature, [=[Update GW2 boss frames, they are now unitframes]=]},
    {GW.Enum.ChangelogType.feature, [=[Added options to toggle grid rol icons, tank icons and leader icons]=]},

    {GW.Enum.ChangelogType.change, [=[Adjust grid out of range alpha value]=]},
    {GW.Enum.ChangelogType.change, [=[Update grid to work again with OmniCD]=]},

    {GW.Enum.ChangelogType.bug, [=[Fix PP mode get saved correctly]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix move HUD grid]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix immersive Questing taint issue]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix arena frame lua errors]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix classpower error in combat]=]},
})

addChange("6.11.1",{
    {GW.Enum.ChangelogType.bug,[=[Correct LEMO integration which was causing an lua error during installation process]=]},
    {GW.Enum.ChangelogType.bug,[=[Tweak Event Timer height]=]},
})

addChange("6.11.0",{
    {GW.Enum.ChangelogType.feature, [=[Redo all grids: Party, Raid, Raid Pet]=]},
    {GW.Enum.ChangelogType.feature, [=[Grids are now secure and can update during combat]=]},
    {GW.Enum.ChangelogType.feature, [=[Added new grids:
        - Maintank
        - Raid 10
        - Raid 25
        - Raid 40]=]},
    {GW.Enum.ChangelogType.feature, [=[Raid grids switch automaticly between the 3 raid grids, based on the number of players at the raid]=]},
    {GW.Enum.ChangelogType.feature, [=[Added new grouping and sorting settings to all grids:
        - Group by: Role, Class, Group, Name, Index
        - Sort direction
        - Sortmethode: Name, Index
        - Raidwaid sorting: If disabled the grouping and sorting settings are applyed per raid group]=]},
    {GW.Enum.ChangelogType.feature, [=[All grids have there individual settings (Raid 10, Raid 25, Raid 40, Maintank, Raid Pet, Group)]=]},
    {GW.Enum.ChangelogType.feature, [=[Added Superbloom event timer to worldmap]=]},
    {GW.Enum.ChangelogType.feature, [=[Added options to change the worldmap coordinats lable]=]},
    {GW.Enum.ChangelogType.feature, [=[Added option to hide classpower bar outside of combat]=]},

    {GW.Enum.ChangelogType.change, [=[Update for 10.2.0]=]},
    {GW.Enum.ChangelogType.change, [=[Update RAF skin]=]},
    {GW.Enum.ChangelogType.change, [=[Update Time Manager skin]=]},
    {GW.Enum.ChangelogType.change, [=[Added back right click option on bags]=]},
    {GW.Enum.ChangelogType.change, [=[Added S3 raid debuffs]=]},
    {GW.Enum.ChangelogType.change, [=[Adjust damage text animations]=]},
    {GW.Enum.ChangelogType.change, [=[Update TaintLess]=]},

    {GW.Enum.ChangelogType.bug, [=[Fix ready check skin]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix blurr on raid warning font]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix Pet Tracker and WQT Anchor points]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix travler log header stucking after tracking activity is completed]=]},
    {GW.Enum.ChangelogType.bug, [=[Fix some taints]=]},
})

addChange("6.10.1",{
    {GW.Enum.ChangelogType.bug,[=[10.1.7 fixes]=]},
})

addChange("6.10.0",{
    {GW.Enum.ChangelogType.bug,[=[Added evoker ebon might bar]=]},
})

addChange("6.9.2",{
    {GW.Enum.ChangelogType.bug,[=[Fix an actionbars issue which can crash the client]=]},
})

addChange("6.9.1",{
    {GW.Enum.ChangelogType.bug,[=[More 10.1.5 related fixes]=]},
})

addChange("6.9.0",{
    {GW.Enum.ChangelogType.feature,[=[Added font settings for GW2 floating combat text]=]},
    {GW.Enum.ChangelogType.change,[=[Update for 10.1.5]=]},
})

addChange("6.8.2",{
    {GW.Enum.ChangelogType.bug,[=[Fix druid little manabar in cat form with player frame in target frame style]=]},
    {GW.Enum.ChangelogType.bug,[=[Try to handle bags correctly for accounts with not 2FA]=]},
})

addChange("6.8.1",{
    {GW.Enum.ChangelogType.bug,[=[Fix buff/debuff auto anchor]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix buff/debuff max wraps setting]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix socket skin lua error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix Pet Tracker integration]=]},

    {GW.Enum.ChangelogType.change,[=[Added LibUIDropDownMenu to prevent drop down taints]=]},
    {GW.Enum.ChangelogType.change,[=[Added Diablo 4 to friends data info]=]},
    {GW.Enum.ChangelogType.change,[=[Update LibEditModeOverride]=]},
})

addChange("6.8.0",{
    {GW.Enum.ChangelogType.feature,[=[Added option to adjust player de/buff horizontal and vertical spacing]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to adjust player de/buff max wrap of lines]=]},
    {GW.Enum.ChangelogType.feature,[=[Added support for the add PetTracker: Now included at GW2 objectives]=]},
    {GW.Enum.ChangelogType.feature,[=[Added evoker bleeding support]=]},

    {GW.Enum.ChangelogType.bug,[=[Avoid possible tooltip taint]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix casting bar lua error at pvp with an evoker]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix rare migration process issue]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix M+ dungeon icon border color at the lfg frame]=]},

    {GW.Enum.ChangelogType.change,[=[Tweak some hover textures]=]},
    {GW.Enum.ChangelogType.change,[=[Cooldown round numbers are more accurate now]=]},
})

addChange("6.7.3",{
    {GW.Enum.ChangelogType.bug,[=[Fix friends frame lua error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix encounterjornal taint issue]=]},
})

addChange("6.7.2",{
    {GW.Enum.ChangelogType.bug,[=[Fix player frame in target frame style]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix immersive questing error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix healtglobe error]=]},
})

addChange("6.7.1",{
    {GW.Enum.ChangelogType.bug,[=[Fix hero panel anchor error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix party frame healthtext error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix hero panel item info error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix target castingbar texture]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix pet grid error]=]},

    {GW.Enum.ChangelogType.change,[=[Handle addon compartment button and add a toggle to hide that button]=]},
})

addChange("6.7.0",{
    {GW.Enum.ChangelogType.feature,[=[Added private aura support)]=]},
    {GW.Enum.ChangelogType.feature,[=[Redo the statusbars and add custom animations to the classpower and ressource bars]=]},

    {GW.Enum.ChangelogType.bug,[=[Added passive talents back to spellbook]=]},
    {GW.Enum.ChangelogType.bug,[=[Tweak vignett alerts to not spam]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix talent micro button taint error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix bank taint issue]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix vigor bar hidding]=]},

    {GW.Enum.ChangelogType.change,[=[Update for 10.1]=]},
    {GW.Enum.ChangelogType.change,[=[Make achievement frame movable]=]},
    {GW.Enum.ChangelogType.change,[=[Update S2 debuffs]=]},
})

addChange("6.6.1",{
    {GW.Enum.ChangelogType.bug,[=[Fix rare lua error during open the worldmap with active worldmap skin]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix issue were is was impossible to buy bank slots]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix macro and gear manager icon selection]=]},

    {GW.Enum.ChangelogType.change,[=[Added tooltips to equipment selection mode]=]},
    {GW.Enum.ChangelogType.change,[=[GW2 achievement frame skin is now compatible with 'Krowi's Achievement Filter' (requires version 55.0 and higher)]=]},
})

addChange("6.6.0",{
    {GW.Enum.ChangelogType.feature,[=[Added 2 new damage text styles: Stacking and Classic (with anchor to nameplats or center of the screen)]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to show healing numbers for these 2 new styles (classic only with anchor to the center of the screen)]=]},

    {GW.Enum.ChangelogType.bug,[=[Fix move hud error if the frames gets moved back to it default position]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix raid frame summon and resurrection icon]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix friends data info tooltip]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix worldmap drop-down position]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix objectives tracker group finder icon]=]},

    {GW.Enum.ChangelogType.change,[=[Changes for 10.0.7]=]},
    {GW.Enum.ChangelogType.change,[=[Update spell flyout skin]=]},
})


addChange("6.5.1",{
    {GW.Enum.ChangelogType.bug,[=[Fixed memory leak cause by channeling spells]=]},
})

addChange("6.5.0",{
    {GW.Enum.ChangelogType.feature,[=[Added option to add a new micromenu icon to show event timers at the tooltip]=]},

    {GW.Enum.ChangelogType.bug,[=[Fix copy chat corloring]=]},
    {GW.Enum.ChangelogType.bug,[=[Hopefully fix ui flickering]=]},

    {GW.Enum.ChangelogType.change,[=[Show micromenu notification also if the micromenu is fade out]=]},
})

addChange("6.4.1",{
    {GW.Enum.ChangelogType.bug,[=[Create the GW2_Layout only if it does not exist]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix an issue where the default target of target/focus frame is not visible if our target/focus module is turned off]=]},
})

addChange("6.4.0",{
    {GW.Enum.ChangelogType.feature,[=[Added Trade Post skin]=]},

    {GW.Enum.ChangelogType.change,[=[Restructur settings, to make some settings easier to find]=]},

    {GW.Enum.ChangelogType.bug,[=[Talent micro button tooltip is hidding corret now]=]},
    {GW.Enum.ChangelogType.bug,[=[Correct monthly activity tracker issues]=]},
    {GW.Enum.ChangelogType.bug,[=[Correct recipe tracking issues]=]},
    {GW.Enum.ChangelogType.bug,[=[Performance improvements]=]},
})
addChange("6.3.1",{
    {GW.Enum.ChangelogType.feature,[=[Added workorder indicator to micromenu]=]},

    {GW.Enum.ChangelogType.change,[=[Move "new mail" indicator to micromenu]=]},

    {GW.Enum.ChangelogType.bug,[=[Performance improvements]=]},
})
addChange("6.2.2",{
    {GW.Enum.ChangelogType.change,[=[Fixes for 10.0.5]=]},
})
addChange("6.2.1",{
    {GW.Enum.ChangelogType.bug,[=[Fix ElvUI micro menu error]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix ElvUI actionbar lua error if our actionbars are disabled]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix ElvUI battle.net frame error if both module are enabled]=]},
})
addChange("6.2.0",{
    {GW.Enum.ChangelogType.feature,[=[Dragon Riding HUD background has been added]=]},
    {GW.Enum.ChangelogType.feature,[=[Vigor has been moved to the Dodge bar]=]},
    {GW.Enum.ChangelogType.feature,[=[Added new achievement skin]=]},
    {GW.Enum.ChangelogType.feature,[=[Added new gossip skin]=]},
    {GW.Enum.ChangelogType.feature,[=[Added fish nets timers to world map]=]},
    {GW.Enum.ChangelogType.feature,[=[Added cooking event timer to scenario tracker]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to show enchants and gems on gw2 character panel]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to flash taskbar on world event reminder]=]},
    {GW.Enum.ChangelogType.feature,[=[Added group info to premade group list and group tooltips]=]},

    {GW.Enum.ChangelogType.change,[=[Update chat bubbles]=]},
    {GW.Enum.ChangelogType.change,[=[Update Move HUD textures]=]},
    {GW.Enum.ChangelogType.change,[=[Add filters to Move HUD mode]=]},
    {GW.Enum.ChangelogType.change,[=[Added char counter to chat editbox]=]},
    {GW.Enum.ChangelogType.change,[=[The info block in Mythic+ dungeons now shows more precise progress information]=]},

    {GW.Enum.ChangelogType.bug,[=[Fix ElvUI micro menu backdrop]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix Details settings page not opens]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix wrong data in fps tooltip]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix TomTom mini map icons moves into the addon button container]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix compass ignoring settings]=]},
})
addChange("6.1.1",{
    {GW.Enum.ChangelogType.change,[=[Aura Indicator updates:

- Evoker:
     Added Dream Breath (echo)
     Added Reversion (echo)
     Added Life Bind]=]},
  {GW.Enum.ChangelogType.change,[=[Update Talent Micro Button tooltip]=]},

    {GW.Enum.ChangelogType.bug,[=[Fix game freezes with scenario tracker]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix actionbar taint on spec switch]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix HUD background setting]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix HUD border setting]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix tooltip hide in combat setting]=]},
    {GW.Enum.ChangelogType.bug,[=[Fix tooltip healthbar setting]=]},
})
addChange("6.1.0",{
    {GW.Enum.ChangelogType.feature,[=[Added brand new settings page]=]},
    {GW.Enum.ChangelogType.feature,[=[Added Community Feast and Siege On Dragonbane Keep timer to worldmap]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to set currencies to unused]=]},
    {GW.Enum.ChangelogType.feature,[=[Added option to collapse all objective trackers in Mythic+]=]},
    {GW.Enum.ChangelogType.feature,[=[Added evoker buff to raid buff reminder]=]},

    {GW.Enum.ChangelogType.change,[=[Aura Indicator updates:

- Resto Druid:
       Added Tranquility
       Added Adaptive Swarm

- Priest:
      Added Power Infusion

- Holy Pally:
       Added Barrier of Faith]=]},
    {GW.Enum.ChangelogType.change,[=[Social panel skin has been fixed has been readded]=]},
    {GW.Enum.ChangelogType.change,[=[Update Raid Debuff Filter and cleanded up Mythic+ Affixes]=]},
    {GW.Enum.ChangelogType.change,[=[Update some raid buff reminder spells]=]},

    {GW.Enum.ChangelogType.bug,[=[Fix for auto sell taint error]=]},
    {GW.Enum.ChangelogType.bug,[=[Temp fix for extra actionbutton taint]=]},
    {GW.Enum.ChangelogType.bug,[=[Memory and performance improvements]=]},
})
addChange("6.0.10",{
    {GW.Enum.ChangelogType.bug,[=[Error on start]=]},
})
addChange("6.0.9",{
    {GW.Enum.ChangelogType.bug,[=[Restored mirror timers]=]},
})
addChange("6.0.8",{
    {GW.Enum.ChangelogType.bug,[=[Fix for memory leak]=]},
})
addChange("6.0.7",{
    {GW.Enum.ChangelogType.bug,[=[Error on start]=]},
})
addChange("6.0.6",{
    {GW.Enum.ChangelogType.bug,[=[Bank issues]=]},
    {GW.Enum.ChangelogType.bug,[=[Error on start]=]}
})
addChange("6.0.5",{
    {GW.Enum.ChangelogType.bug,[=[Minimap lua error]=]},
    {GW.Enum.ChangelogType.bug,[=[Bag taint]=]}
})
addChange("6.0.4",{
    {GW.Enum.ChangelogType.bug,[=[Fix some more taint issues]=]},
})
addChange("6.0.3",{
    {GW.Enum.ChangelogType.bug,[=[Wrong GW2 moverframe value]=]}
})
addChange("6.0.2",{
    {GW.Enum.ChangelogType.bug,[=[Set actionbar 1 to always have 12 buttons]=]},
    {GW.Enum.ChangelogType.bug,[=[Actionbar taint on shapshift forms]=]}
})
addChange("6.0.1",{
    {GW.Enum.ChangelogType.bug,[=[Fix lua error on login]=]}
})
addChange("6.0.0",{
    {GW.Enum.ChangelogType.feature,[=[Update for 10.0.2]=]}
})
