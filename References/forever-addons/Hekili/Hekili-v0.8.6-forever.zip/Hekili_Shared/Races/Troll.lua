-- Hekili_Shared/Races/Troll.lua
-- `all` (Engine/Schema/Spec/All.lua) no longer registers this racial: the stock entry named below is what it used to register.
-- The Troll's Forever racials (DB2 build 70707, except where noted), for every class: Berserking (20554: +10% attack and casting speed
-- for 15 s since the 27 Oct dev notes (wowsims racials.go; the DB2's 10 s), one flat value, no health scaling; 180 s,
-- off the GCD), which replaces `all`'s stock entry and aura
-- (26297, absent on Forever), and Rapid Regeneration (1260270: heals 50% of maximum health over 6 s; a self-channel,
-- SPELL_ATTR1_IS_SELF_CHANNELLED, broken by movement, action or damage; 180 s, off the GCD), registered as a 6 s
-- channel so the simulation does not recommend breaking it. The haste is declared (`spellHaste`, `swingHaste`: x1.1,
-- wowsims racials.go AttachMultiplyCastSpeed/AttachMultiplyAttackSpeed): spell haste is secret in combat, where the
-- belief composes it (the stat split, L971), and the swing clocks rescale at its edges; a priority reads
-- `buff.berserking.up`. Regeneration and Beast Slaying are passives. No resource or cost modifier. No
-- pack names either. Unknown for any other race (Engine/Schema/Races.lua).

local race = Hekili:NewRace("Troll")

race:RegisterAbility("berserking", {
    id = 20554,
    cast = 0,
    cooldown = 180,
    gcd = "off",
    startsCombat = false,
    toggle = "cooldowns",

    handler = function()
        applyBuff("berserking")
    end,
    -- The belief's now-state of the cast (event-facade spec §12a)
    now = function()
        applyBuff("berserking")
    end,
})

race:RegisterAura("berserking", {
    id = 20554,
    duration = 15,
    max_stack = 1,
    spellHaste = 1.1,
    swingHaste = 1.1,
})

race:RegisterAbility("rapid_regeneration", {
    id = 1260270,
    cast = 6,
    channeled = true,
    fixedCast = true, -- the DB2's duration, not hasted
    cooldown = 180,
    gcd = "off",
    startsCombat = false,
    toggle = "defensives",

    start = function() -- a channel: Hekili's simulation runs `start`, not `handler` (State.lua runHandler)
        applyBuff("rapid_regeneration")
    end,
    now = function()
        applyBuff("rapid_regeneration")
    end,
})

race:RegisterAura("rapid_regeneration", {
    id = 1260270,
    duration = 6,
    max_stack = 1,
})
