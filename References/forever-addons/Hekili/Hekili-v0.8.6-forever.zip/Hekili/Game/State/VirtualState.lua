-- Game/State/VirtualState.lua
-- VirtualState carries the game state forward from plain observations on WoW Forever and answers the reads that are
-- secret in combat (docs/superpowers/specs/2026-10-14-hekili-virtualstate-design.md). This file: the public table
-- `ns.VirtualState`, the module's internal table, the observation enum, the Belief record and the debug rings.
-- Ported from Taco Dog Forever: src/TacoDogForever/Engine/Enum.lua (Enum.Obs, Enum.ReadOf, Enum.TargetCastOf, same
-- integers) and src/TacoDogForever/Model/Belief.lua (the est/lo/hi/conf record and its constants).

local _, ns = ...

local VS = { Count = {} }
ns.VirtualState = VS

-- The module's internals, shared by the VirtualState files only. Not a public surface.
local I = {}
ns.VirtualStateInternal = I

--- Observation kinds (spec §2): TDF's Enum.Obs, same integers. The kinds Phase 1 does not log keep their integers.
VS.Obs = {
    Usable = 1, -- a: ability index; b: 1 usable / 0 not; c: 1 not usable for lack of its resource
    CastStart = 2, -- a: ability index; b: the cast's end
    CastSuccess = 3, -- a: ability index
    CastStop = 4, -- a: ability index (failed or interrupted)
    Read = 5, -- a: resource slot or aura index (c: ReadOf); b: the exact value (amount; aura time remaining)
    Cooldown = 6, -- a: ability index; b: 1 ready / 0 not (the plain isActive flag); c: 1 the GCD flag edge
    PowerTick = 7, -- a: resource slot
    TargetSwap = 8, -- a: memory slot (0 none); b: 1 a slot newly taken; c: 1 attackable (plain UnitCanAttack)
    CombatStart = 9,
    CombatEnd = 10,
    Group = 11, -- reserved
    TargetGone = 12,
    Known = 13, -- reserved
    Queued = 14, -- a: ability index; b: 1 queued for the next swing / 0 not
    Swing = 15, -- a: hand (1 main, 2 off, 3 ranged); b: duration or speed; c: 4 swung (PLAYER_SWING), 1 landed
    -- (Events/Rows.lua's pairing with the target's wound; b: 0), 0 a read, 2 base speed, 3 crit (the same pairing with a
    -- CRITICAL wound; b: 0)
    Haste = 16, -- b: melee multiplier (a plain read); c: 1 melee, 2 spell (b: spell haste percent)
    Moving = 17, -- b: 1 moving / 0 not
    Talent = 18, -- a: talent index; b: its rank
    Enemies = 19, -- reserved
    Encounter = 20, -- reserved
    TargetInfo = 21, -- reserved
    PlayerInfo = 22, -- reserved
    GameError = 23, -- reserved
    ChannelStart = 24, -- a: ability index; b: the channel's end
    ChannelStop = 25, -- a: ability index
    ChannelUpdate = 26, -- a: ability index; b: the channel's new end
    CastDelay = 27, -- a: ability index; b: the cast's new end
    PackEvent = 28, -- reserved
    Pet = 29, -- a: the pet unit exists 1/0 (-1: its power changed, nothing else); b: it is dead 1/0; c: its power (-1: a secret read)
    Totem = 30, -- a: slot 1-4; b: expiry (0 empty); c: 1 an out-of-combat read, 0 an update with no read
    Gear = 31, -- a: gear index; b: its value (Sources/Gear.lua)
    ItemCooldown = 32, -- reserved
    Range = 33, -- reserved
    TargetCast = 34, -- a: TargetCastOf; b: castBarID; c: interruptible 1 / 0 / -1 unknown
    TargetDamage = 35, -- b: a WOUND amount the target took (UNIT_COMBAT, plain); VirtualState's own, past TDF's range
    PlayerHit = 36, -- a: I.HitKind; b: the amount (0: none, -1: a wound's secret amount); c: the attacker's level
    TargetRange = 37, -- a: the target's least distance in yards; b: its greatest (math.huge: no bound), the range poll's
    -- (a = -1: the poll's age-out, no plain answer for 1.5 s: unknown)
    Avoided = 38, -- a: ability index; b: its cast's time; c: I.HitKind (DODGE, PARRY, MISS; DEFLECT, EVADE for reactions
    -- only) or I.UNLANDED (a full RESIST or IMMUNE: target undo only): our cast's own outcome on
    -- the target (Events/Rows.lua's pairing in its landing window, GAP AX); Families/Now.lua undoes and refunds it
    Crit = 39, -- a: ability index; b: its cast's time: our cast's own CRITICAL wound on the target (the same pairing);
    -- Families/Now.lua runs the ability's `onCrit` (GAP T); a 0: our white swing's crit, once its credit is final
    SwingSettled = 40, -- a: hand (1 main, 2 off); b: the swing's time; c: I.HitKind (WOUND: landed; -1: no row): our white swing's
    -- settled outcome, at its row's time (Events/Rows.lua: a final credit, T.onFinal, an avoid at T.onExpire);
    -- Families/Now.lua's reactions only
    PlayerCrit = 41, -- a CRITICAL wound on the player (UNIT_COMBAT, beside its PlayerHit); Families/Now.lua's reactions
    Landed = 42, -- a: ability index; b: its cast's time: our cast's direct hit settled as landed (Events/Rows.lua: a
    -- wound or crit paid to its ticket, at its row or once final); Families/Now.lua runs `onLand`
    Kill = 43, -- a: the victim's UnitIsTrivial (plain, of a token bound to it; 1 trivial, 0 not); b: 1 the victim is
    -- our target: our PARTY_KILL (Sources/Units.lua);
    -- Families/Now.lua runs the target "kill" reactions when it yields XP (0)
}

--- What a `PlayerHit` observation reports (its `a`), and each kind's name (the `taken` and `consumedBy` keys): a WOUND
--- flagged BLOCK or BLOCK_REDUCED is BLOCKED (part of it blocked), the BLOCK action a full block. DEFLECT and EVADE
--- (UNIT_COMBAT actions, Blizzard's CombatFeedback) feed reactions only: the other PlayerHit readers key on their kinds.
I.HitKind = { WOUND = 1, BLOCKED = 2, BLOCK = 3, DODGE = 4, PARRY = 5, MISS = 6, HEAL = 7, DEFLECT = 8, EVADE = 9 }
I.UNLANDED = 0 -- Obs.Avoided's c for a full RESIST or IMMUNE (no I.HitKind: Sources/Player.lua stages none for those)
I.HitName = { "WOUND", "BLOCKED", "BLOCK", "DODGE", "PARRY", "MISS", "HEAL", "DEFLECT", "EVADE" }

--- What a `Read` observation read (its `c`): TDF's Enum.ReadOf integers (5 and 7-9 reserved), plus Health = 10 and
--- RegenSpirit = 11 (an `fsr` slot's spirit part: the not-casting rate less the casting one), VirtualState kinds past
--- TDF's range. AuraOpen = 12 and AuraHeld = 13 are the Cooldown Manager's presence writes (Sources/Auras.lua; below
--- I.AURA_STACK, so they pack stacks like Aura): no client expiry behind them, so no plain read our cast's write yields
--- to (Families/Auras.lua); AuraOpen also opens only a record still down when it folds (our cast's write wins).
--- AuraVerdict = 14 is the verdict's close (cdm-verdict §2.3): its `b` is the applied time of the application it judged,
--- and the fold closes the record only while that is still its application (a recast folded first stands).
I.ReadOf = {
    Resource = 1,
    Aura = 2,
    TargetAura = 3,
    Max = 4,
    Regen = 6,
    Health = 10,
    RegenSpirit = 11,
    AuraOpen = 12,
    AuraHeld = 13,
    AuraVerdict = 14,
}

--- What a `TargetCast` observation reports (its `a`): TDF's Enum.TargetCastOf integers.
I.TargetCastOf = { Start = 1, ChannelStart = 2, End = 3, Interrupted = 4, Kickable = 5 }

-- Constants (spec §6), TDF's values (src/TacoDogForever/Model/Belief.lua:39-72; Belief/Resources.lua:26;
-- Belief/Swing.lua:46).
I.PIN_GAP = 1
I.ALPHA = 0.3
I.REGEN_SPREAD = 0.1
I.REGEN_SPREAD_MIN = 0.02
I.REGEN_RATIO = 2
I.EPS = 0.01
I.CAP_WAIT = 0.06 -- seconds of regen a capped read sits under the cost: past Engine/Output.lua's READY, 0.05 (Resolve, Timeline's READY_EPS)
I.CD_PROBE = 0.5
I.SNAP_HOLD = 1
I.AURA_HALF_LIFE = 10
I.CAST_GRACE = 0.5
I.TARGET_CAP = 16
I.SWING_DECAY = 10
I.SWING_TOL = 0.15
I.SAME_FRAME = 0.05 -- a plain aura read at most this long before our cast, or after it, shows its effect (Auras.lua)
I.RING = 8 -- debug ring slots per origin (spec §2)

I.ORIGINS = { "observed", "pinned", "modelled", "default" }

-- Every record, with its label, in creation order (Snapshot and SetDebug walk them).
I.records, I.labels = {}, {}

local function sample()
    return { v = 0, t = 0, event = 0 }
end

--- A preallocated Belief record (spec §2). Allocates; build time only. `label` names it in Snapshot().
---@param label string
---@return table
function I.NewBelief(label)
    local rec = {
        est = 0,
        lo = 0,
        hi = 0,
        conf = 0,
        basis = "unknown",
        last = { observed = sample(), pinned = sample(), modelled = sample(), default = sample() },
    }
    local n = #I.records + 1
    I.records[n], I.labels[n] = rec, label
    if I.debug then
        I.AddRing(rec)
    end
    return rec
end

--- Forgets every record (SpecChanged rebuilds them). Build time only.
function I.ClearRecords()
    I.records, I.labels = {}, {}
end

--- Writes one sample into `rec.last[origin]` (and its debug ring when debug is on), then re-derives the basis.
--- Allocates nothing.
function I.Sample(rec, origin, v, t, event)
    local s = rec.last[origin]
    s.v, s.t, s.event = v, t, event
    local ring = rec.ring
    if ring then
        local r = ring[origin]
        r.head = r.head % I.RING + 1
        local e = r[r.head]
        e.v, e.t, e.event = v, t, event
    end
    I.Basis(rec)
end

--- The basis (spec §2): the newest of observed, pinned and modelled by t (ties in that order), else default when
--- one is in force, else "unknown". Allocates nothing.
function I.Basis(rec)
    local last = rec.last
    local o, p, m = last.observed.t, last.pinned.t, last.modelled.t
    if o == 0 and p == 0 and m == 0 then
        rec.basis = last.default.t > 0 and "default" or "unknown"
    elseif o >= p and o >= m then
        rec.basis = "observed"
    elseif p >= m then
        rec.basis = "pinned"
    else
        rec.basis = "modelled"
    end
end

--- Gives a record its debug rings: per origin, RING preallocated samples and a head index.
function I.AddRing(rec)
    local ring = {}
    for k = 1, #I.ORIGINS do
        local r = { head = 0 }
        for i = 1, I.RING do
            r[i] = sample()
        end
        ring[I.ORIGINS[k]] = r
    end
    rec.ring = ring
end

--- Creates (on) or drops (off) the debug rings of every record (spec §2, §3.5). Allocates when turned on.
---@param on boolean
function VS.SetDebug(on)
    I.debug = on and true or false
    for i = 1, #I.records do
        I.records[i].ring = nil
        if on then
            I.AddRing(I.records[i])
        end
    end
end

-- The static record an accessor returns for an entity nothing tracks: unknown, conf 0.
I.UNKNOWN = {
    est = 0,
    lo = 0,
    hi = 0,
    conf = 0,
    basis = "unknown",
    last = { observed = sample(), pinned = sample(), modelled = sample(), default = sample() },
}

-- Build hooks (families allocate their arrays and records) and the snapshot writers, in registration order.
I.BUILD, I.BUILT, I.SNAPSHOT = {}, {}, {}

--- Registers `fn(def, now)`, run by I.Build for every family. Load time only.
function I.OnBuild(fn)
    I.BUILD[#I.BUILD + 1] = fn
end

--- Registers `fn(def, now)`, run after every OnBuild: the `now` context's names and the talent ranks are this build's,
--- so a pack function may be evaluated. Load time only.
function I.OnBuilt(fn)
    I.BUILT[#I.BUILT + 1] = fn
end

--- Registers `fn(out)`, which appends Snapshot() lines to `out`. Load time only.
function I.OnSnapshot(fn)
    I.SNAPSHOT[#I.SNAPSHOT + 1] = fn
end

-- What VirtualState.Tracked(kind) lists, by kind: arrays the families fill at build time.
I.TRACKED = {}

--- Fills the caller's array `out` with the tracked IDs of `kind` ("ability", "aura", "resource", "unit") and returns
--- the count. Allocates nothing.
---@param kind string
---@param out table
---@return integer
function VS.Tracked(kind, out)
    local list = I.TRACKED[kind]
    local n = list and #list or 0
    for i = 1, n do
        out[i] = list[i]
    end
    for i = n + 1, #out do
        out[i] = nil
    end
    return n
end

--- Rebuilds the tracked set from `def`, the core's build (Engine/Schema/Tracked.lua): Hekili's ability and aura
--- tables with their IDs and spender slots, the resources, talents, units, guardians, providers, and the core's
--- constants and channels. Every family allocates its arrays and records; the records are cleared. Allocates; a spec
--- change only (never a toggle: Drain swaps the providers).
---@param def table
function VS.Build(def)
    I.Build(def, ns.Facade.GetTime())
end
