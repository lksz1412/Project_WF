--[[Dominos Config Localization - Italian]]

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-Config', 'itIT')
if not L then return end

L.Scale = 'Proporzione'
L.FadedOpacity = 'Dissolvenza'
L.Visibility = 'Visibilità'
L.Spacing = 'Distanza'
L.Padding = 'Imbottitura'
L.Layout = 'Disposizione'
L.Modifiers = 'Modificatori'
L.QuickPaging = 'Pagine rapide'
L.ShowStates = 'Mostra stati'
L.Set = 'Set'
L.Bar = 'Barra %d'
L.RightClickUnit = 'Clic Destro sul Bersaglio'
L.RCUPlayer = 'Se stesso'
L.PossessBar = 'Barra sostituita'
L.Profiles = 'Profili'
L.ShowMacroText = 'Mostra il testo delle macro'
L.ShowBindingText = 'Mostra i tasti assegnati'
L.EnterBindingMode = 'Assegna tasto...'
L.EnterConfigMode = 'Configura le barre...'
L.ShowTooltips = 'Mostra informazioni nelle barre'
L.StickyBars = 'Barre appiccicose'
L.ShowMinimapButton = 'Mostra sulla minimappa'
L.LinkedOpacity = "Le barre attaccate ereditano l'opacità"
L.ClickThrough = 'Ignora il passaggio del mouse'
L.ShowOverrideUI = 'Sostituisci con la barra azioni Blizzard'
L.ShowInOverrideUI = "Mostra con la barra azioni sostituita"
L.ShowInPetBattleUI = 'Mostra nei combattimenti tra mascotte'

L.ALT_KEY_TEXT = 'ALT'

L.State_HELP = 'Aiuto'
L.State_HARM = 'Ferito'
L.State_NOTARGET = 'Nessun bersaglio'
L.State_ALTSHIFT = 'ALT-' .. SHIFT_KEY_TEXT
L.State_CTRLSHIFT = CTRL_KEY_TEXT .. '-' .. SHIFT_KEY_TEXT
L.State_CTRLALT = CTRL_KEY_TEXT .. '-ALT'
L.State_CTRLALTSHIFT = CTRL_KEY_TEXT .. '-ALT-' .. SHIFT_KEY_TEXT

--totems
L.ShowTotems = 'Mostra i Totem'
L.ShowTotemRecall = 'Mostra Richiamo'

--extra bar
L.ExtraBarShowBlizzardTexture = 'Mostra Texture di Blizzard'

--general settings panel

--profile settings panel
L.ResetProfile = 'Reset del Profilo...'
L.CopyProfile = 'Copia il Profilo...'
L.Width = 'Larghezza'
L.Height = 'Altezza'
L.Font = 'Carattere'
L.Texture = 'Motivo'
