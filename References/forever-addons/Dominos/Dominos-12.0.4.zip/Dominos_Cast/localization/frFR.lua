--[[
	Localization.lua
		Translations for Dominos Cast
--]]

-- French version (by Kubik) 2008-10-19
-- � = \195\160
-- � = \195\162
-- � = \195\167
-- � = \195\168
-- � = \195\169
-- � = \195\170
-- � = \195\174
-- � = \195\175
-- � = \195\180
-- � = \195\187

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-CastBar', 'frFR')
if not L then return end

L.Display_time = 'Montrer le temps'
