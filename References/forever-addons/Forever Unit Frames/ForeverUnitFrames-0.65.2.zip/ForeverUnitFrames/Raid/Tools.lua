local _, ns = ...

-- The raid tools bar: what Blizzard's raid manager offered (hidden with
-- Blizzard's raid frames, Core/Blizzard.lua), in rows, each switched on
-- its own: the raid target icons for your target (anyone in a party; in
-- a raid the leader and assistants); the ready check (the last result
-- for everyone, starting one for the leader and assistants); the world
-- markers (as the raid target icons); a role poll (leader and assistants),
-- everyone an assistant, party to raid and back, the loot method (the
-- leader). A tool shows only to whom may use it (in a raid, everyone an
-- assistant counts as an assistant), and while test mode is on. It shows in a raid and in a party while the raid
-- frames are on, hidden when solo, and while test mode is on, so it can
-- be placed. A handle on its left edge folds it out and in (folded in,
-- only the handle shows), as do /fuf tools and a right-click on the raid
-- minimap button (Tools.Fold; in combat only the handle, a secure click,
-- folds at once, the others wait for its end). Docked, bar and handle hang on the main panel's
-- right edge (the panel's anchor never moves in combat) and follow the
-- panel (while the panel is hidden, they stand at the free position
-- instead); free, the bar has its own mover (the raid window's lock) and
-- its top-left corner in the raid profile's General settings, the same
-- for every size, the handle just left of it.
--
-- Secure buttons (the raid target icons and the world markers:
-- SECURE_ACTIONS.raidtarget and .worldmarker, Blizzard_FrameXML/
-- SecureTemplates.lua) make the bar protected: it is
-- built, shown, hidden, sized and moved only out of combat
-- (ns.AfterCombat); a change of the group in combat waits for its end.
-- One secure snippet: the handle's fold (Tools.FOLD_SNIPPET), so the
-- markers can be reached in combat. A secure button's action is the client's own
-- (it calls SetRaidTarget, PlaceRaidMarker or ClearRaidMarker in secure
-- code). The other tools are plain buttons that call the group functions
-- Blizzard's raid manager calls (C_PartyInfo, InitiateRolePoll).
local Tools = {}
ns.RaidTools = Tools

local L, Style, Panel = ns.L, ns.Style, ns.RaidPanel

Tools.NAME = "ForeverUnitFramesRaidTools"
-- An icon button's size, the room between buttons and rows, the bar's
-- inner edge.
Tools.ICON, Tools.GAP, Tools.PADDING = 18, 2, 4
-- The mover's size while no row shows.
Tools.EMPTY_SIZE = 40
-- The handle's size, and the room between the panel (docked), the
-- handle and the bar.
Tools.HANDLE_W, Tools.HANDLE_H, Tools.DOCK_GAP = 12, 32, 4
Tools.MARKERS = 8
Tools.POSITION_KEYS = { toolsX = "x", toolsY = "y" }
-- The bar's own settings: the panels do not follow them.
Tools.KEYS = { "toolsShow", "toolsMode", "toolsOpen", "toolsX", "toolsY", "toolsTargets", "toolsReady",
    "toolsMarkers", "toolsRolePoll", "toolsAssist", "toolsConvert", "toolsLoot" }
for _, key in ipairs(Tools.KEYS) do Panel.UNRELATED_KEYS[key] = true end
-- Its position shows in the raid window like a panel's.
Panel.others[#Panel.others + 1] = Tools

-- The rows, top to bottom: { id, key (its switch; optional), build(bar)
-- -> a plain frame of its size, visible() (optional: whether it shows
-- now), texts(frame) (optional: its words, in the language of the
-- moment), layout(frame) (optional: out of combat, its buttons for who
-- you are and its size) }.
Tools.rows = {}
function Tools.AddRow(row)
    Tools.rows[#Tools.rows + 1] = row
    return row
end

local function general(key) return ns.RaidConfig.Get("general", key) end
local function testing() return ns.RaidTestMode ~= nil and ns.RaidTestMode.IsOn() end
-- Docked, while the main panel shows (in test mode too); docked while
-- it is hidden (a party without the raid view in party), the bar falls
-- back to its free position rather than hang beside nothing.
local function docked()
    return general("toolsMode") == "DOCKED" and (Panel.Active() or testing())
end

-- Docked in a party without the raid view: above our party frames (their
-- block's mover), rather than at the free spot, which only the raid
-- window's unlock moves (asked on CurseForge). Nil when it is not.
local function partyDock()
    if general("toolsMode") ~= "DOCKED" or docked() or not ns.FrameEnabled(ns.Party.KEY) then return nil end
    return ns.Party.header and ns.Party.header.mover
end
Tools.PartyDock = partyDock

-- Whether the bar shows now (with at least one row).
function Tools.Shown()
    if not (Panel.Enabled() and general("toolsShow")) then return false end
    return IsInGroup() or testing()
end

-- The bar's size, or a small handle's while it is empty.
function Tools.Size()
    if (Tools.width or 0) > 0 then return Tools.width, Tools.height end
    return Tools.EMPTY_SIZE, Tools.ICON + 2 * Tools.PADDING
end

-- A position value moved to where the bar stays inside the screen.
function Tools.Reachable(axis, v)
    local w, h = Tools.Size()
    return Panel.Reach(w, h, axis, v)
end

-- Its mover shows with the raid window's lock while the bar shows free.
function Tools.Movable()
    return Tools.Shown() and not docked() and not partyDock()
end

function Tools.MoverSpec()
    return {
        scope = "general", config = ns.RaidConfig, xKey = "toolsX", yKey = "toolsY", id = "raidTools",
        group = "raid", point = "TOPLEFT", origin = "TOPLEFT", anchor = false, size = Tools.Size,
        active = Tools.Movable, clamp = Tools.Reachable, label = function() return L.RAID_TOOLS_TITLE end,
    }
end

-- Buttons ---------------------------------------------------------------------------

local function tooltip(button, textKey)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(L[textKey], 1, 1, 1)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function(self)
        if GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end)
end

-- A secure button whose action (its type, the client's) runs on the left
-- mouse button, with or without a modifier; the others do nothing. Both
-- strokes: an addon's button never gets isSecureAction, so
-- SecureActionButton_OnClick acts on the down stroke while the player
-- casts on key down (CVar ActionButtonUseKeyDown, on by default), else on
-- the up stroke, and ignores the other one (as Elements/Totems.lua).
local function secureButton(parent, kind, attributes)
    local b = CreateFrame("Button", nil, parent, "SecureActionButtonTemplate")
    b:SetSize(Tools.ICON, Tools.ICON)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("*type1", kind)
    for name, value in pairs(attributes) do b:SetAttribute(name, value) end
    return b
end

-- The × of a "clear" button, drawn from two lines (the glyph is not in
-- every game font).
local function cross(button)
    for _, angle in ipairs({ math.pi / 4, -math.pi / 4 }) do
        local t = button:CreateTexture(nil, "ARTWORK")
        t:SetColorTexture(unpack(Style.COLORS.text))
        t:SetSize(Tools.ICON - 4, 2)
        t:SetPoint("CENTER")
        t:SetRotation(angle)
    end
end

-- Lays buttons out in a row; the row's size follows them.
local function lineUp(row, buttons)
    local x = 0
    for _, b in ipairs(buttons) do
        b:SetPoint("LEFT", row, "LEFT", x, 0)
        x = x + b:GetWidth() + Tools.GAP
    end
    row:SetSize(math.max(x - Tools.GAP, 1), Tools.ICON)
end

-- The raid target icons, as Blizzard's TargetFrame draws them
-- (Elements/RaidMarker.lua's sheet): a click puts the icon on your
-- target or takes it off again (action "toggle"); the last button takes
-- your target's icon off. Only while you may (Tools.Marks).
Tools.AddRow({ id = "targets", key = "toolsTargets", visible = function() return Tools.Marks() end,
    build = function(bar)
        local row = CreateFrame("Frame", nil, bar)
        local buttons = {}
        for i = 1, Tools.MARKERS do
            local b = secureButton(row, "raidtarget", { unit = "target", marker = i, action = "toggle" })
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetAllPoints(b)
            b.icon:SetTexture(ns.RaidMarker.TEXTURE)
            b.icon:SetSpriteSheetCell(i, ns.RaidMarker.ROWS, ns.RaidMarker.COLUMNS)
            buttons[i] = b
        end
        local clear = secureButton(row, "raidtarget", { unit = "target", action = "clear" })
        cross(clear)
        tooltip(clear, "RAID_TOOLS_CLEAR_TARGET")
        buttons[#buttons + 1] = clear
        lineUp(row, buttons)
        row.buttons, row.clear = buttons, clear
        return row
    end })

-- Ready check -----------------------------------------------------------------------

-- Everyone an assistant (the raid's leader): IsEveryoneAssistant, as
-- Blizzard's raid manager reads it (secret: not).
local function everyoneAssists()
    return ns.Secrets.Call(IsEveryoneAssistant) == true
end

-- Whether you lead the group or assist, in a raid also while everyone is
-- an assistant (secret while your identity is restricted: then not); in
-- test mode yes, so every tool shows.
function Tools.Leads()
    if testing() then return true end
    local Secrets = ns.Secrets
    return Secrets.Bool(UnitIsGroupLeader, "player") == true or Secrets.Bool(UnitIsGroupAssistant, "player") == true
        or (IsInRaid() and everyoneAssists())
end

-- Whether you may set raid target icons and place world markers: anyone
-- in a party, in a raid those who lead (Blizzard's raid manager,
-- CompactRaidFrameManager_UpdateOptionsFlowContainer: its marker row and
-- its leader options with the world marker menu share this condition).
function Tools.Marks()
    return not IsInRaid() or Tools.Leads()
end

Tools.READY_W, Tools.COUNT_W = 90, 22
-- The answers, as Blizzard's raid frames mark them (Elements/GroupIcons.lua).
Tools.READY_ORDER = { "ready", "notready", "waiting" }
-- The last ready check's answers counted per status; nil before the first.
Tools.readyCounts = nil

-- The group's units: the raid's, or you and your party.
local function groupUnits()
    local list, n = {}, GetNumGroupMembers()
    if IsInRaid() then
        for i = 1, n do list[i] = "raid" .. i end
    elseif n > 0 then
        list[1] = "player"
        for i = 1, n - 1 do list[#list + 1] = "party" .. i end
    end
    return list
end

-- Counts every readable answer (a secret one is left out).
local function countReady()
    local counts = { ready = 0, notready = 0, waiting = 0 }
    for _, unit in ipairs(groupUnits()) do
        local status = ns.Secrets.Plain(ns.Secrets.Call(GetReadyCheckStatus, unit), "string")
        if status and counts[status] then
            counts[status] = counts[status] + 1
        end
    end
    Tools.readyCounts = counts
end

-- When the check is over the client no longer reports the answers:
-- whoever was still waiting is not ready (from the last count, as
-- Blizzard's raid frames, CompactUnitFrame_FinishReadyCheck).
local function finishReady()
    local counts = Tools.readyCounts
    if not counts then return end
    counts.notready = counts.notready + counts.waiting
    counts.waiting = 0
end

local readyRow

-- Any time: the counts, or nothing before the first check.
local function renderReady()
    if not readyRow then return end
    local counts = Tools.readyCounts
    for _, status in ipairs(Tools.READY_ORDER) do
        local c = readyRow.counts[status]
        c.icon:SetShown(counts ~= nil)
        c.text:SetText(counts and tostring(counts[status]) or "")
    end
end

-- A group call the client may refuse (HasRestrictions: ready check,
-- convert, everyone assistant, loot method, role poll) goes through
-- pcall; refused, a line in the chat names the tool (`word`), no Lua error.
function Tools.Ask(word, fn, ...)
    if not pcall(fn, ...) then ns.Print(L.RAID_TOOLS_REFUSED:format(word)) end
end

Tools.AddRow({ id = "ready", key = "toolsReady", build = function(bar)
    local row = CreateFrame("Frame", nil, bar)
    row.start = ns.Widgets.Button(row, { text = "", width = Tools.READY_W,
        onClick = function() Tools.Ask(L.RAID_TOOLS_READY_CHECK, C_PartyInfo.DoReadyCheck) end })
    row.start:SetHeight(Tools.ICON)
    row.counts = {}
    for _, status in ipairs(Tools.READY_ORDER) do
        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(Tools.ICON - 4, Tools.ICON - 4)
        icon:SetAtlas(ns.GroupIcons.READY[status])
        local text = Style.Text(row, 11, "text")
        text:SetPoint("LEFT", icon, "RIGHT", 1, 0)
        row.counts[status] = { icon = icon, text = text }
    end
    readyRow = row
    renderReady()
    return row
end, texts = function(row)
    row.start.text:SetText(L.RAID_TOOLS_READY_CHECK)
end, layout = function(row)
    local leads = Tools.Leads()
    row.start:SetShown(leads)
    row.start:ClearAllPoints()
    row.start:SetPoint("LEFT", row, "LEFT", 0, 0)
    local x = leads and (Tools.READY_W + 2 * Tools.GAP) or 0
    for _, status in ipairs(Tools.READY_ORDER) do
        local icon = row.counts[status].icon
        icon:ClearAllPoints()
        icon:SetPoint("LEFT", row, "LEFT", x, 0)
        x = x + Tools.ICON + Tools.COUNT_W
    end
    row:SetSize(x, Tools.ICON)
end })

-- Only while the bar exists (the raid frames have been on).
ns.On("READY_CHECK", function()
    if not Tools.bar then return end
    countReady()
    renderReady()
end)
ns.On("READY_CHECK_CONFIRM", function()
    if not Tools.bar then return end
    countReady()
    renderReady()
end)
ns.On("READY_CHECK_FINISHED", function()
    if not Tools.bar then return end
    finishReady()
    renderReady()
end)

-- World markers ---------------------------------------------------------------------

-- The world markers by index (1 blue square, 2 green triangle, 3 purple
-- diamond, 4 red cross, 5 yellow star, 6 orange circle, 7 silver moon,
-- 8 white skull) drawn with the raid target icon of the same sign.
Tools.WORLD_MARKER_ICONS = { 6, 4, 3, 7, 1, 2, 5, 8 }

-- Whether this client places world markers at all.
local function worldMarkers()
    if type(IsRaidMarkerSystemEnabled) ~= "function" then return true end
    local ok, on = pcall(IsRaidMarkerSystemEnabled)
    return not ok or ns.Secrets.IsSecret(on) or on == true
end

-- A click places the marker (the client's PlaceRaidMarker) or takes it
-- away again (action "toggle"); the last button takes every world marker
-- away (action "clear" without a marker). On a light square, so they do
-- not pass for the raid target icons. Only while you may (Tools.Marks).
Tools.AddRow({ id = "markers", key = "toolsMarkers", visible = function() return Tools.Marks() and worldMarkers() end,
    build = function(bar)
        local row = CreateFrame("Frame", nil, bar)
        local buttons = {}
        for i, icon in ipairs(Tools.WORLD_MARKER_ICONS) do
            local b = secureButton(row, "worldmarker", { marker = i, action = "toggle" })
            local bg = b:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints(b)
            bg:SetColorTexture(1, 1, 1, 0.15)
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetPoint("TOPLEFT", b, "TOPLEFT", 2, -2)
            b.icon:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 2)
            b.icon:SetTexture(ns.RaidMarker.TEXTURE)
            b.icon:SetSpriteSheetCell(icon, ns.RaidMarker.ROWS, ns.RaidMarker.COLUMNS)
            tooltip(b, "RAID_TOOLS_WORLD_MARKER")
            buttons[i] = b
        end
        local clear = secureButton(row, "worldmarker", { action = "clear" })
        cross(clear)
        tooltip(clear, "RAID_TOOLS_CLEAR_MARKERS")
        buttons[#buttons + 1] = clear
        lineUp(row, buttons)
        row.buttons, row.clear = buttons, clear
        return row
    end })

-- The group: role poll, everyone assistant, party and raid, loot -----------------------

-- Whether you lead the group (secret while your identity is restricted:
-- then not); in test mode yes.
function Tools.IsLeader()
    if testing() then return true end
    return ns.Secrets.Bool(UnitIsGroupLeader, "player") == true
end

-- The loot methods offered (Enum.LootMethod, LootConstantsDocumentation.lua)
-- in this order, with their words.
Tools.LOOT_METHODS = { "Freeforall", "Roundrobin", "Masterlooter", "Group", "Needbeforegreed", "Personal" }
Tools.GROUP_BUTTON_W, Tools.BUTTON_PADDING = 60, 16

-- Master looter is the player himself, as Blizzard's unit menu sets it.
local function setLoot(name)
    local method = Enum.LootMethod[name]
    local looter
    if name == "Masterlooter" then
        looter = ns.Secrets.Plain(ns.Secrets.Call(UnitName, "player"), "string")
    end
    Tools.Ask(L.RAID_TOOLS_LOOT, C_PartyInfo.SetLootMethod, method, looter)
end

-- The current method marked (never secret, PartyInfoDocumentation.lua;
-- checked all the same).
local function openLootMenu(owner)
    local current = ns.Secrets.Call(C_PartyInfo.GetLootMethod)
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle(L.RAID_TOOLS_LOOT)
        for _, name in ipairs(Tools.LOOT_METHODS) do
            local function selected(n) return current ~= nil and current == Enum.LootMethod[n] end
            root:CreateRadio(L["RAID_LOOT_" .. name], selected, setLoot, name)
        end
    end)
end

-- Each button: its switch, who may use it, when it applies, its click,
-- its words (a function: party or raid).
local GROUP_BUTTONS = {
    { id = "rolePoll", key = "toolsRolePoll", who = Tools.Leads,
        click = function() Tools.Ask(L.RAID_TOOLS_ROLE_POLL, InitiateRolePoll) end,
        text = function() return L.RAID_TOOLS_ROLE_POLL end },
    { id = "assist", key = "toolsAssist", who = Tools.IsLeader, applies = function() return IsInRaid() or testing() end,
        click = function()
            Tools.Ask(L.RAID_TOOLS_ASSIST, C_PartyInfo.SetEveryoneIsAssistant, not everyoneAssists())
        end,
        text = function() return L.RAID_TOOLS_ASSIST end },
    { id = "convert", key = "toolsConvert", who = Tools.IsLeader,
        applies = function() return not IsInRaid() or GetNumGroupMembers() <= 5 end,
        click = function()
            if IsInRaid() then
                Tools.Ask(L.RAID_TOOLS_TO_PARTY, C_PartyInfo.ConvertToParty)
            else
                Tools.Ask(L.RAID_TOOLS_TO_RAID, C_PartyInfo.ConvertToRaid)
            end
        end,
        text = function() return IsInRaid() and L.RAID_TOOLS_TO_PARTY or L.RAID_TOOLS_TO_RAID end },
    { id = "loot", key = "toolsLoot", who = Tools.IsLeader, click = openLootMenu,
        text = function() return L.RAID_TOOLS_LOOT end },
}

local function wanted(spec)
    return general(spec.key) == true and spec.who() and (not spec.applies or spec.applies())
end

-- Any time: the everyone-assistant button is outlined while it is on.
local groupRow
local function paintAssist()
    if not groupRow then return end
    Style.SetBorderColor(groupRow.buttons.assist, everyoneAssists() and "accent" or "border")
end

Tools.AddRow({ id = "group", visible = function()
    for _, spec in ipairs(GROUP_BUTTONS) do
        if wanted(spec) then return true end
    end
    return false
end, build = function(bar)
    local row = CreateFrame("Frame", nil, bar)
    row.buttons = {}
    for _, spec in ipairs(GROUP_BUTTONS) do
        local b
        b = ns.Widgets.Button(row, { text = "", width = Tools.GROUP_BUTTON_W, onClick = function() spec.click(b) end })
        b:SetHeight(Tools.ICON)
        row.buttons[spec.id] = b
    end
    -- A hover repaints the outline; the switch's state comes back after.
    row.buttons.assist:HookScript("OnLeave", function() paintAssist() end)
    groupRow = row
    return row
end, texts = function(row)
    for _, spec in ipairs(GROUP_BUTTONS) do
        local b = row.buttons[spec.id]
        b.text:SetText(spec.text())
        b:SetWidth(math.max(Tools.GROUP_BUTTON_W, (b.text:GetStringWidth() or 0) + Tools.BUTTON_PADDING))
    end
    paintAssist()
end, layout = function(row)
    local shown = {}
    for _, spec in ipairs(GROUP_BUTTONS) do
        local b = row.buttons[spec.id]
        local on = wanted(spec)
        b:SetShown(on)
        b:ClearAllPoints()
        if on then shown[#shown + 1] = b end
    end
    lineUp(row, shown)
end })

ns.On("PARTY_LEADER_CHANGED", paintAssist)
ns.On("GROUP_ROSTER_UPDATE", paintAssist)

-- The bar ---------------------------------------------------------------------------

-- Docked: the handle beside the main panel, the bar beyond it, both
-- hanging from the panel's anchor (out of combat: the bar is protected);
-- in a party without the panel, both above the party frames.
-- Free: its own mover holds it (before the mover is there, its
-- position), the handle just left of it; the handle never hangs from the
-- protected bar.
local function place()
    local bar, handle = Tools.bar, Tools.handle
    bar:ClearAllPoints()
    handle:ClearAllPoints()
    if docked() then
        local anchor = ns.RaidHeader.anchor or UIParent
        local x = (ns.RaidHeader.width or 0) + Tools.DOCK_GAP
        handle:SetPoint("TOPLEFT", anchor, "TOPLEFT", x, 0)
        bar:SetPoint("TOPLEFT", anchor, "TOPLEFT", x + Tools.HANDLE_W + Tools.DOCK_GAP, 0)
    elseif partyDock() then
        local block = partyDock()
        handle:SetPoint("BOTTOMLEFT", block, "TOPLEFT", 0, Tools.DOCK_GAP)
        bar:SetPoint("BOTTOMLEFT", block, "TOPLEFT", Tools.HANDLE_W + Tools.DOCK_GAP, Tools.DOCK_GAP)
    elseif bar.mover then
        ns.Movers.Sync(bar)
        bar:SetPoint("TOPLEFT", bar.mover, "TOPLEFT", 0, 0)
        handle:SetPoint("TOPRIGHT", bar.mover, "TOPLEFT", -Tools.DOCK_GAP, 0)
    else
        local x, y = ns.Pixel.Snap(general("toolsX")), ns.Pixel.Snap(general("toolsY"))
        bar:SetPoint("TOPLEFT", UIParent, "CENTER", x, y)
        handle:SetPoint("TOPRIGHT", UIParent, "CENTER", x - Tools.DOCK_GAP, y)
    end
end

-- The handle points the way the bar folds.
local function paintHandle()
    Tools.handle.text:SetText(general("toolsOpen") and "<" or ">")
end

-- Out of combat: the rows that show, one below the other, the bar around
-- them with the panel's ring, where it belongs; the handle shown with it,
-- the bar while folded out.
function Tools.Refresh()
    local bar = Tools.bar
    if not bar then return end
    local y, width, any = Tools.PADDING, 0, false
    for _, row in ipairs(Tools.rows) do
        local f = row.frame
        local on = (not row.key or general(row.key) == true) and (not row.visible or row.visible())
        f:SetShown(on)
        if on then
            if row.texts then row.texts(f) end
            if row.layout then row.layout(f) end
            f:ClearAllPoints()
            f:SetPoint("TOPLEFT", bar, "TOPLEFT", Tools.PADDING, -y)
            y = y + f:GetHeight() + Tools.GAP
            width = math.max(width, f:GetWidth())
            any = true
        end
    end
    if any then
        Tools.width, Tools.height = width + 2 * Tools.PADDING, y - Tools.GAP + Tools.PADDING
    else
        Tools.width, Tools.height = 0, 0
    end
    bar:SetSize(Tools.Size())
    place()
    ns.Border.Draw(bar, Panel.PANEL_SCOPE, bar, 0)
    local shown = any and Tools.Shown()
    bar:SetShown(shown and general("toolsOpen"))
    Tools.handle:SetShown(shown)
    paintHandle()
end

-- Whether the bar shows at all (its handle shows whenever it does).
function Tools.IsShown()
    return Tools.handle ~= nil and Tools.handle:IsShown()
end

-- The fold asked for in combat (nil: none), set when combat ends.
local foldAsked

-- /fuf tools and the raid minimap button's right-click: folds the bar out
-- or in; nothing (and no word) while the bar does not show. In combat the
-- fold waits for its end (only the handle's secure click works then), and
-- the chat says so; asked for twice, it is back where it was.
function Tools.Fold()
    if not Tools.IsShown() then return false end
    if InCombatLockdown() then
        if foldAsked == nil then foldAsked = not general("toolsOpen") else foldAsked = not foldAsked end
        ns.Print(L.RAID_TOOLS_COMBAT)
        ns.AfterCombat("raidToolsFold", function()
            local state = foldAsked
            foldAsked = nil
            if state ~= nil and state ~= general("toolsOpen") then ns.RaidConfig.Set("general", "toolsOpen", state) end
        end)
        return true
    end
    return ns.RaidConfig.Set("general", "toolsOpen", not general("toolsOpen"))
end

-- The handle folds the bar in a secure snippet, so it works in combat
-- too: the bar is protected (its secure buttons), only secure code may
-- show or hide it then. PostClick keeps the fold (applied again out of
-- combat by Tools.Refresh).
Tools.FOLD_SNIPPET = [[
    local bar = self:GetFrameRef("bar")
    if bar:IsShown() then bar:Hide() else bar:Show() end
]]

local function createHandle(bar)
    local handle = CreateFrame("Button", Tools.NAME .. "Handle", UIParent, "SecureHandlerClickTemplate")
    handle:SetSize(Tools.HANDLE_W, Tools.HANDLE_H)
    local bg = handle:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(handle)
    bg:SetColorTexture(0, 0, 0, 0.6)
    handle.text = Style.Text(handle, 12, "text")
    handle.text:SetPoint("CENTER")
    handle:SetFrameRef("bar", bar)
    handle:SetAttribute("_onclick", Tools.FOLD_SNIPPET)
    handle:SetScript("PostClick", function()
        ns.RaidConfig.Set("general", "toolsOpen", bar:IsShown())
        paintHandle()
    end)
    tooltip(handle, "RAID_TOOLS_TITLE")
    handle:Hide()
    return handle
end

-- Built once, out of combat, after the raid profile is attached.
function Tools.Create()
    if Tools.bar then return Tools.bar end
    local bar = CreateFrame("Frame", Tools.NAME, UIParent, "SecureFrameTemplate")
    local bg = bar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(bar)
    bg:SetColorTexture(0, 0, 0, 0.6)
    Tools.bar = bar
    Tools.handle = createHandle(bar)
    for _, row in ipairs(Tools.rows) do row.frame = row.build(bar) end
    ns.Movers.Attach(bar, Tools.MoverSpec())
    Tools.Refresh()
    return bar
end

local function update()
    if Tools.bar then ns.AfterCombat("raidTools", Tools.Refresh) end
end

-- Who leads or assists changes which tools show. Everyone an assistant
-- has no event of its own: the roster's (as Blizzard's raid manager's
-- checkbox listens, Blizzard_CompactRaidFrameManager.xml).
ns.On("GROUP_ROSTER_UPDATE", update)
ns.On("PARTY_LEADER_CHANGED", update)
ns.Listen("RAID_CONFIG_CHANGED", update)
ns.Listen("RAID_TEST_MODE", update)
-- Our party frames on or off: docked in a party, the bar hangs above them.
ns.Listen("CONFIG_CHANGED", function(scope, key)
    if scope == ns.Party.KEY and (key == nil or key == "enabled") then update() end
end)
-- The words of the moment (a button's width may change).
ns.Listen("LANGUAGE_CHANGED", update)
-- Docked, it follows the main panel's size (placed out of combat).
ns.Listen("RAID_PANEL_PLACED", function(P)
    if P == ns.RaidHeader and Tools.bar and docked() then place() end
end)
