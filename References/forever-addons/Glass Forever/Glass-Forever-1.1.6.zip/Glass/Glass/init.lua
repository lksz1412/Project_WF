local _G = _G

local AceAddon = _G.LibStub("AceAddon-3.0")

local AddonName, AddonVars = ...
local Core = AceAddon:NewAddon(AddonName)
local Constants = {}
local Utils = {}
AddonVars[1] = Core
AddonVars[2] = Constants
AddonVars[3] = Utils
_G[AddonName] = Core

-- Core
Core.Libs = {
  AceConfig = _G.LibStub("AceConfig-3.0"),
  AceConfigDialog = _G.LibStub("AceConfigDialog-3.0"),
  AceDB = _G.LibStub("AceDB-3.0"),
  AceDBOptions = _G.LibStub("AceDBOptions-3.0"),
  AceGUI = _G.LibStub("AceGUI-3.0"),
  AceHook = _G.LibStub("AceHook-3.0"),
  LSM = _G.LibStub("LibSharedMedia-3.0"),
  LibEasing = _G.LibStub("LibEasing-1.0"),
  lodash = _G.LibStub("lodash.wow")
}
Core.Components = {}
Core.Version = "1.1.6-forever"
--[==[@debug@--
Core.Version = "DEBUG"
--@end-debug@]==]--

-- Modules
Core:NewModule("Config", "AceConsole-3.0")
Core:NewModule("Copy")
Core:NewModule("SpamFilter")
Core:NewModule("VersionCheck")
Core:NewModule("Fonts")
Core:NewModule("Hyperlinks")
Core:NewModule("News")
Core:NewModule("OptionsPanel")
Core:NewModule("TextProcessing")
Core:NewModule("UIManager", "AceHook-3.0")
Core:NewModule("EditMode") -- after UIManager, it uses UIManager's mover frame
Core:NewModule("History") -- after UIManager, it uses UIManager's frames
Core:NewModule("Whispers") -- after UIManager, its bubbles sit above the chat
Core:NewModule("DefaultTabs") -- after UIManager, it opens chat windows Glass takes over

-- Default settings
Core.defaults = {
  profile = {
    -- General
    font = "Friz Quadrata TT",
    fontFlags = "",
    frameWidth = 450,
    frameHeight = 230,
    windowStyle = true, -- separate (undocked) windows get the Glass look
    windowMessageBackground = false, -- separate windows: a background on each message instead of the whole window
    alertStyle = true, -- the game's alerts (achievements, loot...) get the Glass look
    windowOpenPosition = "above", -- where "Open in Separate Window" puts the window
    positionAnchor = {
      point = "BOTTOMLEFT",
      xOfs = 20,
      yOfs = 230
    },

    -- The game's chat buttons beside the chat
    chatButtons = false,
    chatButtonsSide = "left", -- "left", "right", "topleft", "topright", "bottomleft" or "bottomright"
    chatButtonsOffsetX = 0, -- small adjustment of the buttons, in pixels
    chatButtonsOffsetY = 0,

    -- Tabs
    tabFont = "", -- empty: same font as the messages
    tabFontSize = 12,
    tabBarHeight = 20,
    tabPadding = 15,
    tabBarOpacity = 0.4,
    tabBarBackgroundFull = false, -- the tab bar background on the whole bar, not fading out on the right
    tabAlerts = true, -- colored glow and tab bar reveal on new messages
    tabUnreadCount = false, -- how many new messages, by the name of a tab you're not looking at
    tabStyle = "minimal", -- minimal, framed, solid, underline, pill, glossy or classic
    tabAccent = "default", -- accent color of the selected tab; "default" = the style's own
    tabLineAnimation = "slide", -- selected line (Minimal): "slide", "grow" or "off"
    tabTextColor = "auto", -- tab name color: auto, gold, white, silver or dark
    tabBarPosition = "top", -- "top" or "bottom" of the messages
    tabAlign = "left", -- "left", "center" or "right" along the tab bar
    tabBarFade = true, -- the tab bar fades out with the chat; false keeps it visible
    tabBarOffsetX = 0, -- fine adjustment of the tab bar, in pixels
    tabBarOffsetY = 0,

    -- Edit box
    editBoxFontSize = 12,
    editBoxBackgroundOpacity = 0.6,
    editBoxStyle = "minimal", -- "minimal", "solid" or "framed"
    editBoxAnchor = {
      position = "BELOW",
      yOfs = -5
    },

    -- Messages
    messageFontSize = 12,
    chatBackgroundOpacity = 0.4,
    messageBackgroundFull = false, -- the background on the whole line, not fading out on the right
    messageLeading = 3,
    messageLinePadding = 0.25,

    messageFade = true, -- messages fade out after chatHoldTime; false keeps them visible
    chatHoldTime = 10,
    chatShowOnMouseOver = true,
    chatFadeInDuration = 0.6,
    chatFadeOutDuration = 0.6,
    chatSlideInDuration = 0.3,

    indentWordWrap = true,
    shortChannelNames = true,
    emoteStyle = "glass", -- ":)" and friends as faces: "glass", "classic" or "off"
    emoteButton = false, -- the face at the right of the chat box that opens the emote list
    timestamps = "off", -- the time in front of messages: "off", "hm" (17:49) or "hms" (17:49:05)
    chatClassIcons = false, -- class icon in front of players' names
    chatRaceIcons = false, -- race icon in front of players' names
    firstNamesOnly = false, -- "Aehya" for "Aehya Bfc"
    keepHistory = true,
    whisperWindows = true, -- whispers in their own windows (an envelope by the tab bar), not in the chat
    whisperIconSize = 20,
    whisperListOpacity = 0.7, -- the background of the icon's list
    whisperSound = "none", -- a sound when a whisper arrives: "none", "kit:<SOUNDKIT name>" or "lsm:<SharedMedia name>"
    whisperIconStyle = "envelope", -- "envelope", "bubble" or "bubbles"
    whisperIconAnimation = "shake", -- when a whisper arrives: "shake", "pulse", "bounce", "spin" or "none"
    whisperIconColor = "gold", -- "gold", "whisper", "white" or "silver"
    whisperIconPosition = "barRight", -- "barRight", "barInside", "barLeft", "aboveRight" or "aboveLeft"
    whisperIconOffsetX = 0, -- fine adjustment of the envelope, in pixels
    whisperIconOffsetY = 0,
    whisperNameColor = "auto", -- names in the list and the windows: "auto" (gold, class in the chat's look), "gold", "class" or "whisper"
    whisperWindowOpacity = 0.75,
    whisperLook = "boxes", -- "boxes" (like a phone chat) or "chat" (like the Glass chat)
    whisperWindowStyle = "auto", -- "auto" (rounded, none in the chat's look), "rounded", "solid", "fade" or "none"
    whisperWindowColor = "dark", -- "dark", "black", "brown", "blue" or "purple"
    whisperBubbleTheirs = "dark", -- their boxes (Phone chat): "whisper", "dark", "black", "gold", "blue", "green", "purple" or "red"
    whisperBubbleYours = "whisper", -- your boxes (Phone chat)
    whisperBubbleOpacity = 0.9,
    whisperBubbleShape = "round", -- "round" or "square"
    whisperFontSize = 0, -- 0: same as the chat messages
    whisperFont = "", -- empty: same font as the messages
    whisperFontFlags = "same", -- "same" (as the messages), "", "OUTLINE" or "THICKOUTLINE"
    whisperTextColor = "auto", -- "auto" (white, whisper color in the chat's look), "whisper", "white", "silver" or "gold"
    whisperShowNames = true, -- "Name:" in front of each line
    whisperTimestamps = "auto", -- "auto" (17:49, as the chat in the chat's look), "chat", "off", "hm" or "hms"
    whisperAutoOpen = false, -- a new whisper opens its window by itself
    arrowKeyHistory = true, -- Up/Down arrows go through what you typed, no Alt
    spamFilter = true, -- hide messages with any of spamWords
    spamWords = { -- gold sellers; players can change the list
      "safe gold", "cheap gold", "buy gold", "gold for sale", "wts gold",
      "refund if not delivered",
    },
    mouseOverTooltips = true,
    iconTextureYOffset = 4,
  }
}

function Core:OnInitialize()
  self.listeners = {}

  self.db = self.Libs.AceDB:New("GlassDB", self.defaults, true)
  self.printBuffer = {}
end

function Core:OnEnable()
  -- Buffer print messages until ViragDevTool loads
  for _, item in ipairs(self.printBuffer) do
    Utils.print(unpack(item))
  end
  self.printBuffer = {}
end

function Core:Subscribe(messageType, listener)
  if self.listeners[messageType] == nil then
    self.listeners[messageType] = {}
  end

  local listeners = self.listeners[messageType]
  local index = #listeners + 1
  listeners[index] = listener

  return function ()
    self.Libs.lodash.remove(listeners, function (val) return val == listener end)
  end
end

function Core:Dispatch(messageType, payload)
  --[==[@debug@--
  Utils.print('E: '..messageType, payload)
  --@end-debug@]==]--

  local listeners = self.listeners[messageType] or {}
  for _, listener in ipairs(listeners) do
    listener(payload)
  end
end
