local Core, Constants = unpack(select(2, ...))

local MouseEnter = Constants.ACTIONS.MouseEnter
local MouseLeave = Constants.ACTIONS.MouseLeave

local UPDATE_CONFIG = Constants.EVENTS.UPDATE_CONFIG

-- luacheck: push ignore 113
local CreateFrame = CreateFrame
local Mixin = Mixin
-- luacheck: pop

local MainContainerFrameMixin = {}

function MainContainerFrameMixin:Init()
  self.state = {
    mouseOver = false
  }

  self:SetWidth(Core.db.profile.frameWidth)
  self:SetHeight(Core.db.profile.frameHeight)

  --[==[@debug@
  self.bg = self:CreateTexture(nil, "BACKGROUND")
  self.bg:SetColorTexture(1, 0, 0, 0)
  self.bg:SetAllPoints()
  --@end-debug@]==]

  Core:Subscribe(UPDATE_CONFIG, function (key)
    if key == "frameWidth" then
      self:SetWidth(Core.db.profile.frameWidth)
    end

    if key == "frameHeight" then
      self:SetHeight(Core.db.profile.frameHeight)
    end
  end)
end

function MainContainerFrameMixin:OnFrame()
  -- Mouse over tracking. The chat buttons beside the chat count as the chat.
  local mouseOver = self:IsMouseOver()
    or (self.chatButtons ~= nil and self.chatButtons:IsMouseOverButtons())
  if self.state.mouseOver ~= mouseOver then
    if not self.state.mouseOver then
      Core:Dispatch(MouseEnter())
    else
      Core:Dispatch(MouseLeave())
    end

    self.state.mouseOver = not self.state.mouseOver
  elseif mouseOver then
    -- Already over the chat while the tab bar fades out (e.g. after a new
    -- message alert): it comes back, without waiting for the mouse to leave
    -- and enter again
    local dock = _G.GeneralDockManager
    if dock and dock.hideAg and (dock.hideAg:IsPlaying() or not dock:IsShown()) then
      dock:Show()
    end
  end
end

Core.Components.CreateMainContainerFrame = function (name, parent)
  local frame = CreateFrame("Frame", name, parent)
  local object = Mixin(frame, MainContainerFrameMixin)
  object:Init()
  return object
end
