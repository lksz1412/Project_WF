---@class addonTableChattynator
local addonTable = select(2, ...)

local customisers = {}

local function SetupGeneral(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}
  local infoInset = CreateFrame("Frame", nil, container, "InsetFrameTemplate")
  do
    table.insert(allFrames, infoInset)
    infoInset:SetPoint("TOP")
    infoInset:SetPoint("LEFT", 20, 0)
    infoInset:SetPoint("RIGHT", -20, 0)
    infoInset:SetHeight(75)
    addonTable.Skins.AddFrame("InsetFrame", infoInset)

    local logo = infoInset:CreateTexture(nil, "ARTWORK")
    logo:SetTexture("Interface\\AddOns\\Chattynator\\Assets\\Logo.png")
    logo:SetSize(52, 52)
    logo:SetPoint("LEFT", 8, 0)

    local name = infoInset:CreateFontString(nil, "ARTWORK", "GameFontHighlightHuge")
    name:SetText(addonTable.Locales.CHATTYNATOR)
    name:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, 0)

    local credit = infoInset:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    credit:SetText(addonTable.Locales.BY_PLUSMOUSE)
    credit:SetPoint("BOTTOMLEFT", name, "BOTTOMRIGHT", 5, 0)

    local discordButton = CreateFrame("Button", nil, infoInset, "UIPanelDynamicResizeButtonTemplate")
    discordButton:SetText(addonTable.Locales.JOIN_THE_DISCORD)
    DynamicResizeButton_Resize(discordButton)
    discordButton:SetPoint("BOTTOMLEFT", logo, "BOTTOMRIGHT", 8, 0)
    discordButton:SetScript("OnClick", function()
      addonTable.Dialogs.ShowCopy("https://discord.gg/gPS62RjKSZ")
    end)
    addonTable.Skins.AddFrame("Button", discordButton)
    local discordText = infoInset:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    discordText:SetPoint("LEFT", discordButton, "RIGHT", 10, 0)
    discordText:SetText(addonTable.Locales.DISCORD_DESCRIPTION)
  end
  
  do
    local function GetTipsSection(rowContainer, details)
      local header = rowContainer:CreateFontString(nil, "ARTWORK", "GameFontHighlightMedium")
      header:SetJustifyH("LEFT")
      header:SetPoint("TOP")
      header:SetText(details.header)
      header:SetHeight(30)
      local text = rowContainer:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
      text:SetJustifyH("LEFT")
      text:SetPoint("TOP", header, "BOTTOM")
      text:SetText(details.text)
      text:SetSpacing(3)

      return {header, text}
    end

    local function MakeTipsRow(details1, details2)
      local rowContainer = CreateFrame("Frame", nil, container)
      rowContainer:SetPoint("LEFT", 35 + addonTable.Constants.ButtonFrameOffset, 0)
      rowContainer:SetPoint("RIGHT", -35, 0)
      rowContainer:SetHeight(110)
      for _, row in ipairs(GetTipsSection(rowContainer, details1)) do
        row:SetPoint("LEFT")
        row:SetPoint("RIGHT", rowContainer, "CENTER", -15, 0)
      end
      for _, row in ipairs(GetTipsSection(rowContainer, details2)) do
        row:SetPoint("RIGHT")
        row:SetPoint("LEFT", rowContainer, "CENTER", 15, 0)
      end
      return rowContainer
    end

    local tipsRows = {
      MakeTipsRow({
        header = CreateTextureMarkup("Interface\\AddOns\\Chattynator\\Assets\\SettingsCog.png", 64, 64, 13, 13, 0, 1, 0, 1) .. "  " .. addonTable.Locales.CUSTOMIZABLE,
        text = addonTable.Locales.TIPS_CUSTOMIZABLE,
      }, {
        header = addonTable.Locales.THEMES,
        text = addonTable.Locales.TIPS_THEMES,
      }),
      MakeTipsRow({
        header = CreateTextureMarkup("Interface\\AddOns\\Chattynator\\Assets\\Search.png", 64, 64, 13, 13, 0, 1, 0, 1) .. "  " .. addonTable.Locales.MOVING_THE_WINDOW,
        text = addonTable.Locales.TIPS_MOVING_THE_WINDOW,
      }, {
        header = addonTable.Locales.ACCESSING_DEFAULT_SETTINGS,
        text = addonTable.Locales.TIPS_ACCESSING_DEFAULT_SETTINGS,
      }),
    }
    for _, row in ipairs(tipsRows) do
      row:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
      table.insert(allFrames, row)
    end
    tipsRows[1]:SetPoint("TOP", allFrames[#allFrames - #tipsRows], "BOTTOM", 0, -30)
  end

  do
    local header = addonTable.CustomiseDialog.Components.GetHeader(container, addonTable.Locales.DEVELOPMENT_IS_DONE_BY_A_HUMAN)
    header:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
    table.insert(allFrames, header)

    local donateFrame = CreateFrame("Frame", nil, container)
    donateFrame:SetPoint("LEFT")
    donateFrame:SetPoint("RIGHT")
    donateFrame:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
    donateFrame:SetHeight(40)
    local text = donateFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    text:SetPoint("RIGHT", donateFrame, "CENTER", -50, 0)
    text:SetText(addonTable.Locales.DONATE)
    text:SetJustifyH("RIGHT")

    local button = CreateFrame("Button", nil, donateFrame, "UIPanelDynamicResizeButtonTemplate")
    button:SetText(addonTable.Locales.LINK)
    DynamicResizeButton_Resize(button)
    button:SetPoint("LEFT", donateFrame, "CENTER", -35, 0)
    button:SetScript("OnClick", function()
      addonTable.Dialogs.ShowCopy("https://linktr.ee/plusmouse")
    end)
    addonTable.Skins.AddFrame("Button", button)
    table.insert(allFrames, donateFrame)
  end

  local profileDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.PROFILES)
  do
    profileDropdown.SetValue = nil

    local clone = false
    local function ValidateAndCreate(profileName)
      if profileName ~= "" and CHATTYNATOR_CONFIG.Profiles[profileName] == nil then
        local oldSkin = addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)
        addonTable.Config.MakeProfile(profileName, clone)
        profileDropdown.DropDown:GenerateMenu()
        if addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN) ~= oldSkin then
          addonTable.Dialogs.ShowConfirm(addonTable.Locales.RELOAD_REQUIRED, YES, NO, function() ReloadUI() end)
        end
      end
    end
    profileDropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
    profileDropdown.DropDown:SetupMenu(function(menu, rootDescription)
      local profiles = addonTable.Config.GetProfileNames()
      table.sort(profiles, function(a, b) return a:lower() < b:lower() end)
      for _, name in ipairs(profiles) do
        local button = rootDescription:CreateRadio(name ~= "DEFAULT" and name or LIGHTBLUE_FONT_COLOR:WrapTextInColorCode(DEFAULT), function()
          return CHATTYNATOR_CURRENT_PROFILE == name
        end, function()
          local oldSkin = addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)
          addonTable.Config.ChangeProfile(name)
          if addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN) ~= oldSkin then
            addonTable.Dialogs.ShowConfirm(addonTable.Locales.RELOAD_REQUIRED, YES, NO, function() ReloadUI() end)
          end
        end)
        if name ~= "DEFAULT" and name ~= CHATTYNATOR_CURRENT_PROFILE then
          button:AddInitializer(function(button, description, menu)
            local delete = MenuTemplates.AttachAutoHideButton(button, "transmog-icon-remove")
            delete:SetPoint("RIGHT")
            delete:SetSize(18, 18)
            delete.Texture:SetAtlas("transmog-icon-remove")
            delete:SetScript("OnClick", function()
              menu:Close()
              addonTable.Dialogs.ShowConfirm(addonTable.Locales.CONFIRM_DELETE_PROFILE_X:format(name), YES, NO, function()
                addonTable.Config.DeleteProfile(name)
              end)
            end)
            MenuUtil.HookTooltipScripts(delete, function(tooltip)
              GameTooltip_SetTitle(tooltip, DELETE);
            end);
          end)
        end
      end
      rootDescription:CreateButton(NORMAL_FONT_COLOR:WrapTextInColorCode(addonTable.Locales.NEW_PROFILE_CLONE), function()
        clone = true
        addonTable.Dialogs.ShowEditBox(addonTable.Locales.ENTER_PROFILE_NAME, ACCEPT, CANCEL, ValidateAndCreate)
      end)
      rootDescription:CreateButton(NORMAL_FONT_COLOR:WrapTextInColorCode(addonTable.Locales.NEW_PROFILE_BLANK), function()
        clone = false
        addonTable.Dialogs.ShowEditBox(addonTable.Locales.ENTER_PROFILE_NAME, ACCEPT, CANCEL, ValidateAndCreate)
      end)
    end)
  end
  table.insert(allFrames, profileDropdown)

  do
    local exportButton = CreateFrame("Button", nil, container, "UIPanelDynamicResizeButtonTemplate")
    exportButton:SetPoint("TOPLEFT", allFrames[#allFrames], "BOTTOM", -33, -10)
    exportButton:SetText(addonTable.Locales.EXPORT)
    DynamicResizeButton_Resize(exportButton)
    exportButton:SetScript("OnClick", function()
      local tmp = addonTable.Config.DumpCurrentProfile()
      tmp.addon = "Chattynator"
      tmp.version = 1
      tmp.kind = "profile"
      addonTable.Core.RemoveTemporaryWindows(tmp[addonTable.Config.Options.WINDOWS])
      addonTable.Dialogs.ShowCopy("CHATTY!1!" .. C_EncodingUtil.EncodeBase64(C_EncodingUtil.CompressString(C_EncodingUtil.SerializeCBOR(tmp))))
    end)
    addonTable.Skins.AddFrame("Button", exportButton)

    local importButton = CreateFrame("Button", nil, container, "UIPanelDynamicResizeButtonTemplate")
    importButton:SetPoint("TOPRIGHT", allFrames[#allFrames], "BOTTOM", -45, -10)
    importButton:SetText(addonTable.Locales.IMPORT)
    DynamicResizeButton_Resize(importButton)
    importButton:SetScript("OnClick", function()
      addonTable.CustomiseDialog.ShowImportDialog(function(text)
        local import
        local prefix = text:match("^CHATTY!1!")
        if not prefix then
          addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.INVALID_IMPORT)
          return
        end
        local status, decoded = pcall(C_EncodingUtil.DecodeBase64, text:sub(10))
        if not status then
          addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.INVALID_IMPORT)
          return
        end
        local status, decompressed = pcall(C_EncodingUtil.DecompressString, decoded)
        if not status then
          addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.INVALID_IMPORT)
          return
        end
        status, import = pcall(C_EncodingUtil.DeserializeCBOR, decompressed)
        if not status or type(import) ~= "table" or import.addon ~= "Chattynator" then
          addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.INVALID_IMPORT)
          return
        end
        addonTable.Dialogs.ShowDualChoice(addonTable.Locales.OVERWRITE_CURRENT_PROFILE, addonTable.Locales.OVERWRITE, addonTable.Locales.MAKE_NEW,
          function()
            addonTable.CustomiseDialog.ImportData(import, CHATTYNATOR_CURRENT_PROFILE, true)
            profileDropdown.DropDown:GenerateMenu()
          end,
          function()
            addonTable.Dialogs.ShowEditBox(addonTable.Locales.ENTER_THE_NEW_PROFILE_NAME, OKAY, CANCEL, function(value)
              if CHATTYNATOR_CONFIG.Profiles[value] == nil then
                addonTable.CustomiseDialog.ImportData(import, value, false)
                profileDropdown.DropDown:GenerateMenu()
              else
                addonTable.Dialogs.ShowAcknowledge(addonTable.Locales.THAT_PROFILE_NAME_ALREADY_EXISTS)
              end
            end)
          end
        )
      end)
    end)
    addonTable.Skins.AddFrame("Button", importButton)
  end

  local customTabsDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.SPECIAL_TABS)
  do
    customTabsDropdown.SetValue = nil
    customTabsDropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -70)
    customTabsDropdown.DropDown:SetDefaultText(GRAY_FONT_COLOR:WrapTextInColorCode(addonTable.Locales.TOGGLE_COMBAT_LOG_ETC))
    local function IsActive(customType)
      local windows = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)
      for _, w in ipairs(windows) do
        for _, t in ipairs(w.tabs) do
          if t.custom == customType then
            return true
          end
        end
      end
      return false
    end

    customTabsDropdown.DropDown:SetupMenu(function(menu, rootDescription)
      local details = {}
      for key, val in pairs(addonTable.API.CustomTabs) do
        table.insert(details, {
          custom = key,
          label = addonTable.Display.GetTabNameFromName(val.label),
        })
      end
      table.sort(details, function(a, b)
        return a.label:lower() < b.label:lower()
      end)

      for _, d in ipairs(details) do
        rootDescription:CreateCheckbox(d.label, function()
          return IsActive(d.custom)
        end, function()
          local windows = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)
          if IsActive(d.custom) then
            local found = false
            for windowIndex, w in ipairs(windows) do
              for tabIndex, t in ipairs(w.tabs) do
                if t.custom == d.custom then
                  table.remove(w.tabs, tabIndex)
                  if #w.tabs == 0 then
                    table.insert(w.tabs, addonTable.Config.GetEmptyTabConfig(addonTable.Locales.EMPTY_WINDOW))
                  end
                  found = true
                  break
                end
              end
              if found then
                break
              end
            end
          else
            local blank = addonTable.Config.GetEmptyTabConfig(d.label)
            blank.backgroundColor = "262626"
            blank.tabColor = "c97c48"
            blank.custom = d.custom
            table.insert(windows[1].tabs, blank)
          end
          addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
        end)
      end
    end)
  end
  table.insert(allFrames, customTabsDropdown)

  container:SetScript("OnShow", function()
    for _, f in ipairs(allFrames) do
      if f.SetValue then
        f:SetValue(addonTable.Config.Get(f.option))
      end
    end
  end)

  return container
end

local function SetupLayout(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  local showTabs = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.SHOW_TABS, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.SHOW_TABS) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.SHOW_TABS, value)
  end)
  showTabs:SetPoint("TOP")
  do
    local entries = {
      addonTable.Locales.ALWAYS,
      addonTable.Locales.MOUSEOVER,
      addonTable.Locales.NEVER,
    }
    local values = {
      "always",
      "hover",
      "never",
    }
    showTabs:Init(entries, values)
  end
  table.insert(allFrames, showTabs)

  local showButtons = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.SHOW_BUTTONS, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.SHOW_BUTTONS) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.SHOW_BUTTONS, value)
  end)
  showButtons:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
  do
    local entries = {
      addonTable.Locales.ALWAYS,
      addonTable.Locales.MOUSEOVER,
      addonTable.Locales.NEVER,
    }
    local values = {
      "always",
      "hover",
      "never",
    }
    showButtons:Init(entries, values)
  end
  table.insert(allFrames, showButtons)

  local buttonPositionDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.BUTTONS_POSITION, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.BUTTON_POSITION) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.BUTTON_POSITION, value)
  end)
  buttonPositionDropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  do
    local entries = {
      addonTable.Locales.LEFT_OUTSIDE,
      addonTable.Locales.LEFT_INSIDE,
      addonTable.Locales.RIGHT_OUTSIDE,
      addonTable.Locales.RIGHT_INSIDE,
      addonTable.Locales.TABS_ABOVE,
      addonTable.Locales.TABS_BELOW,
    }
    local values = {
      "outside_left",
      "inside_left",
      "outside_right",
      "inside_right",
      "outside_tabs",
      "inside_tabs",
    }
    buttonPositionDropdown:Init(entries, values)
  end
  table.insert(allFrames, buttonPositionDropdown)

  local editBoxHorizontalOffset, editBoxWidth
  local editBoxPositionDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.EDIT_BOX_POSITION, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.EDIT_BOX_POSITION) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.EDIT_BOX_POSITION, value)
    if value == 'bottom' or value == 'top' then
      editBoxHorizontalOffset:Hide()
      editBoxWidth:Hide()
    else
      editBoxHorizontalOffset:Show()
      editBoxWidth:Show()
    end
  end)
  editBoxPositionDropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  do
    local entries = {
      addonTable.Locales.BOTTOM,
      addonTable.Locales.TOP,
      addonTable.Locales.SCREEN_BOTTOM,
      addonTable.Locales.SCREEN_CENTER,
      addonTable.Locales.SCREEN_TOP,
    }
    local values = {
      "bottom",
      "top",
      "screenBottom",
      "screenCenter",
      "screenTop"
    }
    editBoxPositionDropdown:Init(entries, values)
  end
  table.insert(allFrames, editBoxPositionDropdown)

  local keepEditBoxVisible = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.KEEP_EDIT_BOX_VISIBLE, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE, state)
  end)
  keepEditBoxVisible.option = addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE
  keepEditBoxVisible:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
  table.insert(allFrames, keepEditBoxVisible)

  editBoxWidth = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.EDIT_BOX_WIDTH, 200, 700, function(x) return string.format("%spx", x) end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.EDIT_BOX_WIDTH, value)
  end)
  editBoxWidth.option = addonTable.Config.Options.EDIT_BOX_WIDTH
  editBoxWidth:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  editBoxWidth:Hide()
  editBoxWidth:SetCollapsesLayout(true)
  table.insert(allFrames, editBoxWidth)

  local editBoxHeight = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.EDIT_BOX_HEIGHT, 12, 48, function(x) return string.format("%spx", x) end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.EDIT_BOX_HEIGHT, value)
  end)
  editBoxHeight.option = addonTable.Config.Options.EDIT_BOX_HEIGHT
  editBoxHeight:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, editBoxHeight)

  editBoxHorizontalOffset = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.EDIT_BOX_HORIZONTAL_OFFSET, -400, 400, function(x) return string.format("%spx", x) end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.EDIT_BOX_HORIZONTAL_OFFSET, value)
  end)
  editBoxHorizontalOffset.option = addonTable.Config.Options.EDIT_BOX_HORIZONTAL_OFFSET
  editBoxHorizontalOffset:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  editBoxHorizontalOffset:Hide()
  editBoxHorizontalOffset:SetCollapsesLayout(true)
  table.insert(allFrames, editBoxHorizontalOffset)

  local editBoxVerticalOffset = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.EDIT_BOX_VERTICAL_OFFSET,-150, 150, function(x) return string.format("%spx", x) end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.EDIT_BOX_VERTICAL_OFFSET, value)
  end)
  editBoxVerticalOffset.option = addonTable.Config.Options.EDIT_BOX_VERTICAL_OFFSET
  editBoxVerticalOffset:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, editBoxVerticalOffset)

  local fadedAlpha
  local fadeChatCompletely = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.FADE_WHEN_NOT_IN_USE, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.FADE_COMPLETELY, state)
  end)
  fadeChatCompletely.option = addonTable.Config.Options.FADE_COMPLETELY
  fadeChatCompletely:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, fadeChatCompletely)

  fadedAlpha = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.FADED_TRANSPARENCY, 0, 100, function(x) return string.format("%s%%", x) end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.FADED_ALPHA, 1 - value / 100)
  end)
  fadedAlpha:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, fadedAlpha)

  local locked = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.LOCK_CHAT, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.LOCKED, state)
  end)
  locked.option = addonTable.Config.Options.LOCKED
  locked:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, locked)

  container:SetScript("OnShow", function()
    fadedAlpha:SetValue((1 - addonTable.Config.Get(addonTable.Config.Options.FADED_ALPHA))* 100)
    for _, f in ipairs(allFrames) do
      if f.SetValue then
        if f.option then
          f:SetValue(addonTable.Config.Get(f.option))
        elseif f.DropDown then
          f:SetValue()
        end
      end
    end
  end)

  return container
end

local function SetupMessages(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  local fontDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.MESSAGE_FONT)
  fontDropdown:SetPoint("TOP")
  table.insert(allFrames, fontDropdown)

  local fontSize
  fontSize = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.MESSAGE_FONT_SIZE, 2, 40, function(x) return string.format("%spx", x) end, function()
    addonTable.Config.Set(addonTable.Config.Options.MESSAGE_FONT_SIZE, fontSize:GetValue())
  end)
  fontSize.option = addonTable.Config.Options.MESSAGE_FONT_SIZE
  fontSize:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, fontSize)

  local messageSpacing
  messageSpacing = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.MESSAGE_SPACING, 0, 60, function(x) return string.format("%spx", x) end, function()
    addonTable.Config.Set(addonTable.Config.Options.MESSAGE_SPACING, messageSpacing:GetValue())
  end)
  messageSpacing.option = addonTable.Config.Options.MESSAGE_SPACING
  messageSpacing:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, messageSpacing)

  local messageAlignment = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.MESSAGE_ALIGNMENT, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.MESSAGE_ALIGNMENT) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.MESSAGE_ALIGNMENT, value)
  end)
  messageAlignment:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  do
    local entries = {
      addonTable.Locales.LEFT,
      addonTable.Locales.CENTER,
      addonTable.Locales.RIGHT,
    }
    local values = {
      "left",
      "center",
      "right"
    }
    messageAlignment:Init(entries, values)
  end
  table.insert(allFrames, messageAlignment)
  
  local messageOutline = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.MESSAGE_FONT_OUTLINE, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.MESSAGE_FONT_OUTLINE) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.MESSAGE_FONT_OUTLINE, value)
  end)
  messageOutline:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  do
    local entries = {
      NONE,
      addonTable.Locales.THIN,
      addonTable.Locales.THICK,
    }
    local values = {
      "none",
      "thin",
      "thick"
    }
    messageOutline:Init(entries, values)
  end
  table.insert(allFrames, messageOutline)

  local showTextShadow = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.MESSAGE_FONT_SHADOW, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.SHOW_FONT_SHADOW, state)
  end)
  showTextShadow.option = addonTable.Config.Options.SHOW_FONT_SHADOW
  showTextShadow:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
  table.insert(allFrames, showTextShadow)

  local enableMessageFade = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.ENABLE_MESSAGE_FADE, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.ENABLE_MESSAGE_FADE, state)
  end)
  enableMessageFade.option = addonTable.Config.Options.ENABLE_MESSAGE_FADE
  enableMessageFade:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, enableMessageFade)

  local messageFadeTimer
  messageFadeTimer = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.MESSAGE_FADE_TIME, 5, 240, function(x) return string.format("%ss", x) end, function()
    addonTable.Config.Set(addonTable.Config.Options.MESSAGE_FADE_TIME, messageFadeTimer:GetValue())
  end)
  messageFadeTimer.option = addonTable.Config.Options.MESSAGE_FADE_TIME
  messageFadeTimer:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, messageFadeTimer)

  local storeMessages = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.STORE_MESSAGES, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.STORE_MESSAGES, state)
  end)
  storeMessages.option = addonTable.Config.Options.STORE_MESSAGES
  storeMessages:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, storeMessages)

  local removeOldMessages = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.REMOVE_OLD_MESSAGES, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.REMOVE_OLD_MESSAGES, state)
  end)
  removeOldMessages.option = addonTable.Config.Options.REMOVE_OLD_MESSAGES
  removeOldMessages:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
  table.insert(allFrames, removeOldMessages)

  container:SetScript("OnShow", function()
    local LibSharedMedia = LibStub and LibStub:GetLibrary("LibSharedMedia-3.0", true)
    local fontValues, fontLabels = {}, {}
    if LibSharedMedia then
      fontValues = CopyTable(LibSharedMedia:List("font"))
      fontLabels = CopyTable(LibSharedMedia:List("font"))
    end
    table.insert(fontValues, 1, "default")
    table.insert(fontLabels, 1, DEFAULT)

    fontDropdown.DropDown:SetupMenu(function(_, rootDescription)
      for index, label in ipairs(fontLabels) do
        local radio = rootDescription:CreateRadio(label,
          function()
            return addonTable.Config.Get(addonTable.Config.Options.MESSAGE_FONT) == fontValues[index]
          end,
          function()
            addonTable.Config.Set(addonTable.Config.Options.MESSAGE_FONT, fontValues[index])
          end
        )
        radio:AddInitializer(function(button, elementDescription, menu)
          button.fontString:SetFontObject(addonTable.Core.GetFontByID(fontValues[index]))
        end)
      end
      rootDescription:SetScrollMode(20 * 20)
    end)

    for _, f in ipairs(allFrames) do
      if f.SetValue then
        if f.option then
          f:SetValue(addonTable.Config.Get(f.option))
        end
      end
    end
  end)

  return container
end

local function SetupFormatting(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  local timestampDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.TIMESTAMP, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.TIMESTAMP_FORMAT) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.TIMESTAMP_FORMAT, value)
  end)
  timestampDropdown:SetPoint("TOP")
  do
    local entries = {
      NONE,
      "HH:MM",
      "HH:MM:SS",
      "HH:MM AM/PM",
      "HH:MM:SS AM/PM",
    }
    local values = {
      " ",
      "%H:%M",
      "%X",
      "%I:%M %p",
      "%I:%M:%S %p",
    }
    timestampDropdown:Init(entries, values)
  end
  table.insert(allFrames, timestampDropdown)

  local showSeparator = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.SHOW_VERTICAL_SEPARATOR, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.SHOW_TIMESTAMP_SEPARATOR, state)
  end)
  showSeparator.option = addonTable.Config.Options.SHOW_TIMESTAMP_SEPARATOR
  showSeparator:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, showSeparator)
  
  local timestampSpacing
  timestampSpacing = addonTable.CustomiseDialog.Components.GetSlider(container, addonTable.Locales.TIMESTAMP_SPACING, 0, 200, function(x) return string.format("%s%%", x) end, function()
    addonTable.Config.Set(addonTable.Config.Options.TIMESTAMP_SPACING, timestampSpacing:GetValue() / 100)
  end)
  timestampSpacing:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, timestampSpacing)

  local timestampOnRight = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.TIMESTAMP_ON_RIGHT, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.TIMESTAMP_ON_RIGHT, state)
  end)
  timestampOnRight.option = addonTable.Config.Options.TIMESTAMP_ON_RIGHT
  timestampOnRight:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, timestampOnRight)

  local shorteningDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.SHORTEN_CHANNELS, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.SHORTEN_FORMAT) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.SHORTEN_FORMAT, value)
  end)
  shorteningDropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  do
    local entries = {
      addonTable.Locales.NONE,
      addonTable.Locales.SHORTEN_STYLE_1,
      addonTable.Locales.SHORTEN_STYLE_2,
    }
    local values = {
      "none",
      "number",
      "letter",
    }
    shorteningDropdown:Init(entries, values)
  end
  table.insert(allFrames, shorteningDropdown)

  local reduceRedundantText = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.REDUCE_REDUNDANT_TEXT, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.REDUCE_REDUNDANT_TEXT, state)
  end)
  reduceRedundantText.option = addonTable.Config.Options.REDUCE_REDUNDANT_TEXT
  reduceRedundantText:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, reduceRedundantText)

  local useClassColors = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.USE_CLASS_COLORS, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.CLASS_COLORS, state)
  end)
  useClassColors.option = addonTable.Config.Options.CLASS_COLORS
  useClassColors:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, -30)
  table.insert(allFrames, useClassColors)

  if addonTable.Constants.IsMidnightNext or addonTable.Constants.IsForever then
    local showPlayerLevel = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.SHOW_PLAYER_LEVEL, 28, function(state)
      addonTable.Config.Set(addonTable.Config.Options.SHOW_LEVEL, state)
    end)
    showPlayerLevel.option = addonTable.Config.Options.SHOW_LEVEL
    showPlayerLevel:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, 0)
    table.insert(allFrames, showPlayerLevel)
  end

  container:SetScript("OnShow", function()
    timestampSpacing:SetValue(addonTable.Config.Get(addonTable.Config.Options.TIMESTAMP_SPACING) * 100)
    for _, f in ipairs(allFrames) do
      if f.SetValue then
        if f.option then
          f:SetValue(addonTable.Config.Get(f.option))
        elseif f.DropDown then
          f:SetValue()
        end
      end
    end
  end)

  return container
end

local function SetupThemes(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  local themeDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.THEME, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.CURRENT_SKIN, value)
    addonTable.Dialogs.ShowConfirm(addonTable.Locales.RELOAD_REQUIRED, YES, NO, function() ReloadUI() end)
  end)
  themeDropdown:SetPoint("TOP")
  do
    local skins = {}
    for _, skin in pairs(addonTable.Skins.availableSkins) do
      table.insert(skins, {name = skin.label, value = skin.key})
    end
    table.sort(skins, function(a, b) return a.name < b.name end)
    local entries, values = {}, {}
    for _, skinDetails in ipairs(skins) do
      table.insert(entries, skinDetails.name)
      table.insert(values, skinDetails.value)
    end
    themeDropdown:Init(entries, values)
  end
  table.insert(allFrames, themeDropdown)

  local skinKey = addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)
  local currentSkin = addonTable.Skins.availableSkins[skinKey]
  local spacer = false
  for index, option in ipairs(currentSkin.options) do
    local optionKey = "skins." .. skinKey .. "." .. (option.option or "")
    local offset = (index == 1 and -30 or 0) + (spacer and -30 or 0)
    spacer = false
    if option.type == "slider" then
      local slider
      slider = addonTable.CustomiseDialog.Components.GetSlider(container, option.text, option.min, option.max, function(x) return option.valuePattern:format(x) end, function()
        addonTable.Config.Set(optionKey, slider:GetValue() / (option.scale or 1))
      end)
      slider.option = optionKey
      slider.scale = option.scale
      slider:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, offset)
      table.insert(allFrames, slider)
    elseif option.type == "checkbox" then
      local checkbox = addonTable.CustomiseDialog.Components.GetCheckbox(container, option.text, 28, function(state)
        addonTable.Config.Set(optionKey, state)
      end)
      checkbox.option = optionKey
      checkbox:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, offset)
      table.insert(allFrames, checkbox)
    elseif option.type == "colorPicker" then
      local colorPicker = addonTable.CustomiseDialog.Components.GetColorPicker(container, option.text, 28, function(state)
        addonTable.Config.Set(optionKey, state)
      end)
      colorPicker.option = optionKey
      colorPicker:SetPoint("TOP", allFrames[#allFrames], "BOTTOM", 0, offset)
      table.insert(allFrames, colorPicker)
    elseif option.type == "spacer" then
      spacer = true
    end
  end

  container:SetScript("OnShow", function()
    for _, f in ipairs(allFrames) do
      if f.SetValue then
        if f.option and f.scale then
          f:SetValue(addonTable.Config.Get(f.option) * f.scale)
        elseif f.option then
          f:SetValue(addonTable.Config.Get(f.option))
        else
          f:SetValue()
        end
      end
    end
  end)

  return container
end

local function SetupChatColors(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  for _, entry in ipairs(addonTable.CustomiseDialog.TYPE_LAYOUT_ORDER) do
    local dropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, entry[1])
    if #allFrames > 0 then
      dropdown:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
    else
      dropdown:SetPoint("TOP")
    end
    dropdown.DropDown:SetDefaultText(addonTable.Locales.SELECT_TYPE_TO_CHANGE)
    table.insert(allFrames, dropdown)
    local fields = addonTable.CustomiseDialog.TYPE_LAYOUT[entry[2]]
    if not fields then
      dropdown.DropDown:SetupMenu(function(_, rootDescription)
        local colors = addonTable.Config.Get(addonTable.Config.Options.CHAT_COLORS)
        local channelMap, count = addonTable.Messages:GetChannels()
        for i = 1, count do
          if channelMap[i] then
            local color = colors["CHANNEL_" .. channelMap[i]]
            local oldColor = CopyTable(color)
            local colorInfo = {
              r = oldColor.r, g = oldColor.g, b = oldColor.b,
              swatchFunc = function()
                color.r, color.g, color.b =  ColorPickerFrame:GetColorRGB()
                addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.MessageColor] = true})
              end,
              cancelFunc = function()
                color.r, color.g, color.b =  oldColor.r, oldColor.g, oldColor.b
                addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.MessageColor] = true})
              end,
            }
            rootDescription:CreateColorSwatch(addonTable.CustomiseDialog.GetChatColor("CHANNEL_" .. channelMap[i]):WrapTextInColorCode(channelMap[i]),
              function()
                ColorPickerFrame:SetupColorPickerAndShow(colorInfo)
              end,
              colorInfo
            )
          end
        end
      end)
    else
      dropdown.DropDown:SetupMenu(function(_, rootDescription)
        local colors = addonTable.Config.Get(addonTable.Config.Options.CHAT_COLORS)
        local fields = addonTable.CustomiseDialog.TYPE_LAYOUT[entry[2]]
        for _, f in ipairs(fields) do
          if ChatTypeGroup[f[1]] then
            local color = {}
            for _, a in ipairs(ChatTypeGroup[f[1]]) do
              table.insert(color, colors[(a:gsub("CHAT_MSG_", ""))])
            end
            local oldColor = CopyTable(color[1] or {1, 1, 1})
            local colorInfo = {
              r = oldColor.r, g = oldColor.g, b = oldColor.b,
              swatchFunc = function()
                for _, c in ipairs(color) do
                  c.r, c.g, c.b = ColorPickerFrame:GetColorRGB()
                end
                addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.MessageColor] = true})
              end,
              cancelFunc = function()
                for _, c in ipairs(color) do
                  c.r, c.g, c.b = oldColor.r, oldColor.g, oldColor.b
                end
                addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.MessageColor] = true})
              end,
            }
            rootDescription:CreateColorSwatch(addonTable.CustomiseDialog.GetChatColor(f[1]):WrapTextInColorCode(f[2] or _G[f[1]]),
              function()
                ColorPickerFrame:SetupColorPickerAndShow(colorInfo)
              end,
              colorInfo
            )
          end
        end
      end)
    end
  end

  return container
end

local function SetupNotifications(parent)
  local container = CreateFrame("Frame", nil, parent)

  local allFrames = {}

  --[[local whisperDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.WHISPER_SOUNDS, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.WHISPER_SOUNDS) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.WHISPER_SOUNDS, value)
  end)
  whisperDropdown:SetPoint("TOP")
  do
    local entries = {
      addonTable.Locales.FIRST_MESSAGE,
      addonTable.Locales.ALL_MESSAGES,
    }
    local values = {
      "first",
      "all"
    }
    whisperDropdown:Init(entries, values)
  end
  table.insert(allFrames, whisperDropdown)]]

  local flashOnDropdown = addonTable.CustomiseDialog.Components.GetBasicDropdown(container, addonTable.Locales.FLASH_TABS_ON, function(value)
    return addonTable.Config.Get(addonTable.Config.Options.TAB_FLASH_ON) == value
  end, function(value)
    addonTable.Config.Set(addonTable.Config.Options.TAB_FLASH_ON, value)
  end)
  flashOnDropdown:SetPoint("TOP")
  do
    local entries = {
      addonTable.Locales.NEVER,
      addonTable.Locales.ALL_MESSAGES,
      addonTable.Locales.WHISPERS_ONLY,
    }
    local values = {
      "never",
      "all",
      "whispers"
    }
    flashOnDropdown:Init(entries, values)
  end
  table.insert(allFrames, flashOnDropdown)

  local newWhispersNewTab = addonTable.CustomiseDialog.Components.GetCheckbox(container, addonTable.Locales.NEW_WHISPERS_TO_NEW_TAB, 28, function(state)
    addonTable.Config.Set(addonTable.Config.Options.NEW_WHISPER_NEW_TAB, state and 1 or 0)
  end)
  newWhispersNewTab.option = addonTable.Config.Options.NEW_WHISPER_NEW_TAB
  newWhispersNewTab:SetPoint("TOP", allFrames[#allFrames], "BOTTOM")
  table.insert(allFrames, newWhispersNewTab)

  container:SetScript("OnShow", function()
    for _, f in ipairs(allFrames) do
      if f.SetValue then
        if f.option == addonTable.Config.Options.NEW_WHISPER_NEW_TAB then
          f:SetValue(addonTable.Config.Get(f.option) ~= 0)
        elseif f.option then
          f:SetValue(addonTable.Config.Get(f.option))
        else
          f:SetValue()
        end
      end
    end
  end)

  return container
end

local TabSetups = {
  {name = GENERAL, callback = SetupGeneral},
  {name = addonTable.Locales.THEME, callback = SetupThemes},
  {name = addonTable.Locales.LAYOUT, callback = SetupLayout},
  {name = addonTable.Locales.MESSAGES, callback = SetupMessages},
  {name = addonTable.Locales.COLORS, callback = SetupChatColors},
  {name = addonTable.Locales.FORMATTING, callback = SetupFormatting},
  {name = addonTable.Locales.NOTIFICATIONS, callback = SetupNotifications},
}

function addonTable.CustomiseDialog.Toggle()
  if customisers[addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)] then
    local frame = customisers[addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)]
    frame:SetShown(not frame:IsVisible())
    return
  end

  local frame = CreateFrame("Frame", "ChattynatorCustomiseDialog" .. addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN), UIParent, "ButtonFrameTemplate")
  frame:SetToplevel(true)
  customisers[addonTable.Config.Get(addonTable.Config.Options.CURRENT_SKIN)] = frame
  table.insert(UISpecialFrames, frame:GetName())
  frame:SetSize(600, 700)
  frame:SetPoint("CENTER")
  frame:Raise()

  frame:SetMovable(true)
  frame:SetClampedToScreen(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function()
    frame:StartMoving()
    frame:SetUserPlaced(false)
  end)
  frame:SetScript("OnDragStop", function()
    frame:StopMovingOrSizing()
    frame:SetUserPlaced(false)
  end)

  ButtonFrameTemplate_HidePortrait(frame)
  ButtonFrameTemplate_HideButtonBar(frame)
  frame.Inset:Hide()
  frame:EnableMouse(true)
  frame:SetScript("OnMouseWheel", function() end)

  frame:SetTitle(addonTable.Locales.CUSTOMISE_CHATTYNATOR)

  local containers = {}
  local lastTab
  local Tabs = {}
  for _, setup in ipairs(TabSetups) do
    local tabContainer = setup.callback(frame)
    tabContainer:SetPoint("TOPLEFT", 0 + addonTable.Constants.ButtonFrameOffset, -65)
    tabContainer:SetPoint("BOTTOMRIGHT")

    local tabButton = addonTable.CustomiseDialog.Components.GetTab(frame, setup.name)
    if lastTab then
      tabButton:SetPoint("LEFT", lastTab, "RIGHT", 5, 0)
    else
      tabButton:SetPoint("TOPLEFT", 0 + addonTable.Constants.ButtonFrameOffset + 5, -25)
    end
    lastTab = tabButton
    tabContainer.button = tabButton
    tabButton:SetScript("OnClick", function()
      for _, c in ipairs(containers) do
        PanelTemplates_DeselectTab(c.button)
        c:Hide()
      end
      PanelTemplates_SelectTab(tabButton)
      tabContainer:Show()
    end)
    tabContainer:Hide()

    table.insert(Tabs, tabButton)
    table.insert(containers, tabContainer)
  end
  frame.Tabs = Tabs
  PanelTemplates_SetNumTabs(frame, #frame.Tabs)
  containers[1].button:Click()

  frame:SetScript("OnShow", function()
    local shownContainer = FindValueInTableIf(containers, function(c) return c:IsShown() end)
    if shownContainer then
      PanelTemplates_SetTab(frame, tIndexOf(containers, shownContainer))
    end
  end)

  addonTable.Skins.AddFrame("ButtonFrame", frame, {"customise"})
end
