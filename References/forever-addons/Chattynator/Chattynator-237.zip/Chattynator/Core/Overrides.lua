---@class addonTableChattynator
local addonTable = select(2, ...)

function addonTable.Core.ApplyOverrides()
  -- Disable context menu to move channel to new window (for now, will add functionality back)
  local function ChannelDropDown(_, chatType, chatTarget, chatName)
    local actualChatFrame
    for _, frame in ipairs(addonTable.allChatFrames) do
      if frame:IsMouseOver() then
        actualChatFrame = frame
      end
    end
    MenuUtil.CreateContextMenu(nil, function(_, rootDescription)
      local channelNumber = tonumber(chatTarget)
      local channelName = addonTable.Messages.channelMap[channelNumber]
      if not channelName or chatType ~= "CHANNEL" then
        rootDescription:CreateTitle(GRAY_FONT_COLOR:WrapTextInColorCode(addonTable.Locales.CANT_POPOUT_THIS_CHANNEL))
        return
      end
      rootDescription:CreateButton(MOVE_TO_NEW_WINDOW, function()
        local config = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[actualChatFrame:GetID()]
        local tabConfig = addonTable.Config.GetEmptyTabConfig(channelName)
        tabConfig.channels[channelName] = true
        table.insert(config.tabs, tabConfig)
        config.tabs[actualChatFrame.tabIndex].channels[channelName] = false
        actualChatFrame.TabsBar:RefreshTabs()
        actualChatFrame.TabsBar.Tabs[#config.tabs]:Click()
      end)
    end)
  end
  if ChatFrameUtil and ChatFrameUtil.ShowChatChannelContextMenu then
    hooksecurefunc(ChatFrameUtil, "ShowChatChannelContextMenu", ChannelDropDown)
  elseif ChatChannelDropdown_Show then
    hooksecurefunc("ChatChannelDropdown_Show", ChannelDropDown)
  end

  do
    local actualChatFrame
    hooksecurefunc(UnitPopupPopoutChatButtonMixin, "GetText", function()
      for _, frame in ipairs(addonTable.allChatFrames) do
        if frame:IsMouseOver() then
          actualChatFrame = frame
        end
      end
    end)
    function FCF_OpenTemporaryWindow(chatType, chatTarget, _, _)
      if not debugstack():find("UnitPopupShared") or chatType ~= "WHISPER" and chatType ~= "BN_WHISPER" then
        return
      end
      if not actualChatFrame then
        return
      end
      local config = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[actualChatFrame:GetID()]
      local tabConfig = addonTable.Config.GetEmptyTabConfig(Ambiguate(chatTarget, "short"))
      local player = Ambiguate(chatTarget, "none")
      tabConfig.whispersTemp[player] = true
      tabConfig.isTemporary = true
      local c = ChatTypeInfo[chatType]
      tabConfig.tabColor = CreateColor(c.r, c.g, c.b):GenerateHexColorNoAlpha()
      table.insert(config.tabs, tabConfig)
      config.tabs[actualChatFrame.tabIndex].whispersTemp[player] = false
      actualChatFrame.TabsBar:RefreshTabs()
      actualChatFrame.TabsBar.Tabs[#config.tabs]:Click()
      actualChatFrame = nil
    end
  end

  if ChatFrameUtil and ChatFrameUtil.ChatPageUp then
    ChatFrameUtil.ChatPageUp = function()
      addonTable.allChatFrames[1].ScrollingMessages:PageUp()
    end

    ChatFrameUtil.ChatPageDown = function()
      addonTable.allChatFrames[1].ScrollingMessages:PageDown()
    end

    ChatFrameUtil.ScrollToBottom = function()
      addonTable.allChatFrames[1].ScrollingMessages:ScrollToBottom()
    end
  elseif ChatFrame_ChatPageUp then
    ChatFrame_ChatPageUp = function()
      addonTable.allChatFrames[1].ScrollingMessages:PageUp()
    end

    ChatFrame_ChatPageDown = function()
      addonTable.allChatFrames[1].ScrollingMessages:PageDown()
    end

    ChatFrame_ScrollToBottom = function()
      addonTable.allChatFrames[1].ScrollingMessages:ScrollToBottom()
    end
  end

  FloatingChatFrameManager:UnregisterAllEvents()

  -- Prevent custom tabs generated from Blizzard tabs getting hidden on login
  -- ie combat log is immediately hidden because the Blizz code thinks it is definitely not visible
  -- (we handle that ourselves)
  local oldSetScript = GeneralDockManager.SetScript
  GeneralDockManager:SetScript("OnSizeChanged", nil)
  hooksecurefunc(GeneralDockManager, "SetScript", function()
    oldSetScript(GeneralDockManager, "OnSizeChanged", nil)
    oldSetScript(GeneralDockManager, "OnUpdate", nil)
  end)

  local allowedEventsFrameAll = {
    "UPDATE_CHAT_COLOR",
  }
  local allowedEventsFrame1 = {
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_BN_WHISPER",
    "CAUTIONARY_CHAT_MESSAGE",
  }

  -- We delay unregistering so that the chat frame colours get applied properly,
  -- and then ensure that chat colour events get processed, both to avoid errors
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("PLAYER_ENTERING_WORLD")
  frame:RegisterEvent("VARIABLES_LOADED")
  frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_ENTERING_WORLD" then
      frame:UnregisterEvent("PLAYER_ENTERING_WORLD")
      C_Timer.After(0, function()
        for _, tabName in pairs(CHAT_FRAMES) do
          local tab = _G[tabName]
          if tab:GetParent() == UIParent then
            tab:SetParent(addonTable.hiddenFrame)
          end
          if tabName ~= "ChatFrame2" then
            tab:UnregisterAllEvents()
            tab:RegisterEvent("UPDATE_CHAT_COLOR") -- Needed to prevent errors in OnUpdate from UIParent
            -- Workaround for addons trying to prevent messages showing in chat frame by unregistering and reregistering events
            hooksecurefunc(tab, "RegisterEvent", function(_, name)
              if tabName == "ChatFrame1" and tIndexOf(allowedEventsFrame1, name) == nil or tabName ~= "ChatFrame1" and tIndexOf(allowedEventsFrameAll, name) == nil then
                tab:UnregisterEvent(name)
              end
            end)
          end
          if tabName == "ChatFrame1" then
            for _, e in ipairs(allowedEventsFrame1) do
              if C_EventUtils.IsEventValid(e) then
                tab:RegisterEvent(e)
              end
            end
          end
          tab:HookScript("OnEvent", function(_, e)
            if e == "UPDATE_CHAT_WINDOWS" then
              tab:UnregisterEvent("UPDATE_CHAT_WINDOWS")
              tab:UnregisterEvent("UPDATE_FLOATING_CHAT_WINDOWS")
            end
          end)
          local tabButton = _G[tabName .. "Tab"]
          tabButton:SetParent(addonTable.hiddenFrame)
          local SetParent = tabButton.SetParent
          hooksecurefunc(tabButton, "SetParent", function(self) SetParent(self, addonTable.hiddenFrame) end)
        end
        _G["ChatFrame1Tab"].IsVisible = function() return true end -- Workaround for TSM assuming chat tabs are always visible
      end)
    elseif event == "VARIABLES_LOADED" then
      C_CVar.SetCVar("whisperMode", "inline")
    end
  end)

  EventUtil.ContinueOnAddOnLoaded("Blizzard_Communities", function()
    C_Timer.After(0, function()
      local font, height, flags = _G[addonTable.Messages.font]:GetFont()
      CommunitiesFrame.Chat.MessageFrame:SetFont(font, height * addonTable.Messages.scalingFactor, flags)
    end)
  end)

  if ChatFrameUtil and ChatFrameUtil.DeactivateChat then
    local updater = CreateFrame("Frame")
    hooksecurefunc(ChatFrameUtil, "DeactivateChat", function(editBox)
      if editBox == ChatFrame1EditBox then
        local visible = addonTable.Config.Get(addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE)
        editBox:SetShown(visible)
        if visible then
          editBox:SetAlpha(1)
        end
        updater:SetScript("OnUpdate", function()
          updater:SetScript("OnUpdate", nil)
          editBox:SetShown(visible)
          if visible then
            editBox:SetAlpha(1)
          end
        end)
      else
        editBox:Hide()
      end
    end)
    hooksecurefunc(ChatFrameUtil, "ActivateChat", function(editBox)
      editBox:Show()
    end)
  else
    hooksecurefunc("ChatEdit_DeactivateChat", function(editBox)
      if editBox == ChatFrame1EditBox then
        local visible = addonTable.Config.Get(addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE)
        editBox:SetShown(visible)
        if visible then
          editBox:SetAlpha(1)
        end
      else
        editBox:Hide()
      end
    end)
    hooksecurefunc("ChatEdit_ActivateChat", function(editBox)
      editBox:Show()
    end)
  end

  addonTable.CallbackRegistry:RegisterCallback("SettingChanged", function(_, settingName)
    if settingName == addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE then
      ChatFrame1EditBox:SetShown(addonTable.Config.Get(addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE))
    end
  end)

  local function UpdateHeader(editBox)
    if editBox ~= ChatFrame1EditBox then
      return
    end
    local allColors = addonTable.Config.Get(addonTable.Config.Options.CHAT_COLORS)
    local chatType = editBox:GetAttribute("chatType")
    local color
    if chatType == "CHANNEL" then
      local channel = editBox:GetAttribute("channelTarget") and GetChannelName(editBox:GetAttribute("channelTarget")) or 0
      color = allColors[chatType .. channel] or allColors[chatType]
    else
      color = allColors[chatType]
    end
    if color then
      editBox:SetTextColor(color.r, color.g, color.b)
      for _, r in pairs({ChatFrame1EditBox:GetRegions()}) do
        if r:IsObjectType("FontString") and r:GetParentKey() == nil then
          r:SetTextColor(color.r, color.g, color.b)
        end
      end
      editBox.header:SetTextColor(color.r, color.g, color.b)
      editBox.headerSuffix:SetTextColor(color.r, color.g, color.b)
      if editBox.focusLeft then
        editBox.focusLeft:SetVertexColor(color.r, color.g, color.b)
        editBox.focusRight:SetVertexColor(color.r, color.g, color.b)
        editBox.focusMid:SetVertexColor(color.r, color.g, color.b)
      end
    end
  end
  if ChatFrame1EditBox.UpdateHeader then
    hooksecurefunc(ChatFrame1EditBox, "UpdateHeader", UpdateHeader)
  else
    hooksecurefunc("ChatEdit_UpdateHeader", UpdateHeader)
  end
end
