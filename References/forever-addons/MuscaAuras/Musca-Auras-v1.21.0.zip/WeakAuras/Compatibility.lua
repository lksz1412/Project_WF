-- This file is only for base functions that work differently or are deprecated in some versions of wow

if not WeakAuras.IsLibsOK() then return end
---@type string
local AddonName = ...
---@class Private
local Private = select(2, ...)

Private.ExecEnv.GetSpellInfo = function(spellID)
  if not spellID then
    return nil
  end
  local spellInfo = C_Spell.GetSpellInfo(spellID)
  if spellInfo then
    return spellInfo.name, nil, spellInfo.iconID, spellInfo.castTime, spellInfo.minRange, spellInfo.maxRange, spellInfo.spellID, spellInfo.originalIconID
  end
end
Private.ExecEnv.GetSpellName = C_Spell.GetSpellName
Private.ExecEnv.GetSpellIcon = C_Spell.GetSpellTexture
Private.ExecEnv.IsUsableSpell = C_Spell.IsSpellUsable

if C_SpecializationInfo and C_SpecializationInfo.GetSpecialization then
  Private.ExecEnv.GetSpecialization = C_SpecializationInfo.GetSpecialization
else
  Private.ExecEnv.GetSpecialization = GetSpecialization
end
if C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfo then
  Private.ExecEnv.GetSpecializationInfo = C_SpecializationInfo.GetSpecializationInfo
else
  Private.ExecEnv.GetSpecializationInfo = GetSpecializationInfo
end
if C_SpecializationInfo and C_SpecializationInfo.GetNumSpecializationsForClassID then
  Private.ExecEnv.GetNumSpecializationsForClassID = C_SpecializationInfo.GetNumSpecializationsForClassID
else
  Private.ExecEnv.GetNumSpecializationsForClassID = GetNumSpecializationsForClassID
end
Private.hasNativeSwingTimer = C_SwingTimer ~= nil and Enum ~= nil and Enum.PlayerSwingType ~= nil

Private.hasSpecializations = C_SpecializationInfo ~= nil and C_SpecializationInfo.GetSpecialization ~= nil and C_SpecializationInfo.GetNumSpecializationsForClassID ~= nil and GetSpecializationInfoForClassID ~= nil

Private.traitTalents = (Private.hasSpecializations and C_Traits ~= nil
  and C_SpecializationInfo.GetActiveSpecGroup ~= nil and C_SpecializationInfo.GetCombatConfigIDForSpecGroup ~= nil)

Private.ExecEnv.GetSpecializationInfoForClassID = GetSpecializationInfoForClassID

if C_SpecializationInfo and C_SpecializationInfo.GetTalentInfo then
  -- copy pasta from
  -- Interface/AddOns/Blizzard_DeprecatedSpecialization/
  -- ├─ Deprecated_Specialization_Vanilla.lua
  -- ├─ Deprecated_Specialization_TBC.lua
  -- ├─ Deprecated_Specialization_Wrath.lua
  -- └─ Deprecated_Specialization_Cata.lua
  Private.ExecEnv.GetTalentInfo = function(tabIndex, talentIndex, isInspect, isPet, groupIndex)
    local talentInfoQuery = {}
    talentInfoQuery.specializationIndex = tabIndex
    talentInfoQuery.talentIndex = talentIndex
    talentInfoQuery.isInspect = isInspect
    talentInfoQuery.isPet = isPet
    talentInfoQuery.groupIndex = groupIndex
    local ok, talentInfo = pcall(C_SpecializationInfo.GetTalentInfo, talentInfoQuery)
    if not ok or not talentInfo then
      return nil
    end

  return talentInfo.name, talentInfo.icon, talentInfo.tier, talentInfo.column, talentInfo.rank,
    talentInfo.maxRank, talentInfo.meetsPrereq, talentInfo.previewRank,
    talentInfo.meetsPreviewPrereq, talentInfo.isExceptional, talentInfo.hasGoldBorder,
    talentInfo.talentID
  end
end

Private.ExecEnv.GetNumFactions = C_Reputation.GetNumFactions or GetNumFactions

Private.ExecEnv.GetFactionDataByIndex = C_Reputation.GetFactionDataByIndex or function(index)
  local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild, factionID, hasBonusRepGain, canSetInactive = GetFactionInfo(index)
  return {
    factionID = factionID,
    name = name,
    description = description,
    reaction = standingID,
    currentReactionThreshold = barMin,
    nextReactionThreshold = barMax,
    currentStanding = barValue,
    atWarWith = atWarWith,
    canToggleAtWar = canToggleAtWar,
    isChild = isChild,
    isHeader = isHeader,
    isHeaderWithRep = hasRep,
    isCollapsed = isCollapsed,
    isWatched = isWatched,
    hasBonusRepGain = hasBonusRepGain,
    canSetInactive = canSetInactive,
    isAccountWide = nil
  }
end

Private.ExecEnv.GetFactionDataByID = C_Reputation.GetFactionDataByID or function(ID)
  local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild, factionID, hasBonusRepGain, canSetInactive = GetFactionInfoByID(ID)
  return {
    factionID = factionID,
    name = name,
    description = description,
    reaction = standingID,
    currentReactionThreshold = barMin,
    nextReactionThreshold = barMax,
    currentStanding = barValue,
    atWarWith = atWarWith,
    canToggleAtWar = canToggleAtWar,
    isChild = isChild,
    isHeader = isHeader,
    isHeaderWithRep = hasRep,
    isCollapsed = isCollapsed,
    isWatched = isWatched,
    hasBonusRepGain = hasBonusRepGain,
    canSetInactive = canSetInactive,
    isAccountWide = nil
  }
end

-- GetWatchedFactionData behaves differentlly, but we only need the Id, so do a trival wrapper
if C_Reputation.GetWatchedFactionData then
  Private.ExecEnv.GetWatchedFactionId = function()
    local data = C_Reputation.GetWatchedFactionData()
    return data and data.factionID or nil
  end
else
  Private.ExecEnv.GetWatchedFactionId = function()
    return select(6, GetWatchedFactionInfo())
  end
end

Private.ExecEnv.ExpandFactionHeader = C_Reputation.ExpandFactionHeader or ExpandFactionHeader
Private.ExecEnv.CollapseFactionHeader = C_Reputation.CollapseFactionHeader or CollapseFactionHeader
Private.ExecEnv.AreLegacyReputationsShown = C_Reputation.AreLegacyReputationsShown or function() return true end
Private.ExecEnv.GetReputationSortType = C_Reputation.GetReputationSortType or function() return 0 end;
