--[[
	Copyright (C) 2006-2007 Nymbia
	Copyright (C) 2010-2017 Hendrik "Nevcairiel" Leppkes < h.leppkes@gmail.com >

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
]]
local Quartz3 = LibStub("AceAddon-3.0"):GetAddon("Quartz3")
local L = LibStub("AceLocale-3.0"):GetLocale("Quartz3")

local MODNAME = "Flight"
local Flight = Quartz3:NewModule(MODNAME, "AceHook-3.0")
local Player = Quartz3:GetModule("Player")

local WoWClassic = (WOW_PROJECT_ID == WOW_PROJECT_CLASSIC)

local db, getOptions

local defaults = {
	profile = {
		color = {0.7, 1, 0.7},
		deplete = false,
		},
	}

do
	local options
	function getOptions()
	options = options or {
		type = "group",
		name = L["Flight"],
		order = 600,
		args = {
			toggle = {
				type = "toggle",
				name = L["Enable"],
				get = function()
					return Quartz3:GetModuleEnabled(MODNAME)
				end,
				set = function(info, v)
					Quartz3:SetModuleEnabled(MODNAME, v)
				end,
				order = 100,
			},
			color = {
				type = "color",
				name = L["Flight Map Color"],
				desc = L["Set the color to turn the cast bar when taking a flight path"],
				get = function() return unpack(db.color) end,
				set = function(info, ...) db.color = {...} end,
				order = 101,
			},
			deplete = {
				type = "toggle",
				name = L["Deplete"],
				desc = L["Deplete"],
				get = function() return db.deplete end,
				set = function(info, v) db.deplete = v end,
				order = 102,
			},
		},
	}
	return options
	end
end


function Flight:OnInitialize()
	self.db = Quartz3.db:RegisterNamespace(MODNAME, defaults)
	db = self.db.profile

	self:SetEnabledState(Quartz3:GetModuleEnabled(MODNAME))
	Quartz3:RegisterModuleOptions(MODNAME, getOptions, L["Flight"])
end

function Flight:OnEnable()
	self:RegisterEvent("TAXIMAP_OPENED")
end

function Flight:OnDisable()
	self:UnregisterAllEvents()
end

function Flight:ApplySettings()
	db = self.db.profile
end

function Flight:TAXIMAP_OPENED()
	local loaded = C_AddOns.LoadAddOn("InFlight")
	if loaded then
		function Flight.OnEnable(_self)
			self:SecureHook(InFlight, "StartTimer")
		end

		function Flight.StartTimer(_self)
			InFlightBar:Hide()
			local duration = InFlight:GetFlightTime()
			if duration and duration > 0 then
				self:BeginFlight(duration, InFlight:GetDestination())
			end
		end

		-- Execute the new OnEnable to hook InFlight
		if Flight:IsEnabled() then
			Flight:OnEnable()
		end

		self:UnregisterEvent("TAXIMAP_OPENED")
	end
end

--[[if FlightMapTimes_BeginFlight then
	function Flight:OnEnable()
		self:RawHook("FlightMapTimes_BeginFlight")
	end

	function Flight:FlightMapTimes_BeginFlight(duration, destination)
		if duration and duration > 0 then
			self:BeginFlight(duration, destination)
		end
		return self.hooks.FlightMapTimes_BeginFlight(duration, destination)
	end
end]]

function Flight:BeginFlight(duration, destination)
	if not Player:IsEnabled() then return end

	local flightDuration = C_DurationUtil.CreateDuration()
	flightDuration:SetTimeFromStart(GetTime(), duration)

	Player.Bar.Bar:SetStatusBarColor(unpack(db.color))

	Player.Bar:StartTimer(flightDuration, db.deplete)
	Player.Bar:Show()
	Player.Bar:SetAlpha(Player.db.profile.alpha)

	if WoWClassic then
		Player.Bar.Icon:SetTexture("Interface\\Icons\\ability_eyeoftheowl")
	else
		Player.Bar.Icon:SetTexture("Interface\\Icons\\ability_druid_flightform")
	end
	Player.Bar.Text:SetText(destination)

	local position = Player.db.profile.timetextposition
	if position == "caststart" then
		Player.Bar.TimeText:SetPoint("LEFT", Player.Bar.Bar, "LEFT", Player.db.profile.timetextx, Player.db.profile.timetexty)
		Player.Bar.TimeText:SetJustifyH("LEFT")
	elseif position == "castend" then
		Player.Bar.TimeText:SetPoint("RIGHT", Player.Bar.Bar, "RIGHT", -1 * Player.db.profile.timetextx, Player.db.profile.timetexty)
		Player.Bar.TimeText:SetJustifyH("RIGHT")
	end
end
