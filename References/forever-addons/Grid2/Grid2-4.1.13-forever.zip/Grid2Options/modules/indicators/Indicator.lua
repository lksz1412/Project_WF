-- Library of common/shared methods

local Grid2Options = Grid2Options
local L = Grid2Options.L

-- Grid2Options:MakeIndicatorStatusOptions()
-- Grid2Options:MakeStatusIndicatorOptions()
do
	local editedIndicator

	local function GetIndicatorNewPriority(indicator)
		local priority = 50
		local map = Grid2:DbGetValue('statusMap', indicator.name)
		if map then
			for _,p in pairs(map) do
				p = tonumber(p)
				if p and p>=priority then
					priority = p+1
				end
			end
		end
		return priority
	end

	local function RegisterIndicatorStatus(indicator, status, value)
		if value then
			local priority = GetIndicatorNewPriority(indicator)
			Grid2:DbSetMap(indicator.name, status.name, priority)
			indicator:RegisterStatus(status, priority)
		else
			Grid2:DbSetMap(indicator.name, status.name, nil)
			indicator:UnregisterStatus(status)
		end
		if indicator.parentName then
			Grid2Options:RefreshIndicator(Grid2:GetIndicatorByName(indicator.parentName), "Layout")
		else
			Grid2Options:RefreshIndicator(indicator, "Layout")
		end
	end

	local function GetIndexOfValue(map, status)
		for i, s in ipairs(map) do
			if s == status then
				return i
			end
		end
	end

	local function LoadStatusMap(indicator)
		local map = {}
		local dbx = Grid2:DbGetValue("statusMap", indicator.name)
		if dbx then
			for statusKey, priority in pairs(dbx) do
				local status = Grid2:GetStatusByName(statusKey)
				if status then
					map[#map+1] = status
					map[status] = priority
				end
			end
		end
		table.sort( map, function(a,b) return map[a] > map[b] end )
		return map
	end

	local function StatusShift(indicator, status, dir)
		local map = LoadStatusMap(indicator)
		local index1 = GetIndexOfValue(map, status)
		if index1 then
			local index2 = index1 + dir
			if index2<1 then
				index2 = #map
			elseif index2>#map then
				index2 = 1
			end
			local status1 = map[index1]
			local status2 = map[index2]
			local priority1 = map[status1]
			local priority2 = map[status2]
			Grid2:DbSetMap(indicator.name, status1.name, priority2)
			indicator:SetStatusPriority(status1, priority2)
			Grid2:DbSetMap(indicator.name, status2.name, priority1)
			indicator:SetStatusPriority(status2, priority1)
			Grid2Options:RefreshIndicator(indicator, "Layout")
		end
	end

	local function IsStatusVisible(indicator, status, categoryKey)
		return categoryKey==Grid2Options:GetStatusCategory(status) and
		       Grid2Options:IsCompatiblePair(indicator, status) and
		       not status.priorities[indicator] and
		       not indicator.priorities[status]
	end

	local function IsCategoryEmpty(info)
		local categoryKey = info[4]
		for statusKey, status in Grid2:IterateStatuses() do
			if IsStatusVisible(editedIndicator, status, categoryKey) then
				return false
			end
		end
		return true
	end

	local function AreCurrentStatusesIncompatible(indicator)
		if indicator then
			if indicator.dbx.type=='icons' then
				return indicator.auraMode and indicator.iconMode and "Warning: This indicator does not support mixing auras and non-auras statuses. Remove some statuses from this list."
			elseif indicator.dbx.type=='bar' or indicator.dbx.type=='multibar' then
				local maxSlots = Grid2.db.profile.formatting.maxAuraColorSlots or 3
				return (indicator.auraMode or 1)>maxSlots and string.format("Warning: Only a maximum of %d aura statuses can be assigned to this indicator. Remove some statuses from this list.",maxSlots)
			elseif (indicator.auraMode or 1)>1 then
				return "Warning: Only one aura status can be assigned to this indicator. Remove some statuses from this list."
			end
		end
	end

	local sharedOptions = {

		current = {
			type = "multiselect", dialogControl = "Grid2IndicatorCurrentStatuses",
			order = 1,
			width = "full",
			name = L["Current Statuses"],
			desc = L["Current statuses in order of priority"],
			values = function(info)
				local values = {}
				local dbx = Grid2:DbGetValue( "statusMap", editedIndicator.name )
				if dbx then
					for statusKey, priority in pairs(dbx) do
						local status = Grid2:GetStatusByName(statusKey)
						if status then
							values[ string.format("%04d:%s",1000-priority,statusKey) ] = Grid2Options.LocalizeStatus(status)
						end
					end
				end
				return values
			end,
			get = true,
			set = function (info, cmd, key)
				if not key then return end
				local status = Grid2:GetStatusByName( select(2,strsplit(':', key, 2)) )
				if not status then return end
				local indicator = editedIndicator
				if cmd == 'rm' then
					RegisterIndicatorStatus(indicator, status, false)
				elseif cmd == 'up' then
					StatusShift(indicator, status, -1)
				elseif cmd == 'dn' then
					StatusShift(indicator, status, 1)
				else
					Grid2Options:SelectGroup('statuses')
					Grid2Options:RefreshOptions()
					Grid2Options:SelectGroup('statuses', Grid2Options:GetStatusCategory(status), status.name)
				end
				-- Grid2Options:RefreshOptions()
			end,
		},

		msg = { type = "description", order = 0.5, fontSize = "medium",
			name = function() return string.format("|cffFC6A03%s|r", L[AreCurrentStatusesIncompatible(editedIndicator) or ''] ) end,
			hidden = function() return not AreCurrentStatusesIncompatible(editedIndicator) end,
		},

		title = { type = "description", order = 2, fontSize = "medium", name = string.format("|cffffd200    %s|r",L["Available Statuses"]) },
	}

	local sharedStatuses = {
		type = "multiselect", dialogControl = "Grid2SimpleMultiselect", width = "full", order = 1,	name = "",
		values = function(info)
			local values = {}
			local categoryKey = info[4]
			local indicator = editedIndicator
			for statusKey, status in Grid2:IterateStatuses() do
				if IsStatusVisible(indicator, status, categoryKey) then
					values[statusKey] = Grid2Options.LocalizeStatus(status)
				end
			end
			return values
		end,
		get = false,
		set = function(info, statusName)
			local status = Grid2:GetStatusByName(statusName)
			RegisterIndicatorStatus(editedIndicator, status, true)
		end,
	}

	-- Grid2Options:MakeIndicatorStatusOptions()
	function Grid2Options:MakeIndicatorStatusOptions(indicator, options)
		for key, data in pairs(self.categories) do
			sharedOptions[key] = {
				type = "group", order = data.order,
				name = ' ' .. data.name,
				args = {statuses = sharedStatuses},
				hidden = IsCategoryEmpty,
			}
		end
		self.MakeIndicatorStatusOptions = function(self, indicator, options)
			options.__load = { type = "header", order = 0, name = "", hidden = function() editedIndicator = indicator; return true end }
			for k,v in pairs(sharedOptions) do
				options[k] = v
			end
		end
		self:MakeIndicatorStatusOptions(indicator,options)
	end

	-- Grid2Options:MakeStatusIndicatorOptions()
	function Grid2Options:MakeStatusIndicatorsOptions( status, options )
		options.indicators = {
			type = "multiselect",  dialogControl = "Grid2SimpleMultiselect",
			order = 10,
			name = "",
			values = function()
				return self:GetAvailableIndicatorValues(status)
			end,
			get = function(info,key)
				local dbx = Grid2:DbGetValue("statusMap", key)
				return dbx and dbx[status.name]~=nil
			end,
			set = function(info,key,value)
				local indicator = Grid2.indicators[key]
				if indicator.dbx.type~='multibar' then
					RegisterIndicatorStatus(indicator, status, value)
					self:RefreshIndicatorOptions(indicator)
				else
					self:MessageDialog(L['This indicator cannot be changed from here: go to indicators section to assign/unassign statuses to this indicator.'])
				end
			end,
		}
		return options
	end
end

-- Grid2Options:MakeIndicatorTypeOptions()
do
	local typeMorphValue  = {}
	local typeMorphValues = { icon = L["icon"], square = L["square"], shape = L["shape"], text = L["text"], textaura = L["textaura"] }

	local function GetIndicatorTypeValues(info)
		local typeKey = info.arg.dbx.type
		if not typeMorphValues[typeKey] then
			wipe(typeMorphValue)
			typeMorphValue[typeKey] = L[typeKey]
			return typeMorphValue
		end
		return typeMorphValues
	end

	local function GetIndicatorTypeDisabled(info)
		return not typeMorphValues[info.arg.dbx.type]
	end

	local function GetIndicatorType(info)
		return info.arg.dbx.type
	end

	local function SetIndicatorType(info, value)
		local indicator = info.arg
		local baseKey = indicator.name
		local dbx = indicator.dbx
		local colorKey = baseKey.."-color"
		local oldType = dbx.type

		if dbx.type == value then return end

		-- Set new fields width defaults values
		dbx.type = value
		dbx.animEnabled = nil
		for k, v in pairs(Grid2Options.indicatorDefaultValues[value] or {}) do
			if not dbx[k] then
				indicator.dbx[k] = v
				dbx[k] = v
			end
		end
		-- Remove old indicator
		Grid2:UnregisterIndicator(indicator)
		-- Create new indicator
		local setupFunc = Grid2.setupFunc[dbx.type]
		local newIndicator = setupFunc(baseKey, dbx)
		-- Remove incompatible statuses from database
		local map = Grid2:DbGetValue("statusMap", baseKey)
		if map then
			for statusKey, priority in pairs(map) do
				local status = Grid2.statuses[statusKey]
				if (not status) or (not Grid2Options:IsCompatiblePair(newIndicator, status)) then
					map[statusKey]= nil
				end
			end
		end
		-- Register indicator statuses from database
		Grid2Options:RegisterIndicatorStatuses(newIndicator)
		Grid2Options:RegisterIndicatorStatuses(newIndicator.sideKick)
		-- Recreate indicators in frame units
		Grid2Options:CreateIndicatorFrames(newIndicator)
		-- Delete or Create associated text-color indicator in database
		if oldType=="text" then
			Grid2:DbSetIndicator(colorKey, nil)
		elseif value=="text" then
			Grid2:DbSetIndicator(colorKey , { type="text-color" })
		end
		-- Update unit frames
		Grid2Frame:UpdateIndicators()
		-- Create new indicator options
		Grid2Options:MakeIndicatorOptions(newIndicator)
	end

	function Grid2Options:MakeIndicatorTypeOptions(indicator, options, optionParams)
		options.indicatorType = {
			type = 'select',
			order = 1.91,
			name = L["Indicator Type"],
			desc = L["Change the indicator type"],
			values = GetIndicatorTypeValues,
			get = GetIndicatorType,
			set = SetIndicatorType,
			confirm = true,
			confirmText = L["Are you sure do you want to convert the indicator to the new selected type?"],
			arg = indicator,
		}
	end
end

-- Grid2Options:MakeIndicatorLevelOptions()
do
	local levelValues = { 1,2,3,4,5,6,7,8,9 }
	function Grid2Options:MakeIndicatorLevelOptions(indicator, options)
		options.frameLevel = {
			type = "select",
			order = 1.92,
			name = L["Frame Level"],
			desc = L["Bars with higher numbers always show up on top of lower numbers."],
			get = function ()
				return indicator.dbx.level or 1
			end,
			set = function (_, v)
				indicator.dbx.level = v
				self:RefreshIndicator(indicator, "Layout")
			end,
			values = levelValues,
		}
	end
end

-- Grid2Options:MakeIndicatorTypeLevelOptions()
function Grid2Options:MakeIndicatorTypeLevelOptions(indicator, options)
	self:MakeHeaderOptions( options, "General" )
	self:MakeIndicatorTypeOptions( indicator, options )
	self:MakeIndicatorLevelOptions( indicator, options )
end

-- Grid2Options:MakeIndicatorSizeOptions()
function Grid2Options:MakeIndicatorIconSizeOptions(indicator, options, optionParams)
	options.sizeSource = {
		type = "select",
		order = 10.1,
		name = L["Icon Size"],
		desc = L["Default:\nUse the size specified by the active theme.\nPixels:\nUser defined size in pixels.\nPercent:\nUser defined size as percent of the frame height."],
		get = function (info) return (indicator.dbx.size==nil and 1) or (indicator.dbx.size>1 and 2) or 3 end,
		set = function (info, v)
			indicator.dbx.size = (v==3 and .4) or (v==2 and 14) or nil
			self:RefreshIndicator(indicator, "Layout")
		end,
		values = { L["Default"], L["Pixels"], L["Percent"] },
	}
	options.sizeAbsolute = {
		type = "range",
		order = 10.2,
		name = L["Icon Size"],
		desc = L["Adjust the size of the icon."],
		min = 5,
		softMax = 50,
		step = 1,
		get = function ()
			return indicator.dbx.size or Grid2Frame.db.profile.iconSize
		end,
		set = function (_, v)
			indicator.dbx.size = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		disabled = function() return indicator.dbx.size==nil end,
		hidden = function()	return (indicator.dbx.size or Grid2Frame.db.profile.iconSize or 0)<=1 end,
	}
	options.sizeRelative = {
		type = "range",
		order = 10.3,
		name = L["Icon Size"],
		desc = L["Adjust the size of the icon."],
		min = 0.01,
		max = 1,
		step = 0.01,
		isPercent = true,
		get = function ()
			return indicator.dbx.size or Grid2Frame.db.profile.iconSize
		end,
		set = function (_, v)
			indicator.dbx.size = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		disabled = function() return indicator.dbx.size==nil end,
		hidden = function() return (indicator.dbx.size or Grid2Frame.db.profile.iconSize or 1)>1 end,
	}
end

-- Grid2Options:MakeIndicatorSizeOptions()
function Grid2Options:MakeIndicatorSizeOptions(indicator, options, optionParams)
	options.size = {
		type = "range",
		order = 10,
		name = L["Size"],
		desc = L["Adjust the size of the indicator."],
		min = 5,
		max = 50,
		step = 1,
		get = function ()
			return indicator.dbx.size
		end,
		set = function (_, v)
			indicator.dbx.size = v
			self:RefreshIndicator(indicator, "Layout")
		end,
	}
end

-- Grid2Options:MakeIndicatorBorderSizeOptions()
function Grid2Options:MakeIndicatorBorderSizeOptions(indicator, options, optionParams)
	options.borderSize = {
		type = "range",
		order = 20,
		name = L["Border Size"],
		desc = L["Adjust the border size of the indicator."],
		min = 0,
		max = 20,
		step = 0.01,
		bigStep = 1,
		get = function () return indicator.dbx.borderSize or 0 end,
		set = function (_, v)
			if v == 0 then v = nil end
			indicator.dbx.borderSize = v
			self:RefreshIndicator(indicator, (optionParams and optionParams.RefreshMethod) or "Layout")
		end,
	}
end

-- Grid2Options:MakeIndicatorTextureOptions()
function Grid2Options:MakeIndicatorTextureOptions(indicator, options, optionParams)
	options.texture = {
		type = "select", dialogControl = "LSM30_Statusbar",
		order = 11,
		name = L["Frame Texture"],
		desc = L["Adjust the texture of the indicator."],
		get = function (info) return indicator.dbx.texture or "Grid2 Flat" end,
		set = function (info, v)
			indicator.dbx.texture = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		values = AceGUIWidgetLSMlists.statusbar,
	}
end

-- Grid2Options:MakeIndicatorBorderOptions()
function Grid2Options:MakeIndicatorBorderOptions(indicator, options, optionParams)
	optionParams = optionParams or {}
	optionParams.color1 = L["Border Color"]
	optionParams.colorDesc1 = L["Adjust border color and alpha."]
	self:MakeHeaderOptions( options, "Border" )
	self:MakeIndicatorBorderSizeOptions(indicator, options, optionParams)
	self:MakeIndicatorColorOptions(indicator, options, optionParams)
end

-- Grid2Options:MakeIndicatorColorOptions()
do
	local function GetIndicatorColor(info)
		local indicator = info.arg.indicator
		local colorKey  = "color" .. info.arg.colorIndex
		local c = indicator.dbx[ colorKey ]
		if c then return c.r, c.g, c.b, c.a end
		return 0, 0, 0, 0
	end
	local function SetIndicatorColor(info, r, g, b, a)
		local colorKey   = "color" .. info.arg.colorIndex
		local indicator  = info.arg.indicator
		local dbx = indicator.dbx
		local c = dbx[colorKey]
		if not c then c = {}; dbx[colorKey] = c end
		c.r, c.g, c.b, c.a = r, g, b, a
		Grid2Options:RefreshIndicator(indicator, "Layout")
	end
	function Grid2Options:MakeIndicatorColorOptions(indicator, options, optionParams)
		local colorCount = indicator.dbx.colorCount or 1
		local name = L["Color"]
		local desc = L["Color for %s."]:format(indicator.name)
		for i = 1, colorCount, 1 do
			local colorKey = "color" .. i
			if (optionParams and optionParams[colorKey]) then
				name = optionParams[colorKey]
			elseif (colorCount > 1) then
				name = L["Color %d"]:format(i)
			end
			local colorDescKey = "colorDesc" .. i
			if (optionParams and optionParams[colorDescKey]) then
				desc = optionParams[colorDescKey]
			elseif (colorCount > 1) then
				desc = name
			end
			options[colorKey] = {
				type = "color",
				order = (20 + i),
				name = name,
				desc = desc,
				get = GetIndicatorColor,
				set = SetIndicatorColor,
				hasAlpha = true,
				arg = {indicator = indicator, colorIndex = i},
			}
		end
	end
end

-- Grid2Options:MakeIndicatorLocationOptions()
function Grid2Options:MakeIndicatorLocationOptions(indicator, options)
	local location  = indicator.dbx.location
	self:MakeHeaderOptions( options, "Location" )
	options.relPoint = {
		type = 'select',
		order = 4,
		name = L["Location"],
		desc = L["Align my align point relative to"],
		values = self.pointValueList,
		get = function() return self.pointMap[location.relPoint] end,
		set = function(_, v)
			location.relPoint = self.pointMap[v]
			location.point = location.relPoint
			self:RefreshIndicator(indicator, "Layout")
		end,
	}
	options.point = {
		type = 'select',
		order = 5,
		name = L["Align Point"],
		desc = L["Align this point on the indicator"],
		values = self.pointValueList,
		get = function() return self.pointMap[location.point] end,
		set = function(_, v)
			location.point = self.pointMap[v]
			self:RefreshIndicator(indicator, "Layout")
		end,
	}
	options.x = {
		type = "range",
		order = 7,
		name = L["X Offset"],
		desc = L["X - Horizontal Offset"],
		softMin = -50, softMax = 50, step = 1, bigStep = 1,
		get = function() return location.x end,
		set = function(_, v)
			location.x = v
			self:RefreshIndicator(indicator, "Layout")
		end,
	}
	options.y = {
		type = "range",
		order = 8,
		name = L["Y Offset"],
		desc = L["Y - Vertical Offset"],
		softMin = -50, softMax = 50, step = 1, bigStep = 1,
		get = function() return location.y end,
		set = function(_, v)
			location.y = v
			self:RefreshIndicator(indicator, "Layout")
		end,
	}
end

-- Grid2Options:MakeIndicatorCooldownOptions()
function Grid2Options:MakeIndicatorCooldownOptions(indicator, options)
	self:MakeIndicatorCooldownAnimOptions(indicator, options)
	self:MakeIndicatorCooldownTextOptions(indicator, options)
	self:MakeIndicatorCooldownBarOptions(indicator, options)
	self:MakeIndicatorCooldownColorsOptions(indicator, options)
end

-- Grid2Options:MakeIndicatorCooldownAnimOptions()
function Grid2Options:MakeIndicatorCooldownAnimOptions(indicator, options)
	self:MakeHeaderOptions( options, "CoolAnim" )
	options.disableCooldown = {
		type = "toggle",
		order = 210,
		name = L["Show Animation"],
		desc = L["Show the Cooldown Animation Texture"],
		tristate = false,
		get = function () return not indicator.dbx.disableCooldown end,
		set = function (_, v)
			indicator.dbx.disableCooldownAnim = nil -- reset setting not used in midnight
			indicator.dbx.disableCooldown = not v or nil
			self:RefreshIndicator(indicator, "Create")
		end,
	}
	options.reverseCooldown = {
		type = "toggle",
		order = 211,
		name = L["Reverse Animation"],
		desc = L["Set cooldown to become darker over time instead of lighter."],
		tristate = false,
		get = function () return indicator.dbx.reverseCooldown end,
		set = function (_, v)
			indicator.dbx.reverseCooldown = v or nil
			self:RefreshIndicator(indicator, "Create")
		end,
		hidden= function() return indicator.dbx.disableCooldown end,
	}
	options.drawEdge = {
		type = "toggle",
		order = 212,
		name = L["Draw Edge"],
		desc = L["Show a bright line on the moving edge of the cooldown animation."],
		tristate = false,
		get = function () return indicator.dbx.drawEdge end,
		set = function (_, v)
			indicator.dbx.drawEdge = v or nil
			self:RefreshIndicator(indicator, "Create")
		end,
		hidden= function() return indicator.dbx.disableCooldown end,
	}
end

-- Grid2Options:MakeIndicatorCountdownTextOptions()
function Grid2Options:MakeIndicatorCooldownTextOptions(indicator, options)
	self:MakeHeaderOptions( options, "CoolText" )
	options.ctFontJustify = {
		type = 'select',
		order = 136,
		name = L["Text Location"],
		desc = L["Text Location"],
		values = Grid2Options.pointValueListExtra,
		get = function()
			if indicator.dbx.enableCooldownText then
				local JustifyH = indicator.dbx.ctFontJustifyH or "CENTER"
				local JustifyV = indicator.dbx.ctFontJustifyV or "MIDDLE"
				return self.pointMapText[ JustifyH..JustifyV ]
			end
			return "0"
		end,
		set = function(_, v)
			if v ~= "0" then
				local justify =  self.pointMapText[v]
				indicator.dbx.ctFontJustifyH = justify[1]
				indicator.dbx.ctFontJustifyV = justify[2]
				indicator.dbx.enableCooldownText = true
			else
				indicator.dbx.enableCooldownText = nil
			end
            self:RefreshIndicator(indicator, "Create")
		end,
	}
	options.ctFontsize1 = {
		type = "range",
		order = 137,
		name = L["Font Size"],
		desc = L["Adjust the font size."],
		softMin = 0,
		softMax = 32,
		step = 1,
		get = function () return indicator.dbx.ctFontSize or 9 end,
		set = function (_, v)
			if v==0 then v = 0.25 end
			indicator.dbx.ctFontSize = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownText==nil or (indicator.dbx.ctFontSize or 9)<1 end,
	}
	options.ctFontsize2 = {
		type = "range",
		order = 137,
		name = L["Font Size"],
		desc = L["Adjust the font size."],
		min = 0.01,
		max = 1,
		step = 0.01,
		isPercent = true,
		get = function () return indicator.dbx.ctFontSize end,
		set = function (_, v)
			if v>=1 then v = 9 end
			indicator.dbx.ctFontSize = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownText==nil or (indicator.dbx.ctFontSize or 9)>=1 end,
	}
	options.ctFont = {
		type = "select", dialogControl = "LSM30_Font",
		order = 138,
		name = L["Font"],
		desc = L["Adjust the font settings"],
		get = function (info) return indicator.dbx.ctFont or self.MEDIA_VALUE_DEFAULT end,
		set = function (info, v)
			indicator.dbx.ctFont = self.MEDIA_VALUE_DEFAULT~=v and v or nil
			self:RefreshIndicator(indicator, "Layout")
		end,
		values = self.GetFontValues,
		hidden= function() return indicator.dbx.enableCooldownText==nil end,
	}
	options.ctFontFlags = {
		type = "select",
		order = 139,
		name = L["Font Border"],
		desc = L["Set the font border type."],
		get = function ()
			local flags = indicator.dbx.fontFlags
			return (flags == nil and "OUTLINE") or (flags == "" and "NONE") or flags
		end,
		set = function (_, v)
			indicator.dbx.fontFlags =  v ~= "NONE" and v or ""
			self:RefreshIndicator(indicator, "Layout")
		end,
		values = Grid2Options.fontFlagsValues,
		hidden= function() return indicator.dbx.enableCooldownText==nil end,
	}
	options.ctFontOffsetX = {
		type = "range",
		order = 140,
		name = L["X Offset"],
		desc = L["Adjust the horizontal offset of the text"],
		softMin  = -50,
		softMax = 50,
		step = 1,
		get = function () return indicator.dbx.ctFontOffsetX or 0	end,
		set = function (_, v)
			indicator.dbx.ctFontOffsetX = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownText==nil end,
	}
	options.ctFontOffsetY = {
		type = "range",
		order = 141,
		name = L["Y Offset"],
		desc = L["Adjust the vertical offset of the text"],
		softMin  = -50,
		softMax = 50,
		step = 1,
		get = function () return indicator.dbx.ctFontOffsetY or 0	end,
		set = function (_, v)
			indicator.dbx.ctFontOffsetY = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownText==nil end,
	}
	options.ctUseStatusColor = {
		type = "toggle",
		order = 142,
		name = L["Use Status Color"],
		desc = L["Color the countdown text with the status color instead of the color below. Statuses that define their own cooldown colors will use those instead."],
		tristate = false,
		get = function () return indicator.dbx.ctUseStatusColor end,
		set = function (_, v)
			indicator.dbx.ctUseStatusColor = v or nil
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden = function() return indicator.dbx.enableCooldownText==nil end,
	}
	options.ctFontColor = {
		type = "color",
		order = 143,
		name = L["Color"],
		desc = L["Color"],
		hasAlpha = true,
		get = function() return self:UnpackColor( indicator.dbx.ctColor, "WHITE" ) end,
		set = function( info, r,g,b,a )
			self:PackColor( r,g,b,a, indicator.dbx, "ctColor" )
			self:RefreshIndicator(indicator, "Layout" )
		 end,
		hidden = function() return indicator.dbx.enableCooldownText==nil end,
		disabled = function() return indicator.dbx.ctUseStatusColor end,
	}
end

-- Grid2Options:MakeIndicatorCountdownTextOptions()
function Grid2Options:MakeIndicatorCooldownBarOptions(indicator, options)
	self:MakeHeaderOptions( options, "CoolBar" )
	options.cbPoint = {
		type = 'select',
		order = 151,
		name = L["Bar Location"],
		desc = L["Bar Location"],
		values = Grid2Options.pointValueListExtra2,
		get = function()
			if indicator.dbx.enableCooldownBar then
				return self.pointMap[indicator.dbx.cbPoint or 'BOTTOM']
			else
				return "0"
			end
		end,
		set = function(_, v)
			if v ~= "0" then
				indicator.dbx.cbPoint = self.pointMap[v]
				indicator.dbx.enableCooldownBar = true
			else
				indicator.dbx.enableCooldownBar = nil
			end
            self:RefreshIndicator(indicator, "Create")
		end,
	}
	options.cbThickness = {
		type = "range",
		order = 152.5,
		name = L["Thickness"],
		desc = L["Adjust the thickness of the bar."],
		softMin = 0,
		softMax = 32,
		step = 1,
		get = function () return indicator.dbx.cbThickness or 2 end,
		set = function (_, v)
			indicator.dbx.cbThickness = v
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownBar==nil end,
	}
	options.cbDirection = {
		type = "select",
		order = 152,
		name = L["Display"],
		desc = L["Display"],
		get = function ()
			return indicator.dbx.cbDirection or 1 end,
		set = function (_, v)
			indicator.dbx.cbDirection = (v==0) and 0 or nil
			self:RefreshIndicator(indicator, "Layout")
		end,
		values = { [0] = L["Elapsed Time"], [1] = L["Remaining Time"] },
		hidden= function() return indicator.dbx.enableCooldownBar==nil end,
	}
	options.ctReverse = {
		type = "toggle",
		order = 152.7,
		name = L["Reverse Bar Direction"],
		desc = L["Enable this option to reverse the direction of the bar."],
		tristate = false,
		get = function () return indicator.dbx.cbReverse end,
		set = function (_, v)
			indicator.dbx.cbReverse = v or nil
			self:RefreshIndicator(indicator, "Layout")
		end,
		hidden= function() return indicator.dbx.enableCooldownBar==nil end,
	}
	options.cbColor = {
		type = "color",
		order = 153,
		name = L["Foreground Color"],
		desc = L["Color of the Bar"],
		hasAlpha = true,
		get = function() return self:UnpackColor( indicator.dbx.cbColor, "WHITE" ) end,
		set = function( info, r,g,b,a )
			self:PackColor( r,g,b,a, indicator.dbx, "cbColor" )
			self:RefreshIndicator(indicator, "Layout" )
		 end,
		hidden = function() return indicator.dbx.enableCooldownBar==nil end,
	}
	options.cbColorBack = {
		type = "color",
		order = 154,
		name = L["Background Color"],
		desc = L["Background Color of the Bar"],
		hasAlpha = true,
		get = function() return self:UnpackColor( indicator.dbx.cbColorBack, "RED" ) end,
		set = function( info, r,g,b,a )
			self:PackColor( r,g,b,a, indicator.dbx, "cbColorBack" )
			self:RefreshIndicator(indicator, "Layout" )
		 end,
		hidden = function() return indicator.dbx.enableCooldownBar==nil end,
	}
end

local DEF_COLORS = { Grid2.defaultColors.WHITE, Grid2.defaultColors.RED, Grid2.defaultColors.RED, Grid2.defaultColors.RED }
local DEF_THRESHOLDS = { 5, 0, 0, 0}
function Grid2Options:MakeIndicatorCooldownColorsOptions(indicator, options)
	local function RefreshColors(v)
		local dbx = indicator.dbx
		if dbx.ctColorsText then
			dbx.ctColors = dbx.ctColors or {}
			dbx.ctThresholds = dbx.ctThresholds or {}
			for i=1,4 do
				dbx.ctColors[i] = i<=(v or 2) and (dbx.ctColors[i] or Grid2.CopyTable(DEF_COLORS[i])) or nil
				dbx.ctThresholds[i] = i<=(v or 2) and (dbx.ctThresholds[i] or DEF_THRESHOLDS[i]) or nil
			end
		else
			dbx.ctColors, dbx.ctThresholds = nil, nil
		end
		self:RefreshIndicator(indicator, "Create")
	end
	self:MakeHeaderOptions( options, "CoolColors" )
	options.ctColorTargetText = {
		type = "toggle",
		order = 160.1,
		name = L["Cooldown Text"],
		desc = L["Enable this option to apply cooldown colors to the countdown text."],
		width = "full",
		tristate = false,
		get = function () return indicator.dbx.ctColorsText end,
		set = function (_, v)
			indicator.dbx.ctColorsText = v or nil
			RefreshColors()
		end,
		disabled = function() return indicator.dbx.ctUseStatusColor or (indicator.dbx.enableCooldownText==nil and indicator.dbx.ctColorsText==nil) end,
	}
	--[[
	options.ctColorTargetBar = {
		type = "toggle",
		order = 160.2,
		name = L["Cooldown Bar"],
		desc = L["Enable this option to apply cooldown colors to the duration bar."],
		width = .7,
		tristate = false,
		get = function () return indicator.dbx.ctColorsBar end,
		set = function (_, v)
			indicator.dbx.ctColorsBar = v or nil
			RefreshColors()
		end,
		disabled = function() return indicator.dbx.enableCooldownBar==nil and indicator.dbx.ctColorsBar==nil end,
	}
	options.ctColorTargetBorder = {
		type = "toggle",
		order = 160.3,
		name = L["Icon Border"],
		desc = L["Enable this option to apply cooldown colors to the icon border."],
		width = .7,
		tristate = false,
		get = function () return indicator.dbx.ctColorsBorder end,
		set = function (_, v)
			indicator.dbx.ctColorsBorder = v or nil
			RefreshColors()
		end,
		disabled = function() return indicator.dbx.borderSize==nil and indicator.dbx.ctColorsBorder==nil end,
	}
	--]]
	options.ctFontColorCount = {
		type = "select",
		order = 161,
		name = L["Color Count"],
		desc = L["Color Count"],
		get = function ()
			return indicator.dbx.ctColors and #indicator.dbx.ctColors or 2 end,
		set = function (_, v) RefreshColors(v) end,
		values = { [2] = "2", [3] = "3", [4] = "4" },
		hidden = function() return indicator.dbx.ctColors==nil end,
	}
	for i=1,4 do
		options['ctColors'..i] = {
			type = "color",
			order = 162 + i,
			name = function()
				if i==1 then
					return string.format(L["Above %d seconds"], indicator.dbx.ctThresholds and indicator.dbx.ctThresholds[i] or 0)
				else
					return string.format(L["Less than %d seconds"], indicator.dbx.ctThresholds and indicator.dbx.ctThresholds[i-1] or 0)
				end
			end,
			hasAlpha = true,
			get = function() return self:UnpackColor( indicator.dbx.ctColors[i], "WHITE" ) end,
			set = function(info, r,g,b,a)
				self:PackColor( r,g,b,a, indicator.dbx.ctColors, i )
				self:RefreshIndicator(indicator, "Layout" )
			end,
			hidden = function() return indicator.dbx.ctColors==nil or #indicator.dbx.ctColors<i end,
		}
		options['ctThresholds'..i] = {
			type = "input",
			order = 162.5 + i,
			name = L["Threshold (seconds)"],
			get = function() return tostring(indicator.dbx.ctThresholds[i] or 0) end,
			set = function(info, v)
				indicator.dbx.ctThresholds[i] = tonumber(v) or 0
				self:RefreshIndicator(indicator, "Layout" )
			end,
			hidden = function() return indicator.dbx.ctThresholds==nil or #indicator.dbx.ctThresholds<i+1 end,
		}
	end
end

-- Grid2Options:MakeIndicatorTooltipsOptions()
function Grid2Options:MakeIndicatorTooltipsOptions(indicator, options)
	self:MakeHeaderOptions( options, "Tooltip" )
	options.tooltipEnabled = {
		type = "toggle",
		order = 290,
		name = L["Display Tooltip"],
		desc = L["Check this option to display a tooltip when the mouse is over the icon."],
		get = function () return indicator.dbx.tooltipEnabled end,
		set = function (_, v)
			indicator.dbx.enableTooltips = nil -- remove old unused setting
			indicator.dbx.tooltipAnchor = nil
			indicator.dbx.tooltipEnabled = v or nil
			self:RefreshIndicator( indicator, "Create" )
		end,
	}
	options.tooltipAnchor = {
		type = "select",
		name = L["Tooltip Anchor"],
		desc = L["Sets where the Tooltip is anchored relative to the icon."],
		order = 295,
		get = function () return indicator.dbx.tooltipAnchor or 'ANCHOR_ABSENT' end,
		set = function (_, v) indicator.dbx.tooltipAnchor = v ~= 'ANCHOR_ABSENT' and v or nil  end,
		values = Grid2Options.tooltipAnchorValues,
		hidden = function() return not indicator.dbx.tooltipEnabled end,
	}
end

-- Grid2Options:MakeIndicatorHighlightEffectOptions()
do
	local LCG = LibStub("LibCustomGlow-1.0")
	local DEFAULT_COLOR = { 1, 1, 0, 1 }
	local DEFAULT_FREQS = { 0.25, 0.12, 0.12 }
	local EFFECT_VALUES = { [-2] = L['Blink'], [-1] = L['Zoom In'], [0] = L['None'], [1] = L['Glow Border: Pixel'], [2] = L['Glow Border: Shine'], [3] = L['Glow Border: Blizzard'] }
	local ACTIVATION1_VALUES = { L["Always active"], L["Status Controlled"] }
	local ACTIVATION2_VALUES = { L["On Status Activation"], L["On Status Updates"] }

	local function ResetSettings(dbx)
		dbx.highlightAlways = nil
		dbx.animOnEnabled = nil
		dbx.animScale = nil
		dbx.animDuration = nil
		dbx.animOrigin = nil
		dbx.glow_color = nil
		dbx.glow_frequency = nil
		dbx.glow_linesCount = nil
		dbx.glow_thickness = nil
		dbx.glow_particlesCount = nil
		dbx.glow_particlesScale = nil
	end

	local function WithAllScaleAnimations( indicator, func )
		for _,f in next, Grid2Frame.registeredFrames do
			local frame = indicator:GetBlinkFrame(f)
			local anim = frame and frame.scaleAnim
			if anim then func(anim) end
		end
	end

	local function RefreshBlinkFrequencies(indicator, freq)
		for _,f in next, Grid2Frame.registeredFrames do
			local frame = indicator:GetBlinkFrame(f)
			local anim = frame and frame.blinkAnim
			if anim then anim.settings:SetDuration(1/freq) end
		end
	end

	local function RefreshIndicator(indicator)
		for _,f in next, Grid2Frame.registeredFrames do
			local frame = indicator:GetBlinkFrame(f)
			if frame then
				if frame.blinkAnim then frame.blinkAnim:Stop() end -- cancel blink
				for _, func in pairs(LCG.stopList) do -- cancel glow
					func(frame); frame.__glowEnabled = nil
				end
			end
		end
		indicator:UpdateHighlight()
		indicator:UpdateAllFrames()
	end

	function Grid2Options:MakeIndicatorHighlightEffectOptions(indicator, options)
		self:MakeHeaderOptions( options, "Highlight" )
		options.highlightType = {
			type = "select",
			order = 320,
			name = L["Highlight Effect"],
			desc = L["Select the Highlight effect."],
			get = function ()
				return indicator.dbx.highlightType or -2 -- default blink
			end,
			set = function (_, v)
				indicator.dbx.highlightType = v~=-2 and v or nil
				ResetSettings(indicator.dbx)
				RefreshIndicator(indicator)
			end,
			values = EFFECT_VALUES,
		}
		options.highlightActivation = {
			type = "select",
			order = 325,
			name = L["Activation"],
			desc = L["Select when to activate the highlight effect."],
			get = function()
				return indicator.dbx.highlightAlways and 1 or 2
			end,
			set = function (_, v)
				indicator.dbx.highlightAlways = v==1 or nil
				RefreshIndicator(indicator)
			end,
			values = ACTIVATION1_VALUES,
			hidden = function() return indicator.dbx.highlightType == -1 or indicator.dbx.highlightType == 0 end, -- zoomIn or none
		}
		-- common options
		options.glowFrequency = { -- all glow
			type = "range",
			order = 340,
			name = L["Animation Speed"],
			desc = L["Animation Speed"],
			min = -1.5,
			max = 1.5,
			step = 0.01,
			get = function () return indicator.dbx.glow_frequency or DEFAULT_FREQS[indicator.dbx.highlightType] end,
			set = function (_, v)
				indicator.dbx.glow_frequency = (v~=0 and v~=DEFAULT_FREQS[v]) and v or nil
				RefreshIndicator(indicator)
			end,
			hidden = function() return (indicator.dbx.highlightType or 0)<=0 end,
		}
		-- blink (-2|nil)
		options.blinkFrequency = {
			type = "range",
			order = 340,
			width = 'double',
			name = L["Blink Frequency"],
			desc = L["Adjust the frequency of the Blink effect."],
			min = 1,
			max = 10,
			step = .5,
			get = function ()
				return indicator.dbx.blink_frequency or 2
			end,
			set = function (_, v)
				indicator.dbx.blink_frequency = v~=2 and v or nil
				RefreshBlinkFrequencies(indicator, v)
			end,
			hidden = function() return (indicator.dbx.highlightType or -2)~=-2 end,
		}
		-- glow pixel (1)
		options.linesCount = {
			type = "range",
			order = 370,
			width = "normal",
			name = L["Number of Lines"],
			desc = L["Number of Lines"],
			min = 1,
			max = 20,
			step = 1,
			get = function () return indicator.dbx.glow_linesCount or 8 end,
			set = function (_, v)
				indicator.dbx.glow_linesCount = (v~=8) and v or nil
				RefreshIndicator(indicator)
			end,
			hidden = function() return indicator.dbx.highlightType~=1 end,
		}
		-- glow pixel (1)
		options.thickness = {
			type = "range",
			order = 380,
			width = "normal",
			name = L["Thickness"],
			desc = L["Thickness"],
			min = 1,
			max = 10,
			step = 1,
			get = function () return indicator.dbx.glow_thickness or 2 end,
			set = function (_, v)
				indicator.dbx.glow_thickness = (v~=2) and v or nil
				RefreshIndicator(indicator)
			end,
			hidden = function() return indicator.dbx.highlightType~=1 end
		}
		-- glow shine (2)
		options.particlesCount = {
			type = "range",
			order = 370,
			width = "normal",
			name = L["Number of particles"],
			desc = L["Number of particles"],
			min = 1,
			max = 10,
			step = 1,
			get = function () return indicator.dbx.glow_particlesCount or 4 end,
			set = function (_, v)
				indicator.dbx.glow_particlesCount = (v~=4) and v or nil
				RefreshIndicator(indicator)
			end,
			hidden = function() return indicator.dbx.highlightType~=2 end
		}
		options.particlesScale = {
			type = "range",
			order = 380,
			width = "normal",
			name = L["Scale of particles"],
			desc = L["Scale of particles"],
			min = 0.1,
			max = 5,
			step = 0.1,
			get = function () return indicator.dbx.glow_particlesScale or 1 end,
			set = function (_, v)
				indicator.dbx.glow_particlesScale = (v~=1) and v or nil
				RefreshIndicator(indicator)
			end,
			hidden = function() return indicator.dbx.highlightType~=2 end
		}
		-- glow common
		options.glowColor = {
			type = "color",
			hasAlpha = true,
			order = 390,
			name = L["Glow Color"],
			desc = L["Sets the glow color to display when the indicator is highlighted."],
			get = function() return unpack(indicator.dbx.glow_color or DEFAULT_COLOR) end,
			set = function( info, r,g,b,a )
				indicator.dbx.glow_color = { r, g, b, a }
				RefreshIndicator(indicator)
			end,
			hidden = function() return (indicator.dbx.highlightType or 0)<=0 end
		}
		-- zoomIn
		options.animActivation = {
			type = 'select',
			order = 325,
			name = L["Activation"],
			desc = L["Select when to start the Zoom In effect"],
			get = function()
				return indicator.dbx.animOnEnabled and 1 or 2
			end,
			set = function(_, v)
				indicator.dbx.animOnEnabled = v==1 or nil
				indicator:UpdateDB()
			end,
			values = ACTIVATION2_VALUES,
			hidden = function() return indicator.dbx.highlightType ~= -1 end,
		}
		options.animOrigin = {
			type = 'select',
			order = 340,
			name = L["Origin"],
			desc = L["Zoom origin point"],
			values = self.pointValueList,
			get = function() return self.pointMap[indicator.dbx.animOrigin or 'CENTER'] end,
			set = function(_, v)
				local point = self.pointMap[v]
				indicator.dbx.animOrigin = point~='CENTER' and point or nil
				WithAllScaleAnimations( indicator, function(a) a.grow:SetOrigin(point,0,0); a.shrink:SetOrigin(point,0,0); end)
			end,
			hidden = function() return indicator.dbx.highlightType ~= -1 end,
		}
		options.animScale = {
			type = "range",
			order = 350,
			name = L["Scale"],
			desc = L["Sets the zoom factor."],
			min  = 1.1,
			max  = 3,
			step = 0.1,
			get = function () return indicator.dbx.animScale or 1.5	end,
			set = function (_, v)
				indicator.dbx.animScale = v
				WithAllScaleAnimations( indicator, function(a) a.grow:SetScale(v,v); a.shrink:SetScale(1/v,1/v); end)
			end,
			hidden = function() return indicator.dbx.highlightType ~= -1 end,
		}
		options.animDuration = {
			type = "range",
			order = 360,
			width = 'double',
			name = L["Duration"],
			desc = L["Sets the duration in seconds."],
			min  = 0.1,
			max  = 2,
			step = 0.1,
			get = function () return indicator.dbx.animDuration or 0.7 end,
			set = function (_, v)
				indicator.dbx.animDuration = v
				WithAllScaleAnimations( indicator, function(a) a.grow:SetDuration(v/2);	a.shrink:SetDuration(v/2); end)
			end,
			hidden = function() return indicator.dbx.highlightType ~= -1 end,
		}
		return options
	end
end

-- Grid2Options:MakeIndicatorLoadOptions(indicator, options)
do
	local headerTypes

	local function GetHeaderTypes()
		if headerTypes==nil and Grid2Layout.customLayouts then
			for _,layout in next,Grid2Layout.customLayouts do
				for _,header in ipairs(layout) do
					if header.headerName then
						headerTypes = headerTypes or Grid2.CopyTable(Grid2Options.HEADER_TYPES)
						headerTypes[header.headerName] = '/' .. header.headerName .. '/'
					end
				end
			end
		end
		return headerTypes or Grid2Options.HEADER_TYPES
	end

	local function RefreshIndicator(indicator)
		Grid2Options:UpdateIndicatorDB(indicator)
		for _,f in next, Grid2Frame.registeredFrames do
			local new = not not indicator:CanCreate(f)
			local old = not not indicator:GetFrame(f)
			if new~=old then
				if new then
					indicator:Create(f); indicator:Layout(f)
				else
					indicator:Release(f)
				end
			end
		end
		if not indicator.parentName then
			Grid2Frame:UpdateIndicators()
		end
	end

	local function SetFilterOptions( indicator, options, order, key, values, defValue, name, desc, isSingle, updateFunc )
		local dbx    = indicator.dbx
		local filter = dbx.load and dbx.load[key]
		local multi  = filter and next(filter, next(filter))~=nil
		options[key] = {
			type = "toggle",
			name = name,
			desc = desc or name,
			order = order,
			get = function(info) return filter end,
			set = function(info)
				if multi or (isSingle and filter) then
					multi, filter, dbx.load[key] = nil, nil, nil
					if not next(dbx.load) then dbx.load = nil end
				elseif filter and not isSingle then
					multi = true
				else
					dbx.load = dbx.load or {}
					filter = { [defValue] = true }
					dbx.load[key] = filter
				end
				updateFunc(indicator)
			end,
			disabled = function() return indicator.parentName~=nil end,
		}
		options[key..'1'] = {
			type = "select",
			name = name,
			order = order+1,
			get = function() return filter and next(filter) end,
			set = function(_,v)
				wipe(filter)[v] = true
				updateFunc(indicator)
			end,
			disabled = function() return not filter or indicator.parentName~=nil end,
			hidden   = function() return multi end,
			values   = values,
		}
		options[key..'2'] = {
			type = "multiselect",
			order = order+2,
			name = name,
			get = function(info, value) return filter[value] end,
			set = function(info, value)
				filter[value] = (not filter[value]) or nil
				updateFunc(indicator)
			end,
			hidden = function() return not multi end,
			disabled = function() return not filter or indicator.parentName~=nil end,
			values = values,
		}
		options[key.."3"] = {
			type = "description",
			name = "",
			order = order+3,
		}
	end

	local SetFilterThemeOptions
	do
		local themesTable = {}

		local function GetFilterState(name, suspended)
			local count = 0
			for index in pairs(themesTable) do
				if not suspended[index][name] then count = count + 1 end
			end
			return (count>#themesTable and 0) or (count>1 and 2) or 1
		end

		local function RefreshThemes(name, suspended)
			local names = Grid2.db.profile.themes.names
			wipe(themesTable)
			for i=0,#names do
				themesTable[i] = names[i] or L['Default']
			end
			return GetFilterState(name, suspended)
		end

		local function ClearFilter(name, suspended)
			for index in pairs(themesTable) do
				suspended[index][name] = nil
			end
		end

		local function SetSingle(name, suspended, theme)
			for index in pairs(themesTable) do
				suspended[index][name] = (theme~=index) or nil
			end
		end

		function SetFilterThemeOptions( indicator, options, order)
			local name = indicator.name
			local suspended = Grid2.db.profile.themes.indicators
			local state = RefreshThemes(name, suspended)
			options.theme = {
				type = "toggle",
				name = L['Active Theme'],
				desc = L["Load the indicator only for the specified themes."],
				order = order,
				get = function(info)
					return state~=0
				end,
				set = function(info)
					state = state<2 and state+1 or 0
					if state==0 then
						ClearFilter(name, suspended)
					elseif state==1 then
						SetSingle(name, suspended, Grid2.currentTheme or 0)
					end
					Grid2:RefreshTheme()
				end,
				disabled = function() return indicator.parentName~=nil end,
				hidden = function() return Grid2Frame.dba.profile.extraThemes==nil end,
			}
			options.theme1 = {
				type = "select",
				name = L['Active Theme'],
				order = order+1,
				get = function()
					if state==1 then
						local index = #themesTable
						while index>=0 and suspended[index][name] do index = index - 1 end
						return index
					end
				end,
				set = function(_,v)
					SetSingle(name, suspended, v)
					Grid2:RefreshTheme()
				end,
				disabled = function() return indicator.parentName~=nil or state~=1 end,
				hidden   = function() return state==2 or Grid2Frame.dba.profile.extraThemes==nil end,
				values   = themesTable,
			}
			options.theme2 = {
				type = "multiselect",
				order = order+2,
				name = L['Active Theme'],
				get = function(info, theme)
					return not suspended[theme][name]
				end,
				set = function(info, theme)
					suspended[theme][name] = (not suspended[theme][name]) or nil
					Grid2:RefreshTheme()
				end,
				disabled = function() return indicator.parentName~=nil end,
				hidden = function() return state~=2 or Grid2Frame.dba.profile.extraThemes==nil  end,
				values = themesTable,
			}
			options.theme3 = {
				type = "description",
				name = "",
				order = order+3,
			}
		end
	end

	function Grid2Options:RefreshIndicatorsLoadFilter(layoutName)
		headerTypes = nil
		if layoutName == Grid2Layout.layoutName then
			for _, indicator in Grid2:IterateIndicators() do
				if indicator.load and indicator.load.unitType then
					RefreshIndicator(indicator)
				end
			end
		end
	end

	function Grid2Options:MakeIndicatorLoadOptions(indicator, options)
		SetFilterThemeOptions( indicator, options, 10 )
		SetFilterOptions( indicator, options, 20,
			'playerClass',
			self.PLAYER_CLASSES,
			Grid2.playerClass,
			L["Player Class"],
			L["Load the indicator only if your toon belong to the specified class."],
			false,
			RefreshIndicator
		)
		SetFilterOptions( indicator, options, 30,
			'unitType',
			GetHeaderTypes,
			'player',
			L["Header Type"],
			L["Load the indicator only for the specified header types or special units."],
			false,
			RefreshIndicator
		)
		return options
	end
end
