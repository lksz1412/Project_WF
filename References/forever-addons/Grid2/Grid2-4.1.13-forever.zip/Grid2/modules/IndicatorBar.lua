--[[ Created by Grid2 original authors, modified by Michael ]]--

local Grid2 = Grid2
local Grid2Frame = Grid2Frame
local min = min
local issecretvalue = Grid2.issecretvalue
local AlignPoints = Grid2.AlignPoints
local defaultBackColor = { r=0, g=0, b=0, a=1 }

-- helper functions
local function ReleaseAuraColorsSlots(self, parent, f)
	local count = f.countSlots
	if count then
		for i=1,count do
			self:ReleaseAuraSlotButton(parent, i)
		end
		f.countSlots = nil
	end
end

-- indicator methods
local function Bar_CreateHH(self, parent)
	local bar = self:Acquire("StatusBar", parent)
	bar:SetStatusBarColor(0,0,0,0)
	bar:SetMinMaxValues(0, 1)
	bar:SetValue(0)
	if self.backColor then
		bar.bgTex = bar.bgTex or bar:CreateTexture()
	end
end

local function Bar_LayoutAuraColor(self, parent, f, level)
	ReleaseAuraColorsSlots(self, parent, f)
	local color = self.sideKick
	if color.auraMode then
		local tex = f:GetStatusBarTexture()
		for filter, status, index in color:IterateStatusAurasFilters(self.maxSlots) do
			self:AcquireAuraSlotButton(parent, filter, function(_, _, button)
				button:ClearAllPoints()
				button:SetAllPoints(f)
				button:SetFrameLevel(level)
				local ctex = button.__texture or button:CreateTexture(nil, "OVERLAY", nil, -index)
				ctex:ClearAllPoints(tex)
				ctex:SetTexture(self.texture)
				ctex:SetBlendMode('BLEND')
				ctex:SetAllPoints(tex)
				button:ClearDispelTypeTextures()
				button:AddDispelTypeTexture(ctex, filter.borderOptions)
				button.__texture = ctex
				f.countSlots = index
			end, nil, index)
		end
	end
end

local function Bar_Layout(self, parent)
	local Bar    = parent[self.name]
	local bgTex  = Bar.bgTex
	local orient = self.orientation
	local points = AlignPoints[orient][not self.reverseFill]
	local level  = parent:GetFrameLevel() + self.frameLevel
	Bar:SetParent(parent)
	Bar:ClearAllPoints()
	Bar:SetOrientation(orient)
	Bar:SetStatusBarTexture(self.texture)
	Bar:SetReverseFill(self.reverseFill)
	local w = self.width  or parent.container:GetWidth()
	local h = self.height or parent.container:GetHeight()
	Bar:SetFrameLevel(level)
	Bar:SetSize(w, h)
	Bar:SetPoint(self.anchor, parent.container, self.anchorRel, self.offsetx, self.offsety)
	local color = self.backColor
	if color then
		local tex = Bar:GetStatusBarTexture()
		local layer, sublayer = tex:GetDrawLayer()
		bgTex:SetDrawLayer(layer, sublayer-1)
		bgTex:SetTexture(self.backTexture)
		bgTex:ClearAllPoints()
		if self.dbx.invertColor then
			bgTex:SetAllPoints(Bar)
		else
			bgTex:SetPoint( points[1], tex, points[2], 0, 0)
			bgTex:SetPoint( points[3], tex, points[4], 0, 0)
			bgTex:SetPoint( points[2], Bar, points[2], 0, 0)
			bgTex:SetPoint( points[4], Bar, points[4], 0, 0)
			bgTex:SetVertexColor( color.r, color.g, color.b, color.a )
		end
		bgTex:Show()
	elseif bgTex then
		bgTex:Hide()
	end
	if self.direction then
		Bar.durationObject = Bar.durationObject or C_DurationUtil.CreateDuration()
	end
	Bar.fgTex = Bar:GetStatusBarTexture()
	Bar:Show()
	Bar_LayoutAuraColor(self, parent, Bar, level)
end

--{{{ Bar OnUpdate
-- normal updates
local function Bar_OnUpdate(self, parent, unit, status)
	local bar = parent[self.name]
	if status then
		if status.GetValueMinMax then
			local value, min, max = status:GetValueMinMax(unit)
			bar:SetMinMaxValues(min or 0, max or 1)
			bar:SetValue(value, self.interpol)
		else
			bar:SetMinMaxValues(0, 1)
			bar:SetValue( (status:GetPercent(unit)), self.interpol )
		end
		if self.hideInactive then bar:Show() end
	elseif self.hideInactive then
		bar:Hide()
	else
		bar:SetValue(0)
	end
end

local function Bar_OnUpdateD(self, parent, unit, status)
	local bar = parent[self.name]
	if status then
		local duration = status:GetDuration(unit)
		if duration then
			local expiration =	status:GetExpirationTime(unit)
			if expiration then
				bar.durationObject:SetTimeFromEnd(expiration, duration)
			else
				bar.durationObject:SetTimeFromStart(status:GetStartTime(unit) or GetTime(), duration)
			end
			bar:SetTimerDuration(bar.durationObject, 0, self.direction)
			if self.hideInactive then bar:Show() end
			return
		end
	end
	if self.hideInactive then
		bar:Hide()
	else
		bar:SetMinMaxValues(0,1)
		bar:SetValue(0)
	end
end
--}}}

local function Bar_SetOrientation(self, orientation)
	self.orientation     = orientation or Grid2Frame.db.profile.orientation
	self.dbx.orientation = orientation
end

local function Bar_Disable(self, parent)
	local bar = parent[self.name]
	bar:Hide()
	bar:SetParent(nil)
	bar:ClearAllPoints()
	ReleaseAuraColorsSlots(self, parent, bar)
end

local function Bar_UpdateDB(self)
	local dbx = self.dbx
	local theme = Grid2Frame.db.profile
	local l = dbx.location
	self.texture     = Grid2:MediaFetch("statusbar", dbx.texture or theme.barTexture, "Gradient")
	self.backTexture = dbx.backTexture and Grid2:MediaFetch("statusbar", dbx.backTexture, "Gradient") or self.texture
	self.orientation = dbx.orientation or theme.orientation
	self.frameLevel  = self:GetFrameLevel(dbx.level)
	self.anchor      = l.point
	self.anchorRel   = l.relPoint
	self.offsetx     = l.x
	self.offsety     = l.y
	self.width       = dbx.width
	self.height      = dbx.height
	self.reverseFill = not not dbx.reverseFill
	self.backColor   = dbx.backColor or (dbx.invertColor and defaultBackColor) or nil
	self.CanCreate   = self.prototype.CanCreate
	self.hideInactive= dbx.hideWhenInactive
	self.direction   = (dbx.duration==true and 1) or (dbx.duration==false and 0) or nil
	self.interpol    = dbx.interpolation or 0
	self.OnUpdate    = dbx.duration~=nil and Bar_OnUpdateD or Bar_OnUpdate
	self.maxSlots    = Grid2.db.profile.formatting.maxAuraColorSlots or 3
end

local function BarColor_OnUpdate(self, parent, unit, status)
	local bar = parent[self.parentName]
	if bar then
		if status then
			local r, g, b, a = status:GetColor(unit)
			bar.fgTex:SetVertexColor(r, g, b, self.opacity or a )
		else
			bar:SetStatusBarColor(0,0,0,0)
		end
	end
end

local function BarColor_OnUpdateInverted(self, parent, unit, status)
	local bar = parent[self.parentName]
	if bar then
		local r, g, b, a
		if status then
			r, g, b, a = status:GetColor(unit)
			if a==nil or issecretvalue(a) then	a = 1 end
		else
			r, g, b, a = 0, 0, 0, 0
		end
		local c = self.backColor
		bar.fgTex:SetVertexColor(c.r, c.g, c.b, self.opacity)
		bar.bgTex:SetVertexColor(r, g, b, a*c.a)
	end
end

local function BarColor_UpdateDB(self)
	local dbx = self.dbx
	self.backColor = dbx.backColor or defaultBackColor
	if dbx.invertColor then
		self.OnUpdate = BarColor_OnUpdateInverted
		self.opacity = dbx.opacity and min(dbx.opacity, 0.8) or 0.8
	else
		self.OnUpdate = BarColor_OnUpdate
		self.opacity = dbx.opacity~=0 and (dbx.opacity or 1) or nil -- opacity==0 => use status color
	end
end

local function Create(indicatorKey, dbx)
	local Bar = Grid2.indicatorPrototype:new(indicatorKey)
	Bar.dbx            = dbx
	Bar.Create         = Bar_CreateHH
	Bar.OnUpdate       = Bar_OnUpdate
	Bar.SetOrientation = Bar_SetOrientation
	Bar.Disable        = Bar_Disable
	Bar.Layout         = Bar_Layout
	Bar.UpdateDB       = Bar_UpdateDB
	Bar.GetBlinkFrame  = Bar.GetFrame
	Grid2:RegisterIndicator(Bar, { "percent" } )

	local BarColor      = Grid2.indicatorPrototype:new(indicatorKey.."-color")
	BarColor.dbx        = dbx
	BarColor.parentName = indicatorKey
	BarColor.Create     = Grid2.Dummy
	BarColor.Layout     = Grid2.Dummy
	BarColor.OnUpdate   = BarColor_OnUpdate
	BarColor.UpdateDB   = BarColor_UpdateDB
	Grid2:RegisterIndicator(BarColor, { "color" })

	Bar.sideKick = BarColor

	return Bar, BarColor
end

Grid2.setupFunc["bar"] = Create

Grid2.setupFunc["bar-color"] = Grid2.Dummy
