-- Created by Grid2 original authors, modified by Michael
local Range = Grid2.statusPrototype:new("range")
local RangeAlt = Grid2.statusPrototype:new("rangealt")

local Grid2 = Grid2
local next = next
local UnitCanAttack = UnitCanAttack
local UnitPhaseReason = UnitPhaseReason
local InCombatLockdown = InCombatLockdown
local UnitIsDeadOrGhost = UnitIsDeadOrGhost
local CheckInteractDistance = CheckInteractDistance
local playerClass = Grid2.playerClass
local GetSpellInfo = Grid2.API.GetSpellInfo
local IsSpellInRange = C_Spell.IsSpellInRange

local issecretvalue = Grid2.issecretvalue
local roster_guids = Grid2.roster_guids
local roster_external = Grid2.roster_external
local grouped_units = Grid2.grouped_units
local grouped_solo = {}

-------------------------------------------------------------------------
--  range check spells initialization
-------------------------------------------------------------------------
local spellHostile, spellFriendly = "", nil
do
	local function IVS(spellID) return IsPlayerSpell(spellID) and spellID end
	local getHostile, getFriendly
	if Grid2.isForever then
		if playerClass == 'DRUID' then
			getHostile  = function() return 5176 end -- Wrath
			getFriendly = function() return 5185 end -- Healing Touchaw
		elseif playerClass == 'PRIEST' then
			getHostile  = function() return 585  end -- Smite
			getFriendly = function() return 2050 end -- Lesser Heal
		elseif playerClass == 'SHAMAN' then
			getHostile  = function() return 403  end -- Lightning Bolt
			getFriendly = function() return 331  end -- Healing Wave
		elseif playerClass == 'PALADIN' then
			getHostile  = function() return IVS(20271) end -- Judgement
			getFriendly = function() return 635 end -- Holy Light
		elseif playerClass == 'WARLOCK' then
			getHostile  = function() return 686 end -- Shadow Bolt
			getFriendly = function() return IVS(20707) end -- Soulstone
		elseif playerClass == 'WARRIOR' then
			getHostile  = function() return IVS(355) or IVS(772) end  -- Taunt, Rend
			getFriendly = function() return nil end  -- no avail
		elseif playerClass == 'HUNTER' then
			getHostile  = function() return IVS(3044) or IVS(1978) end -- Arcane Shot, Serpent Sting
			getFriendly = function() return nil end -- no avail
		elseif playerClass == 'ROGUE' then
			getHostile  = function() return IVS(1752) end -- Sinister Strike
			getFriendly = function() return nil end -- no avail
		elseif playerClass == 'MAGE' then
			getHostile  = function() return IVS(116) or IVS(133)  end -- Frostbolt, Fireball
			getFriendly = function() return IVS(1459) end -- Arcane intellect
		end
	else -- Midnight
		if playerClass == 'DRUID' then
			getHostile  = function() return 8921 end -- Moonfire
			getFriendly = function() return 8936 end -- Regrowth
		elseif playerClass == 'PRIEST' then
			getHostile  = function() return 585  end  -- Smite
			getFriendly = function() return 2061 end  -- Flash Heal
		elseif playerClass == 'SHAMAN' then
			getHostile  = function() return 188196  end -- Lightning Bolt
			getFriendly = function() return 8004 end    -- Healing Surge
		elseif playerClass == 'PALADIN' then
			getHostile  = function() return 20271 end -- Judgement
			getFriendly = function() return 19750 end -- Flash of light
		elseif playerClass == 'MONK' then
			getHostile  = function() return 115546 end -- Provoke
			getFriendly = function() return 116670 end -- Vivify
		elseif playerClass == 'EVOKER' then
			getHostile  = function() return 361469 end -- Living flame
			getFriendly = function() return 355913 end -- Emerald Blossom
		elseif playerClass == 'WARLOCK' then
			getHostile  = function() return 686 end   -- Shadow Bolt
			getFriendly = function() return 20707 end -- Soulstone
		elseif playerClass == 'WARRIOR' then
			getHostile  = function() return 355 end  -- Taunt
			getFriendly = function() return nil end  -- no avail
		elseif playerClass == 'DEMONHUNTER' then
			getHostile  = function() return 185123 end -- Throw Glaive
			getFriendly = function() return nil    end -- no avail
		elseif playerClass == 'HUNTER' then
			getHostile  = function() return IVS(193455) or IVS(19434) or IVS(132031) end -- Cobra Shot, Aimed Short, Steady shot
			getFriendly = function() return nil end -- no avail
		elseif playerClass == 'ROGUE' then
			getHostile  = function() return IVS(36554) or IVS(6770) end -- Shadowstep, Sap
			getFriendly = function() return IVS(36554) end -- Shadowstep
		elseif playerClass == 'DEATHKNIGHT' then
			getHostile  = function() return IVS(47541) or IVS(49576) end -- Death Coil, Death Grip
			getFriendly = function() return IVS(47541) end -- Death Coil
		elseif playerClass == 'MAGE' then
			getHostile  = function() return IVS(116) or IVS(30451) or IVS(133) end -- Frostbolt, Arcane Blast, Fireball
			getFriendly = function() return 1459 end -- Arcane intellect
		end
	end
	local pendingUpdate
	local function UpdateSpells(...)
		pendingUpdate = nil
		spellHostile  = GetSpellInfo( getHostile() ) or ""
		spellFriendly = GetSpellInfo( getFriendly() )
		if Range.enabled then Range:UpdateDB() end
		if RangeAlt.enabled then RangeAlt:UpdateDB() end
	end
	Range:RegisterEvent("SPELLS_CHANGED", function()
		UpdateSpells()
		Range:UnregisterEvent("SPELLS_CHANGED") -- this event used only on login/reload because is fired a lot in combat.
		Range:RegisterEvent("PLAYER_TALENT_UPDATE", function()
			if not pendingUpdate then -- to update only once because this event fires twice
				pendingUpdate = true
				C_Timer.After(0.01, UpdateSpells)
			end
		end )
	end)
end

------------------------------------------------------------------------
-- range check functions
-------------------------------------------------------------------------

local InCombat = false

-- rez spells
local rezSpellID = ({DRUID=20484,PRIEST=2006,PALADIN=7328,SHAMAN=2008,MONK=115178,DEATHKNIGHT=61999,WARLOCK=20707,EVOKER=361227})[playerClass]
local rezSpell = rezSpellID and GetSpellInfo(rezSpellID)

-- warlock pet spell 755 doe not exist in midnight but we need to assign some number to petSpellID for warlocks because UnitInRange() does not work
-- for pets when solo, so when petSpellID is not a known spell we have to treat pet as an external unit (like target or focus), so pet unit is removed
-- from grouped_units and the timer and IsSpellInRange(spellFriendly) code for external units is used for pet.
local petCheckUnit = nil
local petSpellID = ({HUNTER=136,WARLOCK=755,DEATHKNIGHT=47541})[playerClass]
local petSpell = petSpellID and GetSpellInfo(petSpellID)

local function CreateRangeCheck(spellFriendly, spellHostile, blizRange)
	return function(unit)
		if unit=='player' then
			return true
		elseif unit==petCheckUnit then -- solo player with pet, only when a pet spell is available
			return IsSpellInRange(petSpell, unit) == true
		elseif blizRange and grouped_units[unit] then -- 38y range check
			return UnitInRange(unit)
		elseif UnitPhaseReason(unit) then
			return false
		elseif UnitCanAttack('player', unit) then
			return IsSpellInRange(spellHostile, unit) == true
		elseif rezSpell and UnitIsDeadOrGhost(unit) then
			return IsSpellInRange(rezSpell, unit) == true
		elseif spellFriendly then -- extra CheckInteractDistance() for OOC friendly npcs if spell check fails
			return IsSpellInRange(spellFriendly, unit) == true or (not InCombat and CheckInteractDistance(unit, 4))
		else
			return InCombat or CheckInteractDistance(unit,4)
		end
	end
end

local Ranges = {
	[99] = function() return UnitIsVisible end,
	[38] = CreateRangeCheck,
	["heal"] = CreateRangeCheck,
	["spell"] = CreateRangeCheck,
}

----------------------------------------------------------
-- shared methods
----------------------------------------------------------

local Shared = { GetColor = Grid2.statusLibrary.GetColor }

-- we need to update this on a timer for non-grouped units: target, focus, or when range used is not 38y
function Shared:UpdateUnits(units)
	local cache = self.cache
	local check = self.UnitRangeCheck
	for unit in next, units do
		local new = check(unit)
		local old = cache[unit]
		if issecretvalue(new) or issecretvalue(old) or new~=old then
			cache[unit] = new
			self:UpdateIndicators(unit)
		end
	end
end

-- called from options
function Shared:Refresh()
	Grid2.statusPrototype.Refresh(self, true)
	wipe(self.cache) -- we need to wipe cache to remove secrets if prev range was 38y
	local cache = self.cache
	local check = self.UnitRangeCheck
	for unit in Grid2:IterateRosterUnits() do
		cache[unit] = check(unit)
		self:UpdateIndicators(unit)
	end
end

-- UNIT_IN_RANGE_UPDATE and UnitInRange() don't work for pet units when solo, so we use a timer
-- and a pet spell range check for 38 yards range for classes with pets when not in group.
function Shared:Grid_GroupTypeChanged()
	if petSpell then -- is a class with pet ?
		if Grid2.groupType=='solo' then
			petCheckUnit = IsPlayerSpell(petSpellID) and 'pet' or nil -- for warlock in midnight there is not pet spell available so we have to rely on spellFriendly
			grouped_units = grouped_solo -- when solo pet unit is not considered a grouped unit by the game so UnitInRange() fails for pet.
			roster_external.pet = roster_guids.pet -- roster_external == self.refreshUnits for 38 yard range
		else
			petCheckUnit = nil
			grouped_units = Grid2.grouped_units
			roster_external.pet = nil -- roster_external == self.refreshUnits for 38 yard range
		end
	end
	self.timer:SetPlaying( next(self.refreshUnits)~=nil )
end

function Shared:Grid_UnitUpdated(_, unit)
	self.cache[unit] = self.UnitRangeCheck(unit)
	if grouped_units == grouped_solo then -- special case for pet units while solo
		roster_external.pet = roster_guids.pet
	end
	self.timer:SetPlaying( next(self.refreshUnits)~=nil )
end

function Shared:Grid_UnitLeft(_, unit)
	if unit=='pet' and grouped_units == grouped_solo then -- special case for pet units while solo
		roster_external.pet = nil
	end
	self.cache[unit] = nil
	self.timer:SetPlaying( next(self.refreshUnits)~=nil )
end

function Shared:PLAYER_ENTERING_WORLD(_, isLogin, isReload)
	if isLogin or isReload then return end
	self:UpdateUnits(roster_guids)
end

function Shared:PLAYER_REGEN_ENABLED()
	InCombat = false
end

function Shared:PLAYER_REGEN_DISABLED()
	InCombat = true
end

function Shared:UNIT_IN_RANGE_UPDATE(_, unit)
	self.cache[unit] = self.UnitRangeCheck(unit)
	self:UpdateIndicators(unit)
end

function Shared:GetPercent(unit)
	return self.curAlpha
end

function Shared:GetRanges()
	return Ranges, self.curRange, rezSpellID
end

function Shared:IsActiveR(unit)
	return self.cache[unit], true -- true means inverted activation, hackish because we cannot negate a secret value
end

function Shared:IsActiveN(unit)  -- normal activation for non-secret ranges
	return not self.cache[unit]
end

function Shared:OnEnable()
	InCombat = InCombatLockdown()
	self.timer = Grid2:CreateTimer( function() self:UpdateUnits(self.refreshUnits) end, self.elapsed, false)
	self:RegisterMessage("Grid_UnitUpdated")
	self:RegisterMessage("Grid_UnitLeft")
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	if self.curRange==38 then
		self:RegisterRosterUnitEvent("UNIT_IN_RANGE_UPDATE")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
	end
	if petSpell then
		self:RegisterMessage('Grid_GroupTypeChanged')
	end
	self:Grid_GroupTypeChanged()
end

function Shared:OnDisable()
	self.timer = Grid2:CancelTimer( self.timer )
	self:UnregisterMessage("Grid_UnitUpdated")
	self:UnregisterMessage("Grid_UnitLeft")
	self:UnregisterEvent("PLAYER_REGEN_ENABLED")
	self:UnregisterEvent("PLAYER_REGEN_DISABLED")
	if self.curRange==38 then
		self:UnregisterRosterUnitEvent("UNIT_IN_RANGE_UPDATE")
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
	end
	if petSpell then
		self:UnregisterMessage('Grid_GroupTypeChanged')
	end
end

function Shared:UpdateDB()
	local dbx = self.dbx
	local dbr = dbx.ranges and dbx.ranges[playerClass] or dbx
	local elapsed = dbx.elapsed or 0.25
	local spellh = dbr.hostileSpellID and GetSpellInfo(dbr.hostileSpellID) or spellHostile
	local spellf = dbr.friendlySpellID and GetSpellInfo(dbr.friendlySpellID) or spellFriendly
	local rangec = tonumber(dbr.range) or dbr.range
	rangec = Ranges[rangec] and rangec or 38
	self.refreshUnits = (rangec==38) and roster_external or roster_guids
	self.elapsed = (rangec~=38 or elapsed>1) and elapsed or 1 -- for 38y range do not allow update rate less than 1 second.
	self.UnitRangeCheck = Ranges[rangec](spellf, spellh, rangec==38)
	self.IsActive = rangec==38 and self.IsActiveR or self.IsActiveN
	self.curAlpha = dbx.default or 0.25
	self.curRange = rangec
end

-------------------------------------------------------------------------
-- range status
-------------------------------------------------------------------------

Range.cache = setmetatable( {}, {__index = function() return false end} )

Range:Inject(Shared)

Grid2.setupFunc["range"] = function(baseKey, dbx)
	Grid2:RegisterStatus( Range, {"percent", "color"}, baseKey, dbx)
	return Range
end

Grid2:DbSetStatusDefaultValue( "range", {type = "range", color1 = {r=1, g=0, b=0, a=1}, range=38, default = 0.25, elapsed = 0.5} )

-------------------------------------------------------------------------
-- rangealt status
-------------------------------------------------------------------------

RangeAlt.cache = setmetatable( {}, {__index = function() return false end} )

RangeAlt:Inject(Shared)

Grid2.setupFunc["rangealt"] = function(baseKey, dbx)
	Grid2:RegisterStatus( RangeAlt, {"percent", "color"}, baseKey, dbx)
	return RangeAlt
end

Grid2:DbSetStatusDefaultValue( "rangealt", {type = "rangealt", color1 = {r=1, g=0, b=0, a=1}, range=99, default = 0.25, elapsed = 0.5} )
