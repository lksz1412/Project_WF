local L = LibStub:GetLibrary("AceLocale-3.0"):GetLocale("Grid2")

local Grid2 = Grid2

local status = Grid2.statusPrototype:new("summon")

local HasIncomingSummon = C_IncomingSummon.HasIncomingSummon
local IncomingSummonStatus = C_IncomingSummon.IncomingSummonStatus

local texts = {
 [1] = L["Pending"],
 [2] = L["Accepted"],
 [3] = L["Declined"],
}

function status:INCOMING_SUMMON_CHANGED(_, unit)
	if Grid2:IsPlayerInRaid(unit) then
		self:UpdateIndicators(unit)
	end
end

function status:OnEnable()
	self:RegisterEvent("INCOMING_SUMMON_CHANGED")
end

function status:OnDisable()
	self:UnregisterEvent("INCOMING_SUMMON_CHANGED")
end

function status:IsActive(unit)
	return HasIncomingSummon(unit)
end

function status:GetColor(unit)
	local state, color = IncomingSummonStatus(unit)
	if state == 3 then -- declined(3)
		color = self.dbx.color3
	elseif state == 2 then -- accepted(2)
		color = self.dbx.color2
	else -- pending(1)
		color = self.dbx.color1
	end
	return color.r, color.g, color.b, color.a
end

local SummonCoords = {
	{0.54296875, 0.71484375, 0.2890625, 0.6328125}, --pending
	{0.36328125, 0.53515625, 0.2890625, 0.6328125}, --accepted
	{0.36328125, 0.53515625, 0.6484375, 0.9921875}, --declined
}

function status:GetIcon(unit)
	return "7526019"
end

function status:GetTexCoord(unit)
	local c = SummonCoords[ IncomingSummonStatus(unit) ] or SummonCoords[1]
	return c[1], c[2], c[3], c[4]
end

function status:GetText(unit)
	return texts[ IncomingSummonStatus(unit) ] or ""
end

Grid2.setupFunc["summon"] = function(baseKey, dbx)
	Grid2:RegisterStatus(status, {"text", "color", "icon"}, baseKey, dbx)
	return status
end

Grid2:DbSetStatusDefaultValue( "summon", {type = "summon", colorCount = 3, color1 = {r=1,g=1,b=0,a=1}, color2 = {r=0,g=1,b=0,a=1}, color3 = {r=1,g=0,b=0,a=1} })
