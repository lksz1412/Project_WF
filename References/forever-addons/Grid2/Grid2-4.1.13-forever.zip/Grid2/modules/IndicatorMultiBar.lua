--[[ Created by Michael ]]--

local Grid2 = Grid2
local Grid2Frame = Grid2Frame
local min = min
local floor = math.floor
local type = type
local pairs = pairs
local ipairs = ipairs
local canaccessvalue = Grid2.canaccessvalue

local POINTS = {
	HORIZONTAL = { [true] = "LEFT",   [false] = "RIGHT" }, -- normal, reverse fill
	VERTICAL   = { [true] = "BOTTOM", [false] = "TOP"   }, -- normal, reverse fill
	OPOSITE    = { LEFT = 'RIGHT', RIGHT = 'LEFT', TOP = 'BOTTOM', BOTTOM = 'TOP' },
}

-- Warning: SetClipChildren() enables flattening mode for child status bars, this implies that sublayers are
-- ignored for aura color textures anchored to the mainBar because those textures don't have the same parent.
-- Due to this we cannot use sublayers to put aura color textures between the main bar and the other bars,
-- because those textures are always painted on top of all bars.
-- To fix this issue the mainBar should have a different parent and a lower frameLevel than the other bars.
-- In flattening mode the frameLevel of the status bars are ignored by the render engine too and only
-- the frame level of the parent frame doing the clipping is used.
local function Bar_CreateHH(self, parent)
	local frame = self:Acquire("Frame", parent)
	frame:SetClipsChildren(true)
end

-- value assignments for different types of bars/statuses
local function SetMultibarLineValue(bar, unit, status)
	local state, invert = status:IsActive(unit)
	if invert then
		bar:SetAlphaFromBoolean(state, 0, 1) -- warning, assuming that "blink" inverted states dont exist
	elseif canaccessvalue(state) then
		bar:SetAlpha(state and 1 or 0) -- warning: state for unsecret statuses can be "blink" so dont use AlphaFromBoolean()
	else
		bar:SetAlphaFromBoolean(state, 1, 0)
	end
end

local function SetMultibarPercentValue(bar, unit, status, interpol)
	bar:SetValue(status:GetPercent(unit) or 0, interpol or bar.interpol)
end

local function SetMultibarMinMaxValue(bar, unit, status, interpol)
	local value, minVal, maxVal = status:GetValueMinMax(unit)
	bar:SetMinMaxValues(minVal, maxVal)
	bar:SetValue(value, interpol or bar.interpol)
end

-- release aura slot containers
local function ReleaseAuraColorsSlots(self, parent, f)
	local count = f.countSlots
	if count then
		for i=1,count do
			self:ReleaseAuraSlotButton(parent, i)
		end
		f.countSlots = nil
	end
end

-- Warning: This is an overrided indicator:Update() NOT the standard indicator:OnUpdate()
local function Bar_Update(self, parent, unit, status)
	if unit then
		local frame = parent[self.name]
		if frame then
			local textures = frame.myTextures
			if status then
				local index = self.priorities[status]
				textures[index]:SetMultibarValue(unit, status)
			else -- update due a layout or groupType change not from a status notifying a change
				for index, status in ipairs(self.statuses) do
					textures[index]:SetMultibarValue(unit, status, 0)
				end
			end
		end
	end
end

-- Warning: This is an overrided indicator:Update() NOT the standard indicator:OnUpdate()
local function Bar_UpdateMulti(self, parent, unit, status)
	if unit then
		local frame = parent[self.name]
		if frame then
			local textures = frame.myTextures
			if status then
				local indexes = self.priorities[status]
				repeat
					textures[indexes % 10]:SetMultibarValue(unit, status, 0)
					indexes = floor( indexes / 10 )
				until indexes==0
			else -- update due a layout or groupType change not from a status notifying a change
				for index, status in ipairs(self.bstatuses) do
					textures[index]:SetMultibarValue(unit, status, 0)
				end
			end
		end
	end
end

-- aura color textures have the same framelevel than the first bar, but in a higher draw layer
local function Bar_LayoutAuraColor(self, parent, f, level)
	ReleaseAuraColorsSlots(self, parent, f)
	if self.reverseMain then return end -- in this case main bar is never visible so colorization is not need
	local color = self.sideKick
	if color.auraMode then
		local setup = self.bars[1]
		local tex = f.myCTextures and f.myCTextures[1]
		if tex and setup then
			for filter, status, index in color:IterateStatusAurasFilters(self.maxSlots) do
				self:AcquireAuraSlotButton(parent, filter, function(_, _, button)
					button:ClearAllPoints()
					button:SetAllPoints(f)
					button:SetFrameLevel(level)
					local ctex = button.__texture or button:CreateTexture(nil, "OVERLAY", nil, -index)
					ctex:ClearAllPoints(tex)
					ctex:SetTexture(setup.texture, setup.horWrap, setup.verWrap)
					ctex:SetHorizTile(setup.horWrap~='CLAMP')
					ctex:SetVertTile(setup.verWrap~='CLAMP')
					ctex:SetBlendMode('BLEND')
					ctex:SetAllPoints(tex)
					button:ClearDispelTypeTextures()
					button:AddDispelTypeTexture(ctex, filter.borderOptions)
					button.__texture = ctex
					f.countSlots = index
				end, nil, index)
			end
		end
	end
end

-- First bar should have different parent to avoid SetClipsChildren() flattening issue when aura color textures are anchored to the main bar.
-- The game ignores frameLevel assigned to statusbars because SetClipsChildren() is enabled in parent frame, except for the main bar when
-- it has a different parent, in this case: first statusbar frame level = frameLevel, and others bars inherits its parent frame level = frameLevel+1.
-- Aura color textures are set in the same frameLevel than first status bar but in a higher draw layer, ensuring aura color textures are drawn over
-- the first bar (+0 frameLevel) but behind the other bars (+1 framelevel).
local function Bar_Layout(self, parent)
	local frame = parent[self.name]
	local width = self.width  or parent.container:GetWidth()
	local height = self.height or parent.container:GetHeight()
	local frameLevel = parent:GetFrameLevel() + self.frameLevel
	local auraMode = self.sideKick.auraMode
	frame:SetParent(parent)
	frame:ClearAllPoints()
	frame:SetFrameLevel(frameLevel+1) -- for aura colors the first bar goes behind this frame and it has different parent: first bar = frameLevel / other bars = framelevel+1
	frame:SetSize(width, height)
	frame:SetPoint(self.anchor, parent.container, self.anchorRel, self.offsetx, self.offsety)
	-- bars
	local prevTex = frame
	local prevPnt = self.alignPoint
	local barSetup = self.bars
    local barCount = #barSetup
	local textures = frame.myTextures or {}
	local ctextures
	for i=1,barCount do
		local setup = barSetup[i]
		local texture = textures[i] or CreateFrame("StatusBar") -- texture is a StatusBar frame, not a texture
		texture:Hide()
		texture:SetParent((auraMode and setup.auraParent) and parent or frame)
		texture:SetFrameLevel(frameLevel) -- this has effect only on the first bar and only when aura colorization (auraMode) is enabled
		texture:ClearAllPoints()
		texture:SetMinMaxValues(0, 1)
		texture:SetValue(setup.defValue or 0)
		texture:SetOrientation(self.orientation)
		texture:SetReverseFill(setup.reverse)
		texture:SetStatusBarTexture(setup.texture) -- , "ARTWORK", setup.sublayer)
		local textureReal = texture:GetStatusBarTexture()
		textureReal.myOpacity = setup.opacity
		textureReal:SetTexCoord(0,1,0,1)
		textureReal:SetTexture(setup.texture, setup.horWrap, setup.verWrap)
		textureReal:SetHorizTile(setup.horWrap~='CLAMP')
		textureReal:SetVertTile(setup.verWrap~='CLAMP')
		textureReal:SetBlendMode(setup.lineBlend or 'BLEND')
		textureReal:SetDrawLayer("ARTWORK", setup.sublayer)
		local c = setup.color
		if c then
			textureReal:SetVertexColor( c.r, c.g, c.b, setup.opacity or 0 )
		else
			ctextures = ctextures or {}; ctextures[#ctextures+1] = textureReal
		end
		local prevBarIndex = setup.prevBar
		if prevBarIndex then
			if textures[prevBarIndex] then
				prevTex, prevPnt = textures[prevBarIndex]:GetStatusBarTexture(), barSetup[prevBarIndex].pointTo
			else -- prevBarIndex==0 => attach to frame start, prevBarIndex==-1 attach to frame end
				prevTex, prevPnt = frame, prevBarIndex==0 and self.alignPoint or self.alignPointOp
			end
		end
		if setup.background then
			texture:SetAllPoints(frame)
		elseif setup.lineSize then
			texture.SetMultibarValue = SetMultibarLineValue
			if self.orientation == "HORIZONTAL" then
				texture:SetSize( setup.lineSize, height )
				texture:SetPoint( setup.pointFrom, prevTex, prevPnt, setup.lineAdjust, 0 )
			else
				texture:SetSize( width, setup.lineSize )
				texture:SetPoint( setup.pointFrom, prevTex, prevPnt, 0, setup.lineAdjust )
			end
		else
			local status = self.bstatuses[i]
			texture.SetMultibarValue = (status and status.GetValueMinMax and SetMultibarMinMaxValue) or SetMultibarPercentValue
			texture:SetSize( width, height )
			texture:SetPoint( setup.pointFrom, prevTex, prevPnt )
			prevTex = textureReal
			prevPnt = setup.pointTo
			texture.interpol = setup.interpol
		end
		textures[i] = texture
		texture:Show()
	end
	for i=barCount+1,#textures do
		textures[i]:Hide()
		textures[i]:ClearAllPoints()
	end
	frame.myTextures = textures -- statusbars
	frame.myCTextures = ctextures -- real textures
	frame.myBTexture = self.backColor and textures[barCount]:GetStatusBarTexture() or nil -- back texture
	frame:Show()
	-- aura container colorization
	Bar_LayoutAuraColor(self, parent, frame, frameLevel)
end

local function Bar_SetOrientation(self, orientation)
	self.dbx.orientation = orientation
	self.orientation = orientation or Grid2Frame.db.profile.orientation
end

local function Bar_Disable(self, parent)
	local bar = parent[self.name]
	local textures = bar.myTextures
	if textures then
		for i=1,#textures do
			textures[i]:Hide()
		end
	end
	bar:Hide()
	bar:SetParent(nil)
	bar:ClearAllPoints()
	ReleaseAuraColorsSlots(self, parent, bar)
end

local function Bar_SortStatusesMulti(self)
	local statuses = self.statuses
	table.sort(statuses, self.sortStatuses)
	local bstatuses = self.bstatuses
	wipe(bstatuses)
	for _, status in ipairs(statuses) do
		local indexes = self.priorities[status]
		repeat
			bstatuses[indexes % 10] = status
			indexes = floor( indexes / 10 )
		until indexes==0
	end
end

local function Bar_SortStatusesSingle(self)
	table.sort(self.statuses, self.sortStatuses)
end

local function Bar_UpdateDB(self)
	local bars         = {}
	local dbx          = self.dbx
	local l            = dbx.location
	local theme        = Grid2Frame.db.profile
	local orientation  = dbx.orientation or theme.orientation
	local backColor    = dbx.backColor
	local texColor     = dbx.textureColor.r and dbx.textureColor
	local alignPoint   = POINTS[orientation][not dbx.reverseFill]
	local opositePoint = POINTS.OPOSITE
	self.backColor     = backColor
	self.foreColor     = dbx.invertColor and backColor or texColor
	self.orientation   = orientation
	self.alignPoint    = alignPoint
	self.alignPointOp  = opositePoint[alignPoint]
	self.frameLevel    = self:GetFrameLevel(dbx.level)
	self.anchor        = l.point
	self.anchorRel     = l.relPoint
	self.offsetx       = l.x
	self.offsety       = l.y
	self.width         = dbx.width
	self.height        = dbx.height
	self.horizontal    = (orientation == "HORIZONTAL")
	self.reverseFill   = not not dbx.reverseFill
	self.backAnchor    = dbx.backAnchor -- anchor background to mainBar
	self.reverseMain   = dbx.reverseMainBar
	self.bars          = bars
	local mainBar = {
		reverse   =  not ( not self.reverseFill == not dbx.reverseMainBar ),
		pointFrom  = dbx.reverseMainBar and opositePoint[alignPoint] or alignPoint,
		pointTo    = dbx.reverseMainBar and alignPoint or opositePoint[alignPoint],
		interpol   = dbx.interpolation or 0,
		opacity    = dbx.textureColor.a,
		color      = self.foreColor,
		texture    = Grid2:MediaFetch("statusbar", dbx.texture or theme.barTexture, "Gradient"),
		horWrap    = dbx.horTile or 'CLAMP',
		verWrap    = dbx.verTile or 'CLAMP',
		sublayer   = 0,
		auraParent = not dbx.reverseMainBar,
	}
	bars[1] = mainBar
	for i,setup in ipairs(dbx) do
		bars[#bars+1] = {
			reverse  = not ( not self.reverseFill == not setup.reverse ),
			prevBar   = (setup.prevBar and setup.prevBar<=i and setup.prevBar) or nil,
			pointFrom = (setup.glowLine and 'CENTER') or (setup.reverse and opositePoint[alignPoint] or alignPoint),
			pointTo   = setup.reverse and alignPoint or opositePoint[alignPoint],
			interpol  = setup.interpolation or 0,
			opacity   = setup.color.a,
			color     = setup.color.r and setup.color or self.foreColor,
			texture   = setup.texture and Grid2:MediaFetch("statusbar", setup.texture) or mainBar.texture,
			horWrap   = setup.horTile or 'CLAMP',
			verWrap   = setup.verTile or 'CLAMP',
			sublayer  = setup.glowLine and 7 or i,
			lineSize  = setup.glowLine,
			lineBlend = setup.glowLine and (setup.blendMode or 'ADD') or nil,
			lineAdjust= setup.glowLine and (setup.glowLineAdjust or 0) or nil,
			defValue  = setup.glowLine and 1 or nil,
		}
	end
	if backColor then
	    bars[#bars+1] = {
			reverse = false,
			pointFrom = alignPoint,
			pointTo   = opositePoint[alignPoint],
			texture = dbx.backTexture and Grid2:MediaFetch("statusbar", dbx.backTexture) or mainBar.texture,
			horWrap = dbx.backHorTile or 'CLAMP',
			verWrap = dbx.backVerTile or 'CLAMP',
			color = dbx.invertColor and texColor or backColor,
			opacity = backColor.a,
			prevBar = 1,
			sublayer = -1,
			defValue = 1,
			background = not self.backAnchor,
			auraParent = not self.backAnchor,
		}
	end
	if dbx.multiStatus then -- at least one status linked to several bars: status priority stores several bar indexes
		self.bstatuses = (self.statuses~=self.bstatuses) and self.bstatuses or {}
		self.SortStatuses = Bar_SortStatusesMulti
		self.UpdateO = Bar_UpdateMulti
	else -- no repeated statuses: status priority == bar index
		self.bstatuses = self.statuses
		self.SortStatuses = Bar_SortStatusesSingle
		self.UpdateO = Bar_Update
	end
    self.Update = self.UpdateO
	self.maxSlots = Grid2.db.profile.formatting.maxAuraColorSlots or 3
end

--{{ Bar Color indicator

local function BarColor_OnUpdate(self, parent, unit, status)
	if status then
		self:SetBarColor(parent, status:GetColor(unit))
	else
		self:SetBarColor(parent, 0, 0, 0, 0)
	end
end

-- foreground bar texture colorize
local function BarColor_SetBarColor(self, parent, r, g, b, a)
	local frame = parent[self.parentName]
	if frame then
		local textures = frame.myCTextures
		if textures then
			for i=#textures,1,-1 do
				local tex = textures[i]
				tex:SetVertexColor( r, g, b, tex.myOpacity or a or 1 )
			end
		end
	end
end

-- background bar texture colorize
local function BarColor_SetBarColorInverted(self, parent, r, g, b, a)
	local frame = parent[self.parentName]
	if frame then
		local texture = frame.myBTexture
		if texture then
			texture:SetVertexColor(r, g, b, a)
		end
	end
end

local function BarColor_UpdateDB(self)
	local dbx = self.dbx
	self.SetBarColor = dbx.invertColor and BarColor_SetBarColorInverted or BarColor_SetBarColor
	self.OnUpdate = dbx.textureColor.r and Grid2.Dummy or BarColor_OnUpdate
end

--- }}}

local function Create(indicatorKey, dbx)
	local Bar = Grid2.indicatorPrototype:new(indicatorKey)
	Bar.dbx = dbx
	-- invert sort order to fast lookup bar index: priorities[status] == barIndex / statuses[priorities[status]] == status
	Bar.sortStatuses   = function (a,b) return Bar.priorities[a] < Bar.priorities[b] end
	Bar.Create         = Bar_CreateHH
	Bar.SetOrientation = Bar_SetOrientation
	Bar.Disable        = Bar_Disable
	Bar.Layout         = Bar_Layout
	Bar.UpdateDB       = Bar_UpdateDB
	Bar.UpdateO        = Bar_Update -- special case used by multibar and icons indicator
	Grid2:RegisterIndicator(Bar, { "percent", "color" })

	local BarColor      = Grid2.indicatorPrototype:new(indicatorKey.."-color")
	BarColor.dbx        = dbx
	BarColor.parentName = indicatorKey
	BarColor.Create     = Grid2.Dummy
	BarColor.Layout     = Grid2.Dummy
	BarColor.UpdateDB   = BarColor_UpdateDB
	Grid2:RegisterIndicator(BarColor, { "color" })
	Bar.sideKick = BarColor

	return Bar, BarColor
end

Grid2.setupFunc["multibar"] = Create

Grid2.setupFunc["multibar-color"] = Grid2.Dummy
