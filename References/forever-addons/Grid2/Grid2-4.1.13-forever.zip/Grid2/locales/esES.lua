local L =  LibStub:GetLibrary("AceLocale-3.0"):NewLocale("Grid2", "esES")
if not L then return end

--{{{ Actually used
L["Border"] = "Borde"
L["Charmed"] = "Controlado"
L["Default"] = "Predeterminado"
L["Grid2"] = "Grid2"
L["Beast"] = "Bestia"
L["Demon"] = "Demonio"
L["Humanoid"] = "Humanoide"
L["Elemental"] = "Elemental"
--}}}

--{{{ Health
L["DEAD"] = "Muerto"
L["GHOST"] = "Fantasma"
L["FD"] = "F.M."
L["Offline"] = "Desc"
--}}}

--{{{ Pvp
L["PvP"] = "JcJ"
-- L["FFA"] = ""
--}}}

--{{{ Range
L["OOR"] = "FDR"
--}}}

--{{{ ReadyCheck
-- L["?"] = ""
-- L["R"] = ""
-- L["X"] = ""
L["AFK"] = "AUS"
--}}}

--{{{ Target
L["target"] = "objetivo"
--}}}

--{{{ Vehicle
L["vehicle"] = "vehículo"
--}}}

--{{{ VoiceComm
L["talking"] = "hablando"
--}}}

--{{{ DungeonRole
L["TANK"] = "Tanque"
L["HEALER"] = "Curador"
L["DAMAGER"] = "Daño"
--}}}

--{{{ SpecRole
L["Tank"] = "Tanque"
L["Healer"] = "Healer"
L["Melee"] = "Melee"
L["Ranged"] = "Rango"
--}}}

--{{{ Other roles
L["RL"] = "RL"
L["RA"] = "RA"
L["ML"] = "MD"
--}}}

--{{{ Resurrection
L["Reviving"] = "Reviviendo"
L["Revived"] = "Revivido"
---}}}

--{{{ Self
L["Me"] = "Yo"
---}}}

--{{{ Combat
L["combat"] = "Combate"
--}}

--{{{ Summon
L["Pending"] = "Pendiente"
L["Accepted"] = "Aceptado"
L["Declined"] = "Rechazado"
---}}}

--Layouts
L["None"] = "Ninguno"
L["Solo"] = "Solo"
L["Solo w/Pet"] = "Solo c/Pet"
L["Party"] = "Grupo"
L["Party w/Pets"] = "Grupo c/Pets"
L["By Role"] = "Por Rol"
L["By Role w/Pets"] = "Por Rol c/Pets"
L["By Role | 10x4"] = "Por Rol | 10x4"
L["By Role & Player First"] = "Por Rol & Yo Primero"
L["By Group"] = "Por Grupo"
L["By Group w/Pets"] = "Por Grupo c/Pets"
L["By Group w/Tanks"] = "Por Grupo c/Tanques"
L["By Group & Role"] = "Por Grupo & Rol"
L["By Class"] = "Por Clase"
L["By Class w/Pets"] = "Por Clase c/Pets"
L["By Class | 1x25"] = "Por Clase | 1x25"
L["By Class | 2x15"] = "Por Clase | 2x15"
L["By Group | 40"] = "Por Grupo | 40"
L["By Group | 40 w/Pets"] = "Por Grupo | 40 c/Pets"
L["By Group | 4x10"] = "Por Grupo | 4x10"
L["By Group | 4x10 w/Pets"] = "Por Grupo | 4x10 c/Pets"
L["Select Layout"] = "Elige Diseño"
L["By Group & Class"] = "Por Grupo & Clase"
L["By Group & Class w/Pets"] = "Por Grupo & Clase c/Pets"
L["By Group & Role w/Pets"] = "Por Grupo & Rol c/Pets"
