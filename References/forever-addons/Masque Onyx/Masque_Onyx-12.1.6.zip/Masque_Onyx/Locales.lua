--[[

	This file is part of 'Masque: Onyx', an add-on for World of Warcraft. For bug reports,
	documentation and license information, please visit https://github.com/SFX-WoW/Masque_Onyx.

	* File...: Locales.lua
	* Author.: StormFX

]]

local _, Core = ...

----------------------------------------
-- Locals
---

local Locale = GetLocale()
local L = {}

----------------------------------------
-- Core
---

Core.Locale = setmetatable(L, {
	__index = function(self, k)
		self[k] = k
		return k
	end
})

----------------------------------------
-- Localization
---

if Locale == "deDE" then

elseif Locale == "esES" or Locale == "esMX" then

elseif Locale == "frFR" then

elseif Locale == "itIT" then

elseif Locale == "koKR" then

elseif Locale == "ptBR" then
L["A dark skin with slightly rounded corners."] = "Uma aparência escura com cantos levemente arredondados."
L["The classic Onyx skin with arrow indicators."] = "A aparência Onyx clássica com indicadores de seta."

elseif Locale == "ruRU" then
L["A dark skin with slightly rounded corners."] = "Темный скин со слегка закругленными углами."
L["The classic Onyx skin with arrow indicators."] = "Классический скин Onyx со стрелочными индикаторами."

elseif Locale == "zhCN" then

elseif Locale == "zhTW" then
L["A dark skin with slightly rounded corners."] = "一個暗黑外觀帶有圓潤的邊角。"
L["The classic Onyx skin with arrow indicators."] = "經典的Onyx外觀搭配箭頭指示器。"

end
