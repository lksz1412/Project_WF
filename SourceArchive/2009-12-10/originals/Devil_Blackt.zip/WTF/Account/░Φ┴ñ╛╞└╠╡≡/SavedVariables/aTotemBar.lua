
aTotemBarDB = {
}
