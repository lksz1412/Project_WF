
DuraTek = {
	["profiles"] = {
		["Default"] = {
			["detachedTooltip"] = {
			},
		},
	},
}
