
BagFuDB = {
	["profiles"] = {
		["Default"] = {
			["detachedTooltip"] = {
			},
		},
	},
}
