
OmniCCDB = {
	["minFinishEffectDuration"] = 30,
	["fontSize"] = 14,
	["showModel"] = 1,
	["useMMSS"] = 1,
	["minDuration"] = 2,
	["font"] = "데미지 글꼴",
	["style"] = {
		["secs"] = {
			["b"] = 0.4,
			["s"] = 1,
			["g"] = 1,
			["r"] = 1,
		},
		["mins"] = {
			["b"] = 0.9,
			["s"] = 0.9,
			["g"] = 0.8,
			["r"] = 0.8,
		},
		["short"] = {
			["b"] = 0,
			["s"] = 1.25,
			["g"] = 0,
			["r"] = 1,
		},
		["days"] = {
			["b"] = 0.9,
			["s"] = 0.65,
			["g"] = 0.8,
			["r"] = 0.8,
		},
		["hrs"] = {
			["b"] = 0.9,
			["s"] = 0.8,
			["g"] = 0.8,
			["r"] = 0.8,
		},
	},
	["fontOutline"] = "OUTLINE",
	["minScale"] = 0.800000011920929,
	["version"] = "2.5.8",
}
