local _, wt = ...
local refreshCraftingTab

wt.ProfessionIcon = wt.createIconSetting("WT_ProfessionIcon", {
    {key = "question", texture = "Interface\\Icons\\INV_Misc_QuestionMark", name = wt.L.ADDON_ICON_QUESTION_MARK},
    {key = "toolbox", texture = "Interface\\Icons\\INV_Misc_EngGizmos_19", name = wt.L.PROFESSION_ICON_TOOLBOX},
    {key = "workshop", texture = "Interface\\Icons\\Garrison_Building_Workshop", name = wt.L.PROFESSION_ICON_WORKSHOP},
    {key = "recipe", texture = "Interface\\Icons\\INV_Misc_Note_06", name = wt.L.PROFESSION_ICON_RECIPE_NOTE},
})

local function professionTabPosition()
    if WT_ProfessionTabPosition == "top" or WT_ProfessionTabPosition == "bottom" then return WT_ProfessionTabPosition end
    return "right"
end

local function setProfessionTabPosition(position)
    WT_ProfessionTabPosition = position
    if wt.PositionCraftingTab then wt.PositionCraftingTab() end
end

local function setProfessionTabHidden(hidden)
    WT_HideProfessionTab = hidden
    if refreshCraftingTab then refreshCraftingTab() end
end

function wt.GenerateProfessionTabPositionMenu(_, menu)
    for _, option in ipairs({
        {wt.L.PROFESSION_TAB_TOP, "top"},
        {wt.L.PROFESSION_TAB_RIGHT, "right"},
        {wt.L.PROFESSION_TAB_BOTTOM, "bottom"},
    }) do
        menu:CreateRadio(option[1], function(position) return professionTabPosition() == position end,
            setProfessionTabPosition, option[2])
    end
end

function wt.GenerateProfessionTabMenu(owner, menu)
    wt.GenerateProfessionTabPositionMenu(owner, menu)
    menu:CreateDivider()
    menu:CreateCheckbox(wt.L.HIDE_PROFESSION_TAB, function() return WT_HideProfessionTab == true end, function()
        setProfessionTabHidden(not WT_HideProfessionTab)
        return MenuResponse.CloseAll
    end)
    menu:CreateDivider()
    menu:CreateTitle(wt.L.ADDON_ICON_TITLE)
    menu:CreateIconRow(wt.ProfessionIcon)
end

function wt.MoveProfessionTab(direction)
    if direction == "hide" or direction == "show" then
        setProfessionTabHidden(direction == "hide")
        return
    end
    local position = professionTabPosition()
    if direction == "up" then
        position = position == "bottom" and "right" or "top"
    elseif direction == "down" then
        position = position == "top" and "right" or "bottom"
    elseif direction == "reset" then
        position = "right"
    else
        return
    end
    setProfessionTabPosition(position)
end

-- covers the native profession page
local function attach()
    local book = ProfessionsFrame
    if not book.ProfessionsOverviewTab then return end

    local active, selectedTab, queued, controller
    local nativeTabs = {book.ProfessionsOverviewTab}
    for _, tab in ipairs(book.rightProfessionTabs) do
        tinsert(nativeTabs, tab)
    end

    local page = CreateFrame("Frame", "WhatsTrainingCraftingPage", book)
    page:Hide()
    page:SetPoint("TOPLEFT", book, "TOPLEFT", 3, -24)
    page:SetPoint("BOTTOMRIGHT", book, "BOTTOMRIGHT", -3, 3)
    page:EnableMouse(true)
    page:EnableMouseWheel(true)
    page:SetScript("OnMouseWheel", function() end)
    local function paint(container)
        local canvas = CreateFrame("Frame", nil, container)
        canvas:SetAllPoints(page)
        local backing = canvas:CreateTexture(nil, "BACKGROUND")
        backing:SetAllPoints()
        backing:SetColorTexture(0.06, 0.05, 0.04, 1)
        -- the native atlas's first 54px hold the full header and crease
        local header = CreateFrame("Frame", nil, canvas)
        header:SetPoint("TOPLEFT", book, "TOPLEFT", 3, -21)
        header:SetPoint("TOPRIGHT", book, "TOPRIGHT", -3, -21)
        header:SetHeight(54)
        header:SetClipsChildren(true)
        local headerArt = header:CreateTexture(nil, "ARTWORK")
        headerArt:SetAtlas("Profession-Background-Template2", true)
        headerArt:SetPoint("TOPLEFT", header, "TOPLEFT")
        headerArt:SetPoint("TOPRIGHT", header, "TOPRIGHT")
        local art = canvas:CreateTexture(nil, "ARTWORK")
        art:SetAtlas("Profession-Background-Overview")
        art:SetAllPoints()
    end
    paint(page)

    local title = CreateFrame("Frame", "WhatsTrainingCraftingTitle", page)
    title:SetAllPoints(book.NineSlice.TopEdge)
    title:SetClipsChildren(true)
    local titleCanvas = CreateFrame("Frame", nil, title)
    titleCanvas:SetAllPoints(book.NineSlice.TopEdge)
    local titleBacking = titleCanvas:CreateTexture(nil, "BACKGROUND")
    titleBacking:SetAllPoints()
    titleBacking:SetAtlas(book.NineSlice.TopEdge:GetAtlas())
    titleBacking:SetHorizTile(true)
    title.backing = titleBacking
    title.art = CreateFrame("Frame", nil, titleCanvas)
    title.art:SetAllPoints(titleCanvas)
    title.Text = title.art:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title.Text:SetWordWrap(false)
    title.Text:SetText(wt.L.TITLE)

    local portrait = CreateFrame("Frame", "WhatsTrainingCraftingPortrait", page)
    portrait:SetAllPoints(book.PortraitContainer)
    portrait.Icon = portrait:CreateTexture(nil, "OVERLAY")
    portrait.Icon:SetAllPoints(book.PortraitContainer.portrait)
    portrait.Icon:SetTexture("Interface\\Icons\\INV_SideTab_Professions_c60")
    local mask = portrait:CreateMaskTexture(nil, "OVERLAY")
    mask:SetAllPoints(book.PortraitContainer.CircleMask)
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    portrait.Icon:AddMaskTexture(mask)
    -- gamepad raises the icon above NineSlice
    portrait.Border = portrait:CreateTexture(nil, "OVERLAY", nil, 1)
    portrait.Border:SetAllPoints(book.NineSlice.TopLeftCorner)
    portrait.Border:Hide()
    portrait.RightBorder = portrait:CreateTexture(nil, "OVERLAY", nil, 1)
    portrait.RightBorder:SetAllPoints(book.NineSlice.TopRightCorner)
    portrait.RightBorder:Hide()

    -- rank bars sit in HIGH strata: cover only their rectangles so the native portrait and border stay above the page
    local content = book.BookPage.ProfessionsContentFrame
    local bars = {book.CraftingPage.RankBar}
    for _, key in ipairs({"PrimaryProfession1", "PrimaryProfession2", "SecondaryProfession1", "SecondaryProfession2",
        "SecondaryProfession3"}) do
        tinsert(bars, content[key].StatusBar)
    end
    for _, bar in ipairs(bars) do
        local cover = CreateFrame("Frame", nil, page)
        -- border and fill extend below the 18px bar frame
        cover:SetPoint("TOPLEFT", bar.Border, "TOPLEFT", -2, 2)
        cover:SetPoint("BOTTOMRIGHT", bar.Border, "BOTTOMRIGHT", 2, -2)
        cover:SetFrameStrata("HIGH")
        cover:SetFrameLevel(bar:GetFrameLevel() + 10)
        cover:SetClipsChildren(true)
        cover:EnableMouse(true)
        paint(cover)
    end

    local function makeTab(name)
        local tab = CreateFrame("Frame", name, book, "LargeSideTabButtonTemplate")
        tab:Hide()
        tab:EnableMouse(true)
        tab:SetFillToInterior(true)
        tab:SetChecked(false)
        tab:HookScript("OnHide", function(self)
            local tooltip = GetAppropriateTooltip()
            if tooltip:IsOwned(self) then tooltip:Hide() end
        end)
        return tab
    end

    local launcher = makeTab("WhatsTrainingCraftingTab")
    launcher.Icon:SetTexture(wt.ProfessionIcon.texture())
    wt.ProfessionIcon.onChanged(function(icon) launcher.Icon:SetTexture(icon) end)
    launcher.tooltipText = wt.L.TAB_TEXT
    local width, height = launcher:GetSize()
    local iconOffsets = launcher.GetFinalIconAnchorOffsets
    local bottom
    function launcher:GetFinalIconAnchorOffsets()
        local x, y = iconOffsets(self)
        if bottom then return y, -x end
        return x, y
    end
    local chrome = {launcher.Background, launcher.Mask, launcher.SelectedTexture, launcher.TabGlow, launcher.HighlightTexture}
    function wt.PositionCraftingTab()
        local position = professionTabPosition()
        bottom = position == "bottom"
        launcher:SetSize(bottom and height or width, bottom and width or height)
        for _, texture in ipairs(chrome) do texture:SetRotation(bottom and -math.pi / 2 or 0) end
        launcher:InitializeIconAnchoring()
        launcher:ClearAllPoints()
        if position == "top" then
            launcher:SetPoint("BOTTOMLEFT", book.ProfessionsOverviewTab, "TOPLEFT", 0, 2)
        elseif bottom then
            launcher:SetPoint("TOPRIGHT", book, "BOTTOMRIGHT", -10, 0)
        else
            launcher:SetPoint("BOTTOMLEFT", book, "BOTTOMRIGHT", 0, 10)
        end
    end
    local returnTab = makeTab("WhatsTrainingCraftingReturnTab")
    local recipeList = wt.CreateRecipeList(page)
    -- make sure we cover everything below us, like auctionator prices
    local background = CreateFrame("Frame", nil, recipeList)
    background:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -51) -- matches the recipe viewport
    background:SetPoint("BOTTOMRIGHT", page, "BOTTOMRIGHT")
    background:SetClipsChildren(true)
    background:SetFrameLevel(recipeList:GetFrameLevel() - 2)
    paint(background)

    local function selectedNativeTab()
        local selected
        for _, tab in ipairs(nativeTabs) do
            if tab:IsShown() and tab.SelectedTexture:IsShown() then selected = tab end
        end
        return selected
    end

    local function refreshPage()
        if InputUtil.IsGamepadUIEnabled() then
            title:SetFrameLevel(recipeList:GetFrameLevel() + 1)
            portrait:SetFrameLevel(title.art:GetFrameLevel() + 1)
        end
        wt.PaintCraftingHeader(title, portrait, book)
        if recipeList.needsRefresh then recipeList:Refresh()
        elseif recipeList.needsIgnoreUpdate then recipeList:Filter() end
    end

    local function sync()
        queued = false
        if WT_HideProfessionTab then
            active = false
            if controller then controller:Deactivate() end
            launcher:Hide()
            page:Hide()
            returnTab:Hide()
            return
        end
        if InputUtil.IsGamepadUIEnabled() then
            active = false
            if not controller then
                controller = wt.EnableCraftingController(book, page, recipeList, launcher, returnTab,
                    selectedNativeTab, refreshPage)
            end
            controller:Sync()
            return
        end
        if controller then controller:Deactivate() end
        if not book:IsVisible() then
            active = false
            page:Hide()
            launcher:Hide()
            returnTab:Hide()
            return
        end

        local selected = selectedNativeTab()
        -- opened over a forevercore tab, no native tab was checked yet
        if active and not selectedTab then selectedTab = selected end
        if selected ~= selectedTab then active = false end

        local level = book.PortraitContainer:GetFrameLevel() - 10
        page:SetFrameLevel(level)
        recipeList:SetFrameLevel(level + 1000)
        title:SetFrameLevel(book.TitleContainer:GetFrameLevel() + 1)
        portrait:SetFrameLevel(book.PortraitContainer:GetFrameLevel() + 1)
        launcher:SetFrameLevel(level + 1)
        returnTab:SetFrameLevel(level + 1)
        wt.PositionCraftingTab()
        launcher:SetChecked(active)
        launcher:Show()
        page:SetShown(active)
        if active then
            refreshPage()
        end

        returnTab:SetShown(active and selected ~= nil)
        if active and selected then
            returnTab:ClearAllPoints()
            returnTab:SetPoint("CENTER", selected)
            returnTab.Icon:SetTexture(selected.Icon:GetTexture())
            returnTab.tooltipText = selected.tooltipText
        end
    end
    refreshCraftingTab = sync

    local function request()
        if queued then return end
        queued = true
        RunNextFrame(sync)
    end

    local function deactivate()
        active = false
        if controller then controller:Hide() end
        request()
    end

    launcher:SetCustomOnMouseUpHandler(function(_, button, upInside)
        if not upInside then return end
        if button == "RightButton" then
            if InputUtil.IsGamepadUIEnabled() then
                if controller then controller:OpenPositionMenu() end
            else
                wt.Forever.openContextMenu(launcher, wt.GenerateProfessionTabMenu)
            end
            return
        end
        if button ~= "LeftButton" then return end
        -- skillup forever's tabs share this window
        if ForeverCore and ForeverCore.ProfessionTabs and ForeverCore.ProfessionTabs.Selected() then ForeverCore.ProfessionTabs.ShowNative() end
        if InputUtil.IsGamepadUIEnabled() then
            if controller then controller:Toggle() end
            return
        end
        selectedTab = selectedNativeTab()
        active = not active
        sync()
    end)
    local function returnToNative(_, button, upInside)
        if button ~= "LeftButton" or not upInside then return end
        if controller then controller:Hide() end
        active = false
        sync()
    end
    returnTab:SetCustomOnMouseUpHandler(returnToNative)
    for _, tab in ipairs(nativeTabs) do
        tab:HookScript("OnMouseUp", returnToNative)
    end

    EventRegistry:RegisterCallback("ProfessionsFrame.Show", request, launcher)
    EventRegistry:RegisterCallback("ProfessionsFrame.Hide", deactivate, launcher)
    EventRegistry:RegisterCallback("Professions.ProfessionSelected", deactivate, launcher)
    EventRegistry:RegisterCallback("Professions.ShowSelectedCraftingPage", deactivate, launcher)
    book:HookScript("OnSizeChanged", request)
    if ForeverCore and ForeverCore.ProfessionTabs then hooksecurefunc(ForeverCore.ProfessionTabs, "Select", deactivate) end
    local function dataChanged()
        recipeList.needsRefresh = true
        request()
    end
    local actions = {
        SKILL_LINES_CHANGED = function()
            recipeList:UpdateProfessionSelections()
            recipeList.filterDropdown:GenerateMenu()
            dataChanged()
        end,
        SPELL_DATA_LOAD_RESULT = function(spellID, success)
            if wt.RecipeSpellDataLoaded(spellID, success) then dataChanged() end
        end,
        UPDATE_FACTION = dataChanged,
        NEW_RECIPE_LEARNED = dataChanged,
        SPELLS_CHANGED = dataChanged,
        PLAYER_LEVEL_UP = dataChanged,
        TRADE_SKILL_SHOW = deactivate,
        UI_SCALE_CHANGED = request,
        GAME_PAD_ACTIVE_CHANGED = request,
    }
    for event in pairs(actions) do
        launcher:RegisterEvent(event)
    end
    launcher:SetScript("OnEvent", function(_, event, ...) actions[event](...) end)
    request()
end

function wt.AttachCrafting()
    WT_HideProfessionTab = WT_HideProfessionTab == true
    WT_ProfessionIcon = wt.ProfessionIcon.normalize(WT_ProfessionIcon)
    EventUtil.ContinueOnAddOnLoaded("Blizzard_Professions", attach)
end
