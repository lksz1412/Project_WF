
--[=[

	SLIDER:
	When the value of the slider is changed, it'll call self.OnValueChanged if the value exists.
	slider.OnValueChanged = function(self, FixedValue, value) end
	All hooks set for "OnValueChanged" will also be called, example: slider:SetHook("OnValueChanged", function(self, FixedValue, value) end)

	SWITCH:
	When the value of the switch is changed, it'll call self.OnSwitch if the key exists.
	switch.OnSwitch = function(self, FixedValue, value) end
	All hooks set for "OnSwitch" will also be called, example: switch:SetHook("OnSwitch", function(self, FixedValue, value) end)

--]=]

---@type detailsframework
local DF = _G["DetailsFramework"]
if (not DF or not DetailsFrameworkCanLoad) then
	return
end

local _
local APISliderFunctions = false

do
	local metaPrototype = {
		WidgetType = "slider",
		dversion = DF.dversion
	}

	--check if there's a metaPrototype already existing
	if (_G[DF.GlobalWidgetControlNames["slider"]]) then
		--get the already existing metaPrototype
		local oldMetaPrototype = _G[DF.GlobalWidgetControlNames["slider"]]
		--check if is older
		if ( (not oldMetaPrototype.dversion) or (oldMetaPrototype.dversion < DF.dversion) ) then
			--the version is older them the currently loading one
			--copy the new values into the old metatable
			for funcName, _ in pairs(metaPrototype) do
				oldMetaPrototype[funcName] = metaPrototype[funcName]
			end
		end
	else
		--first time loading the framework
		_G[DF.GlobalWidgetControlNames["slider"]] = metaPrototype
	end
end

local DFSliderMetaFunctions = _G[DF.GlobalWidgetControlNames["slider"]]

DF:Mixin(DFSliderMetaFunctions, DF.SetPointMixin)
DF:Mixin(DFSliderMetaFunctions, DF.FrameMixin)
DF:Mixin(DFSliderMetaFunctions, DF.TooltipHandlerMixin)
DF:Mixin(DFSliderMetaFunctions, DF.ScriptHookMixin)

------------------------------------------------------------------------------------------------------------
--metatables

	DFSliderMetaFunctions.__call = function(object, value)
		if (not value) then
			if (object.isSwitch) then
				if (type(value) == "boolean") then
					object.slider:SetValue(1)
					return
				end

				if (object.slider:GetValue() == 1) then
					return false
				else
					return true
				end
			end

			return object.slider:GetValue()

		else
			if (object.isSwitch) then
				if (type(value) == "boolean") then
					if (value) then
						object.slider:SetValue(2)
					else
						object.slider:SetValue(1)
					end
				else
					object.slider:SetValue(value)
				end
				return
			end

			return object.slider:SetValue(value)
		end
	end

------------------------------------------------------------------------------------------------------------
--members

	--tooltip
	local gmember_tooltip = function(object)
		return object:GetTooltip()
	end

	--shown
	local gmember_shown = function(object)
		return object:IsShown()
	end

	--frame width
	local gmember_width = function(object)
		return object.slider:GetWidth()
	end

	--frame height
	local gmember_height = function(object)
		return object.slider:GetHeight()
	end

	--locked
	local gmember_locked = function(object)
		return rawget(object, "lockdown")
	end

	--fractional
	local gmember_fractional = function(object)
		return rawget(object, "useDecimals")
	end

	--value
	local gmember_value = function(object)
		return object()
	end

	DFSliderMetaFunctions.GetMembers = DFSliderMetaFunctions.GetMembers or {}
	DFSliderMetaFunctions.GetMembers["tooltip"] = gmember_tooltip
	DFSliderMetaFunctions.GetMembers["shown"] = gmember_shown
	DFSliderMetaFunctions.GetMembers["width"] = gmember_width
	DFSliderMetaFunctions.GetMembers["height"] = gmember_height
	DFSliderMetaFunctions.GetMembers["locked"] = gmember_locked
	DFSliderMetaFunctions.GetMembers["fractional"] = gmember_fractional
	DFSliderMetaFunctions.GetMembers["value"] = gmember_value

	DFSliderMetaFunctions.__index = function(object, key)
		local func = DFSliderMetaFunctions.GetMembers[key]
		if (func) then
			return func(object, key)
		end

		local alreadyHaveKey = rawget(object, key)
		if (alreadyHaveKey) then
			return alreadyHaveKey
		end

		return DFSliderMetaFunctions[key]
	end

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	--tooltip
	local smember_tooltip = function(object, value)
		return object:SetTooltip(value)
	end

	--show
	local smember_show = function(object, value)
		if (value) then
			return object:Show()
		else
			return object:Hide()
		end
	end

	--hide
	local smember_hide = function(object, value)
		if (not value) then
			return object:Show()
		else
			return object:Hide()
		end
	end

	--frame width
	local smember_width = function(object, value)
		return object.slider:SetWidth(value)
	end

	--frame height
	local smember_height = function(object, value)
		return object.slider:SetHeight(value)
	end

	--locked
	local smember_locked = function(object, value)
		if (value) then
			return object:Disable()
		else
			return object:Enable()
		end
	end

	--backdrop
	local smember_backdrop = function(object, value)
		return object.slider:SetBackdrop(value)
	end

	--fractional
	local smember_fractional = function(object, value)
		return rawset(object, "useDecimals", value)
	end

	--value
	local smember_value = function(object, value)
		object(value)
	end

	DFSliderMetaFunctions.SetMembers = DFSliderMetaFunctions.SetMembers or {}
	DFSliderMetaFunctions.SetMembers["tooltip"] = smember_tooltip
	DFSliderMetaFunctions.SetMembers["show"] = smember_show
	DFSliderMetaFunctions.SetMembers["hide"] = smember_hide
	DFSliderMetaFunctions.SetMembers["backdrop"] = smember_backdrop
	DFSliderMetaFunctions.SetMembers["width"] = smember_width
	DFSliderMetaFunctions.SetMembers["height"] = smember_height
	DFSliderMetaFunctions.SetMembers["locked"] = smember_locked
	DFSliderMetaFunctions.SetMembers["fractional"] = smember_fractional
	DFSliderMetaFunctions.SetMembers["value"] = smember_value

	DFSliderMetaFunctions.__newindex = function(object, key, value)
		local func = DFSliderMetaFunctions.SetMembers[key]
		if (func) then
			return func(object, value)
		else
			return rawset(object, key, value)
		end
	end

------------------------------------------------------------------------------------------------------------
--methods
	---return the UIObject (the underlying Blizzard slider frame) that is behind the wrapper table.
	function DFSliderMetaFunctions:GetUIObject()
		return self.widget
	end

	--fixed value
	function DFSliderMetaFunctions:SetFixedParameter(value)
		rawset(self, "FixedValue", value)
	end

	function DFSliderMetaFunctions:GetFixedParameter()
		return rawget(self, "FixedValue")
	end

	function DFSliderMetaFunctions:SetValueChangedFunction(newFunction)
		self.OnValueChanged = newFunction
	end

	--set value
	function DFSliderMetaFunctions:SetValue(value)
		return self(value)
	end

	function DFSliderMetaFunctions:SetValueNoCallback(value)
		self.NoCallback = true
		self.slider:SetValue(value)
	end

	-- thumb size
	function DFSliderMetaFunctions:SetThumbSize(width, height)
		--the track look keeps a round thumb sized by its template, a width-only resize would stretch it into an oval
		if (self.is_track) then
			return
		end

		if (not width) then
			width = self.thumb:GetWidth()
		end
		if (not height) then
			height = self.thumb:GetHeight()
		end
		return self.thumb:SetSize(width, height)
	end

	--clear focus
	function DFSliderMetaFunctions:ClearFocus()
		local editbox = DFSliderMetaFunctions.editbox_typevalue
		if editbox and self.typing_value then
			editbox:ClearFocus()
			editbox:Hide()
			editbox:GetParent().MyObject.typing_value = false
			editbox:GetParent().MyObject.value = self.typing_value_started
		end
	end

	--enabled
	function DFSliderMetaFunctions:IsEnabled()
		return not rawget(self, "lockdown")
	end

	function DFSliderMetaFunctions:Enable()
		self.slider:Enable()

		if (not self.is_checkbox) then
			if (not self.lock_texture) then
				DF:NewImage(self, [[Interface\PetBattles\PetBattle-LockIcon]], 12, 12, "overlay", {0.0546875, 0.9453125, 0.0703125, 0.9453125}, "lock_texture", "$parentLockTexture")
				self.lock_texture:SetDesaturated(true)
				self.lock_texture:SetPoint("center", self.amt, "center")
			end
			self.lock_texture:Hide()
		end

		--the track look shows the value only while hovering, and a slider with a value box shows it there
		if (not self.is_track and not self.value_box_shown) then
			self.slider.amt:Show()
		end
		if (self.value_box) then
			self.value_box:EnableMouse(true)
		end
		self:SetAlpha(1)

		if (self.is_checkbox) then
			self.checked_texture:Show()
		end

		DF:SetOptionLabelEnabled(self, true)
		return rawset(self, "lockdown", false)
	end

	function DFSliderMetaFunctions:Disable()
		self:ClearFocus()
		self.slider:Disable()
		self.slider.amt:Hide()
		if (self.value_box) then
			self.value_box:ClearFocus()
			self.value_box:EnableMouse(false)
		end
		self:SetAlpha(.4)

		if (not self.is_checkbox) then
			if (not self.lock_texture) then
				DF:NewImage(self, [[Interface\PetBattles\PetBattle-LockIcon]], 12, 12, "overlay", {0.0546875, 0.9453125, 0.0703125, 0.9453125}, "lock_texture", "$parentLockTexture")
				self.lock_texture:SetDesaturated(true)
				self.lock_texture:SetPoint("center", self.amt, "center")
			end

			--the track look keeps the value text above the thumb, the lock goes over the thumb instead
			self.lock_texture:ClearAllPoints()
			self.lock_texture:SetPoint("center", self.is_track and self.thumb or self.amt, "center")
			self.lock_texture:Show()
		end

		if (self.is_checkbox) then
			self.checked_texture:Show()
		end

		DF:SetOptionLabelEnabled(self, false)
		return rawset(self, "lockdown", true)
	end

------------------------------------------------------------------------------------------------------------
--scripts

	local OnEnter = function(slider)
		local object = slider.MyObject

		if (rawget(object, "lockdown")) then
			return
		end

		DetailsFrameworkSliderButtons1:ShowMe(slider, object.bAttachButtonsToLeft)

		local kill = object:RunHooksForWidget("OnEnter", slider, object)
		if (kill) then
			return
		end

		slider.thumb:SetAlpha(1)

		if (object.is_track and not object.value_box_shown) then
			slider.amt:Show()
		end

		if (object.onenter_backdrop_border_color) then
			slider:SetBackdropBorderColor(unpack(object.onenter_backdrop_border_color))
		end

		object:ShowTooltip()
	end

	local OnLeave = function(slider)
		local object = slider.MyObject

		if (rawget(object, "lockdown")) then
			return
		end

		DetailsFrameworkSliderButtons1:PrepareToHide()

		local kill = object:RunHooksForWidget("OnLeave", slider, object)
		if (kill) then
			return
		end

		--the track thumb stays solid, the value stays visible while the thumb is being dragged
		if (object.is_track) then
			if (not object.IsValueChanging) then
				slider.amt:Hide()
			end
		else
			slider.thumb:SetAlpha(.7)
		end

		if (object.onleave_backdrop_border_color) then
			slider:SetBackdropBorderColor(unpack(object.onleave_backdrop_border_color))
		end

		object:HideTooltip()
	end


	--parent frame for the plus and minus buttons which shows when the slider is hovered over
	local sliderButtonsParentFrame = DetailsFrameworkSliderButtons1 or CreateFrame("frame", "DetailsFrameworkSliderButtons1", UIParent, "BackdropTemplate")
	sliderButtonsParentFrame:Hide()
	sliderButtonsParentFrame:SetHeight(18) --width is set by setpoint

	C_Timer.After(0, function()
		if (not sliderButtonsParentFrame.__background) then
			DetailsFramework:ApplyStandardBackdrop(sliderButtonsParentFrame) --ApplyStandardBackdrop loads after this file
		end
		sliderButtonsParentFrame:SetBackdropBorderColor(0, 0, 0, 0)
		sliderButtonsParentFrame:SetBackdropColor(.05, .05, .05, .9)
	end)
	sliderButtonsParentFrame.isGoingToHide = false

	local timeToHide = 0
	local onUpdateTimeToHide = function(self, elapsed)
		timeToHide = timeToHide + elapsed
		if (timeToHide > 0.3) then
			sliderButtonsParentFrame:Hide()
			sliderButtonsParentFrame:SetScript("OnUpdate", nil)
			sliderButtonsParentFrame.isGoingToHide = false
		end
	end

	function sliderButtonsParentFrame:ShowMe(sliderFrame, bAnchorToLeft)
		sliderButtonsParentFrame.bAnchorToLeft = bAnchorToLeft
		sliderButtonsParentFrame:SetParent(sliderFrame)
		sliderButtonsParentFrame:ClearAllPoints()

		sliderButtonsParentFrame.buttonMinor:ClearAllPoints()
		sliderButtonsParentFrame.buttonPlus:ClearAllPoints()

		sliderButtonsParentFrame:SetWidth(35)

		if (sliderButtonsParentFrame.bAnchorToLeft) then
			sliderButtonsParentFrame:SetPoint("topright", sliderFrame, "topleft", 0, 0)
			sliderButtonsParentFrame:SetPoint("bottomright", sliderFrame, "bottomleft", 0, 0)
			sliderButtonsParentFrame.buttonPlus:SetPoint("right", sliderButtonsParentFrame, "right", -2, 0)
			sliderButtonsParentFrame.buttonMinor:SetPoint("right", sliderButtonsParentFrame.buttonPlus, "left", 0, 0)
		else
			sliderButtonsParentFrame:SetPoint("topleft", sliderFrame, "topright", 2, 0)
			sliderButtonsParentFrame:SetPoint("bottomleft", sliderFrame, "bottomright", 2, 0)
			sliderButtonsParentFrame.buttonMinor:SetPoint("left", sliderButtonsParentFrame, "left", 2, 0)
			sliderButtonsParentFrame.buttonPlus:SetPoint("left", sliderButtonsParentFrame.buttonMinor, "right", 0, 0)
		end

		sliderButtonsParentFrame:SetFrameStrata("FULLSCREEN")
		sliderButtonsParentFrame:SetFrameLevel(sliderFrame:GetFrameLevel() + 1000)
		sliderButtonsParentFrame:Show()

		if (sliderButtonsParentFrame.isGoingToHide) then
			sliderButtonsParentFrame:SetScript("OnUpdate", nil)
			sliderButtonsParentFrame.isGoingToHide = false
		end

		sliderButtonsParentFrame.host = sliderFrame.MyObject
	end

	function sliderButtonsParentFrame:PrepareToHide()
		sliderButtonsParentFrame.isGoingToHide = true
		timeToHide = 0
		sliderButtonsParentFrame:SetScript("OnUpdate", onUpdateTimeToHide)
	end

	local buttonPlus = DetailsFrameworkSliderButtonsPlusButton or CreateFrame("button", "DetailsFrameworkSliderButtonsPlusButton", sliderButtonsParentFrame, "BackdropTemplate")
	local buttonMinor = DetailsFrameworkSliderButtonsMinorButton or CreateFrame("button", "DetailsFrameworkSliderButtonsMinorButton", sliderButtonsParentFrame, "BackdropTemplate")
	buttonPlus:SetFrameStrata(sliderButtonsParentFrame:GetFrameStrata())
	buttonMinor:SetFrameStrata(sliderButtonsParentFrame:GetFrameStrata())
	sliderButtonsParentFrame.buttonPlus = buttonPlus
	sliderButtonsParentFrame.buttonMinor = buttonMinor

	buttonPlus:SetScript("OnEnter", function(self)
		if (sliderButtonsParentFrame.isGoingToHide) then
			sliderButtonsParentFrame:SetScript("OnUpdate", nil)
			sliderButtonsParentFrame.isGoingToHide = false
		end
	end)
	buttonMinor:SetScript("OnEnter", function(self)
		if (sliderButtonsParentFrame.isGoingToHide) then
			sliderButtonsParentFrame:SetScript("OnUpdate", nil)
			sliderButtonsParentFrame.isGoingToHide = false
		end
	end)

	buttonPlus:SetScript("OnLeave", function(self)
		sliderButtonsParentFrame:PrepareToHide()
	end)
	buttonMinor:SetScript("OnLeave", function(self)
		sliderButtonsParentFrame:PrepareToHide()
	end)

	buttonPlus:SetNormalTexture([[Interface\Buttons\UI-PlusButton-Up]])
	buttonMinor:SetNormalTexture([[Interface\Buttons\UI-MinusButton-Up]])

	buttonPlus:SetPushedTexture([[Interface\Buttons\UI-PlusButton-Down]])
	buttonMinor:SetPushedTexture([[Interface\Buttons\UI-MinusButton-Down]])

	buttonPlus:SetDisabledTexture([[Interface\Buttons\UI-PlusButton-Disabled]])
	buttonMinor:SetDisabledTexture([[Interface\Buttons\UI-MinusButton-Disabled]])

	buttonPlus:SetHighlightTexture([[Interface\Buttons\UI-PlusButton-Hilight]])
	buttonMinor:SetHighlightTexture([[Interface\Buttons\UI-PlusButton-Hilight]])

	C_Timer.After(0, function()
		DF:SetButtonTexture(buttonPlus, "AlliedRace-UnlockingFrame-ZoomIn")
		DF:SetButtonTexture(buttonMinor, "AlliedRace-UnlockingFrame-ZoomOut")
	end)

	buttonMinor:ClearAllPoints()
	buttonPlus:ClearAllPoints()
	buttonMinor:SetPoint("bottomright", sliderButtonsParentFrame, "bottomright", 13, -13)
	buttonPlus:SetPoint("left", buttonMinor, "right", -2, 0)

	buttonPlus:SetSize(16, 16)
	buttonMinor:SetSize(16, 16)

	buttonPlus:SetAlpha(0.834)
	buttonMinor:SetAlpha(0.834)

	--increate the value on pressing the button or holding the button pressed
	local buttonPlusOnClick = function()
		local sliderObject = sliderButtonsParentFrame.host
		local currentValueOnSlider = sliderObject.value
		local editboxShowingValue = DFSliderMetaFunctions.editbox_typevalue

		if (sliderObject.fine_tuning) then
			sliderObject:SetValue(currentValueOnSlider + sliderObject.fine_tuning)
			if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
				DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(string.format("%.2f", currentValueOnSlider + sliderObject.fine_tuning)))
			end
		else
			if (sliderObject.useDecimals) then
				sliderObject:SetValue(currentValueOnSlider + 0.1)
				if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
					DFSliderMetaFunctions.editbox_typevalue:SetText(string.format("%.2f", currentValueOnSlider + 0.1))
				end
			else
				sliderObject:SetValue(currentValueOnSlider + 1)
				if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
					DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(math.floor(currentValueOnSlider + 1)))
				end
			end
		end
	end

	buttonPlus:SetScript("OnMouseUp", function(self)
		if (not buttonPlus.got_click) then
			buttonPlusOnClick()
		end
		buttonPlus.got_click = false
		self:SetScript("OnUpdate", nil)
	end)

	--hold the plus or minus button for x amount of time before start changing the value
	local delayBeforeStartSimulatingClicks = 0
	--after the delay been passed, trigger a click each x seconds
	local simulateClickTimer = 0

	local buttonPlusOnUpdate = function(self, deltaTime)
		delayBeforeStartSimulatingClicks = delayBeforeStartSimulatingClicks + deltaTime
		if (delayBeforeStartSimulatingClicks > 0.4) then
			simulateClickTimer = simulateClickTimer + deltaTime
			if (simulateClickTimer > 0.1) then
				simulateClickTimer = 0
				buttonPlusOnClick()
				buttonPlus.got_click = true
			end
		end
	end

	buttonPlus:SetScript("OnMouseDown", function(self)
		delayBeforeStartSimulatingClicks = 0
		simulateClickTimer = 0
		self:SetScript("OnUpdate", buttonPlusOnUpdate)
	end)

	-- -- --

	--increate the value on pressing the button or holding the button pressed
	local buttonMinusOnClick = function()
		local sliderObject = sliderButtonsParentFrame.host
		local currentValueOnSlider = sliderObject.value
		local editboxShowingValue = DFSliderMetaFunctions.editbox_typevalue

		if (sliderObject.fine_tuning) then
			sliderObject:SetValue(currentValueOnSlider - sliderObject.fine_tuning)
			if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
				DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(string.format("%.2f", currentValueOnSlider - sliderObject.fine_tuning)))
			end
		else
			if (sliderObject.useDecimals) then
				sliderObject:SetValue(currentValueOnSlider - 0.1)
				if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
					DFSliderMetaFunctions.editbox_typevalue:SetText(string.format("%.2f", currentValueOnSlider - 0.1))
				end
			else
				sliderObject:SetValue(currentValueOnSlider - 1)
				if (editboxShowingValue and DFSliderMetaFunctions.editbox_typevalue:IsShown()) then
					DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(math.floor(currentValueOnSlider - 1)))
				end
			end
		end
	end

	buttonMinor:SetScript("OnMouseUp", function(self)
		if (not buttonMinor.got_click) then
			buttonMinusOnClick()
		end
		buttonMinor.got_click = false
		self:SetScript("OnUpdate", nil)
	end)

	local buttonMinusOnUpdate = function(self, elapsed)
		delayBeforeStartSimulatingClicks = delayBeforeStartSimulatingClicks + elapsed
		if (delayBeforeStartSimulatingClicks > 0.4) then
			simulateClickTimer = simulateClickTimer + elapsed
			if (simulateClickTimer > 0.1) then
				simulateClickTimer = 0
				buttonMinusOnClick()
				buttonMinor.got_click = true
			end
		end
	end
	buttonMinor:SetScript("OnMouseDown", function(self)
		delayBeforeStartSimulatingClicks = 0
		simulateClickTimer = 0
		self:SetScript("OnUpdate", buttonMinusOnUpdate)
	end)

	local do_precision = function(text)
		if (type(text) == "string" and text:find("%.")) then
			local left, right = strsplit(".", text)
			left = tonumber(left)
			right = tonumber(right)

			if (left and right) then
				local newString = tostring(left) .. "." .. tostring(right)
				local newNumber = tonumber(newString)

				if (newNumber) then
					return newNumber
				end
			end
		end

		return tonumber(text)
	end
	DF.TextToFloor = do_precision

	function DFSliderMetaFunctions:TypeValue()
		if (not self.isSwitch) then
			if (not DFSliderMetaFunctions.editbox_typevalue) then
				local editbox = CreateFrame("EditBox", "DetailsFrameworkSliderEditBox", UIParent, "BackdropTemplate")
				editbox:SetSize(40, 20)
				editbox:SetJustifyH("center")
				DF:ApplyStandardBackdrop(editbox)
				editbox:SetFontObject("GameFontHighlightSmall")

				editbox:SetScript("OnEnterPressed", function()
					editbox:ClearFocus()
					editbox:Hide()
					editbox:GetParent().MyObject.typing_value = false
					editbox:GetParent().MyObject.value = tonumber(editbox:GetText()) --do_precision (editbox:GetText())
				end)

				editbox:SetScript("OnEscapePressed", function()
					editbox:ClearFocus()
					editbox:Hide()
					editbox:GetParent().MyObject.typing_value = false
					editbox:GetParent().MyObject.value = self.typing_value_started --do_precision (self.typing_value_started)
				end)

				editbox:SetScript("OnTextChanged", function()
					editbox:GetParent().MyObject.typing_can_change = true
					editbox:GetParent().MyObject.value = tonumber(editbox:GetText()) --do_precision
					editbox:GetParent().MyObject.typing_can_change = false
				end)

				DFSliderMetaFunctions.editbox_typevalue = editbox
			end

			local pvalue = self.previous_value[2]
			self:SetValue(pvalue)

			self.typing_value = true
			self.typing_value_started = pvalue

			DFSliderMetaFunctions.editbox_typevalue:SetSize(self.width, self.height)
			DFSliderMetaFunctions.editbox_typevalue:SetPoint("center", self.widget, "center")
			DFSliderMetaFunctions.editbox_typevalue:SetFocus()
			DFSliderMetaFunctions.editbox_typevalue:SetParent(self.widget)
			DFSliderMetaFunctions.editbox_typevalue:SetFrameLevel(self.widget:GetFrameLevel()+1)

			if (self.useDecimals) then
				DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(string.format("%.1f", self.value)))
			else
				DFSliderMetaFunctions.editbox_typevalue:SetText(tostring(math.floor(self.value)))
			end

			DFSliderMetaFunctions.editbox_typevalue:HighlightText()

			DFSliderMetaFunctions.editbox_typevalue:Show()
		end
	end

	--paints a track slider's fill and thumb with the template's while-dragging colors, or back with its resting
	--colors. a template without the while-dragging colors keeps the resting ones throughout
	---@param object df_slider
	---@param bIsDragging boolean
	local setTrackDragColors = function(object, bIsDragging)
		if (not object.is_track or not object.track_fill) then
			return
		end

		local fillColor = object.track_fill_color
		local thumbColor = object.thumb_color

		if (bIsDragging) then
			fillColor = object.track_fill_color_active or fillColor
			thumbColor = object.thumb_color_active or thumbColor
		end

		object.track_left_cap:SetVertexColor(unpack(fillColor))
		object.track_fill:SetVertexColor(unpack(fillColor))

		if (thumbColor) then
			object.thumb:SetVertexColor(unpack(thumbColor))
		end
	end

	local OnMouseDown = function(slider, button)
		local object = slider.MyObject
		object.IsValueChanging = true

		if (not rawget(object, "lockdown")) then
			setTrackDragColors(object, true)
		end

		local kill = object:RunHooksForWidget("OnMouseDown", slider, button, object)
		if (kill) then
			return
		end

		if (button == "RightButton") then
			object:TypeValue()
		end
	end

	local OnMouseUp = function(slider, button)
		local object = slider.MyObject
		object.IsValueChanging = nil

		setTrackDragColors(object, false)

		--drag ended outside the slider, the value text was kept visible during the drag
		if (object.is_track and not slider:IsMouseOver()) then
			slider.amt:Hide()
		end

		local kill = object:RunHooksForWidget("OnMouseUp", slider, button, object)
		if (kill) then
			return
		end
	end

	local OnHide = function(slider)
		local object = slider.MyObject
		local kill = object:RunHooksForWidget("OnHide", slider, object)
		if (kill) then
			return
		end

		if (object.typing_value) then
			DFSliderMetaFunctions.editbox_typevalue:ClearFocus()
			DFSliderMetaFunctions.editbox_typevalue:SetText("")
			object.typing_valu = false
		end
	end

	local OnShow = function(slider)
		local object = slider.MyObject
		local kill = object:RunHooksForWidget("OnShow", slider, object)
		if (kill) then
			return
		end
	end

	--the value box: an optional text entry beside the slider showing its value, where the value can also be typed.
	--built the first time a template asks for it and hidden until then, so a slider that never uses it costs nothing

	--writes the slider's current value into its value box, unless the user is typing into it
	---@param object df_slider
	local refreshValueBoxText = function(object)
		local valueBox = object.value_box
		if (not valueBox or valueBox:HasFocus()) then
			return
		end

		local value = object.slider:GetValue()
		if (object.useDecimals) then
			valueBox:SetText(string.format("%.2f", value))
		else
			valueBox:SetText(tostring(math.floor(value + 0.5)))
		end
	end

	--applies the number typed into the value box, clamped to the slider's range; anything that is not a number is
	--discarded and the box shows the slider's value again
	---@param valueBox editbox
	local onValueBoxEnterPressed = function(valueBox)
		local object = valueBox.MyObject
		local typedValue = do_precision(valueBox:GetText())

		valueBox:ClearFocus()

		if (typedValue and not rawget(object, "lockdown")) then
			local minValue, maxValue = object.slider:GetMinMaxValues()
			typedValue = math.max(minValue, math.min(maxValue, typedValue))

			if (not object.useDecimals) then
				typedValue = math.floor(typedValue + 0.5)
			end

			object.slider:SetValue(typedValue)
		end

		refreshValueBoxText(object)
	end

	--leaving the box without pressing enter, by escape or by clicking elsewhere, discards what was typed
	---@param valueBox editbox
	local onValueBoxFocusLost = function(valueBox)
		valueBox:HighlightText(0, 0)
		refreshValueBoxText(valueBox.MyObject)
	end

	---@param valueBox editbox
	local onValueBoxEscapePressed = function(valueBox)
		valueBox:ClearFocus()
	end

	---@param valueBox editbox
	local onValueBoxFocusGained = function(valueBox)
		valueBox:HighlightText()
	end

	---@param object df_slider
	---@return editbox
	local createValueBox = function(object)
		local valueBox = CreateFrame("EditBox", nil, object.slider, "BackdropTemplate")
		valueBox:SetAutoFocus(false)
		valueBox:SetJustifyH("center")
		valueBox:SetFontObject("GameFontHighlightSmall")
		valueBox:SetTextInsets(2, 2, 0, 0)
		valueBox:SetFrameLevel(object.slider:GetFrameLevel() + 2)
		valueBox:SetBackdrop({bgFile = [[Interface\Buttons\WHITE8X8]], edgeFile = [[Interface\Buttons\WHITE8X8]], edgeSize = 1})
		valueBox.MyObject = object

		valueBox:SetScript("OnEnterPressed", onValueBoxEnterPressed)
		valueBox:SetScript("OnEscapePressed", onValueBoxEscapePressed)
		valueBox:SetScript("OnEditFocusLost", onValueBoxFocusLost)
		valueBox:SetScript("OnEditFocusGained", onValueBoxFocusGained)

		valueBox:Hide()
		object.value_box = valueBox
		return valueBox
	end

	--where the value box sits against the slider, and how far from it
	local valueBoxAnchors = {
		right = {"left", "right", 1, 0},
		left = {"right", "left", -1, 0},
		top = {"bottom", "top", 0, 1},
		bottom = {"top", "bottom", 0, -1},
	}

	---show or hide the value box. side is "left", "right" (default), "top" or "bottom"
	---@param bIsShown boolean
	---@param side string?
	---@param width number? default 38
	---@param height number? default 22
	---@param gap number? space between the box and the slider, default 4
	function DFSliderMetaFunctions:SetValueBox(bIsShown, side, width, height, gap)
		if (not bIsShown) then
			self.value_box_shown = false
			if (self.value_box) then
				self.value_box:ClearFocus()
				self.value_box:Hide()
			end
			return
		end

		local valueBox = self.value_box or createValueBox(self)
		side = valueBoxAnchors[side] and side or "right"
		gap = gap or 4

		self.value_box_shown = true
		self.value_box_side = side
		self.value_box_gap = gap

		local anchor = valueBoxAnchors[side]
		valueBox:SetSize(width or 38, height or 22)
		valueBox:ClearAllPoints()
		valueBox:SetPoint(anchor[1], self.slider, anchor[2], anchor[3] * gap, anchor[4] * gap)
		valueBox:EnableMouse(not rawget(self, "lockdown"))
		valueBox:Show()

		--the box shows the value, so the value text drawn on the slider would only repeat it
		self.amt:Hide()

		refreshValueBoxText(self)
	end

	---how much width the value box takes beside the slider: its width plus the gap when it sits on the left or the
	---right, zero when it is hidden or sits above or below. a layout giving the slider a fixed width subtracts it
	---@return number space
	---@return string? side
	function DFSliderMetaFunctions:GetValueBoxSpace()
		if (not self.value_box_shown) then
			return 0
		end

		local side = self.value_box_side
		if (side == "left" or side == "right") then
			return self.value_box:GetWidth() + self.value_box_gap, side
		end

		return 0, side
	end

	local OnValueChanged = function(slider)
		local object = slider.MyObject

		local amt
		if (object.useDecimals) then
			amt = slider:GetValue()
		else
			amt = do_precision(slider:GetValue())
		end

		if (object.typing_value and not object.typing_can_change) then
			object:SetValue(object.typing_value_started)
			return
		end

		table.insert(object.previous_value, 1, amt)
		table.remove(object.previous_value, 4)

		if (object.useDecimals) then
			slider.amt:SetText(string.format("%.2f", amt))
		else
			slider.amt:SetText(math.floor(amt))
		end
		refreshValueBoxText(object)
		object.ivalue = amt

		if (object.NoCallback) then
			object.NoCallback = false
			return
		end

		--some plugins registered OnValueChanged and others with OnValueChange
		local kill = object:RunHooksForWidget("OnValueChanged", slider, object.FixedValue, amt, object)
		if (kill) then
			return
		end

		local kill = object:RunHooksForWidget("OnValueChange", slider, object.FixedValue, amt, object)
		if (kill) then
			return
		end

		if (object.OnValueChanged) then
			object.OnValueChanged(slider, object.FixedValue, amt)
		end
	end

------------------------------------------------------------------------------------------------------------
--object constructor

--toggle mode: the knob slides to the left when off and to the right when on, its color follows the state
local refreshToggleKnob = function(object)
	local knob = object.toggle_knob
	local padding = object.toggle_knob_padding or 2
	local knobSize = math.max(object.widget:GetHeight() - (padding * 2), 1)

	knob:ClearAllPoints()
	PixelUtil.SetSize(knob, knobSize, knobSize)

	if (rawget(object, "value")) then
		PixelUtil.SetPoint(knob, "right", object.widget, "right", -padding, 0)
		knob:SetVertexColor(unpack(object.toggle_knob_color_on))
	else
		PixelUtil.SetPoint(knob, "left", object.widget, "left", padding, 0)
		knob:SetVertexColor(unpack(object.toggle_knob_color_off))
	end

	knob:Show()
end

local SwitchOnClick = function(self, button, forced_value, value)
	local object = self.MyObject

	if (rawget(object, "lockdown")) then
		return
	end

	if (forced_value) then
		rawset(object, "value", not value)
	end

	if (rawget(object, "value")) then --actived
		rawset(object, "value", false)

		if (object.backdrop_disabledcolor) then
			object:SetBackdropColor(unpack(object.backdrop_disabledcolor))
		else
			object:SetBackdropColor(1, 0, 0, 0.4)
		end

		if (object.is_toggle) then
			refreshToggleKnob(object)
		elseif (object.is_checkbox) then
			object.checked_texture:Hide()
		else
			object._text:SetText(object._ltext)
			object._thumb:ClearAllPoints()
			object._thumb:SetPoint("left", object.widget, "left")
		end
	else
		rawset(object, "value", true)
		if (object.backdrop_enabledcolor) then
			object:SetBackdropColor(unpack(object.backdrop_enabledcolor))
		else
			object:SetBackdropColor(0, 0, 1, 0.4)
		end
		if (object.is_toggle) then
			refreshToggleKnob(object)
		elseif (object.is_checkbox) then
			object.checked_texture:Show()
		else
			object._text:SetText(object._rtext)
			object._thumb:ClearAllPoints()
			object._thumb:SetPoint("right", object.widget, "right")
		end
	end

	if (object.OnSwitch and not forced_value) then
		local value = rawget(object, "value")
		if (object.return_func) then
			value = object:return_func (value)
		end

		local success, errorText = xpcall(object.OnSwitch, geterrorhandler(), object, object.FixedValue, value)
		if (not success) then
			return
		end

		--trigger hooks
		object:RunHooksForWidget("OnSwitch", object, object.FixedValue, value)
	end

end

local switch_get_value = function(self)
	return self.value
end

local switch_set_value = function(self, value, forcedState)
	if (self.switch_func) then
		value = self:switch_func(value)
	end

	local bForceValue = true
	if (forcedState == "RUN_CALLBACK") then
		bForceValue = false
	end

	SwitchOnClick (self.widget, nil, bForceValue, value)
end

local switch_set_fixparameter = function(self, value)
	rawset(self, "FixedValue", value)
end

local switch_get_fixparameter = function(self)
	return rawget(self, "FixedValue")
end

local switch_disable = function(self)
	if (self.is_checkbox) then
		self.checked_texture:Hide()
	else
		self._text:Hide()
		if (not self.lock_texture) then
			DF:NewImage(self, [[Interface\PetBattles\PetBattle-LockIcon]], 12, 12, "overlay", {0.0546875, 0.9453125, 0.0703125, 0.9453125}, "lock_texture", "$parentLockTexture")
			self.lock_texture:SetDesaturated(true)
			self.lock_texture:SetPoint("center", self._thumb, "center")
		end
		self.lock_texture:Show()
	end

	self:SetAlpha(.4)
	DF:SetOptionLabelEnabled(self, false)
	rawset(self, "lockdown", true)
end

local switch_enable = function(self)
	if (self.is_toggle) then
		refreshToggleKnob(self)
	elseif (self.is_checkbox) then
		if (rawget(self, "value")) then
			self.checked_texture:Show()
		else
			self.checked_texture:Hide()
		end
	else
		if (not self.lock_texture) then
			DF:NewImage(self, [[Interface\PetBattles\PetBattle-LockIcon]], 12, 12, "overlay", {0.0546875, 0.9453125, 0.0703125, 0.9453125}, "lock_texture", "$parentLockTexture")
			self.lock_texture:SetDesaturated(true)
			self.lock_texture:SetPoint("center", self._thumb, "center")
		end
		self.lock_texture:Hide()
		self._text:Show()
	end

	self:SetAlpha(1)
	DF:SetOptionLabelEnabled(self, true)
	return rawset(self, "lockdown", false)
end

local set_switch_func = function(self, newFunction)
	self.OnSwitch = newFunction
end

local get_switch_func = function(self)
	return self.OnSwitch
end

local setCheckedTexture = function(self, texture, xOffSet, yOffSet, sizePercent, color)
	if (texture) then
		self.checked_texture:SetTexture(texture, "CLAMP", "CLAMP", "TRILINEAR")
	end

	if (xOffSet or yOffSet) then
		self.checked_texture:SetPoint("center", self.button, "center", xOffSet or -1, yOffSet or -1)
	else
		self.checked_texture:SetPoint("center", self.button, "center", -1, -1)
	end

	if (sizePercent and type(sizePercent) == "number") then
		local width = self:GetWidth() * sizePercent
		self.checked_texture:SetSize(width, width)
	end

	if (color) then
		local r, g, b, a = DF:ParseColors(color)
		self.checked_texture:SetVertexColor(r, g, b, a)
	end
end

local set_as_checkbok = function(self)
	--only the CREATION is once. the sizing and the painting below run on every call, because these
	--widgets are pooled and re-templated: a checkbox first converted at some other width, or before
	--its template had been applied, used to keep that first geometry and that first colour for the
	--rest of the session -- the early return here covered all three
	if (not self.is_checkbox or not self.checked_texture) then
		local checked = self:CreateTexture(self:GetName() .. "CheckTexture", "overlay")
		checked:SetTexture([[Interface\Buttons\UI-CheckBox-Check]])
		checked:SetPoint("center", self.button, "center", -1, -1)
		self.checked_texture = checked

		self.SetCheckedTexture = setCheckedTexture
		self.SetChecked = switch_set_value
		self.GetChecked = switch_get_value

		self._thumb:Hide()
		self._text:Hide()
		self.is_checkbox = true
	end

	local size_pct = self:GetWidth()/32
	self.checked_texture:SetSize(32 * size_pct, 32 * size_pct)

	if (rawget(self, "value")) then
		self.checked_texture:Show()
		if (self.backdrop_enabledcolor) then
			self:SetBackdropColor(unpack(self.backdrop_enabledcolor))
		else
			self:SetBackdropColor(0, 0, 1, 0.4)
		end
	else
		self.checked_texture:Hide()
		if (self.backdrop_disabledcolor) then
			self:SetBackdropColor(unpack(self.backdrop_disabledcolor))
		else
			self:SetBackdropColor(0, 0, 1, 0.4)
		end
	end

	if (self.is_toggle) then
		self.checked_texture:Hide()
		refreshToggleKnob(self)
	end
end

--turn the checkbox into a toggle: the check mark is replaced by a knob that slides between the two sides
--colors are {r, g, b, a} tables already parsed, padding is the space between the knob and the track edge
local set_as_toggle = function(self, knobColorOff, knobColorOn, knobPadding)
	if (not self.is_checkbox or not self.checked_texture) then
		self:SetAsCheckBox()
	end

	if (not self.toggle_knob) then
		local knob = self:CreateTexture(nil, "overlay")
		knob:SetTexture([[Interface\Buttons\WHITE8X8]])
		self.toggle_knob = knob
	end

	self.toggle_knob_color_off = knobColorOff or self.toggle_knob_color_off or {.7, .7, .7, 1}
	self.toggle_knob_color_on = knobColorOn or self.toggle_knob_color_on or {1, .82, 0, 1}
	self.toggle_knob_padding = knobPadding or self.toggle_knob_padding or 2
	self.is_toggle = true

	self.checked_texture:Hide()
	refreshToggleKnob(self)
end

--back to a plain checkbox, used when a pooled toggle receives a template without is_toggle
local unset_as_toggle = function(self)
	if (not self.is_toggle) then
		return
	end

	self.is_toggle = false
	self.toggle_knob:Hide()

	if (self.checked_texture) then
		if (rawget(self, "value")) then
			self.checked_texture:Show()
		else
			self.checked_texture:Hide()
		end
	end
end

local createExtraSpaceToClick = function(self, label, widgetWidth, highlight)
    --self = self.widget or self
    label = label.widget or label
	widgetWidth = widgetWidth or 140

    local extraSpaceFrame = CreateFrame("button", nil, self.widget)
    extraSpaceFrame:EnableMouse(true)
    extraSpaceFrame:SetFrameLevel(self:GetFrameLevel()-1)

    PixelUtil.SetSize(extraSpaceFrame, widgetWidth, self:GetHeight() + 1)
    PixelUtil.SetPoint(extraSpaceFrame, "topleft", self.widget, "topleft", 0, 0)

	local highlightTexture

	if (highlight) then
		highlightTexture = extraSpaceFrame:CreateTexture(nil, "highlight")
		if (type(highlight) ~= "boolean") then
			highlightTexture:SetTexture(highlight)
		else
			highlightTexture:SetColorTexture(1, 1, 1, 0.1)
		end
		PixelUtil.SetPoint(highlightTexture, "topleft", extraSpaceFrame, "topleft", 0, 0)
		PixelUtil.SetPoint(highlightTexture, "bottomright", extraSpaceFrame, "bottomright", 0, 0)
	end

	extraSpaceFrame:SetScript("OnClick", function()
		local bNewState = not self:GetValue()
		self.OnSwitch(self, nil, bNewState)

		if (bNewState) then
			self:SetValue(true, "RUN_CALLBACK")
		else
			self:SetValue(false, "RUN_CALLBACK")
		end

		if (self._valueChangeHook) then
			self._valueChangeHook()
		end
	end)

	extraSpaceFrame.parent = self
    return extraSpaceFrame, highlightTexture
end

---@class df_checkbox : df_button, df_widgets
---@field OnSwitch fun(self:df_checkbox, fixedValue:any, value:boolean)
---@field SetValue fun(self:df_button, value:boolean, state:string?)
---@field GetValue fun(self:df_button):boolean
---@field SetFixedParameter fun(self:df_button, value:any)
---@field GetFixedParameter fun(self:df_button):any
---@field Disable fun(self:df_button)
---@field Enable fun(self:df_button)
---@field SetAsCheckBox fun(self:df_button)
---@field SetAsToggle fun(self:df_button, knobColorOff:table?, knobColorOn:table?, knobPadding:number?)
---@field SetTemplate fun(self:df_button, template: table|string)
---@field GetSwitchFunction fun(self:df_button):function
---@field SetSwitchFunction fun(self:df_button, newOnSwitchFunction: function)
---@field GetCapsule fun(self:df_button):df_button capsule only exists in the actual frame of the encapsulated widget
---@field SetCheckedTexture fun(self:df_button, texture:string)
---@field SetChecked fun(self:df_button, value:boolean)
---@field GetChecked fun(self:df_button):boolean
---@field CreateExtraSpaceToClick fun(self:df_button, label:df_label, widgetWidth:number?, highlight:any?):button


---create a switch / checkbox object.
---This function returns a wrapper Lua table (df_checkbox, built on top of df_button via NewButton),
---NOT a Blizzard frame. The underlying UIObject (the Blizzard button frame) is at `wrapper.widget`
---and via `wrapper:GetUIObject()` (inherited from df_button). Method calls on the wrapper itself
---are fine (the metatable forwards them), but when the wrapper is passed AS AN ARGUMENT to a
---Blizzard API that expects a frame — SetPoint relative anchor, CreateFrame parent, etc. — it MUST
---be unwrapped via `wrapper:GetUIObject()` first, otherwise the C side will error or misbehave.
---The optional second return value (df_label) is the label widget; it is also a wrapper (see label.lua).
function DF:CreateSwitch(parent, onSwitch, defaultValue, width, height, leftText, rightText, member, name, colorInverted, switchFunc, returnFunc, withLabel, switch_template, label_template)
	--returns a wrapper table (not a frame); unwrap via wrapper:GetUIObject() / wrapper.widget when handing to Blizzard APIs
	local switch, label = DF:NewSwitch(parent, parent, name, member, width or 60, height or 20, leftText, rightText, defaultValue, colorInverted, switchFunc, returnFunc, withLabel, switch_template, label_template)
	if (onSwitch) then
		switch.OnSwitch = onSwitch
	end

	---@cast switch df_checkbox
	---@cast label df_label
	return switch, label
end

function DF:NewSwitch(parent, container, name, member, width, height, leftText, rightText, defaultValue, colorInverted, switch_func, return_func, with_label, switch_template, label_template)
--early checks
	if (not name) then
		name = "DetailsFrameWorkSlider" .. DF.SwitchCounter
		DF.SwitchCounter = DF.SwitchCounter + 1

	elseif (not parent) then
		return error("Details! FrameWork: parent not found.", 2)
	end

	if (not container) then
		container = parent
	end

--defaults
	leftText = leftText or "OFF"
	rightText = rightText or "ON"

--build frames
	width = width or 60
	height = height or 20

	local slider = DF:NewButton(parent, container, name, member, width, height)
	slider.HookList.OnSwitch = {}
	slider.type = "switch"

	slider.switch_func = switch_func
	slider.return_func = return_func
	slider.SetValue = switch_set_value
	slider.GetValue = switch_get_value
	slider.SetFixedParameter = switch_set_fixparameter
	slider.GetFixedParameter = switch_get_fixparameter
	slider.Disable = switch_disable
	slider.Enable = switch_enable
	slider.SetAsCheckBox = set_as_checkbok
	slider.SetAsToggle = set_as_toggle
	slider.SetTemplate = DFSliderMetaFunctions.SetTemplate
	slider.SetSwitchFunction = set_switch_func
	slider.GetSwitchFunction = get_switch_func
	slider.CreateExtraSpaceToClick = createExtraSpaceToClick

	if (member) then
		parent[member] = slider
	end

	slider:SetBackdrop({edgeFile = [[Interface\Buttons\UI-SliderBar-Border]], edgeSize = 8,
	bgFile = [[Interface\AddOns\Details\images\background]], insets = {left = 3, right = 3, top = 5, bottom = 5}})

	local thumb = slider:CreateTexture(nil, "artwork")
	thumb:SetTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
	thumb:SetSize(34+(height*0.2), height*1.2)
	thumb:SetAlpha(0.7)
	thumb:SetPoint("left", slider.widget, "left")

	local text = slider:CreateFontString(nil, "overlay", "GameFontHighlightSmall")
	text:SetTextColor(.8, .8, .8, 1)
	text:SetPoint("center", thumb, "center")

	slider._text = text
	slider._thumb = thumb
	slider._ltext = leftText
	slider._rtext = rightText
	slider.thumb = thumb

	slider.invert_colors = colorInverted

	--print(slider:GetObjectType()) --slider
	----print(slider.widget:GetObjectType()) --button
	slider.widget:SetScript("OnClick", SwitchOnClick)
	--slider:SetScript("OnClick", SwitchOnClick)

	slider:SetValue(defaultValue)

	slider.isSwitch = true

	if (with_label) then
		local label = DF:CreateLabel(slider.widget, with_label, nil, nil, nil, "label", nil, "overlay")
		label.text = with_label
		PixelUtil.SetPoint(slider.widget, "left", label.widget, "right", 2, 0)
		with_label = label

		if (label_template) then
			label:SetTemplate(label_template)
		end
	end

	--the legacy switch visual (thumb + ON/OFF text) is no longer used; every switch is rendered as a checkbox
	slider:SetAsCheckBox()
	slider:SetTemplate("OPTIONS_CHECKBOX_TEMPLATE")

	--the template passed in goes after the default one, otherwise the default would overwrite it
	if (switch_template) then
		slider:SetTemplate(switch_template)
	end

	return slider, with_label
end

--track look: the backdrop is replaced by a thin bar with round ends, the part left of the thumb uses the fill color
--colors are {r, g, b, a} tables already parsed, the value text moves above the thumb and only shows while hovering
function DFSliderMetaFunctions:SetAsTrack(trackColor, fillColor, trackHeight)
	local slider = self.widget

	self.track_color = trackColor or self.track_color or {.29, .29, .31, 1}
	self.track_fill_color = fillColor or self.track_fill_color or {.39, .73, .96, 1}
	self.track_height = trackHeight or self.track_height or 4
	self.is_track = true

	if (not self.track_fill) then
		--the round ends are the halves of a circle texture, trilinear keeps the small circle edge smooth
		local leftCap = slider:CreateTexture(nil, "border")
		leftCap:SetTexture([[Interface\CHARACTERFRAME\TempPortraitAlphaMaskSmall]], "CLAMP", "CLAMP", "TRILINEAR")
		leftCap:SetTexCoord(0, 0.5, 0, 1)

		local rightCap = slider:CreateTexture(nil, "border")
		rightCap:SetTexture([[Interface\CHARACTERFRAME\TempPortraitAlphaMaskSmall]], "CLAMP", "CLAMP", "TRILINEAR")
		rightCap:SetTexCoord(0.5, 1, 0, 1)

		--both bars are anchored to the thumb center, so they follow the thumb without updating on value change
		local fill = slider:CreateTexture(nil, "border")
		fill:SetTexture([[Interface\Buttons\WHITE8X8]], "CLAMP", "CLAMP", "TRILINEAR")

		local empty = slider:CreateTexture(nil, "border")
		empty:SetTexture([[Interface\Buttons\WHITE8X8]], "CLAMP", "CLAMP", "TRILINEAR")

		self.track_left_cap = leftCap
		self.track_right_cap = rightCap
		self.track_fill = fill
		self.track_empty = empty
	end

	local height = self.track_height
	local leftCap, rightCap, fill, empty = self.track_left_cap, self.track_right_cap, self.track_fill, self.track_empty

	leftCap:ClearAllPoints()
	leftCap:SetSize(height / 2, height)
	leftCap:SetPoint("left", slider, "left", 0, 0)
	leftCap:SetVertexColor(unpack(self.track_fill_color))

	rightCap:ClearAllPoints()
	rightCap:SetSize(height / 2, height)
	rightCap:SetPoint("right", slider, "right", 0, 0)
	rightCap:SetVertexColor(unpack(self.track_color))

	fill:ClearAllPoints()
	fill:SetHeight(height)
	fill:SetPoint("left", leftCap, "right", 0, 0)
	fill:SetPoint("right", self.thumb, "center", 0, 0)
	fill:SetVertexColor(unpack(self.track_fill_color))

	empty:ClearAllPoints()
	empty:SetHeight(height)
	empty:SetPoint("left", self.thumb, "center", 0, 0)
	empty:SetPoint("right", rightCap, "left", 0, 0)
	empty:SetVertexColor(unpack(self.track_color))

	leftCap:Show()
	rightCap:Show()
	fill:Show()
	empty:Show()

	self:SetBackdrop(nil)
	self.slider_left:Hide()
	self.slider_right:Hide()
	self.slider_middle:Hide()

	self.thumb:SetAlpha(1)

	--the template sets the thumb file without a filter, set it again with trilinear so the round edge stays smooth
	local thumbFile = self.thumb:GetTexture()
	if (thumbFile and not self.thumb:GetAtlas()) then
		self.thumb:SetTexture(thumbFile, "CLAMP", "CLAMP", "TRILINEAR")
	end

	self.amt:ClearAllPoints()
	self.amt:SetPoint("bottom", self.thumb, "top", 0, 2)
	if (not slider:IsMouseOver()) then
		self.amt:Hide()
	end
end

--back to the regular look, used when a pooled track slider receives a template without is_track
local unset_as_track = function(self)
	if (not self.is_track) then
		return
	end

	self.is_track = false

	self.track_left_cap:Hide()
	self.track_right_cap:Hide()
	self.track_fill:Hide()
	self.track_empty:Hide()

	self.slider_left:Show()
	self.slider_right:Show()
	self.slider_middle:Show()

	self.thumb:SetAlpha(.7)

	self.amt:ClearAllPoints()
	self.amt:SetPoint("center", self.thumb, "center")
	if (not rawget(self, "lockdown") and not self.value_box_shown) then
		self.amt:Show()
	end
end

function DFSliderMetaFunctions:SetTemplate(template)
	template = DF:ParseTemplate(self.type, template)

	--slider e switch
	if (template.width) then
		PixelUtil.SetWidth(self.widget, template.width)
	end
	if (template.height) then
		PixelUtil.SetHeight(self.widget, template.height)
	end

	if (template.backdrop) then
		self:SetBackdrop(template.backdrop)
	end
	if (template.backdropcolor) then
		local r, g, b, a = DF:ParseColors(template.backdropcolor)
		self:SetBackdropColor(r, g, b, a)
	end
	if (template.backdropbordercolor) then
		local r, g, b, a = DF:ParseColors(template.backdropbordercolor)
		self:SetBackdropBorderColor(r, g, b, a)
		self.onleave_backdrop_border_color = {r, g, b, a}
	end

	if (template.onenterbordercolor) then
		local r, g, b, a = DF:ParseColors(template.onenterbordercolor)
		self.onenter_backdrop_border_color = {r, g, b, a}
	end

	if (template.onleavebordercolor) then
		local r, g, b, a = DF:ParseColors(template.onleavebordercolor)
		self.onleave_backdrop_border_color = {r, g, b, a}
	end

	if (template.thumbtexture) then
		if (self.thumb) then
			DF:SetAtlas(self.thumb, template.thumbtexture)
		end
	end

	if (template.slider_left) then
		if (self.slider_left) then
			DF:SetAtlas(self.slider_left, template.slider_left)
		end
	end

	if (template.slider_right) then
		if (self.slider_right) then
			DF:SetAtlas(self.slider_right, template.slider_right)
		end
	end

	if (template.slider_middle) then
		if (self.slider_middle) then
			self:SetBackdrop(nil)
			DF:SetAtlas(self.slider_middle, template.slider_middle)
		end
	end

	if (template.thumbwidth) then
		if (self.thumb) then
			self.thumb:SetWidth(template.thumbwidth)
		end
	end
	if (template.thumbheight) then
		if (self.thumb) then
			self.thumb:SetHeight(template.thumbheight)
		end
	end
	if (template.thumbcolor) then
		if (self.thumb) then
			local r, g, b, a = DF:ParseColors(template.thumbcolor)
			self.thumb:SetVertexColor(r, g, b, a)
			--kept so a track slider can return to it after being dragged
			self.thumb_color = {r, g, b, a}
		end
	end

	if (template.amount_color) then
		DF:SetFontColor(self.amt, template.amount_color)
	end

	if (template.amount_outline) then
		DF:SetFontOutline(self.amt, template.amount_outline)
	end

	if (template.amount_size) then
		DF:SetFontSize(self.amt, template.amount_size)
	end

	--switch only
	if (template.enabled_backdropcolor) then
		local r, g, b, a = DF:ParseColors(template.enabled_backdropcolor)
		self.backdrop_enabledcolor = {r, g, b, a}
	end
	if (template.disabled_backdropcolor) then
		local r, g, b, a = DF:ParseColors(template.disabled_backdropcolor)
		self.backdrop_disabledcolor = {r, g, b, a}
	end

	if (template.is_checkbox) then
		self:SetAsCheckBox()
		self:SetCheckedTexture(template.checked_texture, template.checked_xoffset or 0, template.checked_yoffset or 0, template.checked_size_percent or 0.7, template.checked_color)
	end

	--toggle look belongs to the template, a template without is_toggle brings a pooled toggle back to a checkbox
	if (self.isSwitch or self.type == "switch") then
		if (template.is_toggle) then
			local knobColorOff, knobColorOn
			if (template.toggle_knob_color_off) then
				knobColorOff = {DF:ParseColors(template.toggle_knob_color_off)}
			end
			if (template.toggle_knob_color_on) then
				knobColorOn = {DF:ParseColors(template.toggle_knob_color_on)}
			end
			set_as_toggle(self, knobColorOff, knobColorOn, template.toggle_knob_padding)
		else
			unset_as_toggle(self)
		end

	--track look belongs to the template as well, a template without is_track brings a pooled track slider back
	else
		if (template.is_track) then
			local trackColor, fillColor
			if (template.track_color) then
				trackColor = {DF:ParseColors(template.track_color)}
			end
			if (template.track_fill_color) then
				fillColor = {DF:ParseColors(template.track_fill_color)}
			end

			--optional colors for the fill and the thumb while the thumb is being dragged. set or cleared every
			--time, so a pooled slider does not keep the ones of the template it had before
			if (template.track_fill_color_active) then
				self.track_fill_color_active = {DF:ParseColors(template.track_fill_color_active)}
			else
				self.track_fill_color_active = nil
			end
			if (template.thumbcolor_active) then
				self.thumb_color_active = {DF:ParseColors(template.thumbcolor_active)}
			else
				self.thumb_color_active = nil
			end

			self:SetAsTrack(trackColor, fillColor, template.track_height)
		else
			unset_as_track(self)
		end

		--the value box belongs to the template too, so a pooled slider given a template without it loses it.
		--after the track look, which decides on its own whether the value text above the thumb is shown
		if (template.value_box) then
			self:SetValueBox(true, template.value_box_side, template.value_box_width, template.value_box_height, template.value_box_gap)

			local valueBox = self.value_box
			valueBox:SetBackdropColor(DF:ParseColors(template.value_box_backdropcolor or {.1, .1, .1, 1}))
			valueBox:SetBackdropBorderColor(DF:ParseColors(template.value_box_bordercolor or {0, 0, 0, 1}))
			DF:SetFontColor(valueBox, template.value_box_text_color or "white")
			DF:SetFontSize(valueBox, template.value_box_text_size or 10)
		else
			self:SetValueBox(false)
		end
	end

	if (template.rounded_corner) then
		self:SetBackdrop(nil)
		DF:AddRoundedCornersToFrame(self.widget or self, template.rounded_corner)
	end
end

--DF:Mixin(DFSliderMetaFunctions, DF.SetPointMixin)
--DF:Mixin(DFSliderMetaFunctions, DF.FrameMixin)
--DF:Mixin(DFSliderMetaFunctions, DF.TooltipHandlerMixin)

---@class df_slider : slider, df_scripthookmixin, df_widgets
---@field tooltip string?
---@field widget slider
---@field slider slider
---@field type string
---@field dframework boolean
---@field GetUIObject fun(self:df_slider):slider returns the UIObject that is behind the wrapper table
---@field SetTemplate fun(self:df_slider, template: table|string)
---@field SetFixedParameter fun(value: any)
---@field GetFixedParameter fun()
---@field SetValueNoCallback fun(value: number)
---@field SetThumbSize fun(width:number, height:number)
---@field SetAsTrack fun(self:df_slider, trackColor:table?, fillColor:table?, trackHeight:number?)
---@field SetValueBox fun(self:df_slider, bIsShown:boolean, side:string?, width:number?, height:number?, gap:number?) show or hide the text entry beside the slider that shows and takes its value. side: "left", "right", "top" or "bottom"
---@field GetValueBoxSpace fun(self:df_slider):number, string? width the value box takes beside the slider (zero above, below or hidden), and its side
---@field value_box editbox? the value box, nil until a template or SetValueBox first asks for it
---@field ClearFocus fun()
---@field SetValueChangedFunction fun(self:df_slider, func: function)

---create a slider object.
---This function returns a wrapper Lua table (df_slider), NOT a Blizzard frame. The underlying
---UIObject (the Blizzard slider frame) is at `wrapper.widget` (or equivalently `wrapper.slider`)
---and via `wrapper:GetUIObject()`. Method calls on the wrapper itself are fine (the metatable
---forwards them), but when the wrapper is passed AS AN ARGUMENT to a Blizzard API that expects a
---frame — SetPoint relative anchor, CreateFrame parent, GameTooltip:SetOwner, secure-template ref,
---etc. — it MUST be unwrapped via `wrapper:GetUIObject()` first, otherwise the C side will error
---or misbehave because the wrapper has no frame userdata.
---The optional second return value (df_label) is the label widget; it is also a wrapper (see label.lua).
---@param parent frame
---@param width number? default 150
---@param height number? default 20
---@param minValue number? default 1
---@param maxValue number? default 2
---@param step number? default 1
---@param defaultv number? default to minValue
---@param isDecemal boolean? default false
---@param member string?
---@param name string?
---@param label string?
---@param sliderTemplate string|table|nil
---@param labelTemplate string|table|nil
---@return df_slider, df_label?
function DF:CreateSlider (parent, width, height, minValue, maxValue, step, defaultv, isDecemal, member, name, label, sliderTemplate, labelTemplate)
	--returns a wrapper table (not a frame); unwrap via wrapper:GetUIObject() / wrapper.widget when handing to Blizzard APIs
	local slider, labelText = DF:NewSlider(parent, parent, name, member, width, height, minValue, maxValue, step, defaultv, isDecemal, false, label, sliderTemplate, labelTemplate)
	return slider, labelText
end

---@return df_slider, df_label?
function DF:NewSlider (parent, container, name, member, width, height, minValue, maxValue, step, defaultValue, isDecemal, isSwitch, with_label, slider_template, label_template)
	if (not name) then
		name = "DetailsFrameworkSlider" .. DF.SliderCounter
		DF.SliderCounter = DF.SliderCounter + 1
	end

	if (not parent) then
		error("Details! FrameWork: parent not found.", 2)
	end

	if (not container) then
		container = parent
	end

	if (name:find("$parent")) then
		local parentName = DF:GetParentName(parent)
		name = name:gsub("$parent", parentName)
	end

	local SliderObject = {type = "slider", dframework = true}

	if (member) then
		parent[member] = SliderObject
	end

	if (parent.dframework) then
		parent = parent.widget
	end
	if (container.dframework) then
		container = container.widget
	end

	--defaults
	minValue = minValue or 1
	maxValue = maxValue or 2
	step = step or 1
	defaultValue = defaultValue or minValue

	width = width or 160
	height = height or 20

	--default members
	SliderObject.lockdown = false
	SliderObject.container = container

	SliderObject.slider = CreateFrame("slider", name, parent,"BackdropTemplate")
	SliderObject.widget = SliderObject.slider

	SliderObject.useDecimals = isDecemal or false

	if (SliderObject.useDecimals) then
		SliderObject.slider:SetValueStep(0.01)
	else
		SliderObject.slider:SetValueStep(step)
		SliderObject.slider:SetObeyStepOnDrag(true)
	end

	if (not APISliderFunctions) then
		APISliderFunctions = true
		local idx = getmetatable(SliderObject.slider).__index
		for funcName, funcAddress in pairs(idx) do
			if (not DFSliderMetaFunctions[funcName]) then
				DFSliderMetaFunctions[funcName] = function(object, ...)
					local x = loadstring( "return _G['" .. object.slider:GetName() .. "']:" .. funcName .. "(...)")
					return x(...)
				end
			end
		end
	end

	SliderObject.slider.MyObject = SliderObject
	PixelUtil.SetSize(SliderObject.slider, width, height)
	SliderObject.slider:SetOrientation("horizontal")
	SliderObject.slider:SetMinMaxValues(minValue, maxValue)
	SliderObject.slider:SetValue(defaultValue)
	SliderObject.ivalue = defaultValue

	SliderObject.slider:SetBackdrop({edgeFile = "Interface\\Buttons\\UI-SliderBar-Border", edgeSize = 8})
	SliderObject.slider:SetBackdropColor(0.9, 0.7, 0.7, 1.0)

	SliderObject.thumb = SliderObject.slider:CreateTexture(nil, "artwork")
	SliderObject.thumb:SetTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
	SliderObject.thumb:SetSize(30 + (height * 0.2), height * 1.2)
	SliderObject.thumb.originalWidth = SliderObject.thumb:GetWidth()
	SliderObject.thumb.originalHeight = SliderObject.thumb:GetHeight()
	SliderObject.thumb:SetAlpha(0.7)
	SliderObject.slider:SetThumbTexture (SliderObject.thumb)
	SliderObject.slider.thumb = SliderObject.thumb

	SliderObject.slider_left = SliderObject.slider:CreateTexture("$parentLeft", "artwork")
	SliderObject.slider_left:SetPoint("topright", SliderObject.slider, "topleft", 0, 0)
	SliderObject.slider_left:SetPoint("bottomright", SliderObject.slider, "bottomleft", 0, 0)
	SliderObject.slider_left:SetWidth(11)

	SliderObject.slider_right = SliderObject.slider:CreateTexture("$parentRight", "artwork")
	SliderObject.slider_right:SetPoint("topleft", SliderObject.slider, "topright", 0, 0)
	SliderObject.slider_right:SetPoint("bottomleft", SliderObject.slider, "bottomright", 0, 0)
	SliderObject.slider_right:SetWidth(11)

	SliderObject.slider_middle = SliderObject.slider:CreateTexture("$parentMiddle", "artwork")
	SliderObject.slider_middle:SetPoint("topleft", SliderObject.slider_left, "topright", 0, 0)
	SliderObject.slider_middle:SetPoint("bottomleft", SliderObject.slider_left, "bottomright", 0, 0)
	SliderObject.slider_middle:SetPoint("topright", SliderObject.slider_right, "topleft", 0, 0)
	SliderObject.slider_middle:SetPoint("bottomright", SliderObject.slider_right, "bottomleft", 0, 0)

	if (not isSwitch) then
		SliderObject.have_tooltip = "Right Click to Type the Value"
	end

	SliderObject.amt = SliderObject.slider:CreateFontString(nil, "overlay", "GameFontHighlightSmall")

	local amt = defaultValue
	if (amt < 10 and amt >= 1) then
		amt = "0" .. amt
	end

	if (SliderObject.useDecimals) then
		SliderObject.amt:SetText(string.format("%.2f", amt))
	else
		SliderObject.amt:SetText(math.floor(amt))
	end

	SliderObject.amt:SetTextColor(.8, .8, .8, 1)
	SliderObject.amt:SetPoint("center", SliderObject.thumb, "center")
	SliderObject.slider.amt = SliderObject.amt

	SliderObject.previous_value = {defaultValue or 0, 0, 0}

	--hooks
	SliderObject.HookList = {
		OnEnter = {},
		OnLeave = {},
		OnHide = {},
		OnShow = {},
		OnMouseDown = {},
		OnMouseUp = {},

		OnValueChange = {},
		OnValueChanged = {},
	}

	SliderObject.slider:SetScript("OnEnter", OnEnter)
	SliderObject.slider:SetScript("OnLeave", OnLeave)
	SliderObject.slider:SetScript("OnHide", OnHide)
	SliderObject.slider:SetScript("OnShow", OnShow)
	SliderObject.slider:SetScript("OnValueChanged", OnValueChanged)
	SliderObject.slider:SetScript("OnMouseDown", OnMouseDown)
	SliderObject.slider:SetScript("OnMouseUp", OnMouseUp)

	setmetatable(SliderObject, DFSliderMetaFunctions)

	SliderObject:SetTooltip("right click to type the value")

	if (with_label) then
		local label = DF:CreateLabel(SliderObject.slider, with_label, nil, nil, nil, "label", nil, "overlay")
		label.text = with_label
		SliderObject.slider:SetPoint("left", label.widget, "right", 2, 0)
		with_label = label

		if (label_template) then
			label:SetTemplate(label_template)
		end

		SliderObject.label = label
	end

	if (slider_template) then
		SliderObject:SetTemplate(slider_template)
	end

	return SliderObject, with_label
end

DF.AdjustmentSliderOptions = {
	width = 70,
	height = 20,
	scale_factor = 1,
}

DF.AdjustmentSliderFunctions = {
	SetScaleFactor = function(self, scalar)
		self.options.scale_factor = scalar or 1
	end,

	GetScaleFactor = function(self, scalar)
		return self.options.scale_factor
	end,

	SetCallback = function(self, func)
		self.callback = func
	end,

	SetPayload = function(self, ...)
		self.payload = {...}
	end,

	RunCallback = function(adjustmentSlider, valueX, valueY, isLiteral)
		local result, errorText = pcall(adjustmentSlider.callback, adjustmentSlider, valueX, valueY, isLiteral, adjustmentSlider:DumpPayload())
		if (not result) then
			DF:Msg("AdjustmentSlider callback Error:", errorText)
			return false
		end
	end,

	--calculate if the mouse has moved and call a callback
	PressingOnUpdate = function(adjustmentSlider, deltaTime)
		if (GetTime() > adjustmentSlider.NextTick) then
			--get currentr mouse position
			local mouseX, mouseY = GetCursorPosition()
			local verticalValue
			local horizontalValue

			--find distance
			local xDelta = adjustmentSlider.MouseX - mouseX --moving the mouse to right or up result in a negative delta
			local yDelta = adjustmentSlider.MouseY - mouseY

			if (adjustmentSlider.buttonPressed ~= "center") then
				if (adjustmentSlider.buttonPressedTime + 0.5 < GetTime()) then
					local scaleResultBy = adjustmentSlider:GetScaleFactor()
					if (adjustmentSlider.buttonPressed == "left") then
						DF.AdjustmentSliderFunctions.RunCallback(adjustmentSlider, -1 * scaleResultBy, 0, true)

					elseif (adjustmentSlider.buttonPressed == "right") then
						DF.AdjustmentSliderFunctions.RunCallback(adjustmentSlider, 1 * scaleResultBy, 0, true)
					end
				end

			elseif (xDelta ~= 0 or yDelta ~= 0) then
				if (adjustmentSlider.buttonPressed == "center") then
					--invert axis as left is positive and right is negative in the deltas
					xDelta = xDelta * -1
					yDelta = yDelta * -1

					horizontalValue = DF:MapRangeClamped(-20, 20, -1, 1, xDelta)
					verticalValue = DF:MapRangeClamped(-20, 20, -1, 1, yDelta)

					local speed = 6 --how fast it moves
					local mouseDirection = CreateVector2D(mouseX - adjustmentSlider.initialMouseX, mouseY - adjustmentSlider.initialMouseY)
					local length = DF:MapRangeClamped(-100, 100, -1, 1, mouseDirection:GetLength())
					mouseDirection:Normalize()
					mouseDirection:ScaleBy(speed * length)
					adjustmentSlider.centerArrowArtwork:SetPoint("center", adjustmentSlider.centerButton.widget, "center", mouseDirection:GetXY())
				end

				local scaleResultBy = adjustmentSlider:GetScaleFactor()
				DF.AdjustmentSliderFunctions.RunCallback(adjustmentSlider, horizontalValue * scaleResultBy, verticalValue * scaleResultBy, false)

				adjustmentSlider.MouseX = mouseX
				adjustmentSlider.MouseY = mouseY
			end

			adjustmentSlider.NextTick = GetTime() + 0.05
		end
	end,

	--button can be the left or right button
	OnButtonDownkHook = function(button)
		local object = button.MyObject

		--change the icon
		if (object.direction == "center") then
			DF:DisableOnEnterScripts()
		end

		local adjustmentSlider = object:GetParent()
		adjustmentSlider.NextTick = GetTime() + 0.05

		--save where the mouse is on the moment of the click
		local mouseX, mouseY = GetCursorPosition()
		adjustmentSlider.MouseX = mouseX
		adjustmentSlider.MouseY = mouseY
		adjustmentSlider.initialMouseX = mouseX
		adjustmentSlider.initialMouseY = mouseY

		adjustmentSlider.buttonPressed = object.direction

		--start monitoring the mouse moviment
		adjustmentSlider.buttonPressedTime = GetTime()
		adjustmentSlider:SetScript("OnUpdate", DF.AdjustmentSliderFunctions.PressingOnUpdate)
	end,

	--button can be the left or right button
	OnButtonUpHook = function(button)
		local object = button.MyObject

		--change the icon
		if (object.direction == "center") then
			DF:EnableOnEnterScripts()
		end

		local adjustmentSlider = object:GetParent()

		--check if the mouse did not moved at all, if not send a callback with a value of 1
		local mouseX, mouseY = GetCursorPosition()
		if (mouseX == adjustmentSlider.MouseX and mouseY == adjustmentSlider.MouseY and adjustmentSlider.buttonPressedTime+0.5 > GetTime()) then
			if (object.direction == "left") then
				DF.AdjustmentSliderFunctions.RunCallback(adjustmentSlider, -1, 0, true)
			elseif (object.direction == "right") then
				DF.AdjustmentSliderFunctions.RunCallback(adjustmentSlider, 1, 0, true)
			end
		end

		adjustmentSlider.centerArrowArtwork:SetPoint("center", adjustmentSlider.centerButton.widget, "center", 0, 0)

		adjustmentSlider:SetScript("OnUpdate", nil)
	end,

	Disable = function(adjustmentSlider)
		adjustmentSlider.leftButton:Disable()
		adjustmentSlider.rightButton:Disable()
		adjustmentSlider.centerButton:Disable()
	end,

	Enable = function(adjustmentSlider)
		adjustmentSlider.leftButton:Enable()
		adjustmentSlider.rightButton:Enable()
		adjustmentSlider.centerButton:Enable()
	end,
}

local createAdjustmentSliderFrames = function(parent, options, name)
	--frame it self
	local adjustmentSlider = CreateFrame("frame", name, parent, "BackdropTemplate")

	DF:Mixin(adjustmentSlider, DF.OptionsFunctions)
	DF:Mixin(adjustmentSlider, DF.AdjustmentSliderFunctions)
	DF:Mixin(adjustmentSlider, DF.PayloadMixin)
	DF:Mixin(adjustmentSlider, DF.SetPointMixin)
	--DF:Mixin(adjustmentSlider, DF.FrameMixin)

	adjustmentSlider:BuildOptionsTable(DF.AdjustmentSliderOptions, options)
	adjustmentSlider:SetSize(adjustmentSlider.options.width, adjustmentSlider.options.height)

	local leftButton = DF:CreateButton(adjustmentSlider, function()end, 20, 20, "", "left", -1, nil, nil, name .. "LeftButton")
	local rightButton = DF:CreateButton(adjustmentSlider, function()end, 20, 20, "", "right", 1, nil, nil, name .. "RightButton")

	leftButton:SetHook("OnMouseDown", DF.AdjustmentSliderFunctions.OnButtonDownkHook)
	rightButton:SetHook("OnMouseDown", DF.AdjustmentSliderFunctions.OnButtonDownkHook)
	leftButton:SetHook("OnMouseUp", DF.AdjustmentSliderFunctions.OnButtonUpHook)
	rightButton:SetHook("OnMouseUp", DF.AdjustmentSliderFunctions.OnButtonUpHook)

	leftButton:SetPoint("left", adjustmentSlider, "left", 0, 0)
	rightButton:SetPoint("right", adjustmentSlider, "right", 0, 0)

	leftButton:SetIcon("Minimal_SliderBar_Button_Left", 8, 14)
	rightButton:SetIcon("Minimal_SliderBar_Button_Right", 8, 14)

	leftButton.direction = "left"
	rightButton.direction = "right"

	--center button
	local centerButton = DF:CreateButton(adjustmentSlider, function()end, 20, 20, "", "center", 0, nil, nil, name .. "CenterButton")
	centerButton:SetPoint("center", adjustmentSlider, "center", -3, 0)
	centerButton:SetIcon("Minimal_SliderBar_Button", nil, nil, nil, nil, "transparent")
	centerButton.direction = "center"
	centerButton:SetHook("OnMouseDown", DF.AdjustmentSliderFunctions.OnButtonDownkHook)
	centerButton:SetHook("OnMouseUp", DF.AdjustmentSliderFunctions.OnButtonUpHook)

	local centerArrowArtwork = centerButton:CreateTexture("$parentCenterArrowArtwork", "artwork")
	centerArrowArtwork:SetAtlas("Minimal_SliderBar_Button")
	centerArrowArtwork:SetPoint("center", centerButton.widget, "center", 0, 0)
	centerArrowArtwork:SetSize(16, 16)
	centerArrowArtwork:SetAlpha(1)

	adjustmentSlider.leftButton = leftButton
	adjustmentSlider.rightButton = rightButton
	adjustmentSlider.centerButton = centerButton
	adjustmentSlider.centerArrowArtwork = centerArrowArtwork

	return adjustmentSlider
end

--creates a slider with left and right buttons and a center button, on click the hold, mouse moviments adjust the value and trigger a callback with a normallized x and y values of the mouse movement
--@parent: who is the parent of this frame
--@callback: run when there's a change in any of the two axis
--@options: a table containing options for the frame, see /dump DetailsFramework.AdjustmentSliderOptions
--@name: the name of the frame, if none a generic name is created
function DF:CreateAdjustmentSlider(parent, callback, options, name, ...)
	if (not name) then
		name = "DetailsFrameworkAdjustmentSlider" .. DF.SliderCounter
		DF.SliderCounter = DF.SliderCounter + 1

	elseif (not parent) then
		return error("DF:CreateAdjustmentSlider(): parent not found.", 2)
	end

	local ASFrame = createAdjustmentSliderFrames(parent, options, name)
	ASFrame:SetPayload(...)
	ASFrame.callback = callback

	return ASFrame
end

----------------------------------------------------------------------------------------------------------------
function DF:DisableOnEnterScripts()
	local ignoreOnEnterZone = DF:CreateOnEnterIgnoreZone()
	ignoreOnEnterZone:Show()
end

function DF:EnableOnEnterScripts()
	local ignoreOnEnterZone = DF:CreateOnEnterIgnoreZone()
	ignoreOnEnterZone:Hide()
end

function DF:CreateOnEnterIgnoreZone()
	if (not _G.DetailsFrameworkIgnoreHoverOverFrame) then
		local ignoreOnEnterFrame = CreateFrame("frame", "DetailsFrameworkIgnoreHoverOverFrame", UIParent)
		ignoreOnEnterFrame:SetFrameStrata("TOOLTIP")
		ignoreOnEnterFrame:SetFrameLevel(9999)
		ignoreOnEnterFrame:SetAllPoints()
		ignoreOnEnterFrame:EnableMouse(true)
		ignoreOnEnterFrame:Hide()
	end

	return _G.DetailsFrameworkIgnoreHoverOverFrame
end

local mouseCaptureFunc = function(self, deltaTime)
	local cMousePosX, cMousePosY = GetCursorPosition()

	local offSetX = cMousePosX - self.mousePosX
	local offSetY = cMousePosY - self.mousePosY
	self.mousePosX = cMousePosX
	self.mousePosY = cMousePosY

	--mouse moving right or up turns the knob clockwise, left or down turns it counter clockwise
	--clockwise means decreasing the radian, hence the subtraction
	local delta = (offSetX + offSetY) * self.mouseToRadians
	self.currentRadian = Clamp(self.currentRadian - delta, self.minRadian, self.maxRadian)

	--normalized value: 0 at the bottom-left, maxValue at the bottom-right
	self.value = (self.maxRadian - self.currentRadian) / (self.maxSweep * 2) * self.maxValue

	self.KnobTexture:SetRotation(self.currentRadian)
end

local knobOnMouseDown = function(self)
	self.mousePosX, self.mousePosY = GetCursorPosition()
	self:SetScript("OnUpdate", mouseCaptureFunc)
	self.capturingMouseMoviment = true
end

local knobOnMouseUp = function(self)
	self.capturingMouseMoviment = false
	self:SetScript("OnUpdate", nil)
end

local createKnob = function(parent, name, width, height)
    local f = CreateFrame("frame", name, parent)
    f:SetSize(width, height)
	f.maxSweep = math.rad(150)
    f.value = 0
    f.maxValue = 1
    --positive rotation is counter clockwise in wow, so the min value (bottom-left) is +maxSweep and the max value (bottom-right) is -maxSweep
    f.minRadian = -f.maxSweep
    f.maxRadian = f.maxSweep
    f.currentRadian = f.maxRadian

	f.mousePosX = 0
	f.mousePosY = 0
	f.mouseToRadians = 0.02

    local texture = f:CreateTexture("$parentCircularTexture", "overlay")
    texture:SetTexture([[Interface\AddOns\Details\images\buttons\button1.png]])
    texture:SetPoint("center")
    texture:SetRotation(f.currentRadian)
	f.KnobTexture = texture

    f:SetScript("OnMouseDown", knobOnMouseDown)
    f:SetScript("OnMouseUp", knobOnMouseUp)

	return f
end

function DF:CreateKnob(parent, name, width, height)
	if (not name) then
		name = "DetailsFrameworkKnob" .. DF.SliderCounter
		DF.SliderCounter = DF.SliderCounter + 1

	elseif (not parent) then
		return error("DF:CreateKnob(): parent not found.", 2)
	end

	local newKnob = createKnob(parent, name, width, height)
	return newKnob
end
--createKnob()