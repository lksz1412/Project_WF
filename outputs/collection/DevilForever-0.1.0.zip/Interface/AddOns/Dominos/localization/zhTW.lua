--[[
	localization.tw.lua
    zhTW (convert from zhCN)
    xuxianhe@gmail.com
    yaroot##gmail#com

	2016/7/18 New translations by 彩虹ui https://www.facebook.com/rainbowui/

	Triditional Chinese 繁體中文
]]

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos', 'zhTW')
if not L then return end

L.ActionBarButtonDisplayName = "快捷列 %d 按鈕 %d"
L.AlertsBarDisplayName = "通知"
L.AvailableProfiles = '可用的設定檔'
L.BarDisplayName = "%s"
L.BindingEnterTip = '<Shift+左鍵> 進入按鍵設定模式'
L.BindingExitTip = '<Shift+左鍵> 退出按鍵設定模式'
L.CantDeleteCurrentProfile = '無法刪除當前設定檔'
L.ConfigDesc = '切換快捷列配置模式'
L.ConfigEnterTip = '<左鍵> 進入快捷列配置模式'
L.ConfigExitTip = '<左鍵> 退出快捷列配置模式'
L.ConfigMode = '快捷列配置模式'
L.ConfigModeHelp = '<拖曳> 任何條列移動位置  <右鍵> 進行設定。  <中鍵> 或 <Shift+右鍵> 切換顯示/隱藏'
L.CopyDesc = '複製設定，從 <profile>'
L.DeleteDesc = '刪除 <profile>'
L.HideBar = '<中鍵 或 Shift+右鍵> 隱藏'
L.HideFramesDesc = '隱藏 <frameList>'
L.InvalidProfile = '無效的設定檔 "%s"'
L.KeyboardMovementTip = "使用移動按鍵來調整位置。"
L.ListDesc = '列出所有設定檔'
L.PrintVersionDesc = '顯示當前版本'
L.ProfileCopied = '複製設定，從 "%s"'
L.ProfileCreated = '已建立新設定檔 "%s"'
L.ProfileDeleted = '已刪除設定檔 "%s"'
L.ProfileLoaded = '設定檔切換成 "%s"'
L.ProfileReset = '重置設定檔 "%s"'
L.QueueStatusBarDisplayName = "排隊資訊"
L.ResetDesc = '恢復成預設的設定'
L.RollBarDisplayName = "骰子面板"
L.SaveDesc = '儲存目前設定並切換成 <profile>'
L.SetAlpha = '<滑鼠滾輪> 設定透明度 (|cffffffff%d|r)'
L.SetAlphaDesc = '設定 <frameList> 的透明度'
L.SetColsDesc = '設定 <frameList> 的行數'
L.SetDesc = '切換設定成 <profile>'
L.SetFadeDesc = '設定 <frameList> 的淡出透明度'
L.SetPadDesc = '設定 <frameList> 的內距'
L.SetScaleDesc = '設定 <frameList> 的縮放大小'
L.SetSpacingDesc = '設定 <frameList> 的間距'
L.ShowBar = '<中鍵 或 Shift+右鍵> 顯示'
L.ShowConfig = '<右鍵> 進行設定'
L.ShowFramesDesc = '顯示 <frameList>'
L.Shown = "已顯示"
L.ShowOptionsTip = '<右鍵> 顯示設定選項'
L.TipRollBar = '在隊伍中時顯示擲骰物品的面板。'
L.ToggleFramesDesc = '切換 <frameList>'
L.Updated = '已更新成 v%s'

L.AddonName = "達美樂快捷列"
